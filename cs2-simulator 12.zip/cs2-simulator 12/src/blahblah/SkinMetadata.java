package blahblah;

import blahblah.hGui.*;
import java.awt.*;
import java.awt.event.*;
import java.util.Set;
import javax.swing.*;

/** Extracted reusable model or widget; behavior retained from the original source. */
final class SkinMetadata {
  final String imageUrl;
  final Double minFloat;
  final Double maxFloat;
  final String category;
  final String rarity;
  final Set<String> crateNames;
  final String collectionName;

  SkinMetadata(
      String imageUrl,
      Double minFloat,
      Double maxFloat,
      String category,
      String rarity,
      Set<String> crateNames) {
    this(imageUrl, minFloat, maxFloat, category, rarity, crateNames, null);
  }

  SkinMetadata(
      String imageUrl,
      Double minFloat,
      Double maxFloat,
      String category,
      String rarity,
      Set<String> crateNames,
      String collectionName) {
    this.collectionName = collectionName;
    this.imageUrl = imageUrl;
    this.minFloat = minFloat;
    this.maxFloat = maxFloat;
    this.category = category;
    this.rarity = rarity;
    this.crateNames = crateNames == null ? Set.of() : Set.copyOf(crateNames);
  }
}
