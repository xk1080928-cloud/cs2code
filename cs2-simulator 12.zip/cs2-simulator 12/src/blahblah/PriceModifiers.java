package blahblah;

import blahblah.hGui.*;
import java.awt.*;
import java.awt.event.*;
import java.util.Map;
import javax.swing.*;

/** Price Modifiers: focused feature implementation. */
final class PriceModifiers {
  private final hGui app;

  PriceModifiers(hGui app) {
    this.app = app;
  }

  double getUnifiedConditionPriceMultiplier(String condition) {
    if (condition == null || "Agent".equals(condition) || "Normal".equals(condition)) return 1.0;
    if ("Factory New".equals(condition)) return 2.5;
    if ("Minimal Wear".equals(condition)) return 1.7;
    if ("Field-Tested".equals(condition)) return 1.0;
    if ("Well-Worn".equals(condition)) return 0.8;
    if ("Battle-Scarred".equals(condition)) return 0.65;
    return 1.0;
  }

  double getConditionPriceMultiplier(String skinName, String condition) {
    if ("Normal".equals(condition)) return 1.0;
    String cacheKey = skinName == null ? null : skinName.replace("StatTrak ", "").trim();
    Map<String, Double> conditionMultipliers =
        cacheKey == null ? null : app.liveConditionPriceMultipliers.get(cacheKey);
    return app.priceModifiers.getConditionPriceMultiplier(
        skinName, condition, conditionMultipliers);
  }

  double getConditionPriceMultiplier(
      String skinName, String condition, Map<String, Double> conditionMultipliers) {
    if (conditionMultipliers != null) {
      Double liveMultiplier = conditionMultipliers.get(condition);
      if (liveMultiplier != null
          && Double.isFinite(liveMultiplier)
          && liveMultiplier > 0.0
          && app.priceModifiers.isPlausibleWearMultiplier(condition, liveMultiplier)) {
        return liveMultiplier;
      }
    }
    if (skinName != null) {
      String cleanSkin = skinName.replace("StatTrak ", "").trim();
      if (("Gloves".equals(app.itemMetadataService.getSkinRarity(cleanSkin))
              || cleanSkin.contains("Hand Wraps"))
          && "Factory New".equals(condition)) {
        return 4.0;
      }
    }
    return app.priceModifiers.getUnifiedConditionPriceMultiplier(condition);
  }

  boolean isPlausibleWearMultiplier(String condition, double multiplier) {
    if ("Battle-Scarred".equals(condition) || "Well-Worn".equals(condition)) {
      return multiplier >= 0.05 && multiplier <= 3.0;
    }
    return multiplier >= 0.02 && multiplier <= 75.0;
  }

  double getMarketConditionMultiplier(String skinName, String condition) {
    return app.priceModifiers.getConditionPriceMultiplier(skinName, condition);
  }

  void showDeliveryReadyNotification(TradeOffer trade) {
    String itemName =
        (trade.npcOfferedItems != null && !trade.npcOfferedItems.isEmpty())
            ? trade.npcOfferedItems.get(0).name
            : "your item";
    JPanel notif = new JPanel(new BorderLayout(6, 0));
    notif.setBackground(new Color(20, 40, 20));
    notif.setBorder(
        BorderFactory.createCompoundBorder(
            BorderFactory.createLineBorder(new Color(70, 200, 100), 2),
            BorderFactory.createEmptyBorder(8, 10, 8, 10)));
    notif.setCursor(new Cursor(Cursor.HAND_CURSOR));
    notif.setToolTipText("Click to dismiss");
    JLabel icon = new JLabel("\u2713", SwingConstants.CENTER);
    icon.setFont(new Font("Consolas", Font.BOLD, 22));
    icon.setForeground(new Color(70, 200, 100));
    notif.add(icon, BorderLayout.WEST);
    JPanel textPanel = new JPanel(new GridLayout(2, 1, 0, 2));
    textPanel.setBackground(new Color(20, 40, 20));
    JLabel titleLbl = new JLabel("DELIVERY READY");
    titleLbl.setFont(new Font("Consolas", Font.BOLD, 10));
    titleLbl.setForeground(new Color(70, 200, 100));
    JLabel msgLbl =
        new JLabel(
            itemName
                + " from "
                + (trade.marketplaceName != null ? trade.marketplaceName : "Marketplace"));
    msgLbl.setFont(new Font("Consolas", Font.BOLD, 12));
    msgLbl.setForeground(Color.WHITE);
    textPanel.add(titleLbl);
    textPanel.add(msgLbl);
    notif.add(textPanel, BorderLayout.CENTER);
    int w = 360, h = 72;
    JLayeredPane layered = app.getLayeredPane();
    int x = layered.getWidth() - w - 12;
    int y = layered.getHeight() - h - 12;
    notif.setBounds(x, y, w, h);
    layered.add(notif, JLayeredPane.POPUP_LAYER);
    layered.revalidate();
    layered.repaint();
    MouseAdapter dismiss =
        new MouseAdapter() {
          @Override
          public void mouseClicked(MouseEvent e) {
            layered.remove(notif);
            layered.repaint();
          }
        };
    notif.addMouseListener(dismiss);
    for (java.awt.Component c : notif.getComponents()) c.addMouseListener(dismiss);
    for (java.awt.Component c : textPanel.getComponents()) c.addMouseListener(dismiss);
    javax.swing.Timer t =
        new javax.swing.Timer(
            7000,
            e -> {
              layered.remove(notif);
              layered.repaint();
            });
    t.setRepeats(false);
    t.start();
  }

  void showTradeCancelNotification(String message) {
    JPanel notif = new JPanel(new BorderLayout(6, 0));
    notif.setBackground(new Color(35, 20, 20));
    notif.setBorder(
        BorderFactory.createCompoundBorder(
            BorderFactory.createLineBorder(new Color(220, 60, 60), 2),
            BorderFactory.createEmptyBorder(8, 10, 8, 10)));
    notif.setCursor(new Cursor(Cursor.HAND_CURSOR));
    notif.setToolTipText("Click to dismiss");

    JLabel icon = new JLabel("X", SwingConstants.CENTER);
    icon.setFont(new Font("Consolas", Font.BOLD, 22));
    notif.add(icon, BorderLayout.WEST);

    JPanel textPanel = new JPanel(new GridLayout(2, 1, 0, 2));
    textPanel.setBackground(new Color(35, 20, 20));
    JLabel titleLbl = new JLabel("TRADE CANCELLED");
    titleLbl.setFont(new Font("Consolas", Font.BOLD, 10));
    titleLbl.setForeground(new Color(220, 80, 80));
    JLabel msgLbl = new JLabel(message);
    msgLbl.setFont(new Font("Consolas", Font.BOLD, 12));
    msgLbl.setForeground(Color.WHITE);
    textPanel.add(titleLbl);
    textPanel.add(msgLbl);
    notif.add(textPanel, BorderLayout.CENTER);

    int w = 340, h = 72;
    JLayeredPane layered = app.getLayeredPane();
    int x = layered.getWidth() - w - 12;
    int y = layered.getHeight() - h - 12;
    notif.setBounds(x, y, w, h);
    layered.add(notif, JLayeredPane.POPUP_LAYER);
    layered.revalidate();
    layered.repaint();

    MouseAdapter dismiss =
        new MouseAdapter() {
          @Override
          public void mouseClicked(MouseEvent e) {
            layered.remove(notif);
            layered.repaint();
          }
        };
    notif.addMouseListener(dismiss);
    for (java.awt.Component c : notif.getComponents()) c.addMouseListener(dismiss);
    for (java.awt.Component c : textPanel.getComponents()) c.addMouseListener(dismiss);
    javax.swing.Timer t =
        new javax.swing.Timer(
            5000,
            e -> {
              layered.remove(notif);
              layered.repaint();
            });
    t.setRepeats(false);
    t.start();
  }
}
