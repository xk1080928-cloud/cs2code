package blahblah;

import blahblah.hGui.*;
import java.awt.*;
import java.awt.event.*;
import javax.swing.*;

/** Extracted reusable model or widget; behavior retained from the original source. */
final class AnimationConfig {
  static final int STRIP_COUNT = 60;
  static final int FINAL_INDEX = 50;
  static final int SKIN_WIDTH = 210;
  static final int SKIN_HEIGHT = 155;
  static final int CARD_GAP = 6;
  static final int SPACING = SKIN_WIDTH + CARD_GAP;
  static final int TIMER_DELAY_MS = 16;
  static final int RESULT_DELAY_MS = 800;
  static final int DIALOG_WIDTH = 800;
  static final int DIALOG_HEIGHT = 340;
  static final int PANEL_HEIGHT = 240;
  static final double MAX_SPEED = 58.0;
  static final double ACCELERATION = 2.4;
  static final double DECEL_ZONE = 1800.0;
  static final double STOP_VELOCITY = 0.15;
}
