package blahblah;

import java.awt.*;
import java.util.Locale;
import javax.swing.*;

/** Dedicated Marketplaces tab, also the specific-owned-item sale destination picker. */
final class MarketplaceDirectory {
  private final hGui app;

  MarketplaceDirectory(hGui app) {
    this.app = app;
  }

  private String money(double value) {
    return Double.isFinite(value) && value > 0
        ? String.format(Locale.US, "$%,.2f", value)
        : "Unavailable";
  }

  JPanel createDirectory() {
    JPanel root = app.cs2Screens.cs2Glass(new BorderLayout(0, 16));
    root.setName("marketplaceDirectory");
    root.setBorder(BorderFactory.createEmptyBorder(24, 28, 24, 28));
    JPanel heading = app.cs2Screens.cs2Glass(new BorderLayout(18, 12));
    JLabel title =
        app.cs2Screens.cs2Text(
            app.exchangePendingSale == null
                ? "Marketplaces"
                : "Choose where to sell: " + app.exchangePendingSale.name,
            24,
            Color.WHITE);
    title.setName("marketplaceDirectoryTitle");
    heading.add(title, BorderLayout.NORTH);
    JTextField search = app.exchangeWidgets.exchangeSearch("");
    search.setName("marketplaceDirectorySearch");
    search.putClientProperty("placeholder", "Find a marketplace…");
    heading.add(search);
    JButton clear =
        app.cs2Screens.cs2Button(
            "Browse without selling",
            false,
            e -> {
              app.exchangePendingSale = null;
              app.loadoutScreen.refreshMarketTab();
              app.exchangeHostSections.setSelectedIndex(1);
            });
    if (app.exchangePendingSale != null) heading.add(clear, BorderLayout.EAST);
    root.add(heading, BorderLayout.NORTH);
    JPanel grid = app.cs2Screens.cs2Grid(3, 18, 18);
    grid.setName("marketplaceDirectoryGrid");
    root.add(app.exchangeWidgets.exchangeScroll(grid));
    Runnable render =
        () -> {
          grid.removeAll();
          String query = search.getText().trim().toLowerCase(Locale.ROOT);
          for (MarketplaceProfile p : MarketplaceProfile.CATALOG)
            if (p.name.toLowerCase(Locale.ROOT).contains(query)) {
              JPanel card = app.exchangeWidgets.exchangePanel(p, new BorderLayout(0, 16));
              card.setBorder(
                  BorderFactory.createCompoundBorder(
                      BorderFactory.createMatteBorder(
                          3, 0, 0, 0, app.exchangeWidgets.exchangeAccent(p)),
                      BorderFactory.createEmptyBorder(22, 20, 22, 20)));
              card.add(
                  app.exchangeWidgets.exchangeLabel(
                      p.name, 24, app.exchangeWidgets.exchangeAccent(p)),
                  BorderLayout.NORTH);
              JPanel details = app.cs2Screens.cs2Glass(new GridLayout(0, 1, 0, 10));
              details.add(
                  app.exchangeWidgets.exchangeLabel(
                      String.format(
                          "%,d available listings",
                          app.exchangeStockService.countStock(
                              app.exchangeSiteStock.getOrDefault(
                                  p.name, java.util.Collections.emptyList()))),
                      14,
                      Color.WHITE));
              details.add(
                  app.exchangeWidgets.exchangeLabel(
                      "<html>" + app.marketplacePricing.label(p) + "</html>", 12, Theme.TEXT_DIM));
              details.add(
                  app.exchangeWidgets.exchangeLabel(
                      ExchangeStockService.supportsExchangeSwap(p.name)
                          ? "Buy / Sell / Swap"
                          : "Buy / Sell",
                      12,
                      Color.WHITE));
              card.add(details);
              InventoryItem sale = app.exchangePendingSale;
              card.putClientProperty("saleItem", sale);
              card.putClientProperty("saleMarketplace", p.name);
              if (sale != null) {
                double reference = app.marketplacePricing.lowest(p, sale);
                String referenceLabel = "Lowest matching ask";
                if (!Double.isFinite(reference)) {
                  reference =
                      app.marketplacePricing.automatic(p.name)
                          ? app.marketplacePricing.quote(p, sale)
                          : sale.price.doubleValue();
                  referenceLabel = "Reference (no matching offers)";
                }
                double ask = app.marketplacePricing.suggested(p, sale),
                    net = ask * (1 - app.exchangeTransactionService.exchangeListingFee(p)),
                    quick = app.marketplacePricing.quickSellQuote(p, sale);
                card.putClientProperty("saleReference", reference);
                card.putClientProperty("saleSuggested", ask);
                card.putClientProperty("saleQuickSell", quick);
                details.add(
                    app.exchangeWidgets.exchangeLabel(
                        referenceLabel + ": " + money(reference), 14, Color.WHITE));
                details.add(
                    app.exchangeWidgets.exchangeLabel(
                        "Suggested listing: " + money(ask) + "  •  Net after fee: " + money(net),
                        13,
                        Color.WHITE));
                details.add(
                    app.exchangeWidgets.exchangeLabel(
                        "Quick sell: you receive " + money(quick),
                        14,
                        app.exchangeWidgets.exchangeAccent(p)));
              }
              JButton open =
                  app.exchangeWidgets.exchangeButton(
                      p,
                      sale == null ? "Enter marketplace →" : "Sell this item on " + p.name,
                      () -> {
                        if (sale != null && !app.containerMarketService.owns(sale)) {
                          JOptionPane.showMessageDialog(
                              app, "That skin is no longer in your inventory.");
                          return;
                        }
                        app.exchangeScreens.openExchangeMarketplace(p, null, sale);
                      });
              open.setName("marketplaceDirectoryOpen-" + p.name);
              card.add(open, BorderLayout.SOUTH);
              grid.add(card);
            }
          grid.revalidate();
          grid.repaint();
        };
    app.exchangeWidgets.exchangeDebounce(search, render);
    render.run();
    return root;
  }
}
