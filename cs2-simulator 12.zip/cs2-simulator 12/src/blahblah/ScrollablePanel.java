package blahblah;

import blahblah.hGui.*;
import java.awt.*;
import java.awt.event.*;
import javax.swing.*;

/** Extracted reusable model or widget; behavior retained from the original source. */
class ScrollablePanel extends JPanel implements Scrollable {
  public boolean getScrollableTracksViewportWidth() {
    return true;
  }

  public Dimension getPreferredScrollableViewportSize() {
    return getPreferredSize();
  }

  public int getScrollableUnitIncrement(java.awt.Rectangle r, int o, int d) {
    return 16;
  }

  public int getScrollableBlockIncrement(java.awt.Rectangle r, int o, int d) {
    return 100;
  }

  public boolean getScrollableTracksViewportHeight() {
    return false;
  }
}
