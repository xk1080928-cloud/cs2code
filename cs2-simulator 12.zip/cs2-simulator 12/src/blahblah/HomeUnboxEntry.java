package blahblah;

import blahblah.hGui.*;
import java.awt.*;
import java.awt.event.*;
import javax.swing.*;

/** Extracted reusable model or widget; behavior retained from the original source. */
final class HomeUnboxEntry {
  final SaleRecord record;
  final String imageKey, rarity;
  final Image image;

  HomeUnboxEntry(SaleRecord record, String imageKey, String rarity, Image image) {
    this.record = record;
    this.imageKey = imageKey;
    this.rarity = rarity;
    this.image = image;
  }
}
