package blahblah;

import javax.swing.*;

/** Pixel-based wheel easing, with a blitting opaque viewport and no card reconstruction. */
final class SmoothScroll {
  static void install(JScrollPane pane) {
    pane.setWheelScrollingEnabled(false);
    pane.getViewport()
        .setScrollMode(
            pane.getViewport().isOpaque()
                ? JViewport.BLIT_SCROLL_MODE
                : JViewport.SIMPLE_SCROLL_MODE);
    JScrollBar bar = pane.getVerticalScrollBar();
    double[] target = {bar.getValue()}, position = {bar.getValue()};
    long[] last = {System.nanoTime()};
    Timer timer = new Timer(16, null);
    timer.addActionListener(
        e -> {
          if (!pane.isShowing() || bar.getValueIsAdjusting()) {
            timer.stop();
            return;
          }
          long now = System.nanoTime();
          double dt = Math.min(.08, (now - last[0]) / 1e9);
          last[0] = now;
          target[0] =
              Math.max(
                  bar.getMinimum(), Math.min(bar.getMaximum() - bar.getVisibleAmount(), target[0]));
          position[0] += (target[0] - position[0]) * (1 - Math.exp(-dt / .045));
          if (Math.abs(target[0] - position[0]) < .6) {
            position[0] = target[0];
            timer.stop();
          }
          bar.setValue((int) Math.round(position[0]));
        });
    timer.setCoalesce(true);
    pane.addMouseWheelListener(
        e -> {
          if (e.isShiftDown()) return;
          if (!timer.isRunning()) {
            position[0] = bar.getValue();
            target[0] = position[0];
            last[0] = System.nanoTime();
          }
          target[0] =
              Math.max(
                  bar.getMinimum(),
                  Math.min(
                      bar.getMaximum() - bar.getVisibleAmount(),
                      target[0] + e.getPreciseWheelRotation() * 52));
          timer.start();
          e.consume();
        });
    bar.addAdjustmentListener(
        e -> {
          if (e.getValueIsAdjusting()) {
            timer.stop();
            target[0] = position[0] = bar.getValue();
          }
        });
  }
}
