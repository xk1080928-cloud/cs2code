package blahblah;

import blahblah.hGui.*;
import java.awt.*;
import java.awt.event.*;
import java.awt.image.BufferedImage;
import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Set;
import javax.swing.*;

/** Opening Artwork Service: focused feature implementation. */
final class OpeningArtworkService {
  private final hGui app;

  OpeningArtworkService(hGui app) {
    this.app = app;
  }

  Image retainContainerThumbnail(Image image) {
    int width = image.getWidth(null), height = image.getHeight(null);
    if (width <= 0 || height <= 0) return image;
    double scale = Math.min(1.0, Math.min(280.0 / width, 200.0 / height));
    if (scale == 1.0) return image;
    BufferedImage thumbnail =
        new BufferedImage(
            Math.max(1, (int) Math.round(width * scale)),
            Math.max(1, (int) Math.round(height * scale)),
            BufferedImage.TYPE_INT_ARGB);
    Graphics2D g = thumbnail.createGraphics();
    g.setRenderingHint(
        RenderingHints.KEY_INTERPOLATION, RenderingHints.VALUE_INTERPOLATION_BICUBIC);
    g.drawImage(image, 0, 0, thumbnail.getWidth(), thumbnail.getHeight(), null);
    g.dispose();
    return thumbnail;
  }

  String describeArtworkKey(String key) {
    if (key.startsWith("case-selector-")) {
      for (CaseType source : CaseType.values())
        if (key.equals("case-selector-" + source.id)) return source.name + " [container]";
    }
    String wear = app.artworkService.artworkWear(key);
    return app.artworkService.artworkSkin(key)
        + (wear == null ? " [standard image]" : " (" + wear + ")");
  }

  Path artworkReportPath() {
    return Paths.get(System.getProperty("user.home"), ".csgo-skin-simulator", "artwork-report.txt");
  }

  String getArtworkLoadReport() {
    StringBuilder text =
        new StringBuilder("IMAGE LOADING REPORT\n")
            .append("Loaded URLs: ")
            .append(app.startupArtworkLoaded)
            .append(" / ")
            .append(app.startupArtworkTotal)
            .append("\nFallback wear images: ")
            .append(app.startupArtworkFallbacks)
            .append("\nUnavailable URLs: ")
            .append(app.startupArtworkFailed)
            .append("\nRetained container thumbnails: ")
            .append(app.containerArtwork.size())
            .append(
                "\n\n"
                    + "A fallback uses the standard online PNG when the genuine wear PNG cannot be"
                    + " loaded.\n")
            .append(
                "These are image/wear entries, not necessarily distinct skins.\n\n"
                    + "FALLBACK DETAILS\n");
    if (app.startupArtworkFallbackDetails.isEmpty()) text.append("None recorded.\n");
    for (Map.Entry<String, String> entry :
        new java.util.TreeMap<>(app.startupArtworkFallbackDetails).entrySet())
      text.append("\n")
          .append(app.openingArtworkService.describeArtworkKey(entry.getKey()))
          .append("\n")
          .append(entry.getValue())
          .append("\n");
    text.append("\nUNAVAILABLE DETAILS\n");
    if (app.startupArtworkUnavailableDetails.isEmpty()) text.append("None recorded.\n");
    for (Map.Entry<String, String> entry :
        new java.util.TreeMap<>(app.startupArtworkUnavailableDetails).entrySet())
      text.append("\n")
          .append(app.openingArtworkService.describeArtworkKey(entry.getKey()))
          .append("\n")
          .append(entry.getValue())
          .append("\n");
    return text.toString();
  }

  void saveArtworkLoadReport() {
    try {
      Path file = app.openingArtworkService.artworkReportPath();
      Files.createDirectories(file.getParent());
      Files.writeString(
          file, app.openingArtworkService.getArtworkLoadReport(), StandardCharsets.UTF_8);
    } catch (IOException | SecurityException ex) {
      System.err.println("Could not save image-loading report: " + ex.getMessage());
    }
  }

  void showArtworkLoadReport() {
    JDialog dialog = new JDialog(app, "Image loading report", false);
    JTextArea text = new JTextArea(app.openingArtworkService.getArtworkLoadReport());
    text.setEditable(false);
    text.setFont(new Font("Monospaced", Font.PLAIN, 12));
    text.setLineWrap(true);
    text.setWrapStyleWord(true);
    text.setCaretPosition(0);
    dialog.add(new JScrollPane(text), BorderLayout.CENTER);
    JLabel location = new JLabel("Saved report: " + app.openingArtworkService.artworkReportPath());
    location.setBorder(BorderFactory.createEmptyBorder(8, 10, 8, 10));
    dialog.add(location, BorderLayout.SOUTH);
    dialog.setSize(760, 560);
    dialog.setLocationRelativeTo(app);
    dialog.setVisible(true);
  }

  void warmAllContainerArtwork() {
    Map<String, Image> byUrl = new HashMap<>();
    CaseType[] sources = CaseType.values();
    int checked = 0;
    for (CaseType source : sources) {
      String key = "case-selector-" + source.id;
      app.startupScreen.setStartupProgress(
          88 + (int) Math.round(2.0 * checked / Math.max(1, sources.length)),
          "Retaining container PNGs (" + checked + " / " + sources.length + "): " + source.name);
      Image image = app.containerArtwork.get(key);
      String url = source.imageUrl;
      if (image == null && url != null) {
        image = byUrl.get(url);
        if (image == null) {
          String resolved = app.startupResolvedArtworkUrls.getOrDefault(url, url);
          if (app.imageRepository.isCachedOnDisk(resolved)) {
            try {
              image = app.imageRepository.readRemoteCachedImage(resolved);
            } catch (IOException ignored) {
            }
          }
        }
      }
      if (image != null) {
        app.imageRepository.put(key, image);
        byUrl.put(url, app.containerArtwork.get(key));
        app.startupArtworkUnavailableDetails.remove(key);
      } else
        app.startupArtworkUnavailableDetails.put(key, "Container PNG unavailable from: " + url);
      checked++;
    }
    app.startupScreen.setStartupProgress(
        90, "Container PNGs retained: " + app.containerArtwork.size() + " / " + sources.length);
  }

  void loadOpeningArtwork(Map<String, Image> pinned, String key, String primary, String fallback) {
    if (primary == null) primary = fallback;
    if (primary == null) return;
    Image cached = app.imageRepository.get(key);
    if (cached != null) {
      pinned.put(key, cached);
      return;
    }
    for (String url : new String[] {primary, fallback}) {
      if (url == null) continue;
      url = app.startupResolvedArtworkUrls.getOrDefault(url, url);
      Long retry = app.unavailableRemoteImageUrls.get(url);
      if (retry != null && retry > System.currentTimeMillis()) continue;
      try {
        BufferedImage image = app.imageRepository.readRemoteCachedImage(url);
        if (image != null) {
          pinned.put(key, image);
          app.imageRepository.put(key, image);
          return;
        }
      } catch (IOException ex) {
        app.unavailableRemoteImageUrls.put(url, System.currentTimeMillis() + 300000L);
      }
    }
  }

  void prepareOpeningArtwork(CaseType source) {
    if (source == null) return;
    Map<String, Image> pinned = new HashMap<>();
    app.openingArtworkService.loadOpeningArtwork(
        pinned, "case-selector-" + source.id, source.imageUrl, null);
    Set<String> names = new java.util.LinkedHashSet<>(source.rareDropNames);
    for (List<String> tier : source.regularDropNames.values()) names.addAll(tier);
    int warmed = 0;
    for (String skin : names) {
      if (app.startupWorkStarted && !app.marketInitialized)
        app.startupScreen.setStartupProgress(
            90 + (int) Math.round(3.0 * warmed / Math.max(1, names.size())),
            "Preparing opening artwork (" + warmed + " / " + names.size() + "): " + skin);
      String name = app.artworkService.canonicalArtworkName(skin);
      SkinMetadata metadata = app.artworkService.getArtworkMetadata(name);
      String standard = metadata == null ? null : metadata.imageUrl;
      app.openingArtworkService.loadOpeningArtwork(pinned, name, standard, null);
      for (String wear : app.floatRules.getAvailableConditions(name))
        app.openingArtworkService.loadOpeningArtwork(
            pinned,
            app.artworkService.getSkinArtworkKey(name, wear),
            app.artworkService.getWearImageUrl(name, wear),
            standard);
      warmed++;
    }
    if (app.startupWorkStarted && !app.marketInitialized)
      app.startupScreen.setStartupProgress(93, "Opening artwork ready: " + source.name);
    app.openingArtwork = java.util.Collections.unmodifiableMap(pinned);
    app.openingArtworkCaseId = source.id;
  }
}
