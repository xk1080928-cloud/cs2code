package blahblah;

import java.util.*;

/** Site references with five-second skin movement and explicit float-aware valuations. */
final class MarketplacePricing {
  private final hGui app;
  private static final Set<String> AUTOMATIC =
      Collections.unmodifiableSet(
          new HashSet<>(
              Arrays.asList(
                  "CS.MONEY",
                  "DMarket",
                  "Skins.com",
                  "Skin.Land",
                  "VaultDrop",
                  "NeonGrid",
                  "EmberSkins",
                  "RelayMarket")));

  MarketplacePricing(hGui app) {
    this.app = app;
  }

  static boolean automatic(String site) {
    return AUTOMATIC.contains(site);
  }

  static String variant(InventoryItem i) {
    return i.name + "\u001f" + i.condition + "\u001f" + i.isStattrak;
  }

  double quote(MarketplaceProfile site, InventoryItem item) {
    Double container = ContainerMarketService.quote(item.name);
    if (container != null) return container;
    double reference = Double.NaN, bestAsk=Double.POSITIVE_INFINITY;
    for (MarketListing lot : app.exchangeSiteStock.getOrDefault(site.name, Collections.emptyList()))
      if (!lot.isPlayerListing && lot.quantity > 0 && variant(lot.item).equals(variant(item))) {
        double ask=app.marketplaceUnitStock.floorAsk(lot);
        if(ask<bestAsk){bestAsk=ask;reference=lot.getPrice();}
      }
    if (!Double.isFinite(reference)) return item.price.doubleValue();
    return MarketDynamics.cents(reference * MarketDynamics.floatPremium(item.condition, item.itemFloat,
        app.marketStockService.getMarketWearBounds(item.name)[0], app.marketStockService.getMarketWearBounds(item.name)[1]));
  }

  double lowest(MarketplaceProfile site, InventoryItem item) {
    double low = Double.POSITIVE_INFINITY;
    for (MarketListing lot : app.exchangeSiteStock.getOrDefault(site.name, Collections.emptyList()))
      if (lot.quantity > 0 && variant(lot.item).equals(variant(item)))
        low = Math.min(low, app.marketplaceUnitStock.floorAsk(lot));
    return low;
  }

  double suggested(MarketplaceProfile site, InventoryItem item) {
    if (automatic(site.name)) return quote(site, item);
    double low = lowest(site, item);
    return Double.isFinite(low)
        ? Math.max(.01, Math.round((low - .01) * 100) / 100.0)
        : item.price.doubleValue();
  }

  double quickSellQuote(MarketplaceProfile site, InventoryItem item) {
    double reference = automatic(site.name) ? quote(site, item) : item.price.doubleValue();
    if (!Double.isFinite(reference) || reference <= 0) return Double.NaN;
    return app.coreUtilities
        .money(reference * (1 - app.exchangeTransactionService.exchangeQuickSellLoss(site)))
        .doubleValue();
  }

  String label(MarketplaceProfile site) {
    return automatic(site.name)
        ? "Automatic valuation • float premium / moving reference"
        : "Custom asks • set your price or undercut the lowest";
  }
}
