package blahblah;

import blahblah.hGui.*;
import java.awt.*;
import java.awt.event.*;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Comparator;
import java.util.Iterator;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.prefs.Preferences;
import javax.swing.*;

/** Item Price Service: focused feature implementation. */
final class ItemPriceService {
  private final hGui app;

  ItemPriceService(hGui app) {
    this.app = app;
  }

  String findBlueGemTier(Map<String, List<Integer>> patterns, int patternID) {
    for (String tier : new String[] {"T1", "T2", "T3", "T4"}) {
      List<Integer> ids = patterns.get(tier);
      if (ids != null && ids.contains(patternID)) {
        return "Blue Gem " + tier;
      }
    }
    return null;
  }

  String getBlueGemTier(String skinName, int patternID) {
    if (patternID < 0 || patternID > 1000) return null;
    if (!skinName.contains("Case Hardened")) return null;

    if (skinName.contains("Flip Knife")) {
      return app.itemPriceService.findBlueGemTier(hGui.FLIP_KNIFE_BG, patternID);
    }

    if (skinName.contains("M9 Bayonet")) {
      return app.itemPriceService.findBlueGemTier(hGui.M9_BG, patternID);
    }

    if (skinName.contains("AK-47")) {
      return app.itemPriceService.findBlueGemTier(hGui.AK_BG, patternID);
    }

    if (skinName.contains("Butterfly Knife")) {
      return app.itemPriceService.findBlueGemTier(hGui.BUTTERFLY_BG, patternID);
    }

    if (skinName.contains("Kukri Knife")) {
      return app.itemPriceService.findBlueGemTier(hGui.KUKRI_BG, patternID);
    }

    return null;
  }

  boolean isBlueGem(InventoryItem item) {
    return item.blueGemTier != null && item.blueGemTier.contains("Blue Gem");
  }

  public void openCrate() {
    if (!app.isAnimating) app.caseOpeningScreen.openCrateWithAnimation();
  }

  void trackOpeningStreak() {
    double caseProfit = app.finalPrice - app.currentOpeningCost;

    if (caseProfit > 0) {
      app.profitStreakCount++;
      app.lossStreakCount = 0;
    } else {
      app.lossStreakCount++;
      app.profitStreakCount = 0;
    }

    if (app.profitStreakCount >= 10 && !app.achievements.get("profit_streak").isUnlocked) {
      app.achievementScreen.unlockAchievement("profit_streak");
    }
    if (app.profitStreakCount >= 20 && !app.achievements.get("profit_streak_20").isUnlocked) {
      app.achievementScreen.unlockAchievement("profit_streak_20");
    }

    if (app.lossStreakCount >= 10 && !app.achievements.get("loss_streak").isUnlocked) {
      app.achievementScreen.unlockAchievement("loss_streak");
    }
    if (app.lossStreakCount >= 25 && !app.achievements.get("loss_streak_25").isUnlocked) {
      app.achievementScreen.unlockAchievement("loss_streak_25");
    }
  }

  double capPriceToMarket(
      String skinName,
      String condition,
      boolean isStattrak,
      double calculatedPrice,
      String blueGemTier) {

    String marketKey = isStattrak ? "StatTrak " + skinName : skinName;
    ArrayList<MarketListing> listings = app.globalMarketListings.get(marketKey);

    if (listings == null || listings.isEmpty()) {
      return calculatedPrice;
    }

    ArrayList<MarketListing> sameCondition = new ArrayList<>();
    ArrayList<MarketListing> snapshot;
    synchronized (app.globalMarketListings) {
      snapshot = new ArrayList<>(listings);
    }
    for (MarketListing listing : snapshot) {
      if (listing.item.condition.equals(condition)) {
        sameCondition.add(listing);
      }
    }

    if (sameCondition.isEmpty()) {
      return calculatedPrice;
    }

    sameCondition.sort(Comparator.comparingDouble(l -> l.getPrice()));
    double lowestMarketPrice = sameCondition.get(0).getPrice();

    return lowestMarketPrice;
  }

  double applyBlueGemMultiplier(String skinName, int patternID, String blueGemTier, double price) {
    if (blueGemTier == null) {
      return price;
    }

    if (blueGemTier.contains("T1")) {

      if (skinName.equals("AK-47 | Case Hardened") && (patternID == 661 || patternID == 670)) {
        return price * 350;
      }

      if (skinName.equals("Flip Knife | Case Hardened") && patternID == 670) {
        return price * 45;
      }

      if (skinName.equals("M9 Bayonet | Case Hardened")
          && (patternID == 601 || patternID == 58 || patternID == 150)) {
        return price * 85;
      }

      return price * 50;

    } else if (blueGemTier.contains("T2")) {
      return price * 10;
    } else if (blueGemTier.contains("T3")) {
      return price * 3;
    } else if (blueGemTier.contains("T4")) {
      return price * 1.5;
    }

    return price;
  }

  double getBasePrice(String skinName) {
    Double livePrice = app.liveBasePrices.get(skinName);
    if (livePrice != null && !(app.floatRules.hasNoFloatWear(skinName) && livePrice <= 5.00))
      return livePrice;
    if (livePrice != null) app.liveBasePrices.remove(skinName, livePrice);
    Double persistedPrice = app.itemPriceService.loadCachedMarketBasePrice(skinName);
    // A prior build cached the generic $5 fallback for unconditioned items.
    // Do not treat that placeholder as a real Normal-variant market quote.
    if (persistedPrice != null
        && app.floatRules.hasNoFloatWear(skinName)
        && persistedPrice <= 5.00) {
      persistedPrice = null;
    }
    if (persistedPrice != null) {
      app.liveBasePrices.put(skinName, persistedPrice);
      synchronized (app.basePriceCache) {
        app.basePriceCache.put(skinName, persistedPrice);
      }
      long cachedAt =
          app.marketPricePreferences.getLong(
              app.itemPriceService.marketPricePreferenceKey("t", skinName), 0L);
      if (System.currentTimeMillis() - cachedAt >= hGui.MARKET_PRICE_CACHE_TTL_MS
          || !app.liveConditionPriceMultipliers.containsKey(skinName)) {
        app.itemPriceService.scheduleMarketPriceLookup(skinName, persistedPrice);
      }
      return persistedPrice;
    }
    Double bpCached;
    synchronized (app.basePriceCache) {
      bpCached = app.basePriceCache.get(skinName);
    }
    if (bpCached != null && app.floatRules.hasNoFloatWear(skinName) && bpCached <= 5.00) {
      synchronized (app.basePriceCache) {
        app.basePriceCache.remove(skinName);
      }
      bpCached = null;
    }
    if (bpCached != null) {
      app.itemPriceService.scheduleMarketPriceLookup(skinName, bpCached);
      return bpCached;
    }
    double bpResult = app.priceTables.getBasePriceInner(skinName);
    synchronized (app.basePriceCache) {
      Double racedPrice = app.basePriceCache.get(skinName);
      if (racedPrice != null) return racedPrice;
      app.basePriceCache.put(skinName, bpResult);
    }
    app.itemPriceService.scheduleMarketPriceLookup(skinName, bpResult);
    return bpResult;
  }

  Double loadCachedMarketBasePrice(String skinName) {
    if (skinName == null
        || app.itemPriceService.marketPricePreferenceKey("p", skinName).length()
            > Preferences.MAX_KEY_LENGTH) return null;
    double cachedPrice =
        app.marketPricePreferences.getDouble(
            app.itemPriceService.marketPricePreferenceKey("p", skinName), 0.0);
    return cachedPrice > 0.0 && Double.isFinite(cachedPrice) ? cachedPrice : null;
  }

  boolean isStartupQuoteOnly() {
    if (!app.startupWorkStarted
        || app.marketInitialized
        || !app.globalMarketListings.isEmpty()
        || !app.activeListings.isEmpty()) return false;
    // Stock equipment is not a real pre-existing owned inventory requiring repricing.
    for (InventoryItem item : app.inventoryList)
      if (!app.cs2EquipmentScreens.isDefaultWeaponItem(item)) return false;
    return true;
  }

  void scheduleMarketPriceLookup(String skinName, double fallbackBasePrice) {
    if (skinName == null
        || skinName.trim().isEmpty()
        || skinName.startsWith("StatTrak ")
        || skinName.contains("(Blue Gem")
        || !app.marketPriceLookups.add(skinName)) {
      return;
    }
    app.fallbackBasePrices.put(skinName, fallbackBasePrice);
    app.pendingMarketPriceLookups.add(skinName);
    try {
      app.marketPriceExecutor.execute(
          () -> {
            boolean handedToEdt = false;
            try {
              MarketPriceData quote = app.itemPriceService.fetchPublicFeedBasePrice(skinName);
              if (quote != null && quote.basePrice > 0.0) {
                if (app.itemPriceService.isStartupQuoteOnly()) {
                  app.publicPriceFeeds.updateBasePriceFromMarket(skinName, quote);
                  return;
                }
                SwingUtilities.invokeLater(
                    () -> {
                      try {
                        app.publicPriceFeeds.updateBasePriceFromMarket(skinName, quote);
                      } finally {
                        app.pendingMarketPriceLookups.remove(skinName);
                      }
                    });
                handedToEdt = true;
              }
            } catch (IOException ex) {
              app.marketPriceLookups.remove(skinName);
              if (!app.startupWorkStarted || app.marketInitialized)
                System.err.println(
                    "Public price feed lookup failed for " + skinName + ": " + ex.getMessage());
            } finally {
              if (!handedToEdt) app.pendingMarketPriceLookups.remove(skinName);
            }
          });
    } catch (java.util.concurrent.RejectedExecutionException ex) {
      app.pendingMarketPriceLookups.remove(skinName);
      app.marketPriceLookups.remove(skinName);
    }
  }

  String getPublicFeedSkinName(String name, String dopplerVariant) {
    String result = name.replaceFirst("^★\\s*", "").trim();
    if (app.floatRules.isVanillaKnife(result))
      return result.replaceFirst("(?i)\\s*\\|\\s*Vanilla$", "").trim();
    return dopplerVariant == null ? result : result.substring(0, result.lastIndexOf(" (")).trim();
  }

  String marketPricePreferenceKey(String kind, String name) {
    // Ignore prices cached under the old, invalid '| Vanilla' feed lookup.
    return kind
        + (app.floatRules.isVanillaKnife(name)
            ? ".vanilla-v2."
            : name.equals("Karambit | Doppler (Ruby)") ? ".ruby-wear-v3." : ".")
        + name;
  }

  MarketPriceData fetchPublicFeedBasePrice(String skinName) throws IOException {
    String[] availableConditions = app.floatRules.getAvailableConditions(skinName);
    if (availableConditions.length == 0) return null;

    boolean unconditioned = app.floatRules.hasNoFloatWear(skinName);
    String dopplerVariant = app.publicPriceFeeds.getDopplerVariant(skinName);
    String marketSkinName = app.itemPriceService.getPublicFeedSkinName(skinName, dopplerVariant);
    String itemRarity = app.itemMetadataService.getSkinRarity(skinName);
    IOException feedFailures = null;
    Map<String, Double> conditionPrices = new LinkedHashMap<>();
    for (String marketCondition : availableConditions) {
      String marketHashName =
          unconditioned ? marketSkinName : marketSkinName + " (" + marketCondition + ")";
      if ("Knife".equals(itemRarity) || "Gloves".equals(itemRarity)) {
        marketHashName = "★ " + marketHashName;
      }
      for (String provider : new String[] {"csfloat"}) {
        try {
          String response = app.publicPriceFeeds.getPublicPriceSnapshot(provider);
          Double listingPrice =
              app.publicPriceFeeds.findCsfloatSnapshotPrice(
                  response, marketHashName, dopplerVariant);
          if (listingPrice == null && marketHashName.startsWith("★ ")) {
            listingPrice =
                app.publicPriceFeeds.findCsfloatSnapshotPrice(
                    response, marketHashName.substring(2), dopplerVariant);
          }
          if (listingPrice != null) {
            conditionPrices.put(marketCondition, listingPrice);
            System.out.printf(
                "Using %s feed price $%.2f for %s (%s).%n",
                provider, listingPrice, skinName, marketCondition);
            break;
          }
        } catch (IOException e) {
          if (feedFailures == null) feedFailures = e;
          else feedFailures.addSuppressed(e);
        }
      }
    }
    if (conditionPrices.isEmpty() && feedFailures != null) throw feedFailures;
    if (conditionPrices.isEmpty()) {
      System.err.println(
          "Public price sources have no price for "
              + skinName
              + " in any available wear condition"
              + "; using the existing base price.");
      return null;
    }
    app.itemPriceService.rejectIlliquidGemWearQuote(skinName, conditionPrices);
    app.itemPriceService.discardImplausibleWearQuotes(skinName, conditionPrices);
    if (conditionPrices.isEmpty()) return null;
    String referenceCondition =
        conditionPrices.containsKey("Field-Tested")
            ? "Field-Tested"
            : conditionPrices.keySet().iterator().next();
    double referencePrice = conditionPrices.get(referenceCondition);
    double fallbackMultiplier =
        unconditioned
            ? 1.0
            : app.priceModifiers.getConditionPriceMultiplier(skinName, referenceCondition);
    if (!Double.isFinite(fallbackMultiplier) || fallbackMultiplier <= 0.0) return null;
    // Vanilla knives and agents trade as one Normal variant. Their public
    // price is already the base price; never derive it from a wear multiplier.
    double basePrice = unconditioned ? referencePrice : referencePrice / fallbackMultiplier;
    Map<String, Double> conditionMultipliers = new LinkedHashMap<>();
    for (Map.Entry<String, Double> entry : conditionPrices.entrySet()) {
      double multiplier = unconditioned ? 1.0 : entry.getValue() / basePrice;
      if (Double.isFinite(multiplier) && multiplier > 0.0) {
        conditionMultipliers.put(entry.getKey(), multiplier);
      }
    }
    Double vanillaStatTrakPrice = null;
    if (app.floatRules.isVanillaKnife(skinName)) {
      String snapshot = app.publicPriceFeeds.getPublicPriceSnapshot("csfloat");
      vanillaStatTrakPrice =
          app.publicPriceFeeds.findCsfloatSnapshotPrice(
              snapshot, "★ StatTrak™ " + marketSkinName, null);
    }
    return new MarketPriceData(basePrice, conditionMultipliers, vanillaStatTrakPrice);
  }

  void rejectIlliquidGemWearQuote(String name, Map<String, Double> quotes) {
    if (!"Karambit | Doppler (Ruby)".equals(name)) return;
    Double fn = quotes.get("Factory New"), mw = quotes.get("Minimal Wear");
    if (fn != null && mw != null && fn > 0 && mw > fn * 2.0) {
      // A lone asking price is not fair value. Model MW at an explicit 15% wear discount
      // to the same Ruby/FN cash reference, rather than capping every knife to a dollar limit.
      double estimate = Math.round(fn * .85 * 100.0) / 100.0;
      System.err.printf(
          "Rejected illiquid Ruby MW ask $%.2f; MODELED MW $%.2f from same-variant FN $%.2f (15%%"
              + " wear discount; not a live MW quote).%n",
          mw, estimate, fn);
      quotes.put("Minimal Wear", estimate);
    }
  }

  void discardImplausibleWearQuotes(String skinName, Map<String, Double> conditionPrices) {
    Double fieldTestedPrice = conditionPrices.get("Field-Tested");
    if (fieldTestedPrice == null || !Double.isFinite(fieldTestedPrice) || fieldTestedPrice <= 0.0)
      return;

    for (Iterator<Map.Entry<String, Double>> it = conditionPrices.entrySet().iterator();
        it.hasNext(); ) {
      Map.Entry<String, Double> entry = it.next();
      String condition = entry.getKey();
      Double quote = entry.getValue();
      if (!"Battle-Scarred".equals(condition) && !"Well-Worn".equals(condition)) continue;
      if (quote == null || !Double.isFinite(quote) || quote <= 0.0) {
        it.remove();
        continue;
      }
      if (quote > fieldTestedPrice * 3.0) {
        System.err.printf(
            "Ignoring implausible %s quote $%.2f for %s; Field-Tested is $%.2f.%n",
            condition, quote, skinName, fieldTestedPrice);
        it.remove();
      }
    }
  }
}
