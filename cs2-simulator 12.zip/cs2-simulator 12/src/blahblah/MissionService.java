package blahblah;

import blahblah.hGui.*;
import java.awt.*;
import java.awt.event.*;
import java.util.HashSet;
import java.util.Map;
import java.util.Set;
import javax.swing.*;

/** Mission Service: focused feature implementation. */
final class MissionService {
  private final hGui app;

  MissionService(hGui app) {
    this.app = app;
  }

  void generateNewMissions() {
    app.activeMissions.clear();
    java.util.List<Object[]> pool =
        new java.util.ArrayList<>(java.util.Arrays.asList(hGui.ALL_MISSION_TEMPLATES));
    java.util.Collections.shuffle(pool, hGui.random);

    java.util.Set<String> usedTypes = new java.util.HashSet<>();
    int count = 0;
    for (Object[] tpl : pool) {
      if (count >= 4) break;
      String type = (String) tpl[3];
      if (usedTypes.contains(type)) continue;
      usedTypes.add(type);
      String id = (String) tpl[0] + "_" + System.currentTimeMillis();
      app.activeMissions.add(
          new Mission(
              id, (String) tpl[1], (String) tpl[2], (String) tpl[3], (int) tpl[4], (int) tpl[5]));
      count++;
    }
    app.missionProgress = new MissionProgress();
  }

  void checkMissionProgress() {
    if (app.activeMissions.isEmpty()) return;
    for (Mission m : app.activeMissions) {
      if (m.completed) continue;
      switch (m.type) {
        case "CASES":
          m.current = app.missionProgress.casesOpened;
          break;
        case "TRADEUP":
          m.current = app.missionProgress.tradeUps;
          break;
        case "MARKET_SPEND":
          m.current = (int) (app.missionProgress.marketSpent / 100.0);
          break;
        case "MARKET_SELL":
          m.current = app.missionProgress.marketSellCount;
          break;
        case "KNIFE":
          m.current = app.missionProgress.knivesUnboxed;
          break;
        case "GLOVES":
          m.current = app.missionProgress.glovesUnboxed;
          break;
        case "ARMOURY":
          m.current = app.missionProgress.armouryRedeems;
          break;
        case "INVENTORY":
          m.current = app.cs2EquipmentScreens.collectibleInventory().size();
          break;
        case "COVERT":
          m.current = app.missionProgress.covertsUnboxed;
          break;
        case "CLASSIFIED":
          m.current = app.missionProgress.classifiedsUnboxed;
          break;
        case "BALANCE":
          m.current = (int) Math.min(app.balance, m.goal);
          break;
      }
      if (m.current >= m.goal && !m.completed) {
        m.completed = true;
        m.current = m.goal;
        app.missionService.awardStars(m.starReward, m.name);
        app.carePackages.award(m);
      }
    }
  }

  void awardStars(int amount, String source) {
    app.playerStars += amount;
    app.missionService.updateStarsLabel();

    javax.swing.SwingUtilities.invokeLater(
        () -> {
          JPanel notif = new JPanel(new BorderLayout(6, 0));
          notif.setBackground(Theme.BG_PANEL);
          notif.setBorder(
              BorderFactory.createCompoundBorder(
                  BorderFactory.createLineBorder(Theme.GOLD, 2),
                  BorderFactory.createEmptyBorder(8, 12, 8, 12)));
          JLabel icon = new JLabel("*", SwingConstants.CENTER);
          icon.setFont(new Font("Consolas", Font.BOLD, 26));
          icon.setForeground(Theme.GOLD);
          JLabel msg =
              new JLabel(
                  "<html><b>Mission Complete!</b><br>"
                      + source
                      + "<br>+"
                      + amount
                      + " Star"
                      + (amount > 1 ? "s" : "")
                      + " + " + Math.max(10,amount*25) + " XP awarded</html>");
          msg.setFont(new Font("Consolas", Font.PLAIN, 12));
          msg.setForeground(new Color(230, 230, 235));
          notif.add(icon, BorderLayout.WEST);
          notif.add(msg, BorderLayout.CENTER);
          notif.setPreferredSize(new Dimension(280, 70));
          JLayeredPane lp2 = app.getLayeredPane();
          notif.setBounds(lp2.getWidth() - 292, lp2.getHeight() - 82, 280, 70);
          JLayeredPane lp = app.getLayeredPane();
          lp.add(notif, JLayeredPane.POPUP_LAYER);
          lp.revalidate();
          lp.repaint();
          javax.swing.Timer t =
              new javax.swing.Timer(
                  3500,
                  ev -> {
                    lp.remove(notif);
                    lp.revalidate();
                    lp.repaint();
                  });
          t.setRepeats(false);
          t.start();
        });
  }

  void updateStarsLabel() {
    if (app.starsLabel != null)
      app.starsLabel.setText("* " + app.playerStars + " Star" + (app.playerStars == 1 ? "" : "s"));
    if (app.armouryStarsDisp != null)
      app.armouryStarsDisp.setText("* " + app.playerStars + " Stars");
  }

  void updateCaseResultLabels(
      String rarityText, String skinName, double floatValue, String wear, String collectionName) {
    app.priceLabel.setText("Rarity: " + rarityText);
    app.floatLabel.setText(
        app.itemMetadataService.shouldShowFloatForItem(skinName, rarityText)
            ? String.format("Float: %.10f", floatValue)
            : "");
    app.conditionLabel.setText(wear != null && !wear.isEmpty() ? "Wear: " + wear : "");
    app.collectionLabel.setText(
        collectionName != null && !collectionName.isEmpty() ? "Collection: " + collectionName : "");
  }

  void checkMarketAchievements() {
    app.achievements.get("market_sell_100").progress = app.missionProgress.marketSellCount;
    app.achievements.get("market_sell_500").progress = app.missionProgress.marketSellCount;
    app.achievements.get("market_sell_1000").progress = app.missionProgress.marketSellCount;
    app.achievements.get("total_profit_100k").progress =
        (int) Math.min(app.totalMarketProfit, 100000.0);

    if (app.missionProgress.marketSellCount >= 100
        && !app.achievements.get("market_sell_100").isUnlocked) {
      app.achievementScreen.unlockAchievement("market_sell_100");
    }
    if (app.missionProgress.marketSellCount >= 500
        && !app.achievements.get("market_sell_500").isUnlocked) {
      app.achievementScreen.unlockAchievement("market_sell_500");
    }
    if (app.missionProgress.marketSellCount >= 1000
        && !app.achievements.get("market_sell_1000").isUnlocked) {
      app.achievementScreen.unlockAchievement("market_sell_1000");
    }
    if (app.totalMarketProfit >= 100000 && !app.achievements.get("total_profit_100k").isUnlocked) {
      app.achievementScreen.unlockAchievement("total_profit_100k");
    }
  }

  void checkTradeUpAchievements(String outputRarity) {
    app.achievements.get("tradeup_10").progress = app.missionProgress.tradeUps;
    app.achievements.get("tradeup_50").progress = app.missionProgress.tradeUps;
    app.achievements.get("tradeup_100").progress = app.missionProgress.tradeUps;
    app.achievements.get("tradeup_250").progress = app.missionProgress.tradeUps;

    if (app.missionProgress.tradeUps >= 10 && !app.achievements.get("tradeup_10").isUnlocked) {
      app.achievementScreen.unlockAchievement("tradeup_10");
    }
    if (app.missionProgress.tradeUps >= 50 && !app.achievements.get("tradeup_50").isUnlocked) {
      app.achievementScreen.unlockAchievement("tradeup_50");
    }
    if (app.missionProgress.tradeUps >= 100 && !app.achievements.get("tradeup_100").isUnlocked) {
      app.achievementScreen.unlockAchievement("tradeup_100");
    }
    if (app.missionProgress.tradeUps >= 250 && !app.achievements.get("tradeup_250").isUnlocked) {
      app.achievementScreen.unlockAchievement("tradeup_250");
    }
    if ("Covert".equals(outputRarity) && !app.achievements.get("tradeup_knife").isUnlocked) {
      app.achievementScreen.unlockAchievement("tradeup_knife");
    }
  }

  void checkArmouryAchievements() {
    app.achievements.get("armoury_25").progress = app.missionProgress.armouryRedeems;
    app.achievements.get("armoury_50").progress = app.missionProgress.armouryRedeems;

    if (app.missionProgress.armouryRedeems >= 25
        && !app.achievements.get("armoury_25").isUnlocked) {
      app.achievementScreen.unlockAchievement("armoury_25");
    }
    if (app.missionProgress.armouryRedeems >= 50
        && !app.achievements.get("armoury_50").isUnlocked) {
      app.achievementScreen.unlockAchievement("armoury_50");
    }
  }

  void checkInventoryCollectionAchievements() {
    int factoryNewCount = 0;
    int lowFloatCount = 0;
    Set<String> knifeTypes = new HashSet<>();

    for (InventoryItem item : app.inventoryList) {
      if (app.cs2EquipmentScreens.isDefaultWeaponItem(item)) continue;
      if ("Factory New".equals(item.condition)) factoryNewCount++;
      if (item.itemFloat < 0.005) lowFloatCount++;
      if (item.name != null && item.name.contains("Knife")) {
        String cleanName = item.name.replace("StatTrak ", "").trim();
        int sep = cleanName.indexOf(" | ");
        knifeTypes.add(sep > 0 ? cleanName.substring(0, sep).trim() : cleanName);
      }
    }

    app.achievements.get("fn_collection").progress = factoryNewCount;
    app.achievements.get("low_float_5").progress = lowFloatCount;
    app.achievements.get("knife_3types").progress = knifeTypes.size();

    if (factoryNewCount >= 10 && !app.achievements.get("fn_collection").isUnlocked) {
      app.achievementScreen.unlockAchievement("fn_collection");
    }
    if (lowFloatCount >= 5 && !app.achievements.get("low_float_5").isUnlocked) {
      app.achievementScreen.unlockAchievement("low_float_5");
    }
    if (knifeTypes.size() >= 3 && !app.achievements.get("knife_3types").isUnlocked) {
      app.achievementScreen.unlockAchievement("knife_3types");
    }
    if (app.inventoryValue >= 5000000 && !app.achievements.get("inventory_5m").isUnlocked) {
      app.achievementScreen.unlockAchievement("inventory_5m");
    }
  }

  boolean isLoadoutSideFull(Map<String, InventoryItem> loadout, boolean isTSide) {
    for (InventoryItem item : loadout.values())
      if (app.cs2EquipmentScreens.isDefaultWeaponItem(item)) return false;
    String[] pistols = isTSide ? hGui.T_SLOTS_PISTOL : hGui.CT_SLOTS_PISTOL;
    String[] sidearms = isTSide ? hGui.T_SLOTS_OTHER : hGui.CT_SLOTS_OTHER;
    String[] smgs = isTSide ? hGui.T_SLOTS_SMG : hGui.CT_SLOTS_SMG;
    String[] rifles = isTSide ? hGui.T_SLOTS_RIFLE : hGui.CT_SLOTS_RIFLE;
    String[] heavies = isTSide ? hGui.T_SLOTS_HEAVY : hGui.CT_SLOTS_HEAVY;
    String knifeKey = isTSide ? "Knife_T" : "Knife_CT";
    String glovesKey = isTSide ? "Gloves_T" : "Gloves_CT";
    String agentKey = isTSide ? hGui.AGENT_SLOT_T : hGui.AGENT_SLOT_CT;

    if (loadout.get(agentKey) == null
        || loadout.get(knifeKey) == null
        || loadout.get(glovesKey) == null) {
      return false;
    }
    for (String slot : pistols) if (loadout.get(slot) == null) return false;
    for (String slot : sidearms) if (loadout.get(slot) == null) return false;
    for (String slot : smgs) if (loadout.get(slot) == null) return false;
    for (String slot : rifles) if (loadout.get(slot) == null) return false;
    for (String slot : heavies) if (loadout.get(slot) == null) return false;
    return true;
  }

  void checkLoadoutAchievements() {
    if (app.missionService.isLoadoutSideFull(app.tLoadout, true)
        && !app.achievements.get("loadout_full_t").isUnlocked) {
      app.achievementScreen.unlockAchievement("loadout_full_t");
    }
    if (app.missionService.isLoadoutSideFull(app.ctLoadout, false)
        && !app.achievements.get("loadout_full_ct").isUnlocked) {
      app.achievementScreen.unlockAchievement("loadout_full_ct");
    }
  }
}
