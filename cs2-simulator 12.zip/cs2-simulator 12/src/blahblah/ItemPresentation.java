package blahblah;

import java.awt.*;
import javax.swing.*;

/** Display-only identity: never changes saved names, quote keys, ownership or collection rules. */
final class ItemPresentation {
  static String name(hGui app, InventoryItem item) {
    String name = item.name == null ? "" : item.name.trim();
    boolean star =
        name.startsWith("★")
            || (item.rarity != null
                && (item.rarity.contains("Knife") || item.rarity.contains("Glove")));
    boolean st = item.isStattrak || name.matches("^(?:★\\s*)?StatTrak(?:™)?\\s+.*");
    name =
        name.replaceFirst("^★\\s*", "")
            .replaceFirst("^StatTrak(?:™)?\\s*", "")
            .replaceFirst("^★\\s*", "")
            .trim();
    if (app.cs2EquipmentScreens.isDefaultWeaponItem(item)) return item.name;
    return (star ? "★ " : "") + (st ? "StatTrak™ " : "") + name;
  }

  static String collection(hGui app, InventoryItem item) {
    CaseType container = app.exchangeStockService.exchangeContainer(item.name);
    if (container == null)
      for (CaseType ct : CaseType.values())
        if (item.name.equals(ct.name) || item.name.equals(ct.catalogCrateName())) {
          container = ct;
          break;
        }
    if (container != null) {
      java.util.Map<String, Integer> votes = new java.util.TreeMap<>();
      for (java.util.List<String> pool : container.regularDropNames.values())
        for (String skin : pool) {
          SkinMetadata m =
              app.artworkService.getArtworkMetadata(app.artworkService.canonicalArtworkName(skin));
          if (m != null && m.collectionName != null && !m.collectionName.isEmpty())
            votes.merge(m.collectionName, 1, Integer::sum);
        }
      if (!votes.isEmpty())
        return java.util.Collections.max(votes.entrySet(), java.util.Map.Entry.comparingByValue())
            .getKey();
      String fallback = app.collectionService.getCatalogCollectionName(container);
      if (CollectionEmblems.icon(fallback) != null) return fallback;
      if (CollectionEmblems.icon("The " + fallback) != null) return "The " + fallback;
      return fallback == null ? "" : fallback;
    }
    if (app.inventoryScreen.hasNoItemCollection(item.rarity)) return "";
    SkinMetadata m =
        app.artworkService.getArtworkMetadata(app.artworkService.canonicalArtworkName(item.name));
    if (m != null && m.collectionName != null && !m.collectionName.isEmpty())
      return m.collectionName;
    String value = app.inventoryScreen.resolveInventoryItemCollection(item);
    return value == null || value.equals("None") ? "" : value;
  }

  static JPanel identity(hGui app, InventoryItem item, int size, String prefix, boolean centered) {
    JPanel group = app.cs2Screens.cs2Glass(new BorderLayout(14, 0));
    group.setName(prefix + "Identity");
    String collection = collection(app, item);
    ImageIcon emblem = CollectionEmblems.icon(collection);
    if (emblem == null) emblem = ArmouryCollectionIcons.icon(collection);
    if (emblem != null) {
      JLabel icon =
          new JLabel(new ImageIcon(app.cs2Screens.scaleCs2Image(emblem.getImage(), 64, 64)));
      icon.setName(prefix + "CollectionIcon");
      icon.setToolTipText(collection);
      icon.setPreferredSize(new Dimension(68, 68));
      group.add(icon, BorderLayout.WEST);
    }
    JPanel words = app.cs2Screens.cs2Glass(new GridLayout(0, 1, 0, 5));
    JLabel name =
        app.cs2Screens.cs2Text(
            prefix.equals("tradeUpResult")
                ? app.inventoryToolsService.displayName(item)
                : prefix.startsWith("inspect")
                    ? app.cs2EquipmentScreens.inspectionName(item)
                    : ItemPresentation.name(app, item),
            size,
            Color.WHITE);
    name.setName(prefix + "Name");
    name.setFont(app.cs2Screens.cs2Font(Font.BOLD, size));
    if (prefix.startsWith("inspect") || prefix.startsWith("unbox")) {
      name.setBorder(
          BorderFactory.createMatteBorder(0, 0, 4, 0, app.cs2EquipmentScreens.itemColor(item)));
      name.putClientProperty("rarityLine", app.cs2EquipmentScreens.itemColor(item));
    }
    words.add(name);
    JLabel subtitle =
        app.cs2Screens.cs2Text(
            collection, Math.min(15, Math.max(12, size - 7)), new Color(207, 214, 220));
    subtitle.setName(prefix + "CollectionName");
    words.add(subtitle);
    group.add(words);
    if (!centered) return group;
    JPanel wrapper = app.cs2Screens.cs2Glass(new FlowLayout(FlowLayout.CENTER, 0, 0));
    wrapper.add(group);
    return wrapper;
  }
}
