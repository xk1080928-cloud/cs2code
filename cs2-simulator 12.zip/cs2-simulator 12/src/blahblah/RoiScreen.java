package blahblah;

import blahblah.hGui.*;
import java.awt.*;
import java.awt.event.*;
import javax.swing.*;

/** Roi Screen: focused feature implementation. */
final class RoiScreen {
  private final hGui app;

  RoiScreen(hGui app) {
    this.app = app;
  }

  void showROIWindow() {
    JFrame roiFrame = new JFrame("Case Type ROI Statistics");
    roiFrame.setSize(900, 800);
    roiFrame.setLocationRelativeTo(app);
    roiFrame.setLayout(new BorderLayout());

    roiFrame.setAlwaysOnTop(true);

    JPanel headerPanel = new JPanel();
    headerPanel.setBackground(new Color(30, 30, 35));
    headerPanel.setBorder(BorderFactory.createEmptyBorder(20, 20, 20, 20));

    JLabel titleLabel = new JLabel("Case Type ROI Analysis", SwingConstants.CENTER);
    titleLabel.setFont(new Font("Arial", Font.BOLD, 28));
    titleLabel.setForeground(Color.WHITE);
    headerPanel.add(titleLabel);

    roiFrame.add(headerPanel, BorderLayout.NORTH);

    JPanel statsContainer = new JPanel();
    statsContainer.setLayout(new BoxLayout(statsContainer, BoxLayout.Y_AXIS));
    statsContainer.setBackground(new Color(35, 35, 40));
    statsContainer.setBorder(BorderFactory.createEmptyBorder(30, 40, 30, 40));

    for (CaseType caseType : CaseType.values()) {
      JPanel casePanel = app.roiScreen.createCaseROIPanel(caseType);
      statsContainer.add(casePanel);
      statsContainer.add(Box.createRigidArea(new Dimension(0, 25)));
    }

    JScrollPane scrollPane = new JScrollPane(statsContainer);
    scrollPane.getVerticalScrollBar().setUnitIncrement(16);
    scrollPane.setBorder(null);
    scrollPane.getViewport().setBackground(new Color(35, 35, 40));

    roiFrame.add(scrollPane, BorderLayout.CENTER);

    JPanel footerPanel = new JPanel(new FlowLayout(FlowLayout.CENTER));
    footerPanel.setBackground(new Color(30, 30, 35));
    footerPanel.setBorder(BorderFactory.createEmptyBorder(15, 15, 15, 15));

    JLabel infoLabel = new JLabel("ROI = (Total Received - Total Spent) / Total Spent × 100%");
    infoLabel.setFont(new Font("Arial", Font.ITALIC, 14));
    infoLabel.setForeground(Color.LIGHT_GRAY);
    footerPanel.add(infoLabel);

    roiFrame.add(footerPanel, BorderLayout.SOUTH);

    roiFrame.setVisible(true);

    javax.swing.Timer timer =
        new javax.swing.Timer(
            100,
            e -> {
              roiFrame.setAlwaysOnTop(false);
              roiFrame.toFront();
              roiFrame.requestFocus();
            });
    timer.setRepeats(false);
    timer.start();
  }

  JPanel createCaseROIPanel(CaseType caseType) {
    JPanel panel = new JPanel();
    panel.setLayout(new BoxLayout(panel, BoxLayout.Y_AXIS));
    panel.setBackground(new Color(50, 50, 55));
    panel.setBorder(
        BorderFactory.createCompoundBorder(
            BorderFactory.createLineBorder(Color.GRAY, 2),
            BorderFactory.createEmptyBorder(20, 20, 20, 20)));
    panel.setPreferredSize(new Dimension(700, 280));
    panel.setMaximumSize(new Dimension(800, 280));

    JPanel headerPanel = new JPanel(new FlowLayout(FlowLayout.LEFT));
    headerPanel.setBackground(new Color(50, 50, 55));
    headerPanel.setMaximumSize(new Dimension(Integer.MAX_VALUE, 40));

    JLabel nameLabel = new JLabel(caseType.name + " - $" + String.format("%.2f", caseType.price));
    nameLabel.setFont(new Font("Arial", Font.BOLD, 20));
    nameLabel.setForeground(Color.YELLOW);
    headerPanel.add(nameLabel);

    panel.add(headerPanel);
    panel.add(Box.createRigidArea(new Dimension(0, 10)));

    JPanel statsPanel = new JPanel();
    statsPanel.setLayout(new BoxLayout(statsPanel, BoxLayout.Y_AXIS));
    statsPanel.setBackground(new Color(50, 50, 55));

    app.roiScreen.addROIStatRow(statsPanel, "Times Opened:", String.valueOf(caseType.timesOpened));
    app.roiScreen.addROIStatRow(
        statsPanel, "Total Spent:", "$" + String.format("%,.2f", caseType.totalSpent));
    app.roiScreen.addROIStatRow(
        statsPanel, "Total Received:", "$" + String.format("%,.2f", caseType.totalReceived));

    double roi = caseType.getROI();
    Color roiColor = roi >= 0 ? new Color(50, 200, 50) : Color.RED;
    String roiSign = roi >= 0 ? "+" : "";
    app.roiScreen.addROIStatRow(
        statsPanel, "ROI:", roiSign + String.format("%.2f%%", roi), roiColor);

    double avgProfit = caseType.getAverageProfit();
    Color profitColor = avgProfit >= 0 ? new Color(50, 200, 50) : Color.RED;
    String profitSign = avgProfit >= 0 ? "+" : "";
    app.roiScreen.addROIStatRow(
        statsPanel,
        "Avg Profit/Case:",
        profitSign + "$" + String.format("%.2f", avgProfit),
        profitColor);

    panel.add(statsPanel);

    return panel;
  }

  void addROIStatRow(JPanel panel, String label, String value) {
    app.roiScreen.addROIStatRow(panel, label, value, Color.WHITE);
  }

  void addROIStatRow(JPanel panel, String label, String value, Color valueColor) {
    JPanel rowPanel = new JPanel(new BorderLayout());
    rowPanel.setBackground(new Color(50, 50, 55));
    rowPanel.setPreferredSize(new Dimension(650, 40));
    rowPanel.setBorder(BorderFactory.createEmptyBorder(5, 10, 5, 10));

    JLabel labelComp = new JLabel(label);
    labelComp.setFont(new Font("Arial", Font.BOLD, 16));
    labelComp.setForeground(Color.LIGHT_GRAY);

    JLabel valueComp = new JLabel(value);
    valueComp.setFont(new Font("Arial", Font.BOLD, 16));
    valueComp.setForeground(valueColor);
    valueComp.setHorizontalAlignment(SwingConstants.RIGHT);

    rowPanel.add(labelComp, BorderLayout.WEST);
    rowPanel.add(valueComp, BorderLayout.EAST);

    panel.add(rowPanel);
  }
}
