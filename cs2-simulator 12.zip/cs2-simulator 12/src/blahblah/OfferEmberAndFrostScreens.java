package blahblah;

import blahblah.hGui.*;
import java.awt.*;
import java.awt.event.*;
import java.util.ArrayList;
import javax.swing.*;

/** Offer Ember And Frost Screens: focused feature implementation. */
final class OfferEmberAndFrostScreens {
  private final hGui app;

  OfferEmberAndFrostScreens(hGui app) {
    this.app = app;
  }

  void showMarketplaceOfferWindowEmberBoard(
      String skinName, String conditionToken, MarketplaceOfferAggregate offer, JFrame parent) {
    JFrame frame =
        app.offerNeonAndMirageScreens.createMarketplaceFrame(
            offer, skinName, conditionToken, parent, new Color(22, 8, 6));
    frame.add(
        app.offerHeroAndSellerScreens.createOfferHeader(
            offer.marketplaceName + " Ember Board",
            skinName + "  ·  hot inventory",
            offer,
            "🔥 FLASH STOCK"),
        BorderLayout.NORTH);

    ArrayList<MarketListing> sorted = app.marketOfferService.getSortedOfferListings(offer);
    double lo = sorted.stream().mapToDouble(l -> l.getPrice()).min().orElse(0);

    JPanel topStats = new JPanel(new GridLayout(1, 4, 1, 0));
    topStats.setBackground(new Color(16, 6, 4));
    topStats.setBorder(BorderFactory.createMatteBorder(0, 0, 1, 0, new Color(200, 80, 20)));
    topStats.add(
        app.offerEmberAndFrostScreens.createEmberKPI(
            "🔥 BEST ASK", "$" + String.format("%.2f", lo), new Color(255, 120, 30)));
    topStats.add(
        app.offerEmberAndFrostScreens.createEmberKPI(
            "OFFERS", String.valueOf(offer.listingCount), new Color(220, 80, 20)));
    topStats.add(
        app.offerEmberAndFrostScreens.createEmberKPI(
            "RATING", String.format("%.1f ★", offer.rating), new Color(255, 160, 60)));
    topStats.add(
        app.offerEmberAndFrostScreens.createEmberKPI(
            "REVIEWS", offer.reviews, new Color(200, 100, 30)));

    JPanel stack = new JPanel();
    stack.setLayout(new BoxLayout(stack, BoxLayout.Y_AXIS));
    stack.setBackground(new Color(22, 8, 6));
    stack.setBorder(BorderFactory.createEmptyBorder(14, 14, 14, 14));
    boolean first = true;
    for (MarketListing listing : sorted) {
      stack.add(app.offerEmberAndFrostScreens.createEmberRow(listing, offer, frame, first));
      stack.add(Box.createRigidArea(new Dimension(0, 8)));
      first = false;
    }

    JScrollPane scroll = new JScrollPane(stack);
    scroll.setBorder(null);
    scroll.getViewport().setBackground(new Color(22, 8, 6));
    scroll.getVerticalScrollBar().setUnitIncrement(20);

    JPanel center = new JPanel(new BorderLayout());
    center.setBackground(new Color(22, 8, 6));
    center.add(topStats, BorderLayout.NORTH);
    center.add(scroll, BorderLayout.CENTER);
    frame.add(center, BorderLayout.CENTER);
    frame.setVisible(true);
  }

  JPanel createEmberKPI(String label, String value, Color color) {
    JPanel p = new JPanel(new BorderLayout(0, 3));
    p.setBackground(new Color(28, 10, 8));
    p.setBorder(BorderFactory.createEmptyBorder(12, 16, 12, 16));
    JLabel lbl = new JLabel(label);
    lbl.setFont(new Font("Arial", Font.BOLD, 10));
    lbl.setForeground(new Color(140, 60, 30));
    JLabel val = new JLabel(value);
    val.setFont(new Font("Consolas", Font.BOLD, 18));
    val.setForeground(color);
    p.add(lbl, BorderLayout.NORTH);
    p.add(val, BorderLayout.CENTER);
    return p;
  }

  JPanel createEmberRow(
      MarketListing listing, MarketplaceOfferAggregate offer, JFrame parent, boolean hot) {
    JPanel row = new JPanel(new BorderLayout(12, 0));
    row.setBackground(hot ? new Color(50, 18, 10) : new Color(32, 12, 8));
    row.setMaximumSize(new Dimension(Integer.MAX_VALUE, 70));
    row.setBorder(
        BorderFactory.createCompoundBorder(
            BorderFactory.createLineBorder(hot ? new Color(220, 80, 20) : new Color(80, 30, 20), 1),
            BorderFactory.createEmptyBorder(12, 14, 12, 14)));

    JPanel info = new JPanel(new GridLayout(2, 1, 0, 4));
    info.setOpaque(false);
    JLabel top =
        new JLabel(
            (hot ? "🔥 " : "") + (listing.sellerName != null ? listing.sellerName : "Seller"));
    top.setFont(new Font("Arial", Font.BOLD, 14));
    top.setForeground(hot ? new Color(255, 140, 60) : Color.WHITE);
    JLabel bot =
        new JLabel(
            app.itemMetadataService.isAgentSkin(listing.item.name)
                ? "Agent"
                : ("Float "
                    + String.format("%.5f", listing.item.itemFloat)
                    + "  ·  "
                    + app.marketOfferService.formatMarketPatternText(listing)));
    bot.setFont(new Font("Consolas", Font.PLAIN, 11));
    bot.setForeground(new Color(160, 80, 40));
    info.add(top);
    info.add(bot);

    JPanel right = new JPanel(new BorderLayout(10, 0));
    right.setOpaque(false);
    JLabel price = new JLabel("$" + String.format("%.2f", listing.getPrice()));
    price.setFont(new Font("Consolas", Font.BOLD, 20));
    price.setForeground(hot ? new Color(255, 120, 30) : new Color(220, 100, 40));
    price.setHorizontalAlignment(SwingConstants.RIGHT);
    JButton btn =
        app.offerNeonAndMirageScreens.createMarketplaceActionButton(
            listing, offer, parent, hot ? "🔥 GRAB" : "BUY");
    btn.setPreferredSize(new Dimension(100, 36));
    right.add(price, BorderLayout.CENTER);
    right.add(btn, BorderLayout.EAST);

    row.add(info, BorderLayout.CENTER);
    row.add(right, BorderLayout.EAST);
    return row;
  }

  void showMarketplaceOfferWindowFrostLane(
      String skinName, String conditionToken, MarketplaceOfferAggregate offer, JFrame parent) {
    JFrame frame =
        app.offerNeonAndMirageScreens.createMarketplaceFrame(
            offer, skinName, conditionToken, parent, new Color(10, 18, 26));
    frame.add(
        app.offerHeroAndSellerScreens.createOfferHeader(
            offer.marketplaceName + " Frost Lane",
            conditionToken + "  ·  chilled corridor",
            offer,
            "❄ COLD QUEUE"),
        BorderLayout.NORTH);

    ArrayList<MarketListing> sorted = app.marketOfferService.getSortedOfferListings(offer);

    JPanel left = new JPanel();
    left.setLayout(new BoxLayout(left, BoxLayout.Y_AXIS));
    left.setBackground(new Color(10, 18, 26));
    left.setBorder(BorderFactory.createEmptyBorder(14, 14, 14, 14));
    for (MarketListing listing : sorted) {
      left.add(app.offerEmberAndFrostScreens.createFrostRow(listing, offer, frame));
      left.add(Box.createRigidArea(new Dimension(0, 8)));
    }

    JScrollPane scroll = new JScrollPane(left);
    scroll.setBorder(null);
    scroll.getViewport().setBackground(new Color(10, 18, 26));
    scroll.getVerticalScrollBar().setUnitIncrement(20);

    // Right frost panel
    JPanel right = new JPanel();
    right.setLayout(new BoxLayout(right, BoxLayout.Y_AXIS));
    right.setPreferredSize(new Dimension(210, 0));
    right.setBackground(new Color(12, 22, 32));
    right.setBorder(
        BorderFactory.createCompoundBorder(
            BorderFactory.createMatteBorder(0, 1, 0, 0, new Color(40, 100, 160)),
            BorderFactory.createEmptyBorder(20, 16, 20, 16)));

    right.add(
        app.offerEmberAndFrostScreens.createFrostStatBlock(
            "DELIVERY", offer.marketplaceType, offer.accent));
    right.add(Box.createRigidArea(new Dimension(0, 16)));
    right.add(
        app.offerEmberAndFrostScreens.createFrostStatBlock(
            "BEST PRICE", "$" + String.format("%.2f", offer.lowestPrice), offer.accent));
    right.add(Box.createRigidArea(new Dimension(0, 16)));
    right.add(
        app.offerEmberAndFrostScreens.createFrostStatBlock(
            "SELLERS", String.valueOf(offer.listingCount), offer.accent));
    right.add(Box.createRigidArea(new Dimension(0, 16)));
    right.add(
        app.offerEmberAndFrostScreens.createFrostStatBlock(
            "RATING", String.format("%.1f / 5", offer.rating), offer.accent));

    JSplitPane split = new JSplitPane(JSplitPane.HORIZONTAL_SPLIT, scroll, right);
    split.setResizeWeight(0.76);
    split.setDividerSize(3);
    split.setBorder(null);
    frame.add(split, BorderLayout.CENTER);
    frame.setVisible(true);
  }

  JPanel createFrostRow(MarketListing listing, MarketplaceOfferAggregate offer, JFrame parent) {
    JPanel row = new JPanel(new BorderLayout(12, 0));
    row.setBackground(new Color(14, 24, 34));
    row.setMaximumSize(new Dimension(Integer.MAX_VALUE, 64));
    row.setBorder(
        BorderFactory.createCompoundBorder(
            BorderFactory.createLineBorder(new Color(30, 70, 110), 1),
            BorderFactory.createEmptyBorder(10, 14, 10, 14)));

    JPanel info = new JPanel(new GridLayout(2, 1, 0, 3));
    info.setOpaque(false);
    JLabel name = new JLabel(listing.sellerName != null ? listing.sellerName : "Seller");
    name.setFont(new Font("Arial", Font.BOLD, 13));
    name.setForeground(new Color(220, 240, 255));
    JLabel detail =
        new JLabel(
            app.itemMetadataService.isAgentSkin(listing.item.name)
                ? "Agent"
                : ("Float "
                    + String.format("%.6f", listing.item.itemFloat)
                    + "  ·  "
                    + app.marketOfferService.formatMarketPatternText(listing)));
    detail.setFont(new Font("Consolas", Font.PLAIN, 11));
    detail.setForeground(new Color(80, 150, 200));
    info.add(name);
    info.add(detail);

    JPanel right = new JPanel(new BorderLayout(8, 0));
    right.setOpaque(false);
    JLabel price = new JLabel("$" + String.format("%.2f", listing.getPrice()));
    price.setFont(new Font("Consolas", Font.BOLD, 18));
    price.setForeground(offer.accent);
    price.setHorizontalAlignment(SwingConstants.RIGHT);
    JButton btn =
        app.offerNeonAndMirageScreens.createMarketplaceActionButton(listing, offer, parent, "BUY");
    btn.setPreferredSize(new Dimension(80, 34));
    right.add(price, BorderLayout.CENTER);
    right.add(btn, BorderLayout.EAST);

    row.add(info, BorderLayout.CENTER);
    row.add(right, BorderLayout.EAST);
    return row;
  }

  JPanel createFrostStatBlock(String label, String value, Color accent) {
    JPanel block = new JPanel(new BorderLayout(0, 6));
    block.setBackground(new Color(16, 28, 40));
    block.setBorder(
        BorderFactory.createCompoundBorder(
            BorderFactory.createLineBorder(new Color(30, 80, 130), 1),
            BorderFactory.createEmptyBorder(12, 14, 12, 14)));
    JLabel lbl = new JLabel(label);
    lbl.setFont(new Font("Arial", Font.BOLD, 10));
    lbl.setForeground(new Color(60, 130, 190));
    JLabel val = new JLabel(value);
    val.setFont(new Font("Consolas", Font.BOLD, 18));
    val.setForeground(Color.WHITE);
    block.add(lbl, BorderLayout.NORTH);
    block.add(val, BorderLayout.CENTER);
    return block;
  }
}
