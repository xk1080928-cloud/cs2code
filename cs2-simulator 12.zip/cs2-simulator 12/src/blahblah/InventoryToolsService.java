package blahblah;

import blahblah.InventoryToolsState.Tool;
import blahblah.hGui.*;
import java.awt.*;
import java.awt.event.*;
import java.math.BigDecimal;
import java.util.*;
import java.util.List;
import javax.swing.*;

/** CS2-style in-game tools store and owned-tool workflows; no real Steam payment is performed. */
final class InventoryToolsService {
  static final double PRICE = 1.99;
  static final int CAPACITY = 1000;
  static final String TAG_IMAGE =
      "https://community.akamai.steamstatic.com/economy/image/i0CoZ81Ui0m-9KwlBY1L_18myuGuq1wfhWSaZgMttyVfPaERSR0Wqmu7LAocGJG51EejH-LVxIT5Z3jCtwYt9YLw7F--F0ipzcG3pCQJ66f_bqA7c6GSCzfGwO9047BvATm9ks8vFHUO";
  static final String STORAGE_IMAGE =
      "https://community.akamai.steamstatic.com/economy/image/i0CoZ81Ui0m-9KwlBY1L_18myuGuq1wfhWSaZgMttyVfPaERSR0Wqmu7LAocGJG51EejH_XV0MGkITXE5AB094KtuwG0Exv1yMfkqXcCtvT_MPw5JPTKV2bDk7Z3sudtHSjr2w0ptCMWPT2u";
  private final hGui app;
  InventoryToolsState state = new InventoryToolsState();

  InventoryToolsService(hGui app) {
    this.app = app;
  }

  String title(Tool t) {
    return t.storage ? (t.activated ? t.label : "Storage Unit") : "Name Tag";
  }

  String displayName(InventoryItem i) {
    String label = state.customNames.get(i.itemId);
    String name = ItemPresentation.name(app, i);
    return label == null ? name : "“" + label + "” · " + name;
  }

  void changed() {
    if (!SwingUtilities.isEventDispatchThread()) {
      SwingUtilities.invokeLater(this::changed);
      return;
    }
    app.uiWidgets.updateBalanceLabel();
    app.containerSelectionScreen.invalidateCs2Inventory();
    app.cs2Screens.refreshCs2Inventory();
    app.saveService.saveProgress();
  }

  List<Tool> buy(boolean storage, int quantity) {
    List<Tool> bought = new ArrayList<>();
    synchronized (app) {
      if (quantity < 1 || quantity > 20) throw new IllegalArgumentException("Choose 1–20 tools.");
      BigDecimal cost = BigDecimal.valueOf(PRICE).multiply(BigDecimal.valueOf(quantity));
      if (app.coreUtilities.money(app.balance).compareTo(cost) < 0)
        throw new IllegalArgumentException("Insufficient simulator balance.");
      for (int n = 0; n < quantity; n++) {
        Tool tool = new Tool(storage);
        state.tools.add(tool);
        bought.add(tool);
      }
      app.balance = app.coreUtilities.money(app.balance).subtract(cost).doubleValue();
    }
    changed();
    return bought;
  }

  void showStore() {
    app.storeScreen.open("TOOLS");
  }

  JPanel storePanel() {
    JPanel root = app.cs2Screens.cs2Scene(true);
    root.setName("storeTools");
    root.setBorder(BorderFactory.createEmptyBorder(24, 30, 24, 30));
    root.add(app.cs2Screens.cs2Text("TOOLS", 28, Color.WHITE), BorderLayout.NORTH);
    JPanel cards = app.cs2Screens.cs2Glass(new GridLayout(1, 2, 24, 0));
    cards.setBorder(BorderFactory.createEmptyBorder(24, 0, 24, 0));
    for (boolean storage : new boolean[] {true, false}) {
      JPanel card = new JPanel(new BorderLayout(0, 16));
      card.setBackground(new Color(27, 35, 42));
      card.setBorder(BorderFactory.createEmptyBorder(20, 20, 20, 20));
      card.add(art(storage, 270, 210));
      JPanel text = app.cs2Screens.cs2Glass(new GridLayout(0, 1, 0, 10));
      text.add(app.cs2Screens.cs2Text(storage ? "Storage Unit" : "Name Tag", 22, Color.WHITE));
      text.add(
          app.cs2Screens.cs2Text(
              storage ? "Store up to 1,000 items" : "Rename one weapon", 14, Theme.TEXT_DIM));
      JButton buy = app.cs2Screens.cs2Button("BUY  $1.99", true, e -> checkout(storage));
      buy.setName(storage ? "buyStorageUnit" : "buyNameTag");
      text.add(buy);
      card.add(text, BorderLayout.SOUTH);
      cards.add(card);
    }
    root.add(cards);
    root.add(
        app.cs2Screens.cs2Text(
            "Simulated store • uses simulator balance, not Steam Wallet", 13, Theme.TEXT_DIM),
        BorderLayout.SOUTH);
    return root;
  }

  private void checkout(boolean storage) {
    JDialog d = dialog("Authorize purchase", 510, 330);
    JPanel root = new JPanel(new BorderLayout(16, 16));
    root.setBackground(Theme.BG_DARK);
    root.setBorder(BorderFactory.createEmptyBorder(24, 28, 24, 28));
    JPanel details = app.cs2Screens.cs2Glass(new GridLayout(0, 1, 0, 12));
    details.add(
        app.cs2Screens.cs2Text(
            "PURCHASE / " + (storage ? "Storage Unit" : "Name Tag"), 20, Color.WHITE));
    details.add(
        app.cs2Screens.cs2Text("$1.99 USD each · simulated in-game checkout", 14, Theme.TEXT_DIM));
    JSpinner quantity = new JSpinner(new SpinnerNumberModel(1, 1, 20, 1));
    quantity.setName("toolPurchaseQuantity");
    details.add(quantity);
    JLabel total = app.cs2Screens.cs2Text("TOTAL $1.99", 19, Color.WHITE);
    quantity.addChangeListener(
        e -> total.setText(String.format("TOTAL $%.2f", PRICE * (Integer) quantity.getValue())));
    details.add(total);
    root.add(details);
    boolean[] authorized = {false};
    JButton authorize =
        app.cs2Screens.cs2Button(
            "AUTHORIZE",
            true,
            e -> {
              if (authorized[0]) return;
              authorized[0] = true;
              try {
                buy(storage, (Integer) quantity.getValue());
                d.dispose();
                closeBrowser();
                app.cs2Screens.selectCs2InventorySection("EQUIPMENT");
              } catch (IllegalArgumentException ex) {
                authorized[0] = false;
                JOptionPane.showMessageDialog(d, ex.getMessage());
              }
            });
    authorize.setName("authorizeToolPurchase");
    JPanel actions = app.cs2Screens.cs2Glass(new FlowLayout(FlowLayout.RIGHT));
    actions.add(app.cs2Screens.cs2Button("CANCEL", false, e -> d.dispose()));
    actions.add(authorize);
    root.add(actions, BorderLayout.SOUTH);
    d.setContentPane(root);
    d.setVisible(true);
  }

  JLabel art(boolean storage, int width, int height) {
    JLabel l = new JLabel("", SwingConstants.CENTER);
    String key = storage ? "tool-storage" : "tool-name-tag";
    Image image = app.imageRepository == null ? null : app.imageRepository.get(key);
    if (image != null) l.setIcon(new ImageIcon(app.cs2Screens.scaleCs2Image(image, width, height)));
    else l.setText("Loading artwork…");
    l.setForeground(Theme.TEXT_DIM);
    if (image == null && app.imageRepository != null) {
      app.artworkService.registerPendingRemoteImageLabel(key, l, width, height);
      app.imageRepository.loadRemote(key, storage ? STORAGE_IMAGE : TAG_IMAGE, false);
    }
    return l;
  }

  JPanel card(Tool t) {
    JPanel p =
        app.cs2Screens.createCs2Tile(
            title(t),
            t.storage
                ? (t.activated ? t.size() + " / 1,000 items" : "Storage Unit · Not in use")
                : "Base Grade Tool",
            new Color(165, 187, 197),
            art(t.storage, 150, 105),
            () -> menu(t));
    app.cs2Screens.installCs2CardClick(
        p,
        new MouseAdapter() {
          public void mouseClicked(MouseEvent e) {
            if (SwingUtilities.isRightMouseButton(e) || e.isControlDown()) menu(t);
          }
        });
    p.putClientProperty("inventoryTool", t);
    return p;
  }

  void menu(Tool t) {
    JPopupMenu m = popup();
    if (t.storage) {
      if (!t.activated) add(m, "Start Using This Unit", () -> label(t));
      else {
        add(m, "Inspect", () -> transfer(t, false));
        add(m, "Deposit Items", () -> transfer(t, true));
        add(m, "Retrieve Items", () -> transfer(t, false));
        add(m, "Change Label", () -> label(t));
      }
    } else add(m, "Apply Name Tag", () -> pickRenameTarget(t));
    showPopupAtCursor(m);
  }

  void label(Tool t) {
    String value =
        JOptionPane.showInputDialog(
            app, t.activated ? "Change Label" : "Start Using This Unit — choose a label", t.label);
    if (value == null) return;
    try {
      setLabel(t, value);
      changed();
    } catch (IllegalArgumentException e) {
      JOptionPane.showMessageDialog(app, e.getMessage());
    }
  }

  static String validName(String value) {
    if (value == null) throw new IllegalArgumentException("Enter a label.");
    String s = value.trim();
    if (s.isEmpty()
        || s.codePointCount(0, s.length()) > 20
        || s.codePoints().anyMatch(Character::isISOControl))
      throw new IllegalArgumentException("Use 1–20 characters, without control characters.");
    return s;
  }

  void setLabel(Tool t, String name) {
    if (!state.tools.contains(t) || !t.storage)
      throw new IllegalArgumentException("Select an owned Storage Unit.");
    t.label = validName(name);
    t.activated = true;
  }

  boolean canRename(InventoryItem i) {
    if (i == null || !app.inventoryList.contains(i)) return false;
    String rarity = i.rarity.replace("StatTrak ", "");
    return !"Gloves".equals(rarity)
        && !app.itemMetadataService.isAgentSkin(i.name)
        && app.exchangeStockService.exchangeContainer(i.name) == null;
  }

  void rename(Tool tag, InventoryItem item, String label) {
    synchronized (app) {
      String name = validName(label);
      if (!state.tools.contains(tag) || tag.storage || !canRename(item))
        throw new IllegalArgumentException("The Name Tag or weapon is no longer available.");
      app.ownershipHistoryService.ensureInventoryItemTracking(item);
      state.customNames.put(item.itemId, name);
      state.tools.remove(tag);
    }
  }

  void renameItem(InventoryItem item) {
    Tool tag = state.tools.stream().filter(t -> !t.storage).findFirst().orElse(null);
    if (tag == null) {
      if (JOptionPane.showConfirmDialog(
              app,
              "You need a Name Tag. Open the in-game Tools Store?",
              "Rename",
              JOptionPane.YES_NO_OPTION)
          == JOptionPane.YES_OPTION) showStore();
      return;
    }
    promptRename(tag, item);
  }

  void promptRename(Tool tag, InventoryItem item) {
    String label =
        JOptionPane.showInputDialog(
            app,
            "Rename " + item.name + "\nA Name Tag can only be used once. Maximum 20 characters.",
            state.customNames.getOrDefault(item.itemId, ""));
    if (label == null) return;
    if (JOptionPane.showConfirmDialog(
            app,
            "Apply “" + label + "” to " + item.name + "?\nThis consumes one Name Tag.",
            "Apply Name Tag",
            JOptionPane.OK_CANCEL_OPTION)
        != JOptionPane.OK_OPTION) return;
    try {
      rename(tag, item, label);
      changed();
    } catch (IllegalArgumentException ex) {
      JOptionPane.showMessageDialog(app, ex.getMessage());
    }
  }

  void pickRenameTarget(Tool tag) {
    JDialog d = dialog("Apply Name Tag · Select a weapon", 900, 650);
    JPanel grid = app.cs2Screens.cs2Grid(5, 12, 12);
    for (InventoryItem i : app.inventoryList)
      if (canRename(i))
        grid.add(
            app.cs2Screens.createCs2SkinCard(
                i,
                () -> {
                  d.dispose();
                  promptRename(tag, i);
                }));
    d.setContentPane(scroll(grid));
    d.setVisible(true);
  }

  boolean storable(Object value) {
    if (value instanceof Tool) return !((Tool) value).storage && state.tools.contains(value);
    if (value instanceof OwnedSupply)
      return !((OwnedSupply) value).key && app.ownedSupplies.contains(value);
    if (!(value instanceof InventoryItem)) return false;
    InventoryItem i = (InventoryItem) value;
    return app.inventoryList.contains(i)
        && !app.cs2EquipmentScreens.isDefaultWeaponItem(i)
        && !i.rarity.contains("Gloves")
        && !app.itemMetadataService.isAgentSkin(i.name);
  }

  void deposit(Tool unit, List<Object> items) {
    synchronized (app) {
      validateUnit(unit);
      Set<Object> unique = Collections.newSetFromMap(new IdentityHashMap<>());
      unique.addAll(items);
      if (unique.size() != items.size() || unit.size() + items.size() > CAPACITY)
        throw new IllegalArgumentException(
            "Select distinct items; a Storage Unit holds up to 1,000 items.");
      for (Object o : items)
        if (!storable(o))
          throw new IllegalArgumentException(
              "One selected item cannot be stored or is no longer in Inventory.");
      for (Object o : items)
        if (o instanceof InventoryItem) {
          InventoryItem i = (InventoryItem) o;
          app.ownershipHistoryService.ensureInventoryItemTracking(i);
          unit.skins.add(InventoryItemCodec.encode(i));
          app.inventoryList.remove(i);
          app.exchangeTransactionService.unEquipExchangeItem(i);
          app.inventoryValue = Math.max(0, app.inventoryValue - i.price.doubleValue());
        } else if (o instanceof OwnedSupply) {
          unit.supplies.add((OwnedSupply) o);
          app.ownedSupplies.remove(o);
        } else {
          unit.tags.add((Tool) o);
          state.tools.remove(o);
        }
    }
  }

  void validateUnit(Tool unit) {
    if (!state.tools.contains(unit) || !unit.storage || !unit.activated)
      throw new IllegalArgumentException("Activate an owned Storage Unit first.");
  }

  List<Object> contents(Tool t) {
    List<Object> list = new ArrayList<>();
    list.addAll(t.skins);
    list.addAll(t.supplies);
    list.addAll(t.tags);
    return list;
  }

  void retrieve(Tool unit, List<Object> items) {
    synchronized (app) {
      validateUnit(unit);
      List<Object> all = contents(unit);
      Set<Object> unique = Collections.newSetFromMap(new IdentityHashMap<>());
      unique.addAll(items);
      if (unique.size() != items.size() || !all.containsAll(items))
        throw new IllegalArgumentException("A selected stored item is no longer available.");
      for (Object o : items)
        if (o instanceof GameState.SerializableInventoryItem) {
          InventoryItem i = InventoryItemCodec.decode((GameState.SerializableInventoryItem) o);
          if (app.inventoryList.stream().anyMatch(x -> Objects.equals(x.itemId, i.itemId)))
            throw new IllegalArgumentException("Duplicate item identity.");
        }
      for (Object o : items)
        if (o instanceof GameState.SerializableInventoryItem) {
          unit.skins.remove(o);
          InventoryItem i = InventoryItemCodec.decode((GameState.SerializableInventoryItem) o);
          app.inventoryList.add(i);
          app.inventoryValue += i.price.doubleValue();
          app.itemRevealService.received(i);
        } else if (o instanceof OwnedSupply) {
          unit.supplies.remove(o);
          app.ownedSupplies.add((OwnedSupply) o);
          app.itemRevealService.received((OwnedSupply) o);
        } else {
          unit.tags.remove(o);
          state.tools.add((Tool) o);
        }
    }
  }

  String name(Object o) {
    if (o instanceof InventoryItem) return displayName((InventoryItem) o);
    if (o instanceof GameState.SerializableInventoryItem)
      return ((GameState.SerializableInventoryItem) o).name;
    if (o instanceof OwnedSupply) {
      OwnedSupply s = (OwnedSupply) o;
      return CaseType.valueOf(s.caseId).catalogCrateName() + (s.key ? " Key" : "");
    }
    return title((Tool) o);
  }

  Tool browsingUnit;
  private boolean depositing;
  private String browserSearch = "";
  private int browserPage;
  private final List<Object> selected = new ArrayList<>();

  void closeBrowser() {
    browsingUnit = null;
    selected.clear();
    if (app.inventoryTabPanel != null)
      app.inventoryTabPanel.putClientProperty("storageSnapshot", null);
  }

  void transfer(Tool unit, boolean deposit) {
    validateUnit(unit);
    closeBrowser();
    browsingUnit = unit;
    depositing = deposit;
    browserSearch = "";
    browserPage = 0;
    app.cs2EquipFilter = null;
    app.cs2UnlockSelection = null;
    app.mainTabs.setSelectedIndex(2);
    renderBrowser();
  }

  void renderBrowser() {
    Tool unit = browsingUnit;
    if (unit == null) return;
    if (!state.tools.contains(unit)) {
      closeBrowser();
      app.cs2Screens.refreshCs2Inventory();
      return;
    }
    List<Object> items = new ArrayList<>();
    if (depositing) {
      for (InventoryItem i : app.inventoryList) if (storable(i)) items.add(i);
      for (OwnedSupply supply : app.ownedSupplies) if (storable(supply)) items.add(supply);
      for (Tool tool : state.tools) if (storable(tool)) items.add(tool);
    } else items.addAll(contents(unit));
    selected.retainAll(items);
    List<Object> snapshot = new ArrayList<>(items);
    snapshot.add(unit.id);
    snapshot.add(unit.label);
    snapshot.add(unit.size());
    snapshot.add(depositing);
    if (snapshot.equals(app.inventoryTabPanel.getClientProperty("storageSnapshot"))) return;
    app.inventoryTabPanel.putClientProperty("storageSnapshot", snapshot);
    app.inventoryTabPanel.removeAll();
    app.inventoryTabPanel.setLayout(new BorderLayout());
    app.inventoryTabPanel.add(app.cs2Screens.createCs2InventoryNav(), BorderLayout.NORTH);
    JPanel scene = app.cs2Screens.cs2Scene(true);
    scene.setName("storageInventoryBrowser");
    scene.putClientProperty("storageUnitId", unit.id);
    JPanel heading = app.cs2Screens.cs2Glass(new BorderLayout(16, 8));
    heading.setBorder(BorderFactory.createEmptyBorder(16, 28, 12, 28));
    heading.add(
        app.cs2Screens.cs2Button(
            "← INVENTORY",
            false,
            e -> {
              closeBrowser();
              app.cs2Screens.selectCs2InventorySection("EQUIPMENT");
            }),
        BorderLayout.WEST);
    heading.add(
        app.cs2Screens.cs2Text(
            title(unit)
                + "  /  "
                + (depositing ? "DEPOSIT ITEMS" : "STORED ITEMS")
                + "  ·  "
                + unit.size()
                + " / 1,000",
            18,
            Color.WHITE));
    JTextField search = new JTextField(browserSearch, 20);
    search.setName("storageInventorySearch");
    search.setBackground(new Color(53, 61, 65));
    search.setForeground(Color.WHITE);
    search.setCaretColor(Color.WHITE);
    heading.add(search, BorderLayout.EAST);
    scene.add(heading, BorderLayout.NORTH);
    JPanel grid = app.cs2Screens.cs2Grid(8, 14, 18);
    grid.setName("storageInventoryGrid");
    grid.setBorder(BorderFactory.createEmptyBorder(10, 28, 24, 28));
    JScrollPane scroll = scroll(grid);
    scroll.setOpaque(false);
    scroll.getViewport().setOpaque(false);
    scene.add(scroll);
    JPanel footer = app.cs2Screens.cs2Glass(new FlowLayout(FlowLayout.RIGHT, 12, 14));
    JLabel count = app.cs2Screens.cs2Text("", 14, Color.WHITE);
    footer.add(count);
    JButton prev = app.cs2Screens.cs2Button("‹", false, null),
        next = app.cs2Screens.cs2Button("›", false, null);
    footer.add(prev);
    footer.add(next);
    JButton commit =
        app.cs2Screens.cs2Button(
            depositing ? "DEPOSIT SELECTED" : "RETRIEVE SELECTED",
            true,
            e -> {
              try {
                List<Object> batch = new ArrayList<>(selected);
                if (depositing) deposit(unit, batch);
                else retrieve(unit, batch);
                selected.clear();
                app.inventoryTabPanel.putClientProperty("storageSnapshot", null);
                if (!depositing) app.navigationService.mainInventory();
                changed();
                if (!depositing) SwingUtilities.invokeLater(app.itemRevealService::showPending);
              } catch (IllegalArgumentException ex) {
                JOptionPane.showMessageDialog(app, ex.getMessage());
              }
            });
    commit.setName("storageInventoryCommit");
    footer.add(commit);
    scene.add(footer, BorderLayout.SOUTH);
    Runnable[] paint = {null};
    paint[0] =
        () -> {
          browserSearch = search.getText();
          List<Object> visible = new ArrayList<>();
          String q = browserSearch.toLowerCase(Locale.ROOT);
          for (Object o : items) if (name(o).toLowerCase(Locale.ROOT).contains(q)) visible.add(o);
          int pages = Math.max(1, (visible.size() + 59) / 60);
          browserPage = Math.max(0, Math.min(browserPage, pages - 1));
          grid.removeAll();
          for (int n = browserPage * 60;
              n < Math.min(visible.size(), (browserPage + 1) * 60);
              n++) {
            Object o = visible.get(n);
            Runnable choose =
                () -> {
                  if (!selected.remove(o)) selected.add(o);
                  paint[0].run();
                };
            JPanel card;
            if (o instanceof GameState.SerializableInventoryItem)
              card =
                  app.cs2Screens.createCs2SkinCard(
                      InventoryItemCodec.decode((GameState.SerializableInventoryItem) o), choose);
            else if (o instanceof InventoryItem)
              card = app.cs2Screens.createCs2SkinCard((InventoryItem) o, choose);
            else if (o instanceof OwnedSupply) {
              OwnedSupply supply = (OwnedSupply) o;
              JLabel image = new JLabel("", SwingConstants.CENTER);
              app.cs2Screens.bindCs2SupplyArtwork(
                  CaseType.valueOf(supply.caseId), supply.key, image, 150, 105);
              card =
                  app.cs2Screens.createCs2Tile(
                      name(o),
                      supply.key ? "Key" : "Container",
                      new Color(165, 180, 190),
                      image,
                      choose);
            } else {
              Tool tool = (Tool) o;
              card =
                  app.cs2Screens.createCs2Tile(
                      title(tool),
                      "Name Tag",
                      new Color(165, 180, 190),
                      art(false, 150, 105),
                      choose);
            }
            card.putClientProperty("storedObject", o);
            card.setBorder(
                BorderFactory.createLineBorder(
                    selected.contains(o) ? new Color(120, 205, 240) : new Color(0, 0, 0, 0), 2));
            grid.add(card);
          }
          count.setText(
              visible.size()
                  + " items · "
                  + selected.size()
                  + " selected · Page "
                  + (browserPage + 1)
                  + " / "
                  + pages);
          commit.setEnabled(!selected.isEmpty());
          prev.setEnabled(browserPage > 0);
          next.setEnabled(browserPage + 1 < pages);
          grid.revalidate();
          grid.repaint();
        };
    prev.addActionListener(
        e -> {
          browserPage--;
          paint[0].run();
        });
    next.addActionListener(
        e -> {
          browserPage++;
          paint[0].run();
        });
    app.exchangeWidgets.exchangeDebounce(
        search,
        () -> {
          browserPage = 0;
          paint[0].run();
        });
    paint[0].run();
    app.inventoryTabPanel.add(scene);
    app.inventoryTabPanel.revalidate();
    app.inventoryTabPanel.repaint();
  }

  Set<String> favorites(boolean t) {
    if (t) {
      if (state.favoriteT == null) state.favoriteT = new LinkedHashSet<>();
      return state.favoriteT;
    }
    if (state.favoriteCT == null) state.favoriteCT = new LinkedHashSet<>();
    return state.favoriteCT;
  }

  void moveToUnit(InventoryItem item) {
    List<Tool> units = new ArrayList<>();
    for (Tool t : state.tools) if (t.storage && t.activated && t.size() < CAPACITY) units.add(t);
    if (units.isEmpty()) {
      if (JOptionPane.showConfirmDialog(
              app,
              "No activated Storage Unit with free space. Open Store → Tools?",
              "Move to Storage Unit",
              JOptionPane.YES_NO_OPTION)
          == JOptionPane.YES_OPTION) showStore();
      return;
    }
    String[] labels = new String[units.size()];
    for (int n = 0; n < units.size(); n++)
      labels[n] = (n + 1) + ". " + title(units.get(n)) + " (" + units.get(n).size() + " / 1,000)";
    Object choice =
        JOptionPane.showInputDialog(
            app,
            "Choose a Storage Unit",
            "Move to Storage Unit",
            JOptionPane.PLAIN_MESSAGE,
            null,
            labels,
            labels[0]);
    if (choice == null) return;
    try {
      deposit(units.get(java.util.Arrays.asList(labels).indexOf(choice)), List.of(item));
      changed();
    } catch (IllegalArgumentException ex) {
      JOptionPane.showMessageDialog(app, ex.getMessage());
    }
  }

  JPopupMenu popup() {
    JPopupMenu p = new JPopupMenu();
    p.setBackground(new Color(36, 36, 36));
    p.setBorder(BorderFactory.createLineBorder(new Color(61, 61, 61)));
    return p;
  }

  void showPopupAtCursor(JPopupMenu menu) {
    Point point = null;
    try {
      PointerInfo pointer = MouseInfo.getPointerInfo();
      if (pointer != null) point = pointer.getLocation();
    } catch (HeadlessException | SecurityException ignored) {
    }
    JComponent owner = app.getRootPane();
    if (point == null) point = new Point(owner.getWidth() / 2, owner.getHeight() / 2);
    else SwingUtilities.convertPointFromScreen(point, owner);
    menu.show(owner, point.x, point.y);
  }

  void add(JPopupMenu m, String text, Runnable run) {
    JMenuItem i = new JMenuItem(text);
    i.setUI(
        new javax.swing.plaf.basic.BasicMenuItemUI() {
          protected void installDefaults() {
            super.installDefaults();
            selectionBackground = new Color(55, 61, 65);
            selectionForeground = Color.WHITE;
          }
        });
    i.setOpaque(true);
    i.setBackground(new Color(36, 36, 36));
    i.setForeground(new Color(225, 225, 225));
    i.setFont(app.cs2Screens.cs2Font(Font.PLAIN, 14));
    i.setBorder(BorderFactory.createEmptyBorder(11, 18, 11, 22));
    i.addActionListener(e -> run.run());
    m.add(i);
  }

  private JScrollPane scroll(JPanel p) {
    JScrollPane s = new JScrollPane(p);
    s.setBorder(null);
    s.getViewport().setBackground(Theme.BG_DARK);
    s.getVerticalScrollBar().setUnitIncrement(24);
    return s;
  }

  private JDialog dialog(String title, int w, int h) {
    JDialog d = new JDialog(app, title, true);
    d.setDefaultCloseOperation(JDialog.DISPOSE_ON_CLOSE);
    d.setSize(Math.min(w, app.getWidth() - 40), Math.min(h, app.getHeight() - 40));
    d.setLocationRelativeTo(app);
    return d;
  }
}
