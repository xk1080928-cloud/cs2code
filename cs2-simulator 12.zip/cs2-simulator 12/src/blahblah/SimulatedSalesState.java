package blahblah;

import blahblah.hGui.*;
import java.awt.*;
import java.awt.event.*;
import java.util.ArrayList;
import java.util.List;
import javax.swing.*;

/** Extracted reusable model or widget; behavior retained from the original source. */
final class SimulatedSalesState {
  private final hGui app;

  final String key, skinName, condition, rarity, browseKey;
  final boolean statTrak;
  final MarketListing template;
  final long seed;
  final double minFloat, maxFloat;
  final long[] timestamps = new long[hGui.SIMULATED_SALE_HISTORY_SIZE];
  final double[] prices = new double[hGui.SIMULATED_SALE_HISTORY_SIZE];
  int next, count;
  long sequence;
  double lastSaleAt, baseAsk, rate;

  SimulatedSalesState(hGui app, String key, MarketListing template, double ask, long now) {
    this.app = app;
    this.key = key;
    this.template = template;
    skinName = template.item.name;
    condition = template.item.condition;
    statTrak = template.item.isStattrak;
    rarity = app.salesSimulationService.getListingRarity(template, key);
    browseKey = app.marketGroupingService.getMarketplaceBrowseKey(skinName);
    seed = SalesSimulationService.simulatedSaleHash(key.hashCode());
    double[] limits = app.marketStockService.getMarketWearBounds(skinName);
    int wear = java.util.Arrays.asList(hGui.MARKET_WEAR_NAMES).indexOf(condition);
    minFloat =
        wear < 0 || app.floatRules.hasNoFloatWear(skinName)
            ? 0
            : Math.max(limits[0], hGui.MARKET_WEAR_EDGES[wear]);
    maxFloat =
        wear < 0 || app.floatRules.hasNoFloatWear(skinName)
            ? 0
            : Math.min(limits[1], hGui.MARKET_WEAR_EDGES[wear + 1]);
    baseAsk = ask;
    rate = app.salesSimulationService.getSimulatedSalesPerMinute(rarity, ask, statTrak);
    double interval = 60000.0 / Math.max(.0005, rate);
    for (int i = hGui.SIMULATED_SALE_HISTORY_SIZE - 1; i >= 0; i--)
      append((long) (now - i * interval), ask);
    lastSaleAt = now;
  }

  void append(long timestamp, double ask) {
    long hash = SalesSimulationService.simulatedSaleHash(seed + sequence++);
    double noise = .985 + (hash >>> 11) * 0x1.0p-53 * .03;
    timestamps[next] = timestamp;
    prices[next] = Math.max(.01, Math.round(ask * noise * 100.0) / 100.0);
    next = (next + 1) % hGui.SIMULATED_SALE_HISTORY_SIZE;
    count = Math.min(count + 1, hGui.SIMULATED_SALE_HISTORY_SIZE);
  }

  synchronized void advance(long now) {
    if (rate <= 0 || now <= lastSaleAt) return;
    double interval = 60000.0 / rate;
    long due = (long) Math.floor((now - lastSaleAt) / interval);
    if (due <= 0) return;
    if (due > hGui.SIMULATED_SALE_HISTORY_SIZE) {
      long skipped = due - hGui.SIMULATED_SALE_HISTORY_SIZE;
      sequence += skipped;
      lastSaleAt += skipped * interval;
      due = hGui.SIMULATED_SALE_HISTORY_SIZE;
    }
    for (long i = 0; i < due; i++) {
      lastSaleAt += interval;
      append((long) lastSaleAt, baseAsk);
    }
  }

  synchronized void quote(double ask, long now) {
    advance(now);
    if (!Double.isFinite(ask) || ask <= 0) return;
    double fraction = Math.max(0, (now - lastSaleAt) / (60000.0 / Math.max(.0005, rate)));
    baseAsk = ask;
    rate = app.salesSimulationService.getSimulatedSalesPerMinute(rarity, ask, statTrak);
    lastSaleAt = now - fraction * (60000.0 / rate);
  }

  synchronized List<SaleRecord> snapshot(long now) {
    advance(now);
    List<SaleRecord> sales = new ArrayList<>(count);
    for (int i = 0; i < count; i++) {
      int slot =
          (next - count + i + hGui.SIMULATED_SALE_HISTORY_SIZE) % hGui.SIMULATED_SALE_HISTORY_SIZE;
      long hash = SalesSimulationService.simulatedSaleHash(seed ^ timestamps[slot]);
      double unit = (hash >>> 11) * 0x1.0p-53;
      double itemFloat =
          minFloat >= maxFloat ? minFloat : minFloat + unit * (Math.nextDown(maxFloat) - minFloat);
      String name = (statTrak ? "StatTrak " : "") + skinName;
      SaleRecord sale =
          new SaleRecord(name, prices[slot], condition, itemFloat, template.item.blueGemTier);
      sale.timestamp = timestamps[slot];
      sale.simulatedMarketSale = true;
      sale.marketplaceName = template.marketplaceName;
      sale.buyerName = hGui.NPC_USERNAMES[Math.floorMod((int) hash, hGui.NPC_USERNAMES.length)];
      sale.buyerAvatar =
          hGui.NPC_AVATAR_POOL[Math.floorMod((int) (hash >>> 32), hGui.NPC_AVATAR_POOL.length)];
      sales.add(sale);
    }
    return sales;
  }
}
