package blahblah;

import blahblah.hGui.*;
import java.awt.*;
import java.awt.event.*;
import javax.swing.*;

/** Extracted reusable model or widget; behavior retained from the original source. */
public class TradeUpCollection {
  final String collectionName;
  final String[] consumerSkins;
  final String[] industrialSkins;
  final String[] milspecSkins;
  final String[] restrictedSkins;
  final String[] classifiedSkins;
  final String[] covertSkins;

  public TradeUpCollection(String n, String[] mil, String[] res, String[] cls, String[] cov) {
    this.collectionName = n;
    this.consumerSkins = new String[0];
    this.industrialSkins = new String[0];
    this.milspecSkins = mil != null ? mil : new String[0];
    this.restrictedSkins = res != null ? res : new String[0];
    this.classifiedSkins = cls != null ? cls : new String[0];
    this.covertSkins = cov != null ? cov : new String[0];
  }

  public TradeUpCollection(
      String n, String[] ind, String[] mil, String[] res, String[] cls, String[] cov) {
    this(n, new String[0], ind, mil, res, cls, cov);
  }

  public TradeUpCollection(
      String n,
      String[] consumer,
      String[] ind,
      String[] mil,
      String[] res,
      String[] cls,
      String[] cov) {
    this.collectionName = n;
    this.consumerSkins = consumer != null ? consumer : new String[0];
    this.industrialSkins = ind != null ? ind : new String[0];
    this.milspecSkins = mil != null ? mil : new String[0];
    this.restrictedSkins = res != null ? res : new String[0];
    this.classifiedSkins = cls != null ? cls : new String[0];
    this.covertSkins = cov != null ? cov : new String[0];
  }

  public String getTierForSkin(String name) {
    String n = name.replace("StatTrak ", "").replace("StatTrak ", "").trim();
    n = n.replaceFirst("(?i)^Souvenir\\s+", "");
    int p = n.indexOf(" (");
    if (p > 0) n = n.substring(0, p).trim();
    for (String s : consumerSkins)
      if (s.replaceFirst("(?i)^Souvenir\\s+", "").equalsIgnoreCase(n)) return "Consumer";
    for (String s : industrialSkins)
      if (s.replaceFirst("(?i)^Souvenir\\s+", "").equalsIgnoreCase(n)) return "Industrial";
    for (String s : milspecSkins)
      if (s.replaceFirst("(?i)^Souvenir\\s+", "").equalsIgnoreCase(n)) return "Milspec";
    for (String s : restrictedSkins)
      if (s.replaceFirst("(?i)^Souvenir\\s+", "").equalsIgnoreCase(n)) return "Restricted";
    for (String s : classifiedSkins)
      if (s.replaceFirst("(?i)^Souvenir\\s+", "").equalsIgnoreCase(n)) return "Classified";
    for (String s : covertSkins)
      if (s.replaceFirst("(?i)^Souvenir\\s+", "").equalsIgnoreCase(n)) return "Covert";
    return null;
  }

  public String[] getOutcomePool(String inputRarity) {
    switch (inputRarity) {
      case "Consumer":
        return industrialSkins;
      case "Industrial":
        return milspecSkins;
      case "Milspec":
        return restrictedSkins;
      case "Restricted":
        return classifiedSkins;
      case "Classified":
        return covertSkins;
      default:
        return new String[0];
    }
  }
}
