package blahblah;

import blahblah.hGui.*;
import java.awt.*;
import java.awt.event.*;
import javax.swing.*;

/** Navigation Service: focused feature implementation. */
final class NavigationService {
  private final hGui app;

  NavigationService(hGui app) {
    this.app = app;
  }

  void navigateCs2Top(int index) {
    app.pageTransitions.begin();
    if (index == 6) {
      app.generalScreen.refreshGeneralTab();
      app.mainTabs.setSelectedIndex(6);
      app.pageTransitions.finish();
      return;
    }
    if (index == 2 && app.mainTabs.getSelectedIndex() != 2) {
      mainInventory();
      return;
    }
    if (index == 2 && app.inventoryToolsService.browsingUnit != null) {
      app.inventoryToolsService.closeBrowser();
      app.cs2Screens.selectCs2InventorySection("EQUIPMENT");
      return;
    }
    if (index == 2 && (app.cs2UnlockSelection != null || app.cs2EquipFilter != null)) {
      app.cs2UnlockSelection = null;
      app.cs2EquipFilter = null;
      app.cs2InventorySearch = "";
      app.cs2Screens.selectCs2InventorySection("EVERYTHING");
      return;
    }
    int target = app.mainTabs.getSelectedIndex() == index ? 0 : index;
    if (target == 0) app.cs2Screens.refreshCs2Home();
    app.mainTabs.setSelectedIndex(target);
  }

  void mainInventory() {
    app.pageTransitions.begin();
    app.inventoryToolsService.closeBrowser();
    app.cs2UnlockSelection = null;
    app.cs2EquipFilter = null;
    app.cs2InventorySearch = "";
    app.cs2InventoryPage = 0;
    app.containerSelectionScreen.invalidateCs2Inventory();
    app.cs2Screens.selectCs2InventorySection("EVERYTHING");
    app.mainTabs.setSelectedIndex(2);
    app.pageTransitions.finish();
  }
}
