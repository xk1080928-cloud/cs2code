package blahblah;

import java.util.*;

/** Individually addressable virtual units. Only viewed units and consumed bitsets are allocated. */
final class MarketplaceUnitStock {
  private final hGui app;
  private final Map<MarketListing, State> states = new WeakHashMap<>();
  private final Map<String, Long> nextOrdinal = new HashMap<>();

  MarketplaceUnitStock(hGui app) {
    this.app = app;
  }

  private static final class State {
    final long base;
    final int initial;
    final BitSet consumed = new BitSet();
    long first, capacity, step, offset;
    boolean noFloat;
    int cheapest = -1;
    double priceSum=Double.NaN, sumBase=Double.NaN;
    double min, max;

    State(long base, int count) {
      this.base = base;
      initial = count;
    }
  }

  private synchronized State state(MarketListing parent) {
    State state = states.get(parent);
    if (state == null) {
      String key = MarketplacePricing.variant(parent.item);
      long base = nextOrdinal.getOrDefault(key, 0L);
      state = new State(base, parent.quantity);
      initializeSequence(parent.item, state);
      states.put(parent, state);
      nextOrdinal.put(key, base + parent.quantity);
    }
    return state;
  }

  boolean available(MarketListing view) {
    if (view.stockParent == null) return false;
    State state = state(view.stockParent);
    return view.stockIndex >= 0
        && view.stockIndex < state.initial
        && !state.consumed.get(view.stockIndex);
  }

  MarketListing at(MarketplaceGroups.Group group, int rank) {
    for (MarketListing parent : group.lots) {
      int size = Math.max(0, parent.quantity);
      if (rank < size) return unit(parent, rank);
      rank -= size;
    }
    throw new IndexOutOfBoundsException("Offer no longer available");
  }

  synchronized MarketListing unit(MarketListing parent, int availableRank) {
    if (parent.isPlayerListing) return parent;
    State state = state(parent);
    int index = availableRank;
    for (int sold = state.consumed.nextSetBit(0);
        sold >= 0 && sold <= index;
        sold = state.consumed.nextSetBit(sold + 1)) index++;
    if (index >= state.initial) throw new IndexOutOfBoundsException("Offer no longer available");
    InventoryItem src = parent.item;
    double value = floatAt(state, index);
    int pattern =
        (int)
            Math.floorMod(
                app.exchangeStockService.mixExchange((state.base + index) ^ 0x6A09E667F3BCC909L),
                1000);
    InventoryItem item =
        new InventoryItem(
            null,
            src.name,
            src.condition,
            src.rarity,
            src.price,
            value,
            src.isStattrak,
            pattern,
            app.itemPriceService.getBlueGemTier(src.name, pattern),
            src.basePrice,
            true);
    item.collection = src.collection;
    MarketListing view = new MarketListing(item, parent.getPrice(), parent.timeRemaining, true);
    view.isPlayerListing = false;
    view.stockParent = parent;
    if (app.exchangeStockService.exchangeContainer(src.name) == null) {
      view.unitPriceFactor = MarketDynamics.floatPremium(src.condition, value, state.min, state.max);
      view.item.price = app.coreUtilities.money(view.getPrice());
    }
    view.stockIndex = index;
    view.quantity = 1;
    view.marketplaceName = parent.marketplaceName;
    view.marketplaceType = parent.marketplaceType;
    view.sellerName = parent.sellerName;
    view.sellerAvatar = parent.sellerAvatar;
    view.marketplaceRating = parent.marketplaceRating;
    view.marketplaceReviews = parent.marketplaceReviews;
    return view;
  }

  private void initializeSequence(InventoryItem item, State state) {
    state.noFloat = app.floatRules.hasNoFloatWear(item.name) || app.exchangeStockService.exchangeContainer(item.name) != null;
    if (state.noFloat) return;
    double[] bounds = app.marketStockService.getMarketWearBounds(item.name);
    state.min=bounds[0]; state.max=bounds[1];
    int wear=Arrays.asList(hGui.MARKET_WEAR_NAMES).indexOf(item.condition);
    double low=state.min, high=state.max;
    if (wear>=0) {low=Math.max(low,hGui.MARKET_WEAR_EDGES[wear]); high=Math.min(high,hGui.MARKET_WEAR_EDGES[wear+1]);}
    state.first=(long)Math.ceil(low*100_000_000.0);
    long last=(long)Math.floor(high*100_000_000.0);
    if(wear>=0&&wear<4&&last/100_000_000.0>=hGui.MARKET_WEAR_EDGES[wear+1])last--;
    state.capacity=last-state.first+1;
    if(state.capacity<1)throw new IllegalStateException("No valid wear interval: "+item.name);
    long seed=app.exchangeStockService.mixExchange(MarketplacePricing.variant(item).hashCode());
    state.step=Math.max(1,Math.floorMod(seed,state.capacity));
    while(gcd(state.step,state.capacity)!=1)state.step++;
    state.offset=Math.floorMod(seed>>>1,state.capacity);
  }

  private double floatAt(State state,int index) {
    if(state.noFloat)return 0;
    long ordinal=state.base+index;
    if(ordinal>=state.capacity)throw new IllegalStateException("Float precision capacity exceeded");
    return (state.first+Math.floorMod(state.offset+ordinal*state.step,state.capacity))/100_000_000.0;
  }

  private int cheapestIndex(MarketListing parent, State state) {
    if(state.cheapest>=0&&!state.consumed.get(state.cheapest))return state.cheapest;
    double largest=-1; int best=-1;
    for(int i=0;i<state.initial;i++)if(!state.consumed.get(i)) {
      double f=floatAt(state,i);
      if(f>largest){largest=f;best=i;}
    }
    return state.cheapest=best;
  }

  synchronized double floorAsk(MarketListing parent) {
    if(parent.quantity<=0)return Double.NaN;
    if(parent.isPlayerListing||app.exchangeStockService.exchangeContainer(parent.item.name)!=null)return parent.getPrice();
    State state=state(parent);int index=cheapestIndex(parent,state);
    return index<0?Double.NaN:MarketDynamics.cents(parent.getPrice()*MarketDynamics.floatPremium(parent.item.condition,floatAt(state,index),state.min,state.max));
  }

  synchronized void trimTo(MarketListing parent,int remaining){
    int target=Math.max(0,remaining);if(parent.quantity<=target)return;
    State s=state(parent);int remove=parent.quantity-target;
    for(int n=s.initial-1;n>=0&&remove>0;n--)if(!s.consumed.get(n)){
      s.consumed.set(n);remove--;
      if(Double.isFinite(s.priceSum)&&s.sumBase==parent.getPrice())s.priceSum-=MarketDynamics.cents(parent.getPrice()*MarketDynamics.floatPremium(parent.item.condition,floatAt(s,n),s.min,s.max));
    }
    parent.quantity=target;s.cheapest=-1;
  }

  synchronized double averageAsk(MarketListing parent) {
    if(parent.quantity<=0)return Double.NaN;
    if(parent.isPlayerListing||app.floatRules.hasNoFloatWear(parent.item.name)||app.exchangeStockService.exchangeContainer(parent.item.name)!=null)return parent.getPrice();
    State s=state(parent);double base=parent.getPrice();
    if(!Double.isFinite(s.priceSum)||s.sumBase!=base){
      double sum=0,largest=-1;int cheapest=-1;
      for(int n=0;n<s.initial;n++)if(!s.consumed.get(n)){
        double f=floatAt(s,n);sum+=MarketDynamics.cents(base*MarketDynamics.floatPremium(parent.item.condition,f,s.min,s.max));
        if(f>largest){largest=f;cheapest=n;}
      }
      s.priceSum=sum;s.sumBase=base;s.cheapest=cheapest;
    }
    return s.priceSum/parent.quantity;
  }

  synchronized MarketListing cheapest(MarketListing parent) {
    State state=state(parent);int index=cheapestIndex(parent,state);
    if(index<0)throw new IllegalArgumentException("No available offers");
    return unit(parent,index-state.consumed.get(0,index).cardinality());
  }

  int[] sortedPriceRanks(MarketplaceGroups.Group group, boolean ascending) {
    int count=group.units();Integer[] ranks=new Integer[count];double[] prices=new double[count];
    for(int n=0;n<count;n++){if(Thread.currentThread().isInterrupted())throw new java.util.concurrent.CancellationException();ranks[n]=n;prices[n]=at(group,n).getPrice();}
    Arrays.sort(ranks,(a,b)->{int c=Double.compare(prices[a],prices[b]);return c==0?Integer.compare(a,b):ascending?c:-c;});
    return Arrays.stream(ranks).mapToInt(Integer::intValue).toArray();
  }

  int[] sortedRanks(MarketplaceGroups.Group group, boolean ascending) {
    int count = group.units();
    long stride = Math.max(1, count);
    long[] keys = new long[count];
    for (int rank = 0; rank < count; rank++) {
      if (Thread.currentThread().isInterrupted())
        throw new java.util.concurrent.CancellationException();
      MarketListing view = at(group, rank);
      long tick = Math.round(view.item.itemFloat * 100_000_000.0);
      keys[rank] = tick * stride + rank;
    }
    Arrays.sort(keys);
    int[] order = new int[count];
    for (int n = 0; n < count; n++) order[n] = (int) (keys[ascending ? n : count - 1 - n] % stride);
    return order;
  }

  private static long gcd(long a, long b) {
    while (b != 0) {
      long x = a % b;
      a = b;
      b = x;
    }
    return a;
  }

  synchronized void consume(MarketListing view) {
    MarketListing parent = view.stockParent;
    if (parent == null || !available(view))
      throw new IllegalArgumentException("This individual offer was already sold.");
    State s=state(parent);
    if(Double.isFinite(s.priceSum)&&s.sumBase==parent.getPrice())s.priceSum-=view.getPrice();
    else s.priceSum=Double.NaN;
    s.consumed.set(view.stockIndex);
    parent.quantity--;
    view.quantity = 0;
  }

  boolean hasState(MarketListing parent) {
    return states.containsKey(parent);
  }
}
