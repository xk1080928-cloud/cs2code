package blahblah;

import blahblah.hGui.*;
import java.awt.*;
import java.awt.event.*;
import java.util.ArrayList;
import java.util.List;
import javax.swing.*;

/** Offer Neon And Mirage Screens: focused feature implementation. */
final class OfferNeonAndMirageScreens {
  private final hGui app;

  OfferNeonAndMirageScreens(hGui app) {
    this.app = app;
  }

  String buildStars(double rating) {
    StringBuilder sb = new StringBuilder();
    int full = (int) rating;
    for (int i = 0; i < 5; i++) sb.append(i < full ? "★" : "☆");
    return sb.toString();
  }

  JFrame createMarketplaceFrame(
      MarketplaceOfferAggregate offer,
      String skinName,
      String conditionToken,
      JFrame parent,
      Color bg) {
    JFrame frame = new JFrame(offer.marketplaceName + " - " + skinName);
    Dimension screen = Toolkit.getDefaultToolkit().getScreenSize();
    frame.setSize(
        Math.min(1000, Math.max(720, screen.width - 80)),
        Math.min(740, Math.max(540, screen.height - 100)));
    frame.setLocationRelativeTo(parent);
    frame.setLayout(new BorderLayout());
    frame.getContentPane().setBackground(bg);
    frame.add(
        app.marketOfferService.createMarketplaceFilterBar(
            offer, skinName, conditionToken, frame, parent),
        BorderLayout.SOUTH);
    return frame;
  }

  JButton createMarketplaceActionButton(
      MarketListing listing, MarketplaceOfferAggregate offer, JFrame parent, String text) {
    JButton button = new JButton(text);
    button.setBackground(offer.accent);
    button.setForeground(Color.WHITE);
    button.setFocusPainted(false);
    button.setFont(new Font("Arial", Font.BOLD, 12));
    button.setBorder(BorderFactory.createEmptyBorder(8, 12, 8, 12));
    button.addActionListener(
        e -> app.marketOfferService.purchaseMarketplaceListing(listing, offer, parent));
    return button;
  }

  double getLowestMarketplacePriceForItem(InventoryItem item, String marketplaceName) {
    if (item == null || marketplaceName == null || marketplaceName.trim().isEmpty()) return 0.0;
    String marketKey =
        app.leaderboardService.normalizeSkinName((item.isStattrak ? "StatTrak " : "") + item.name);
    ArrayList<MarketListing> listings = app.globalMarketListings.get(marketKey);
    if (listings == null || listings.isEmpty()) return 0.0;
    return listings.stream()
        .filter(listing -> !listing.isPlayerListing)
        .filter(listing -> marketplaceName.equals(listing.marketplaceName))
        .filter(listing -> item.condition.equals(listing.item.condition))
        .mapToDouble(listing -> listing.getPrice())
        .min()
        .orElse(0.0);
  }

  void showMarketplaceOfferWindowNeonGrid(
      String skinName, String conditionToken, MarketplaceOfferAggregate offer, JFrame parent) {
    JFrame frame =
        app.offerNeonAndMirageScreens.createMarketplaceFrame(
            offer, skinName, conditionToken, parent, new Color(6, 8, 16));
    frame.add(
        app.offerHeroAndSellerScreens.createOfferHeader(
            offer.marketplaceName + " Neon Grid",
            skinName + "  ·  reactive offer matrix",
            offer,
            "◈ LIVE NEON"),
        BorderLayout.NORTH);

    JPanel grid = new JPanel(new GridLayout(0, 2, 2, 2));
    grid.setBackground(new Color(2, 4, 10));
    grid.setBorder(BorderFactory.createEmptyBorder(2, 2, 2, 2));

    List<MarketListing> sorted = app.marketOfferService.getSortedOfferListings(offer);
    Color[] neonPalette = {
      new Color(0, 240, 255), // cyan
      new Color(255, 0, 200), // magenta
      new Color(80, 255, 120), // green
      new Color(255, 200, 0), // yellow
    };

    for (int i = 0; i < sorted.size(); i++) {
      Color neon = neonPalette[i % neonPalette.length];
      grid.add(app.offerNeonAndMirageScreens.createNeonCard(sorted.get(i), offer, frame, neon));
    }

    JScrollPane scroll = new JScrollPane(grid);
    scroll.setBorder(null);
    scroll.getViewport().setBackground(new Color(2, 4, 10));
    scroll.getVerticalScrollBar().setUnitIncrement(20);
    frame.add(scroll, BorderLayout.CENTER);
    frame.setVisible(true);
  }

  JPanel createNeonCard(
      MarketListing listing, MarketplaceOfferAggregate offer, JFrame parent, Color neon) {
    JPanel card = new JPanel(new BorderLayout(0, 10));
    card.setBackground(new Color(10, 12, 22));
    card.setBorder(
        BorderFactory.createCompoundBorder(
            BorderFactory.createLineBorder(neon, 1),
            BorderFactory.createEmptyBorder(16, 16, 16, 16)));

    JLabel price = new JLabel("$" + String.format("%.2f", listing.getPrice()));
    price.setFont(new Font("Consolas", Font.BOLD, 28));
    price.setForeground(neon);

    JLabel seller = new JLabel(listing.sellerName != null ? listing.sellerName : "Seller");
    seller.setFont(new Font("Arial", Font.BOLD, 13));
    seller.setForeground(Color.WHITE);

    JLabel info =
        new JLabel(
            app.itemMetadataService.isAgentSkin(listing.item.name)
                ? "Agent"
                : ("<html>Float: "
                    + String.format("%.6f", listing.item.itemFloat)
                    + "<br>Pattern: "
                    + app.marketOfferService.formatMarketPatternText(listing)
                    + "</html>"));
    info.setFont(new Font("Consolas", Font.PLAIN, 11));
    info.setForeground(new Color(neon.getRed(), neon.getGreen(), neon.getBlue(), 180));

    JButton btn =
        app.offerNeonAndMirageScreens.createMarketplaceActionButton(
            listing, offer, parent, "ACQUIRE");
    btn.setBackground(new Color(neon.getRed() / 10, neon.getGreen() / 10, neon.getBlue() / 10));
    btn.setForeground(neon);
    btn.setBorder(BorderFactory.createLineBorder(neon, 1));
    btn.setFont(new Font("Arial", Font.BOLD, 12));

    JPanel info2 = new JPanel(new GridLayout(3, 1, 0, 4));
    info2.setOpaque(false);
    info2.add(seller);
    info2.add(info);
    info2.add(btn);

    card.add(price, BorderLayout.NORTH);
    card.add(info2, BorderLayout.CENTER);
    return card;
  }

  void showMarketplaceOfferWindowMirageRun(
      String skinName, String conditionToken, MarketplaceOfferAggregate offer, JFrame parent) {
    JFrame frame =
        app.offerNeonAndMirageScreens.createMarketplaceFrame(
            offer, skinName, conditionToken, parent, new Color(24, 18, 10));
    frame.add(
        app.offerHeroAndSellerScreens.createOfferHeader(
            offer.marketplaceName + " Mirage Run",
            conditionToken + "  ·  mission runbook",
            offer,
            "▷ P2P ROUTE"),
        BorderLayout.NORTH);

    ArrayList<MarketListing> sorted = app.marketOfferService.getSortedOfferListings(offer);

    JPanel rail = new JPanel();
    rail.setLayout(new BoxLayout(rail, BoxLayout.Y_AXIS));
    rail.setBackground(new Color(24, 18, 10));
    rail.setBorder(BorderFactory.createEmptyBorder(16, 20, 16, 20));

    // Mission header bar
    JPanel missionHdr = new JPanel(new BorderLayout());
    missionHdr.setBackground(new Color(36, 28, 14));
    missionHdr.setBorder(
        BorderFactory.createCompoundBorder(
            BorderFactory.createMatteBorder(0, 0, 2, 0, offer.accent),
            BorderFactory.createEmptyBorder(8, 14, 8, 14)));
    JLabel hdrLbl =
        new JLabel(
            "OPERATION: ACQUIRE  ·  "
                + sorted.size()
                + " TARGETS  ·  OBJECTIVE: "
                + skinName.toUpperCase());
    hdrLbl.setFont(new Font("Consolas", Font.BOLD, 12));
    hdrLbl.setForeground(offer.accent);
    missionHdr.add(hdrLbl, BorderLayout.CENTER);
    rail.add(missionHdr);
    rail.add(Box.createRigidArea(new Dimension(0, 12)));

    int idx = 1;
    for (MarketListing listing : sorted) {
      rail.add(app.offerNeonAndMirageScreens.createMirageRow(idx++, listing, offer, frame));
      rail.add(Box.createRigidArea(new Dimension(0, 6)));
    }

    JScrollPane scroll = new JScrollPane(rail);
    scroll.setBorder(null);
    scroll.getViewport().setBackground(new Color(24, 18, 10));
    scroll.getVerticalScrollBar().setUnitIncrement(20);
    frame.add(scroll, BorderLayout.CENTER);
    frame.setVisible(true);
  }

  JPanel createMirageRow(
      int rank, MarketListing listing, MarketplaceOfferAggregate offer, JFrame parent) {
    JPanel row = new JPanel(new BorderLayout(12, 0));
    row.setBackground(new Color(32, 24, 12));
    row.setMaximumSize(new Dimension(Integer.MAX_VALUE, 50));
    row.setBorder(
        BorderFactory.createCompoundBorder(
            BorderFactory.createMatteBorder(0, 3, 0, 0, new Color(160, 120, 40)),
            BorderFactory.createEmptyBorder(10, 14, 10, 14)));

    JLabel rankLbl = new JLabel(String.format("T%02d", rank));
    rankLbl.setFont(new Font("Consolas", Font.BOLD, 14));
    rankLbl.setForeground(offer.accent);
    rankLbl.setPreferredSize(new Dimension(40, 0));

    JLabel info =
        new JLabel(
            "["
                + (listing.sellerName != null ? listing.sellerName : "UNKNOWN")
                + "]"
                + (app.itemMetadataService.isAgentSkin(listing.item.name)
                    ? ""
                    : ("   FLOAT: "
                        + String.format("%.6f", listing.item.itemFloat)
                        + "   PAT: "
                        + app.marketOfferService.formatMarketPatternText(listing))));
    info.setFont(new Font("Consolas", Font.PLAIN, 12));
    info.setForeground(new Color(200, 170, 100));

    JPanel right = new JPanel(new BorderLayout(8, 0));
    right.setOpaque(false);
    JLabel price = new JLabel("$" + String.format("%.2f", listing.getPrice()));
    price.setFont(new Font("Consolas", Font.BOLD, 16));
    price.setForeground(offer.accent);
    price.setHorizontalAlignment(SwingConstants.RIGHT);
    JButton btn =
        app.offerNeonAndMirageScreens.createMarketplaceActionButton(
            listing, offer, parent, "EXTRACT");
    btn.setPreferredSize(new Dimension(90, 32));
    right.add(price, BorderLayout.CENTER);
    right.add(btn, BorderLayout.EAST);

    row.add(rankLbl, BorderLayout.WEST);
    row.add(info, BorderLayout.CENTER);
    row.add(right, BorderLayout.EAST);
    return row;
  }
}
