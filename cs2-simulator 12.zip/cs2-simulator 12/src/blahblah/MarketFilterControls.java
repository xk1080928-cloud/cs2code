package blahblah;

import blahblah.hGui.*;
import java.awt.*;
import java.awt.event.*;
import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.Map;
import javax.swing.*;

/** Market Filter Controls: focused feature implementation. */
final class MarketFilterControls {
  private final hGui app;

  MarketFilterControls(hGui app) {
    this.app = app;
  }

  void installEnterSearchHandler(JComboBox<String> searchBox, Runnable updateAction) {
    JTextField editor = app.searchControls.getSearchEditor(searchBox);
    if (editor != null) {
      editor.addActionListener(
          e -> {
            app.searchControls.commitSearchQuery(searchBox);
            updateAction.run();
          });
    }
    searchBox.addActionListener(
        e -> {
          if (Boolean.TRUE.equals(searchBox.getClientProperty("searchHistorySyncing"))) {
            return;
          }
          Object selected = searchBox.getSelectedItem();
          if (selected != null && !selected.toString().trim().isEmpty()) {
            app.searchControls.commitSearchQuery(searchBox);
            updateAction.run();
          }
        });
  }

  String[] concatMenuItems(String[] prefix, String[] values) {
    if (values == null) values = new String[0];
    String[] result = new String[prefix.length + values.length];
    System.arraycopy(prefix, 0, result, 0, prefix.length);
    System.arraycopy(values, 0, result, prefix.length, values.length);
    return result;
  }

  JPopupMenu buildMarketplaceSelectionMenu(
      String group,
      String[] items,
      String[] selectedGroup,
      String[] selectedWeapon,
      Runnable rebuildGrid,
      int maxHeight) {
    Color bg = new Color(30, 38, 54);
    JPopupMenu menu = new JPopupMenu();
    menu.setLayout(new BorderLayout());
    menu.setBorder(BorderFactory.createLineBorder(Theme.ACCENT_CT, 1));
    JPanel panel = new JPanel(new BorderLayout(0, 6));
    panel.setBackground(bg);
    panel.setBorder(BorderFactory.createEmptyBorder(8, 8, 8, 8));
    JPanel heading = new JPanel(new BorderLayout(0, 5));
    heading.setOpaque(false);
    JLabel label = new JLabel("Search " + group.toLowerCase(java.util.Locale.ROOT));
    label.setForeground(Color.LIGHT_GRAY);
    JTextField search = new JTextField();
    search.setBackground(new Color(43, 54, 73));
    search.setForeground(Color.WHITE);
    search.setCaretColor(Color.WHITE);
    search.setBorder(
        BorderFactory.createCompoundBorder(
            BorderFactory.createLineBorder(new Color(75, 91, 119)),
            BorderFactory.createEmptyBorder(5, 7, 5, 7)));
    search.setToolTipText("Type to filter; Down to browse; Enter to select; Escape to close");
    search.getAccessibleContext().setAccessibleName("Search " + group);
    heading.add(label, BorderLayout.NORTH);
    heading.add(search, BorderLayout.CENTER);
    panel.add(heading, BorderLayout.NORTH);
    DefaultListModel<String> model = new DefaultListModel<>();
    JList<String> list = new JList<>(model);
    list.setBackground(bg);
    list.setForeground(Color.WHITE);
    list.setSelectionBackground(new Color(61, 83, 116));
    list.setSelectionForeground(Color.WHITE);
    list.setSelectionMode(ListSelectionModel.SINGLE_SELECTION);
    list.setFixedCellHeight(28);
    list.getAccessibleContext().setAccessibleName(group + " options");
    JScrollPane scroll =
        new JScrollPane(
            list, JScrollPane.VERTICAL_SCROLLBAR_AS_NEEDED, JScrollPane.HORIZONTAL_SCROLLBAR_NEVER);
    scroll.setBorder(BorderFactory.createEmptyBorder());
    scroll.getVerticalScrollBar().setUnitIncrement(28);
    panel.add(scroll, BorderLayout.CENTER);
    JLabel count = new JLabel();
    count.setForeground(Color.LIGHT_GRAY);
    panel.add(count, BorderLayout.SOUTH);
    Runnable filter =
        () -> {
          String query = search.getText().trim().toLowerCase(java.util.Locale.ROOT);
          model.clear();
          for (String item : items)
            if (item.toLowerCase(java.util.Locale.ROOT).contains(query)) model.addElement(item);
          String current = group.equals(selectedGroup[0]) ? selectedWeapon[0] : null;
          if (current != null && model.contains(current)) list.setSelectedValue(current, true);
          else if (!model.isEmpty()) list.setSelectedIndex(0);
          if (list.getSelectedIndex() >= 0) list.ensureIndexIsVisible(list.getSelectedIndex());
          count.setText(
              model.isEmpty()
                  ? "No matching options"
                  : model.size() + " options  |  Enter to select");
        };
    search
        .getDocument()
        .addDocumentListener(
            new javax.swing.event.DocumentListener() {
              public void insertUpdate(javax.swing.event.DocumentEvent e) {
                filter.run();
              }

              public void removeUpdate(javax.swing.event.DocumentEvent e) {
                filter.run();
              }

              public void changedUpdate(javax.swing.event.DocumentEvent e) {
                filter.run();
              }
            });
    Runnable choose =
        () -> {
          String value = list.getSelectedValue();
          if (value == null) return;
          selectedGroup[0] = group;
          selectedWeapon[0] = value;
          menu.setVisible(false);
          rebuildGrid.run();
        };
    search.addActionListener(e -> choose.run());
    list.getInputMap().put(KeyStroke.getKeyStroke("ENTER"), "chooseOption");
    list.getActionMap()
        .put(
            "chooseOption",
            new AbstractAction() {
              public void actionPerformed(ActionEvent e) {
                choose.run();
              }
            });
    search.getInputMap().put(KeyStroke.getKeyStroke("DOWN"), "browseOptions");
    search
        .getActionMap()
        .put(
            "browseOptions",
            new AbstractAction() {
              public void actionPerformed(ActionEvent e) {
                if (!model.isEmpty()) list.requestFocusInWindow();
              }
            });
    panel
        .getInputMap(JComponent.WHEN_ANCESTOR_OF_FOCUSED_COMPONENT)
        .put(KeyStroke.getKeyStroke("ESCAPE"), "closeOptions");
    panel
        .getActionMap()
        .put(
            "closeOptions",
            new AbstractAction() {
              public void actionPerformed(ActionEvent e) {
                menu.setVisible(false);
              }
            });
    list.addMouseListener(
        new MouseAdapter() {
          public void mouseClicked(MouseEvent e) {
            int index = list.locationToIndex(e.getPoint());
            if (SwingUtilities.isLeftMouseButton(e)
                && index >= 0
                && list.getCellBounds(index, index).contains(e.getPoint())) {
              list.setSelectedIndex(index);
              choose.run();
            }
          }
        });
    menu.add(panel, BorderLayout.CENTER);
    int width = 320;
    for (String item : items)
      width = Math.max(width, list.getFontMetrics(list.getFont()).stringWidth(item) + 56);
    menu.setPreferredSize(
        new Dimension(
            Math.min(460, width),
            Math.min(Math.max(130, maxHeight), Math.min(460, 100 + items.length * 28))));
    menu.addPopupMenuListener(
        new javax.swing.event.PopupMenuListener() {
          public void popupMenuWillBecomeVisible(javax.swing.event.PopupMenuEvent e) {
            SwingUtilities.invokeLater(() -> search.requestFocusInWindow());
          }

          public void popupMenuWillBecomeInvisible(javax.swing.event.PopupMenuEvent e) {}

          public void popupMenuCanceled(javax.swing.event.PopupMenuEvent e) {}
        });
    filter.run();
    return menu;
  }

  void showMarketplaceSelectionMenu(
      JButton source,
      String group,
      String[] items,
      String[] selectedGroup,
      String[] selectedWeapon,
      Runnable rebuildGrid) {
    GraphicsConfiguration config = source.getGraphicsConfiguration();
    Rectangle screen = config.getBounds();
    Insets insets = Toolkit.getDefaultToolkit().getScreenInsets(config);
    Point anchor = source.getLocationOnScreen();
    int below = screen.y + screen.height - insets.bottom - anchor.y - source.getHeight() - 8;
    int above = anchor.y - screen.y - insets.top - 8;
    JPopupMenu menu =
        app.marketFilterControls.buildMarketplaceSelectionMenu(
            group, items, selectedGroup, selectedWeapon, rebuildGrid, Math.max(above, below));
    Dimension preferred = menu.getPreferredSize();
    preferred.width =
        Math.min(preferred.width, Math.max(120, screen.width - insets.left - insets.right - 16));
    menu.setPreferredSize(preferred);
    menu.show(source, 0, below >= preferred.height ? source.getHeight() : -preferred.height);
  }

  Map<String, String[]> createMarketplaceCategoryMenus() {
    LinkedHashMap<String, String[]> menus = new LinkedHashMap<>();
    java.util.Set<String> knifeTypes = new java.util.TreeSet<>();
    java.util.Set<String> gloveTypes = new java.util.TreeSet<>();
    for (String skinName : app.marketGroupingService.buildGroupedMarketListings().keySet()) {
      String rarity = app.itemMetadataService.getSkinRarity(skinName);
      String weaponType = app.marketFilterControls.extractWeaponType(skinName);
      if ("Knife".equals(rarity)) knifeTypes.add(weaponType);
      if ("Gloves".equals(rarity)) gloveTypes.add(weaponType);
    }
    menus.put("Knives", knifeTypes.toArray(new String[0]));
    menus.put("Gloves", gloveTypes.toArray(new String[0]));
    return menus;
  }

  String[] getMarketplaceCollectionMenuItems() {
    java.util.Set<String> collections = new java.util.TreeSet<>();
    for (String skinName : app.marketGroupingService.buildGroupedMarketListings().keySet()) {
      String collectionName = app.collectionService.getCollectionName(skinName);
      if (collectionName != null && !collectionName.trim().isEmpty()) {
        collections.add(app.marketCatalogService.canonicalMarketCollectionName(collectionName));
      }
    }
    collections.addAll(app.requestedMarketCollections.keySet());

    return app.marketFilterControls.concatMenuItems(
        new String[] {"All Collections"}, collections.toArray(new String[0]));
  }

  JButton createMarketplaceNavButton(String label) {
    JButton button = new JButton(label + "  v");
    button.setFont(new Font("Arial", Font.PLAIN, 13));
    button.setForeground(new Color(235, 238, 245));
    button.setBackground(new Color(31, 40, 56));
    button.setBorder(BorderFactory.createEmptyBorder(6, 4, 6, 4));
    button.setFocusPainted(false);
    button.setContentAreaFilled(false);
    button.setCursor(new Cursor(Cursor.HAND_CURSOR));
    return button;
  }

  java.util.List<Map.Entry<String, ArrayList<MarketListing>>> collectMarketplaceEntries(
      String selectedGroup, String selectedWeapon, String search, String sortMode) {
    java.util.List<Map.Entry<String, ArrayList<MarketListing>>> entries =
        new ArrayList<>(app.marketGroupingService.buildGroupedMarketListings().entrySet());
    final String normalizedSearch = search == null ? "" : search.toLowerCase();
    entries.removeIf(
        entry -> {
          String skinName = entry.getKey();
          String rarity = app.itemMetadataService.getSkinRarity(skinName);
          String weapon = app.marketFilterControls.extractWeaponType(skinName);
          boolean keep;
          switch (selectedGroup) {
            case "Containers":
              CaseType container = app.exchangeStockService.exchangeContainer(skinName);
              keep =
                  container != null
                      && (selectedWeapon == null
                          || "All Containers".equals(selectedWeapon)
                          || "Cases".equals(selectedWeapon)
                              && !container.isSouvenir
                              && !container.isTerminal
                          || "Souvenir Packages".equals(selectedWeapon) && container.isSouvenir
                          || "Terminals".equals(selectedWeapon) && container.isTerminal
                          || container.catalogCrateName().equals(selectedWeapon));
              break;
            case "Pistols":
            case "Mid-Tier":
            case "Rifles":
              keep = selectedWeapon != null && selectedWeapon.equals(weapon);
              break;
            case "Knives":
              keep =
                  "Knife".equals(rarity)
                      && (selectedWeapon == null
                          || "All Knives".equals(selectedWeapon)
                          || selectedWeapon.equals(weapon));
              break;
            case "Gloves":
              keep =
                  "Gloves".equals(rarity)
                      && (selectedWeapon == null
                          || "All Gloves".equals(selectedWeapon)
                          || selectedWeapon.equals(weapon));
              break;
            case "Collections":
              String collectionName = app.collectionService.getCollectionName(skinName);
              keep =
                  (collectionName != null
                          || app.requestedMarketSkinCollections.containsKey(
                              app.marketCatalogService.marketCollectionSkinKey(skinName)))
                      && (selectedWeapon == null
                          || "All Collections".equals(selectedWeapon)
                          || app.marketCatalogService.belongsToMarketplaceCollection(
                              skinName, selectedWeapon));
              break;
            default:
              keep = true;
          }
          if (!normalizedSearch.isEmpty()) {
            keep = keep && skinName.toLowerCase().contains(normalizedSearch);
          }
          return !keep || entry.getValue().isEmpty();
        });
    entries.sort(
        (a, b) -> {
          double aMin =
              a.getValue().stream().mapToDouble(l -> l.getPrice()).min().orElse(Double.MAX_VALUE);
          double bMin =
              b.getValue().stream().mapToDouble(l -> l.getPrice()).min().orElse(Double.MAX_VALUE);
          String aCollection = app.collectionService.getCollectionName(a.getKey());
          String bCollection = app.collectionService.getCollectionName(b.getKey());
          if ("Highest Price".equals(sortMode)) {
            int highCompare = Double.compare(bMin, aMin);
            if (highCompare != 0) return highCompare;
          } else if ("Name".equals(sortMode)) {
            int nameCompare = a.getKey().compareToIgnoreCase(b.getKey());
            if (nameCompare != 0) return nameCompare;
          } else if ("Collection".equals(sortMode)) {
            int collectionCompare =
                String.valueOf(aCollection).compareToIgnoreCase(String.valueOf(bCollection));
            if (collectionCompare != 0) return collectionCompare;
            int withinCollection = a.getKey().compareToIgnoreCase(b.getKey());
            if (withinCollection != 0) return withinCollection;
          } else {
            int priceCompare = Double.compare(aMin, bMin);
            if (priceCompare != 0) return priceCompare;
          }
          int fallbackPrice = Double.compare(aMin, bMin);
          if (fallbackPrice != 0) return fallbackPrice;
          return a.getKey().compareToIgnoreCase(b.getKey());
        });
    return entries;
  }

  int countDistinctMarketplaces(ArrayList<MarketListing> listings) {
    java.util.Set<String> markets = new java.util.HashSet<>();
    for (MarketListing listing : listings) {
      if (listing.marketplaceName != null) {
        markets.add(listing.marketplaceName);
      }
    }
    return markets.size();
  }

  String extractWeaponType(String skinName) {
    skinName =
        skinName.replace("StatTrak ", "").replace("StatTrak ", "").replace("* StatTrak ", "");

    if (skinName.contains("Bloodhound Gloves")) return "Bloodhound Gloves";
    if (skinName.contains("Driver Gloves")) return "Driver Gloves";
    if (skinName.contains("Hand Wraps")) return "Hand Wraps";
    if (skinName.contains("Moto Gloves")) return "Moto Gloves";
    if (skinName.contains("Specialist Gloves")) return "Specialist Gloves";
    if (skinName.contains("Sport Gloves")) return "Sport Gloves";

    if (skinName.contains("|")) {
      String weaponType = skinName.split("\\|")[0].trim();
      return weaponType;
    }

    if (skinName.contains("Karambit")) return "Karambit";
    if (skinName.contains("M9 Bayonet")) return "M9 Bayonet";
    if (skinName.contains("Bayonet")) return "Bayonet";
    if (skinName.contains("Butterfly Knife")) return "Butterfly Knife";
    if (skinName.contains("Flip Knife")) return "Flip Knife";
    if (skinName.contains("Gut Knife")) return "Gut Knife";

    return skinName;
  }
}
