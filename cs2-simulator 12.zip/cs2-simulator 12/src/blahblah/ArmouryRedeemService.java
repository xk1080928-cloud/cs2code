package blahblah;

import blahblah.hGui.*;
import java.awt.*;
import java.awt.event.*;
import javax.swing.*;

/** Armoury Redeem Service: focused feature implementation. */
final class ArmouryRedeemService {
  private final hGui app;

  ArmouryRedeemService(hGui app) {
    this.app = app;
  }

  void attemptArmouryRedeem(
      ArmouryCollection col, JLabel starsDisplay, JButton redeemBtn, boolean autoMode) {
    if (app.armouryAnimating || (app.cs2ShellEnabled && autoMode)) return;
    if (col.name.contains("Achroma")) return;
    int cost = app.itemMetadataService.getArmouryRedeemCost(col);
    if (app.playerStars < cost) {
      if (!autoMode) {
        JOptionPane.showMessageDialog(
            null,
            "You need " + cost + " Stars to redeem! Complete missions to earn Stars.",
            "Not Enough Stars",
            JOptionPane.WARNING_MESSAGE);
      }
      app.containerBrowserScreen.stopArmouryAutoOpen();
      return;
    }
    app.playerStars -= cost;
    app.missionService.updateStarsLabel();
    if (starsDisplay != null) starsDisplay.setText("* " + app.playerStars + " Stars");
    app.missionProgress.armouryRedeems++;
    app.missionService.checkArmouryAchievements();
    app.missionService.checkMissionProgress();

    double[] rarityWeights;
    String[][] tierFiles;
    String[][] tierNames;
    double[][] tierPrices;
    String[] tierRarities;
    int maxTier;
    if (col.isAgents) {
      rarityWeights = app.itemMetadataService.getArmouryRarityWeights(col);
      tierFiles = new String[][] {col.covert, col.classified, col.restricted, col.milspec};
      tierNames =
          new String[][] {
            col.covertNames, col.classifiedNames, col.restrictedNames, col.milspecNames
          };
      tierPrices =
          new double[][] {
            col.covertPrices, col.classifiedPrices, col.restrictedPrices, col.milspecPrices
          };
      tierRarities = new String[] {"Master", "Superior", "Exceptional", "Distinguished"};
      maxTier = 3;
    } else if (col.consumer == null || col.consumer.length == 0) {
      rarityWeights = app.itemMetadataService.getArmouryRarityWeights(col);
      tierFiles =
          new String[][] {col.covert, col.classified, col.restricted, col.milspec, col.industrial};
      tierNames =
          new String[][] {
            col.covertNames,
            col.classifiedNames,
            col.restrictedNames,
            col.milspecNames,
            col.industrialNames
          };
      tierPrices =
          new double[][] {
            col.covertPrices,
            col.classifiedPrices,
            col.restrictedPrices,
            col.milspecPrices,
            col.industrialPrices
          };
      tierRarities = new String[] {"Covert", "Classified", "Restricted", "Milspec", "Industrial"};
      maxTier = 4;
    } else {
      rarityWeights = app.itemMetadataService.getArmouryRarityWeights(col);
      tierFiles =
          new String[][] {
            col.covert, col.classified, col.restricted, col.milspec, col.industrial, col.consumer
          };
      tierNames =
          new String[][] {
            col.covertNames,
            col.classifiedNames,
            col.restrictedNames,
            col.milspecNames,
            col.industrialNames,
            col.consumerNames
          };
      tierPrices =
          new double[][] {
            col.covertPrices,
            col.classifiedPrices,
            col.restrictedPrices,
            col.milspecPrices,
            col.industrialPrices,
            col.consumerPrices
          };
      tierRarities =
          new String[] {"Covert", "Classified", "Restricted", "Milspec", "Industrial", "Consumer"};
      maxTier = 5;
    }
    double roll = hGui.random.nextDouble();
    double cumulative = 0.0;
    int chosenTier = maxTier;
    for (int ti = 0; ti < rarityWeights.length; ti++) {
      cumulative += rarityWeights[ti];
      if (roll < cumulative && tierFiles[ti] != null && tierFiles[ti].length > 0) {
        chosenTier = ti;
        break;
      }
    }
    while (chosenTier < maxTier
        && (tierFiles[chosenTier] == null || tierFiles[chosenTier].length == 0)) chosenTier++;
    int skinIdx = hGui.random.nextInt(tierFiles[chosenTier].length);
    String chosenFile = tierFiles[chosenTier][skinIdx] + ".png";
    String chosenName = tierNames[chosenTier][skinIdx];
    double chosenPrice = tierPrices[chosenTier][skinIdx];
    if (app.marketCatalogService.usesCatalogArmouryArtwork(col))
      chosenPrice = app.itemPriceService.getBasePrice(chosenName);
    String chosenRarity = tierRarities[chosenTier];
    if (redeemBtn != null) redeemBtn.setEnabled(false);
    app.armouryAnimationScreen.performArmouryRedeem(
        col,
        chosenName,
        chosenRarity,
        chosenPrice,
        chosenFile,
        redeemBtn,
        autoMode ? 5.0 : 1.0,
        autoMode);
  }

  Image resolveArmouryArtwork(ArmouryCollection col, String fileKey) {
    String[][] files = {
      col.consumer, col.industrial, col.milspec, col.restricted, col.classified, col.covert
    };
    String[][] names = {
      col.consumerNames,
      col.industrialNames,
      col.milspecNames,
      col.restrictedNames,
      col.classifiedNames,
      col.covertNames
    };
    for (int t = 0; t < files.length; t++) {
      if (files[t] == null || names[t] == null) continue;
      for (int i = 0; i < files[t].length; i++) {
        if (!fileKey.equals(files[t][i])) continue;
        Image image = app.artworkService.getSkinImageFromName(names[t][i]);
        return image != null ? image : app.containerBrowserScreen.createItemPlaceholderImage();
      }
    }
    return app.containerBrowserScreen.createItemPlaceholderImage();
  }

  java.util.List<StripItem> getArmouryAnimationPool(ArmouryCollection col) {
    String cacheKey = col.name + "|" + col.isAgents;
    java.util.List<StripItem> cached = app.armouryAnimationPoolCache.get(cacheKey);
    if (cached != null && !cached.isEmpty()) return cached;

    String[][] wFiles =
        col.isAgents
            ? new String[][] {col.milspec, col.restricted, col.classified, col.covert}
            : new String[][] {
              col.consumer, col.industrial, col.milspec, col.restricted, col.classified, col.covert
            };
    Color[] wColors =
        col.isAgents
            ? new Color[] {
              Theme.RARITY_MILSPEC,
              Theme.RARITY_RESTRICTED,
              Theme.RARITY_CLASSIFIED,
              Theme.RARITY_COVERT
            }
            : new Color[] {
              new Color(175, 175, 175),
              new Color(110, 190, 110),
              Theme.RARITY_MILSPEC,
              Theme.RARITY_RESTRICTED,
              Theme.RARITY_CLASSIFIED,
              Theme.RARITY_COVERT
            };
    int[] wCounts = col.isAgents ? new int[] {80, 16, 3, 1} : new int[] {80, 16, 3, 1, 1, 1};

    java.util.List<StripItem> pool = new java.util.ArrayList<>();
    for (int wi = 0; wi < wFiles.length; wi++) {
      if (wFiles[wi] == null || wFiles[wi].length == 0) continue;
      for (int wc = 0; wc < wCounts[wi]; wc++) {
        int pick = hGui.random.nextInt(wFiles[wi].length);
        pool.add(
            new StripItem(
                app.armouryRedeemService.resolveArmouryArtwork(col, wFiles[wi][pick]),
                wColors[wi]));
      }
    }
    if (pool.isEmpty()) {
      for (Image img : app.blueSkins) pool.add(new StripItem(img, Theme.RARITY_MILSPEC));
    }
    app.armouryAnimationPoolCache.put(cacheKey, pool);
    return pool;
  }

  StripItem rollArmouryAnimationItem(ArmouryCollection col) {
    String[][] tierFiles;
    Color[] tierColors;
    if (col.isAgents) {
      tierFiles = new String[][] {col.covert, col.classified, col.restricted, col.milspec};
      tierColors =
          new Color[] {
            Theme.RARITY_COVERT,
            Theme.RARITY_CLASSIFIED,
            Theme.RARITY_RESTRICTED,
            Theme.RARITY_MILSPEC
          };
    } else if (col.consumer == null || col.consumer.length == 0) {
      tierFiles =
          new String[][] {col.covert, col.classified, col.restricted, col.milspec, col.industrial};
      tierColors =
          new Color[] {
            Theme.RARITY_COVERT,
            Theme.RARITY_CLASSIFIED,
            Theme.RARITY_RESTRICTED,
            Theme.RARITY_MILSPEC,
            new Color(110, 190, 110)
          };
    } else {
      tierFiles =
          new String[][] {
            col.covert, col.classified, col.restricted, col.milspec, col.industrial, col.consumer
          };
      tierColors =
          new Color[] {
            Theme.RARITY_COVERT,
            Theme.RARITY_CLASSIFIED,
            Theme.RARITY_RESTRICTED,
            Theme.RARITY_MILSPEC,
            new Color(110, 190, 110),
            new Color(175, 175, 175)
          };
    }

    double[] weights = app.itemMetadataService.getArmouryRarityWeights(col);
    double roll = hGui.random.nextDouble();
    double cumulative = 0.0;
    int selectedTier = tierFiles.length - 1;
    for (int i = 0; i < tierFiles.length; i++) {
      cumulative += weights[i];
      if (roll < cumulative && tierFiles[i] != null && tierFiles[i].length > 0) {
        selectedTier = i;
        break;
      }
    }
    while (selectedTier < tierFiles.length - 1
        && (tierFiles[selectedTier] == null || tierFiles[selectedTier].length == 0)) {
      selectedTier++;
    }
    if (tierFiles[selectedTier] == null || tierFiles[selectedTier].length == 0) {
      return new StripItem(
          app.containerBrowserScreen.createItemPlaceholderImage(), Theme.RARITY_MILSPEC);
    }
    String file = tierFiles[selectedTier][hGui.random.nextInt(tierFiles[selectedTier].length)];
    return new StripItem(
        app.armouryRedeemService.resolveArmouryArtwork(col, file), tierColors[selectedTier]);
  }
}
