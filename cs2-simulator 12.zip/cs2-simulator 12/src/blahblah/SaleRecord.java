package blahblah;

import blahblah.hGui.*;
import java.awt.*;
import java.awt.event.*;
import javax.swing.*;

/** Extracted reusable model or widget; behavior retained from the original source. */
public class SaleRecord {
  boolean simulatedMarketSale;
  double price;
  long timestamp;
  String condition;
  double itemFloat;
  String skinName;
  String specialVariant;
  String buyerName;
  Image buyerAvatar;
  String marketplaceName;

  public SaleRecord(double price, long timestamp, String condition, double itemFloat) {
    this.price = price;
    this.timestamp = timestamp;
    this.condition = condition;
    this.itemFloat = itemFloat;
  }

  public SaleRecord(
      String skinName, double price, String condition, double itemFloat, String specialVariant) {
    this.skinName = skinName;
    this.price = price;
    this.condition = condition;
    this.itemFloat = itemFloat;
    this.specialVariant = specialVariant;
    this.timestamp = System.currentTimeMillis();
    this.buyerName = generateRandomUsername();
    this.buyerAvatar = generateRandomAvatar();
  }

  static String generateRandomUsername() {
    return hGui.NPC_USERNAMES[hGui.random.nextInt(hGui.NPC_USERNAMES.length)];
  }

  static Image generateRandomAvatar() {
    return hGui.NPC_AVATAR_POOL[hGui.random.nextInt(hGui.NPC_AVATAR_POOL.length)];
  }
}
