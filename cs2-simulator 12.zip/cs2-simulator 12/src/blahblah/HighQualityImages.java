package blahblah;

import java.awt.*;
import java.awt.image.*;

/** Lossless-source, device-scale-aware display derivatives; never manufactures skin detail. */
final class HighQualityImages {
  static Image fit(Image source, int maxWidth, int maxHeight) {
    int sw = source.getWidth(null), sh = source.getHeight(null);
    if (sw <= 0 || sh <= 0) return source;
    double scale =
        Math.min(Math.max(1, maxWidth) / (double) sw, Math.max(1, maxHeight) / (double) sh);
    int w = Math.max(1, (int) (sw * scale)), h = Math.max(1, (int) (sh * scale));
    BufferedImage base = resample(source, w, h);
    if (sw >= 2 * w && sh >= 2 * h)
      return new BaseMultiResolutionImage(base, resample(source, w * 2, h * 2));
    return base;
  }

  static Image canvas(Image source, int w, int h) {
    BufferedImage base = centered(source, w, h);
    if (source.getWidth(null) >= w * 2 && source.getHeight(null) >= h * 2)
      return new BaseMultiResolutionImage(base, centered(source, w * 2, h * 2));
    return base;
  }

  private static BufferedImage centered(Image source, int w, int h) {
    BufferedImage out = new BufferedImage(w, h, BufferedImage.TYPE_INT_ARGB);
    Image fitted = fit(source, w, h);
    Graphics2D g = out.createGraphics();
    g.drawImage(fitted, (w - fitted.getWidth(null)) / 2, (h - fitted.getHeight(null)) / 2, null);
    g.dispose();
    return out;
  }

  static BufferedImage resample(Image source, int w, int h) {
    BufferedImage result = new BufferedImage(w, h, BufferedImage.TYPE_INT_ARGB);
    Graphics2D g = result.createGraphics();
    g.setRenderingHint(
        RenderingHints.KEY_INTERPOLATION, RenderingHints.VALUE_INTERPOLATION_BICUBIC);
    g.setRenderingHint(RenderingHints.KEY_RENDERING, RenderingHints.VALUE_RENDER_QUALITY);
    g.setRenderingHint(
        RenderingHints.KEY_ALPHA_INTERPOLATION, RenderingHints.VALUE_ALPHA_INTERPOLATION_QUALITY);
    g.drawImage(source, 0, 0, w, h, null);
    g.dispose();
    return result;
  }
}
