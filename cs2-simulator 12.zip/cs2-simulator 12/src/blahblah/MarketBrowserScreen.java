package blahblah;

import blahblah.hGui.*;
import java.awt.*;
import java.awt.event.*;
import java.util.ArrayList;
import java.util.Map;
import javax.swing.*;

/** Market Browser Screen: focused feature implementation. */
final class MarketBrowserScreen {
  private final hGui app;

  MarketBrowserScreen(hGui app) {
    this.app = app;
  }

  JPanel createMarketplaceBrowserPanel() {
    JPanel panel = new JPanel(new BorderLayout());
    panel.setBackground(new Color(15, 15, 20));
    final String HOME_GROUP = "Home";

    JPanel navBar = new JPanel(new BorderLayout(0, 10));
    navBar.setBackground(new Color(31, 40, 56));
    navBar.setBorder(BorderFactory.createEmptyBorder(12, 18, 12, 18));

    JLabel logo = new JLabel("MARKETPLACE");
    logo.setFont(new Font("Arial", Font.BOLD, 28));
    logo.setForeground(Color.WHITE);
    JPanel topRow = new JPanel(new BorderLayout(12, 0));
    topRow.setOpaque(false);
    topRow.add(logo, BorderLayout.WEST);

    JPanel searchWrap = new JPanel(new FlowLayout(FlowLayout.RIGHT, 10, 0));
    searchWrap.setOpaque(false);
    JComboBox<String> searchField = app.searchControls.createSearchFieldWithHistory(18);
    searchField.setPrototypeDisplayValue("Search marketplace");
    JTextField searchEditor = app.searchControls.getSearchEditor(searchField);
    if (searchEditor != null) {
      searchEditor.setText("");
      searchEditor.setToolTipText("Press Enter to search");
    }
    JLabel searchLabel = new JLabel("Search");
    searchLabel.setFont(new Font("Arial", Font.BOLD, 12));
    searchLabel.setForeground(new Color(190, 205, 235));
    searchField.setPreferredSize(new Dimension(330, 34));
    searchWrap.add(searchLabel);
    searchWrap.add(searchField);
    topRow.add(searchWrap, BorderLayout.EAST);

    final String[] selectedGroup = {HOME_GROUP};
    final String[] selectedWeapon = {null};
    final String[] selectedSort = {"Lowest Price"};

    JPanel navButtonsRow = new JPanel(new FlowLayout(FlowLayout.LEFT, 14, 0));
    navButtonsRow.setOpaque(false);
    JButton homeBtn = app.marketFilterControls.createMarketplaceNavButton("Home");
    homeBtn.setText("Home");
    JButton pistolsBtn = app.marketFilterControls.createMarketplaceNavButton("Pistols");
    JButton midTierBtn = app.marketFilterControls.createMarketplaceNavButton("Mid-Tier");
    JButton riflesBtn = app.marketFilterControls.createMarketplaceNavButton("Rifles");
    JButton knivesBtn = app.marketFilterControls.createMarketplaceNavButton("Knives");
    JButton glovesBtn = app.marketFilterControls.createMarketplaceNavButton("Gloves");
    JButton collectionsBtn = app.marketFilterControls.createMarketplaceNavButton("Collections");
    JButton casesBox = app.marketFilterControls.createMarketplaceNavButton("Cases");
    casesBox.setName("marketplaceCasesDropdown");
    Map<String, String[]> categoryMenus = app.marketFilterControls.createMarketplaceCategoryMenus();

    navButtonsRow.add(homeBtn);
    navButtonsRow.add(pistolsBtn);
    navButtonsRow.add(midTierBtn);
    navButtonsRow.add(riflesBtn);
    navButtonsRow.add(knivesBtn);
    navButtonsRow.add(glovesBtn);
    navButtonsRow.add(collectionsBtn);
    if (app.cs2ShellEnabled) navButtonsRow.add(casesBox);

    navBar.add(topRow, BorderLayout.NORTH);
    navBar.add(navButtonsRow, BorderLayout.CENTER);
    panel.add(navBar, BorderLayout.NORTH);

    JPanel contentHeader = new JPanel(new BorderLayout());
    contentHeader.setBackground(new Color(18, 22, 30));
    contentHeader.setBorder(BorderFactory.createEmptyBorder(10, 18, 10, 18));
    JLabel selectionLabel = new JLabel();
    selectionLabel.setFont(new Font("Arial", Font.BOLD, 20));
    selectionLabel.setForeground(new Color(220, 220, 230));
    JLabel statsLabel = new JLabel("", SwingConstants.RIGHT);
    statsLabel.setFont(new Font("Consolas", Font.BOLD, 11));
    statsLabel.setForeground(Theme.ACCENT_CT);
    JComboBox<String> sortBox =
        new JComboBox<>(new String[] {"Lowest Price", "Highest Price", "Name", "Collection"});
    app.uiWidgets.styleComboBox(sortBox);
    sortBox.setSelectedItem(selectedSort[0]);
    JPanel headerRight = new JPanel(new FlowLayout(FlowLayout.RIGHT, 10, 0));
    headerRight.setOpaque(false);
    JLabel sortLabel = new JLabel("Sort");
    sortLabel.setFont(new Font("Arial", Font.BOLD, 12));
    sortLabel.setForeground(new Color(190, 205, 235));
    headerRight.add(sortLabel);
    headerRight.add(sortBox);
    JButton refreshCaseQuotes =
        app.marketFilterControls.createMarketplaceNavButton("Refresh quotes");
    refreshCaseQuotes.setName("refreshCaseQuotes");
    refreshCaseQuotes.setVisible(false);
    headerRight.add(refreshCaseQuotes);
    headerRight.add(statsLabel);
    contentHeader.add(selectionLabel, BorderLayout.WEST);
    contentHeader.add(headerRight, BorderLayout.EAST);

    ScrollablePanel homeContent = new ScrollablePanel();
    homeContent.setLayout(new BoxLayout(homeContent, BoxLayout.Y_AXIS));
    homeContent.setBackground(new Color(15, 15, 20));
    homeContent.setBorder(BorderFactory.createEmptyBorder(16, 16, 16, 16));
    JScrollPane homeScroll = new JScrollPane(homeContent);
    homeScroll.setBorder(null);
    homeScroll.getViewport().setBackground(new Color(15, 15, 20));
    homeScroll.getVerticalScrollBar().setUnitIncrement(20);
    homeScroll.setHorizontalScrollBarPolicy(ScrollPaneConstants.HORIZONTAL_SCROLLBAR_NEVER);

    JPanel grid = new JPanel(new GridLayout(0, 5, 12, 12));
    grid.setBackground(new Color(15, 15, 20));
    grid.setBorder(BorderFactory.createEmptyBorder(16, 16, 16, 16));
    JScrollPane scroll = new JScrollPane(grid);
    scroll.setBorder(null);
    scroll.getViewport().setBackground(new Color(15, 15, 20));
    scroll.getViewport().setScrollMode(JViewport.BLIT_SCROLL_MODE);
    scroll.getVerticalScrollBar().setUnitIncrement(20);
    scroll.setHorizontalScrollBarPolicy(ScrollPaneConstants.HORIZONTAL_SCROLLBAR_NEVER);

    CardLayout contentCards = new CardLayout();
    JPanel contentPanel = new JPanel(contentCards);
    contentPanel.setBackground(new Color(15, 15, 20));
    contentPanel.add(homeScroll, "HOME");
    contentPanel.add(scroll, "GRID");

    JPanel centerWrap = new JPanel(new BorderLayout());
    centerWrap.setBackground(new Color(15, 15, 20));
    centerWrap.add(contentHeader, BorderLayout.NORTH);
    centerWrap.add(contentPanel, BorderLayout.CENTER);
    panel.add(centerWrap, BorderLayout.CENTER);

    Runnable rebuildHome =
        () -> {
          if (homeContent.getComponentCount() > 0)
            return; // Keep the existing live chain and scroll position.
          homeContent.removeAll();
          app.marketHomeScreen.createMarketplaceHomeContent(homeContent, app);
          homeContent.revalidate();
          homeContent.repaint();
        };

    final ArrayList<Map.Entry<String, ArrayList<MarketListing>>> gridEntries = new ArrayList<>();
    final int[] gridRenderedCount = {0};
    Runnable renderMoreGridCards =
        () -> {
          // Keep Swing's component tree small; cards are rendered as the user nears them.
          int end = Math.min(gridRenderedCount[0] + 12, gridEntries.size());
          for (int i = gridRenderedCount[0]; i < end; i++) {
            Map.Entry<String, ArrayList<MarketListing>> entry = gridEntries.get(i);
            grid.add(
                app.marketItemCards.createMarketplaceSkinCard(
                    entry.getKey(), entry.getValue(), app));
          }
          gridRenderedCount[0] = end;
          grid.revalidate();
          grid.repaint();
        };

    Runnable rebuildGrid =
        () -> {
          String search = app.searchControls.getSearchText(searchField);
          refreshCaseQuotes.setVisible("Containers".equals(selectedGroup[0]));

          boolean showHome = HOME_GROUP.equals(selectedGroup[0]) && search.isEmpty();
          homeBtn.setEnabled(!showHome);
          sortLabel.setVisible(!showHome);
          sortBox.setVisible(!showHome);
          if (showHome) {
            int activeMarketCount =
                app.marketHomeScreen.getTopMarketplaceSummaries(Integer.MAX_VALUE).size();
            selectionLabel.setText("Home");
            statsLabel.setText(
                String.format(
                    "%d skins | %d tracked markets",
                    app.marketHomeScreen.getTrackedMarketSkinCount(), activeMarketCount));
            rebuildHome.run();
            contentCards.show(contentPanel, "HOME");
            headerRight.revalidate();
            headerRight.repaint();
            return;
          }

          grid.removeAll();
          java.util.List<Map.Entry<String, ArrayList<MarketListing>>> entries =
              app.marketFilterControls.collectMarketplaceEntries(
                  selectedGroup[0], selectedWeapon[0], search, selectedSort[0]);
          gridEntries.clear();
          gridEntries.addAll(entries);
          gridRenderedCount[0] = 0;
          renderMoreGridCards.run();
          String title =
              !search.isEmpty() && HOME_GROUP.equals(selectedGroup[0])
                  ? "Search Results"
                  : (selectedWeapon[0] != null ? selectedWeapon[0] : selectedGroup[0]);
          selectionLabel.setText(title);
          int marketCount = 0;
          for (Map.Entry<String, ArrayList<MarketListing>> entry : entries) {
            marketCount += app.marketFilterControls.countDistinctMarketplaces(entry.getValue());
          }
          statsLabel.setText(
              String.format("%d skins | %d tracked markets", entries.size(), marketCount));
          contentCards.show(contentPanel, "GRID");
          headerRight.revalidate();
          headerRight.repaint();
        };

    scroll
        .getViewport()
        .addChangeListener(
            e -> {
              JScrollBar bar = scroll.getVerticalScrollBar();
              if (gridRenderedCount[0] < gridEntries.size()
                  && bar.getValue() + bar.getVisibleAmount() >= bar.getMaximum() - 250) {
                renderMoreGridCards.run();
              }
            });

    Runnable refreshCurrentView =
        () -> {
          if (homeScroll.isShowing()) {
            Object refreshStats = homeContent.getClientProperty("refreshHomeStats");
            if (refreshStats instanceof Runnable) ((Runnable) refreshStats).run();
            // The 150 ms chain has its own clock. Market refreshes never replace it.
          } else {
            for (String skinName : new ArrayList<>(app.marketplacePriceLabels.keySet())) {
              java.util.Set<JLabel> labels = app.marketplacePriceLabels.get(skinName);
              if (labels == null) continue;
              labels.removeIf(label -> !label.isDisplayable());
              if (labels.isEmpty()) {
                app.marketplacePriceLabels.remove(skinName, labels);
                continue;
              }
              if (labels.stream().anyMatch(Component::isShowing))
                app.artworkService.updateMarketplacePriceLabels(skinName);
            }
          }
        };

    java.util.function.BiConsumer<JButton, String[][]> openMenu =
        (source, menuGroups) -> {
          JPopupMenu menu = new JPopupMenu();
          menu.setBackground(new Color(61, 71, 91));
          menu.setBorder(BorderFactory.createLineBorder(Theme.ACCENT_CT, 1));
          for (String[] group : menuGroups) {
            JMenuItem header = new JMenuItem(group[0]);
            header.setEnabled(false);
            header.setForeground(new Color(170, 175, 190));
            header.setBackground(new Color(61, 71, 91));
            menu.add(header);
            for (int i = 1; i < group.length; i++) {
              String weapon = group[i];
              JMenuItem item = new JMenuItem(weapon);
              item.setBackground(new Color(61, 71, 91));
              item.setForeground(Color.WHITE);
              item.addActionListener(
                  e -> {
                    selectedWeapon[0] = weapon;
                    rebuildGrid.run();
                  });
              menu.add(item);
            }
            menu.addSeparator();
          }
          if (menu.getComponentCount() > 0
              && menu.getComponent(menu.getComponentCount() - 1) instanceof JSeparator) {
            menu.remove(menu.getComponentCount() - 1);
          }
          menu.show(source, 0, source.getHeight());
        };

    homeBtn.setName("marketplaceHomeButton");
    logo.setName("marketplaceHomeLogo");
    Runnable navigateHome =
        () -> {
          if (HOME_GROUP.equals(selectedGroup[0])
              && selectedWeapon[0] == null
              && app.searchControls.getSearchText(searchField).isEmpty()
              && homeContent.getComponentCount() > 0) return;
          selectedGroup[0] = HOME_GROUP;
          selectedWeapon[0] = null;
          if (searchEditor != null) searchEditor.setText("");
          rebuildGrid.run();
        };
    homeBtn.addActionListener(e -> navigateHome.run());
    logo.setCursor(new Cursor(Cursor.HAND_CURSOR));
    logo.addMouseListener(
        new MouseAdapter() {
          @Override
          public void mouseClicked(MouseEvent e) {
            navigateHome.run();
          }
        });

    pistolsBtn.addActionListener(
        e -> {
          selectedGroup[0] = "Pistols";
          openMenu.accept(
              pistolsBtn,
              new String[][] {
                {
                  "Pistols",
                  "CZ75-Auto",
                  "Desert Eagle",
                  "Dual Berettas",
                  "Five-SeveN",
                  "Glock-18",
                  "P2000",
                  "P250",
                  "R8 Revolver",
                  "Tec-9",
                  "USP-S",
                  "Zeus x27"
                }
              });
        });
    midTierBtn.addActionListener(
        e -> {
          selectedGroup[0] = "Mid-Tier";
          openMenu.accept(
              midTierBtn,
              new String[][] {
                {"SMGs", "MAC-10", "MP5-SD", "MP7", "MP9", "P90", "PP-Bizon", "UMP-45"},
                {"Shotguns", "MAG-7", "Nova", "Sawed-Off", "XM1014"},
                {"Machine Guns", "M249", "Negev"}
              });
        });
    riflesBtn.addActionListener(
        e -> {
          selectedGroup[0] = "Rifles";
          openMenu.accept(
              riflesBtn,
              new String[][] {
                {"Assault Rifles", "AK-47", "AUG", "FAMAS", "Galil AR", "M4A1-S", "M4A4", "SG 553"},
                {"Sniper Rifles", "AWP", "G3SG1", "SCAR-20", "SSG 08"}
              });
        });
    knivesBtn.addActionListener(
        e -> {
          app.marketFilterControls.showMarketplaceSelectionMenu(
              knivesBtn,
              "Knives",
              app.marketFilterControls.concatMenuItems(
                  new String[] {"All Knives"}, categoryMenus.get("Knives")),
              selectedGroup,
              selectedWeapon,
              rebuildGrid);
        });
    glovesBtn.addActionListener(
        e -> {
          app.marketFilterControls.showMarketplaceSelectionMenu(
              glovesBtn,
              "Gloves",
              app.marketFilterControls.concatMenuItems(
                  new String[] {"All Gloves"}, categoryMenus.get("Gloves")),
              selectedGroup,
              selectedWeapon,
              rebuildGrid);
        });
    collectionsBtn.addActionListener(
        e -> {
          app.marketFilterControls.showMarketplaceSelectionMenu(
              collectionsBtn,
              "Collections",
              app.marketFilterControls.getMarketplaceCollectionMenuItems(),
              selectedGroup,
              selectedWeapon,
              rebuildGrid);
        });

    refreshCaseQuotes.addActionListener(
        e -> {
          refreshCaseQuotes.setEnabled(false);
          refreshCaseQuotes.setText("Updating…");
          new SwingWorker<Map<CaseType, Double>, Void>() {
            protected Map<CaseType, Double> doInBackground() {
              app.publicPriceSnapshotTimes.remove("csfloat");
              return app.startupArtworkService.fetchRoundedMarketCasePrices();
            }

            protected void done() {
              try {
                app.startupArtworkService.applyMarketCasePrices(get());
                rebuildGrid.run();
              } catch (Exception ex) {
                JOptionPane.showMessageDialog(
                    panel, "Could not update container quotes: " + ex.getMessage());
              } finally {
                refreshCaseQuotes.setText("Refresh quotes");
                refreshCaseQuotes.setEnabled(true);
              }
            }
          }.execute();
        });
    casesBox.addActionListener(
        e -> {
          String[] options =
              app.marketFilterControls.concatMenuItems(
                  new String[] {"All Containers", "Cases", "Souvenir Packages", "Terminals"},
                  java.util.Arrays.stream(CaseType.values())
                      .map(ct -> ct.catalogCrateName())
                      .distinct()
                      .sorted()
                      .toArray(String[]::new));
          app.marketFilterControls.showMarketplaceSelectionMenu(
              casesBox, "Containers", options, selectedGroup, selectedWeapon, rebuildGrid);
        });
    sortBox.addActionListener(
        e -> {
          selectedSort[0] = (String) sortBox.getSelectedItem();
          rebuildGrid.run();
        });
    app.marketFilterControls.installEnterSearchHandler(searchField, rebuildGrid);
    javax.swing.Timer browserRefreshTimer =
        new javax.swing.Timer(hGui.MARKET_UPDATE_INTERVAL, e -> refreshCurrentView.run());
    browserRefreshTimer.setCoalesce(true);
    panel.putClientProperty("browserRefreshTimer", browserRefreshTimer);
    panel.addHierarchyListener(
        e -> {
          if ((e.getChangeFlags() & HierarchyEvent.SHOWING_CHANGED) != 0) {
            if (panel.isShowing()) browserRefreshTimer.start();
            else browserRefreshTimer.stop();
          }
        });
    if (panel.isShowing()) browserRefreshTimer.start();
    SwingUtilities.invokeLater(rebuildGrid);
    return panel;
  }
}
