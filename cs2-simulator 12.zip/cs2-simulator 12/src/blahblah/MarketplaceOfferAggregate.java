package blahblah;

import blahblah.hGui.*;
import java.awt.*;
import java.awt.event.*;
import java.util.ArrayList;
import javax.swing.*;

/** Extracted reusable model or widget; behavior retained from the original source. */
public class MarketplaceOfferAggregate {
  String marketplaceName;
  String marketplaceType;
  double lowestPrice;
  double totalValue;
  int listingCount;
  double rating;
  String reviews;
  boolean promoted;
  Color accent;
  Color accentAlt;
  ArrayList<MarketListing> listings = new ArrayList<>();
}
