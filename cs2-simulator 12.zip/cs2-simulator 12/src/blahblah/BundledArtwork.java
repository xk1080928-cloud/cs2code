package blahblah;

import blahblah.hGui.*;
import java.awt.*;
import java.awt.event.*;
import java.awt.image.BufferedImage;
import javax.swing.*;

/** Bundled Artwork: focused feature implementation. */
final class BundledArtwork {
  private final hGui app;

  BundledArtwork(hGui app) {
    this.app = app;
  }

  public void loadSkinImages() {
    // No bundled PNGs, including the old gold icon, are required.
    app.blueSkins = new Image[0];
    app.purpleSkins = new Image[0];
    app.pinkSkins = new Image[0];
    app.redSkins = new Image[0];
    app.knifeSkins = new Image[0];
    app.gloveSkins = new Image[0];
    app.knifeSkinNames = new String[0];
    BufferedImage gold = new BufferedImage(120, 88, BufferedImage.TYPE_INT_ARGB);
    Graphics2D graphics = gold.createGraphics();
    graphics.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
    Polygon star = new Polygon();
    for (int i = 0; i < 10; i++) {
      double angle = -Math.PI / 2 + i * Math.PI / 5, radius = i % 2 == 0 ? 34 : 15;
      star.addPoint(
          60 + (int) Math.round(Math.cos(angle) * radius),
          44 + (int) Math.round(Math.sin(angle) * radius));
    }
    graphics.setColor(Theme.RARITY_GOLD);
    graphics.fillPolygon(star);
    graphics.dispose();
    app.goldIconImage = gold;
  }

  Image getKnifeImage(String skinName) {
    return app.artworkService.getSkinImageFromName(skinName);
  }

  void refreshMainUI() {
    app.revalidate();
    app.repaint();
  }
}
