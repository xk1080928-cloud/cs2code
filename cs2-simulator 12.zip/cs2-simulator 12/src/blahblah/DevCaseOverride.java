package blahblah;

import blahblah.hGui.*;
import java.awt.*;
import java.awt.event.*;
import javax.swing.*;

/** Extracted reusable model or widget; behavior retained from the original source. */
final class DevCaseOverride {
  final String mode, target, statTrakMode;
  int remaining;

  DevCaseOverride(String mode, String target, int remaining, String statTrakMode) {
    this.mode = mode;
    this.target = target;
    this.remaining = remaining;
    this.statTrakMode = statTrakMode;
  }
}
