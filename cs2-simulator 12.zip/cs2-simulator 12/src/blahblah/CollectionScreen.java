package blahblah;

import blahblah.hGui.*;
import java.awt.*;
import java.awt.event.*;
import java.util.ArrayList;
import java.util.List;
import javax.swing.*;

/** Collection Screen: focused feature implementation. */
final class CollectionScreen {
  private final hGui app;

  CollectionScreen(hGui app) {
    this.app = app;
  }

  void showCollectionWindow() {
    JFrame collectionFrame = new JFrame("Skin Collection");
    collectionFrame.setSize(1000, 800);
    collectionFrame.setLocationRelativeTo(app);
    collectionFrame.setLayout(new BorderLayout());

    collectionFrame.setAlwaysOnTop(true);

    JPanel headerPanel = new JPanel(new GridLayout(2, 1));
    headerPanel.setBackground(new Color(30, 30, 35));
    headerPanel.setBorder(BorderFactory.createEmptyBorder(10, 10, 10, 10));

    JLabel titleLabel = new JLabel("Skin Collection", SwingConstants.CENTER);
    titleLabel.setFont(new Font("Arial", Font.BOLD, 24));
    titleLabel.setForeground(Color.WHITE);

    int totalSkins = app.collectionScreen.getAllPossibleSkins().size();
    int unlockedCount = app.unboxedSkins.size();
    double completionPercent = (unlockedCount * 100.0) / totalSkins;

    JLabel statsLabel =
        new JLabel(
            String.format(
                "Unlocked: %d / %d (%.1f%%)", unlockedCount, totalSkins, completionPercent),
            SwingConstants.CENTER);
    statsLabel.setFont(new Font("Arial", Font.BOLD, 18));
    statsLabel.setForeground(Color.CYAN);

    headerPanel.add(titleLabel);
    headerPanel.add(statsLabel);
    collectionFrame.add(headerPanel, BorderLayout.NORTH);

    JTabbedPane tabbedPane = new JTabbedPane();
    List<String> allItems = app.collectionScreen.getAllPossibleSkins();
    tabbedPane.addTab(
        "All Items",
        app.collectionScreen.createCollectionPanelForItems(allItems, "All Items", Color.CYAN));

    String[] rarityOrder = {
      "Knife",
      "Gloves",
      "Covert",
      "Master",
      "Classified",
      "Superior",
      "Restricted",
      "Exceptional",
      "Milspec",
      "Distinguished",
      "Industrial",
      "Consumer"
    };
    for (String rarity : rarityOrder) {
      List<String> items = app.collectionScreen.getSkinsByRarity(rarity);
      if (!items.isEmpty()) {
        tabbedPane.addTab(
            rarity,
            app.collectionScreen.createCollectionPanelForItems(
                items, rarity, app.itemInspectionScreen.getRarityColor(rarity)));
      }
    }

    collectionFrame.add(tabbedPane, BorderLayout.CENTER);
    collectionFrame.setVisible(true);

    javax.swing.Timer timer =
        new javax.swing.Timer(
            100,
            e -> {
              collectionFrame.setAlwaysOnTop(false);
              collectionFrame.toFront();
              collectionFrame.requestFocus();
            });
    timer.setRepeats(false);
    timer.start();
  }

  List<String> getAllPossibleSkins() {
    java.util.LinkedHashSet<String> allSkins = new java.util.LinkedHashSet<>();

    allSkins.add("Karambit | Slaughter");
    allSkins.add("Karambit | Crimson Web");
    allSkins.add("Karambit | Scorched");
    allSkins.add("Karambit | Urban Masked");
    allSkins.add("Karambit | Night");
    allSkins.add("Karambit | Doppler");
    allSkins.add("M9 Bayonet | Crimson Web");
    allSkins.add("M9 Bayonet | Blue Steel");
    allSkins.add("M9 Bayonet | Case Hardened");
    allSkins.add("M9 Bayonet | Slaughter");
    allSkins.add("M9 Bayonet | Doppler");
    allSkins.add("Flip Knife | Vanilla");
    allSkins.add("Flip Knife | Case Hardened");
    allSkins.add("Gut Knife | Fade");
    allSkins.add("Gut Knife | Forest DDPAT");
    allSkins.add("Gut Knife | Safari Mesh");
    allSkins.add("Bayonet | Scorched");
    allSkins.add("Bayonet | Boreal Forest");
    allSkins.add("Bayonet | Fade");
    allSkins.add("Butterfly Knife | Case Hardened");
    allSkins.add("Butterfly Knife | Crimson Web");
    allSkins.add("Butterfly Knife | Fade");
    allSkins.add("Butterfly Knife | Safari Mesh");
    allSkins.add("Butterfly Knife | Slaughter");
    allSkins.add("Butterfly Knife | Urban Masked");
    allSkins.add("Butterfly Knife | Vanilla");
    allSkins.add("Butterfly Knife | Ultraviolet");
    allSkins.add("Butterfly Knife | Doppler");
    allSkins.add("Butterfly Knife | Gamma Doppler");
    allSkins.add("Butterfly Knife | Marble Fade");
    allSkins.add("Butterfly Knife | Lore");
    allSkins.add("Kukri Knife | Urban Masked");
    allSkins.add("Kukri Knife | Stained");
    allSkins.add("Kukri Knife | Slaughter");
    allSkins.add("Kukri Knife | Scorched");
    allSkins.add("Kukri Knife | Safari Mesh");
    allSkins.add("Kukri Knife | Night Stripe");
    allSkins.add("Kukri Knife | Fade");
    allSkins.add("Kukri Knife | Crimson Web");
    allSkins.add("Kukri Knife | Case Hardened");

    allSkins.add("Huntsman Knife | Marble Fade");
    allSkins.add("Huntsman Knife | Tiger Tooth");
    allSkins.add("Bowie Knife | Marble Fade");
    allSkins.add("Bowie Knife | Urban Masked");
    allSkins.add("Bowie Knife | Stained");
    allSkins.add("Bowie Knife | Scorched");
    allSkins.add("Bowie Knife | Lore");
    allSkins.add("Bowie Knife | Forest DDPAT");
    allSkins.add("Bowie Knife | Fade");
    allSkins.add("Bowie Knife | Crimson Web");
    allSkins.add("Bowie Knife | Boreal Forest");
    allSkins.add("Bowie Knife | Blue Steel");
    allSkins.add("Bowie Knife | Black Laminate");
    allSkins.add("Bowie Knife | Tiger Tooth");
    allSkins.add("Falchion Knife | Marble Fade");
    allSkins.add("Falchion Knife | Tiger Tooth");

    allSkins.add("Bloodhound Gloves | Bronzed");
    allSkins.add("Bloodhound Gloves | Charred");
    allSkins.add("Bloodhound Gloves | Guerrilla");
    allSkins.add("Bloodhound Gloves | Snakebite");
    allSkins.add("Driver Gloves | Convoy");
    allSkins.add("Driver Gloves | Crimson Weave");
    allSkins.add("Driver Gloves | Diamondback");
    allSkins.add("Driver Gloves | Lunar Weave");
    allSkins.add("Hand Wraps | Badlands");
    allSkins.add("Hand Wraps | Leather");
    allSkins.add("Hand Wraps | Slaughter");
    allSkins.add("Hand Wraps | Spruce DDPAT");
    allSkins.add("Moto Gloves | Boom!");
    allSkins.add("Moto Gloves | Cool Mint");
    allSkins.add("Moto Gloves | Eclipse");
    allSkins.add("Moto Gloves | Spearmint");
    allSkins.add("Specialist Gloves | Crimson Kimono");
    allSkins.add("Specialist Gloves | Emerald Web");
    allSkins.add("Specialist Gloves | Forest DDPAT");
    allSkins.add("Specialist Gloves | Foundation");
    allSkins.add("Sport Gloves | Arid");
    allSkins.add("Sport Gloves | Hedge Maze");
    allSkins.add("Sport Gloves | Pandora's Box");
    allSkins.add("Sport Gloves | Superconductor");
    allSkins.add("Hydra Gloves | Rattler");
    allSkins.add("Hydra Gloves | Mangrove");
    allSkins.add("Hydra Gloves | Emerald");
    allSkins.add("Hydra Gloves | Case Hardened");
    allSkins.add("Hand Wraps | Overprint");
    allSkins.add("Hand Wraps | Duct Tape");
    allSkins.add("Hand Wraps | Cobalt Skulls");
    allSkins.add("Hand Wraps | Arboreal");
    allSkins.add("Driver Gloves | Racing Green");
    allSkins.add("Driver Gloves | Overtake");
    allSkins.add("Driver Gloves | King Snake");
    allSkins.add("Driver Gloves | Imperial Plaid");
    allSkins.add("Sport Gloves | Vice");
    allSkins.add("Sport Gloves | Omega");
    allSkins.add("Sport Gloves | Bronze Morph");
    allSkins.add("Sport Gloves | Amphibious");
    allSkins.add("Specialist Gloves | Mogul");
    allSkins.add("Specialist Gloves | Fade");
    allSkins.add("Specialist Gloves | Crimson Web");
    allSkins.add("Specialist Gloves | Buckshot");
    allSkins.add("Moto Gloves | Turtle");
    allSkins.add("Moto Gloves | Transport");
    allSkins.add("Moto Gloves | POW!");
    allSkins.add("Moto Gloves | Polygon");

    allSkins.addAll(app.collectionService.getCatalogSkinsByCategory("Knives"));
    allSkins.addAll(app.collectionService.getCatalogSkinsByCategory("Gloves"));
    allSkins.addAll(app.skinCatalog.keySet());

    allSkins.addAll(app.oddsAndChecklistScreen.getRegisteredTradeUpSkins());

    for (ArmouryCollection col : hGui.ARMOURY_COLLECTIONS) {
      for (String[] tier :
          new String[][] {
            col.covertNames,
            col.classifiedNames,
            col.restrictedNames,
            col.milspecNames,
            col.industrialNames,
            col.consumerNames
          }) {
        if (tier == null) continue;
        for (String name : tier) {
          if (name != null && !name.isEmpty()) allSkins.add(name);
        }
      }
    }

    return new ArrayList<>(allSkins);
  }

  List<String> getSkinsByRarity(String rarity) {
    List<String> skins = new ArrayList<>();

    for (String skin : app.collectionScreen.getAllPossibleSkins()) {
      if (app.itemMetadataService.getSkinRarity(skin).equals(rarity)) {
        skins.add(skin);
      }
    }

    return skins;
  }

  JPanel createCollectionPanelForItems(
      List<String> skinsInRarity, String title, Color accentColor) {
    JPanel panel = new JPanel(new BorderLayout());
    panel.setBackground(new Color(35, 35, 40));

    int unlockedInRarity = 0;
    for (String skin : skinsInRarity) {
      if (app.unboxedSkins.contains(skin)) {
        unlockedInRarity++;
      }
    }

    JLabel rarityStatsLabel =
        new JLabel(
            String.format("%s: %d / %d unlocked", title, unlockedInRarity, skinsInRarity.size()),
            SwingConstants.CENTER);
    rarityStatsLabel.setFont(new Font("Arial", Font.BOLD, 16));
    rarityStatsLabel.setForeground(accentColor);
    rarityStatsLabel.setBorder(BorderFactory.createEmptyBorder(10, 10, 10, 10));
    panel.add(rarityStatsLabel, BorderLayout.NORTH);

    JPanel grid = new JPanel(new GridLayout(0, 3, 10, 10));
    grid.setBackground(new Color(35, 35, 40));
    grid.setBorder(BorderFactory.createEmptyBorder(10, 10, 10, 10));

    for (String skinName : skinsInRarity) {
      JPanel skinCard =
          app.collectionScreen.createCollectionSkinCard(
              skinName, app.itemMetadataService.getSkinRarity(skinName));
      grid.add(skinCard);
    }

    JScrollPane scroll = new JScrollPane(grid);
    scroll.getVerticalScrollBar().setUnitIncrement(16);
    scroll.setBorder(null);
    scroll.getViewport().setBackground(new Color(35, 35, 40));
    panel.add(scroll, BorderLayout.CENTER);

    return panel;
  }

  JPanel createCollectionSkinCard(String skinName, String rarity) {
    JPanel card = new JPanel(new BorderLayout());
    card.setBackground(new Color(50, 50, 55));
    card.setBorder(
        BorderFactory.createLineBorder(app.itemInspectionScreen.getRarityColor(rarity), 3));
    card.setPreferredSize(new Dimension(200, 180));

    boolean isUnlocked = app.unboxedSkins.contains(skinName);

    if (isUnlocked) {
      Image skinImg = app.artworkService.getSkinImageFromName(skinName);
      if (skinImg != null) {
        Image scaled = HighQualityImages.fit(skinImg, 180, 120);
        JLabel imgLabel = new JLabel(new ImageIcon(scaled));
        imgLabel.setHorizontalAlignment(SwingConstants.CENTER);
        card.add(imgLabel, BorderLayout.CENTER);
      } else {
        JLabel placeholderLabel = new JLabel("Image Missing", SwingConstants.CENTER);
        placeholderLabel.setForeground(Color.GRAY);
        placeholderLabel.setFont(new Font("Arial", Font.ITALIC, 12));
        card.add(placeholderLabel, BorderLayout.CENTER);
      }

      JLabel nameLabel =
          new JLabel("<html><center>" + skinName + "</center></html>", SwingConstants.CENTER);
      nameLabel.setFont(new Font("Arial", Font.BOLD, 11));
      nameLabel.setForeground(Color.WHITE);
      nameLabel.setBorder(BorderFactory.createEmptyBorder(5, 5, 5, 5));
      card.add(nameLabel, BorderLayout.SOUTH);
    } else {
      JPanel lockedPanel = new JPanel(new BorderLayout());
      lockedPanel.setBackground(new Color(30, 30, 35));

      JLabel mysteryLabel = new JLabel("???", SwingConstants.CENTER);
      mysteryLabel.setFont(new Font("Arial", Font.BOLD, 72));
      mysteryLabel.setForeground(new Color(80, 80, 85));
      lockedPanel.add(mysteryLabel, BorderLayout.CENTER);

      JLabel lockedLabel = new JLabel("LOCKED", SwingConstants.CENTER);
      lockedLabel.setFont(new Font("Arial", Font.BOLD, 14));
      lockedLabel.setForeground(new Color(100, 100, 105));
      lockedLabel.setBorder(BorderFactory.createEmptyBorder(5, 5, 5, 5));
      lockedPanel.add(lockedLabel, BorderLayout.SOUTH);

      card.add(lockedPanel, BorderLayout.CENTER);
    }

    return card;
  }
}
