package blahblah;

import blahblah.hGui.*;
import java.awt.*;
import java.awt.event.*;
import javax.swing.*;

/** Extracted reusable model or widget; behavior retained from the original source. */
final class StripItem {
  final Image image;
  final Color rarityColor;

  StripItem(Image image, Color rarityColor) {
    this.image = image;
    this.rarityColor = rarityColor;
  }
}
