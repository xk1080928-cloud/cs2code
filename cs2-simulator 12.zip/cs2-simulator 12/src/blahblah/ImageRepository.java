package blahblah;

import blahblah.hGui.*;
import java.awt.*;
import java.awt.event.*;
import java.awt.image.BufferedImage;
import java.io.IOException;
import java.io.InputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.net.URLConnection;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.nio.file.StandardCopyOption;
import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.Set;
import javax.swing.*;

/** Extracted reusable model or widget; behavior retained from the original source. */
final class ImageRepository {
  private final hGui app;

  ImageRepository(hGui app) {
    this.app = app;
  }

  static final int MAX_CACHE_SIZE = 512;
  final Path diskCacheDirectory =
      Paths.get(System.getProperty("user.home"), ".csgo-skin-simulator", "images");
  final Map<String, Image> cache =
      new LinkedHashMap<String, Image>(64, 0.75f, true) {
        @Override
        protected boolean removeEldestEntry(Map.Entry<String, Image> eldest) {
          return size() > MAX_CACHE_SIZE;
        }
      };

  synchronized Image get(String skinName) {
    if (skinName != null && skinName.startsWith("case-key-") && app.cs2KeyArtwork != null) {
      Image key = app.cs2KeyArtwork.get(skinName.substring(9));
      if (key != null) return key;
    }
    Image container = app.containerArtwork == null ? null : app.containerArtwork.get(skinName);
    if (container != null) return container;
    Image pinned = app.openingArtwork == null ? null : app.openingArtwork.get(skinName);
    return pinned != null ? pinned : cache.get(skinName);
  }

  synchronized void put(String skinName, Image image) {
    if (skinName != null && image != null) {
      if (skinName.startsWith("case-selector-") || skinName.startsWith("cs2-stock-"))
        app.containerArtwork.put(
            skinName, app.openingArtworkService.retainContainerThumbnail(image));
      if (skinName.startsWith("case-key-") && app.cs2KeyArtwork != null)
        app.cs2KeyArtwork.put(
            skinName.substring(9), app.openingArtworkService.retainContainerThumbnail(image));
      app.armouryArtworkCache.remember(skinName, image);
      cache.put(skinName, image);
      // Every cache insertion (including preload and late defaults) wakes existing cards.
      SwingUtilities.invokeLater(
          () -> app.artworkService.updatePendingRemoteImageLabels(skinName, image));
    }
  }

  Image loadByFilename(String skinName, String filename) {
    // Legacy callers are resolved by item name; bundled filenames are never opened.
    return app.artworkService.getSkinImageFromName(skinName);
  }

  void loadRemote(String skinName, String imageUrl) {
    loadRemote(skinName, imageUrl, true);
  }

  void loadRemote(String skinName, String imageUrl, boolean notifyGameViews) {
    loadRemote(skinName, imageUrl, notifyGameViews, null);
  }

  void loadRemote(String skinName, String imageUrl, boolean notifyGameViews, String fallbackUrl) {
    if (app.startupWorkStarted && !app.marketInitialized) return;
    if (skinName == null
        || imageUrl == null
        || get(skinName) != null
        || app.remoteImageExecutor == null
        || app.remoteImageExecutor.isShutdown()) return;
    if (notifyGameViews) app.remoteImageGameViewRequests.add(skinName);
    if (!app.remoteImageLoads.add(skinName)) return;
    app.remoteImageExecutor.execute(
        () -> {
          try {
            BufferedImage image = null;
            IOException failure = null;
            for (String url :
                fallbackUrl == null || fallbackUrl.equals(imageUrl)
                    ? new String[] {imageUrl}
                    : new String[] {imageUrl, fallbackUrl}) {
              if (url == null || !url.startsWith("https://")) continue;
              url = app.startupResolvedArtworkUrls.getOrDefault(url, url);
              Long retryAfter = app.unavailableRemoteImageUrls.get(url);
              if (retryAfter != null && retryAfter > System.currentTimeMillis()) continue;
              try {
                image = readRemoteCachedImage(url);
                if (image != null) break;
              } catch (IOException ex) {
                failure = ex;
                app.unavailableRemoteImageUrls.put(url, System.currentTimeMillis() + 300000L);
              }
            }
            if (image == null)
              throw failure == null ? new IOException("Image temporarily unavailable") : failure;
            BufferedImage loadedImage = image;
            put(skinName, loadedImage);
            boolean regularUIRequested = app.remoteImageGameViewRequests.remove(skinName);
            if (!notifyGameViews && !regularUIRequested) {
              SwingUtilities.invokeLater(
                  () -> {
                    app.artworkService.updatePendingRemoteImageLabels(skinName, loadedImage);
                    app.marketHomeFeeds.repaintHomeFeedsForArtwork(skinName);
                  });
              return;
            }
            SwingUtilities.invokeLater(
                () -> {
                  app.marketHomeFeeds.repaintHomeFeedsForArtwork(skinName);
                  app.armouryAnimationPoolCache.clear();
                  app.containerBrowserScreen.showLoadedCaseResultImage(skinName, loadedImage);
                  if (!app.artworkService.updatePendingRemoteImageLabels(skinName, loadedImage)
                      && (app.startupLoadingOverlay == null
                          || !app.startupLoadingOverlay.isVisible()))
                    app.artworkService.refreshForLoadedSkinImage();
                });
          } catch (IOException ex) {
            app.remoteImageGameViewRequests.remove(skinName);
            SwingUtilities.invokeLater(
                () -> {
                  Set<JLabel> labels = app.pendingRemoteImageLabels.remove(skinName);
                  if (labels != null)
                    for (JLabel label : labels) {
                      if (!skinName.equals(label.getClientProperty("remoteImageRequestKey")))
                        continue;
                      if (Boolean.TRUE.equals(label.getClientProperty("skinArtworkPlaceholder")))
                        label.setIcon(null);
                      label.setText(label.getIcon() == null ? "Image unavailable" : "");
                      label.setToolTipText(
                          "Online artwork is unavailable; reopen this view to retry.");
                    }
                });
            System.err.println(
                "Could not load remote skin image for " + skinName + ": " + ex.getMessage());
          } finally {
            app.remoteImageLoads.remove(skinName);
          }
        });
  }

  BufferedImage readRemoteCachedImage(String imageUrl) throws IOException {
    Path file = getDiskCacheFile(imageUrl);
    if (Files.isRegularFile(file)) {
      try (InputStream stream = Files.newInputStream(file)) {
        BufferedImage cached = javax.imageio.ImageIO.read(stream);
        if (cached != null) return cached;
      } catch (IOException ignored) {
      }
      try {
        Files.deleteIfExists(file);
      } catch (IOException ignored) {
      }
    }
    BufferedImage image = null;
    IOException failure = null;
    // Steam's CDN aliases can intermittently fail TLS/edge requests. Retry only
    // official HTTPS mirrors of the identical asset; never disable certificate checks.
    for (String candidate : steamArtworkMirrors(imageUrl)) {
      URLConnection connection = java.net.URI.create(candidate).toURL().openConnection();
      connection.setRequestProperty("User-Agent", "CS2-Skin-Simulator/2.0");
      connection.setRequestProperty("Accept", "image/png,image/*;q=0.9,*/*;q=0.5");
      connection.setConnectTimeout(4000);
      connection.setReadTimeout(6000);
      try (InputStream stream = connection.getInputStream()) {
        image = javax.imageio.ImageIO.read(stream);
        if (image == null) throw new IOException("Image response could not be decoded");
        break;
      } catch (IOException ex) {
        failure = ex;
        // Try every official mirror of this exact asset, including after an edge-local 404.
      } finally {
        if (connection instanceof HttpURLConnection) ((HttpURLConnection) connection).disconnect();
      }
    }
    if (image == null)
      throw failure == null ? new IOException("Image response could not be decoded") : failure;
    try {
      Files.createDirectories(diskCacheDirectory);
      Path temporary = Files.createTempFile(diskCacheDirectory, "image-", ".tmp");
      try {
        if (javax.imageio.ImageIO.write(image, "png", temporary.toFile()))
          Files.move(temporary, file, StandardCopyOption.REPLACE_EXISTING);
      } finally {
        Files.deleteIfExists(temporary);
      }
    } catch (IOException ex) {
      System.err.println("Could not cache downloaded image: " + ex.getMessage());
    }
    return image;
  }

  List<String> steamArtworkMirrors(String original) throws IOException {
    java.util.LinkedHashSet<String> urls = new java.util.LinkedHashSet<>();
    urls.add(original);
    URL u = java.net.URI.create(original).toURL();
    String host = u.getHost().toLowerCase(java.util.Locale.ROOT);
    if ("https".equals(u.getProtocol())
        && java.util.Arrays.asList(
                "community.akamai.steamstatic.com",
                "community.fastly.steamstatic.com",
                "community.cloudflare.steamstatic.com")
            .contains(host)) {
      for (String mirror :
          new String[] {
            "community.fastly.steamstatic.com",
            "community.cloudflare.steamstatic.com",
            "community.akamai.steamstatic.com"
          }) urls.add("https://" + mirror + u.getFile());
    } else if ("https".equals(u.getProtocol())
        && java.util.Arrays.asList(
                "cdn.steamstatic.com",
                "cdn.akamai.steamstatic.com",
                "cdn.cloudflare.steamstatic.com")
            .contains(host)) {
      for (String mirror :
          new String[] {
            "cdn.akamai.steamstatic.com", "cdn.cloudflare.steamstatic.com", "cdn.steamstatic.com"
          }) urls.add("https://" + mirror + u.getFile());
    }
    return new ArrayList<>(urls);
  }

  Path getDiskCacheFile(String imageUrl) throws IOException {
    try {
      byte[] digest =
          java.security.MessageDigest.getInstance("SHA-256")
              .digest(imageUrl.getBytes(StandardCharsets.UTF_8));
      StringBuilder fileName = new StringBuilder(digest.length * 2);
      for (byte value : digest) fileName.append(String.format("%02x", value & 0xff));
      return diskCacheDirectory.resolve(fileName + ".png");
    } catch (java.security.NoSuchAlgorithmException e) {
      throw new IOException("SHA-256 is unavailable for the image cache.", e);
    }
  }

  boolean isCachedOnDisk(String imageUrl) {
    try {
      return Files.isRegularFile(getDiskCacheFile(imageUrl));
    } catch (IOException e) {
      System.err.println("Could not check the image cache: " + e.getMessage());
      return false;
    }
  }
}
