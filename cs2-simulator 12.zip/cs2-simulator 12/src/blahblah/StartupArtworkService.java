package blahblah;

import blahblah.hGui.*;
import java.awt.*;
import java.awt.event.*;
import java.awt.image.BufferedImage;
import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.Set;
import javax.swing.*;

/** Startup Artwork Service: focused feature implementation. */
final class StartupArtworkService {
  private final hGui app;

  StartupArtworkService(hGui app) {
    this.app = app;
  }

  void addStartupArtworkJob(
      Map<String, StartupArtworkJob> jobs, String key, String primary, String fallback) {
    if (primary != null && primary.startsWith("https://"))
      jobs.putIfAbsent(primary, new StartupArtworkJob(key, primary, fallback));
  }

  List<StartupArtworkJob> buildStartupArtworkManifest() {
    // Deduplicate by requested URL: aliases/StatTrak/Souvenir never redownload the same PNG.
    Map<String, StartupArtworkJob> jobs = new LinkedHashMap<>();
    for (CaseType ct : CaseType.values())
      app.startupArtworkService.addStartupArtworkJob(
          jobs, "case-selector-" + ct.id, ct.imageUrl, null);
    if (app.cs2ShellEnabled) {
      for (CaseType ct : CaseType.values()) {
        String[] info = hGui.CS2_KEY_CATALOG.get(ct.catalogCrateName());
        if (app.containerInventoryService.requiresOwnedKey(ct) && info != null)
          app.startupArtworkService.addStartupArtworkJob(jobs, "case-key-" + ct.id, info[1], null);
      }
      for (Map.Entry<String, String> item : hGui.CS2_DEFAULT_WEAPONS.entrySet())
        app.startupArtworkService.addStartupArtworkJob(
            jobs, "cs2-stock-" + item.getKey(), item.getValue(), null);
    }
    app.startupArtworkService.addStartupArtworkJob(
        jobs, "tool-name-tag", InventoryToolsService.TAG_IMAGE, null);
    app.startupArtworkService.addStartupArtworkJob(
        jobs, "tool-storage", InventoryToolsService.STORAGE_IMAGE, null);
    Set<String> names = app.startupPriceService.getStartupArtworkNames();
    for (String name : names) {
      SkinMetadata metadata = app.artworkService.getArtworkMetadata(name);
      app.startupArtworkService.addStartupArtworkJob(
          jobs, name, metadata == null ? null : metadata.imageUrl, null);
    }
    for (String name : names) {
      SkinMetadata metadata = app.artworkService.getArtworkMetadata(name);
      String standard = metadata == null ? null : metadata.imageUrl;
      for (String condition : app.floatRules.getAvailableConditions(name)) {
        String wear = app.artworkService.getWearImageUrl(name, condition);
        if (wear != null)
          app.startupArtworkService.addStartupArtworkJob(
              jobs, app.artworkService.getSkinArtworkKey(name, condition), wear, standard);
      }
    }
    return new ArrayList<>(jobs.values());
  }

  StartupArtworkResult preloadStartupArtworkJob(StartupArtworkJob job) {
    String[] urls =
        job.fallback == null || job.fallback.equals(job.primary)
            ? new String[] {job.primary}
            : new String[] {job.primary, job.fallback};
    for (String url : urls) {
      if (Thread.currentThread().isInterrupted()) return new StartupArtworkResult(false, false);
      if (url == null || !url.startsWith("https://")) continue;
      Long retry = app.unavailableRemoteImageUrls.get(url);
      if (retry != null && retry > System.currentTimeMillis()) continue;
      try {
        BufferedImage image = app.imageRepository.readRemoteCachedImage(url);
        if (!app.imageRepository.isCachedOnDisk(url))
          throw new IOException("Could not retain downloaded PNG in the automatic cache");
        // RAM remains bounded; all PNGs stay downloaded/validated on disk, not thousands of full
        // decoded images in RAM.
        app.imageRepository.put(job.key, image);
        app.startupResolvedArtworkUrls.put(job.primary, url);
        app.startupArtworkUnavailableDetails.remove(job.key);
        if (!url.equals(job.primary))
          app.startupArtworkFallbackDetails.put(
              job.key,
              "Genuine-wear PNG unavailable; standard online PNG used.\nRequested: "
                  + job.primary
                  + "\nUsed: "
                  + url);
        else app.startupArtworkFallbackDetails.remove(job.key);
        return new StartupArtworkResult(true, !url.equals(job.primary));
      } catch (IOException ex) {
        app.unavailableRemoteImageUrls.put(url, System.currentTimeMillis() + 300000L);
      }
    }
    app.startupArtworkUnavailableDetails.put(
        job.key,
        "Could not load requested PNG: "
            + job.primary
            + (job.fallback == null ? "" : "\nFallback also unavailable: " + job.fallback));
    return new StartupArtworkResult(false, false);
  }

  void updateStartupArtworkProgress(int completed) {
    app.startupScreen.setStartupProgress(
        45 + (int) Math.round(43.0 * completed / Math.max(1, app.startupArtworkTotal)),
        "Skin PNGs loaded: " + app.startupArtworkLoaded + " / " + app.startupArtworkTotal);
  }

  void preloadStartupArtwork() throws InterruptedException {
    if (SwingUtilities.isEventDispatchThread())
      throw new IllegalStateException("PNG preload must run off the EDT");
    List<StartupArtworkJob> jobs = app.startupArtworkService.buildStartupArtworkManifest();
    app.startupArtworkTotal = jobs.size();
    app.startupArtworkLoaded = 0;
    app.startupArtworkFailed = 0;
    app.startupArtworkFallbacks = 0;
    app.startupArtworkFallbackDetails.clear();
    app.startupArtworkUnavailableDetails.clear();
    app.startupArtworkService.updateStartupArtworkProgress(0);
    java.util.concurrent.ExecutorService downloads =
        java.util.concurrent.Executors.newFixedThreadPool(
            8,
            task -> {
              Thread thread = new Thread(task, "startup-PNG-preload");
              thread.setDaemon(true);
              return thread;
            });
    java.util.concurrent.CompletionService<StartupArtworkResult> finished =
        new java.util.concurrent.ExecutorCompletionService<>(downloads);
    int submitted = 0, completed = 0;
    try {
      // Keep at most eight downloads in flight rather than queueing the entire catalog.
      while (submitted < Math.min(8, jobs.size())) {
        final StartupArtworkJob job = jobs.get(submitted++);
        finished.submit(() -> app.startupArtworkService.preloadStartupArtworkJob(job));
      }
      while (completed < jobs.size()) {
        StartupArtworkResult result;
        try {
          result = finished.take().get();
        } catch (java.util.concurrent.ExecutionException ex) {
          result = new StartupArtworkResult(false, false);
        }
        if (result.loaded) app.startupArtworkLoaded++;
        else app.startupArtworkFailed++;
        if (result.fallback) app.startupArtworkFallbacks++;
        completed++;
        app.startupArtworkService.updateStartupArtworkProgress(completed);
        if (submitted < jobs.size()) {
          final StartupArtworkJob job = jobs.get(submitted++);
          finished.submit(() -> app.startupArtworkService.preloadStartupArtworkJob(job));
        }
      }
      if (jobs.isEmpty())
        app.startupScreen.setStartupProgress(
            88, "Skin PNGs loaded: 0 / 0 (no configured online artwork)");
      app.armouryArtworkCache.warm();
      app.openingArtworkService.warmAllContainerArtwork();
      if (app.cs2ShellEnabled) {
        for (CaseType ct : CaseType.values()) {
          String[] info = hGui.CS2_KEY_CATALOG.get(ct.catalogCrateName());
          if (app.containerInventoryService.requiresOwnedKey(ct) && info != null)
            app.startupArtworkService.warmStartupCachedArtwork("case-key-" + ct.id, info[1]);
        }
        for (Map.Entry<String, String> item : hGui.CS2_DEFAULT_WEAPONS.entrySet())
          app.startupArtworkService.warmStartupCachedArtwork(
              "cs2-stock-" + item.getKey(), item.getValue());
      }
      if (app.cs2ShellEnabled) app.cs2EquipmentScreens.warmCs2KeyArtwork();
      app.startupArtworkService.warmStartupOpeningArtwork();
      app.startupArtworkService.warmStartupCachedArtwork(
          "tool-name-tag", InventoryToolsService.TAG_IMAGE);
      app.startupArtworkService.warmStartupCachedArtwork(
          "tool-storage", InventoryToolsService.STORAGE_IMAGE);
      app.openingArtworkService.saveArtworkLoadReport();
    } finally {
      downloads.shutdownNow();
    }
  }

  void warmStartupCachedArtwork(String key, String primary) {
    if (primary == null) return;
    String resolved = app.startupResolvedArtworkUrls.get(primary);
    if (resolved == null || !app.imageRepository.isCachedOnDisk(resolved)) return;
    try {
      app.imageRepository.put(key, app.imageRepository.readRemoteCachedImage(resolved));
    } catch (IOException ignored) {
    }
  }

  void warmStartupOpeningArtwork() {
    app.openingArtworkService.prepareOpeningArtwork(app.currentCase);
    app.startupScreen.setStartupProgress(
        93,
        "PNG caches ready. Container PNGs retained: "
            + app.containerArtwork.size()
            + " / "
            + CaseType.values().length
            + "; opening artwork: "
            + (app.currentCase == null ? "no container selected" : app.currentCase.name));
  }

  Map<CaseType, Double> fetchRoundedMarketCasePrices() {
    Map<CaseType, Double> prices = new LinkedHashMap<>();
    long now = System.currentTimeMillis();
    CaseType[] caseTypes = CaseType.values();
    int caseIndex = 0;
    for (CaseType caseType : caseTypes) {
      caseIndex++;
      if (app.startupLoadingOverlay != null && app.startupLoadingOverlay.isVisible()) {
        int progress = 40;
        app.startupScreen.setStartupProgress(
            progress, "Checking case prices (" + caseIndex + " of " + caseTypes.length + ")...");
      }
      String priceKey = app.startupArtworkService.caseQuotePreferenceKey("p", caseType);
      String timeKey = app.startupArtworkService.caseQuotePreferenceKey("t", caseType);
      long cachedAt = app.marketPricePreferences.getLong(timeKey, 0L);
      double cachedPrice = app.marketPricePreferences.getDouble(priceKey, 0.0);

      IOException feedFailures = null;
      Double marketPrice = null;
      for (String provider : new String[] {"csfloat"}) {
        try {
          String snapshot = app.publicPriceFeeds.getPublicPriceSnapshot(provider);
          marketPrice =
              app.publicPriceFeeds.findCsfloatSnapshotPrice(
                  snapshot, caseType.catalogCrateName(), null);
          if (marketPrice != null) break;
        } catch (IOException e) {
          if (feedFailures == null) feedFailures = e;
          else feedFailures.addSuppressed(e);
        }
      }
      if (marketPrice == null || !Double.isFinite(marketPrice) || marketPrice <= 0.0) {
        if (feedFailures != null) {
          System.err.println(
              "Could not load a real market price for "
                  + caseType.catalogCrateName()
                  + ": "
                  + feedFailures.getMessage());
        } else {
          System.err.println(
              "Public price sources have no case price for "
                  + caseType.catalogCrateName()
                  + "; a verified cached quote is required for purchasing.");
        }
        if (cachedPrice > 0 && Double.isFinite(cachedPrice)) {
          prices.put(caseType, cachedPrice);
          app.caseQuoteDescriptions.put(
              caseType.id,
              "Cached CSFloat USD quote • "
                  + new java.util.Date(cachedAt)
                  + " • live feed unavailable");
        } else
          app.caseQuoteDescriptions.put(
              caseType.id, "No verified USD market quote available; purchasing disabled");
        continue;
      }
      double roundedPrice = Math.max(0.01, app.coreUtilities.money(marketPrice).doubleValue());
      prices.put(caseType, roundedPrice);
      app.marketPricePreferences.putDouble(priceKey, roundedPrice);
      app.marketPricePreferences.putLong(timeKey, now);
      app.caseQuoteDescriptions.put(
          caseType.id,
          "CSFloat USD listing quote • " + new java.util.Date(now) + " • excludes key");
    }
    return prices;
  }

  String caseQuotePreferenceKey(String kind, CaseType ct) {
    return "case.usd.v4."
        + kind
        + "."
        + java.util.UUID.nameUUIDFromBytes(ct.catalogCrateName().getBytes(StandardCharsets.UTF_8));
  }

  boolean hasPurchasableCaseQuote(CaseType ct) {
    return !app.caseQuotesResolved || app.verifiedCaseQuotes.contains(ct.id);
  }

  String caseQuoteLabel(CaseType ct) {
    return app.startupArtworkService.hasPurchasableCaseQuote(ct)
        ? String.format("$%.2f", ct.price)
        : "Quote unavailable";
  }

  void applyMarketCasePrices(Map<CaseType, Double> prices) {
    app.verifiedCaseQuotes.clear();
    for (CaseType ct : prices.keySet()) app.verifiedCaseQuotes.add(ct.id);
    app.caseQuotesResolved = true;
    for (CaseType ct : CaseType.values()) ContainerMarketService.publish(ct, prices.get(ct));
    for (Map.Entry<CaseType, Double> entry : prices.entrySet()) {
      entry.getKey().price = entry.getValue();
      ArrayList<MarketListing> bucket =
          app.globalMarketListings.get(entry.getKey().catalogCrateName());
      if (bucket != null)
        for (MarketListing lot : bucket)
          if (!app.marketInitialized && !lot.isPlayerListing) {
            lot.setPrice(entry.getValue());
            lot.item.price = app.coreUtilities.money(entry.getValue());
          }
    }
    if (app.openCrateButton != null) {
      app.openCrateButton.setText(
          String.format(
              "OPEN CASE  $%.2f", app.developerTools.getCaseOpeningCost(app.currentCase)));
      app.openCrateButton.setEnabled(
          !app.isAnimating
              && app.balance >= app.developerTools.getCaseOpeningCost(app.currentCase));
    }
    app.uiWidgets.updateBalanceLabel();
    app.containerBrowserScreen.rebuildCaseBoxes();
    app.collectionService.updateSelectedCaseRoi();
    if (app.cs2ShellEnabled && !app.exchangeContainers.isEmpty()) {
      app.exchangeStockService.seedExchangeContainers();
      app.exchangeStockService.rebuildExchangeIndex();
      app.marketStockService.invalidateGroupedMarketListingsCache();
    }
  }

  void showStartupError(String message) {
    System.err.println(message);
    app.startupWorkStarted = false;
    app.startupScreen.finishStartupLoading();
    app.mainTabs.setEnabledAt(4, true);
    app.openCrateButton.setEnabled(true);
    app.autoOpenButton.setEnabled(true);
    app.caseRoiLabel.setText("Marketplace setup failed; see the startup error for details.");
    JOptionPane.showMessageDialog(app, message, "Startup Error", JOptionPane.ERROR_MESSAGE);
  }
}
