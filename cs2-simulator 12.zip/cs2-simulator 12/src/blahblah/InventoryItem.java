package blahblah;

import blahblah.hGui.*;
import java.awt.*;
import java.awt.event.*;
import java.math.BigDecimal;
import java.util.ArrayList;
import javax.swing.*;

/** Extracted reusable model or widget; behavior retained from the original source. */
public class InventoryItem {
  ImageIcon image;
  String name, condition, rarity;
  BigDecimal price;
  double itemFloat;
  boolean isStattrak;
  int patternID;
  String blueGemTier;
  double basePrice;
  String collection;
  long createdAt;
  String currentOwner;
  String itemId;
  ArrayList<ItemHistoryEntry> history;

  transient ImageIcon thumb110x75;
  transient ImageIcon thumb130x88;

  public InventoryItem(
      ImageIcon image,
      String name,
      String condition,
      String rarity,
      BigDecimal price,
      double itemFloat,
      boolean isStattrak,
      int patternID,
      String blueGemTier,
      double basePrice) {
    this(
        image,
        name,
        condition,
        rarity,
        price,
        itemFloat,
        isStattrak,
        patternID,
        blueGemTier,
        basePrice,
        false);
  }

  InventoryItem(
      ImageIcon image,
      String name,
      String condition,
      String rarity,
      BigDecimal price,
      double itemFloat,
      boolean isStattrak,
      int patternID,
      String blueGemTier,
      double basePrice,
      boolean lightweightMarketItem) {
    this.image = image;
    this.name = name;
    this.condition = condition;
    this.rarity = rarity;
    this.price = price;
    this.itemFloat = itemFloat;
    this.isStattrak = isStattrak;
    this.patternID = patternID;
    this.blueGemTier = blueGemTier;
    this.basePrice = basePrice;
    this.createdAt = System.currentTimeMillis();
    this.currentOwner = "UNASSIGNED";
    this.itemId = null;
    this.history = lightweightMarketItem ? null : new ArrayList<>();
  }

  public ImageIcon getThumb110() {
    if (thumb110x75 == null && image != null) {
      Image src = image.getImage();
      int w = src.getWidth(null), h = src.getHeight(null);
      if (w > 0 && h > 0) {
        double s = Math.min(110.0 / w, 75.0 / h);
        thumb110x75 =
            new ImageIcon(
                HighQualityImages.fit(src, Math.max(1, (int) (w * s)), Math.max(1, (int) (h * s))));
      } else {
        thumb110x75 = image;
      }
    }
    return thumb110x75 != null ? thumb110x75 : image;
  }

  public ImageIcon getThumb130() {
    if (thumb130x88 == null && image != null) {
      Image src = image.getImage();
      int w = src.getWidth(null), h = src.getHeight(null);
      if (w > 0 && h > 0) {
        double s = Math.min(130.0 / w, 88.0 / h);
        thumb130x88 =
            new ImageIcon(
                HighQualityImages.fit(src, Math.max(1, (int) (w * s)), Math.max(1, (int) (h * s))));
      } else {
        thumb130x88 = image;
      }
    }
    return thumb130x88 != null ? thumb130x88 : image;
  }
}
