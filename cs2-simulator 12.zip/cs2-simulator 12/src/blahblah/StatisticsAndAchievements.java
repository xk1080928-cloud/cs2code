package blahblah;

import blahblah.hGui.*;
import java.awt.*;
import java.awt.event.*;
import javax.swing.*;

/** Statistics And Achievements: focused feature implementation. */
final class StatisticsAndAchievements {
  private final hGui app;

  StatisticsAndAchievements(hGui app) {
    this.app = app;
  }

  void showStatsWindow() {
    JFrame statsFrame = new JFrame("Opening Statistics");
    statsFrame.setSize(760, 640);
    statsFrame.setLocationRelativeTo(app);
    statsFrame.setLayout(new BorderLayout());

    statsFrame.setAlwaysOnTop(true);

    JPanel headerPanel = new JPanel();
    headerPanel.setBackground(new Color(30, 30, 35));
    headerPanel.setBorder(BorderFactory.createEmptyBorder(15, 15, 15, 15));

    JLabel titleLabel = new JLabel("Opening Statistics", SwingConstants.CENTER);
    titleLabel.setFont(new Font("Arial", Font.BOLD, 24));
    titleLabel.setForeground(Color.WHITE);
    headerPanel.add(titleLabel);

    statsFrame.add(headerPanel, BorderLayout.NORTH);

    int totalOpenings = app.totalCrates + app.totalArmouryRedeems;
    JPanel statsPanel = new JPanel(new GridLayout(10, 2, 10, 10));
    statsPanel.setBackground(new Color(35, 35, 40));
    statsPanel.setBorder(BorderFactory.createEmptyBorder(20, 20, 20, 20));

    app.statisticsAndAchievements.addStatRow(
        statsPanel, "Case Opens:", String.valueOf(app.totalCrates), Color.CYAN);
    app.statisticsAndAchievements.addStatRow(
        statsPanel, "Armoury Redeems:", String.valueOf(app.totalArmouryRedeems), Theme.GOLD);
    app.statisticsAndAchievements.addStatRow(
        statsPanel, "Total Openings:", String.valueOf(totalOpenings), Color.WHITE);
    app.statisticsAndAchievements.addStatRow(
        statsPanel, "Total Milspecs:", String.valueOf(app.totMil), Color.BLUE);
    app.statisticsAndAchievements.addStatRow(
        statsPanel, "Total Restricteds:", String.valueOf(app.totRes), new Color(128, 0, 128));
    app.statisticsAndAchievements.addStatRow(
        statsPanel, "Total Classifieds:", String.valueOf(app.totClass), Color.MAGENTA);
    app.statisticsAndAchievements.addStatRow(
        statsPanel, "Total Coverts:", String.valueOf(app.totCov), Color.RED);
    app.statisticsAndAchievements.addStatRow(
        statsPanel, "Total Knives:", String.valueOf(app.totKnife), Color.YELLOW);
    app.statisticsAndAchievements.addStatRow(
        statsPanel, "Total Gloves:", String.valueOf(app.totGlove), Color.YELLOW);
    app.statisticsAndAchievements.addStatRow(
        statsPanel,
        "Lowest Float:",
        String.format("%.10f", app.lowestFloat),
        new Color(100, 220, 255));

    statsFrame.add(statsPanel, BorderLayout.CENTER);

    JPanel percentagesPanel = new JPanel(new GridLayout(0, 1, 5, 5));
    percentagesPanel.setBackground(new Color(35, 35, 40));
    percentagesPanel.setBorder(
        BorderFactory.createCompoundBorder(
            BorderFactory.createTitledBorder(
                BorderFactory.createLineBorder(Color.GRAY),
                "Drop Rates",
                0,
                0,
                new Font("Arial", Font.BOLD, 14),
                Color.WHITE),
            BorderFactory.createEmptyBorder(10, 10, 10, 10)));

    if (totalOpenings > 0) {
      app.statisticsAndAchievements.addPercentageRow(
          percentagesPanel,
          "Industrial:",
          app.totIndustrial,
          totalOpenings,
          new Color(110, 190, 110));
      app.statisticsAndAchievements.addPercentageRow(
          percentagesPanel, "Milspec:", app.totMil, totalOpenings, Color.BLUE);
      app.statisticsAndAchievements.addPercentageRow(
          percentagesPanel,
          "Distinguished:",
          app.totDistinguished,
          totalOpenings,
          Theme.RARITY_MILSPEC);
      app.statisticsAndAchievements.addPercentageRow(
          percentagesPanel, "Restricted:", app.totRes, totalOpenings, new Color(128, 0, 128));
      app.statisticsAndAchievements.addPercentageRow(
          percentagesPanel,
          "Exceptional:",
          app.totExceptional,
          totalOpenings,
          Theme.RARITY_RESTRICTED);
      app.statisticsAndAchievements.addPercentageRow(
          percentagesPanel, "Classified:", app.totClass, totalOpenings, Color.MAGENTA);
      app.statisticsAndAchievements.addPercentageRow(
          percentagesPanel, "Superior:", app.totSuperior, totalOpenings, Theme.RARITY_CLASSIFIED);
      app.statisticsAndAchievements.addPercentageRow(
          percentagesPanel, "Covert:", app.totCov, totalOpenings, Color.RED);
      app.statisticsAndAchievements.addPercentageRow(
          percentagesPanel, "Master:", app.totMaster, totalOpenings, Theme.RARITY_COVERT);
      app.statisticsAndAchievements.addPercentageRow(
          percentagesPanel, "Knives:", app.totKnife, totalOpenings, Color.YELLOW);
      app.statisticsAndAchievements.addPercentageRow(
          percentagesPanel, "Gloves:", app.totGlove, totalOpenings, Color.YELLOW);
    } else {
      JLabel noDataLabel = new JLabel("No opening data yet.", SwingConstants.CENTER);
      noDataLabel.setForeground(Color.GRAY);
      percentagesPanel.add(noDataLabel);
    }

    statsFrame.add(percentagesPanel, BorderLayout.SOUTH);
    statsFrame.setVisible(true);

    javax.swing.Timer timer =
        new javax.swing.Timer(
            100,
            e -> {
              statsFrame.setAlwaysOnTop(false);
              statsFrame.toFront();
              statsFrame.requestFocus();
            });
    timer.setRepeats(false);
    timer.start();
  }

  void addStatRow(JPanel panel, String label, String value, Color color) {
    JLabel labelComp = new JLabel(label);
    labelComp.setFont(new Font("Arial", Font.BOLD, 16));
    labelComp.setForeground(Color.WHITE);

    JLabel valueComp = new JLabel(value);
    valueComp.setFont(new Font("Arial", Font.BOLD, 16));
    valueComp.setForeground(color);
    valueComp.setHorizontalAlignment(SwingConstants.RIGHT);

    panel.add(labelComp);
    panel.add(valueComp);
  }

  void addPercentageRow(JPanel panel, String label, int count, int total, Color color) {
    double percentage = (count * 100.0) / total;
    JLabel row = new JLabel(String.format("%s %d (%.2f%%)", label, count, percentage));
    row.setFont(new Font("Arial", Font.PLAIN, 13));
    row.setForeground(color);
    panel.add(row);
  }

  void recordArmouryOpening(String skinRarity, String skinName, double itemFloat) {
    app.totalArmouryRedeems++;
    app.activitySimulationService.addUnboxedSkin(skinName);
    if (!app.itemMetadataService.isAgentSkin(skinName) && itemFloat < app.lowestFloat)
      app.lowestFloat = itemFloat;

    switch (skinRarity) {
      case "Industrial":
        app.totIndustrial++;
        break;
      case "Milspec":
        app.totMil++;
        break;
      case "Restricted":
        app.totRes++;
        break;
      case "Classified":
        app.totClass++;
        break;
      case "Covert":
        app.totCov++;
        break;
      case "Distinguished":
        app.totDistinguished++;
        break;
      case "Exceptional":
        app.totExceptional++;
        break;
      case "Superior":
        app.totSuperior++;
        break;
      case "Master":
        app.totMaster++;
        break;
    }
  }

  void checkUnboxingAchievements(
      String item,
      String selectedSkinName,
      double bonusPrice,
      double itemFloat,
      String blueGemTier,
      int totMil,
      int totRes,
      int totClass,
      int totCov,
      int totKnife,
      boolean isStattrak) {
    app.achievements.get("open_100").progress = app.totalCrates;
    app.achievements.get("open_500").progress = app.totalCrates;
    app.achievements.get("open_1000").progress = app.totalCrates;
    app.achievements.get("open_2500").progress = app.totalCrates;
    app.achievements.get("open_5000").progress = app.totalCrates;
    app.achievements.get("open_10000").progress = app.totalCrates;
    app.achievements.get("open_25000").progress = app.totalCrates;
    app.achievements.get("glove_collector").progress = app.totGlove;
    app.achievements.get("glove_master").progress = app.totGlove;
    app.achievements.get("knife_5").progress = totKnife;
    app.achievements.get("knife_10").progress = totKnife;

    if (app.totalCrates >= 100 && !app.achievements.get("open_100").isUnlocked)
      app.achievementScreen.unlockAchievement("open_100");
    if (app.totalCrates >= 500 && !app.achievements.get("open_500").isUnlocked)
      app.achievementScreen.unlockAchievement("open_500");
    if (app.totalCrates >= 1000 && !app.achievements.get("open_1000").isUnlocked)
      app.achievementScreen.unlockAchievement("open_1000");
    if (app.totalCrates >= 2500 && !app.achievements.get("open_2500").isUnlocked)
      app.achievementScreen.unlockAchievement("open_2500");
    if (app.totalCrates >= 5000 && !app.achievements.get("open_5000").isUnlocked)
      app.achievementScreen.unlockAchievement("open_5000");
    if (app.totalCrates >= 10000 && !app.achievements.get("open_10000").isUnlocked)
      app.achievementScreen.unlockAchievement("open_10000");
    if (app.totalCrates >= 25000 && !app.achievements.get("open_25000").isUnlocked)
      app.achievementScreen.unlockAchievement("open_25000");

    if (item.contains("Milspec") && totMil == 1 && !app.achievements.get("first_blue").isUnlocked)
      app.achievementScreen.unlockAchievement("first_blue");
    if (item.contains("Restricted")
        && totRes == 1
        && !app.achievements.get("first_purple").isUnlocked)
      app.achievementScreen.unlockAchievement("first_purple");
    if (item.contains("Classified")
        && totClass == 1
        && !app.achievements.get("first_pink").isUnlocked)
      app.achievementScreen.unlockAchievement("first_pink");
    if (item.contains("Covert") && totCov == 1 && !app.achievements.get("first_red").isUnlocked)
      app.achievementScreen.unlockAchievement("first_red");
    if (item.contains("Knife")
        && !item.contains("Gloves")
        && totKnife == 1
        && !app.achievements.get("first_knife").isUnlocked)
      app.achievementScreen.unlockAchievement("first_knife");
    if (item.contains("Gloves")
        && app.totGlove == 1
        && !app.achievements.get("first_glove").isUnlocked)
      app.achievementScreen.unlockAchievement("first_glove");
    if (app.totGlove >= 10 && !app.achievements.get("glove_collector").isUnlocked)
      app.achievementScreen.unlockAchievement("glove_collector");
    if (app.totGlove >= 25 && !app.achievements.get("glove_master").isUnlocked)
      app.achievementScreen.unlockAchievement("glove_master");
    if (totKnife >= 5 && !app.achievements.get("knife_5").isUnlocked)
      app.achievementScreen.unlockAchievement("knife_5");
    if (totKnife >= 10 && !app.achievements.get("knife_10").isUnlocked)
      app.achievementScreen.unlockAchievement("knife_10");

    if (item.contains("Gloves")
        && bonusPrice >= 2000
        && !app.achievements.get("rare_gloves").isUnlocked)
      app.achievementScreen.unlockAchievement("rare_gloves");
    if (selectedSkinName.equals("Sport Gloves | Hedge Maze")
        && !app.achievements.get("hedge_maze").isUnlocked)
      app.achievementScreen.unlockAchievement("hedge_maze");
    if (selectedSkinName.equals("Specialist Gloves | Crimson Kimono")
        && !app.achievements.get("crimson_kimono").isUnlocked)
      app.achievementScreen.unlockAchievement("crimson_kimono");
    if (selectedSkinName.equals("Sport Gloves | Pandora's Box")
        && !app.achievements.get("pandoras_box").isUnlocked)
      app.achievementScreen.unlockAchievement("pandoras_box");
    if (selectedSkinName.equals("AWP | Lightning Strike")
        && !app.achievements.get("lightning_strike").isUnlocked)
      app.achievementScreen.unlockAchievement("lightning_strike");
    if (selectedSkinName.equals("AK-47 | Fire Serpent")
        && !app.achievements.get("fire_serpent").isUnlocked)
      app.achievementScreen.unlockAchievement("fire_serpent");

    if (bonusPrice >= 1000 && !app.achievements.get("unbox_1000").isUnlocked)
      app.achievementScreen.unlockAchievement("unbox_1000");
    if (bonusPrice >= 5000 && !app.achievements.get("unbox_5000").isUnlocked)
      app.achievementScreen.unlockAchievement("unbox_5000");
    if (bonusPrice >= 10000 && !app.achievements.get("unbox_10000").isUnlocked)
      app.achievementScreen.unlockAchievement("unbox_10000");
    if (bonusPrice >= 50000 && !app.achievements.get("unbox_50000").isUnlocked)
      app.achievementScreen.unlockAchievement("unbox_50000");
    if (bonusPrice >= 250000 && !app.achievements.get("unbox_250000").isUnlocked)
      app.achievementScreen.unlockAchievement("unbox_250000");

    if (app.inventoryValue >= 50000 && !app.achievements.get("inventory_50k").isUnlocked)
      app.achievementScreen.unlockAchievement("inventory_50k");
    if (app.inventoryValue >= 100000 && !app.achievements.get("inventory_100k").isUnlocked)
      app.achievementScreen.unlockAchievement("inventory_100k");
    if (app.inventoryValue >= 500000 && !app.achievements.get("inventory_500k").isUnlocked)
      app.achievementScreen.unlockAchievement("inventory_500k");
    if (app.inventoryValue >= 1000000 && !app.achievements.get("inventory_1m").isUnlocked)
      app.achievementScreen.unlockAchievement("inventory_1m");
    if (app.inventoryValue >= 5000000 && !app.achievements.get("inventory_5m").isUnlocked)
      app.achievementScreen.unlockAchievement("inventory_5m");
    if (app.balance >= 10000 && !app.achievements.get("balance_10k").isUnlocked)
      app.achievementScreen.unlockAchievement("balance_10k");

    if (itemFloat < 0.001 && !app.achievements.get("float_0001").isUnlocked)
      app.achievementScreen.unlockAchievement("float_0001");
    if (itemFloat < 0.0001 && !app.achievements.get("float_00001").isUnlocked)
      app.achievementScreen.unlockAchievement("float_00001");
    if (itemFloat < 0.00001 && !app.achievements.get("float_000001").isUnlocked)
      app.achievementScreen.unlockAchievement("float_000001");

    if (blueGemTier != null && !app.achievements.get("blue_gem").isUnlocked)
      app.achievementScreen.unlockAchievement("blue_gem");
    if (blueGemTier != null
        && blueGemTier.contains("T1")
        && !app.achievements.get("blue_gem_t1").isUnlocked)
      app.achievementScreen.unlockAchievement("blue_gem_t1");
    if (blueGemTier != null
        && item.contains("Knife")
        && !app.achievements.get("blue_gem_knife").isUnlocked)
      app.achievementScreen.unlockAchievement("blue_gem_knife");

    if (selectedSkinName.contains("Doppler") && !app.achievements.get("doppler").isUnlocked)
      app.achievementScreen.unlockAchievement("doppler");
    if (selectedSkinName.contains("Sapphire") && !app.achievements.get("sapphire").isUnlocked)
      app.achievementScreen.unlockAchievement("sapphire");
    if (selectedSkinName.contains("Ruby") && !app.achievements.get("ruby").isUnlocked)
      app.achievementScreen.unlockAchievement("ruby");
    if (selectedSkinName.contains("Black Pearl") && !app.achievements.get("black_pearl").isUnlocked)
      app.achievementScreen.unlockAchievement("black_pearl");

    if (isStattrak && item.contains("Knife") && !app.achievements.get("stattrak_knife").isUnlocked)
      app.achievementScreen.unlockAchievement("stattrak_knife");
  }
}
