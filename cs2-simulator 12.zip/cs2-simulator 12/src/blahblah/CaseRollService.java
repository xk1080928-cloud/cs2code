package blahblah;

import blahblah.hGui.*;
import java.awt.*;
import java.awt.event.*;
import javax.swing.*;

/** Case Roll Service: focused feature implementation. */
final class CaseRollService {
  private final hGui app;

  CaseRollService(hGui app) {
    this.app = app;
  }

  public void writeStats() {
    app.totalMilspec.setText("Total Milspecs: " + app.totMil);
    app.totalRestrict.setText("Total Restricteds: " + app.totRes);
    app.totalClass.setText("Total Classifieds: " + app.totClass);
    app.totalCovert.setText("Total Coverts: " + app.totCov);
    app.totalKnife.setText("Total Knifes: " + app.totKnife);
    app.totalGlove.setText("Total Gloves: " + app.totGlove);
  }

  public static CrateRollResult crateItem(CaseType caseType) {
    if (caseType != null && caseType.isSouvenir) {
      String tier = CaseRollService.rollSouvenirTier(caseType);
      Color color;
      switch (tier) {
        case "Consumer":
          color = new Color(176, 195, 217);
          break;
        case "Industrial":
          color = new Color(94, 152, 217);
          break;
        case "Milspec":
          color = Theme.RARITY_MILSPEC;
          break;
        case "Restricted":
          color = Theme.RARITY_RESTRICTED;
          break;
        case "Classified":
          color = Theme.RARITY_CLASSIFIED;
          break;
        case "Covert":
          color = Theme.RARITY_COVERT;
          break;
        default:
          throw new IllegalStateException("Unsupported souvenir rarity: " + tier);
      }
      return new CrateRollResult(tier, color, false, 1.0);
    }
    String item;
    boolean statTrak = hGui.random.nextInt(10) == 0;
    int itemNum =
        caseType != null && caseType.isTerminal && caseType.rareDropNames.isEmpty()
            ? 260 + hGui.random.nextInt(99740)
            : hGui.random.nextInt(100000);
    // Case odds: Gold 0.26%, Covert 0.64%, Classified 3.20%, Restricted 15.98%, Mil-Spec 79.92%.

    int goldThreshold = 260;
    int covertThreshold = goldThreshold + 640;
    int classifiedThreshold = covertThreshold + 3200;
    int restrictedThreshold = classifiedThreshold + 15980;

    if (itemNum < goldThreshold) {
      item = caseType.randomRareDropCategory();
      if ("Gloves".equals(item)) {
        item = "Gloves";
        statTrak = false;
      } else {
        item = "Knife";
      }
      return new CrateRollResult(item, Theme.RARITY_GOLD, statTrak, 1.0);
    } else if (itemNum < covertThreshold) {
      item = "Covert";
      return new CrateRollResult(item, Theme.RARITY_COVERT, statTrak, 1.0);
    } else if (itemNum < classifiedThreshold) {
      item = "Classified";
      return new CrateRollResult(item, Theme.RARITY_CLASSIFIED, statTrak, 1.0);
    } else if (itemNum < restrictedThreshold) {
      item = "Restricted";
      return new CrateRollResult(item, Theme.RARITY_RESTRICTED, statTrak, 1.0);
    } else {
      item = "Milspec";
      return new CrateRollResult(item, Theme.RARITY_MILSPEC, statTrak, 1.0);
    }
  }

  static double[] calculateCollectionTierOdds(boolean[] availableLowToHigh) {
    double[] odds = new double[availableLowToHigh.length];
    double nextWeight = 1.0;
    double totalWeight = 0.0;
    for (int i = 0; i < availableLowToHigh.length; i++) {
      if (!availableLowToHigh[i]) continue;
      odds[i] = nextWeight;
      totalWeight += nextWeight;
      nextWeight *= 0.2;
    }
    if (totalWeight <= 0.0) return odds;
    for (int i = 0; i < odds.length; i++) odds[i] /= totalWeight;
    return odds;
  }

  static double[] calculateCollectionTierOddsHighToLow(boolean[] availableLowToHigh) {
    double[] lowToHigh = CaseRollService.calculateCollectionTierOdds(availableLowToHigh);
    double[] highToLow = new double[lowToHigh.length];
    for (int i = 0; i < lowToHigh.length; i++) {
      highToLow[i] = lowToHigh[lowToHigh.length - 1 - i];
    }
    return highToLow;
  }

  static String rollSouvenirTier(CaseType caseType) {
    String[] tiers = {"Consumer", "Industrial", "Milspec", "Restricted", "Classified", "Covert"};
    boolean[] available = new boolean[tiers.length];
    for (int i = 0; i < tiers.length; i++) {
      available[i] =
          !caseType
              .regularDropNames
              .getOrDefault(tiers[i], java.util.Collections.emptyList())
              .isEmpty();
    }
    boolean hasAvailableTier = false;
    for (boolean tierAvailable : available) hasAvailableTier |= tierAvailable;
    if (!hasAvailableTier) {
      throw new IllegalStateException(
          "No verified souvenir rarity pool is available for " + caseType.name);
    }
    double[] weights = CaseRollService.calculateCollectionTierOdds(available);

    double roll = hGui.random.nextDouble();
    for (int i = 0; i < tiers.length; i++) {
      if (!available[i]) continue;
      roll -= weights[i];
      if (roll < 0.0) return tiers[i];
    }
    // Account for floating-point rounding at the end of the normalized curve.
    for (int i = tiers.length - 1; i >= 0; i--) if (available[i]) return tiers[i];
    throw new IllegalStateException("Souvenir rarity weights did not cover the roll.");
  }
}
