package blahblah;

import blahblah.hGui.*;
import java.awt.*;
import java.awt.event.*;
import javax.swing.*;

/** Embedded data kept in Java so no extra resource folder is required. */
final class ArmouryTradeUpCollectionsData {
  static final TradeUpCollection[] DATA = {
    new TradeUpCollection(
        "The Achroma Collection",
        new String[] {
          "MP9 | Dizzy",
          "PP-Bizon | Bizoom",
          "Dual Berettas | Silver Pour",
          "SSG 08 | Sans Comic",
          "SCAR-20 | Zinc",
          "M249 | Sleet",
          "P250 | Sleet",
          "Nova | Currents"
        },
        new String[] {
          "MAC-10 | Snow Splash",
          "MP5-SD | Snow Splash",
          "FAMAS | Vendetta",
          "M4A4 | Aeolian Dark",
          "R8 Revolver | Dark Chamber"
        },
        new String[] {
          "AUG | Creep",
          "P90 | Aeolian Light",
          "Desert Eagle | The Daily Deagle",
          "P2000 | Grip Tape"
        },
        new String[] {"AK-47 | Breakthrough", "Glock-18 | Trace Lock"},
        new String[] {"AWP | The End"},
        new String[0]),
    new TradeUpCollection(
        "Sport & Field Collection",
        new String[] {
          "MP5-SD | Savannah Halftone",
          "PP-Bizon | Cold Cell",
          "Tec-9 | Tiger Stencil",
          "MAG-7 | Wildwood",
          "FAMAS | Half Sleeve",
          "AK-47 | Olive Polycam"
        },
        new String[] {
          "USP-S | Alpine Camo", "SSG 08 | Zeno", "P250 | Small Game", "Nova | Yorkshire"
        },
        new String[] {
          "UMP-45 | Crimson Foil", "MP9 | Arctic Tri-Tone", "Five-SeveN | Heat Treated"
        },
        new String[] {"Glock-18 | AXIA", "Galil AR | Rainbow Spoon"},
        new String[] {"M4A1-S | Fade"}),
    new TradeUpCollection(
        "Overpass 2024 Collection",
        new String[] {
          "MP5-SD | Neon Squeezer",
          "P90 | Wash me",
          "Negev | Wall Bang",
          "M4A1-S | Wash me plz",
          "Five-SeveN | Midnight Paintover",
          "Desert Eagle | Tilted"
        },
        new String[] {
          "Nova | Wurst Holle",
          "MAC-10 | Pipsqueak",
          "Glock-18 | Teal Graf",
          "Galil AR | Metallic Squeezer"
        },
        new String[] {
          "XM1014 | Monster Melt", "Dual Berettas | Sweet Little Angels", "AUG | Eye of Zapems"
        },
        new String[] {"Zeus x27 | Dragon Snore", "AWP | Crakow!"},
        new String[] {"AK-47 | B the Monster"}),
    new TradeUpCollection(
        "Graphic Design Collection",
        new String[] {
          "SSG 08 | Halftone Whorl",
          "P2000 | Coral Halftone",
          "MP7 | Astrolabe",
          "M249 | Spectrogram",
          "Galil AR | NV",
          "FAMAS | Halftone Wash"
        },
        new String[] {
          "XM1014 | Halftone Shift",
          "SG 553 | Berry Gel Coat",
          "SCAR-20 | Wild Berry",
          "AK-47 | Crossfade"
        },
        new String[] {"P90 | Attack Vector", "M4A4 | Polysoup", "CZ75-Auto | Slalom"},
        new String[] {"Desert Eagle | Starcade", "AUG | Lil' Pig"},
        new String[] {"AWP | CMYK"}),
    new TradeUpCollection(
        "The Canals Collection",
        new String[] {
          "AUG | Navy Murano",
          "CZ75-Auto | Indigo",
          "Negev | Boroque Sand",
          "R8 Revolver | Canal Spray",
          "SCAR-20 | Stone Mosaico"
        },
        new String[] {
          "AK-47 | Baroque Purple",
          "P250 | Dark Filigree",
          "SG 553 | Candy Apple",
          "Tec-9 | Orange Murano"
        },
        new String[] {
          "Dual Berettas | Emerald",
          "G3SG1 | Violet Murano",
          "P90 | Baroque Red",
          "SSG 08 | Orange Filigree"
        },
        new String[] {"MAC-10 | Red Filigree", "MP9 | Stained Glass", "Nova | Baroque Orange"},
        new String[] {"MAG-7 | Cinquedea"},
        new String[] {"AWP | The Prince"}),
    new TradeUpCollection(
        "The Norse Collection",
        new String[] {
          "FAMAS | Night Borre",
          "Galil AR | Tornado",
          "MP7 | Scorched",
          "SG 553 | Barricade",
          "SSG 08 | Red Stone"
        },
        new String[] {
          "Dual Berettas | Pyre", "M4A1-S | Moss Quartz", "MAG-7 | Chainmail", "USP-S | Pathfinder"
        },
        new String[] {
          "CZ75-Auto | Emerald Quartz",
          "MAC-10 | Copper Borre",
          "SCAR-20 | Brass",
          "XM1014 | Frost Borre"
        },
        new String[] {
          "AUG | Flame Jörmungandr",
          "Desert Eagle | Emerald Jörmungandr",
          "P90 | Astral Jörmungandr"
        },
        new String[] {"Negev | Mjölnir"},
        new String[] {"AWP | Gungnir"}),
    new TradeUpCollection(
        "The St. Marc Collection",
        new String[] {
          "M249 | Jungle",
          "MP5-SD | Bamboo Garden",
          "MAC-10 | Surfwood",
          "PP-Bizon | Seabird",
          "Sawed-Off | Jungle Thicket"
        },
        new String[] {
          "M4A4 | Dark Blossom", "P90 | Sunset Lily", "Tec-9 | Rust Leaf", "XM1014 | Banana Leaf"
        },
        new String[] {
          "Five-SeveN | Crimson Blossom",
          "FAMAS | Sundown",
          "MP7 | Teal Blossom",
          "UMP-45 | Day Lily"
        },
        new String[] {"AUG | Midnight Lily", "Glock-18 | Synth Leaf", "SSG 08 | Sea Calico"},
        new String[] {"MP9 | Wild Lily"},
        new String[] {"AK-47 | Wild Lotus"}),
    new TradeUpCollection(
        "The Control Collection",
        new String[] {
          "AUG | Surveillance",
          "CZ75-Auto | Jungle Dashed",
          "MP9 | Army Sheen",
          "P250 | Forest Night",
          "XM1014 | Charter"
        },
        new String[] {
          "Desert Eagle | The Bronze",
          "Dual Berettas | Switch Board",
          "MAG-7 | Carbon Fiber",
          "MP5-SD | Nitro"
        },
        new String[] {
          "M4A4 | Global Offensive",
          "P2000 | Dispatch",
          "SCAR-20 | Magna Carta",
          "SSG 08 | Threat Detected"
        },
        new String[] {
          "FAMAS | Prime Conspiracy", "UMP-45 | Crime Scene", "Five-SeveN | Berries And Cherries"
        },
        new String[] {"M4A1-S | Blue Phosphor", "USP-S | Target Acquired"},
        new String[] {"AWP | Fade"}),
    new TradeUpCollection(
        "The Havoc Collection",
        new String[] {
          "Dual Berettas | Heist",
          "M249 | Predator",
          "PP-Bizon | Death Rattle",
          "Sawed-Off | Clay Ambush",
          "Tec-9 | Phoenix Chalk"
        },
        new String[] {
          "MP7 | Vault Heist",
          "Nova | Rust Coat",
          "R8 Revolver | Phoenix Marker",
          "UMP-45 | Houndstooth"
        },
        new String[] {
          "Desert Eagle | Night Heist",
          "Negev | Phoenix Stencil",
          "P250 | Bengal Tiger",
          "P90 | Tiger Pit"
        },
        new String[] {"Galil AR | Phoenix Blacklight", "Glock-18 | Franklin", "SG 553 | Hypnotic"},
        new String[] {"AWP | Silk Tiger", "MAC-10 | Hot Snakes"},
        new String[] {"AK-47 | X-Ray"}),
    new TradeUpCollection(
        "The Rising Sun Collection",
        new String[] {
          "Sawed-Off | Bamboo Shadow",
          "PP-Bizon | Bamboo Print",
          "P250 | Mint Kimono",
          "Tec-9 | Bamboo Forest",
          "G3SG1 | Orange Kimono"
        },
        new String[] {"P250 | Crimson Kimono", "Desert Eagle | Midnight Storm"},
        new String[] {"Galil AR | Aqua Terrace", "MAG-7 | Counter Terrace", "Tec-9 | Terrace"},
        new String[] {
          "M4A4 | Daybreak",
          "Five-SeveN | Neon Kimono",
          "Desert Eagle | Sunset Storm 壱",
          "Desert Eagle | Sunset Storm 弐"
        },
        new String[] {"AK-47 | Hydroponic"},
        new String[] {"AUG | Akihabara Accept"}),
    new TradeUpCollection(
        "The Baggage Collection",
        new String[] {
          "G3SG1 | Contractor",
          "MP7 | Olive Plaid",
          "CZ75-Auto | Green Plaid",
          "MP9 | Green Plaid",
          "SSG 08 | Sand Dune"
        },
        new String[] {
          "SG 553 | Traveler", "P90 | Leather", "MAC-10 | Commuter", "P2000 | Coach Class"
        },
        new String[] {"Sawed-Off | First Class", "USP-S | Business Class", "XM1014 | Red Leather"},
        new String[] {"AK-47 | First Class", "Desert Eagle | Pilot"},
        new String[] {"AK-47 | Jet Set"},
        new String[0]),
    new TradeUpCollection(
        "The Gods and Monsters Collection",
        new String[] {
          "MP7 | Asterion",
          "Dual Berettas | Moon in Libra",
          "AUG | Daedalus",
          "Nova | Moon in Libra"
        },
        new String[] {
          "AWP | Sun in Leo", "M249 | Shipping Forecast", "P2000 | Pathfinder", "Tec-9 | Hades"
        },
        new String[] {"MP9 | Pandora's Box", "UMP-45 | Minotaur's Labyrinth"},
        new String[] {"M4A1-S | Icarus Fell", "G3SG1 | Chronos"},
        new String[] {"M4A4 | Poseidon"},
        new String[] {"AWP | Medusa"}),
    new TradeUpCollection(
        "The Chop Shop Collection",
        new String[] {
          "M249 | Impact Drill", "MAG-7 | Seabird", "SCAR-20 | Army Sheen", "CZ75-Auto | Army Sheen"
        },
        new String[] {"Desert Eagle | Night", "USP-S | Para Green", "Galil AR | Urban Rubble"},
        new String[] {
          "P250 | Whiteout",
          "MAC-10 | Fade",
          "CZ75-Auto | Emerald",
          "Five-SeveN | Nitro",
          "MP7 | Full Stop"
        },
        new String[] {"SG 553 | Bulldozer", "Dual Berettas | Duelist"},
        new String[] {"M4A1-S | Hot Rod", "Glock-18 | Twilight Galaxy"},
        new String[0]),
    new TradeUpCollection(
        "The Arabesque Collection",
        new String[] {},
        new String[] {
          "PP-Bizon | Traitor",
          "MP9 | Dune Asp",
          "Nova | Morning Sun",
          "SCAR-20 | Sirocco Script",
          "Five-SeveN | Desert Seal",
          "Dual Berettas | Mystic Conjunction"
        },
        new String[] {
          "Sawed-Off | Lunar Wyrm",
          "FAMAS | Snake Song",
          "Tec-9 | Sultan",
          "MAC-10 | Arabesque Mosaic"
        },
        new String[] {"AUG | Lapis Lazuli", "Glock-18 | Ifrit Lattice", "P250 | Lotus Imprint"},
        new String[] {"Desert Eagle | Eastern Enigma", "M4A4 | Falak"},
        new String[] {"AWP | Sovereign Flame", "AK-47 | Consequence of the Jinn"}),
    new TradeUpCollection(
        "The Spy Tech Collection",
        new String[] {},
        new String[] {
          "MP7 | Base-2",
          "Tec-9 | Perimeter",
          "MAC-10 | Video Cam",
          "SCAR-20 | Arctic Camo Panels",
          "XM1014 | Black Site",
          "FAMAS | Corp Defense"
        },
        new String[] {
          "R8 Revolver | Monarch",
          "AUG | Signal Scanner",
          "MP9 | Spy Prototype",
          "M4A4 | Dark Operative"
        },
        new String[] {"CZ75-Auto | Hydraulics", "Nova | Smart Gun", "AWP | Black Box"},
        new String[] {"USP-S | Spiral Glitch", "M4A1-S | Fatal Glitch"},
        new String[] {"AK-47 | AUTOEXEC", "Glock-18 | Ghost Protocol"})
  };
}
