package blahblah;

import blahblah.hGui.*;
import java.awt.*;
import java.awt.event.*;
import java.util.ArrayList;
import java.util.Map;
import javax.swing.*;

/** Market Generation: focused feature implementation. */
final class MarketGeneration {
  private final hGui app;

  MarketGeneration(hGui app) {
    this.app = app;
  }

  void generateGlobalMarketListings() {
    app.itemMetadataService.normalizeUnsupportedStatTrakListings();
    app.marketStockService.invalidateGroupedMarketListingsCache();
    if (app.globalMarketListings.isEmpty()) app.globalBlueGemCounts.clear();

    String[] allKnifeSkins =
        app.collectionService.mergeCatalogSkins(
            "Knives",
            new String[] {
              "Karambit | Slaughter",
              "Karambit | Crimson Web",
              "Karambit | Scorched",
              "Karambit | Urban Masked",
              "Karambit | Night",
              "Karambit | Doppler (Phase 1)",
              "Karambit | Doppler (Phase 2)",
              "Karambit | Doppler (Phase 3)",
              "Karambit | Doppler (Phase 4)",
              "Karambit | Doppler (Sapphire)",
              "Karambit | Doppler (Ruby)",
              "Karambit | Doppler (Black Pearl)",
              "M9 Bayonet | Slaughter",
              "M9 Bayonet | Crimson Web",
              "M9 Bayonet | Blue Steel",
              "M9 Bayonet | Case Hardened",
              "M9 Bayonet | Doppler (Phase 1)",
              "M9 Bayonet | Doppler (Phase 2)",
              "M9 Bayonet | Doppler (Phase 3)",
              "M9 Bayonet | Doppler (Phase 4)",
              "M9 Bayonet | Doppler (Sapphire)",
              "M9 Bayonet | Doppler (Ruby)",
              "M9 Bayonet | Doppler (Black Pearl)",
              "Bayonet | Scorched",
              "Bayonet | Boreal Forest",
              "Bayonet | Fade",
              "Flip Knife | Vanilla",
              "Flip Knife | Case Hardened",
              "Gut Knife | Fade",
              "Gut Knife | Forest DDPAT",
              "Gut Knife | Safari Mesh",
              "Butterfly Knife | Case Hardened",
              "Butterfly Knife | Crimson Web",
              "Butterfly Knife | Fade",
              "Butterfly Knife | Safari Mesh",
              "Butterfly Knife | Slaughter",
              "Butterfly Knife | Urban Masked",
              "Butterfly Knife | Vanilla",
              "Butterfly Knife | Ultraviolet",
              "Butterfly Knife | Doppler (Phase 1)",
              "Butterfly Knife | Doppler (Phase 2)",
              "Butterfly Knife | Doppler (Phase 3)",
              "Butterfly Knife | Doppler (Phase 4)",
              "Butterfly Knife | Doppler (Sapphire)",
              "Butterfly Knife | Doppler (Ruby)",
              "Butterfly Knife | Doppler (Black Pearl)",
              "Butterfly Knife | Gamma Doppler (Phase 1)",
              "Butterfly Knife | Gamma Doppler (Phase 2)",
              "Butterfly Knife | Gamma Doppler (Phase 3)",
              "Butterfly Knife | Gamma Doppler (Phase 4)",
              "Butterfly Knife | Gamma Doppler (Emerald)",
              "Butterfly Knife | Marble Fade",
              "Butterfly Knife | Lore",
              "Kukri Knife | Urban Masked",
              "Kukri Knife | Stained",
              "Kukri Knife | Slaughter",
              "Kukri Knife | Scorched",
              "Kukri Knife | Safari Mesh",
              "Kukri Knife | Night Stripe",
              "Kukri Knife | Fade",
              "Kukri Knife | Crimson Web",
              "Kukri Knife | Case Hardened",
              "Huntsman Knife | Marble Fade",
              "Huntsman Knife | Tiger Tooth",
              "Bowie Knife | Marble Fade",
              "Bowie Knife | Urban Masked",
              "Bowie Knife | Stained",
              "Bowie Knife | Scorched",
              "Bowie Knife | Lore",
              "Bowie Knife | Forest DDPAT",
              "Bowie Knife | Fade",
              "Bowie Knife | Crimson Web",
              "Bowie Knife | Boreal Forest",
              "Bowie Knife | Blue Steel",
              "Bowie Knife | Black Laminate",
              "Bowie Knife | Tiger Tooth",
              "Falchion Knife | Marble Fade",
              "Falchion Knife | Tiger Tooth"
            });

    String[] allGloveSkins =
        app.collectionService.mergeCatalogSkins(
            "Gloves",
            new String[] {
              "Bloodhound Gloves | Bronzed",
              "Bloodhound Gloves | Charred",
              "Bloodhound Gloves | Guerrilla",
              "Bloodhound Gloves | Snakebite",
              "Driver Gloves | Convoy",
              "Driver Gloves | Crimson Weave",
              "Driver Gloves | Diamondback",
              "Driver Gloves | Lunar Weave",
              "Hand Wraps | Badlands",
              "Hand Wraps | Leather",
              "Hand Wraps | Slaughter",
              "Hand Wraps | Spruce DDPAT",
              "Moto Gloves | Boom!",
              "Moto Gloves | Cool Mint",
              "Moto Gloves | Eclipse",
              "Moto Gloves | Spearmint",
              "Specialist Gloves | Crimson Kimono",
              "Specialist Gloves | Emerald Web",
              "Specialist Gloves | Forest DDPAT",
              "Specialist Gloves | Foundation",
              "Sport Gloves | Arid",
              "Sport Gloves | Hedge Maze",
              "Sport Gloves | Pandora's Box",
              "Sport Gloves | Superconductor",
              "Hydra Gloves | Rattler",
              "Hydra Gloves | Mangrove",
              "Hydra Gloves | Emerald",
              "Hydra Gloves | Case Hardened",
              "Hand Wraps | Overprint",
              "Hand Wraps | Duct Tape",
              "Hand Wraps | Cobalt Skulls",
              "Hand Wraps | Arboreal",
              "Driver Gloves | Racing Green",
              "Driver Gloves | Overtake",
              "Driver Gloves | King Snake",
              "Driver Gloves | Imperial Plaid",
              "Sport Gloves | Vice",
              "Sport Gloves | Omega",
              "Sport Gloves | Bronze Morph",
              "Sport Gloves | Amphibious",
              "Specialist Gloves | Mogul",
              "Specialist Gloves | Fade",
              "Specialist Gloves | Crimson Web",
              "Specialist Gloves | Buckshot",
              "Moto Gloves | Turtle",
              "Moto Gloves | Transport",
              "Moto Gloves | POW!",
              "Moto Gloves | Polygon"
            });

    java.util.TreeSet<String> allGunSkinSet =
        new java.util.TreeSet<>(String.CASE_INSENSITIVE_ORDER);
    allGunSkinSet.addAll(app.oddsAndChecklistScreen.getRegisteredTradeUpSkins());
    for (String category : new String[] {"Pistols", "SMGs", "Rifles", "Heavy", "Equipment"}) {
      allGunSkinSet.addAll(app.collectionService.getCatalogSkinsByCategory(category));
    }
    String[] allGunSkins = allGunSkinSet.toArray(new String[0]);

    String[] allSkins =
        new String[allKnifeSkins.length + allGloveSkins.length + allGunSkins.length];
    System.arraycopy(allKnifeSkins, 0, allSkins, 0, allKnifeSkins.length);
    System.arraycopy(allGloveSkins, 0, allSkins, allKnifeSkins.length, allGloveSkins.length);
    System.arraycopy(
        allGunSkins, 0, allSkins, allKnifeSkins.length + allGloveSkins.length, allGunSkins.length);

    if (app.cs2ShellEnabled) {
      app.exchangeStockService.seedExchangeContainers();
      allSkins = app.exchangeStockService.prepareExchangeStockPlan(allSkins);
    }
    int startupSkinIndex = 0;
    for (String skinName : allSkins) {
      startupSkinIndex++;
      if (app.startupLoadingOverlay != null
          && app.startupLoadingOverlay.isVisible()
          && (startupSkinIndex == 1
              || startupSkinIndex % 25 == 0
              || startupSkinIndex == allSkins.length)) {
        int listingProgress =
            40 + (int) Math.round(5.0 * startupSkinIndex / Math.max(1, allSkins.length));
        app.startupScreen.setStartupProgress(
            listingProgress,
            app.cs2ShellEnabled
                ? String.format(
                    "Generating listings: %,d / %,d  •  %,d / %,d skins",
                    app.exchangeGeneratedStock,
                    app.exchangePlannedStock,
                    startupSkinIndex,
                    allSkins.length)
                : "Generating marketplace listings ("
                    + startupSkinIndex
                    + " of "
                    + allSkins.length
                    + " skins)...");
      }
      String name = app.leaderboardService.normalizeSkinName(skinName);
      int versions = app.itemMetadataService.supportsStatTrak(name) ? 2 : 1;
      synchronized (app.globalMarketListings) {
        for (int version = 0; version < versions; version++) {
          String key = version == 1 ? "StatTrak " + name : name;
          ArrayList<MarketListing> bucket =
              app.globalMarketListings.computeIfAbsent(key, k -> new ArrayList<>());
          app.marketStockService.rebalanceMarketBucket(key, bucket, true);
        }
      }
    }

    for (MarketListing playerListing : app.activeListings) {
      String cleanName = app.leaderboardService.normalizeSkinName(playerListing.item.name);
      String marketKey = playerListing.item.isStattrak ? "StatTrak " + cleanName : cleanName;

      if (!app.globalMarketListings.containsKey(marketKey)) {
        app.globalMarketListings.put(marketKey, new ArrayList<>());
      }
      if (app.globalMarketListings.get(marketKey).stream()
          .noneMatch(existing -> existing == playerListing)) {
        app.globalMarketListings.get(marketKey).add(playerListing);
      }
    }

    // Include Agents and any catalog-independent Armoury reward without
    // creating five impossible wear variants for no-float items.
    if (hGui.ARMOURY_COLLECTIONS != null) {
      synchronized (app.globalMarketListings) {
        for (ArmouryCollection col : hGui.ARMOURY_COLLECTIONS) {
          for (String[] tier :
              new String[][] {
                col.consumerNames,
                col.industrialNames,
                col.milspecNames,
                col.restrictedNames,
                col.classifiedNames,
                col.covertNames
              }) {
            if (tier == null) continue;
            for (String name : tier)
              app.globalMarketListings.computeIfAbsent(
                  app.leaderboardService.normalizeSkinName(name), k -> new ArrayList<>());
          }
        }
      }
    }
    app.marketStockService.rebalanceMarketWearSupply(true);
    app.marketPriceChanges.enforceStatTrakListingScarcity();
    if (app.cs2ShellEnabled) {
      app.exchangeSeededBuckets.clear();
      app.exchangeGeneratedStock = 0;
    }
    for (Map.Entry<String, ArrayList<MarketListing>> entry : app.globalMarketListings.entrySet()) {
      if (app.cs2ShellEnabled)
        app.exchangeStockService.seedExchangeBucket(entry.getKey(), entry.getValue());
      app.marketStockService.redistributeMarketplacesForBucket(entry.getKey(), entry.getValue());
    }
    if (app.cs2ShellEnabled) {
      app.exchangeStockService.seedExchangeContainers();
      app.exchangeStockService.rebuildExchangeIndex();
      app.exchangeGeneratedStock = app.marketStockService.getTotalMarketListingCount();
      app.exchangePlannedStock = app.exchangeGeneratedStock;
      app.startupScreen.setStartupProgress(
          45,
          String.format(
              "Generated listings: %,d / %,d",
              app.exchangeGeneratedStock, app.exchangePlannedStock));
    }
    app.marketStockService.invalidateGroupedMarketListingsCache();
  }

  double generateFloatForCondition(String skinName, String condition) {
    if ("Normal".equals(condition) || app.floatRules.hasNoFloatWear(skinName)) return 0.0;
    if (skinName.contains("Gloves") || skinName.contains("Hand Wraps")) {
      FloatRange gloveLimits = hGui.FLOAT_LIMITS.get(skinName);
      double min = gloveLimits != null && gloveLimits.min != null ? gloveLimits.min : 0.06;
      double max = gloveLimits != null && gloveLimits.max != null ? gloveLimits.max : 0.80;

      double condMin, condMax;

      if (condition.equals("Factory New")) {
        condMin = 0.06;
        condMax = Math.min(max, 0.0699);
      } else if (condition.equals("Minimal Wear")) {
        condMin = Math.max(min, 0.07);
        condMax = Math.min(max, 0.15);
      } else if (condition.equals("Field-Tested")) {
        condMin = Math.max(min, 0.15);
        condMax = Math.min(max, 0.38);
      } else if (condition.equals("Well-Worn")) {
        condMin = Math.max(min, 0.38);
        condMax = Math.min(max, 0.45);
      } else {
        condMin = Math.max(min, 0.45);
        condMax = Math.min(max, 0.80);
      }

      if (condMin >= condMax) {
        return condMin;
      }

      return condMin + (hGui.random.nextDouble() * (condMax - condMin));
    }

    FloatRange fr = app.catalogParsingService.findFloatRange(skinName);

    double min = (fr != null && fr.min != null) ? fr.min : 0.0;
    double max = (fr != null && fr.max != null) ? fr.max : 1.0;

    double condMin, condMax;

    if (condition.equals("Factory New")) {
      condMin = Math.max(min, 0.00);
      condMax = Math.min(max, 0.0699);
    } else if (condition.equals("Minimal Wear")) {
      condMin = Math.max(min, 0.07);
      condMax = Math.min(max, 0.15);
    } else if (condition.equals("Field-Tested")) {
      condMin = Math.max(min, 0.15);
      condMax = Math.min(max, 0.38);
    } else if (condition.equals("Well-Worn")) {
      condMin = Math.max(min, 0.38);
      condMax = Math.min(max, 0.45);
    } else {
      condMin = Math.max(min, 0.45);
      condMax = Math.min(max, 1.00);
    }

    if (condMin >= condMax) {
      return condMin;
    }

    boolean isDoppler = skinName.contains("Doppler");
    boolean isFade = skinName.contains("Fade");

    if ((isDoppler || isFade) && max <= 0.08) {
      double range = condMax - condMin;
      double bias = hGui.random.nextDouble();
      bias = Math.pow(bias, 2.5);
      return condMin + (bias * range);
    }

    return condMin + (hGui.random.nextDouble() * (condMax - condMin));
  }
}
