package blahblah;

import blahblah.hGui.*;
import java.awt.*;
import java.awt.event.*;
import java.math.BigDecimal;
import java.util.ArrayList;
import javax.swing.*;

/** Container Inventory Service: focused feature implementation. */
final class ContainerInventoryService {
  private final hGui app;

  ContainerInventoryService(hGui app) {
    this.app = app;
  }

  boolean requiresOwnedKey(CaseType ct) {
    return !ct.isTerminal && !ct.isSouvenir;
  }

  int ownedSupplyCount(CaseType ct, boolean key) {
    if (app.ownedSupplies == null) return 0;
    int n = 0;
    for (OwnedSupply s : app.ownedSupplies) if (s.caseId.equals(ct.id) && s.key == key) n++;
    return n;
  }

  void buyOwnedSupplies(CaseType ct, boolean key, int quantity) {
    synchronized (app) {
      if (ct == null || quantity < 1 || quantity > (key ? 20 : 100))
        throw new IllegalArgumentException(
            "Choose a quantity between 1 and " + (key ? 20 : 100) + ".");
      if (key && !app.containerInventoryService.requiresOwnedKey(ct))
        throw new IllegalArgumentException("This container does not use a key.");
      if (!key && !app.startupArtworkService.hasPurchasableCaseQuote(ct))
        throw new IllegalArgumentException(
            "No verified market quote is available for this container. Try refreshing prices"
                + " later.");
      BigDecimal unit = key ? hGui.CS2_KEY_PRICE : app.coreUtilities.money(ct.price);
      if (unit.signum() <= 0 || !Double.isFinite(ct.price))
        throw new IllegalArgumentException("A valid container quote is required.");
      BigDecimal total = unit.multiply(BigDecimal.valueOf(quantity));
      if (app.coreUtilities.money(app.balance).compareTo(total) < 0)
        throw new IllegalArgumentException(
            "Insufficient balance. Required: $" + total.toPlainString());
      if (app.ownedSupplies == null) app.ownedSupplies = new ArrayList<>();
      for (int i = 0; i < quantity; i++)
        app.ownedSupplies.add(new OwnedSupply(ct, key, unit.doubleValue()));
      if(!key)app.globalSupply.created(ct,quantity);
      app.balance = app.coreUtilities.money(app.balance).subtract(total).doubleValue();
    }
  }

  boolean canUnlockOwnedContainer(CaseType ct) {
    return app.containerInventoryService.ownedSupplyCount(ct, false) > 0
        && (!app.containerInventoryService.requiresOwnedKey(ct)
            || app.containerInventoryService.ownedSupplyCount(ct, true) > 0);
  }

  double consumeOwnedOpening(CaseType ct) {
    synchronized (app) {
      if (!app.containerInventoryService.canUnlockOwnedContainer(ct))
        throw new IllegalStateException("An owned container and its matching key are required.");
      OwnedSupply container = null, key = null;
      for (OwnedSupply s : app.ownedSupplies)
        if (s.caseId.equals(ct.id)) {
          if (!s.key && container == null) container = s;
          if (s.key && key == null) key = s;
        }
      if (app.cs2SelectedOpeningContainer != null) {
        container = null;
        for (OwnedSupply supply : app.ownedSupplies)
          if (supply.id.equals(app.cs2SelectedOpeningContainer)
              && !supply.key
              && supply.caseId.equals(ct.id)) container = supply;
        if (container == null)
          throw new IllegalStateException("The selected container is no longer owned.");
      }
      if (app.containerInventoryService.requiresOwnedKey(ct) && app.cs2SelectedOpeningKey != null) {
        key = null;
        for (OwnedSupply supply : app.ownedSupplies)
          if (supply.id.equals(app.cs2SelectedOpeningKey)
              && supply.key
              && supply.caseId.equals(ct.id)) key = supply;
        if (key == null) throw new IllegalStateException("The selected key is no longer owned.");
      }
      app.cs2SelectedOpeningContainer = null;
      app.cs2SelectedOpeningKey = null;
      double cost = container.purchasePrice;
      app.globalSupply.destroyed(ct);
      app.ownedSupplies.remove(container);
      if (app.containerInventoryService.requiresOwnedKey(ct)) {
        app.ownedSupplies.remove(key);
        cost += key.purchasePrice;
      }
      return cost; // Acquisition cost for profit statistics; never debit balance a second time.
    }
  }

  void cs2PurchaseChanged() {
    app.containerSelectionScreen.invalidateCs2Inventory();
    app.uiWidgets.updateBalanceLabel();
    if (app.cs2BalanceLabel != null)
      app.cs2BalanceLabel.setText(String.format("$%,.2f", app.balance));
    if (app.cs2ShellEnabled && app.mainTabs.getSelectedIndex() == 2)
      app.cs2Screens.refreshCs2Inventory();
    app.saveService.saveProgress();
  }
}
