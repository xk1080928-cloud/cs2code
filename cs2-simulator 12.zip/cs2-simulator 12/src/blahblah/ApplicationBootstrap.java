package blahblah;

import blahblah.hGui.*;
import java.awt.*;
import java.awt.event.*;
import javax.swing.*;

/** Application Bootstrap: focused feature implementation. */
final class ApplicationBootstrap {
  private final hGui app;

  ApplicationBootstrap(hGui app) {
    this.app = app;
  }

  void initialize() {

    app.setSize(810, 860);
    app.setMinimumSize(new Dimension(810, 860));
    app.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
    app.setResizable(true);

    app.addWindowListener(
        new java.awt.event.WindowAdapter() {
          @Override
          public void windowClosed(java.awt.event.WindowEvent e){app.backgroundUnboxing.stop();}
          @Override
          public void windowClosing(java.awt.event.WindowEvent e) {
            if (app.cs2PendingOpeningReward != null) {
              app.cs2PendingOpeningReward.run();
              app.cs2PendingOpeningReward = null;
            }
            app.backgroundUnboxing.stop();
            app.saveService.saveProgress();
            if (app.startupLoadingTimer != null) app.startupLoadingTimer.stop();
            if (app.marketTimer != null) app.marketTimer.stop();
            if (app.simulatedSalesExecutor != null) app.simulatedSalesExecutor.shutdownNow();
            if (app.autoTimer != null) app.autoTimer.stop();
            if (app.armouryAutoTimer != null) app.armouryAutoTimer.stop();
            if (app.fakeSalesTimer != null) app.fakeSalesTimer.stop();
            if (app.salesUpdateTimer != null) app.salesUpdateTimer.stop();
            if (app.tradeGenerationTimer != null) app.tradeGenerationTimer.stop();
            if (app.inventoryRefreshTimer != null) app.inventoryRefreshTimer.stop();
          }
        });

    app.achievementDefinitions.initializeAchievements();

    app.skinImage = null;
    app.crateImage = null; // Online artwork starts only after the first loading-screen paint.

    app.getContentPane().setBackground(Theme.BG_DARK);
    app.setLayout(new BorderLayout(0, 0));

    app.headerPanel = new JPanel(new BorderLayout());
    app.headerPanel.setBackground(Theme.BG_PANEL);
    app.headerPanel.setBorder(BorderFactory.createMatteBorder(0, 0, 2, 0, Theme.ACCENT_T));
    app.headerPanel.setPreferredSize(new Dimension(0, 56));

    JLabel titleLabel = new JLabel("  CS:GO CASE SIMULATOR");
    titleLabel.setFont(new Font("Consolas", Font.BOLD, 18));
    titleLabel.setForeground(Theme.ACCENT_T);
    app.headerPanel.add(titleLabel, BorderLayout.WEST);

    JPanel headerRight = new JPanel(new FlowLayout(FlowLayout.RIGHT, 14, 0));
    headerRight.setBackground(Theme.BG_PANEL);

    app.balanceLabel = new JLabel();
    app.balanceLabel.setFont(Theme.CONSOLE_BOLD_16);
    app.balanceLabel.setForeground(new Color(80, 220, 120));
    app.uiWidgets.updateBalanceLabel();

    app.tradeNotificationLabel = new JLabel("");
    app.tradeNotificationLabel.setFont(Theme.CONSOLE_BOLD_13);
    app.tradeNotificationLabel.setForeground(Theme.ACCENT_T);

    app.saveButton = app.uiWidgets.makeHeaderButton("SAVE", Theme.BG_CARD, Theme.TEXT_DIM);
    app.saveButton.addActionListener(app);
    app.loadButton = app.uiWidgets.makeHeaderButton("LOAD", Theme.BG_CARD, Theme.TEXT_DIM);
    app.loadButton.addActionListener(app);

    app.starsLabel = new JLabel("* " + app.playerStars + " Stars");
    app.starsLabel.setFont(Theme.CONSOLE_BOLD_14);
    app.starsLabel.setForeground(Theme.GOLD);
    headerRight.add(app.starsLabel);
    headerRight.add(app.tradeNotificationLabel);
    headerRight.add(app.balanceLabel);
    headerRight.add(app.saveButton);
    headerRight.add(app.loadButton);
    app.headerPanel.add(headerRight, BorderLayout.EAST);
    app.add(app.headerPanel, BorderLayout.NORTH);

    app.mainTabs = new JTabbedPane(JTabbedPane.TOP);
    app.mainTabs.setBackground(Theme.BG_DARK);
    app.mainTabs.setForeground(Theme.TEXT);
    app.mainTabs.setFont(Theme.CONSOLE_BOLD_14);
    app.mainTabs.setBorder(BorderFactory.createEmptyBorder());
    UIManager.put("TabbedPane.selected", Theme.BG_PANEL);
    UIManager.put("TabbedPane.background", Theme.BG_DARK);
    UIManager.put("TabbedPane.foreground", Theme.TEXT);
    UIManager.put("TabbedPane.selectedForeground", Theme.ACCENT_T);
    UIManager.put("TabbedPane.contentAreaColor", Theme.BG_PANEL);
    UIManager.put("TabbedPane.tabAreaBackground", Theme.BG_DARK);

    app.casesTabPanel = new JPanel(null);
    app.casesTabPanel.setBackground(Theme.BG_DARK);

    JLabel caseSelectorTitle = app.uiWidgets.makeModernLabel(10, 18, 120, 28, 13, Theme.TEXT);
    caseSelectorTitle.setText("SELECT CASE");
    app.casesTabPanel.add(caseSelectorTitle);
    app.caseSelectorButton = new JButton(app.currentCase.name);
    app.caseSelectorButton.setBounds(135, 15, 420, 34);
    app.uiWidgets.styleButton(app.caseSelectorButton, Theme.BG_CARD, Theme.TEXT, Theme.BORDER);
    app.caseSelectorButton.setFont(Theme.CONSOLE_BOLD_14);
    app.caseSelectorButton.addActionListener(
        e -> app.containerBrowserScreen.showCaseSelectorDialog());
    app.casesTabPanel.add(app.caseSelectorButton);
    app.caseRoiLabel = app.uiWidgets.makeModernLabel(10, 57, 750, 30, 13, Theme.TEXT_DIM);
    app.casesTabPanel.add(app.caseRoiLabel);

    int btnY1 = 112;
    int btnY2 = 182;
    int btnW = 220;
    int btnH = 36;
    int btnCenterX = Math.max(10, (760 - btnW) / 2);

    app.devToolsButton = new JButton("DEV TOOLS");
    app.devToolsButton.setBounds(690, 690, 100, 30);
    app.uiWidgets.styleButton(app.devToolsButton, Theme.BG_CARD, Theme.ACCENT_CT, Theme.BORDER);
    app.devToolsButton.setFont(new Font("Consolas", Font.BOLD, 11));
    app.devToolsButton.addActionListener(e -> app.developerTools.showDevToolsWindow());
    app.casesTabPanel.add(app.devToolsButton);

    app.openCrateButton =
        new JButton(
            String.format(
                "OPEN CASE  $%.2f", app.developerTools.getCaseOpeningCost(app.currentCase)));
    app.openCrateButton.setActionCommand("OPEN");
    app.openCrateButton.setBounds(btnCenterX, btnY1, btnW, btnH);
    app.uiWidgets.styleButton(app.openCrateButton, Theme.ACCENT_T, Theme.BG_DARK, Theme.ACCENT_T);
    app.openCrateButton.setFont(new Font("Consolas", Font.BOLD, 14));
    app.openCrateButton.addActionListener(app);
    app.casesTabPanel.add(app.openCrateButton);

    app.closeCrateButton = new JButton("CLOSE");
    app.closeCrateButton.setBounds(btnCenterX, btnY1, btnW, btnH);
    app.uiWidgets.styleButton(app.closeCrateButton, Theme.BG_CARD, Theme.TEXT_DIM, Theme.BORDER);
    app.closeCrateButton.addActionListener(app);
    app.closeCrateButton.setVisible(false);
    app.casesTabPanel.add(app.closeCrateButton);

    app.autoOpenButton = new JButton("AUTO OPEN");
    app.autoOpenButton.setBounds(btnCenterX, btnY2, btnW, btnH);
    app.uiWidgets.styleButton(app.autoOpenButton, Theme.BG_CARD, Theme.ACCENT_CT, Theme.BORDER);
    app.autoOpenButton.addActionListener(app);
    app.autoOpenButton.setActionCommand("AUTO");
    app.autoOpenButton.setVisible(false);

    app.profitLabel = app.uiWidgets.makeModernLabel(10, 152, 740, 24, 13, Theme.TEXT_DIM);
    app.rarityLabel = app.uiWidgets.makeModernLabel(10, 220, 760, 32, 18, Theme.TEXT);
    app.nameLabel = app.uiWidgets.makeModernLabel(10, 258, 780, 44, 28, Theme.TEXT);
    app.priceLabel = app.uiWidgets.makeModernLabel(10, 308, 380, 26, 14, Theme.TEXT);
    app.floatLabel = app.uiWidgets.makeModernLabel(10, 332, 760, 26, 13, Theme.TEXT_DIM);
    app.conditionLabel = app.uiWidgets.makeModernLabel(10, 355, 380, 26, 13, Theme.TEXT);
    app.patternId = app.uiWidgets.makeModernLabel(10, 378, 380, 26, 13, Theme.TEXT_DIM);
    app.collectionLabel =
        app.uiWidgets.makeModernLabel(10, 401, 500, 22, 11, new Color(170, 130, 255));
    app.lowFloatLabel = app.uiWidgets.makeModernLabel(10, 400, 760, 26, 12, Theme.TEXT_DIM);
    app.totalInventoryValueLabel =
        app.uiWidgets.makeModernLabel(10, 690, 380, 26, 12, Theme.TEXT_DIM);

    app.totalMilspec =
        app.uiWidgets.makeModernLabel(10, 620, 400, 24, 12, new Color(100, 160, 255));
    app.totalRestrict =
        app.uiWidgets.makeModernLabel(10, 642, 400, 24, 12, new Color(170, 80, 255));
    app.totalClass = app.uiWidgets.makeModernLabel(10, 664, 400, 24, 12, new Color(220, 90, 220));
    app.totalCovert = app.uiWidgets.makeModernLabel(10, 686, 400, 24, 12, new Color(220, 50, 50));
    app.totalKnife = app.uiWidgets.makeModernLabel(10, 708, 400, 24, 12, new Color(220, 185, 30));
    app.totalGlove = app.uiWidgets.makeModernLabel(10, 730, 400, 24, 12, new Color(220, 185, 30));

    app.lowFloatLabel.setVisible(false);

    app.profitLabel.setHorizontalAlignment(SwingConstants.CENTER);
    app.casesTabPanel.addComponentListener(
        new ComponentAdapter() {
          public void componentResized(ComponentEvent e) {
            app.developerTools.layoutCaseOpeningControls();
          }
        });
    app.casesTabPanel.add(app.profitLabel);
    app.casesTabPanel.add(app.rarityLabel);
    app.casesTabPanel.add(app.nameLabel);
    app.casesTabPanel.add(app.priceLabel);
    app.casesTabPanel.add(app.floatLabel);
    app.casesTabPanel.add(app.conditionLabel);
    app.casesTabPanel.add(app.patternId);
    app.casesTabPanel.add(app.collectionLabel);
    app.casesTabPanel.add(app.totalMilspec);
    app.casesTabPanel.add(app.totalRestrict);
    app.casesTabPanel.add(app.totalClass);
    app.casesTabPanel.add(app.totalCovert);
    app.casesTabPanel.add(app.totalKnife);
    app.casesTabPanel.add(app.totalGlove);

    app.tradesButton =
        app.uiWidgets.makeIconButton("TRADES", Theme.BG_CARD, Theme.TEXT, Theme.BORDER);
    app.collectionButton =
        app.uiWidgets.makeIconButton("COLLECTION", Theme.BG_CARD, Theme.TEXT, Theme.BORDER);
    app.achievementsButton =
        app.uiWidgets.makeIconButton("ACHIEVEMENTS", Theme.BG_CARD, Theme.ACCENT_T, Theme.BORDER);
    app.statsButton =
        app.uiWidgets.makeIconButton("STATS", Theme.BG_CARD, Theme.TEXT, Theme.BORDER);
    app.leaderboardButton =
        app.uiWidgets.makeIconButton("LEADERBOARD", Theme.BG_CARD, Theme.ACCENT_CT, Theme.BORDER);
    app.leaderboardButton.setActionCommand("LEADERBOARD");
    app.roiButton =
        app.uiWidgets.makeIconButton("ROI STATS", Theme.BG_CARD, Theme.TEXT_DIM, Theme.BORDER);
    app.roiButton.setActionCommand("ROI");
    app.tradesButton.addActionListener(app);
    app.collectionButton.addActionListener(app);
    app.achievementsButton.addActionListener(app);
    app.statsButton.addActionListener(app);
    app.leaderboardButton.addActionListener(app);
    app.roiButton.addActionListener(app);
    app.missionsButton =
        app.uiWidgets.makeIconButton(
            "MISSIONS", Theme.BG_CARD, new Color(100, 220, 255), Theme.BORDER);
    app.missionsButton.setActionCommand("MISSIONS");
    app.missionsButton.addActionListener(app);
    app.armouryButton =
        app.uiWidgets.makeIconButton(
            "ARMOURY", Theme.BG_CARD, new Color(100, 220, 255), Theme.BORDER);
    app.armouryButton.setActionCommand("ARMOURY_TAB");
    app.armouryButton.addActionListener(app);

    app.armouryOddsButton =
        app.uiWidgets.makeIconButton("ARMOURY ODDS", Theme.BG_CARD, Theme.GOLD, Theme.BORDER);
    app.armouryOddsButton.setActionCommand("ARMOURY_ODDS");
    app.armouryOddsButton.addActionListener(app);

    app.inventoryTabPanel = new JPanel(new BorderLayout());
    app.inventoryTabPanel.setBackground(Theme.BG_DARK);

    app.tradeUpTabPanel = new JPanel(new BorderLayout());
    app.tradeUpTabPanel.setBackground(Theme.BG_DARK);

    app.marketTabPanel = new JPanel(new BorderLayout());
    app.marketTabPanel.setBackground(Theme.BG_DARK);

    app.generalTabPanel = new JPanel(new BorderLayout());

    app.armouryTabPanel = new JPanel(new BorderLayout());
    app.armouryTabPanel.setBackground(new Color(15, 15, 20));
    app.generalTabPanel.setBackground(Theme.BG_DARK);

    app.loadoutTabPanel = new JPanel(new BorderLayout());
    app.loadoutTabPanel.setBackground(Theme.BG_DARK);

    app.mainTabs.addTab("  CASES  ", app.casesTabPanel);
    app.mainTabs.addTab("  ARMOURY  ", app.armouryTabPanel);
    app.mainTabs.addTab("  INVENTORY  ", app.inventoryTabPanel);
    app.mainTabs.addTab("  TRADE UP  ", app.tradeUpTabPanel);
    app.mainTabs.addTab("  MARKET  ", app.marketTabPanel);
    app.mainTabs.addTab("  LOADOUT  ", app.loadoutTabPanel);
    app.mainTabs.addTab("  GENERAL  ", app.generalTabPanel);
    app.add(app.mainTabs, BorderLayout.CENTER);

    app.mainTabs.addChangeListener(
        e2 -> {
          int idx = app.mainTabs.getSelectedIndex();
          if (idx == 1) app.armouryScreen.refreshArmouryTab();
          else if (idx == 2) app.inventoryScreen.refreshInventoryTab();
          else if (idx == 3) app.tradeUpScreen.refreshTradeUpTab();
          else if (idx == 4) app.loadoutScreen.refreshMarketTab();
          else if (idx == 5) app.loadoutScreen.refreshLoadoutTab();
          else if (idx == 6) app.generalScreen.refreshGeneralTab();
        });

    app.cs2Screens.installCs2Shell();
    app.pageTransitions.install();
    app.startupScreen.beginStartupLoading();
    // All startup data work is deferred until the loading overlay has actually painted.

    app.developerTools.layoutCaseOpeningControls();
    app.totalMilspec.setVisible(false);
    app.totalRestrict.setVisible(false);
    app.totalClass.setVisible(false);
    app.totalCovert.setVisible(false);
    app.totalKnife.setVisible(false);
    app.totalGlove.setVisible(false);
    app.lowFloatLabel.setVisible(false);
  }
}
