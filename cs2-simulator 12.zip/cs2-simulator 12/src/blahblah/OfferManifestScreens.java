package blahblah;

import blahblah.hGui.*;
import java.awt.*;
import java.awt.event.*;
import java.util.ArrayList;
import javax.swing.*;

/** Offer Manifest Screens: focused feature implementation. */
final class OfferManifestScreens {
  private final hGui app;

  OfferManifestScreens(hGui app) {
    this.app = app;
  }

  void showMarketplaceOfferWindowManifest(
      String skinName, String conditionToken, MarketplaceOfferAggregate offer, JFrame parent) {
    JFrame frame =
        app.offerNeonAndMirageScreens.createMarketplaceFrame(
            offer, skinName, conditionToken, parent, new Color(16, 14, 26));
    frame.add(
        app.offerHeroAndSellerScreens.createOfferHeader(
            offer.marketplaceName + " Manifest",
            conditionToken + "  ·  manifest by seller",
            offer,
            "P2P Manifest"),
        BorderLayout.NORTH);

    ArrayList<MarketListing> sorted = app.marketOfferService.getSortedOfferListings(offer);

    // Table header
    JPanel thead = new JPanel(new GridLayout(1, 5, 0, 0));
    thead.setBackground(new Color(22, 18, 36));
    thead.setBorder(
        BorderFactory.createCompoundBorder(
            BorderFactory.createMatteBorder(0, 0, 2, 0, offer.accent),
            BorderFactory.createEmptyBorder(8, 16, 8, 16)));
    for (String col : new String[] {"ID", "SELLER", "FLOAT", "PATTERN", "PRICE"}) {
      JLabel h = new JLabel(col);
      h.setFont(new Font("Consolas", Font.BOLD, 10));
      h.setForeground(new Color(150, 130, 200));
      thead.add(h);
    }

    JPanel tbody = new JPanel();
    tbody.setLayout(new BoxLayout(tbody, BoxLayout.Y_AXIS));
    tbody.setBackground(new Color(16, 14, 26));

    double total = 0;
    int idx = 1;
    for (MarketListing listing : sorted) {
      total += listing.getPrice();
      tbody.add(app.offerManifestScreens.createManifestRow(idx++, listing, offer, frame));
    }

    // Footer totals bar
    JPanel footer = new JPanel(new BorderLayout());
    footer.setBackground(new Color(22, 18, 36));
    footer.setBorder(
        BorderFactory.createCompoundBorder(
            BorderFactory.createMatteBorder(2, 0, 0, 0, offer.accent),
            BorderFactory.createEmptyBorder(10, 16, 10, 16)));
    JLabel totalLbl = new JLabel("TOTAL VALUE:   $" + String.format("%.2f", total));
    totalLbl.setFont(new Font("Consolas", Font.BOLD, 14));
    totalLbl.setForeground(offer.accent);
    JLabel countLbl = new JLabel(sorted.size() + " ITEMS");
    countLbl.setFont(new Font("Consolas", Font.PLAIN, 12));
    countLbl.setForeground(new Color(140, 120, 180));
    footer.add(totalLbl, BorderLayout.WEST);
    footer.add(countLbl, BorderLayout.EAST);

    JScrollPane scroll = new JScrollPane(tbody);
    scroll.setBorder(null);
    scroll.getViewport().setBackground(new Color(16, 14, 26));
    scroll.getVerticalScrollBar().setUnitIncrement(20);

    JPanel center = new JPanel(new BorderLayout());
    center.setBackground(new Color(16, 14, 26));
    center.add(thead, BorderLayout.NORTH);
    center.add(scroll, BorderLayout.CENTER);
    center.add(footer, BorderLayout.SOUTH);
    frame.add(center, BorderLayout.CENTER);
    frame.setVisible(true);
  }

  JPanel createManifestRow(
      int idx, MarketListing listing, MarketplaceOfferAggregate offer, JFrame parent) {
    JPanel row = new JPanel(new GridLayout(1, 5, 0, 0));
    Color bg = idx % 2 == 0 ? new Color(20, 18, 32) : new Color(16, 14, 26);
    row.setBackground(bg);
    row.setMaximumSize(new Dimension(Integer.MAX_VALUE, 40));
    row.setBorder(BorderFactory.createEmptyBorder(0, 16, 0, 16));
    boolean isAgentManifest = app.itemMetadataService.isAgentSkin(listing.item.name);

    row.add(
        app.offerAnalyticsScreens.styledMono(
            String.format("MNF-%04d", idx), new Color(100, 80, 150)));
    row.add(
        app.offerAnalyticsScreens.styledMono(
            listing.sellerName != null ? listing.sellerName : "—", new Color(200, 200, 220)));
    row.add(
        app.offerAnalyticsScreens.styledMono(
            isAgentManifest ? "—" : String.format("%.6f", listing.item.itemFloat),
            new Color(160, 140, 200)));
    row.add(
        app.offerAnalyticsScreens.styledMono(
            isAgentManifest ? "—" : app.marketOfferService.formatMarketPatternText(listing),
            app.marketOfferService.getMarketPatternColor(listing, new Color(140, 120, 180))));

    JButton buy =
        app.offerNeonAndMirageScreens.createMarketplaceActionButton(
            listing, offer, parent, "$" + String.format("%.2f", listing.getPrice()));
    buy.setBackground(new Color(30, 22, 50));
    buy.setForeground(offer.accent);
    buy.setBorder(BorderFactory.createEmptyBorder(4, 8, 4, 8));
    row.add(buy);
    return row;
  }

  void showMarketplaceOfferWindowCommandTable(
      String skinName, String conditionToken, MarketplaceOfferAggregate offer, JFrame parent) {
    JFrame frame =
        app.offerNeonAndMirageScreens.createMarketplaceFrame(
            offer, skinName, conditionToken, parent, new Color(14, 16, 12));
    frame.add(
        app.offerHeroAndSellerScreens.createOfferHeader(
            offer.marketplaceName + " Command",
            skinName + "  ·  execution table",
            offer,
            "⬤ DOCK QUEUE"),
        BorderLayout.NORTH);

    ArrayList<MarketListing> sorted = app.marketOfferService.getSortedOfferListings(offer);

    // KPI strip
    JPanel kpi = new JPanel(new GridLayout(1, 4, 1, 0));
    kpi.setBackground(new Color(10, 12, 8));
    kpi.setBorder(BorderFactory.createMatteBorder(0, 0, 1, 0, new Color(100, 130, 60)));
    double lo = sorted.stream().mapToDouble(l -> l.getPrice()).min().orElse(0);
    kpi.add(
        app.offerManifestScreens.createCommandKPI("BEST PRICE", "$" + String.format("%.2f", lo)));
    kpi.add(app.offerManifestScreens.createCommandKPI("SELLERS", String.valueOf(sorted.size())));
    kpi.add(
        app.offerManifestScreens.createCommandKPI(
            "RATING", String.format("%.1f / 5.0", offer.rating)));
    kpi.add(app.offerManifestScreens.createCommandKPI("STATUS", "ACTIVE"));

    // Header
    boolean isAgentCommand = app.itemMetadataService.isAgentSkin(skinName);
    JPanel thead = new JPanel(new GridLayout(1, 5, 0, 0));
    thead.setBackground(new Color(18, 22, 14));
    thead.setBorder(
        BorderFactory.createCompoundBorder(
            BorderFactory.createMatteBorder(0, 0, 1, 0, new Color(80, 100, 40)),
            BorderFactory.createEmptyBorder(7, 14, 7, 14)));
    for (String col :
        new String[] {
          "STATUS",
          "SELLER",
          isAgentCommand ? "—" : "FLOAT",
          isAgentCommand ? "—" : "PATTERN",
          "EXECUTE"
        }) {
      JLabel h = new JLabel(col);
      h.setFont(new Font("Consolas", Font.BOLD, 10));
      h.setForeground(new Color(120, 150, 70));
      thead.add(h);
    }

    JPanel tbody = new JPanel();
    tbody.setLayout(new BoxLayout(tbody, BoxLayout.Y_AXIS));
    tbody.setBackground(new Color(14, 16, 12));

    int i = 0;
    for (MarketListing listing : sorted) {
      tbody.add(app.offerManifestScreens.createCommandRow(i++, listing, offer, frame));
    }

    JScrollPane scroll = new JScrollPane(tbody);
    scroll.setBorder(null);
    scroll.getViewport().setBackground(new Color(14, 16, 12));
    scroll.getVerticalScrollBar().setUnitIncrement(20);

    JPanel center = new JPanel(new BorderLayout());
    center.setBackground(new Color(14, 16, 12));
    center.add(kpi, BorderLayout.NORTH);
    center.add(thead, BorderLayout.CENTER); // won't scroll with this placement — use wrapper
    frame.add(center, BorderLayout.NORTH);

    JPanel tableWrap = new JPanel(new BorderLayout());
    tableWrap.setBackground(new Color(14, 16, 12));
    tableWrap.add(thead, BorderLayout.NORTH);
    tableWrap.add(scroll, BorderLayout.CENTER);

    JPanel main = new JPanel(new BorderLayout());
    main.setBackground(new Color(14, 16, 12));
    main.add(kpi, BorderLayout.NORTH);
    main.add(tableWrap, BorderLayout.CENTER);
    frame.add(main, BorderLayout.CENTER);
    frame.setVisible(true);
  }

  JPanel createCommandKPI(String label, String value) {
    JPanel p = new JPanel(new BorderLayout(0, 3));
    p.setBackground(new Color(14, 18, 10));
    p.setBorder(BorderFactory.createEmptyBorder(10, 16, 10, 16));
    JLabel lbl = new JLabel(label);
    lbl.setFont(new Font("Consolas", Font.PLAIN, 9));
    lbl.setForeground(new Color(80, 100, 50));
    JLabel val = new JLabel(value);
    val.setFont(new Font("Consolas", Font.BOLD, 16));
    val.setForeground(new Color(160, 200, 80));
    p.add(lbl, BorderLayout.NORTH);
    p.add(val, BorderLayout.CENTER);
    return p;
  }

  JPanel createCommandRow(
      int idx, MarketListing listing, MarketplaceOfferAggregate offer, JFrame parent) {
    JPanel row = new JPanel(new GridLayout(1, 5, 0, 0));
    Color bg = idx % 2 == 0 ? new Color(16, 18, 14) : new Color(12, 14, 10);
    row.setBackground(bg);
    row.setMaximumSize(new Dimension(Integer.MAX_VALUE, 38));
    row.setBorder(BorderFactory.createEmptyBorder(0, 14, 0, 14));
    boolean isAgentRow = app.itemMetadataService.isAgentSkin(listing.item.name);

    // Status dot
    JLabel dot = new JLabel("● READY");
    dot.setFont(new Font("Consolas", Font.PLAIN, 11));
    dot.setForeground(new Color(100, 200, 60));

    row.add(dot);
    row.add(
        app.offerAnalyticsScreens.styledMono(
            listing.sellerName != null ? listing.sellerName : "—", new Color(180, 200, 140)));
    row.add(
        app.offerAnalyticsScreens.styledMono(
            isAgentRow ? "—" : String.format("%.6f", listing.item.itemFloat),
            new Color(140, 180, 80)));
    row.add(
        app.offerAnalyticsScreens.styledMono(
            isAgentRow ? "—" : app.marketOfferService.formatMarketPatternText(listing),
            app.marketOfferService.getMarketPatternColor(listing, new Color(120, 160, 60))));

    JButton exec =
        app.offerNeonAndMirageScreens.createMarketplaceActionButton(
            listing, offer, parent, "EXECUTE  $" + String.format("%.2f", listing.getPrice()));
    exec.setBackground(new Color(30, 40, 16));
    exec.setForeground(new Color(160, 200, 80));
    exec.setFont(new Font("Consolas", Font.BOLD, 11));
    exec.setBorder(BorderFactory.createEmptyBorder(4, 8, 4, 8));
    row.add(exec);
    return row;
  }

  void showMarketplaceOfferWindowShowcase(
      String skinName, String conditionToken, MarketplaceOfferAggregate offer, JFrame parent) {
    JFrame frame =
        app.offerNeonAndMirageScreens.createMarketplaceFrame(
            offer, skinName, conditionToken, parent, new Color(8, 18, 24));
    frame.add(
        app.offerHeroAndSellerScreens.createOfferHeader(
            offer.marketplaceName + " Showcase",
            conditionToken + "  ·  gallery format",
            offer,
            "Vault Shelf"),
        BorderLayout.NORTH);

    JPanel gallery = new JPanel(new GridLayout(0, 2, 16, 16));
    gallery.setBackground(new Color(8, 18, 24));
    gallery.setBorder(BorderFactory.createEmptyBorder(18, 18, 18, 18));
    for (MarketListing listing : app.marketOfferService.getSortedOfferListings(offer)) {
      gallery.add(app.offerManifestScreens.createShowcaseCard(listing, offer, frame));
    }

    JScrollPane scroll = new JScrollPane(gallery);
    scroll.setBorder(null);
    scroll.getViewport().setBackground(new Color(8, 18, 24));
    scroll.getVerticalScrollBar().setUnitIncrement(20);
    frame.add(scroll, BorderLayout.CENTER);
    frame.setVisible(true);
  }

  JPanel createShowcaseCard(MarketListing listing, MarketplaceOfferAggregate offer, JFrame parent) {
    JPanel card = new JPanel(new BorderLayout(0, 0));
    card.setBackground(new Color(12, 24, 32));
    card.setBorder(BorderFactory.createLineBorder(new Color(30, 70, 90), 1));

    // Accent band top
    JPanel band = new JPanel();
    band.setBackground(offer.accent);
    band.setPreferredSize(new Dimension(0, 4));
    card.add(band, BorderLayout.NORTH);

    // Body
    JPanel body = new JPanel(new BorderLayout(0, 10));
    body.setOpaque(false);
    body.setBorder(BorderFactory.createEmptyBorder(14, 16, 14, 16));

    JLabel seller = new JLabel(listing.sellerName != null ? listing.sellerName : "Anonymous");
    seller.setFont(new Font("Arial", Font.BOLD, 15));
    seller.setForeground(Color.WHITE);

    JPanel stats = new JPanel(new GridLayout(2, 2, 8, 4));
    stats.setOpaque(false);
    boolean isAgentShowcase = app.itemMetadataService.isAgentSkin(listing.item.name);
    stats.add(
        app.offerManifestScreens.createShowcaseStat(
            "FLOAT", isAgentShowcase ? "—" : String.format("%.6f", listing.item.itemFloat)));
    stats.add(
        app.offerManifestScreens.createShowcaseStat(
            "PATTERN",
            isAgentShowcase ? "—" : app.marketOfferService.formatMarketPatternText(listing)));
    stats.add(app.offerManifestScreens.createShowcaseStat("MARKET", offer.marketplaceName));
    stats.add(app.offerManifestScreens.createShowcaseStat("DELIVERY", offer.marketplaceType));

    JPanel bottom = new JPanel(new BorderLayout(10, 0));
    bottom.setOpaque(false);
    JLabel price = new JLabel("$" + String.format("%.2f", listing.getPrice()));
    price.setFont(new Font("Consolas", Font.BOLD, 22));
    price.setForeground(offer.accent);
    JButton btn =
        app.offerNeonAndMirageScreens.createMarketplaceActionButton(
            listing, offer, parent, "PURCHASE");
    btn.setPreferredSize(new Dimension(110, 36));
    bottom.add(price, BorderLayout.CENTER);
    bottom.add(btn, BorderLayout.EAST);

    body.add(seller, BorderLayout.NORTH);
    body.add(stats, BorderLayout.CENTER);
    body.add(bottom, BorderLayout.SOUTH);
    card.add(body, BorderLayout.CENTER);
    return card;
  }

  JPanel createShowcaseStat(String label, String value) {
    JPanel p = new JPanel(new BorderLayout(0, 2));
    p.setOpaque(false);
    JLabel lbl = new JLabel(label);
    lbl.setFont(new Font("Arial", Font.PLAIN, 9));
    lbl.setForeground(new Color(80, 130, 150));
    JLabel val = new JLabel(value);
    val.setFont(new Font("Consolas", Font.PLAIN, 12));
    val.setForeground(new Color(180, 210, 220));
    p.add(lbl, BorderLayout.NORTH);
    p.add(val, BorderLayout.CENTER);
    return p;
  }
}
