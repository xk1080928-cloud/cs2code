package blahblah;

import blahblah.hGui.*;
import java.awt.*;
import java.awt.event.*;
import java.math.BigDecimal;
import java.math.RoundingMode;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;
import javax.swing.*;

/** Market Price Changes: focused feature implementation. */
final class MarketPriceChanges {
  private final hGui app;

  MarketPriceChanges(hGui app) {
    this.app = app;
  }

  void ensureMinimumListings() {
    app.itemMetadataService.normalizeUnsupportedStatTrakListings();
    app.marketStockService.rebalanceMarketWearSupply(true);
    app.marketPriceChanges.enforceStatTrakListingScarcity();
  }

  void enforceStatTrakListingScarcity() {
    if (app.globalSupply.ready())
      return; // Scarcity is seeded in units; never delete live compact parents.
    synchronized (app.globalMarketListings) {
      for (Map.Entry<String, ArrayList<MarketListing>> entry :
          new ArrayList<>(app.globalMarketListings.entrySet())) {
        String statTrakKey = entry.getKey();
        if (!statTrakKey.startsWith("StatTrak ")) continue;

        ArrayList<MarketListing> statTrakListings = entry.getValue();
        ArrayList<MarketListing> regularListings =
            app.globalMarketListings.get(statTrakKey.replace("StatTrak ", ""));
        if (statTrakListings == null || regularListings == null) continue;

        Map<String, Integer> regularNpcByCondition = new HashMap<>();
        for (MarketListing listing : regularListings) {
          if (listing == null || listing.item == null || listing.isPlayerListing) continue;
          String condition = listing.item.condition != null ? listing.item.condition : "Unknown";
          regularNpcByCondition.put(
              condition, regularNpcByCondition.getOrDefault(condition, 0) + 1);
        }

        Map<String, Integer> keptNpcByCondition = new HashMap<>();
        ArrayList<MarketListing> trimmed = new ArrayList<>();
        for (MarketListing listing : statTrakListings) {
          if (listing == null || listing.item == null || listing.isPlayerListing) {
            trimmed.add(listing);
            continue;
          }
          String condition = listing.item.condition != null ? listing.item.condition : "Unknown";
          int regularCount = regularNpcByCondition.getOrDefault(condition, 0);
          int maxStatTrakForCondition = Math.max(1, (int) Math.floor(regularCount * 0.45));
          int kept = keptNpcByCondition.getOrDefault(condition, 0);
          if (kept < maxStatTrakForCondition) {
            trimmed.add(listing);
            keptNpcByCondition.put(condition, kept + 1);
          }
        }

        if (trimmed.size() < statTrakListings.size()) {
          statTrakListings.clear();
          statTrakListings.addAll(trimmed);
        }
      }
    }
  }

  void repriceExistingNpcListings(String rarity, double oldMultiplier, double newMultiplier) {}

  void handlePriceIncrease(String rarity, double oldMultiplier, double newMultiplier) {

    app.marketPriceChanges.repriceExistingNpcListings(rarity, oldMultiplier, newMultiplier);

    for (Map.Entry<String, ArrayList<MarketListing>> entry : app.globalMarketListings.entrySet()) {
      String skinName = entry.getKey();
      String cleanSkinName =
          skinName.replace("StatTrak ", "").replace("StatTrak ", "").replace(" StatTrak ", "");
      String skinRarity = app.itemMetadataService.getSkinRarity(cleanSkinName);

      if (skinRarity.equals(rarity)) {
        ArrayList<MarketListing> listings = entry.getValue();
        ArrayList<MarketListing> toRemove = new ArrayList<>();
        ArrayList<MarketListing> priceMoveSales = new ArrayList<>();
        int totalItemsRemoved = 0;

        for (MarketListing listing : listings) {
          boolean isBlueGem = listing.item.blueGemTier != null;

          if (!listing.isPlayerListing && !isBlueGem) {

            String cleanForPrice = skinName.replace("StatTrak ", "").replace("StatTrak ", "");
            double basePrice = app.itemPriceService.getBasePrice(cleanForPrice);
            boolean isAgent = app.itemMetadataService.isAgentSkin(cleanForPrice);
            double expectedPrice = basePrice * newMultiplier;

            if (!isAgent) {
              expectedPrice *=
                  app.priceModifiers.getConditionPriceMultiplier(
                      cleanForPrice, listing.item.condition);
            }

            if (!isAgent && listing.item.isStattrak) {
              boolean isCW6 = cleanSkinName.contains("Crimson Web");
              boolean isD6 = cleanSkinName.contains("Doppler");
              if (isCW6) expectedPrice *= 2.0;
              else if (isD6) expectedPrice *= 0.80;
              else if (skinRarity.equals("Knife")) expectedPrice *= 0.90;
              else expectedPrice *= 1.85;
            }

            if (listing.getPrice() < expectedPrice * 0.90 && hGui.random.nextDouble() < 0.6) {
              toRemove.add(listing);
              priceMoveSales.add(listing);
              totalItemsRemoved++;
            }
          } else if (listing.isPlayerListing) {
            String cleanForPrice2 = skinName.replace("StatTrak ", "").replace("StatTrak ", "");
            double basePrice = app.itemPriceService.getBasePrice(cleanForPrice2);
            boolean isAgent = app.itemMetadataService.isAgentSkin(cleanForPrice2);
            double minPrice = basePrice * newMultiplier * 0.85;

            if (!isAgent) {
              minPrice *=
                  app.priceModifiers.getConditionPriceMultiplier(
                      cleanForPrice2, listing.item.condition);
            }

            if (listing.getPrice() < minPrice) {
              toRemove.add(listing);
              app.containerMarketService.restore(listing.item);
              app.activeListings.remove(listing);
            }
          }
        }

        synchronized (app.globalMarketListings) {
          listings.removeAll(toRemove);
        }
        for (MarketListing soldListing : priceMoveSales) {
          app.salesSimulationService.recordMarketListingSale(soldListing, null, null);
        }

        if (totalItemsRemoved > 0) {
          boolean isRareDopplerGem =
              (skinName.contains("Sapphire")
                  || skinName.contains("Ruby")
                  || skinName.contains("Black Pearl")
                  || skinName.contains("Emerald"));

          int newListingsToAdd;

          if (isRareDopplerGem) {
            newListingsToAdd = hGui.random.nextDouble() < 0.15 ? 1 : 0;
          } else {

            newListingsToAdd = (int) (totalItemsRemoved * (0.1 + hGui.random.nextDouble() * 0.2));

            switch (rarity) {
              case "Milspec":
                newListingsToAdd = Math.max(3, newListingsToAdd);
                break;
              case "Restricted":
                newListingsToAdd = Math.max(2, newListingsToAdd);
                break;
              case "Classified":
                newListingsToAdd = Math.max(2, newListingsToAdd);
                break;
              case "Covert":
                newListingsToAdd = Math.max(1, newListingsToAdd);
                break;
              case "Knife":
                newListingsToAdd = Math.max(1, Math.min(2, newListingsToAdd));
                break;
            }
          }

          int maxAllowed;
          switch (rarity) {
            case "Milspec":
              maxAllowed = 600;
              break;
            case "Restricted":
              maxAllowed = 450;
              break;
            case "Classified":
              maxAllowed = 350;
              break;
            case "Covert":
              maxAllowed = 220;
              break;
            case "Knife":
              maxAllowed = 100;
              break;
            case "Gloves":
              maxAllowed = 100;
              break;
            default:
              maxAllowed = 300;
              break;
          }
          if (listings.size() >= maxAllowed) newListingsToAdd = 0;
          else newListingsToAdd = Math.min(newListingsToAdd, maxAllowed - listings.size());

          for (int i = 0; i < newListingsToAdd; i++) {
            String cleanSkin = skinName.replace("StatTrak ", "").replace("StatTrak ", "");
            boolean isStatTrak =
                skinName.startsWith("StatTrak") || skinName.startsWith("StatTrak ");
            if (isStatTrak && !app.itemMetadataService.supportsStatTrak(cleanSkin)) continue;
            boolean isAgent = app.itemMetadataService.isAgentSkin(cleanSkin);

            String[] availableConditions = app.floatRules.getAvailableConditions(cleanSkin);
            String condition =
                isAgent
                    ? "Normal"
                    : availableConditions[hGui.random.nextInt(availableConditions.length)];

            double basePrice = app.itemPriceService.getBasePrice(cleanSkin);
            double itemFloat =
                isAgent
                    ? 0.0
                    : app.marketGeneration.generateFloatForCondition(cleanSkin, condition);

            double variance = 0.95 + (hGui.random.nextDouble() * 0.20);

            double listPrice = basePrice * newMultiplier * variance;

            boolean isGlove = rarity.equals("Gloves");
            if (isAgent) {
              listPrice = basePrice * newMultiplier * variance;
            } else if (isGlove) {
              double gloveBasePrice = app.itemPriceService.getBasePrice(cleanSkin);
              listPrice = app.priceTables.calculateGlovePrice(cleanSkin, condition, gloveBasePrice);
              listPrice *= newMultiplier * variance;

              double gloveFloor =
                  app.priceTables.calculateGlovePrice(cleanSkin, condition, gloveBasePrice) * 0.75;
              if (listPrice < gloveFloor) listPrice = gloveFloor;
            } else {
              listPrice *= app.priceModifiers.getConditionPriceMultiplier(skinName, condition);
            }

            if (!isAgent && isStatTrak && !isGlove) {
              boolean isCW2 = cleanSkin.contains("Crimson Web");
              boolean isD2 = cleanSkin.contains("Doppler");
              if (isCW2) listPrice *= 2.0;
              else if (isD2) listPrice *= 0.80;
              else if (rarity.equals("Knife")) listPrice *= 0.90;
              else listPrice *= 1.70 + hGui.random.nextDouble() * 0.30;
            }

            int sellTime = 30 + hGui.random.nextInt(150);
            double trueBasePrice = listPrice / newMultiplier;

            String displayRarity = isStatTrak ? "StatTrak " + rarity : rarity;

            Image skinImg = app.artworkService.getSkinImageFromName(cleanSkin, condition);

            InventoryItem dummyItem =
                new InventoryItem(
                    skinImg != null ? new ImageIcon(skinImg) : null,
                    cleanSkin,
                    condition,
                    displayRarity,
                    BigDecimal.valueOf(listPrice).setScale(2, RoundingMode.HALF_UP),
                    itemFloat,
                    isStatTrak,
                    hGui.random.nextInt(1000),
                    null,
                    trueBasePrice);

            MarketListing listing = new MarketListing(dummyItem, listPrice, sellTime, false);
            listings.add(listing);
          }
        }
      }
    }
  }

  void handlePriceDecrease(String rarity, double oldMultiplier, double newMultiplier) {
    if (app.cs2ShellEnabled)
      return; // runtime changes use fixed-ask order flow, never lot repricing

    app.marketPriceChanges.repriceExistingNpcListings(rarity, oldMultiplier, newMultiplier);

    ArrayList<String> skinsOfRarity = new ArrayList<>();
    for (String skinName : app.globalMarketListings.keySet()) {
      String cleanName = skinName.replace("StatTrak ", "").replace("StatTrak ", "");
      if (app.itemMetadataService.getSkinRarity(cleanName).equals(rarity)) {
        skinsOfRarity.add(skinName);
      }
    }

    if (skinsOfRarity.isEmpty()) return;

    for (String skinName : skinsOfRarity) {
      if (skinName.contains("Sapphire")
          || skinName.contains("Ruby")
          || skinName.contains("Black Pearl")
          || skinName.contains("Emerald")) continue;
      ArrayList<MarketListing> listings = app.globalMarketListings.get(skinName);
      if (listings == null) continue;
      String cleanSkin = skinName.replace("StatTrak ", "").replace("StatTrak ", "");
      boolean isStatTrak = skinName.startsWith("StatTrak") || skinName.startsWith("StatTrak ");
      for (MarketListing ml : listings) {
        if (ml.isPlayerListing) continue;

        boolean isAgent = app.itemMetadataService.isAgentSkin(cleanSkin);
        double base =
            rarity.equals("Gloves")
                ? app.priceTables.calculateGlovePrice(
                    cleanSkin, ml.item.condition, app.itemPriceService.getBasePrice(cleanSkin))
                : app.itemPriceService.getBasePrice(cleanSkin);
        if (!rarity.equals("Gloves") && !isAgent) {
          base *= app.priceModifiers.getConditionPriceMultiplier(cleanSkin, ml.item.condition);
          if (isStatTrak) {
            boolean isCW8 = cleanSkin.contains("Crimson Web");
            boolean isD8 = cleanSkin.contains("Doppler");
            if (isCW8) base *= 2.0;
            else if (isD8) base *= 0.80;
            else if (rarity.equals("Knife")) base *= 0.90;
            else base *= 1.85;
          }
        }
        double expectedNew = base * newMultiplier;

        if (expectedNew > 0 && ml.getPrice() > expectedNew * 1.15) {
          double adjusted = expectedNew * (0.97 + hGui.random.nextDouble() * 0.10);
          ml.setPrice(Math.max(expectedNew * 0.92, adjusted));
          if (ml.item != null) {
            ml.item.price = BigDecimal.valueOf(ml.getPrice()).setScale(2, RoundingMode.HALF_UP);
          }
        }
      }
    }

    boolean isRareDopplerGem = false;
    for (String skinName : skinsOfRarity) {
      if (skinName.contains("Sapphire")
          || skinName.contains("Ruby")
          || skinName.contains("Black Pearl")
          || skinName.contains("Emerald")) {
        isRareDopplerGem = true;
        break;
      }
    }

    int totalNewListings;
    if (isRareDopplerGem) {
      totalNewListings = hGui.random.nextDouble() < 0.20 ? 1 : 0;
    } else {
      switch (rarity) {
        case "Milspec":
          totalNewListings = 5 + hGui.random.nextInt(5);
          break;
        case "Restricted":
          totalNewListings = 4 + hGui.random.nextInt(4);
          break;
        case "Classified":
          totalNewListings = 3 + hGui.random.nextInt(3);
          break;
        case "Covert":
          totalNewListings = 2 + hGui.random.nextInt(2);
          break;
        case "Knife":
          totalNewListings = 1 + hGui.random.nextInt(2);
          break;
        case "Gloves":
          totalNewListings = 1 + hGui.random.nextInt(2);
          break;
        default:
          totalNewListings = 3;
      }
    }

    for (int i = 0; i < totalNewListings; i++) {
      String skinName = skinsOfRarity.get(hGui.random.nextInt(skinsOfRarity.size()));
      String cleanSkin = skinName.replace("StatTrak ", "").replace("StatTrak ", "");
      boolean isStatTrak = skinName.startsWith("StatTrak") || skinName.startsWith("StatTrak ");
      if (isStatTrak && !app.itemMetadataService.supportsStatTrak(cleanSkin)) continue;
      boolean isAgent = app.itemMetadataService.isAgentSkin(cleanSkin);

      String[] availableConditions = app.floatRules.getAvailableConditions(cleanSkin);
      String condition =
          isAgent ? "Normal" : availableConditions[hGui.random.nextInt(availableConditions.length)];

      double basePrice = app.itemPriceService.getBasePrice(cleanSkin);
      double itemFloat =
          isAgent ? 0.0 : app.marketGeneration.generateFloatForCondition(cleanSkin, condition);

      double variance = 0.85 + (hGui.random.nextDouble() * 0.30);

      double listPrice = basePrice * newMultiplier * variance;

      boolean isGlove = rarity.equals("Gloves");
      if (isAgent) {
        listPrice = basePrice * newMultiplier * variance;
      } else if (isGlove) {
        double gloveBasePrice = app.itemPriceService.getBasePrice(cleanSkin);
        listPrice = app.priceTables.calculateGlovePrice(cleanSkin, condition, gloveBasePrice);
        listPrice *= newMultiplier * variance;

        double gloveFloor =
            app.priceTables.calculateGlovePrice(cleanSkin, condition, gloveBasePrice) * 0.75;
        if (listPrice < gloveFloor) listPrice = gloveFloor;
      } else {
        listPrice *= app.priceModifiers.getConditionPriceMultiplier(cleanSkin, condition);
      }

      if (!isAgent && isStatTrak && !isGlove) {
        boolean isCW3 = cleanSkin.contains("Crimson Web");
        boolean isD3 = cleanSkin.contains("Doppler");
        if (isCW3) listPrice *= 2.0;
        else if (isD3) listPrice *= 0.80;
        else if (rarity.equals("Knife")) listPrice *= 0.90;
        else listPrice *= 1.70 + hGui.random.nextDouble() * 0.30;
      }

      int sellTime = 30 + hGui.random.nextInt(150);
      double trueBasePrice = listPrice / newMultiplier;

      String displayRarity = isStatTrak ? "StatTrak " + rarity : rarity;

      Image skinImg = app.artworkService.getSkinImageFromName(cleanSkin, condition);

      InventoryItem dummyItem =
          new InventoryItem(
              skinImg != null ? new ImageIcon(skinImg) : null,
              cleanSkin,
              condition,
              displayRarity,
              BigDecimal.valueOf(listPrice).setScale(2, RoundingMode.HALF_UP),
              itemFloat,
              isStatTrak,
              hGui.random.nextInt(1000),
              null,
              trueBasePrice);

      MarketListing listing = new MarketListing(dummyItem, listPrice, sellTime, false);

      if (!app.globalMarketListings.containsKey(skinName)) {
        app.globalMarketListings.put(skinName, new ArrayList<>());
      }

      int maxDecreaseAllowed;
      switch (rarity) {
        case "Milspec":
          maxDecreaseAllowed = 600;
          break;
        case "Restricted":
          maxDecreaseAllowed = 450;
          break;
        case "Classified":
          maxDecreaseAllowed = 350;
          break;
        case "Covert":
          maxDecreaseAllowed = 220;
          break;
        default:
          maxDecreaseAllowed = 100;
          break;
      }
      if (app.globalMarketListings.get(skinName).size() < maxDecreaseAllowed) {
        app.globalMarketListings.get(skinName).add(listing);
      }
    }
  }
}
