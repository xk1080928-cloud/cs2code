package blahblah;

import blahblah.hGui.*;
import java.awt.*;
import java.awt.event.*;
import java.util.ArrayList;
import javax.swing.*;

/** Offer Hero And Seller Screens: focused feature implementation. */
final class OfferHeroAndSellerScreens {
  private final hGui app;

  OfferHeroAndSellerScreens(hGui app) {
    this.app = app;
  }

  JPanel createOfferHeader(
      String titleText, String subtitleText, MarketplaceOfferAggregate offer, String badgeText) {
    JPanel header = new JPanel(new BorderLayout());
    header.setBackground(offer.accentAlt);
    header.setBorder(
        BorderFactory.createCompoundBorder(
            BorderFactory.createMatteBorder(0, 0, 2, 0, offer.accent),
            BorderFactory.createEmptyBorder(16, 20, 16, 20)));
    JLabel title = new JLabel(offer.marketplaceName != null ? offer.marketplaceName : titleText);
    title.setFont(new Font("Arial", Font.BOLD, 28));
    title.setForeground(Color.WHITE);
    JLabel subtitle = new JLabel(subtitleText);
    subtitle.setFont(new Font("Arial", Font.PLAIN, 13));
    subtitle.setForeground(new Color(220, 230, 255));
    JPanel titleCol = new JPanel();
    titleCol.setOpaque(false);
    titleCol.setLayout(new BoxLayout(titleCol, BoxLayout.Y_AXIS));
    titleCol.add(title);
    titleCol.add(subtitle);
    header.add(titleCol, BorderLayout.WEST);
    JLabel badge = new JLabel(badgeText);
    badge.setOpaque(true);
    badge.setBackground(offer.accent);
    badge.setForeground(new Color(15, 15, 20));
    badge.setFont(new Font("Arial", Font.BOLD, 13));
    badge.setBorder(BorderFactory.createEmptyBorder(8, 12, 8, 12));
    header.add(badge, BorderLayout.EAST);
    return header;
  }

  void showMarketplaceOfferWindowHero(
      String skinName, String conditionToken, MarketplaceOfferAggregate offer, JFrame parent) {
    JFrame frame =
        app.offerNeonAndMirageScreens.createMarketplaceFrame(
            offer, skinName, conditionToken, parent, new Color(10, 13, 22));

    frame.add(
        app.offerHeroAndSellerScreens.createOfferHeader(
            offer.marketplaceName + "  ·  " + offer.marketplaceType,
            skinName + "  ·  " + conditionToken + "  ·  " + offer.listingCount + " offers",
            offer,
            "INSTANT".equals(offer.marketplaceType) ? "⚡ Instant" : "🔄 P2P"),
        BorderLayout.NORTH);

    ArrayList<MarketListing> sorted = app.marketOfferService.getSortedOfferListings(offer);
    double lowest = sorted.stream().mapToDouble(l -> l.getPrice()).min().orElse(0);
    double highest = sorted.stream().mapToDouble(l -> l.getPrice()).max().orElse(0);
    double avgFloat = sorted.stream().mapToDouble(l -> l.item.itemFloat).average().orElse(0);
    boolean isAgentHero = app.itemMetadataService.isAgentSkin(skinName);

    // ── Spotlight panel (left 340px) ──
    JPanel spotlight = new JPanel(new BorderLayout(0, 0));
    spotlight.setPreferredSize(new Dimension(340, 0));
    spotlight.setBackground(new Color(14, 18, 30));
    spotlight.setBorder(BorderFactory.createMatteBorder(0, 0, 0, 1, new Color(40, 50, 80)));

    // Skin image with dark vignette background
    JPanel imgBg =
        new JPanel(new BorderLayout()) {
          @Override
          protected void paintComponent(Graphics g) {
            super.paintComponent(g);
            Graphics2D g2 = (Graphics2D) g;
            // radial-like dark vignette
            g2.setColor(new Color(8, 12, 22));
            g2.fillRect(0, 0, getWidth(), getHeight());
            g2.setPaint(
                new RadialGradientPaint(
                    new Point(getWidth() / 2, getHeight() / 2),
                    Math.max(getWidth(), getHeight()) / 2f,
                    new float[] {0f, 1f},
                    new Color[] {new Color(20, 26, 48), new Color(8, 12, 22)}));
            g2.fillRect(0, 0, getWidth(), getHeight());
          }
        };
    imgBg.setOpaque(false);
    imgBg.setPreferredSize(new Dimension(340, 220));
    imgBg.setBorder(BorderFactory.createEmptyBorder(20, 20, 20, 20));
    JLabel offerHeroArtwork = new JLabel("", SwingConstants.CENTER);
    app.artworkService.getSkinImageFromName(
        skinName,
        app.marketHistoryScreen.getPriceHistoryCondition(conditionToken),
        offerHeroArtwork,
        300,
        180);
    imgBg.add(offerHeroArtwork, BorderLayout.CENTER);

    spotlight.add(imgBg, BorderLayout.NORTH);

    // Divider strip with gradient price label
    JPanel priceStrip = new JPanel(new BorderLayout());
    priceStrip.setBackground(new Color(18, 22, 38));
    priceStrip.setBorder(
        BorderFactory.createCompoundBorder(
            BorderFactory.createMatteBorder(1, 0, 1, 0, offer.accent),
            BorderFactory.createEmptyBorder(12, 20, 12, 20)));
    JLabel priceLabel = new JLabel("From  $" + String.format("%.2f", lowest));
    priceLabel.setFont(new Font("Consolas", Font.BOLD, 22));
    priceLabel.setForeground(offer.accent);
    JLabel offersBadge = new JLabel(offer.listingCount + " offers");
    offersBadge.setFont(new Font("Arial", Font.PLAIN, 12));
    offersBadge.setForeground(new Color(140, 160, 200));
    priceStrip.add(priceLabel, BorderLayout.WEST);
    priceStrip.add(offersBadge, BorderLayout.EAST);
    spotlight.add(priceStrip, BorderLayout.CENTER);

    // Stat cards vertically in sidebar
    JPanel sideStats = new JPanel(new GridLayout(isAgentHero ? 2 : 3, 1, 0, 1));
    sideStats.setBackground(new Color(10, 13, 22));
    sideStats.add(
        app.offerHeroAndSellerScreens.createHeroStatRow(
            "BEST ASK", "$" + String.format("%.2f", lowest), offer.accent, new Color(14, 18, 30)));
    sideStats.add(
        app.offerHeroAndSellerScreens.createHeroStatRow(
            "WORST ASK",
            "$" + String.format("%.2f", highest),
            offer.accent,
            new Color(12, 16, 26)));
    if (!isAgentHero) {
      sideStats.add(
          app.offerHeroAndSellerScreens.createHeroStatRow(
              "AVG FLOAT", String.format("%.6f", avgFloat), offer.accent, new Color(14, 18, 30)));
    }
    spotlight.add(sideStats, BorderLayout.SOUTH);

    // ── Listing feed (right) ──
    JPanel feed = new JPanel();
    feed.setLayout(new BoxLayout(feed, BoxLayout.Y_AXIS));
    feed.setBackground(new Color(10, 13, 22));
    feed.setBorder(BorderFactory.createEmptyBorder(16, 16, 16, 16));

    // Column header row
    int heroColCount = isAgentHero ? 2 : 4;
    JPanel colHeader = new JPanel(new GridLayout(1, heroColCount, 0, 0));
    colHeader.setBackground(new Color(16, 20, 34));
    colHeader.setBorder(
        BorderFactory.createCompoundBorder(
            BorderFactory.createMatteBorder(0, 0, 1, 0, new Color(40, 50, 80)),
            BorderFactory.createEmptyBorder(6, 12, 6, 12)));
    String[] heroHeaders =
        isAgentHero
            ? new String[] {"SELLER", "PRICE"}
            : new String[] {"SELLER", "FLOAT", "PATTERN", "PRICE"};
    for (String col : heroHeaders) {
      JLabel lbl = new JLabel(col);
      lbl.setFont(new Font("Arial", Font.BOLD, 10));
      lbl.setForeground(new Color(100, 120, 160));
      colHeader.add(lbl);
    }
    feed.add(colHeader);
    feed.add(Box.createRigidArea(new Dimension(0, 8)));

    for (MarketListing listing : sorted) {
      feed.add(
          app.offerHeroAndSellerScreens.createHeroListingRow(listing, offer, frame, isAgentHero));
      feed.add(Box.createRigidArea(new Dimension(0, 4)));
    }

    JScrollPane scroll = new JScrollPane(feed);
    scroll.setBorder(null);
    scroll.getViewport().setBackground(new Color(10, 13, 22));
    scroll.getVerticalScrollBar().setUnitIncrement(20);

    JPanel body = new JPanel(new BorderLayout());
    body.setBackground(new Color(10, 13, 22));
    body.add(spotlight, BorderLayout.WEST);
    body.add(scroll, BorderLayout.CENTER);
    frame.add(body, BorderLayout.CENTER);
    frame.setVisible(true);
  }

  JPanel createHeroStatRow(String label, String value, Color accent, Color bg) {
    JPanel row = new JPanel(new BorderLayout());
    row.setBackground(bg);
    row.setBorder(
        BorderFactory.createCompoundBorder(
            BorderFactory.createMatteBorder(0, 3, 0, 0, accent),
            BorderFactory.createEmptyBorder(10, 14, 10, 14)));
    JLabel lbl = new JLabel(label);
    lbl.setFont(new Font("Arial", Font.BOLD, 10));
    lbl.setForeground(new Color(100, 120, 160));
    JLabel val = new JLabel(value);
    val.setFont(new Font("Consolas", Font.BOLD, 15));
    val.setForeground(Color.WHITE);
    row.add(lbl, BorderLayout.NORTH);
    row.add(val, BorderLayout.SOUTH);
    return row;
  }

  JPanel createHeroListingRow(
      MarketListing listing, MarketplaceOfferAggregate offer, JFrame parent, boolean isAgent) {
    int colCount = isAgent ? 2 : 4;
    JPanel row = new JPanel(new GridLayout(1, colCount, 0, 0));
    row.setBackground(new Color(14, 18, 30));
    row.setMaximumSize(new Dimension(Integer.MAX_VALUE, 46));
    row.setBorder(
        BorderFactory.createCompoundBorder(
            BorderFactory.createMatteBorder(0, 0, 1, 0, new Color(22, 28, 46)),
            BorderFactory.createEmptyBorder(0, 12, 0, 12)));

    JLabel seller = new JLabel(listing.sellerName != null ? listing.sellerName : "Seller");
    seller.setFont(new Font("Arial", Font.PLAIN, 12));
    seller.setForeground(new Color(200, 210, 230));

    row.add(seller);
    if (!isAgent) {
      JLabel floatLbl = new JLabel(String.format("%.5f", listing.item.itemFloat));
      floatLbl.setFont(new Font("Consolas", Font.PLAIN, 12));
      floatLbl.setForeground(new Color(160, 180, 220));
      JLabel pattern = new JLabel(app.marketOfferService.formatMarketPatternText(listing));
      pattern.setFont(new Font("Consolas", Font.PLAIN, 12));
      pattern.setForeground(
          app.marketOfferService.getMarketPatternColor(listing, new Color(140, 160, 200)));
      row.add(floatLbl);
      row.add(pattern);
    }

    JButton buy =
        app.offerNeonAndMirageScreens.createMarketplaceActionButton(
            listing, offer, parent, "$" + String.format("%.2f", listing.getPrice()));
    buy.setFont(new Font("Consolas", Font.BOLD, 13));
    buy.setPreferredSize(new Dimension(90, 34));
    row.add(buy);
    return row;
  }

  void showMarketplaceOfferWindowSellerDesk(
      String skinName, String conditionToken, MarketplaceOfferAggregate offer, JFrame parent) {
    JFrame frame =
        app.offerNeonAndMirageScreens.createMarketplaceFrame(
            offer, skinName, conditionToken, parent, new Color(13, 10, 20));

    frame.add(
        app.offerHeroAndSellerScreens.createOfferHeader(
            offer.marketplaceName + " Seller Desk",
            conditionToken + "  ·  negotiate directly with sellers",
            offer,
            "P2P Queue"),
        BorderLayout.NORTH);

    ArrayList<MarketListing> sorted = app.marketOfferService.getSortedOfferListings(offer);

    // ── Seller card rail ──
    JPanel rail = new JPanel();
    rail.setLayout(new BoxLayout(rail, BoxLayout.Y_AXIS));
    rail.setBackground(new Color(13, 10, 20));
    rail.setBorder(BorderFactory.createEmptyBorder(16, 16, 16, 16));

    for (int i = 0; i < sorted.size(); i++) {
      MarketListing listing = sorted.get(i);
      rail.add(app.offerHeroAndSellerScreens.createSellerDeskCard(i + 1, listing, offer, frame));
      rail.add(Box.createRigidArea(new Dimension(0, 8)));
    }

    JScrollPane scroll = new JScrollPane(rail);
    scroll.setBorder(null);
    scroll.getViewport().setBackground(new Color(13, 10, 20));
    scroll.getVerticalScrollBar().setUnitIncrement(20);

    // ── Right info rail ──
    JPanel infoRail = new JPanel();
    infoRail.setLayout(new BoxLayout(infoRail, BoxLayout.Y_AXIS));
    infoRail.setPreferredSize(new Dimension(220, 0));
    infoRail.setBackground(new Color(18, 14, 28));
    infoRail.setBorder(
        BorderFactory.createCompoundBorder(
            BorderFactory.createMatteBorder(0, 2, 0, 0, offer.accent),
            BorderFactory.createEmptyBorder(20, 16, 20, 16)));

    infoRail.add(
        app.offerHeroAndSellerScreens.createInfoBlock(
            "MARKET", offer.marketplaceName, offer.accent));
    infoRail.add(Box.createRigidArea(new Dimension(0, 16)));
    infoRail.add(
        app.offerHeroAndSellerScreens.createInfoBlock(
            "DELIVERY", "P2P — Seller sends after payment", offer.accent));
    infoRail.add(Box.createRigidArea(new Dimension(0, 16)));
    infoRail.add(
        app.offerHeroAndSellerScreens.createInfoBlock(
            "OFFERS", String.valueOf(offer.listingCount), offer.accent));
    infoRail.add(Box.createRigidArea(new Dimension(0, 16)));
    infoRail.add(
        app.offerHeroAndSellerScreens.createInfoBlock(
            "RATING", String.format("%.1f ★", offer.rating), offer.accent));
    infoRail.add(Box.createRigidArea(new Dimension(0, 16)));
    infoRail.add(
        app.offerHeroAndSellerScreens.createInfoBlock("REVIEWS", offer.reviews, offer.accent));

    frame.add(scroll, BorderLayout.CENTER);
    frame.add(infoRail, BorderLayout.EAST);
    frame.setVisible(true);
  }

  JPanel createSellerDeskCard(
      int rank, MarketListing listing, MarketplaceOfferAggregate offer, JFrame parent) {
    JPanel card = new JPanel(new BorderLayout(14, 0));
    card.setBackground(new Color(20, 16, 32));
    card.setMaximumSize(new Dimension(Integer.MAX_VALUE, 72));
    card.setBorder(
        BorderFactory.createCompoundBorder(
            BorderFactory.createLineBorder(new Color(60, 40, 90), 1),
            BorderFactory.createEmptyBorder(12, 14, 12, 14)));

    // Rank badge
    JLabel rankBadge = new JLabel(String.format("%02d", rank));
    rankBadge.setFont(new Font("Consolas", Font.BOLD, 18));
    rankBadge.setForeground(offer.accent);
    rankBadge.setPreferredSize(new Dimension(32, 0));
    rankBadge.setHorizontalAlignment(SwingConstants.CENTER);

    // Center info
    JPanel info = new JPanel(new GridLayout(2, 1, 0, 2));
    info.setOpaque(false);
    JLabel name = new JLabel(listing.sellerName != null ? listing.sellerName : "Anonymous Seller");
    name.setFont(new Font("Arial", Font.BOLD, 13));
    name.setForeground(Color.WHITE);
    boolean isAgentDesk = app.itemMetadataService.isAgentSkin(listing.item.name);
    String detailText =
        isAgentDesk
            ? "Agent"
            : ("Float: "
                + String.format("%.6f", listing.item.itemFloat)
                + "   Pattern: "
                + app.marketOfferService.formatMarketPatternText(listing));
    JLabel details = new JLabel(detailText);
    details.setFont(new Font("Consolas", Font.PLAIN, 11));
    details.setForeground(new Color(140, 120, 180));
    info.add(name);
    info.add(details);

    // Right — price + button
    JPanel right = new JPanel(new BorderLayout(8, 0));
    right.setOpaque(false);
    JLabel price = new JLabel("$" + String.format("%.2f", listing.getPrice()));
    price.setFont(new Font("Consolas", Font.BOLD, 18));
    price.setForeground(offer.accent);
    price.setHorizontalAlignment(SwingConstants.RIGHT);
    JButton btn =
        app.offerNeonAndMirageScreens.createMarketplaceActionButton(
            listing, offer, parent, "NEGOTIATE");
    btn.setPreferredSize(new Dimension(110, 36));
    right.add(price, BorderLayout.CENTER);
    right.add(btn, BorderLayout.EAST);

    card.add(rankBadge, BorderLayout.WEST);
    card.add(info, BorderLayout.CENTER);
    card.add(right, BorderLayout.EAST);
    return card;
  }

  JPanel createInfoBlock(String label, String value, Color accent) {
    JPanel block = new JPanel(new BorderLayout(0, 4));
    block.setOpaque(false);
    JLabel lbl = new JLabel(label);
    lbl.setFont(new Font("Arial", Font.BOLD, 9));
    lbl.setForeground(new Color(100, 80, 140));
    JLabel val = new JLabel("<html>" + value + "</html>");
    val.setFont(new Font("Arial", Font.PLAIN, 13));
    val.setForeground(Color.WHITE);
    block.add(lbl, BorderLayout.NORTH);
    block.add(val, BorderLayout.CENTER);
    return block;
  }
}
