package blahblah;

import java.awt.Component;
import java.awt.Container;
import java.util.*;
import javax.swing.*;

/** Fixed asks; reference movement is caused only by real simulated stock additions/consumption. */
final class MarketDynamics {
  static final int MAX_LOTS_PER_VARIANT = 24;
  static final int INTERVAL_MS = hGui.MARKET_UPDATE_INTERVAL;
  private final hGui app;

  MarketDynamics(hGui app) {
    this.app = app;
  }

  static double factor(String name) {
    return 1.0;
  } // no hidden multiplier on an existing ask

  static double cents(double value) {
    return !Double.isFinite(value) || value <= 0
        ? value
        : Math.max(.01, Math.round(value * 100.0) / 100.0);
  }

  static double step(double previous, Random random) {
    double magnitude = .0025 + random.nextDouble() * .0025;
    return previous * (random.nextBoolean() ? 1 + magnitude : 1 - magnitude);
  }

  static double floatPremium(String wear, double value) {
    return floatPremium(wear, value, 0, 1);
  }

  static double floatPremium(String wear, double value, double minimum, double maximum) {
    if (!Double.isFinite(value) || value < 0 || "Normal".equals(wear)) return 1;
    if ("Factory New".equals(wear)) {
      if (minimum > 0) {
        double span = Math.max(.00000001, Math.min(.07, maximum) - minimum);
        double position = Math.max(0, Math.min(1, (value - minimum) / span));
        return 1 + .8 * (1 - position) * (1 - position);
      }
      double baseline = Math.sqrt(.0005 / .07);
      return 1
          + Math.min(
              5,
              Math.max(
                  0,
                  1.5 * (Math.sqrt(.0005 / Math.max(.000001, value)) - baseline) / (1 - baseline)));
    }
    double edge =
        "Minimal Wear".equals(wear)
            ? .07
            : "Field-Tested".equals(wear)
                ? .15
                : "Well-Worn".equals(wear) ? .38 : "Battle-Scarred".equals(wear) ? .45 : -1;
    if (edge < 0) return 1;
    double low = Math.max(edge, minimum);
    double upper =
        "Minimal Wear".equals(wear)
            ? .15
            : "Field-Tested".equals(wear) ? .38 : "Well-Worn".equals(wear) ? .45 : 1;
    double span = Math.max(.00000001, Math.min(upper, maximum) - low);
    double position = Math.max(0, Math.min(1, (value - low) / span));
    return 1 + .12 * (1 - position) * (1 - position);
  }

  // Kept as lifecycle hooks for old callers; the ONLY clock is app.marketTimer.
  void start() {}

  void stop() {}

  void tick() {
    final long version = app.worldVersion;
    List<Runnable> changes = new ArrayList<>();
    for (ArrayList<MarketListing> bucket : new ArrayList<>(app.globalMarketListings.values())) {
      Map<String, List<MarketListing>> variants = new LinkedHashMap<>();
      synchronized (bucket) {
        for (MarketListing lot : bucket) {
          if (lot == null || lot.item == null || lot.isPlayerListing || lot.quantity <= 0) continue;
          if (!Double.isFinite(lot.getPrice()) || lot.getPrice() <= 0) continue;
          variants
              .computeIfAbsent(MarketplacePricing.variant(lot.item), k -> new ArrayList<>())
              .add(lot);
        }
      }
      for (List<MarketListing> lots : variants.values()) {
        // Warm exact per-lot minima OFF the EDT. Later reads use cached extreme indices.
        for (MarketListing lot : lots) app.marketplaceUnitStock.floorAsk(lot);
        boolean buy = hGui.random.nextBoolean() || lots.size() >= MAX_LOTS_PER_VARIANT;
        double magnitude = .0025 + hGui.random.nextDouble() * .0025;
        changes.add(() -> move(bucket, lots, buy, magnitude));
      }
    }
    for (int first = 0; first < changes.size(); first += 24) {
      int start = first, end = Math.min(first + 24, changes.size());
      Runnable batch =
          () -> {
            if (version != app.worldVersion) return;
            for (int i = start; i < end; i++) changes.get(i).run();
          };
      if (SwingUtilities.isEventDispatchThread()) batch.run();
      else
        try {
          SwingUtilities.invokeAndWait(batch);
        } catch (InterruptedException e) {
          Thread.currentThread().interrupt();
          return;
        } catch (java.lang.reflect.InvocationTargetException e) {
          throw new IllegalStateException("Order-flow batch failed", e.getCause());
        }
    }
    app.marketStockService.invalidateGroupedMarketListingsCache();
    app.exchangeStockService.rebuildExchangeIndex();
  }

  void move(
      ArrayList<MarketListing> bucket, List<MarketListing> lots, boolean buy, double magnitude) {
    lots.removeIf(l -> l.quantity <= 0 || l.isPlayerListing);
    if (lots.isEmpty()) return;
    lots.sort(Comparator.comparingDouble(app.marketplaceUnitStock::floorAsk));
    MarketListing best = lots.get(0);
    double floor = app.marketplaceUnitStock.floorAsk(best);
    if (!Double.isFinite(floor) || floor <= 0) return;
    double rate =
        app.salesSimulationService.getSimulatedSalesPerMinute(
            best.item.rarity, floor, best.item.isStattrak);
    double mean = rate * INTERVAL_MS / 60000.0 * (buy ? 2 : 1);
    int units =
        (int) Math.floor(mean) + (hGui.random.nextDouble() < mean - Math.floor(mean) ? 1 : 0);
    if (buy) {
      // Expensive/illiquid books can have no trade this refresh: never invent high-value volume.
      double target = floor * (1 + magnitude);
      for (int i = 0; i < Math.min(100, units); i++) {
        MarketListing cheapest = null;
        double ask = Double.POSITIVE_INFINITY;
        for (MarketListing lot : lots)
          if (lot.quantity > 0) {
            double price = app.marketplaceUnitStock.floorAsk(lot);
            if (price < ask) {
              ask = price;
              cheapest = lot;
            }
          }
        if (cheapest == null || ask >= target) break;
        app.marketplaceUnitStock.consume(app.marketplaceUnitStock.cheapest(cheapest));
      }
      synchronized (bucket) {
        bucket.removeIf(l -> !l.isPlayerListing && l.quantity <= 0);
      }
    } else {
      double target = cents(floor * (1 - magnitude));
      if (target >= floor || lots.size() >= MAX_LOTS_PER_VARIANT)
        return; // cents / bounded compact-book depth
      if (app.globalSupply.ready()) {
        long listed = 0;
        synchronized (bucket) {
          for (MarketListing l : bucket)
            if (MarketplacePricing.variant(best.item).equals(MarketplacePricing.variant(l.item)))
              listed += Math.max(0, l.quantity);
        }
        long reserve = app.globalSupply.unlisted(best.item, listed);
        if (reserve <= 0) return;
        units = (int) Math.min(Math.max(1, units), reserve);
      }
      InventoryItem source = best.item;
      InventoryItem item =
          new InventoryItem(
              null,
              source.name,
              source.condition,
              source.rarity,
              app.coreUtilities.money(target),
              source.itemFloat,
              source.isStattrak,
              source.patternID,
              source.blueGemTier,
              source.basePrice,
              true);
      item.collection = source.collection;
      MarketListing fresh = new MarketListing(item, target, 120, true);
      fresh.isPlayerListing = false;
      fresh.quantity = Math.max(1, Math.min(100, units));
      MarketplaceProfile profile = MarketplaceProfile.byName(best.marketplaceName);
      if (profile == null) profile = MarketplaceProfile.CATALOG[0];
      app.marketStockService.assignMarketplaceProfile(fresh, profile);
      double initial = app.marketplaceUnitStock.floorAsk(fresh);
      fresh.setPrice(
          target / (initial / target)); // calibrate ONLY this new lot, never an existing ask
      fresh.item.price = app.coreUtilities.money(fresh.getPrice());
      synchronized (bucket) {
        bucket.add(fresh);
      }
    }
  }

  void refreshVisible() {
    if (app.mainTabs != null
        && app.mainTabs.getSelectedIndex() == 4
        && app.storeScreen.sections != null
        && app.storeScreen.sections.getSelectedIndex() == 1
        && app.exchangeHostSections != null)
      refreshSelected(app.exchangeHostSections.getSelectedComponent());
  }

  private boolean refreshSelected(Component component) {
    if (component instanceof JComponent) {
      Object refresh = ((JComponent) component).getClientProperty("refreshPrices");
      if (!(refresh instanceof Runnable))
        refresh = ((JComponent) component).getClientProperty("refreshExchange");
      if (refresh instanceof Runnable) {
        ((Runnable) refresh).run();
        return true;
      }
    }
    if (component instanceof JTabbedPane)
      return refreshSelected(((JTabbedPane) component).getSelectedComponent());
    if (component instanceof Container)
      for (Component child : ((Container) component).getComponents())
        if (refreshSelected(child)) return true;
    return false;
  }
}
