package blahblah;

import java.awt.*;
import java.util.List;
import java.util.function.*;
import javax.swing.*;

/**
 * Closeable, paged tabs show every independently addressable unit, never repeated lot-head floats.
 */
final class MarketplaceStackPicker {
  private final hGui app;

  MarketplaceStackPicker(hGui app) {
    this.app = app;
  }

  void owned(
      MarketplaceProfile site,
      Component parent,
      List<InventoryItem> items,
      Predicate<InventoryItem> selected,
      Consumer<InventoryItem> choose,
      boolean single) {
    show(
        site,
        items.get(0).name + " / owned",
        items::size,
        mode -> {
          Integer[] ids = new Integer[items.size()];
          for (int n = 0; n < ids.length; n++) ids[n] = n;
          java.util.Arrays.sort(
              ids,
              (a, b) ->
                  mode >= 3
                      ? (mode == 3 ? 1 : -1) * items.get(a).price.compareTo(items.get(b).price)
                      : (mode == 1 ? 1 : -1)
                          * Double.compare(items.get(a).itemFloat, items.get(b).itemFloat));
          return java.util.Arrays.stream(ids).mapToInt(Integer::intValue).toArray();
        },
        (index, refresh, close) -> {
          InventoryItem item = items.get(index);
          JPanel card =
              app.cs2Screens.createCs2SkinCard(
                  item,
                  () -> {
                    if (!app.containerMarketService.owns(item)) return;
                    choose.accept(item);
                    if (single) close.run();
                    else refresh.run();
                  });
          card.putClientProperty("inventoryItem", item);
          card.setToolTipText(null);
          app.marketCardSelection.select(
              card, selected.test(item), app.exchangeWidgets.exchangeAccent(site));
          return card;
        });
  }

  void lots(
      MarketplaceProfile site,
      Component parent,
      MarketplaceGroups.Group group,
      Predicate<MarketListing> selected,
      Consumer<MarketListing> choose) {
    show(
        site,
        group.head().item.name + " / individual offers",
        group::units,
        mode ->
            mode >= 3
                ? app.marketplaceUnitStock.sortedPriceRanks(group, mode == 3)
                : app.marketplaceUnitStock.sortedRanks(group, mode == 1),
        (index, refresh, close) -> {
          MarketListing unit = app.marketplaceUnitStock.at(group, index);
          JPanel card =
              unitCard(
                  site,
                  unit,
                  () -> {
                    if (!app.exchangeTransactionService.isExchangeLotAvailable(unit)) return;
                    choose.accept(unit);
                    refresh.run();
                  },
                  true);
          app.marketCardSelection.select(
              card, selected.test(unit), app.exchangeWidgets.exchangeAccent(site));
          return card;
        });
  }

  void buy(
      MarketplaceProfile site,
      Component parent,
      MarketplaceGroups.Group group,
      Consumer<MarketListing> purchase) {
    MarketListing[] selection = {null};
    show(
        site,
        group.head().item.name + " / individual offers",
        group::units,
        mode ->
            mode >= 3
                ? app.marketplaceUnitStock.sortedPriceRanks(group, mode == 3)
                : app.marketplaceUnitStock.sortedRanks(group, mode == 1),
        (index, refresh, close) -> {
          MarketListing unit = app.marketplaceUnitStock.at(group, index);
          JPanel card =
              unitCard(
                  site,
                  unit,
                  () -> {
                    selection[0] = unit;
                    refresh.run();
                  },
                  false);
          app.marketCardSelection.select(
              card, unit.equals(selection[0]), app.exchangeWidgets.exchangeAccent(site));
          JPanel ticket = app.exchangeWidgets.exchangePanel(site, new BorderLayout());
          ticket.add(card);
          JButton buy =
              app.exchangeWidgets.exchangeButton(
                  site,
                  unit.isPlayerListing ? "YOUR LISTING" : "BUY",
                  () -> {
                    purchase.accept(unit);
                    selection[0] = null;
                    refresh.run();
                  });
          buy.setName("exchangeOfferBuy");
          buy.setEnabled(!unit.isPlayerListing && unit.equals(selection[0]));
          ticket.add(buy, BorderLayout.SOUTH);
          return ticket;
        });
  }

  private JPanel unitCard(
      MarketplaceProfile site, MarketListing unit, Runnable select, boolean swap) {
    JPanel card = app.exchangeCatalogScreens.createExchangeListingCard(site, unit, select, swap);
    new MarketplaceBuyScreen(app)
        .setQuantity(
            card,
            app.floatRules.hasNoFloatWear(unit.item.name)
                ? "No float / 1 individual offer"
                : String.format(
                    java.util.Locale.US,
                    "Float %.8f / Pattern %d",
                    unit.item.itemFloat,
                    unit.item.patternID));
    card.setToolTipText(null);
    return card;
  }

  interface CardFactory {
    JPanel create(int index, Runnable refresh, Runnable close);
  }

  private void show(
      MarketplaceProfile site,
      String title,
      IntSupplier count,
      java.util.function.IntFunction<int[]> sortedOrder,
      CardFactory factory) {
    JPanel root = app.exchangeWidgets.exchangePanel(site, new BorderLayout(12, 12));
    root.setName("temporaryIndividualOffers");
    root.setBorder(BorderFactory.createEmptyBorder(16, 18, 16, 18));
    JLabel heading = app.exchangeWidgets.exchangeLabel(title, 20, Color.WHITE);
    JPanel toolbar = app.cs2Screens.cs2Glass(new BorderLayout(12, 0));
    toolbar.add(heading);
    JComboBox<String> sort =
        app.uiWidgets.createComboBox(
            new String[] {
              "Price: lowest first",
              "Price: highest first",
              "Float: low to high",
              "Float: high to low"
            });
    sort.setName("individualOfferFloatSort");
    toolbar.add(sort, BorderLayout.EAST);
    root.add(toolbar, BorderLayout.NORTH);
    int[][] order = {null};
    int[] orderedCount = {-1};
    JPanel grid = app.cs2Screens.cs2Grid(5, 10, 12);
    grid.setName("exchangeStackIndividuals");
    root.add(app.exchangeWidgets.exchangeScroll(grid));
    JPanel controls = app.cs2Screens.cs2Glass(new FlowLayout());
    JLabel status = app.exchangeWidgets.exchangeLabel("", 12, Color.WHITE);
    int[] page = {0};
    Runnable[] render = {null}, close = {null};
    JButton prev =
        app.exchangeWidgets.exchangeButton(
            site,
            "‹",
            () -> {
              page[0]--;
              render[0].run();
            });
    JButton next =
        app.exchangeWidgets.exchangeButton(
            site,
            "›",
            () -> {
              page[0]++;
              render[0].run();
            });
    controls.add(prev);
    controls.add(status);
    controls.add(next);
    controls.add(app.exchangeWidgets.exchangeButton(site, "Close tab", () -> close[0].run()));
    root.add(controls, BorderLayout.SOUTH);
    boolean[] sorting = {false}, disposed = {false};
    java.util.List<SwingWorker<int[], Void>> jobs = new java.util.ArrayList<>();
    root.putClientProperty(
        "disposeTemporaryView",
        (Runnable)
            () -> {
              disposed[0] = true;
              for (SwingWorker<?, ?> job : jobs) job.cancel(true);
            });
    render[0] =
        () -> {
          int total = count.getAsInt(), pages = Math.max(1, (total + 14) / 15);
          page[0] = Math.max(0, Math.min(page[0], pages - 1));
          if (order[0] == null || orderedCount[0] != total) {
            if (total > 2000) {
              if (sorting[0]) return;
              sorting[0] = true;
              sort.setEnabled(false);
              status.setText("Sorting " + String.format("%,d", total) + " individual offers…");
              final int selection = sort.getSelectedIndex();
              final int direction = new int[] {3, 4, 1, 2}[selection];
              SwingWorker<int[], Void> job =
                  new SwingWorker<int[], Void>() {
                    protected int[] doInBackground() {
                      return sortedOrder.apply(direction);
                    }

                    protected void done() {
                      sorting[0] = false;
                      if (disposed[0] || isCancelled()) return;
                      sort.setEnabled(true);
                      try {
                        int[] result = get();
                        if (total == count.getAsInt() && selection == sort.getSelectedIndex()) {
                          order[0] = result;
                          orderedCount[0] = total;
                        }
                        render[0].run();
                      } catch (Exception ex) {
                        status.setText("Stock changed. Choose a sort to refresh.");
                      }
                      jobs.remove(this);
                    }
                  };
              jobs.add(job);
              job.execute();
              return;
            }
            order[0] = sortedOrder.apply(new int[] {3, 4, 1, 2}[sort.getSelectedIndex()]);
            orderedCount[0] = total;
          }
          grid.removeAll();
          for (int n = page[0] * 15; n < Math.min(total, (page[0] + 1) * 15); n++)
            grid.add(factory.create(order[0][n], render[0], () -> close[0].run()));
          status.setText(
              String.format("%,d individual offers / Page %d / %d", total, page[0] + 1, pages));
          prev.setEnabled(page[0] > 0);
          next.setEnabled(page[0] + 1 < pages);
          grid.revalidate();
          grid.repaint();
        };
    sort.addActionListener(
        e -> {
          order[0] = null;
          page[0] = 0;
          render[0].run();
        });
    root.putClientProperty("refreshExchange", render[0]);
    close[0] = app.marketplaceTabs.open(title, root);
    render[0].run();
  }
}
