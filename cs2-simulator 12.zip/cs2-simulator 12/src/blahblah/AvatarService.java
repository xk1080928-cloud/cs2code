package blahblah;

import blahblah.hGui.*;
import java.awt.*;
import java.awt.event.*;
import java.awt.image.BufferedImage;
import javax.swing.*;

/** Avatar Service: focused feature implementation. */
final class AvatarService {
  private final hGui app;

  AvatarService(hGui app) {
    this.app = app;
  }

  void initializeMarketQueue() {
    app.marketProcessQueue.clear();
    app.marketProcessQueue.addAll(app.globalMarketListings.keySet());
  }

  void loadAvatars() {
    app.npcAvatars = new Image[20];
    for (int i = 0; i < app.npcAvatars.length; i++) {
      app.npcAvatars[i] = app.avatarService.createNPCAvatar(i);
    }
    app.playerAvatar = app.avatarService.createPlayerAvatar();
  }

  Image createPlayerAvatar() {
    BufferedImage img = new BufferedImage(64, 64, BufferedImage.TYPE_INT_ARGB);
    Graphics2D g2 = img.createGraphics();
    g2.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);

    g2.setColor(new Color(50, 150, 255));
    g2.fillOval(2, 2, 60, 60);

    g2.setColor(Color.WHITE);
    g2.setFont(new Font("Arial", Font.BOLD, 24));
    String initial = "YOU";
    g2.setFont(new Font("Arial", Font.BOLD, 16));
    FontMetrics fm = g2.getFontMetrics();
    int x = (64 - fm.stringWidth(initial)) / 2;
    int y = ((64 - fm.getHeight()) / 2) + fm.getAscent();
    g2.drawString(initial, x, y);

    g2.dispose();
    return img;
  }

  Image createNPCAvatar(int id) {
    BufferedImage img = new BufferedImage(64, 64, BufferedImage.TYPE_INT_ARGB);
    Graphics2D g2 = img.createGraphics();
    g2.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);

    Color[] colors = {
      new Color(255, 100, 100),
      new Color(100, 150, 255),
      new Color(100, 255, 150),
      new Color(255, 200, 100),
      new Color(200, 100, 255),
      new Color(255, 150, 200),
      new Color(150, 255, 255),
      new Color(255, 255, 100),
      new Color(255, 150, 100),
      new Color(150, 100, 255),
      new Color(100, 255, 200),
      new Color(255, 100, 150),
      new Color(200, 200, 100),
      new Color(100, 200, 255),
      new Color(255, 180, 200),
      new Color(180, 255, 180),
      new Color(200, 150, 255),
      new Color(255, 200, 150),
      new Color(150, 200, 255),
      new Color(255, 220, 150)
    };

    g2.setColor(colors[id % colors.length]);
    g2.fillOval(2, 2, 60, 60);

    g2.setColor(Color.WHITE);
    g2.setFont(new Font("Arial", Font.BOLD, 24));
    String initial = "" + (char) ('A' + (id % 26));
    FontMetrics fm = g2.getFontMetrics();
    int x = (64 - fm.stringWidth(initial)) / 2;
    int y = ((64 - fm.getHeight()) / 2) + fm.getAscent();
    g2.drawString(initial, x, y);

    g2.dispose();
    return img;
  }
}
