package blahblah;

import blahblah.hGui.*;
import java.awt.*;
import java.awt.event.*;
import java.math.BigDecimal;
import java.math.RoundingMode;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import javax.swing.*;

/** Market Runtime: focused feature implementation. */
final class MarketRuntime {
  private final hGui app;
  private final Object capLock = new Object();

  MarketRuntime(hGui app) {
    this.app = app;
  }

  double calculateTotalMarketCap() {
    synchronized (capLock) {
      return app.globalSupply.capitalization();
    }
  }

  void maintainMarketBucketsIncrementally(List<String> keys) {
    if (keys.isEmpty()) return;
    int total = Math.min(48, keys.size());
    // Preserve all 48 buckets of work, but yield between four-bucket EDT transactions.
    for (int base = 0; base < total; base += 4) {
      final int count = Math.min(4, total - base);
      Runnable apply =
          () -> {
            for (int n = 0; n < count; n++) {
              String key = keys.get(Math.floorMod(app.runtimeRestockCursor++, keys.size()));
              ArrayList<MarketListing> bucket = app.globalMarketListings.get(key);
              if (bucket != null) app.marketStockService.rebalanceMarketBucket(key, bucket, true);
            }
          };
      if (SwingUtilities.isEventDispatchThread()) apply.run();
      else
        try {
          SwingUtilities.invokeAndWait(apply);
          java.util.concurrent.locks.LockSupport.parkNanos(8_000_000L);
        } catch (InterruptedException ex) {
          Thread.currentThread().interrupt();
          return;
        } catch (java.lang.reflect.InvocationTargetException ex) {
          throw new IllegalStateException("Incremental market maintenance failed", ex.getCause());
        }
    }
  }

  void startMarketFluctuationTimerAfterInitialization() {
    app.marketTimer =
        new javax.swing.Timer(
            hGui.MARKET_UPDATE_INTERVAL,
            e -> {
              if (app.marketUpdateInProgress) return;
              app.marketUpdateInProgress = true;
              new SwingWorker<Double, Void>() {
                protected Double doInBackground() {
                  {
                    for (String rarity : app.marketPriceMultipliers.keySet()) {
                      double old = app.marketPriceMultipliers.get(rarity);
                      double next = old;
                      ArrayList<Double> values =
                          app.priceHistory.computeIfAbsent(rarity, r -> new ArrayList<>());
                      values.add(next);
                      if (values.size() > 60) values.remove(0);
                    }
                  }
                  List<String> keys = new ArrayList<>(app.globalMarketListings.keySet());
                  app.marketDynamics.tick();
                  app.marketBuffer.tick();
                  Map<String, double[]> collectionTotals = new HashMap<>();
                  Map<String, Double> lowest = new HashMap<>();
                  for (String key : keys) {
                    ArrayList<MarketListing> bucket = app.globalMarketListings.get(key);
                    if (bucket == null) continue;
                    Map<String, Double> minima = new HashMap<>();
                    synchronized (bucket) {
                      for (MarketListing listing : bucket.toArray(new MarketListing[0])) {
                        if (listing == null || listing.item == null) continue;
                        double ask = app.marketplaceUnitStock.floorAsk(listing);
                        if (!Double.isFinite(ask) || ask <= 0) continue;
                        Double previous = minima.get(listing.item.condition);
                        if (previous == null || ask < previous)
                          minima.put(listing.item.condition, ask);
                      }
                    }
                    String collection =
                        app.collectionService.getCollectionName(key.replace("StatTrak ", ""));
                    Map<String, Double> initial = app.initialConditionPrices.get(key);
                    for (Map.Entry<String, Double> entry : minima.entrySet()) {
                      String historyKey = key + ":" + entry.getKey();
                      lowest.put(historyKey, entry.getValue());
                      SimulatedSalesState simulated =
                          app.simulatedSalesStates.get(key + "\u001f" + entry.getKey());
                      if (simulated != null)
                        simulated.quote(entry.getValue(), System.currentTimeMillis());
                      ArrayList<Double> history =
                          app.skinConditionPriceHistory.computeIfAbsent(
                              historyKey, k -> new ArrayList<>());
                      history.add(entry.getValue());
                      if (history.size() > 300) history.remove(0);
                      if (collection != null
                          && initial != null
                          && initial.getOrDefault(entry.getKey(), 0.0) > 0) {
                        double[] aggregate =
                            collectionTotals.computeIfAbsent(collection, k -> new double[2]);
                        aggregate[0] += entry.getValue() / initial.get(entry.getKey());
                        aggregate[1]++;
                      }
                    }
                  }
                  for (Map.Entry<String, double[]> entry : collectionTotals.entrySet()) {
                    ArrayList<Double> history =
                        app.collectionPriceHistory.computeIfAbsent(
                            entry.getKey(), k -> new ArrayList<>());
                    history.add(entry.getValue()[0] / entry.getValue()[1]);
                    if (history.size() > 60) history.remove(0);
                  }
                  // Revalue owned items using the already computed minima, not another scan per
                  // item.
                  synchronized (app.inventoryList) {
                    double value = 0;
                    for (InventoryItem item : app.inventoryList) {
                      if (app.cs2EquipmentScreens.isDefaultWeaponItem(item)) {
                        item.price = BigDecimal.ZERO;
                        continue;
                      }
                      if (!app.itemPriceService.isBlueGem(item)) {
                        String key =
                            (item.isStattrak ? "StatTrak " : "") + item.name + ":" + item.condition;
                        Double known = lowest.get(key);
                        double price =
                            known != null
                                ? known
                                    * MarketDynamics.floatPremium(
                                        item.condition,
                                        item.itemFloat,
                                        app.marketStockService.getMarketWearBounds(item.name)[0],
                                        app.marketStockService.getMarketWearBounds(item.name)[1])
                                : app.listingSalesService.getCurrentMarketPrice(item);
                        item.price = app.coreUtilities.money(price);
                      }
                      value += item.price.doubleValue();
                    }
                    app.inventoryValue = value;
                  }
                  app.marketHomeScreen.refreshMarketplaceSummarySnapshot();
                  return app.inventoryValue;
                }

                protected void done() {
                  try {
                    double value = get();
                    if (app.totalInventoryValueLabel != null)
                      app.totalInventoryValueLabel.setText(
                          "Inventory Value: $" + app.coreUtilities.money(value));
                    app.marketDynamics.refreshVisible();
                    app.marketRuntime.updateTradeOfferPrices();
                    app.activitySimulationService.simulateMarketActivity();
                    app.listingSalesService.updateActiveListings();
                  } catch (InterruptedException ex) {
                    Thread.currentThread().interrupt();
                  } catch (java.util.concurrent.ExecutionException ex) {
                    System.err.println("Market update failed: " + ex.getCause());
                  } finally {
                    app.marketUpdateInProgress = false;
                  }
                }
              }.execute();
            });
    app.marketTimer.setCoalesce(true);
    app.marketTimer.start();
  }

  void updateTradeOfferPrices() {
    ArrayList<TradeOffer> tradesToCancel = new ArrayList<>();

    synchronized (app.pendingTrades) {
      for (TradeOffer trade : app.pendingTrades) {
        double newOfferedValue = 0.0;
        for (InventoryItem item : trade.npcOfferedItems) {
          if (app.itemPriceService.isBlueGem(item)) {
            newOfferedValue += item.price.doubleValue();
          } else {
            double currentPrice = app.listingSalesService.getCurrentMarketPrice(item);
            synchronized (item) {
              item.price = BigDecimal.valueOf(currentPrice).setScale(2, RoundingMode.HALF_UP);
            }
            newOfferedValue += currentPrice;
          }
        }

        double newRequestedValue = 0.0;
        for (InventoryItem item : trade.npcRequestedItems) {
          synchronized (app.inventoryList) {
            if (!app.inventoryList.contains(item)) {
              tradesToCancel.add(trade);
              break;
            }
          }

          if (app.itemPriceService.isBlueGem(item)) {
            newRequestedValue += item.price.doubleValue();
          } else {
            for (InventoryItem invItem : app.inventoryList) {
              if (invItem == item) {
                double currentPrice = app.listingSalesService.getCurrentMarketPrice(invItem);
                synchronized (item) {
                  item.price = BigDecimal.valueOf(currentPrice).setScale(2, RoundingMode.HALF_UP);
                }
                newRequestedValue += currentPrice;
                break;
              }
            }
          }
        }
        newRequestedValue += trade.npcRequestedMoney;

        double offeredTotal = newOfferedValue + trade.npcOfferedMoney;
        double requestedTotal = newRequestedValue;

        if (requestedTotal > 0 && offeredTotal > 0) {
          double lossRatio = offeredTotal / requestedTotal;

          if (lossRatio > 1.15) {
            if (hGui.random.nextDouble() > 0.25) {
              if (!tradesToCancel.contains(trade)) {
                tradesToCancel.add(trade);
              }
            }
          }
        }
      }
    }

    if (!tradesToCancel.isEmpty()) {
      synchronized (app.pendingTrades) {
        app.pendingTrades.removeAll(tradesToCancel);
      }

      app.unreadTradesCount = Math.max(0, app.unreadTradesCount - tradesToCancel.size());
      app.tradeHubScreen.updateTradeNotification();

      SwingUtilities.invokeLater(
          () -> {
            String cancelMsg =
                tradesToCancel.size() == 1
                    ? tradesToCancel.get(0).npcName + " cancelled their offer"
                    : tradesToCancel.size() + " trade offers were cancelled";
            app.priceModifiers.showTradeCancelNotification(cancelMsg);
          });
    }
  }
}
