package blahblah;

import blahblah.hGui.*;
import java.awt.*;
import java.awt.event.*;
import javax.swing.*;

/** Extracted reusable model or widget; behavior retained from the original source. */
public class Mission {
  String id;
  String name;
  String description;
  String type;
  int goal;
  int current;
  int starReward;
  boolean completed;

  Mission(String id, String name, String description, String type, int goal, int starReward) {
    this.id = id;
    this.name = name;
    this.description = description;
    this.type = type;
    this.goal = goal;
    this.starReward = starReward;
    this.current = 0;
    this.completed = false;
  }

  double progressPct() {
    return Math.min(1.0, (double) current / goal);
  }
}
