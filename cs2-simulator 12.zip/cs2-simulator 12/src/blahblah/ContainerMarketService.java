package blahblah;

import blahblah.hGui.*;
import java.util.*;
import java.util.concurrent.ConcurrentHashMap;

/** Real-source container quotes and identity-preserving OwnedSupply sale adapters. */
final class ContainerMarketService {
  private final hGui app;
  private static final Map<String, Double> QUOTES = new ConcurrentHashMap<>();

  ContainerMarketService(hGui app) {
    this.app = app;
  }

  static void publish(CaseType ct, Double quote) {
    double value = quote != null && Double.isFinite(quote) && quote > 0 ? quote : Double.NaN;
    QUOTES.put(ct.catalogCrateName(), value);
    QUOTES.put(ct.name, value);
  }

  static Double quote(String name) {
    return name == null ? null : QUOTES.get(name);
  }

  InventoryItem item(OwnedSupply supply) {
    if (supply.key) throw new IllegalArgumentException("Keys cannot be sold.");
    CaseType ct = CaseType.valueOf(supply.caseId);
    InventoryItem item =
        new InventoryItem(
            null,
            ct.catalogCrateName(),
            "Normal",
            "Container",
            app.coreUtilities.money(
                app.startupArtworkService.hasPurchasableCaseQuote(ct) ? ct.price : 0),
            0,
            false,
            0,
            null,
            supply.purchasePrice);
    item.itemId = "supply:" + supply.id;
    item.createdAt = supply.createdAt;
    item.currentOwner = "YOU";
    return item;
  }

  OwnedSupply supply(InventoryItem item) {
    if (item == null || item.itemId == null || !item.itemId.startsWith("supply:")) return null;
    String id = item.itemId.substring(7);
    for (OwnedSupply s : app.ownedSupplies) if (!s.key && s.id.equals(id)) return s;
    return null;
  }

  boolean owns(InventoryItem item) {
    return item != null && (app.inventoryList.contains(item) || supply(item) != null);
  }

  List<InventoryItem> sellableInventory() {
    List<InventoryItem> result = app.cs2EquipmentScreens.collectibleInventory();
    for (OwnedSupply s : app.ownedSupplies) if (!s.key) result.add(item(s));
    return result;
  }

  void remove(InventoryItem item) {
    OwnedSupply supply = supply(item);
    if (supply != null) app.ownedSupplies.remove(supply);
    else if (app.inventoryList.remove(item))
      app.inventoryValue = Math.max(0, app.inventoryValue - item.price.doubleValue());
    else throw new IllegalArgumentException("That item is no longer owned.");
  }

  void restore(InventoryItem item) {
    CaseType ct = app.exchangeStockService.exchangeContainer(item.name);
    if (ct != null) {
      String id =
          item.itemId != null && item.itemId.startsWith("supply:")
              ? item.itemId.substring(7)
              : UUID.randomUUID().toString();
      if (app.ownedSupplies.stream().noneMatch(s -> s.id.equals(id)))
        app.ownedSupplies.add(new OwnedSupply(ct, false, item.basePrice, id, item.createdAt));
    } else if (!app.inventoryList.contains(item)) {
      app.inventoryList.add(item);
      app.inventoryValue += item.price.doubleValue();
    }
  }
}
