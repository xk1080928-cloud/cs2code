package blahblah;

import blahblah.hGui.*;
import java.io.Serializable;
import java.util.*;

/**
 * Optional UID-6 save extension. Old saves deserialize it as null. No canonical item names change.
 */
final class InventoryToolsState implements Serializable {
  private static final long serialVersionUID = 1L;
  GlobalSupply.State supply;
  BufferedMarketSupply.State marketBuffer;
  CarePackages.State care;
  List<GameState.SerializableInventoryItem> pendingTradeRewards;
  Set<String> favoriteT, favoriteCT;
  final List<Tool> tools = new ArrayList<>();
  final Map<String, String> customNames = new HashMap<>();
  final LinkedHashSet<String> newItems = new LinkedHashSet<>();

  static final class Tool implements Serializable {
    private static final long serialVersionUID = 1L;
    final String id = UUID.randomUUID().toString();
    final boolean storage;
    final long createdAt = System.currentTimeMillis();
    String label = "";
    boolean activated;
    final List<GameState.SerializableInventoryItem> skins = new ArrayList<>();
    final List<OwnedSupply> supplies = new ArrayList<>();
    final List<Tool> tags = new ArrayList<>();

    Tool(boolean storage) {
      this.storage = storage;
    }

    int size() {
      return skins.size() + supplies.size() + tags.size();
    }
  }
}
