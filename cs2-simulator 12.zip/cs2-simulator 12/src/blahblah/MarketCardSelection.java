package blahblah;

import java.awt.*;
import javax.swing.*;
import javax.swing.border.*;

/** Paint-only selection. Original card padding and child bounds never change on selection. */
final class MarketCardSelection {
  private final hGui app;

  MarketCardSelection(hGui app) {
    this.app = app;
  }

  void select(JComponent card, boolean selected, Color color) {
    if (!Boolean.TRUE.equals(card.getClientProperty("stableSelectionBorder"))) {
      Border original = card.getBorder();
      Insets insets = original == null ? new Insets(0, 0, 0, 0) : original.getBorderInsets(card);
      card.setBorder(
          new AbstractBorder() {
            public Insets getBorderInsets(Component c) {
              return new Insets(insets.top, insets.left, insets.bottom, insets.right);
            }

            public Insets getBorderInsets(Component c, Insets out) {
              out.set(insets.top, insets.left, insets.bottom, insets.right);
              return out;
            }

            public void paintBorder(Component c, Graphics g, int x, int y, int w, int h) {
              if (original != null) original.paintBorder(c, g, x, y, w, h);
              if (Boolean.TRUE.equals(card.getClientProperty("marketSelected"))) {
                Graphics2D p = (Graphics2D) g.create();
                p.setColor(color);
                p.setStroke(new BasicStroke(2));
                p.drawRoundRect(x + 1, y + 1, Math.max(0, w - 3), Math.max(0, h - 3), 8, 8);
                p.dispose();
              }
            }
          });
      card.putClientProperty("stableSelectionBorder", true);
    }
    card.putClientProperty("marketSelected", selected);
    card.repaint();
  }
}
