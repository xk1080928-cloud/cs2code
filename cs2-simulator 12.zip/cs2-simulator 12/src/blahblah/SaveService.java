package blahblah;

import blahblah.hGui.*;
import java.awt.*;
import java.awt.event.*;
import java.io.IOException;
import java.math.BigDecimal;
import java.math.RoundingMode;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Map;
import javax.swing.*;

/** Save Service: focused feature implementation. */
final class SaveService {
  private final hGui app;

  SaveService(hGui app) {
    this.app = app;
  }

  private GameState captureProgress() throws Exception {
      app.carePackages.captureMissions();
      GameState state = new GameState();
      state.balance = app.balance;
      state.inventoryTools = app.inventoryToolsService.state;
      state.ownedSupplies =
          app.ownedSupplies == null ? new ArrayList<>() : new ArrayList<>(app.ownedSupplies);
      state.inventoryValue = app.inventoryValue;
      state.openingProfit = app.openingProfit;
      state.totalMarketProfit = app.totalMarketProfit;
      state.totalCrates = app.totalCrates;
      state.totalArmouryRedeems = app.totalArmouryRedeems;
      state.totMil = app.totMil;
      state.totRes = app.totRes;
      state.totClass = app.totClass;
      state.totCov = app.totCov;
      state.totKnife = app.totKnife;
      state.totGlove = app.totGlove;
      state.totIndustrial = app.totIndustrial;
      state.totDistinguished = app.totDistinguished;
      state.totExceptional = app.totExceptional;
      state.totSuperior = app.totSuperior;
      state.totMaster = app.totMaster;
      state.lowestFloat = app.lowestFloat;
      state.currentCaseType = app.currentCase.name();
      state.caseStats = new HashMap<>();
      for (CaseType caseType : CaseType.values()) {
        GameState.CaseTypeStats stats = new GameState.CaseTypeStats();
        stats.timesOpened = caseType.timesOpened;
        stats.totalSpent = caseType.totalSpent;
        stats.totalReceived = caseType.totalReceived;
        state.caseStats.put(caseType.name(), stats);
      }
      state.unlockedAchievements = new ArrayList<>(app.unlockedAchievements);
      state.unboxedSkins = new HashSet<>(app.unboxedSkins);

      state.activeListingItems = new ArrayList<>();
      state.activeListingPrices = new ArrayList<>();
      state.activeListingMarkets = new ArrayList<>();
      state.activeListingFees = new ArrayList<>();
      for (MarketListing ml : app.activeListings) {
        GameState.SerializableInventoryItem sItem = new GameState.SerializableInventoryItem();
        sItem.name = app.leaderboardService.normalizeSkinName(ml.item.name);
        sItem.condition = ml.item.condition;
        sItem.rarity = app.leaderboardService.normalizeSkinName(ml.item.rarity);
        sItem.price = ml.item.price.doubleValue();
        sItem.itemFloat = ml.item.itemFloat;
        sItem.isStattrak = ml.item.isStattrak;
        sItem.patternID = ml.item.patternID;
        sItem.blueGemTier =
            ml.item.blueGemTier != null
                ? app.leaderboardService.normalizeSkinName(ml.item.blueGemTier)
                : null;
        sItem.basePrice = ml.item.basePrice;
        sItem.collection = app.inventoryScreen.resolveInventoryItemCollection(ml.item);
        sItem.createdAt = ml.item.createdAt;
        sItem.currentOwner = ml.item.currentOwner;
        sItem.itemId = ml.item.itemId;
        sItem.history =
            ml.item.history != null ? new ArrayList<>(ml.item.history) : new ArrayList<>();
        state.activeListingItems.add(sItem);
        state.activeListingPrices.add(ml.getPrice());
        state.activeListingMarkets.add(ml.marketplaceName);
        state.activeListingFees.add(ml.saleFee);
      }

      state.inventory = new ArrayList<>();
      for (InventoryItem item : app.inventoryList) {
        GameState.SerializableInventoryItem sItem = new GameState.SerializableInventoryItem();

        sItem.name = app.leaderboardService.normalizeSkinName(item.name);
        sItem.condition = item.condition;
        sItem.rarity = app.leaderboardService.normalizeSkinName(item.rarity);
        sItem.price = item.price.doubleValue();
        sItem.itemFloat = item.itemFloat;
        sItem.isStattrak = item.isStattrak;
        sItem.patternID = item.patternID;
        sItem.blueGemTier =
            item.blueGemTier != null
                ? app.leaderboardService.normalizeSkinName(item.blueGemTier)
                : null;
        sItem.basePrice = item.basePrice;
        sItem.collection = app.inventoryScreen.resolveInventoryItemCollection(item);
        sItem.createdAt = item.createdAt;
        sItem.currentOwner = item.currentOwner;
        sItem.itemId = item.itemId;
        sItem.history = item.history != null ? new ArrayList<>(item.history) : new ArrayList<>();
        state.inventory.add(sItem);
      }

      state.playerStars = app.playerStars;

      state.tLoadoutKeys = new HashMap<>();
      state.ctLoadoutKeys = new HashMap<>();
      for (Map.Entry<String, InventoryItem> e : app.tLoadout.entrySet()) {
        if (e.getValue() != null)
          state.tLoadoutKeys.put(
              e.getKey(), e.getValue().itemId == null ? e.getValue().name : e.getValue().itemId);
      }
      for (Map.Entry<String, InventoryItem> e : app.ctLoadout.entrySet()) {
        if (e.getValue() != null)
          state.ctLoadoutKeys.put(
              e.getKey(), e.getValue().itemId == null ? e.getValue().name : e.getValue().itemId);
      }

      state.achievementProgress = new HashMap<>();
      for (Map.Entry<String, Achievement> entry : app.achievements.entrySet()) {
        state.achievementProgress.put(entry.getKey(), entry.getValue().progress);
      }

      // The extension owns mutable storage/favorites/name maps: detach it on the EDT.
      synchronized(app.globalSupply) { if (state.inventoryTools != null) {
        java.io.ByteArrayOutputStream bytes = new java.io.ByteArrayOutputStream();
        try (java.io.ObjectOutputStream out = new java.io.ObjectOutputStream(bytes)) { out.writeObject(state.inventoryTools); }
        try (java.io.ObjectInputStream in = new java.io.ObjectInputStream(new java.io.ByteArrayInputStream(bytes.toByteArray()))) {
          state.inventoryTools = (InventoryToolsState) in.readObject();
        }
      }
      }
      return state;
  }

  private final Object writeLock = new Object();
  private final java.util.concurrent.atomic.AtomicLong revision = new java.util.concurrent.atomic.AtomicLong();
  private long writtenRevision;
  private final java.util.concurrent.ExecutorService writer = java.util.concurrent.Executors.newSingleThreadExecutor(r -> {
    Thread t = new Thread(r, "simulator-save-writer"); t.setDaemon(true); return t;
  });

  void saveProgress() {
    long version = revision.incrementAndGet();
    try { writeProgress(captureProgress(), version); }
    catch (Exception e) { saveError(e); }
  }

  void saveProgressAsync() {
    // Called on the UI thread: capture identity/ownership now, move disk/JSON work off animation.
    long version = revision.incrementAndGet();
    try {
      GameState snapshot = captureProgress();
      writer.execute(() -> { try { writeProgress(snapshot, version); } catch (Exception e) { saveError(e); } });
    } catch (Exception e) { saveError(e); }
  }

  private void writeProgress(GameState state, long version) throws Exception {
    synchronized (writeLock) {
      if (version < writtenRevision) return; // queued older snapshots cannot overwrite a newer save
      java.nio.file.Path destination = java.nio.file.Paths.get(hGui.SAVE_FILE);
      java.nio.file.Path temporary = java.nio.file.Paths.get(hGui.SAVE_FILE + ".tmp");
      try (java.io.ObjectOutputStream out = new java.io.ObjectOutputStream(java.nio.file.Files.newOutputStream(temporary))) { out.writeObject(state); }
      try { java.nio.file.Files.move(temporary, destination, java.nio.file.StandardCopyOption.REPLACE_EXISTING, java.nio.file.StandardCopyOption.ATOMIC_MOVE); }
      catch (java.nio.file.AtomicMoveNotSupportedException e) { java.nio.file.Files.move(temporary, destination, java.nio.file.StandardCopyOption.REPLACE_EXISTING); }
      saveJsonProgressSnapshot(state);
      writtenRevision = version;
      System.out.println("Save successful! Inventory items: " + state.inventory.size());
    }
  }

  private void saveError(Exception e) {
    System.err.println("Failed to save progress: " + e.getMessage());
    e.printStackTrace();
  }

  String jsonEscape(String value) {
    if (value == null) return "";
    return value
        .replace("\\", "\\\\")
        .replace("\"", "\\\"")
        .replace("\n", "\\n")
        .replace("\r", "\\r");
  }

  void appendJsonItem(StringBuilder json, GameState.SerializableInventoryItem item, String indent) {
    json.append(indent).append("{\n");
    json.append(indent)
        .append("  \"id\": \"")
        .append(app.saveService.jsonEscape(item.itemId))
        .append("\",\n");
    json.append(indent)
        .append("  \"name\": \"")
        .append(app.saveService.jsonEscape(item.name))
        .append("\",\n");
    json.append(indent)
        .append("  \"condition\": \"")
        .append(app.saveService.jsonEscape(item.condition))
        .append("\",\n");
    json.append(indent)
        .append("  \"rarity\": \"")
        .append(app.saveService.jsonEscape(item.rarity))
        .append("\",\n");
    json.append(indent)
        .append("  \"price\": ")
        .append(String.format(java.util.Locale.US, "%.2f", item.price))
        .append(",\n");
    json.append(indent)
        .append("  \"float\": ")
        .append(String.format(java.util.Locale.US, "%.6f", item.itemFloat))
        .append(",\n");
    json.append(indent).append("  \"statTrak\": ").append(item.isStattrak).append(",\n");
    json.append(indent).append("  \"pattern\": ").append(item.patternID).append(",\n");
    json.append(indent)
        .append("  \"blueGemTier\": \"")
        .append(app.saveService.jsonEscape(item.blueGemTier))
        .append("\",\n");
    json.append(indent)
        .append("  \"collection\": \"")
        .append(app.saveService.jsonEscape(item.collection))
        .append("\"\n");
    json.append(indent).append("}");
  }

  void saveJsonProgressSnapshot(GameState state) throws IOException {
    StringBuilder json = new StringBuilder(4096);
    json.append("{\n");
    json.append("  \"version\": 1,\n");
    json.append("  \"balance\": ")
        .append(String.format(java.util.Locale.US, "%.2f", state.balance))
        .append(",\n");
    json.append("  \"inventoryValue\": ")
        .append(String.format(java.util.Locale.US, "%.2f", state.inventoryValue))
        .append(",\n");
    json.append("  \"openingProfit\": ")
        .append(String.format(java.util.Locale.US, "%.2f", state.openingProfit))
        .append(",\n");
    json.append("  \"totalCrates\": ").append(state.totalCrates).append(",\n");
    json.append("  \"currentCaseType\": \"")
        .append(app.saveService.jsonEscape(state.currentCaseType))
        .append("\",\n");
    json.append("  \"playerStars\": ").append(state.playerStars).append(",\n");
    json.append("  \"ownedSupplies\": [");
    if (state.ownedSupplies != null)
      for (int i = 0; i < state.ownedSupplies.size(); i++) {
        OwnedSupply supply = state.ownedSupplies.get(i);
        if (i > 0) json.append(",");
        json.append("{\"id\":\"")
            .append(supply.id)
            .append("\",\"caseId\":\"")
            .append(supply.caseId)
            .append("\",\"key\":")
            .append(supply.key)
            .append(",\"purchasePrice\":")
            .append(supply.purchasePrice)
            .append("}");
      }
    json.append("],\n");
    json.append("  \"inventory\": [\n");
    for (int i = 0; i < state.inventory.size(); i++) {
      app.saveService.appendJsonItem(json, state.inventory.get(i), "    ");
      if (i < state.inventory.size() - 1) json.append(",");
      json.append("\n");
    }
    json.append("  ],\n");
    // Full optional tools payload, independent of runtime item objects; binary save remains
    // primary.
    json.append("  \"inventoryToolsBase64\": \"");
    java.io.ByteArrayOutputStream toolBytes = new java.io.ByteArrayOutputStream();
    try (java.io.ObjectOutputStream toolOut = new java.io.ObjectOutputStream(toolBytes)) {
      toolOut.writeObject(state.inventoryTools);
    }
    json.append(java.util.Base64.getEncoder().encodeToString(toolBytes.toByteArray()))
        .append("\"\n");
    json.append("}\n");
    try (java.io.PrintWriter out =
        new java.io.PrintWriter(
            new java.io.OutputStreamWriter(
                new java.io.FileOutputStream(hGui.SAVE_JSON_FILE),
                java.nio.charset.StandardCharsets.UTF_8))) {
      out.print(json.toString());
    }
  }

  void loadProgress() throws IOException {
    try {
      java.io.File saveFile = new java.io.File(hGui.SAVE_FILE);
      if (!saveFile.exists()) {
        System.out.println("No save file found");
        return;
      }

      GameState state;
      try (java.io.ObjectInputStream ois =
          new java.io.ObjectInputStream(new java.io.FileInputStream(hGui.SAVE_FILE))) {
        state = (GameState) ois.readObject();
      }

      app.worldVersion++;
      boolean resumeMarket=app.marketTimer!=null&&app.marketTimer.isRunning();
      if(resumeMarket)app.marketTimer.stop();
      boolean resumeFake=app.backgroundUnboxing.isEnabled();
      app.backgroundUnboxing.stop();
      System.out.println("Loading save file with " + state.inventory.size() + " items");

      app.balance = state.balance;
      app.inventoryToolsService.state =
          state.inventoryTools == null ? new InventoryToolsState() : state.inventoryTools;
      app.ownedSupplies =
          state.ownedSupplies == null ? new ArrayList<>() : new ArrayList<>(state.ownedSupplies);
      app.inventoryValue = state.inventoryValue;
      app.openingProfit = state.openingProfit;
      app.totalMarketProfit = state.totalMarketProfit;
      app.totalCrates = state.totalCrates;
      app.totalArmouryRedeems = state.totalArmouryRedeems;
      app.totMil = state.totMil;
      app.totRes = state.totRes;
      app.totClass = state.totClass;
      app.totCov = state.totCov;
      app.totKnife = state.totKnife;
      app.totGlove = state.totGlove;
      app.totIndustrial = state.totIndustrial;
      app.totDistinguished = state.totDistinguished;
      app.totExceptional = state.totExceptional;
      app.totSuperior = state.totSuperior;
      app.totMaster = state.totMaster;
      app.lowestFloat = state.lowestFloat;
      app.playerStars = state.playerStars;
      if (app.starsLabel != null) app.starsLabel.setText("* " + app.playerStars + " Stars");

      if (state.currentCaseType != null) {
        try {
          app.currentCase = CaseType.valueOf(state.currentCaseType);
          app.openCrateButton.setText(
              String.format(
                  "OPEN CASE  $%.2f", app.developerTools.getCaseOpeningCost(app.currentCase)));
        } catch (IllegalArgumentException e) {
          app.currentCase = CaseType.WEAPON_CASE_ONE;
          app.openCrateButton.setText(
              String.format(
                  "OPEN CASE  $%.2f", app.developerTools.getCaseOpeningCost(app.currentCase)));
        }
      }

      if (state.caseStats != null) {
        for (CaseType caseType : CaseType.values()) {
          GameState.CaseTypeStats stats = state.caseStats.get(caseType.name());
          if (stats != null) {
            caseType.timesOpened = stats.timesOpened;
            caseType.totalSpent = stats.totalSpent;
            caseType.totalReceived = stats.totalReceived;
          }
        }
      }

      app.unlockedAchievements =
          state.unlockedAchievements != null
              ? new ArrayList<>(state.unlockedAchievements)
              : new ArrayList<>();
      app.unboxedSkins =
          state.unboxedSkins != null ? new HashSet<>(state.unboxedSkins) : new HashSet<>();

      app.activeListings.clear();
      if (state.activeListingItems != null && state.activeListingPrices != null) {
        for (int i = 0; i < state.activeListingItems.size(); i++) {
          GameState.SerializableInventoryItem sItem = state.activeListingItems.get(i);
          double listPrice = state.activeListingPrices.get(i);
          String cleanName = app.leaderboardService.normalizeSkinName(sItem.name);
          Image img = app.artworkService.getSkinImageFromName(cleanName, sItem.condition);
          InventoryItem item =
              new InventoryItem(
                  img != null ? new ImageIcon(img) : null,
                  cleanName,
                  sItem.condition,
                  app.leaderboardService.normalizeSkinName(sItem.rarity),
                  BigDecimal.valueOf(sItem.price).setScale(2, RoundingMode.HALF_UP),
                  sItem.itemFloat,
                  sItem.isStattrak,
                  sItem.patternID,
                  sItem.blueGemTier != null
                      ? app.leaderboardService.normalizeSkinName(sItem.blueGemTier)
                      : null,
                  sItem.basePrice);
          item.collection =
              app.inventoryScreen.hasNoItemCollection(item.rarity) ? null : sItem.collection;
          item.createdAt = sItem.createdAt > 0 ? sItem.createdAt : item.createdAt;
          item.currentOwner = sItem.currentOwner != null ? sItem.currentOwner : item.currentOwner;
          item.itemId = sItem.itemId;
          item.history = sItem.history != null ? new ArrayList<>(sItem.history) : new ArrayList<>();
          int sellTime = app.listingSalesService.calculateSellTime(listPrice, sItem.price);
          MarketListing restored = new MarketListing(item, listPrice, sellTime, true);
          if (state.activeListingMarkets != null && i < state.activeListingMarkets.size()) {
            MarketplaceProfile profile =
                MarketplaceProfile.byName(state.activeListingMarkets.get(i));
            restored.marketplaceName = profile.name;
            restored.marketplaceType = profile.type;
          }
          if (state.activeListingFees != null && i < state.activeListingFees.size())
            restored.saleFee = state.activeListingFees.get(i);
          app.activeListings.add(restored);
        }
      }

      app.inventoryList.clear();
      for (GameState.SerializableInventoryItem sItem : state.inventory) {
        String cleanName = app.leaderboardService.normalizeSkinName(sItem.name);
        String cleanRarity = app.leaderboardService.normalizeSkinName(sItem.rarity);
        String cleanBlueGem =
            sItem.blueGemTier != null
                ? app.leaderboardService.normalizeSkinName(sItem.blueGemTier)
                : null;

        Image img = app.artworkService.getSkinImageFromName(cleanName, sItem.condition);
        InventoryItem item =
            new InventoryItem(
                img != null ? new ImageIcon(img) : null,
                cleanName,
                sItem.condition,
                cleanRarity,
                BigDecimal.valueOf(sItem.price).setScale(2, RoundingMode.HALF_UP),
                sItem.itemFloat,
                sItem.isStattrak,
                sItem.patternID,
                cleanBlueGem,
                sItem.basePrice);
        item.collection =
            app.inventoryScreen.hasNoItemCollection(item.rarity) ? null : sItem.collection;
        item.createdAt = sItem.createdAt > 0 ? sItem.createdAt : item.createdAt;
        item.currentOwner = sItem.currentOwner != null ? sItem.currentOwner : item.currentOwner;
        item.itemId = sItem.itemId;
        item.history = sItem.history != null ? new ArrayList<>(sItem.history) : new ArrayList<>();
        app.inventoryList.add(item);
        System.out.println("Loaded item: " + cleanName);
      }

      if (state.achievementProgress != null) {
        for (Map.Entry<String, Integer> entry : state.achievementProgress.entrySet()) {
          Achievement ach = app.achievements.get(entry.getKey());
          if (ach != null) {
            ach.progress = entry.getValue();
            if (app.unlockedAchievements.contains(entry.getKey())) {
              ach.isUnlocked = true;
            }
          }
        }
      }

      app.tLoadout.clear();
      app.ctLoadout.clear();
      if (state.tLoadoutKeys != null) {
        for (Map.Entry<String, String> e : state.tLoadoutKeys.entrySet()) {
          for (InventoryItem inv : app.inventoryList) {
            if (inv.name.equals(e.getValue()) || e.getValue().equals(inv.itemId)) {
              app.tLoadout.put(e.getKey(), inv);
              break;
            }
          }
        }
      }
      if (state.ctLoadoutKeys != null) {
        for (Map.Entry<String, String> e : state.ctLoadoutKeys.entrySet()) {
          for (InventoryItem inv : app.inventoryList) {
            if (inv.name.equals(e.getValue()) || e.getValue().equals(inv.itemId)) {
              app.ctLoadout.put(e.getKey(), inv);
              break;
            }
          }
        }
      }

      app.skinImage = null;
      app.crateImage = app.containerBrowserScreen.getContainerImage(app.currentCase);

      app.rarityLabel.setText("");
      app.nameLabel.setText("");
      app.priceLabel.setText("");
      app.floatLabel.setText("");
      app.conditionLabel.setText("");
      app.patternId.setText("");
      app.collectionLabel.setText("");

      app.openCrateButton.setVisible(true);
      app.closeCrateButton.setVisible(false);
      app.lowFloatLabel.setVisible(true);

      app.uiWidgets.updateBalanceLabel();
      app.caseRollService.writeStats();
      BigDecimal newInventoryValue =
          BigDecimal.valueOf(app.inventoryValue).setScale(2, RoundingMode.HALF_UP);
      app.totalInventoryValueLabel.setText("Inventory Value: $" + newInventoryValue);
      app.lowFloatLabel.setText(String.format("Lowest Float: %.10f", app.lowestFloat));

      BigDecimal roundedProfit =
          BigDecimal.valueOf(app.openingProfit).setScale(2, RoundingMode.HALF_UP);
      if (roundedProfit.signum() >= 0) {
        app.profitLabel.setForeground(Theme.PROFIT);
        app.profitLabel.setText("Opening Profit: +$" + roundedProfit);
      } else {
        app.profitLabel.setForeground(Color.RED);
        app.profitLabel.setText("Opening Profit: -$" + roundedProfit.abs());
      }

      SwingUtilities.invokeLater(
          () -> {
            app.revalidate();
            app.repaint();
          });

      if(app.marketInitialized){
        new SwingWorker<Void,Void>(){
          protected Void doInBackground(){app.globalSupply.reconcileListings();return null;}
          protected void done(){try{get();if(resumeFake)app.backgroundUnboxing.start();if(resumeMarket)app.marketTimer.start();}catch(Exception ex){System.err.println("World supply restore failed: "+ex);}}
        }.execute();
      }
      app.carePackages.restoreMissions();
      app.itemRevealService.resumeTradeUp();
      if(!app.carePackages.state().pending.isEmpty())app.carePackages.queuePresentation();
      System.out.println("Load complete! Items in inventory: " + app.inventoryList.size());
      System.out.println("Current case type: " + app.currentCase.name);

    } catch (Exception e) {
      System.err.println("Failed to load progress: " + e.getMessage());
      e.printStackTrace();

      app.skinImage = null;
      app.crateImage = app.containerBrowserScreen.getContainerImage(app.currentCase);
      SwingUtilities.invokeLater(
          () -> {
            app.revalidate();
            app.repaint();
          });
    }
  }
}
