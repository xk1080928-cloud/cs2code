package blahblah;

import blahblah.hGui.*;
import java.awt.*;
import java.awt.event.*;
import java.util.ArrayList;
import java.util.Comparator;
import java.util.List;
import javax.swing.*;

/** Inventory Cards: focused feature implementation. */
final class InventoryCards {
  private final hGui app;

  InventoryCards(hGui app) {
    this.app = app;
  }

  public void showInventory() {
    if (app.inventoryList.isEmpty()) {
      JOptionPane.showMessageDialog(app, "Inventory is empty!");
      return;
    }

    JFrame invFrame = new JFrame("Inventory");
    invFrame.setSize(780, 550);
    invFrame.setLocationRelativeTo(app);
    invFrame.setLayout(new BorderLayout());

    invFrame.setAlwaysOnTop(true);

    JPanel controlPanel = new JPanel(new GridLayout(3, 1));

    JPanel searchPanel = new JPanel(new FlowLayout(FlowLayout.LEFT));
    JLabel searchLabel = new JLabel("Search:");
    searchLabel.setForeground(Color.BLACK);
    searchLabel.setFont(new Font("Arial", Font.BOLD, 12));
    JComboBox<String> searchField = app.searchControls.createSearchFieldWithHistory(20);
    searchPanel.add(searchLabel);
    searchPanel.add(searchField);

    JPanel sortPanel = new JPanel(new FlowLayout(FlowLayout.LEFT));
    JLabel sortPriceLabel = new JLabel("Sort by Price:");
    JComboBox<String> priceSortBox =
        new JComboBox<>(new String[] {"Default", "Lowest Price", "Highest Price"});
    app.uiWidgets.styleComboBox(priceSortBox);

    JLabel sortRarityLabel = new JLabel("Filter by Rarity:");
    JComboBox<String> raritySortBox =
        new JComboBox<>(
            new String[] {
              "Default", "Knife", "Gloves", "Covert", "Classified", "Restricted", "Milspec"
            });
    app.uiWidgets.styleComboBox(raritySortBox);

    JLabel sortFloatLabel = new JLabel("Sort by Float:");
    JComboBox<String> floatSortBox =
        new JComboBox<>(new String[] {"Default", "Lowest Float", "Highest Float"});
    app.uiWidgets.styleComboBox(floatSortBox);

    java.util.Set<String> colSetInv = new java.util.LinkedHashSet<>();
    colSetInv.add("All");
    for (InventoryItem it : app.inventoryList) {
      app.inventoryScreen.resolveInventoryItemCollection(it);
      if (it.collection != null && !it.collection.isEmpty()) colSetInv.add(it.collection);
    }
    JLabel sortColLabel = new JLabel("Collection:");
    JComboBox<String> collectionSortBox = new JComboBox<>(colSetInv.toArray(new String[0]));
    app.uiWidgets.styleComboBox(collectionSortBox);

    sortPanel.add(sortPriceLabel);
    sortPanel.add(priceSortBox);
    sortPanel.add(sortRarityLabel);
    sortPanel.add(raritySortBox);
    sortPanel.add(sortFloatLabel);
    sortPanel.add(floatSortBox);
    sortPanel.add(sortColLabel);
    sortPanel.add(collectionSortBox);

    controlPanel.add(searchPanel);
    controlPanel.add(sortPanel);

    invFrame.add(controlPanel, BorderLayout.NORTH);

    JPanel grid = new JPanel(new GridLayout(0, 3, 8, 8));
    grid.setBackground(Color.DARK_GRAY);
    grid.setBorder(BorderFactory.createEmptyBorder(10, 10, 10, 10));

    JScrollPane scroll = new JScrollPane(grid);
    app.tradeCards.optimizeScrollPane(scroll);
    invFrame.add(scroll, BorderLayout.CENTER);

    Runnable rebuildGrid =
        () -> {
          grid.removeAll();
          scroll.setColumnHeaderView(null);

          String searchText = app.searchControls.getSearchText(searchField);
          String priceOrder = (String) priceSortBox.getSelectedItem();
          String raritySelection = (String) raritySortBox.getSelectedItem();
          String floatOrder = (String) floatSortBox.getSelectedItem();
          String collectionOrder = (String) collectionSortBox.getSelectedItem();

          List<InventoryItem> filtered = new ArrayList<>(app.inventoryList);

          if (!searchText.isEmpty()) {
            filtered.removeIf(
                item ->
                    !item.name.toLowerCase().contains(searchText)
                        && !item.condition.toLowerCase().contains(searchText)
                        && !item.rarity.toLowerCase().contains(searchText));
          }
          if (!"Default".equals(raritySelection)) {
            filtered.removeIf(it -> !it.rarity.contains(raritySelection));
          }
          if (!"All".equals(collectionOrder)) {
            filtered.removeIf(it -> !collectionOrder.equals(it.collection));
          }

          filtered.sort(
              (a, b) ->
                  Integer.compare(
                      CoreUtilities.rarityRank(a.rarity), CoreUtilities.rarityRank(b.rarity)));

          if ("Lowest Price".equals(priceOrder)) {
            filtered.sort(Comparator.comparing(a -> a.price));
          } else if ("Highest Price".equals(priceOrder)) {
            filtered.sort((a, b) -> b.price.compareTo(a.price));
          }
          if ("Lowest Float".equals(floatOrder)) {
            filtered.sort((a, b) -> Double.compare(a.itemFloat, b.itemFloat));
          } else if ("Highest Float".equals(floatOrder)) {
            filtered.sort((a, b) -> Double.compare(b.itemFloat, a.itemFloat));
          }

          app.inventoryScreen.setPagedInventoryItems(
              grid,
              scroll,
              filtered,
              item -> app.inventoryCards.createInventoryCardFast(item, item.getThumb130()),
              0);
        };

    grid.putClientProperty("rebuildGrid", rebuildGrid);
    javax.swing.Timer searchTimer =
        app.searchControls.createSearchHistoryTimer(searchField, rebuildGrid);
    app.searchControls.installSearchHistoryHandlers(searchField, searchTimer, rebuildGrid);

    priceSortBox.addActionListener(e -> rebuildGrid.run());
    raritySortBox.addActionListener(e -> rebuildGrid.run());
    floatSortBox.addActionListener(e -> rebuildGrid.run());
    collectionSortBox.addActionListener(e -> rebuildGrid.run());

    SwingUtilities.invokeLater(rebuildGrid);

    invFrame.setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
    invFrame.addWindowListener(
        new java.awt.event.WindowAdapter() {
          @Override
          public void windowClosed(java.awt.event.WindowEvent e) {
            app.inventoryScreen.releaseInventoryGridCaches(grid);
          }
        });

    invFrame.setVisible(true);

    javax.swing.Timer timer =
        new javax.swing.Timer(
            100,
            e -> {
              invFrame.setAlwaysOnTop(false);
              invFrame.toFront();
              invFrame.requestFocus();
            });
    timer.setRepeats(false);
    timer.start();
  }

  JPanel createInventoryCardFast(InventoryItem item, ImageIcon cachedImage) {
    return app.inventoryCards.createInventoryCardFast(item, cachedImage, true);
  }

  JPanel createInventoryCardFast(
      InventoryItem item, ImageIcon cachedImage, boolean allowMarketActions) {
    ImageIcon oldImage = item.image;
    app.artworkService.refreshInventoryItemArtwork(item);
    if (oldImage != item.image) cachedImage = item.getThumb110();
    JPanel card = new JPanel(new BorderLayout());
    card.setBackground(new Color(30, 30, 40));
    card.setBorder(
        BorderFactory.createLineBorder(app.itemInspectionScreen.getRarityColor(item.rarity), 2));
    card.setPreferredSize(new Dimension(165, 205));
    card.setMaximumSize(new Dimension(165, 205));

    JLabel imgLabel;
    if (cachedImage != null) {
      imgLabel = new JLabel(cachedImage);
    } else if (item.image != null) {
      Image scaled = item.getThumb110().getImage();
      imgLabel = new JLabel(new ImageIcon(scaled));
    } else {
      String cleanName = item.name.replace("StatTrak ", "").replace("* ", "").trim();
      if (item.blueGemTier != null && cleanName.contains("(Blue Gem"))
        cleanName = cleanName.substring(0, cleanName.indexOf("(Blue Gem")).trim();
      Image img = app.artworkService.getSkinImageFromName(cleanName, item.condition);
      if (img != null) {
        Image scaled = HighQualityImages.fit(img, 110, 75);
        imgLabel = new JLabel(new ImageIcon(scaled));
        item.image = new ImageIcon(img);
      } else {
        imgLabel = new JLabel("?", SwingConstants.CENTER);
        imgLabel.setForeground(Color.WHITE);
      }
    }
    imgLabel.setHorizontalAlignment(SwingConstants.CENTER);
    imgLabel.setPreferredSize(new Dimension(130, 98));
    imgLabel.setBorder(BorderFactory.createEmptyBorder(6, 4, 4, 4));
    String remoteName = app.artworkService.getSkinArtworkKey(item.name, item.condition);
    if (app.imageRepository.get(remoteName) == null)
      app.artworkService.registerPendingRemoteImageLabel(remoteName, imgLabel, 110, 75);
    card.putClientProperty("inventoryArtwork", imgLabel);
    card.putClientProperty("inventoryImageSource", item.image);
    card.putClientProperty("inventoryItem", item);
    card.putClientProperty("inventoryRemoteName", remoteName);

    String displayName = item.isStattrak ? "ST " + item.name : item.name;
    JLabel n = new JLabel(displayName, SwingConstants.CENTER);
    n.setForeground(item.isStattrak ? new Color(255, 153, 51) : Color.WHITE);
    n.setFont(new Font("Consolas", Font.BOLD, 10));

    JLabel c = new JLabel(item.condition, SwingConstants.CENTER);
    c.setForeground(Color.LIGHT_GRAY);
    c.setFont(new Font("Consolas", Font.PLAIN, 9));

    JLabel p = new JLabel("$" + item.price, SwingConstants.CENTER);
    p.putClientProperty("inventoryPriceItem", item);
    card.putClientProperty("inventoryPriceLabel", p);
    p.setForeground(Color.YELLOW);
    p.setFont(new Font("Consolas", Font.BOLD, 10));

    JLabel r = new JLabel(item.rarity, SwingConstants.CENTER);
    r.setForeground(app.itemInspectionScreen.getRarityColor(item.rarity));
    r.setFont(new Font("Consolas", Font.PLAIN, 9));

    app.inventoryScreen.resolveInventoryItemCollection(item);
    JLabel col = new JLabel(item.collection != null ? item.collection : "", SwingConstants.CENTER);
    col.setForeground(new Color(170, 130, 255));
    col.setFont(new Font("Consolas", Font.ITALIC, 8));

    boolean isAgentItem =
        app.itemMetadataService.isAgentSkin(item.name) || "Agent".equals(item.condition);

    JPanel text = new JPanel(new GridLayout(isAgentItem ? 5 : 7, 1, 0, 0));
    text.setBackground(new Color(22, 22, 30));
    text.setBorder(BorderFactory.createEmptyBorder(2, 2, 2, 2));
    text.add(n);
    text.add(c);
    if (!isAgentItem) {
      text.add(app.inventoryCards.createFloatWearBar(item.itemFloat, item.condition));
      JLabel floatLabel =
          new JLabel(String.format("Float: %.6f", item.itemFloat), SwingConstants.CENTER);
      floatLabel.setForeground(Theme.ACCENT_CT);
      floatLabel.setFont(Theme.CONSOLE_PLAIN_9);
      text.add(floatLabel);
    }
    text.add(r);
    text.add(p);
    text.add(col);

    card.add(imgLabel, BorderLayout.CENTER);
    card.add(text, BorderLayout.SOUTH);

    card.addMouseListener(
        new MouseAdapter() {
          public void mouseClicked(MouseEvent e) {
            app.itemInspectionScreen.showItemPopup(item, allowMarketActions);
          }
        });
    return card;
  }

  JComponent createFloatWearBar(double itemFloat, String condition) {
    JComponent bar =
        new JComponent() {
          @Override
          protected void paintComponent(Graphics g) {
            super.paintComponent(g);
            Graphics2D g2 = (Graphics2D) g.create();
            g2.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
            int w = getWidth();
            int h = getHeight();
            int trackY = Math.max(2, h / 2 - 3);
            int trackH = Math.max(4, Math.min(6, h - 4));
            g2.setPaint(
                new GradientPaint(0, 0, new Color(80, 220, 120), w, 0, new Color(190, 70, 55)));
            g2.fillRoundRect(4, trackY, Math.max(1, w - 8), trackH, trackH, trackH);
            g2.setColor(new Color(0, 0, 0, 170));
            g2.drawRoundRect(4, trackY, Math.max(1, w - 8), trackH, trackH, trackH);
            double clamped = Math.max(0.0, Math.min(1.0, itemFloat));
            int markerX = 4 + (int) Math.round((w - 8) * clamped);
            g2.setColor(Color.WHITE);
            g2.fillRect(markerX - 1, Math.max(0, trackY - 2), 3, trackH + 4);
            g2.setColor(Color.BLACK);
            g2.drawRect(markerX - 2, Math.max(0, trackY - 3), 4, trackH + 5);
            g2.dispose();
          }
        };
    bar.setPreferredSize(new Dimension(120, 12));
    bar.setToolTipText(
        String.format("%s float: %.6f", condition != null ? condition : "Item", itemFloat));
    return bar;
  }

  void updateInventoryGridCardWidths(JPanel grid, JScrollPane scroll) {
    if (grid == null || scroll == null) return;
    int viewportWidth = scroll.getViewport().getWidth();
    if (viewportWidth <= 0) return;
    java.awt.Insets insets = grid.getInsets();
    GridLayout layout =
        (grid.getLayout() instanceof GridLayout) ? (GridLayout) grid.getLayout() : null;
    int leftInset = insets != null ? insets.left : 0;
    int rightInset = insets != null ? insets.right : 0;
    int hgap = layout != null ? layout.getHgap() : 8;
    int minCardWidth = 165;
    int usableViewportWidth = viewportWidth - leftInset - rightInset;
    if (usableViewportWidth <= 0) return;
    int columns = Math.max(1, (usableViewportWidth + hgap) / (minCardWidth + hgap));
    columns = Math.min(4, columns);
    if (layout != null) {
      layout.setColumns(columns);
      layout.setRows(0);
    }
    int usableWidth = usableViewportWidth - ((columns - 1) * hgap);
    int cardWidth = Math.max(minCardWidth, usableWidth / columns);
    for (Component comp : grid.getComponents()) {
      if (comp instanceof JPanel) {
        Dimension pref = comp.getPreferredSize();
        if (pref != null && pref.height > 0) {
          Dimension resized = new Dimension(cardWidth, pref.height);
          if (!resized.equals(pref)) {
            comp.setPreferredSize(resized);
            comp.setMaximumSize(resized);
          }
        }
      }
    }
    grid.revalidate();
  }
}
