package blahblah;

import blahblah.hGui.*;
import java.io.Serializable;
import java.util.*;

/** Surviving circulating supply, independent of listings, ownership and sales. */
final class GlobalSupply {
  private final hGui app;

  GlobalSupply(hGui app) {
    this.app = app;
  }

  static final class Entry implements Serializable {
    private static final long serialVersionUID = 1L;
    long quantity;
    double average;
  }

  static final class State implements Serializable {
    private static final long serialVersionUID = 1L;
    boolean seeded;
    final Map<String, Entry> variants = new HashMap<>();
    long initialQuantity, created, destroyed, fakeOpenings;
    // Legacy serialized fields only: retained to read old saves; never sampled or displayed.
    final ArrayList<Double> capHistory = new ArrayList<>();
    final ArrayList<Long> capTimes = new ArrayList<>();
    double peak;
  }

  private State state() {
    if (app.inventoryToolsService.state.supply == null)
      app.inventoryToolsService.state.supply = new State();
    return app.inventoryToolsService.state.supply;
  }

  synchronized boolean ready() {
    return state().seeded;
  }

  synchronized long quantity(String variant) {
    Entry e = state().variants.get(variant);
    return e == null ? 0 : e.quantity;
  }

  synchronized long total() {
    long n = 0;
    for (Entry e : state().variants.values()) n += e.quantity;
    return n;
  }

  private void add(String key, long count, double price) {
    Entry e = state().variants.computeIfAbsent(key, k -> new Entry());
    e.quantity += count;
    if (e.average <= 0 && Double.isFinite(price) && price > 0) e.average = price;
  }

  void initialize() {
    synchronized (this) {
      if (state().seeded) return;
    }
    Map<String, long[]> counts = new HashMap<>();
    Map<String, Double> prices = new HashMap<>();
    Set<MarketListing> seen = Collections.newSetFromMap(new IdentityHashMap<>());
    Set<String> owned = new HashSet<>();
    for (ArrayList<MarketListing> bucket : new ArrayList<>(app.globalMarketListings.values()))
      if (bucket != null)
        synchronized (bucket) {
          for (MarketListing l : bucket) {
            if (l == null || l.item == null || l.quantity <= 0 || !seen.add(l)) continue;
            String key = MarketplacePricing.variant(l.item);
            counts.computeIfAbsent(key, k -> new long[1])[0] += l.quantity;
            prices.put(key, l.getPrice());
            if (l.isPlayerListing && l.item.itemId != null) owned.add(l.item.itemId);
          }
        }
    List<InventoryItem> personal = new ArrayList<>(app.inventoryList);
    for (MarketListing l : app.activeListings)
      if (l.quantity > 0 && !seen.contains(l)) personal.add(l.item);
    for (InventoryToolsState.Tool tool : app.inventoryToolsService.state.tools)
      for (GameState.SerializableInventoryItem i : tool.skins)
        personal.add(InventoryItemCodec.decode(i));
    if (app.inventoryToolsService.state.pendingTradeRewards != null)
      for (GameState.SerializableInventoryItem i :
          app.inventoryToolsService.state.pendingTradeRewards)
        personal.add(InventoryItemCodec.decode(i));
    for (InventoryItem i : personal)
      if (!app.cs2EquipmentScreens.isDefaultWeaponItem(i)
          && (i.itemId == null || owned.add(i.itemId))) {
        String k = MarketplacePricing.variant(i);
        counts.computeIfAbsent(k, v -> new long[1])[0]++;
        prices.putIfAbsent(k, i.price.doubleValue());
      }
    List<OwnedSupply> supplies = new ArrayList<>(app.ownedSupplies);
    for (InventoryToolsState.Tool tool : app.inventoryToolsService.state.tools)
      supplies.addAll(tool.supplies);
    for (OwnedSupply s : supplies)
      if (!s.key && owned.add("supply:" + s.id)) {
        CaseType ct = CaseType.valueOf(s.caseId);
        String k = containerKey(ct);
        counts.computeIfAbsent(k, v -> new long[1])[0]++;
        prices.putIfAbsent(k, ct.price);
      }
    synchronized (this) {
      if (state().seeded) return;
      for (Map.Entry<String, long[]> c : counts.entrySet())
        add(c.getKey(), c.getValue()[0], prices.getOrDefault(c.getKey(), 0.0));
      state().initialQuantity = total();
      state().seeded = true;
    }
  }
  /** Restoring a world never re-mints supply just because a fresh NPC order book was generated. */
  void reconcileListings() {
    initialize();
    Map<String, Long> remaining = new HashMap<>();
    synchronized (this) {
      for (Map.Entry<String, Entry> e : state().variants.entrySet())
        remaining.put(e.getKey(), e.getValue().quantity);
    }
    java.util.function.Consumer<InventoryItem> owned =
        i -> {
          if (!app.cs2EquipmentScreens.isDefaultWeaponItem(i))
            remaining.merge(MarketplacePricing.variant(i), -1L, Long::sum);
        };
    for (InventoryItem i : app.inventoryList) owned.accept(i);
    for (InventoryToolsState.Tool tool : app.inventoryToolsService.state.tools) {
      for (GameState.SerializableInventoryItem i : tool.skins)
        remaining.merge(i.name + "\u001f" + i.condition + "\u001f" + i.isStattrak, -1L, Long::sum);
      for (OwnedSupply box : tool.supplies)
        if (!box.key) remaining.merge(containerKey(CaseType.valueOf(box.caseId)), -1L, Long::sum);
    }
    for (OwnedSupply box : app.ownedSupplies)
      if (!box.key) remaining.merge(containerKey(CaseType.valueOf(box.caseId)), -1L, Long::sum);
    if (app.inventoryToolsService.state.pendingTradeRewards != null)
      for (GameState.SerializableInventoryItem i :
          app.inventoryToolsService.state.pendingTradeRewards)
        remaining.merge(i.name + "\u001f" + i.condition + "\u001f" + i.isStattrak, -1L, Long::sum);
    for (MarketListing l : app.activeListings)
      if (l.quantity > 0)
        remaining.merge(MarketplacePricing.variant(l.item), -(long) l.quantity, Long::sum);
    Set<MarketListing> seen = Collections.newSetFromMap(new IdentityHashMap<>());
    for (ArrayList<MarketListing> bucket : new ArrayList<>(app.globalMarketListings.values()))
      if (bucket != null)
        synchronized (bucket) {
          for (MarketListing l : bucket)
            if (l != null && !l.isPlayerListing && seen.add(l)) {
              String key = MarketplacePricing.variant(l.item);
              long available = Math.max(0, remaining.getOrDefault(key, 0L));
              int keep = (int) Math.min(l.quantity, available);
              app.marketplaceUnitStock.trimTo(l, keep);
              remaining.put(key, available - keep);
            }
          bucket.removeIf(l -> !l.isPlayerListing && l.quantity <= 0);
        }
    app.marketStockService.invalidateGroupedMarketListingsCache();
    app.exchangeStockService.rebuildExchangeIndex();
  }

  static String containerKey(CaseType ct) {
    return ct.catalogCrateName() + "\u001fNormal\u001ffalse";
  }

  synchronized void created(InventoryItem item) {
    created(item, 1);
  }

  synchronized void created(InventoryItem item, int count) {
    if (count <= 0 || !ready() || app.cs2EquipmentScreens.isDefaultWeaponItem(item)) return;
    add(MarketplacePricing.variant(item), count, item.price.doubleValue());
    state().created += count;
  }

  synchronized Map<String, Long> quantities() {
    Map<String, Long> result = new HashMap<>();
    for (Map.Entry<String, Entry> e : state().variants.entrySet())
      result.put(e.getKey(), e.getValue().quantity);
    return result;
  }

  synchronized double reference(String key) {
    Entry e = state().variants.get(key);
    return e == null ? 0 : e.average;
  }

  synchronized void created(CaseType ct, int n) {
    if (!ready()) return;
    add(containerKey(ct), n, ct.price);
    state().created += n;
  }

  synchronized void destroyed(InventoryItem item) {
    destroy(MarketplacePricing.variant(item));
  }

  synchronized void destroyed(CaseType ct) {
    destroy(containerKey(ct));
  }

  private boolean destroy(String key) {
    if (!ready()) return false;
    Entry e = state().variants.get(key);
    if (e == null || e.quantity <= 0) return false;
    e.quantity--;
    state().destroyed++;
    return true;
  }

  synchronized void contract(List<InventoryItem> inputs, InventoryItem result) {
    if (!ready()) return;
    for (InventoryItem i : inputs) destroy(MarketplacePricing.variant(i));
    created(result);
  }

  long listed(String variant) {
    long n = 0;
    for (ArrayList<MarketListing> bucket : new ArrayList<>(app.globalMarketListings.values()))
      if (bucket != null)
        synchronized (bucket) {
          for (MarketListing l : bucket)
            if (l != null && l.quantity > 0 && variant.equals(MarketplacePricing.variant(l.item)))
              n += l.quantity;
        }
    return n;
  }
  // Cheap periodic supply checks are provided the already grouped current book by the caller.
  long personalQuantity(InventoryItem variant) {
    CaseType variantCase = app.exchangeStockService.exchangeContainer(variant.name);
    long n = 0;
    for (InventoryItem i : app.inventoryList)
      if (!app.cs2EquipmentScreens.isDefaultWeaponItem(i)
          && same(variant, i.name, i.condition, i.isStattrak)) n++;
    for (InventoryToolsState.Tool t : app.inventoryToolsService.state.tools) {
      for (GameState.SerializableInventoryItem i : t.skins)
        if (same(variant, i.name, i.condition, i.isStattrak)) n++;
      if (variantCase != null)
        for (OwnedSupply box : t.supplies) if (!box.key && variantCase.id.equals(box.caseId)) n++;
    }
    if (variantCase != null)
      for (OwnedSupply box : app.ownedSupplies)
        if (!box.key && variantCase.id.equals(box.caseId)) n++;
    if (app.inventoryToolsService.state.pendingTradeRewards != null)
      for (GameState.SerializableInventoryItem i :
          app.inventoryToolsService.state.pendingTradeRewards)
        if (same(variant, i.name, i.condition, i.isStattrak)) n++;
    return n;
  }

  long personalTotal() {
    long n = 0;
    for (InventoryItem i : app.inventoryList)
      if (!app.cs2EquipmentScreens.isDefaultWeaponItem(i)) n++;
    for (OwnedSupply s : app.ownedSupplies) if (!s.key) n++;
    for (InventoryToolsState.Tool tool : app.inventoryToolsService.state.tools) {
      n += tool.skins.size();
      for (OwnedSupply s : tool.supplies) if (!s.key) n++;
    }
    if (app.inventoryToolsService.state.pendingTradeRewards != null)
      n += app.inventoryToolsService.state.pendingTradeRewards.size();
    return n;
  }

  private boolean same(InventoryItem v, String name, String wear, boolean st) {
    return v.isStattrak == st && v.name.equals(name) && v.condition.equals(wear);
  }

  synchronized long unlisted(InventoryItem variant, long listed) {
    return Math.max(
        0, quantity(MarketplacePricing.variant(variant)) - listed - personalQuantity(variant));
  }

  boolean fakeOpening(CaseType ct, HomeUnboxEntry reward) {
    if (!ready()) return false;
    long player = app.ownedSupplies.stream().filter(s -> !s.key && s.caseId.equals(ct.id)).count();
    for (InventoryToolsState.Tool t : app.inventoryToolsService.state.tools)
      player += t.supplies.stream().filter(s -> !s.key && s.caseId.equals(ct.id)).count();
    for (MarketListing l : app.activeListings)
      if (l.quantity > 0 && l.item.name.equals(ct.catalogCrateName())) player += l.quantity;
    synchronized (this) {
      if (quantity(containerKey(ct)) <= player) return false;
    }
    ArrayList<MarketListing> bucket = app.globalMarketListings.get(ct.catalogCrateName());
    if (bucket != null)
      synchronized (bucket) {
        for (MarketListing l : bucket)
          if (!l.isPlayerListing && l.quantity > 0) {
            app.marketplaceUnitStock.consume(app.marketplaceUnitStock.cheapest(l));
            break;
          }
      }
    SaleRecord r = reward.record;
    String name = r.skinName;
    boolean st = name.startsWith("StatTrak ");
    if (st) name = name.substring(9);
    if (r.specialVariant != null && name.endsWith(" (" + r.specialVariant + ")"))
      name = name.substring(0, name.length() - r.specialVariant.length() - 3);
    InventoryItem output =
        new InventoryItem(
            null,
            name,
            r.condition,
            reward.rarity,
            app.coreUtilities.money(r.price),
            r.itemFloat,
            st,
            0,
            r.specialVariant,
            r.price,
            true);
    synchronized (this) {
      if (!destroy(containerKey(ct))) return false;
      created(output);
      state().fakeOpenings++;
    }
    app.marketStockService.invalidateGroupedMarketListingsCache();
    return true;
  }

  double capitalization() {
    if (!ready()) initialize();
    Map<String, double[]> observed = new HashMap<>();
    Set<MarketListing> seen = Collections.newSetFromMap(new IdentityHashMap<>());
    for (ArrayList<MarketListing> bucket : new ArrayList<>(app.globalMarketListings.values()))
      if (bucket != null)
        synchronized (bucket) {
          for (MarketListing l : bucket) {
            if (l == null || l.item == null || l.quantity <= 0 || !seen.add(l)) continue;
            double average = app.marketplaceUnitStock.averageAsk(l);
            if (!Double.isFinite(average) || average <= 0) continue;
            double[] sum =
                observed.computeIfAbsent(MarketplacePricing.variant(l.item), k -> new double[2]);
            sum[0] += average * l.quantity;
            sum[1] += l.quantity;
          }
        }
    synchronized (this) {
      for (Map.Entry<String, double[]> p : observed.entrySet()) {
        Entry e = state().variants.get(p.getKey());
        if (e != null) e.average = p.getValue()[0] / p.getValue()[1];
      }
      double cap = 0;
      for (Entry e : state().variants.values())
        if (e.quantity > 0 && Double.isFinite(e.average) && e.average > 0)
          cap += e.quantity * e.average;
      return cap;
    }
  }
}
