package blahblah;

import java.awt.*;
import java.awt.event.*;
import java.awt.geom.Path2D;
import java.awt.image.BufferedImage;
import java.util.*;
import javax.swing.*;

/** In-place two-second geometric redemption, followed by the existing New Item presentation. */
final class ArmouryOrbit {
  private final hGui app;

  ArmouryOrbit(hGui app) {
    this.app = app;
  }

  void start(ArmouryCollection col, String name, String rarity, double basePrice, JButton redeem) {
    app.armouryAnimating = true;
    app.pageTransitions.stop();
    final long version = app.worldVersion;
    FloatRange range = hGui.FLOAT_LIMITS.get(name);
    if (range == null)
      for (Map.Entry<String, FloatRange> entry : hGui.FLOAT_LIMITS.entrySet())
        if (name.startsWith(entry.getKey())) {
          range = entry.getValue();
          break;
        }
    double minimum = range != null && range.min != null ? range.min : 0,
        maximum = range != null && range.max != null ? range.max : .80;
    double f = col.isAgents ? 0 : minimum + hGui.random.nextDouble() * (maximum - minimum);
    String wear = col.isAgents ? "Agent" : app.floatRules.getConditionForFloat(name, f);
    double price =
        col.isAgents
            ? basePrice * app.marketPriceMultipliers.getOrDefault(rarity, 1.0)
            : basePrice
                * app.marketInitialization.getMarketMultiplier(rarity, col.name)
                * app.priceModifiers.getMarketConditionMultiplier(name, wear)
                * (.88 + hGui.random.nextDouble() * .24);
    Image art = col.isAgents ? BundledAgentPreviews.image(name) : null;
    if (art == null) art = app.artworkService.getSkinImageFromName(name, wear);
    InventoryItem item =
        new InventoryItem(
            art == null ? null : new ImageIcon(art),
            name,
            wear,
            rarity,
            app.coreUtilities.money(price),
            f,
            false,
            hGui.random.nextInt(1000),
            null,
            basePrice);
    item.collection = col.name;
    // Ownership is durable before visual work starts. Save/close cannot lose or reroll a charged
    // reward.
    app.ownershipHistoryService.addItemHistory(
        item,
        System.currentTimeMillis(),
        "Armoury Redeem",
        "armoury redeem by YOU from " + col.name,
        "YOU");
    app.activitySimulationService.addRecentUnboxedSkin(item);
    app.globalSupply.created(item);
    app.inventoryList.add(item);
    app.coreUtilities.addInventoryValue(price);
    app.itemRevealService.received(item);
    app.statisticsAndAchievements.recordArmouryOpening(rarity, name, f);
    app.caseRollService.writeStats();
    app.containerSelectionScreen.invalidateCs2Inventory();
    app.saveService.saveProgressAsync();
    JComponent host = app.storeScreen.armouryHost();
    if (host == null) {
      app.armouryAnimating = false;
      if (redeem != null) redeem.setEnabled(true);
      return;
    }
    BufferedImage catalog =
        new BufferedImage(
            Math.max(1, host.getWidth()),
            Math.max(1, host.getHeight()),
            BufferedImage.TYPE_INT_RGB);
    Graphics2D snapshot = catalog.createGraphics();
    host.printAll(snapshot);
    snapshot.dispose();
    Component oldGlass = app.getGlassPane();
    boolean oldVisible = oldGlass.isVisible();
    Point origin = SwingUtilities.convertPoint(host, 0, 0, app.getRootPane());
    Rectangle area = new Rectangle(origin.x, origin.y, host.getWidth(), host.getHeight());
    final long[] began = {System.nanoTime()};
    final boolean[] returning = {false};
    final float[] progress = {0};
    final double[] angle = new double[36], radius = new double[36], size = new double[36];
    final Shape[] shapes = new Shape[36];
    Random random = new Random();
    for (int n = 0; n < shapes.length; n++) {
      angle[n] = random.nextDouble() * Math.PI * 2;
      radius[n] = .25 + random.nextDouble() * .25;
      size[n] = 4 + random.nextDouble() * 11;
      int sides = 3 + n % 6;
      Path2D polygon = new Path2D.Double();
      for (int j = 0; j < sides; j++) {
        double a = j * Math.PI * 2 / sides;
        double r = size[n] * (j % 2 == 0 ? 1 : .55 + random.nextDouble() * .45);
        if (j == 0) polygon.moveTo(Math.cos(a) * r, Math.sin(a) * r);
        else polygon.lineTo(Math.cos(a) * r, Math.sin(a) * r);
      }
      polygon.closePath();
      shapes[n] = polygon;
    }
    JComponent effect =
        new JComponent() {
          protected void paintComponent(Graphics graphics) {
            Graphics2D g = (Graphics2D) graphics.create();
            g.translate(area.x, area.y);
            g.clipRect(0, 0, area.width, area.height);
            g.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
            int w = area.width, h = area.height;
            float p = progress[0];
            g.setPaint(
                new RadialGradientPaint(
                    w * .5f,
                    h * .5f,
                    Math.max(1, w * .62f),
                    new float[] {0, .55f, 1},
                    new Color[] {
                      new Color(41, 91, 89), new Color(18, 37, 49), new Color(9, 18, 29)
                    }));
            g.fillRect(0, 0, w, h);
            if (!returning[0]) {
              for (int n = 0; n < shapes.length; n++) {
                double a = angle[n] + p * Math.PI * (4 + n % 3);
                double distance = Math.pow(1 - p, .75) * radius[n] * Math.min(w, h);
                Graphics2D object = (Graphics2D) g.create();
                object.translate(
                    w * .5 + Math.cos(a) * distance, h * .5 + Math.sin(a) * distance * .78);
                object.rotate(a * 1.7 + n);
                object.setColor(
                    new Color(135 + n % 3 * 30, 205 + n % 2 * 28, 202 + n % 4 * 10, 185));
                object.setStroke(new BasicStroke(n % 3 == 0 ? 2f : 1f));
                if (n % 4 == 0) object.fill(shapes[n]);
                else object.draw(shapes[n]);
                object.dispose();
              }
              float fade = Math.max(0, 1 - p / .12f);
              if (fade > 0) {
                g.setComposite(AlphaComposite.SrcOver.derive(fade));
                g.drawImage(catalog, 0, 0, null);
              }
            } else {
              g.drawImage(catalog, 0, 0, null);
              g.setComposite(AlphaComposite.SrcOver.derive(.12f * (1 - p) * (1 - p)));
              g.setColor(new Color(151, 207, 205));
              g.fillRect(0, 0, w, h);
            }
            g.dispose();
          }
        };
    effect.setName("armouryOrbitEffect");
    effect.addMouseListener(new MouseAdapter() {});
    effect.addMouseMotionListener(new MouseMotionAdapter() {});
    effect.setFocusTraversalKeysEnabled(false);
    effect.setFocusable(true);
    effect.addKeyListener(
        new KeyAdapter() {
          public void keyPressed(KeyEvent e) {
            e.consume();
          }
        });
    app.setGlassPane(effect);
    effect.setVisible(true);
    effect.requestFocusInWindow();
    javax.swing.Timer timer = new javax.swing.Timer(16, null);
    Runnable cleanup =
        () -> {
          timer.stop();
          if (app.getGlassPane() == effect) {
            app.setGlassPane(oldGlass);
            oldGlass.setVisible(oldVisible);
          }
          app.armouryAnimating = false;
          if (redeem != null) redeem.setEnabled(true);
          app.cs2Screens.refreshCs2Inventory();
        };
    timer.addActionListener(
        e -> {
          if (version != app.worldVersion || !app.isDisplayable()) {
            cleanup.run();
            return;
          }
          progress[0] =
              Math.min(
                  1f,
                  (System.nanoTime() - began[0]) / (returning[0] ? 240_000_000f : 2_000_000_000f));
          effect.putClientProperty("orbitProgress", progress[0]);
          effect.repaint();
          if (progress[0] >= 1) {
            timer.stop();
            if (returning[0]) {
              cleanup.run();
              return;
            }
            // This modal method returns after CONTINUE/close, then the same catalog fades back in.
            app.itemRevealService.show(java.util.List.of(item), true, "Armoury Redeem");
            if (version != app.worldVersion) {
              cleanup.run();
              return;
            }
            returning[0] = true;
            progress[0] = 0;
            effect.repaint();
            began[0] = System.nanoTime();
            timer.restart();
          }
        });
    timer.setCoalesce(true);
    timer.start();
  }
}
