package blahblah;

import blahblah.hGui.*;
import java.awt.*;
import java.awt.event.*;
import java.io.IOException;
import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import javax.swing.*;

/** Cs2 Equipment Screens: focused feature implementation. */
final class Cs2EquipmentScreens {
  private final hGui app;

  Cs2EquipmentScreens(hGui app) {
    this.app = app;
  }

  private boolean tradeUpAcknowledged;
  private List<InventoryItem> acknowledgedInputs = new ArrayList<>();

  JPanel tradeUpInputCard(InventoryItem item, Runnable choose) {
    JPanel card = app.cs2Screens.createCs2SkinCard(item, choose);
    String info =
        app.uiWidgets.buildItemInfoHtml(
            item.rarity,
            item.condition,
            item.itemFloat,
            item.patternID,
            app.inventoryScreen.resolveInventoryItemCollection(item),
            false);
    app.uiWidgets.installItemHover(card, info);
    card.putClientProperty("tradeUpItemInfoHtml", info);
    return card;
  }

  void refreshCs2TradeUp() {
    app.tradeUpSelection.removeIf(i -> !app.inventoryList.contains(i));
    app.goldTradeUpMode =
        !app.tradeUpSelection.isEmpty() && app.tradeUpSelection.get(0).rarity.contains("Covert");
    app.tradeUpSelection.removeIf(
        i -> !app.inventoryList.contains(i) || !app.goldTradeUpService.isTradeUpEligibleForMode(i));
    if (!acknowledgedInputs.equals(app.tradeUpSelection)) {
      tradeUpAcknowledged = false;
      acknowledgedInputs = new ArrayList<>(app.tradeUpSelection);
    }
    app.tradeUpTabPanel.removeAll();
    app.tradeUpTabPanel.setLayout(new BorderLayout());
    JPanel scene = app.cs2Screens.cs2Scene(true);
    JPanel controls = app.cs2Screens.cs2Glass(new BorderLayout(16, 0));
    controls.setBorder(BorderFactory.createEmptyBorder(12, 24, 12, 24));
    controls.add(
        app.cs2Screens.cs2Text(
            "ⓘ  Exchange identical-quality items for an item of the next highest quality",
            15,
            Color.WHITE),
        BorderLayout.WEST);
    scene.add(controls, BorderLayout.NORTH);
    JPanel split = app.cs2Screens.cs2Glass(new GridLayout(1, 2, 22, 0));
    split.setBorder(BorderFactory.createEmptyBorder(15, 28, 15, 28));
    JPanel left = app.cs2Screens.cs2Glass(new BorderLayout()),
        right = app.cs2Screens.cs2Glass(new BorderLayout());
    List<InventoryItem> eligible = new ArrayList<>();
    for (InventoryItem item : app.inventoryList)
      if (app.goldTradeUpService.isTradeUpEligibleForMode(item)
          && item.name
              .toLowerCase(java.util.Locale.ROOT)
              .contains(app.cs2TradeUpQuery.toLowerCase(java.util.Locale.ROOT))
          && ("All".equals(app.cs2TradeUpQuality)
              || item.rarity.replace("StatTrak ", "").equals(app.cs2TradeUpQuality))
          && !app.tradeUpSelection.contains(item)
          && (app.tradeUpSelection.isEmpty()
              || item.rarity.equals(app.tradeUpSelection.get(0).rarity)
                  && item.isStattrak == app.tradeUpSelection.get(0).isStattrak)) eligible.add(item);
    eligible.sort(
        java.util.Comparator.comparingInt((InventoryItem i) -> CoreUtilities.rarityRank(i.rarity))
            .thenComparing(i -> i.name, String.CASE_INSENSITIVE_ORDER)
            .thenComparingDouble(i -> i.itemFloat));
    if (app.tradeUpSelection.size()
        >= app.goldTradeUpService.getTradeUpRequiredCount(app.tradeUpSelection)) eligible.clear();
    JLabel available =
        app.cs2Screens.cs2Text(eligible.size() + " Eligible for Exchange", 16, Color.WHITE);
    available.setBorder(BorderFactory.createEmptyBorder(0, 0, 20, 0));
    JPanel sourceHeader = app.cs2Screens.cs2Glass(new BorderLayout(10, 6));
    sourceHeader.add(available, BorderLayout.NORTH);
    JPanel filters = app.cs2Screens.cs2Glass(new BorderLayout(12, 0));
    JTextField search = new JTextField(app.cs2TradeUpQuery);
    search.setToolTipText("Search eligible skins");
    search.setName("cs2TradeUpSearch");
    search.setBackground(new Color(43, 52, 59));
    search.setForeground(Color.WHITE);
    search.setCaretColor(Color.WHITE);
    search.setBorder(BorderFactory.createEmptyBorder(7, 10, 7, 10));
    JComboBox<String> quality =
        app.uiWidgets.createComboBox(
            new String[] {
              "All", "Consumer", "Industrial", "Milspec", "Restricted", "Classified", "Covert"
            });
    quality.setSelectedItem(app.cs2TradeUpQuality);
    quality.setName("cs2TradeUpQuality");
    quality.addActionListener(
        e -> {
          app.cs2TradeUpQuality = (String) quality.getSelectedItem();
          app.cs2TradeUpPage = 0;
          app.cs2EquipmentScreens.refreshCs2TradeUp();
        });
    filters.add(search, BorderLayout.CENTER);
    filters.add(quality, BorderLayout.EAST);
    sourceHeader.add(filters, BorderLayout.SOUTH);
    sourceHeader.setBorder(BorderFactory.createEmptyBorder(0, 0, 15, 0));
    left.add(sourceHeader, BorderLayout.NORTH);
    javax.swing.Timer searchTimer =
        new javax.swing.Timer(
            200,
            e -> {
              app.cs2TradeUpQuery = search.getText();
              app.cs2TradeUpPage = 0;
              app.cs2EquipmentScreens.refreshCs2TradeUp();
              JTextField fresh =
                  app.cs2EquipmentScreens.findCs2TextField(app.tradeUpTabPanel, "cs2TradeUpSearch");
              if (fresh != null) {
                fresh.requestFocusInWindow();
                fresh.setCaretPosition(fresh.getText().length());
              }
            });
    searchTimer.setRepeats(false);
    search
        .getDocument()
        .addDocumentListener(
            new javax.swing.event.DocumentListener() {
              public void insertUpdate(javax.swing.event.DocumentEvent e) {
                searchTimer.restart();
              }

              public void removeUpdate(javax.swing.event.DocumentEvent e) {
                searchTimer.restart();
              }

              public void changedUpdate(javax.swing.event.DocumentEvent e) {
                searchTimer.restart();
              }
            });
    JPanel pool = app.cs2Screens.cs2Grid(4, 16, 22);
    pool.setName("cs2TradeUpEligible");
    int start = app.cs2TradeUpPage * 48;
    int pages = Math.max(1, (eligible.size() + 47) / 48);
    if (start >= eligible.size()) {
      app.cs2TradeUpPage = 0;
      start = 0;
    }
    for (int i = start; i < Math.min(start + 48, eligible.size()); i++) {
      InventoryItem item = eligible.get(i);
      pool.add(
          tradeUpInputCard(
              item,
              () -> {
                int required =
                    app.tradeUpSelection.isEmpty()
                        ? (item.rarity.contains("Covert") ? 5 : 10)
                        : app.goldTradeUpService.getTradeUpRequiredCount(app.tradeUpSelection);
                if (app.tradeUpSelection.size() < required) {
                  app.tradeUpSelection.add(item);
                  app.goldTradeUpMode = item.rarity.contains("Covert");
                  app.cs2EquipmentScreens.refreshCs2TradeUp();
                }
              }));
    }
    JScrollPane poolScroll = new JScrollPane(pool);
    poolScroll.setBorder(null);
    poolScroll.setOpaque(false);
    poolScroll.getViewport().setOpaque(false);
    poolScroll.getVerticalScrollBar().setUnitIncrement(25);
    left.add(poolScroll);
    JPanel paging = app.cs2Screens.cs2Glass(new FlowLayout());
    JButton
        previous =
            app.cs2Screens.cs2Button(
                "‹",
                false,
                e -> {
                  app.cs2TradeUpPage--;
                  app.cs2EquipmentScreens.refreshCs2TradeUp();
                }),
        next =
            app.cs2Screens.cs2Button(
                "›",
                false,
                e -> {
                  app.cs2TradeUpPage++;
                  app.cs2EquipmentScreens.refreshCs2TradeUp();
                });
    previous.setEnabled(app.cs2TradeUpPage > 0);
    next.setEnabled(app.cs2TradeUpPage + 1 < pages);
    paging.add(previous);
    paging.add(
        app.cs2Screens.cs2Text("Page " + (app.cs2TradeUpPage + 1) + " / " + pages, 12, Theme.TEXT));
    paging.add(next);
    left.add(paging, BorderLayout.SOUTH);
    JLabel chosen =
        app.cs2Screens.cs2Text(
            app.tradeUpSelection.size()
                + " / "
                + (app.goldTradeUpMode ? 5 : 10)
                + " Selected for Exchange",
            16,
            Color.WHITE);
    chosen.setBorder(BorderFactory.createEmptyBorder(0, 0, 20, 0));
    right.add(chosen, BorderLayout.NORTH);
    JPanel selection = app.cs2Screens.cs2Grid(4, 16, 22);
    selection.setName("cs2TradeUpSelected");
    for (InventoryItem item : app.tradeUpSelection)
      selection.add(
          tradeUpInputCard(
              item,
              () -> {
                app.tradeUpSelection.remove(item);
                app.cs2EquipmentScreens.refreshCs2TradeUp();
              }));
    JScrollPane chosenScroll = new JScrollPane(selection);
    chosenScroll.setBorder(null);
    chosenScroll.setOpaque(false);
    chosenScroll.getViewport().setOpaque(false);
    right.add(chosenScroll);
    split.add(left);
    split.add(right);
    scene.add(split);
    JPanel bottom = app.cs2Screens.cs2Glass(new FlowLayout(FlowLayout.RIGHT, 12, 16));
    double value = app.tradeUpSelection.stream().mapToDouble(i -> i.price.doubleValue()).sum();
    bottom.add(app.cs2Screens.cs2Text(String.format("Input value $%.2f", value), 14, Color.WHITE));
    bottom.add(
        app.cs2Screens.cs2Button(
            "VIEW OUTCOMES",
            false,
            e -> {
              if (!app.tradeUpSelection.isEmpty())
                app.tradeUpScreen.showTradeUpOutcomes(app.tradeUpSelection);
            }));
    bottom.add(
        app.cs2Screens.cs2Button(
            "CLEAR ITEMS",
            false,
            e -> {
              app.tradeUpSelection.clear();
              app.cs2EquipmentScreens.refreshCs2TradeUp();
            }));
    JCheckBox acknowledge = new JCheckBox("READY TO TRADE UP", tradeUpAcknowledged);
    acknowledge.setName("cs2TradeUpReady");
    acknowledge.setOpaque(false);
    acknowledge.setForeground(Color.WHITE);
    bottom.add(acknowledge);
    JButton proceed =
        app.cs2Screens.cs2Button(
            "PROCEED…",
            true,
            e -> app.tradeUpScreen.executeTradeUp(app.tradeUpSelection, app.tradeUpTabPanel));
    proceed.setName("cs2TradeUpProceed");
    proceed.setEnabled(
        tradeUpAcknowledged
            && !app.itemRevealService.tradeUpPending
            && app.tradeUpSelection.size() == (app.goldTradeUpMode ? 5 : 10));
    acknowledge.addActionListener(
        e -> {
          tradeUpAcknowledged = acknowledge.isSelected();
          acknowledgedInputs = new ArrayList<>(app.tradeUpSelection);
          proceed.setEnabled(
              tradeUpAcknowledged
                  && !app.itemRevealService.tradeUpPending
                  && app.tradeUpSelection.size() == (app.goldTradeUpMode ? 5 : 10));
        });
    bottom.add(proceed);
    scene.add(bottom, BorderLayout.SOUTH);
    app.tradeUpTabPanel.add(scene);
    app.tradeUpTabPanel.revalidate();
    app.tradeUpTabPanel.repaint();
  }

  JTextField findCs2TextField(Container root, String name) {
    for (Component c : root.getComponents()) {
      if (c instanceof JTextField && name.equals(c.getName())) return (JTextField) c;
      if (c instanceof Container) {
        JTextField match = app.cs2EquipmentScreens.findCs2TextField((Container) c, name);
        if (match != null) return match;
      }
    }
    return null;
  }

  void refreshCs2Loadout() {
    app.tLoadout.values().removeIf(item -> !app.inventoryList.contains(item));
    app.ctLoadout.values().removeIf(item -> !app.inventoryList.contains(item));
    app.loadoutTabPanel.removeAll();
    app.loadoutTabPanel.setLayout(new BorderLayout());
    boolean t = app.loadoutSelectedSide == 0;
    Map<String, InventoryItem> equipped = t ? app.tLoadout : app.ctLoadout;
    JPanel scene = app.cs2Screens.cs2Scene(true);
    JPanel header = app.cs2Screens.cs2Glass(new FlowLayout(FlowLayout.CENTER, 20, 12));
    header.add(
        app.cs2Screens.cs2Button(
            "EQUIP CT",
            !t,
            e -> {
              app.loadoutSelectedSide = 1;
              app.cs2EquipmentScreens.refreshCs2Loadout();
            }));
    header.add(
        app.cs2Screens.cs2Button(
            "EQUIP T",
            t,
            e -> {
              app.loadoutSelectedSide = 0;
              app.cs2EquipmentScreens.refreshCs2Loadout();
            }));
    scene.add(header, BorderLayout.NORTH);
    JPanel columns = app.cs2Screens.cs2Glass(new GridLayout(1, 4, 16, 0));
    columns.setBorder(BorderFactory.createEmptyBorder(18, 5, 28, 42));
    String[][] groups = {
      app.cs2EquipmentScreens.concatCs2Slots(
          t ? hGui.T_SLOTS_PISTOL : hGui.CT_SLOTS_PISTOL,
          t ? hGui.T_SLOTS_OTHER : hGui.CT_SLOTS_OTHER),
      app.cs2EquipmentScreens.concatCs2Slots(
          t ? hGui.T_SLOTS_SMG : hGui.CT_SLOTS_SMG, t ? hGui.T_SLOTS_HEAVY : hGui.CT_SLOTS_HEAVY),
      t ? hGui.T_SLOTS_RIFLE : hGui.CT_SLOTS_RIFLE,
      new String[] {
        "Knife_" + (t ? "T" : "CT"),
        "Gloves_" + (t ? "T" : "CT"),
        t ? hGui.AGENT_SLOT_T : hGui.AGENT_SLOT_CT
      }
    };
    String[] labels = {"STARTING / OTHER PISTOLS", "MID-TIER", "RIFLES", "KNIFE / GLOVES / AGENT"};
    for (int c = 0; c < 4; c++) {
      JPanel column = app.cs2Screens.cs2Glass(new BorderLayout(0, 12));
      column.add(
          app.cs2Screens.cs2Text(labels[c], 14, new Color(187, 207, 216)), BorderLayout.NORTH);
      JPanel weapons = app.cs2Screens.cs2Grid(1, 0, 8);
      for (String weapon : groups[c]) {
        InventoryItem selected = equipped.get(weapon);
        if (selected == null) {
          final String expected =
              weapon.startsWith("Knife_")
                  ? (t ? "T Knife" : "CT Knife")
                  : weapon.startsWith("Gloves_") ? (t ? "T Gloves" : "CT Gloves") : weapon;
          selected =
              app.inventoryList.stream()
                  .filter(i -> isDefaultWeaponItem(i) && i.name.equals(expected + " | Default"))
                  .findFirst()
                  .orElse(null);
        }
        final InventoryItem item = selected;
        JLabel art = new JLabel("", SwingConstants.CENTER);
        if (item != null)
          app.artworkService.getSkinImageFromName(item.name, item.condition, art, 195, 76);
        else {
          Image stock = app.imageRepository.get("cs2-stock-" + weapon);
          if (stock != null)
            art.setIcon(new ImageIcon(app.cs2Screens.scaleCs2Image(stock, 195, 76)));
        }
        JPanel card =
            app.cs2Screens.createCs2Tile(
                weapon.replace('_', ' '),
                item == null
                    ? "Default"
                    : item.name.split(" \\| ", 2).length > 1
                        ? item.name.split(" \\| ", 2)[1]
                        : item.condition,
                item == null ? new Color(165, 180, 190) : itemColor(item),
                art,
                () -> app.cs2EquipmentScreens.openLoadoutInventory(weapon, t));
        card.setPreferredSize(new Dimension(190, 115));
        weapons.add(card);
      }
      JScrollPane scroll = new JScrollPane(weapons);
      scroll.setBorder(null);
      scroll.setOpaque(false);
      scroll.getViewport().setOpaque(false);
      scroll.getVerticalScrollBar().setUnitIncrement(24);
      column.add(scroll);
      columns.add(column);
    }
    scene.add(columns, BorderLayout.CENTER);
    app.loadoutTabPanel.add(scene);
    app.loadoutTabPanel.revalidate();
    app.loadoutTabPanel.repaint();
  }

  String[] concatCs2Slots(String[] a, String[] b) {
    String[] both = java.util.Arrays.copyOf(a, a.length + b.length);
    System.arraycopy(b, 0, both, a.length, b.length);
    return both;
  }

  String defaultCs2Weapon(String weapon) {
    for (String name : app.skinCatalog.keySet()) if (name.startsWith(weapon + " | ")) return name;
    return null;
  }

  String keyName(CaseType ct) {
    String[] info = hGui.CS2_KEY_CATALOG.get(ct.catalogCrateName());
    return info == null ? ct.name + " Key" : info[0];
  }

  Image getCs2KeyImage(CaseType ct) {
    if (!app.containerInventoryService.requiresOwnedKey(ct)) return null;
    Image art = app.cs2KeyArtwork.get(ct.id);
    if (art != null) return art;
    String[] info = hGui.CS2_KEY_CATALOG.get(ct.catalogCrateName());
    if (info != null) {
      Image image = app.imageRepository.get("case-key-" + ct.id);
      if (image != null) {
        app.cs2KeyArtwork.put(ct.id, image);
        return image;
      }
    }
    return null;
  }

  void warmCs2KeyArtwork() {
    if (!app.cs2ShellEnabled) return;
    for (CaseType ct : CaseType.values()) {
      String[] info = hGui.CS2_KEY_CATALOG.get(ct.catalogCrateName());
      if (!app.containerInventoryService.requiresOwnedKey(ct) || info == null) continue;
      try {
        app.cs2KeyArtwork.put(
            ct.id,
            app.openingArtworkService.retainContainerThumbnail(
                app.imageRepository.readRemoteCachedImage(info[1])));
      } catch (IOException ex) {
        app.startupArtworkUnavailableDetails.put(
            "case-key-" + ct.id, "Requested key PNG: " + info[1] + "\n" + ex.getMessage());
      }
    }
  }

  Color itemColor(InventoryItem item) {
    return isDefaultWeaponItem(item)
        ? new Color(165, 180, 190)
        : app.itemInspectionScreen.getRarityColor(item.rarity);
  }

  String inspectionName(InventoryItem item) {
    if (!isDefaultWeaponItem(item)) return ItemPresentation.name(app, item);
    String base = item.name.replace(" | Default", "");
    return base.endsWith("Knife") || base.endsWith("Gloves") ? "Default " + base : base;
  }

  String equipmentSlot(InventoryItem item, boolean t) {
    String rarity = item.rarity.replace("StatTrak ", "");
    return app.itemMetadataService.isAgentSkin(item.name)
        ? (t ? hGui.AGENT_SLOT_T : hGui.AGENT_SLOT_CT)
        : "Knife".equals(rarity)
            ? "Knife_" + (t ? "T" : "CT")
            : "Gloves".equals(rarity)
                ? "Gloves_" + (t ? "T" : "CT")
                : app.marketFilterControls.extractWeaponType(item.name);
  }

  boolean isEquipped(InventoryItem item, boolean t) {
    if (!app.loadoutScreen.isUsableOnSide(item, t)) return false;
    Map<String, InventoryItem> loadout = t ? app.tLoadout : app.ctLoadout;
    InventoryItem selected = loadout.get(equipmentSlot(item, t));
    if (selected == null) return isDefaultWeaponItem(item);
    return selected == item || item.itemId != null && item.itemId.equals(selected.itemId);
  }

  boolean isDefaultWeaponItem(InventoryItem i) {
    return i != null
        && (i.itemId != null && i.itemId.startsWith("default:")
            || i.name != null && i.name.endsWith(" | Default"));
  }

  Image defaultWeaponImage(String name) {
    if (name == null || !name.endsWith(" | Default")) return null;
    String weapon = name.substring(0, name.length() - 10);
    String key = "cs2-stock-" + weapon;
    Image image = app.imageRepository.get(key);
    if (image == null && hGui.CS2_DEFAULT_WEAPONS.containsKey(weapon))
      app.imageRepository.loadRemote(key, hGui.CS2_DEFAULT_WEAPONS.get(weapon), false);
    return image;
  }

  java.util.List<InventoryItem> collectibleInventory() {
    java.util.List<InventoryItem> result = new java.util.ArrayList<>();
    for (InventoryItem item : app.inventoryList) if (!isDefaultWeaponItem(item)) result.add(item);
    return result;
  }

  void ensureDefaultWeaponInventory() {
    if (!app.cs2ShellEnabled) return;
    for (String gun : hGui.CS2_DEFAULT_WEAPONS.keySet()) {
      String name = gun + " | Default";
      if (app.inventoryList.stream().noneMatch(i -> name.equals(i.name))) {
        Image image = app.imageRepository.get("cs2-stock-" + gun);
        InventoryItem item =
            new InventoryItem(
                image == null ? null : new ImageIcon(image),
                name,
                "Default",
                gun.endsWith("Knife") ? "Knife" : gun.endsWith("Gloves") ? "Gloves" : "Stock",
                BigDecimal.ZERO,
                0,
                false,
                0,
                null,
                0);
        item.itemId = "default:" + gun;
        item.createdAt = 1;
        item.currentOwner = "YOU";
        app.inventoryList.add(item);
      }
    }
  }

  void openLoadoutInventory(String slot, boolean t) {
    app.cs2EquipFilter = slot;
    app.cs2EquipT = t;
    app.cs2UnlockSelection = null;
    app.cs2InventorySearch = "";
    app.cs2Screens.selectCs2InventorySection("EVERYTHING");
  }

  boolean matchesEquipSlot(InventoryItem i, String slot) {
    if (slot.startsWith("Agent"))
      return app.itemMetadataService.isAgentSkin(i.name)
          && app.loadoutScreen.isUsableOnSide(i, app.cs2EquipT);
    if (slot.startsWith("Knife"))
      return "Knife".equals(i.rarity.replace("StatTrak ", ""))
          && app.loadoutScreen.isUsableOnSide(i, app.cs2EquipT);
    if (slot.startsWith("Gloves"))
      return "Gloves".equals(i.rarity.replace("StatTrak ", ""))
          && app.loadoutScreen.isUsableOnSide(i, app.cs2EquipT);
    return app.marketFilterControls.extractWeaponType(i.name).equals(slot);
  }
}
