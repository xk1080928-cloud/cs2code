package blahblah;

import blahblah.hGui.*;
import java.awt.*;
import java.awt.event.*;
import java.util.ArrayList;
import java.util.Comparator;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import javax.swing.*;

/** Market Stock Service: focused feature implementation. */
final class MarketStockService {
  private final hGui app;

  MarketStockService(hGui app) {
    this.app = app;
  }

  void invalidateGroupedMarketListingsCache() {
    app.groupedMarketListingsCache = null;
    app.groupedMarketListingsCacheSize = -1;
  }

  int getTotalMarketListingCount() {
    long total = 0;
    for (ArrayList<MarketListing> listings : app.globalMarketListings.values())
      if (listings != null)
        synchronized (listings) {
          for (MarketListing lot : listings) total += app.exchangeStockService.stockUnits(lot);
        }
    return (int) Math.min(Integer.MAX_VALUE, total);
  }

  static String wearConditionForFloat(double value) {
    for (int i = 0; i < hGui.MARKET_WEAR_NAMES.length - 1; i++)
      if (value < hGui.MARKET_WEAR_EDGES[i + 1]) return hGui.MARKET_WEAR_NAMES[i];
    return hGui.MARKET_WEAR_NAMES[hGui.MARKET_WEAR_NAMES.length - 1];
  }

  double[] getMarketWearBounds(String skinName) {
    FloatRange range = app.catalogParsingService.findFloatRange(skinName);
    double min = range != null && range.min != null ? range.min : 0.0;
    double max = range != null && range.max != null ? range.max : 1.0;
    if (!Double.isFinite(min) || !Double.isFinite(max) || min < 0.0 || max > 1.0 || min > max)
      return new double[] {0.0, 1.0};
    return new double[] {min, max};
  }

  boolean isDopplerGemSkin(String name) {
    return name != null
        && name.contains("Doppler")
        && (name.contains("Sapphire")
            || name.contains("Ruby")
            || name.contains("Black Pearl")
            || name.contains("Emerald"));
  }

  double getMarketSupplyVariance(String rarity) {
    switch (rarity) {
      case "Consumer":
        return 0.50;
      case "Industrial":
        return 0.40;
      case "Milspec":
      case "Distinguished":
        return 0.32;
      case "Restricted":
      case "Exceptional":
        return 0.24;
      case "Classified":
      case "Superior":
        return 0.17;
      case "Covert":
      case "Master":
        return 0.11;
      case "Contraband":
        return 0.08;
      case "Knife":
      case "Gloves":
        return 0.06;
      default:
        return 0.32;
    }
  }

  int fullMarketSupplyBudget(String name, boolean statTrak) {
    String rarity = app.itemMetadataService.getSkinRarity(name);
    int mean;
    switch (rarity) {
      case "Consumer":
        mean = 480;
        break;
      case "Industrial":
        mean = 390;
        break;
      case "Milspec":
      case "Distinguished":
        mean = 300;
        break;
      case "Restricted":
      case "Exceptional":
        mean = 210;
        break;
      case "Classified":
      case "Superior":
        mean = 140;
        break;
      case "Covert":
      case "Master":
        mean = 90;
        break;
      case "Contraband":
        mean = 65;
        break;
      case "Knife":
      case "Gloves":
        mean = 60;
        break;
      default:
        mean = 300;
    }
    double variance = app.marketStockService.getMarketSupplyVariance(rarity);
    if (app.marketStockService.isDopplerGemSkin(name)) {
      mean = 32;
      variance = 0.04;
    }
    String key =
        app.catalogParsingService.normalizeCatalogSkinName(
            name.replaceFirst("(?i)^StatTrak(?:™)?\\s+", ""));
    // Mix the name hash before sampling: related finish names must not have
    // correlated quantities. No fresh rerolls on every repair or refresh.
    long seed = ((long) key.hashCode()) ^ 0x6A09E667F3BCC909L;
    seed = (seed ^ (seed >>> 30)) * 0xBF58476D1CE4E5B9L;
    seed = (seed ^ (seed >>> 27)) * 0x94D049BB133111EBL;
    seed ^= seed >>> 31;
    double unit = (seed >>> 11) * 0x1.0p-53;
    int budget = (int) Math.round(mean * (1.0 + (unit * 2.0 - 1.0) * variance));
    if (statTrak) budget = (int) Math.floor(budget * 0.35);
    int floor = statTrak ? 2 : ("Knife".equals(rarity) || "Gloves".equals(rarity)) ? 6 : 8;
    return hGui.MARKET_STOCK_MULTIPLIER
        * Math.max(app.floatRules.getAvailableConditions(name).length * floor, budget);
  }

  int getMarketSupplyBudget(String name, boolean statTrak) {
    int budget = app.marketStockService.fullMarketSupplyBudget(name, statTrak);
    return app.cs2ShellEnabled
        ? Math.max(app.floatRules.getAvailableConditions(name).length * 3, (budget + 7) / 8)
        : budget;
  }

  LinkedHashMap<String, Integer> getMarketSupplyTargets(String name, boolean statTrak) {
    LinkedHashMap<String, Integer> targets = new LinkedHashMap<>();
    String[] conditions = app.floatRules.getAvailableConditions(name);
    if (conditions.length == 0) return targets;
    String rarity = app.itemMetadataService.getSkinRarity(name);
    boolean rare = "Knife".equals(rarity) || "Gloves".equals(rarity);
    int budget = app.marketStockService.getMarketSupplyBudget(name, statTrak);
    int floor = hGui.MARKET_STOCK_MULTIPLIER * (statTrak ? 2 : rare ? 6 : 8);
    double[] bounds = app.marketStockService.getMarketWearBounds(name);
    double total = 0.0;
    Map<String, Double> weights = new LinkedHashMap<>();
    for (String condition : conditions) {
      double weight = app.floatRules.hasNoFloatWear(name) ? 1.0 : 0.0;
      for (int i = 0; i < hGui.MARKET_WEAR_NAMES.length; i++) {
        if (condition.equals(hGui.MARKET_WEAR_NAMES[i]))
          weight =
              Math.max(
                  0.0,
                  Math.min(bounds[1], hGui.MARKET_WEAR_EDGES[i + 1])
                      - Math.max(bounds[0], hGui.MARKET_WEAR_EDGES[i]));
      }
      weights.put(condition, weight);
      total += weight;
    }
    int remaining = budget - floor * conditions.length;
    for (String condition : conditions) {
      double fraction = total > 0.0 ? weights.get(condition) / total : 1.0 / conditions.length;
      targets.put(condition, floor + (int) Math.floor(Math.max(0, remaining) * fraction));
    }
    // Largest-remainder allocation conserves the exact per-skin budget.
    int allocated = targets.values().stream().mapToInt(Integer::intValue).sum();
    java.util.List<String> remainderOrder = new ArrayList<>(java.util.Arrays.asList(conditions));
    final double weightTotal = total;
    remainderOrder.sort(
        Comparator.comparingDouble(
                (String condition) -> {
                  double fraction =
                      weightTotal > 0.0
                          ? weights.get(condition) / weightTotal
                          : 1.0 / conditions.length;
                  double exact = Math.max(0, remaining) * fraction;
                  return exact - Math.floor(exact);
                })
            .reversed());
    for (int i = 0; allocated < budget; allocated++, i++) {
      String condition = remainderOrder.get(i % remainderOrder.size());
      targets.put(condition, targets.get(condition) + 1);
    }
    return targets;
  }

  double getVanillaVariantBasePrice(String name, boolean statTrak, double normalBase) {
    if (!statTrak) return normalBase;
    return app.liveVanillaStatTrakPrices.getOrDefault(name, normalBase * 0.90);
  }

  MarketListing createNpcWearListing(
      String name, String condition, boolean statTrak, double basePrice, String rarity) {
    boolean noWear = app.floatRules.hasNoFloatWear(name);
    double marketMulti =
        app.marketInitialization.getMarketMultiplier(
            rarity, app.collectionService.getCollectionName(name));
    double value = basePrice * marketMulti * (0.90 + hGui.random.nextDouble() * 0.20);
    if (!noWear) value *= app.priceModifiers.getMarketConditionMultiplier(name, condition);
    if (app.floatRules.isVanillaKnife(name)) {
      value =
          app.marketStockService.getVanillaVariantBasePrice(name, statTrak, basePrice)
              * marketMulti
              * (0.90 + hGui.random.nextDouble() * 0.20);
    } else if (statTrak) {
      if ("Knife".equals(rarity)) value *= name.contains("Doppler") ? 0.80 : 0.90;
      else value *= name.contains("Crimson Web") ? 2.0 : 1.85;
    }
    value = Math.max(0.01, value);
    InventoryItem item =
        new InventoryItem(
            null,
            name,
            noWear ? "Normal" : condition,
            statTrak ? "StatTrak " + rarity : rarity,
            app.coreUtilities.money(value),
            noWear ? 0.0 : app.marketGeneration.generateFloatForCondition(name, condition),
            statTrak,
            hGui.random.nextInt(1000),
            null,
            basePrice,
            true);
    item.collection = app.collectionService.getCollectionName(name);
    return new MarketListing(item, value, 30 + hGui.random.nextInt(150), false);
  }

  int getNpcRestockBatchSize(String name) {
    if (app.marketStockService.isDopplerGemSkin(name)) return 1;
    switch (app.itemMetadataService.getSkinRarity(name)) {
      case "Consumer":
        return 24;
      case "Industrial":
        return 18;
      case "Milspec":
      case "Distinguished":
        return 12;
      case "Restricted":
      case "Exceptional":
        return 8;
      case "Classified":
      case "Superior":
        return 5;
      case "Covert":
      case "Master":
        return 3;
      case "Knife":
      case "Gloves":
      case "Contraband":
        return 2;
      default:
        return 8;
    }
  }

  Map<String, Integer> planNpcRestock(
      String key,
      String name,
      LinkedHashMap<String, Integer> targets,
      Map<String, ArrayList<MarketListing>> byWear,
      boolean fillMissing) {
    Map<String, Integer> additions = new LinkedHashMap<>();
    for (String wear : targets.keySet()) additions.put(wear, 0);
    if (!fillMissing) return additions;
    long now = System.currentTimeMillis();
    Long last = app.lastNpcRestockAt.get(key);
    if (app.marketInitialized
        && last != null
        && now - last < hGui.MARKET_UPDATE_INTERVAL
        && now >= last) return additions;
    app.lastNpcRestockAt.put(key, now);
    int allowance =
        app.marketInitialized
            ? app.marketStockService.getNpcRestockBatchSize(name)
            : Integer.MAX_VALUE;
    List<String> wears = new ArrayList<>(targets.keySet());
    if (wears.isEmpty()) return additions;
    int cursor =
        Math.floorMod(app.npcRestockCursor.getOrDefault(key, name.hashCode()), wears.size());
    boolean progress = true;
    while (allowance > 0 && progress) {
      progress = false;
      for (int i = 0; i < wears.size() && allowance > 0; i++) {
        String wear = wears.get((cursor + i) % wears.size());
        ArrayList<MarketListing> existing = byWear.get(wear);
        int count = (existing == null ? 0 : existing.size()) + additions.get(wear);
        if (count < targets.get(wear)) {
          additions.put(wear, additions.get(wear) + 1);
          allowance--;
          progress = true;
        }
      }
    }
    app.npcRestockCursor.put(key, (cursor + 1) % wears.size());
    return additions;
  }

  void rebalanceMarketBucket(String key, ArrayList<MarketListing> listings, boolean fillMissing) {
    if (app.globalSupply.ready())
      return; // Live stock belongs to reserve-first order flow, not legacy lot-count repair.
    if (app.exchangeStockService.exchangeContainer(key) != null) return;
    boolean statTrak = key.startsWith("StatTrak ");
    String name = statTrak ? key.substring("StatTrak ".length()) : key;
    if (statTrak && !app.itemMetadataService.supportsStatTrak(name)) return;
    LinkedHashMap<String, Integer> targets =
        app.marketStockService.getMarketSupplyTargets(name, statTrak);
    Map<String, ArrayList<MarketListing>> byWear = new LinkedHashMap<>();
    ArrayList<MarketListing> kept = new ArrayList<>();
    boolean changed = false;
    boolean noWear = app.floatRules.hasNoFloatWear(name);
    double[] bounds = app.marketStockService.getMarketWearBounds(name);
    synchronized (listings) {
      for (MarketListing listing : listings) {
        if (listing == null || listing.item == null) {
          changed = true;
          continue;
        }
        // User asks, ownership and item floats are never rewritten by supply repair.
        if (listing.isPlayerListing) {
          kept.add(listing);
          continue;
        }
        if (!targets.containsKey(listing.item.condition)) {
          changed = true;
          continue;
        }
        if (noWear) {
          listing.item.itemFloat = 0.0;
        } else {
          double value = listing.item.itemFloat;
          if (!Double.isFinite(value)
              || value < bounds[0]
              || value > bounds[1]
              || !listing.item.condition.equals(MarketStockService.wearConditionForFloat(value))) {
            // Replace malformed generated NPC floats with a valid float in that wear.
            listing.item.itemFloat =
                app.marketGeneration.generateFloatForCondition(name, listing.item.condition);
            changed = true;
          }
        }
        byWear.computeIfAbsent(listing.item.condition, c -> new ArrayList<>()).add(listing);
      }
      Map<String, Integer> additions =
          app.marketStockService.planNpcRestock(key, name, targets, byWear, fillMissing);
      double basePrice = 0.0;
      String rarity = app.itemMetadataService.getSkinRarity(name);
      for (Map.Entry<String, Integer> target : targets.entrySet()) {
        ArrayList<MarketListing> wearListings =
            byWear.getOrDefault(target.getKey(), new ArrayList<>());
        if (wearListings.size() > target.getValue()) {
          wearListings.sort(Comparator.comparingDouble(l -> l.getPrice()));
          changed = true;
        }
        int count = Math.min(wearListings.size(), target.getValue());
        kept.addAll(wearListings.subList(0, count));
        int toAdd = additions.getOrDefault(target.getKey(), 0);
        if (toAdd > 0) {
          if (basePrice <= 0.0) basePrice = app.itemPriceService.getBasePrice(name);
          if (Double.isFinite(basePrice) && basePrice > 0.0) {
            for (int i = 0; i < toAdd; i++)
              kept.add(
                  app.marketStockService.createNpcWearListing(
                      name, target.getKey(), statTrak, basePrice, rarity));
            changed = true;
          }
        }
      }
      if (changed || kept.size() != listings.size()) {
        listings.clear();
        listings.addAll(kept);
        app.marketStockService.redistributeMarketplacesForBucket(key, listings);
      }
      if (app.cs2ShellEnabled && !app.marketInitialized)
        app.exchangeStockService.seedExchangeBucket(key, listings);
    }
  }

  void rebalanceMarketWearSupply(boolean fillMissing) {
    synchronized (app.globalMarketListings) {
      if (fillMissing) {
        for (String skin : app.requestedMarketSkinCollections.keySet()) {
          app.globalMarketListings.computeIfAbsent(skin, key -> new ArrayList<>());
        }
      }
      for (Map.Entry<String, ArrayList<MarketListing>> entry :
          new ArrayList<>(app.globalMarketListings.entrySet()))
        if (entry.getValue() != null)
          app.marketStockService.rebalanceMarketBucket(
              entry.getKey(), entry.getValue(), fillMissing);
      app.marketStockService.invalidateGroupedMarketListingsCache();
    }
  }

  void trimMarketListingsForResponsiveUi() {
    app.marketStockService.rebalanceMarketWearSupply(false);
  }

  void assignMarketplaceProfile(MarketListing listing, MarketplaceProfile profile) {
    if (listing == null || listing.isPlayerListing || profile == null) return;
    listing.marketplaceName = profile.name;
    listing.marketplaceType = profile.type;
    listing.marketplaceRating = profile.rating;
    listing.marketplaceReviews = profile.reviews;
    listing.promoted = profile.promoted;
    listing.sellerName = MarketListing.generateRandomUsername();
    listing.sellerAvatar = MarketListing.generateRandomAvatar();
  }

  void redistributeMarketplacesForBucket(String marketKey, ArrayList<MarketListing> listings) {
    if (listings == null || listings.isEmpty()) return;
    ArrayList<MarketListing> npcListings = new ArrayList<>();
    for (MarketListing listing : new ArrayList<>(listings)) {
      if (listing == null) continue;
      if (!listing.isPlayerListing) npcListings.add(listing);
    }
    if (npcListings.isEmpty()) return;
    if (app.cs2ShellEnabled) {
      for (int i = 0; i < npcListings.size(); i++)
        app.marketStockService.assignMarketplaceProfile(
            npcListings.get(i), app.exchangeStockService.weightedExchangeProfile(marketKey, i));
      return;
    }

    MarketplaceProfile[] catalog = MarketplaceProfile.CATALOG;
    int marketCount =
        Math.min(catalog.length, Math.max(4, Math.min(12, npcListings.size() / 8 + 3)));
    int start = Math.floorMod(marketKey.hashCode(), catalog.length);
    ArrayList<MarketplaceProfile> rotation = new ArrayList<>();
    for (int i = 0; i < marketCount; i++) {
      rotation.add(catalog[(start + i) % catalog.length]);
    }

    int chunkSize = Math.max(2, Math.min(6, npcListings.size() / Math.max(1, marketCount)));
    for (int i = 0; i < npcListings.size(); i++) {
      MarketplaceProfile profile = rotation.get((i / chunkSize) % rotation.size());
      app.marketStockService.assignMarketplaceProfile(npcListings.get(i), profile);
    }
  }
}
