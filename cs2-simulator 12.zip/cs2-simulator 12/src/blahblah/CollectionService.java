package blahblah;

import blahblah.hGui.*;
import java.awt.*;
import java.awt.event.*;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.Set;
import javax.swing.*;

/** Collection Service: focused feature implementation. */
final class CollectionService {
  private final hGui app;

  CollectionService(hGui app) {
    this.app = app;
  }

  TradeUpCollection findCollection(String skinName) {
    if (skinName == null || skinName.isEmpty()) return null;
    TradeUpCollection cached = app.collectionCache.get(skinName);
    if (cached != null || app.collectionCache.containsKey(skinName)) return cached;
    boolean souvenir = skinName.matches("(?is)^Souvenir\\s+.*");
    if (souvenir) {
      for (CaseType caseType : CaseType.values()) {
        if (!caseType.isSouvenir) continue;
        TradeUpCollection col = app.collectionService.buildCatalogCaseCollection(caseType);
        if (col != null && col.getTierForSkin(skinName) != null) {
          app.collectionCache.put(skinName, col);
          return col;
        }
      }
      app.collectionCache.put(skinName, null);
      return null;
    }
    for (TradeUpCollection col : hGui.TRADE_UP_COLLECTIONS)
      if (col.getTierForSkin(skinName) != null) {
        app.collectionCache.put(skinName, col);
        return col;
      }
    if (hGui.ARMOURY_TRADE_UP_COLLECTIONS != null) {
      for (TradeUpCollection col : hGui.ARMOURY_TRADE_UP_COLLECTIONS)
        if (col.getTierForSkin(skinName) != null) {
          app.collectionCache.put(skinName, col);
          return col;
        }
    }
    Set<String> marketMemberships =
        app.requestedMarketSkinCollections.get(
            app.marketCatalogService.marketCollectionSkinKey(skinName));
    if (marketMemberships != null && !marketMemberships.isEmpty()) {
      TradeUpCollection col =
          app.requestedMarketCollections.get(marketMemberships.iterator().next());
      if (col != null) {
        app.collectionCache.put(skinName, col);
        return col;
      }
    }

    for (CaseType caseType : CaseType.values()) {
      if (caseType.isSouvenir) continue;
      TradeUpCollection col = app.collectionService.buildCatalogCaseCollection(caseType);
      if (col != null && col.getTierForSkin(skinName) != null) {
        app.collectionCache.put(skinName, col);
        return col;
      }
    }
    app.collectionCache.put(skinName, null);
    return null;
  }

  TradeUpCollection getCurrentCaseCollection() {
    if (app.currentCase != null && app.currentCase.isSouvenir) {
      return app.collectionService.buildCatalogCaseCollection(app.currentCase);
    }
    String colName = app.oddsAndChecklistScreen.getCollectionNameForCaseType(app.currentCase);
    if (colName != null) {
      for (TradeUpCollection c : hGui.TRADE_UP_COLLECTIONS)
        if (c.collectionName.equals(colName)) return c;
    }
    return app.collectionService.buildCatalogCaseCollection(app.currentCase);
  }

  List<String> getCatalogItemsForCase(CaseType caseType, String category) {
    if (caseType == null) return java.util.Collections.emptyList();
    java.util.TreeSet<String> names = new java.util.TreeSet<>(String.CASE_INSENSITIVE_ORDER);
    for (Map.Entry<String, SkinMetadata> entry : app.skinCatalog.entrySet()) {
      SkinMetadata metadata = entry.getValue();
      if (category.equals(metadata.category)
          && metadata.crateNames.contains(caseType.catalogCrateName())) {
        names.add(entry.getKey());
      }
    }
    return new ArrayList<>(names);
  }

  List<String> getCatalogSkinsByCategory(String category) {
    java.util.TreeSet<String> names = new java.util.TreeSet<>(String.CASE_INSENSITIVE_ORDER);
    for (Map.Entry<String, SkinMetadata> entry : app.skinCatalog.entrySet()) {
      if (category.equals(entry.getValue().category)) names.add(entry.getKey());
    }
    app.collectionService.addDopplerVariants(names);
    return new ArrayList<>(names);
  }

  void addDopplerVariants(Set<String> names) {
    for (String skinName : new ArrayList<>(names)) {
      if (skinName.endsWith(" | Doppler")) {
        for (int phase = 1; phase <= 4; phase++) {
          names.add(skinName + " (Phase " + phase + ")");
        }
        names.add(skinName + " (Sapphire)");
        names.add(skinName + " (Ruby)");
        names.add(skinName + " (Black Pearl)");
      } else if (skinName.endsWith(" | Gamma Doppler")) {
        for (int phase = 1; phase <= 4; phase++) {
          names.add(skinName + " (Phase " + phase + ")");
        }
        names.add(skinName + " (Emerald)");
      }
    }
  }

  String[] mergeCatalogSkins(String category, String[] existingNames) {
    java.util.TreeSet<String> names = new java.util.TreeSet<>(String.CASE_INSENSITIVE_ORDER);
    names.addAll(java.util.Arrays.asList(existingNames));
    names.addAll(app.collectionService.getCatalogSkinsByCategory(category));
    if ("Knives".equals(category)) app.collectionService.addDopplerVariants(names);
    return names.toArray(new String[0]);
  }

  String getRandomCaseGoldDrop(CaseType caseType, String category) {
    String catalogCategory = "Knives".equals(category) ? "Knives" : "Gloves";
    Map<String, Double> odds =
        app.goldTradeUpService.getCaseUnboxingGoldOutcomeOdds(caseType, catalogCategory);
    if (odds.isEmpty())
      throw new IllegalStateException(
          "No verified " + category + " special-drop pool is available for " + caseType.name);
    // Base-finish shares are unchanged; only unboxing gets the separate 92% phase / 8% gem split.
    return app.goldTradeUpService.sampleTradeUpOdds(odds);
  }

  String chooseCaseDrop(CaseType caseType, String tier) {
    List<String> pool =
        caseType.regularDropNames.getOrDefault(tier, java.util.Collections.emptyList());
    if (pool.isEmpty()) {
      throw new IllegalStateException(
          "No verified " + tier + " drop pool is available for " + caseType.name);
    }
    return pool.get(hGui.random.nextInt(pool.size()));
  }

  TradeUpCollection buildCatalogCaseCollection(CaseType caseType) {
    if (caseType == null) return null;
    return app.catalogCaseCollectionCache.computeIfAbsent(
        caseType, app.collectionService::createCatalogCaseCollection);
  }

  TradeUpCollection createCatalogCaseCollection(CaseType caseType) {
    Map<String, List<String>> tiers = new HashMap<>();
    for (String rarity :
        new String[] {"Consumer", "Industrial", "Milspec", "Restricted", "Classified", "Covert"}) {
      tiers.put(rarity, new ArrayList<>());
    }
    for (Map.Entry<String, List<String>> entry : caseType.regularDropNames.entrySet()) {
      List<String> tier = tiers.get(entry.getKey());
      if (tier != null) tier.addAll(entry.getValue());
    }
    if (tiers.values().stream().allMatch(List::isEmpty)) {
      for (Map.Entry<String, SkinMetadata> entry : app.skinCatalog.entrySet()) {
        SkinMetadata metadata = entry.getValue();
        if (metadata.crateNames.contains(caseType.catalogCrateName())
            && !"Knives".equals(metadata.category)
            && !"Gloves".equals(metadata.category)
            && metadata.rarity != null) {
          String tier = app.collectionService.catalogRarityTier(metadata.rarity);
          if (tier != null) tiers.get(tier).add(entry.getKey());
        }
      }
    }
    if (tiers.values().stream().allMatch(List::isEmpty)) return null;
    for (List<String> tier : tiers.values()) tier.sort(String.CASE_INSENSITIVE_ORDER);
    return new TradeUpCollection(
        app.collectionService.getCatalogCollectionName(caseType),
        tiers.get("Consumer").toArray(new String[0]),
        tiers.get("Industrial").toArray(new String[0]),
        tiers.get("Milspec").toArray(new String[0]),
        tiers.get("Restricted").toArray(new String[0]),
        tiers.get("Classified").toArray(new String[0]),
        tiers.get("Covert").toArray(new String[0]));
  }

  String getCatalogCollectionName(CaseType caseType) {
    if (caseType == null) return null;
    String knownCollection = app.oddsAndChecklistScreen.getCollectionNameForCaseType(caseType);
    if (knownCollection != null) return knownCollection;
    String crateName = caseType.catalogCrateName();
    if (caseType.isSouvenir) {
      String mapName = app.catalogLoadingService.resolveSouvenirMapName(crateName);
      if (mapName != null && !mapName.isEmpty()) return mapName + " Collection";
    }
    if (crateName == null || crateName.trim().isEmpty()) return null;
    String collectionName =
        crateName
            .trim()
            .replaceFirst("(?i)\\s+Souvenir Package$", "")
            .replaceFirst("(?i)\\s+Weapon Case$", " Collection")
            .replaceFirst("(?i)\\s+Case$", " Collection");
    return collectionName.matches("(?i).*\\bCollection$")
        ? collectionName
        : collectionName + " Collection";
  }

  void updateSelectedCaseRoi() {
    if (app.caseRoiLabel == null || app.currentCase == null) return;
    if (!app.collectionService.hasVerifiedCasePools(app.currentCase)) {
      app.caseRoiLabel.setText(
          "Expected return unavailable until this case's drop catalog is loaded.");
      return;
    }
    double expectedReturn = app.collectionService.getExpectedCaseReturn(app.currentCase);
    double roi = app.collectionService.getEstimatedCaseRoi(app.currentCase);
    app.caseRoiLabel.setText(
        String.format(
            "Estimated average return: $%.2f | Expected ROI: %.1f%% (market prices)",
            expectedReturn, roi));
  }

  double getEstimatedCaseRoi(CaseType caseType) {
    if (caseType == null
        || caseType.price <= 0.0
        || !app.collectionService.hasVerifiedCasePools(caseType)) return 0.0;
    return ((app.collectionService.getExpectedCaseReturn(caseType) - caseType.price)
            / caseType.price)
        * 100.0;
  }

  double getExpectedCaseReturn(CaseType caseType) {
    if (caseType.isSouvenir) {
      Map<String, Double> weights =
          Map.of(
              "Consumer",
              799200.0,
              "Industrial",
              159800.0,
              "Milspec",
              32000.0,
              "Restricted",
              6400.0,
              "Classified",
              1280.0,
              "Covert",
              256.0);
      double totalWeight =
          weights.entrySet().stream()
              .filter(
                  entry ->
                      !caseType
                          .regularDropNames
                          .getOrDefault(entry.getKey(), java.util.Collections.emptyList())
                          .isEmpty())
              .mapToDouble(Map.Entry::getValue)
              .sum();
      double expected = 0.0;
      for (Map.Entry<String, Double> entry : weights.entrySet()) {
        List<String> drops =
            caseType.regularDropNames.getOrDefault(
                entry.getKey(), java.util.Collections.emptyList());
        if (!drops.isEmpty()) {
          expected +=
              entry.getValue() / totalWeight * app.collectionService.averageCatalogItemValue(drops);
        }
      }
      return expected;
    }
    Map<String, Double> oddsByTier = new HashMap<>();
    oddsByTier.put("Industrial", 0.0);
    oddsByTier.put("Milspec", 0.0);
    oddsByTier.put("Restricted", 0.1598);
    oddsByTier.put("Classified", 0.0320);
    oddsByTier.put("Covert", 0.0064);
    boolean hasMilspec =
        !caseType
            .regularDropNames
            .getOrDefault("Milspec", java.util.Collections.emptyList())
            .isEmpty();
    String lowestTier = hasMilspec ? "Milspec" : "Industrial";
    oddsByTier.put(lowestTier, 0.7992);

    double expectedReturn = 0.0026 * app.collectionService.averageRareDropValue(caseType);
    for (Map.Entry<String, Double> odds : oddsByTier.entrySet()) {
      if (odds.getValue() <= 0.0) continue;
      List<String> items =
          caseType.regularDropNames.getOrDefault(odds.getKey(), java.util.Collections.emptyList());
      if (items.isEmpty()) continue;
      expectedReturn +=
          odds.getValue() * app.collectionService.averageCatalogItemValue(items) * 1.1;
    }
    if (caseType.isTerminal && caseType.rareDropNames.isEmpty()) expectedReturn /= 0.9974;
    return expectedReturn;
  }

  boolean hasVerifiedCasePools(CaseType caseType) {
    if (caseType == null) return false;
    if (caseType.isSouvenir) {
      return caseType.regularDropNames.values().stream().anyMatch(items -> !items.isEmpty());
    }
    return (caseType.isTerminal || !caseType.rareDropNames.isEmpty())
        && java.util.Arrays.stream(new String[] {"Milspec", "Restricted", "Classified", "Covert"})
            .allMatch(
                tier ->
                    !caseType
                        .regularDropNames
                        .getOrDefault(tier, java.util.Collections.emptyList())
                        .isEmpty());
  }

  double averageRareDropValue(CaseType caseType) {
    double expected = 0;
    for (Map.Entry<String, Double> e :
        app.goldTradeUpService.getCaseUnboxingGoldOutcomeOdds(caseType, null).entrySet()) {
      double value = app.collectionService.averageWearPrice(e.getKey());
      if ("Knife".equals(app.goldTradeUpService.getGoldTradeUpOutputRarity(e.getKey())))
        value *= 1.015;
      expected += e.getValue() * value;
    }
    return expected;
  }

  double averageCatalogItemValue(List<String> items) {
    if (items == null || items.isEmpty()) return 0.0;
    double total = 0.0;
    int count = 0;
    for (String item : items) {
      if (item == null || item.isEmpty()) continue;
      String priceName = item;
      double wearAverage = app.collectionService.averageWearPrice(priceName);
      total += wearAverage;
      count++;
    }
    return count == 0 ? 0.0 : total / count;
  }

  double averageWearPrice(String skinName) {
    String[] conditions = app.floatRules.getAvailableConditions(skinName);
    if (conditions.length == 0) return app.itemPriceService.getBasePrice(skinName);
    if (conditions.length == 1
        && ("Normal".equals(conditions[0]) || "Agent".equals(conditions[0]))) {
      return app.itemPriceService.getBasePrice(skinName);
    }
    FloatRange range = app.catalogParsingService.findFloatRange(skinName);
    double min = range != null && range.min != null ? range.min : 0.0;
    double max = range != null && range.max != null ? range.max : 1.0;
    Map<String, double[]> bounds = new HashMap<>();
    bounds.put("Factory New", new double[] {0.0, 0.07});
    bounds.put("Minimal Wear", new double[] {0.07, 0.15});
    bounds.put("Field-Tested", new double[] {0.15, 0.38});
    bounds.put("Well-Worn", new double[] {0.38, 0.45});
    bounds.put("Battle-Scarred", new double[] {0.45, 1.0});
    double weightedPrice = 0.0;
    double totalRange = 0.0;
    for (String condition : conditions) {
      double[] wear = bounds.get(condition);
      if (wear == null) continue;
      double overlap = Math.max(0.0, Math.min(max, wear[1]) - Math.max(min, wear[0]));
      if (overlap <= 0.0) continue;
      weightedPrice +=
          overlap
              * app.itemPriceService.getBasePrice(skinName)
              * app.priceModifiers.getConditionPriceMultiplier(skinName, condition);
      totalRange += overlap;
    }
    return totalRange > 0.0
        ? weightedPrice / totalRange
        : app.itemPriceService.getBasePrice(skinName);
  }

  String catalogRarityTier(String rarity) {
    String normalized = rarity.toLowerCase(java.util.Locale.ROOT);
    if (normalized.contains("consumer")) return "Consumer";
    if (normalized.contains("industrial")) return "Industrial";
    if (normalized.contains("mil-spec") || normalized.contains("milspec")) return "Milspec";
    if (normalized.contains("restricted")) return "Restricted";
    if (normalized.contains("classified")) return "Classified";
    if (normalized.contains("covert")) return "Covert";
    return null;
  }

  String getCollectionName(String skinName) {
    if (skinName == null
        || app.inventoryScreen.hasNoItemCollection(app.itemMetadataService.getSkinRarity(skinName)))
      return null;
    TradeUpCollection col = app.collectionService.findCollection(skinName);
    if (col != null) return col.collectionName;
    String catalogName =
        app.catalogParsingService.normalizeCatalogSkinName(
            app.catalogParsingService.stripSouvenirPrefix(skinName == null ? "" : skinName));
    int variantStart = catalogName.lastIndexOf(" (");
    if (variantStart > 0) catalogName = catalogName.substring(0, variantStart).trim();
    SkinMetadata metadata = app.skinCatalog.get(catalogName);
    if (metadata != null) {
      for (String crateName : metadata.crateNames) {
        CaseType caseType =
            CaseType.CASES_BY_CRATE.get(crateName.toLowerCase(java.util.Locale.ROOT));
        if (caseType != null) {
          String collectionName = app.collectionService.getCatalogCollectionName(caseType);
          if (collectionName != null) return collectionName;
        }
      }
    }
    if (hGui.ARMOURY_COLLECTIONS != null && skinName != null) {
      String cleanName = skinName.replace("StatTrak ", "").trim();
      int suffixIdx = cleanName.indexOf(" (");
      if (suffixIdx > 0) cleanName = cleanName.substring(0, suffixIdx).trim();
      for (ArmouryCollection ac : hGui.ARMOURY_COLLECTIONS) {
        for (String[] tier :
            new String[][] {
              ac.covertNames,
              ac.classifiedNames,
              ac.restrictedNames,
              ac.milspecNames,
              ac.industrialNames,
              ac.consumerNames
            }) {
          if (tier == null) continue;
          for (String itemName : tier) {
            if (itemName != null && itemName.equalsIgnoreCase(cleanName)) {
              return ac.name;
            }
          }
        }
      }
    }
    return null;
  }

  Map<String, Double> resolveTradeUpOutcomeOdds(
      List<InventoryItem> selectedItems, String baseRarity) {
    Map<String, Double> odds = new LinkedHashMap<>();
    if (selectedItems.isEmpty()) return odds;
    Map<String, Integer> collectionCounts = new LinkedHashMap<>();
    Map<String, TradeUpCollection> collections = new LinkedHashMap<>();
    for (InventoryItem input : selectedItems) {
      TradeUpCollection collection = app.collectionService.findCollection(input.name);
      if (collection == null) return new LinkedHashMap<>();
      collectionCounts.merge(collection.collectionName, 1, Integer::sum);
      collections.put(collection.collectionName, collection);
    }
    for (Map.Entry<String, Integer> entry : collectionCounts.entrySet()) {
      Set<String> outputs =
          new java.util.LinkedHashSet<>(
              java.util.Arrays.asList(collections.get(entry.getKey()).getOutcomePool(baseRarity)));
      if (outputs.isEmpty()) return new LinkedHashMap<>();
      // First allocate each collection its input share, THEN divide among its outcomes.
      double perSkin = (double) entry.getValue() / selectedItems.size() / outputs.size();
      for (String name : outputs) odds.merge(name, perSkin, Double::sum);
    }
    return odds;
  }
}
