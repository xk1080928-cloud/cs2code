package blahblah;

import blahblah.hGui.*;
import java.awt.*;
import java.awt.event.*;
import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.Set;
import javax.swing.*;

/** Inventory Screen: focused feature implementation. */
final class InventoryScreen {
  private final hGui app;

  InventoryScreen(hGui app) {
    this.app = app;
  }

  boolean hasNoItemCollection(String rarity) {
    return rarity != null && (rarity.contains("Knife") || rarity.contains("Glove"));
  }

  String resolveInventoryItemCollection(InventoryItem item) {
    if (item == null) return null;
    if (app.inventoryScreen.hasNoItemCollection(item.rarity)) item.collection = null;
    else if (item.collection == null)
      item.collection = app.collectionService.getCollectionName(item.name);
    return item.collection;
  }

  void releaseInventoryCardArtwork(JPanel card) {
    Object key = card.getClientProperty("inventoryRemoteName");
    Object art = card.getClientProperty("inventoryArtwork");
    if (!(key instanceof String) || !(art instanceof JLabel)) return;
    Set<JLabel> pending = app.pendingRemoteImageLabels.get((String) key);
    if (pending != null) {
      pending.remove((JLabel) art);
      if (pending.isEmpty()) app.pendingRemoteImageLabels.remove((String) key, pending);
    }
  }

  @SuppressWarnings("unchecked")
  void releaseInventoryGridCaches(Container root) {
    if (root instanceof JPanel) {
      Object value = ((JPanel) root).getClientProperty("cardCache");
      if (value instanceof Map) {
        Map<InventoryItem, JPanel> cache = (Map<InventoryItem, JPanel>) value;
        for (JPanel card : cache.values()) app.inventoryScreen.releaseInventoryCardArtwork(card);
        cache.clear();
      }
    }
    for (Component child : root.getComponents())
      if (child instanceof Container)
        app.inventoryScreen.releaseInventoryGridCaches((Container) child);
  }

  @SuppressWarnings("unchecked")
  JPanel cachedInventoryGridCard(
      JPanel grid,
      InventoryItem item,
      java.util.function.Function<InventoryItem, JPanel> renderer) {
    Map<InventoryItem, JPanel> cache =
        (Map<InventoryItem, JPanel>) grid.getClientProperty("cardCache");
    if (cache == null) {
      cache =
          new LinkedHashMap<InventoryItem, JPanel>(64, 0.75f, true) {
            @Override
            protected boolean removeEldestEntry(Map.Entry<InventoryItem, JPanel> e) {
              boolean evict = size() > hGui.INVENTORY_CARD_CACHE_SIZE;
              if (evict) app.inventoryScreen.releaseInventoryCardArtwork(e.getValue());
              return evict;
            }
          };
      grid.putClientProperty("cardCache", cache);
    }
    app.artworkService.refreshInventoryItemArtwork(item);
    JPanel card = cache.get(item);
    if (card == null) {
      card = renderer.apply(item);
      cache.put(item, card);
    }
    JLabel price = (JLabel) card.getClientProperty("inventoryPriceLabel");
    if (price != null) price.setText("$" + item.price);
    JLabel artwork = (JLabel) card.getClientProperty("inventoryArtwork");
    if (artwork != null && card.getClientProperty("inventoryImageSource") != item.image) {
      ImageIcon thumb = item.getThumb110();
      if (thumb != null) artwork.setIcon(thumb);
      card.putClientProperty("inventoryImageSource", item.image);
    }
    Object selection = grid.getClientProperty("tradeUpSelection");
    if (selection instanceof List)
      app.inventoryScreen.updateTradeUpCardSelection(card, item, (List<InventoryItem>) selection);
    return card;
  }

  void setPagedInventoryItems(
      JPanel grid,
      JScrollPane scroll,
      List<InventoryItem> items,
      java.util.function.Function<InventoryItem, JPanel> renderer,
      int preferredPage) {
    grid.putClientProperty("pageItems", items);
    grid.putClientProperty("pageRenderer", renderer);
    grid.putClientProperty("pageScroll", scroll);
    grid.putClientProperty("pageIndex", preferredPage);
    app.inventoryScreen.renderInventoryPage(grid);
  }

  @SuppressWarnings("unchecked")
  void renderInventoryPage(JPanel grid) {
    List<InventoryItem> items = (List<InventoryItem>) grid.getClientProperty("pageItems");
    java.util.function.Function<InventoryItem, JPanel> renderer =
        (java.util.function.Function<InventoryItem, JPanel>) grid.getClientProperty("pageRenderer");
    JScrollPane scroll = (JScrollPane) grid.getClientProperty("pageScroll");
    if (items == null || renderer == null || scroll == null) return;
    int pages =
        Math.max(1, (items.size() + hGui.INVENTORY_PAGE_SIZE - 1) / hGui.INVENTORY_PAGE_SIZE);
    Object value = grid.getClientProperty("pageIndex");
    int page = Math.max(0, Math.min(pages - 1, value instanceof Integer ? (Integer) value : 0));
    grid.putClientProperty("pageIndex", page);
    grid.removeAll();
    int start = page * hGui.INVENTORY_PAGE_SIZE,
        end = Math.min(items.size(), start + hGui.INVENTORY_PAGE_SIZE);
    for (int i = start; i < end; i++)
      grid.add(app.inventoryScreen.cachedInventoryGridCard(grid, items.get(i), renderer));
    if (items.isEmpty()) {
      JLabel empty = new JLabel("No matching skins", SwingConstants.CENTER);
      empty.setForeground(Theme.TEXT_DIM);
      grid.add(empty);
    }
    if (pages > 1) {
      JPanel navigation = new JPanel(new BorderLayout(12, 0));
      navigation.setName("inventoryPageControls");
      navigation.setBackground(Theme.BG_PANEL);
      navigation.setBorder(BorderFactory.createEmptyBorder(6, 8, 6, 8));
      JLabel count =
          new JLabel(
              "Page "
                  + (page + 1)
                  + " / "
                  + pages
                  + "  |  "
                  + (start + 1)
                  + "–"
                  + end
                  + " of "
                  + items.size()
                  + " skins",
              SwingConstants.CENTER);
      count.setForeground(Theme.TEXT);
      count.setFont(Theme.CONSOLE_PLAIN_12);
      navigation.add(count, BorderLayout.CENTER);
      JButton previous = new JButton("PREVIOUS"), next = new JButton("NEXT PAGE");
      previous.setName("inventoryPreviousPage");
      next.setName("inventoryNextPage");
      app.uiWidgets.styleButton(previous, Theme.BG_CARD, Theme.ACCENT_CT, Theme.BORDER);
      app.uiWidgets.styleButton(next, Theme.BG_CARD, Theme.ACCENT_CT, Theme.BORDER);
      previous.setEnabled(page > 0);
      next.setEnabled(page + 1 < pages);
      final int current = page;
      previous.addActionListener(
          e -> {
            grid.putClientProperty("pageIndex", current - 1);
            app.inventoryScreen.renderInventoryPage(grid);
            scroll.getViewport().setViewPosition(new Point());
          });
      next.addActionListener(
          e -> {
            grid.putClientProperty("pageIndex", current + 1);
            app.inventoryScreen.renderInventoryPage(grid);
            scroll.getViewport().setViewPosition(new Point());
          });
      navigation.add(previous, BorderLayout.WEST);
      navigation.add(next, BorderLayout.EAST);
      scroll.setColumnHeaderView(navigation);
    } else scroll.setColumnHeaderView(null);
    app.inventoryCards.updateInventoryGridCardWidths(grid, scroll);
    grid.revalidate();
    grid.repaint();
  }

  void updateTradeUpCardSelection(JPanel card, InventoryItem item, List<InventoryItem> selected) {
    boolean chosen = selected.contains(item);
    card.setBackground(chosen ? new Color(20, 60, 20) : new Color(30, 30, 40));
    Object text = card.getClientProperty("tradeUpText");
    if (text instanceof JPanel)
      ((JPanel) text).setBackground(chosen ? new Color(15, 45, 15) : new Color(22, 22, 30));
    card.setBorder(
        BorderFactory.createLineBorder(
            chosen ? new Color(80, 220, 80) : app.itemInspectionScreen.getRarityColor(item.rarity),
            chosen ? 3 : 2));
  }

  @SuppressWarnings("unchecked")
  void updateTradeUpSelectionView(JPanel grid) {
    List<InventoryItem> selected = (List<InventoryItem>) grid.getClientProperty("tradeUpSelection");
    List<InventoryItem> base = (List<InventoryItem>) grid.getClientProperty("tradeUpFilteredItems");
    if (selected == null || base == null) return;
    String lock =
        selected.isEmpty() ? "" : selected.get(0).rarity + ":" + selected.get(0).isStattrak;
    // Only first selection / last deselection changes the eligible pool. Other clicks touch one
    // card.
    if (!lock.equals(grid.getClientProperty("selectionLock"))) {
      grid.putClientProperty("selectionLock", lock);
      List<InventoryItem> eligible = new ArrayList<>();
      for (InventoryItem item : base)
        if (selected.isEmpty()
            || (item.rarity.equals(selected.get(0).rarity)
                && item.isStattrak == selected.get(0).isStattrak)) eligible.add(item);
      InventoryItem anchor = selected.isEmpty() ? null : selected.get(0);
      int page =
          anchor == null ? 0 : Math.max(0, eligible.indexOf(anchor)) / hGui.INVENTORY_PAGE_SIZE;
      grid.putClientProperty("pageItems", eligible);
      grid.putClientProperty("pageIndex", page);
      Point position =
          ((JScrollPane) grid.getClientProperty("pageScroll")).getViewport().getViewPosition();
      app.inventoryScreen.renderInventoryPage(grid);
      app.inventoryScreen.restoreViewPosition(
          (JScrollPane) grid.getClientProperty("pageScroll"), position);
    }
    Object summary = grid.getClientProperty("selectionSummaryChanged");
    if (summary instanceof Runnable) ((Runnable) summary).run();
  }

  boolean inventoryContentsUnchanged(JPanel panel) {
    Object previous = panel.getClientProperty("inventorySnapshot");
    ArrayList<InventoryItem> current = new ArrayList<>(app.inventoryList);
    if (current.equals(previous)) {
      app.inventoryScreen.updateVisibleInventoryPrices(panel);
      panel.repaint();
      return true;
    }
    panel.putClientProperty("inventorySnapshot", current);
    return false;
  }

  void updateVisibleInventoryPrices(Container root) {
    for (Component child : root.getComponents()) {
      if (child instanceof JLabel) {
        JLabel label = (JLabel) child;
        Object item = label.getClientProperty("inventoryPriceItem");
        if (item instanceof InventoryItem) label.setText("$" + ((InventoryItem) item).price);
      }
      if (child instanceof Container)
        app.inventoryScreen.updateVisibleInventoryPrices((Container) child);
    }
  }

  void collectViewControls(Container root, List<Component> controls) {
    for (Component child : root.getComponents()) {
      if (child instanceof JComboBox || child instanceof JTextField) controls.add(child);
      else if (child instanceof Container && !(child instanceof JScrollPane))
        app.inventoryScreen.collectViewControls((Container) child, controls);
    }
  }

  List<Object> captureViewControls(JPanel panel) {
    List<Component> controls = new ArrayList<>();
    app.inventoryScreen.collectViewControls(panel, controls);
    List<Object> values = new ArrayList<>();
    for (Component c : controls)
      values.add(
          c instanceof JComboBox
              ? ((JComboBox<?>) c).getSelectedItem()
              : ((JTextField) c).getText());
    return values;
  }

  void restoreViewControls(JPanel panel, List<Object> values) {
    List<Component> controls = new ArrayList<>();
    app.inventoryScreen.collectViewControls(panel, controls);
    for (int i = 0; i < Math.min(values.size(), controls.size()); i++) {
      Component c = controls.get(i);
      if (c instanceof JComboBox) ((JComboBox<?>) c).setSelectedItem(values.get(i));
      else ((JTextField) c).setText(String.valueOf(values.get(i)));
    }
  }

  Point captureViewPosition(JPanel panel) {
    for (Component c : panel.getComponents())
      if (c instanceof JScrollPane) return ((JScrollPane) c).getViewport().getViewPosition();
    return new Point();
  }

  void restoreViewPosition(JScrollPane scroll, Point position) {
    SwingUtilities.invokeLater(
        () -> {
          scroll.getViewport().getView().validate();
          Dimension view = scroll.getViewport().getViewSize();
          Dimension extent = scroll.getViewport().getExtentSize();
          scroll
              .getViewport()
              .setViewPosition(
                  new Point(
                      Math.max(0, Math.min(position.x, view.width - extent.width)),
                      Math.max(0, Math.min(position.y, view.height - extent.height))));
        });
  }

  void refreshInventoryTab() {
    if (app.cs2ShellEnabled) {
      app.cs2Screens.refreshCs2Inventory();
      return;
    }
    if (app.inventoryScreen.inventoryContentsUnchanged(app.inventoryTabPanel)) return;
    List<Object> savedControls = app.inventoryScreen.captureViewControls(app.inventoryTabPanel);
    Point savedPosition = app.inventoryScreen.captureViewPosition(app.inventoryTabPanel);
    app.inventoryScreen.releaseInventoryGridCaches(app.inventoryTabPanel);
    app.inventoryTabPanel.removeAll();

    if (app.inventoryList.isEmpty()) {
      JLabel empty =
          new JLabel("Your inventory is empty - open some cases!", SwingConstants.CENTER);
      empty.setFont(Theme.CONSOLE_BOLD_16);
      empty.setForeground(Theme.TEXT_DIM);
      app.inventoryTabPanel.setBackground(Theme.BG_DARK);
      app.inventoryTabPanel.add(empty, BorderLayout.CENTER);
      app.inventoryTabPanel.revalidate();
      app.inventoryTabPanel.repaint();
      return;
    }

    JPanel controlPanel = new JPanel(new GridLayout(5, 1));
    controlPanel.setBackground(Theme.BG_PANEL);
    controlPanel.setBorder(BorderFactory.createMatteBorder(0, 0, 1, 0, Theme.BORDER));

    JPanel searchPanel = app.uiWidgets.createControlRow();
    JLabel searchLabel = app.uiWidgets.createControlLabel("Search:", true);
    JComboBox<String> searchField = app.searchControls.createSearchFieldWithHistory(22);
    searchPanel.add(searchLabel);
    searchPanel.add(searchField);

    JPanel sortPanel = app.uiWidgets.createControlRow();
    JLabel sortPriceLabel = app.uiWidgets.createControlLabel("Price:", false);
    JComboBox<String> priceSortBox =
        app.uiWidgets.createComboBox(new String[] {"Default", "Highest Price", "Lowest Price"});

    JLabel sortRarityLabel = app.uiWidgets.createControlLabel("Rarity:", false);
    JComboBox<String> raritySortBox =
        app.uiWidgets.createComboBox(
            new String[] {
              "Default",
              "Agents",
              "Knife",
              "Gloves",
              "Covert",
              "Classified",
              "Restricted",
              "Milspec"
            });

    JLabel sortFloatLabel = app.uiWidgets.createControlLabel("Float:", false);
    JComboBox<String> floatSortBox =
        app.uiWidgets.createComboBox(new String[] {"Default", "Lowest Float", "Highest Float"});

    sortPanel.add(sortPriceLabel);
    sortPanel.add(priceSortBox);
    sortPanel.add(sortRarityLabel);
    sortPanel.add(raritySortBox);
    sortPanel.add(sortFloatLabel);
    sortPanel.add(floatSortBox);

    JLabel sortSTLabel = app.uiWidgets.createControlLabel("StatTrak:", false);
    JComboBox<String> stattrakSortBox =
        app.uiWidgets.createComboBox(new String[] {"All", "StatTrak Only", "Non-StatTrak"});

    JLabel equipLabel = app.uiWidgets.createControlLabel("Equip:", false);
    JComboBox<String> equippedSortBox =
        app.uiWidgets.createComboBox(
            new String[] {"All Items", "Equipped Only", "Unequipped Only"});

    java.util.Set<String> colSet = new java.util.LinkedHashSet<>();
    colSet.add("All");
    for (InventoryItem it : app.inventoryList) {
      app.inventoryScreen.resolveInventoryItemCollection(it);
      if (it.collection != null && !it.collection.isEmpty()) colSet.add(it.collection);
    }
    JLabel sortColLabel = app.uiWidgets.createControlLabel("Collection:", false);
    JComboBox<String> collectionSortBox =
        app.uiWidgets.createComboBox(colSet.toArray(new String[0]));

    JLabel sideLabel = app.uiWidgets.createControlLabel("Side:", false);
    JComboBox<String> sideSortBox =
        app.uiWidgets.createComboBox(new String[] {"Any Side", "T Side", "CT Side", "Both Sides"});

    JLabel minFloatLabel = app.uiWidgets.createControlLabel("Min Float:", false);
    JTextField minFloatField = app.uiWidgets.createDarkTextField(6);

    JLabel maxFloatLabel = app.uiWidgets.createControlLabel("Max Float:", false);
    JTextField maxFloatField = app.uiWidgets.createDarkTextField(6);

    JPanel sortPanel2 = app.uiWidgets.createControlRow();
    sortPanel2.add(sortSTLabel);
    sortPanel2.add(stattrakSortBox);
    sortPanel2.add(equipLabel);
    sortPanel2.add(equippedSortBox);
    sortPanel2.add(sideLabel);
    sortPanel2.add(sideSortBox);

    JPanel sortPanel3 = app.uiWidgets.createControlRow();
    sortPanel3.add(sortColLabel);
    sortPanel3.add(collectionSortBox);
    sortPanel3.add(minFloatLabel);
    sortPanel3.add(minFloatField);
    sortPanel3.add(maxFloatLabel);
    sortPanel3.add(maxFloatField);

    JPanel sellPanel = app.uiWidgets.createControlRow();

    JLabel invValueLabel = new JLabel();
    invValueLabel.setForeground(Theme.ACCENT_CT);
    invValueLabel.setFont(Theme.CONSOLE_BOLD_12);
    invValueLabel.setText(
        String.format(
            "  Inventory: $%.2f (%d collectible items; stock equipment excluded)",
            app.inventoryValue, app.cs2EquipmentScreens.collectibleInventory().size()));

    JButton refreshInventoryBtn = new JButton("REFRESH INVENTORY");
    app.uiWidgets.styleButton(
        refreshInventoryBtn, new Color(30, 90, 120), Theme.TEXT, new Color(70, 150, 190));
    refreshInventoryBtn.addActionListener(
        e -> {
          app.inventoryTabPanel.putClientProperty("inventorySnapshot", null);
          app.inventoryScreen.refreshInventoryTab();
        });
    sellPanel.add(refreshInventoryBtn);
    sellPanel.add(invValueLabel);

    controlPanel.add(searchPanel);
    controlPanel.add(sortPanel);
    controlPanel.add(sortPanel2);
    controlPanel.add(sortPanel3);
    controlPanel.add(sellPanel);
    app.inventoryTabPanel.add(controlPanel, BorderLayout.NORTH);

    JPanel grid = new JPanel(new GridLayout(0, 1, 8, 8));
    grid.setBackground(Theme.BG_DARK);
    grid.setBorder(BorderFactory.createEmptyBorder(8, 8, 8, 8));
    JScrollPane scroll = new JScrollPane(grid);
    scroll.setHorizontalScrollBarPolicy(ScrollPaneConstants.HORIZONTAL_SCROLLBAR_NEVER);
    scroll.setBackground(Theme.BG_DARK);
    scroll.getViewport().setBackground(Theme.BG_DARK);
    app.tradeCards.optimizeScrollPane(scroll);
    scroll.setBorder(BorderFactory.createLineBorder(Theme.BORDER, 1));
    scroll
        .getViewport()
        .addComponentListener(
            new java.awt.event.ComponentAdapter() {
              @Override
              public void componentResized(java.awt.event.ComponentEvent e) {
                app.inventoryCards.updateInventoryGridCardWidths(grid, scroll);
              }
            });
    app.inventoryTabPanel.add(scroll, BorderLayout.CENTER);
    app.inventoryTabPanel.setBackground(Theme.BG_DARK);

    Runnable rebuildGrid =
        () -> {
          grid.removeAll();
          scroll.setColumnHeaderView(null);
          String search = app.searchControls.getSearchText(searchField);
          String rarityOrder2 = (String) raritySortBox.getSelectedItem();
          String priceOrder = (String) priceSortBox.getSelectedItem();
          String floatOrder = (String) floatSortBox.getSelectedItem();

          String stattrakOrder = (String) stattrakSortBox.getSelectedItem();
          String equippedOrder = (String) equippedSortBox.getSelectedItem();
          String sideOrder = (String) sideSortBox.getSelectedItem();
          String collectionOrder = (String) collectionSortBox.getSelectedItem();
          double minFloat = Double.NEGATIVE_INFINITY;
          double maxFloat = Double.POSITIVE_INFINITY;
          try {
            if (!minFloatField.getText().trim().isEmpty())
              minFloat = Double.parseDouble(minFloatField.getText().trim());
          } catch (NumberFormatException ex) {
            minFloat = Double.NaN;
          }
          try {
            if (!maxFloatField.getText().trim().isEmpty())
              maxFloat = Double.parseDouble(maxFloatField.getText().trim());
          } catch (NumberFormatException ex) {
            maxFloat = Double.NaN;
          }
          final double minFloatFilter = minFloat;
          final double maxFloatFilter = maxFloat;

          List<InventoryItem> filtered = new ArrayList<>(app.inventoryList);
          if (Double.isNaN(minFloatFilter) || Double.isNaN(maxFloatFilter)) {
            grid.add(new JLabel("Enter valid float values.", SwingConstants.CENTER));
            app.inventoryCards.updateInventoryGridCardWidths(grid, scroll);
            grid.revalidate();
            grid.repaint();
            return;
          }
          Integer searchPatternId = null;
          if (!search.isEmpty()) {
            try {
              searchPatternId = Integer.parseInt(search);
            } catch (NumberFormatException ex) {
              searchPatternId = null;
            }
          }
          final Integer patternSearch = searchPatternId;
          if (!search.isEmpty()) {
            filtered.removeIf(
                it ->
                    !it.name.toLowerCase().contains(search)
                        && !it.condition.toLowerCase().contains(search)
                        && !it.rarity.toLowerCase().contains(search)
                        && (patternSearch == null || it.patternID != patternSearch));
          }
          if ("Agents".equals(rarityOrder2)) {
            filtered.removeIf(it -> !app.itemMetadataService.isAgentSkin(it.name));
          } else if (!rarityOrder2.equals("Default")) {
            filtered.removeIf(it -> !it.rarity.contains(rarityOrder2));
          }
          if ("StatTrak Only".equals(stattrakOrder)) filtered.removeIf(it -> !it.isStattrak);
          if ("Non-StatTrak".equals(stattrakOrder)) filtered.removeIf(it -> it.isStattrak);
          if ("Equipped Only".equals(equippedOrder))
            filtered.removeIf(it -> !app.loadoutScreen.isItemEquipped(it));
          if ("Unequipped Only".equals(equippedOrder))
            filtered.removeIf(app.loadoutScreen::isItemEquipped);
          filtered.removeIf(it -> !app.loadoutScreen.passesSideFilter(it, sideOrder));
          if (!"All".equals(collectionOrder))
            filtered.removeIf(it -> !collectionOrder.equals(it.collection));
          filtered.removeIf(
              it ->
                  !app.itemMetadataService.isAgentSkin(it.name)
                      && (it.itemFloat < minFloatFilter || it.itemFloat > maxFloatFilter));
          if ("Highest Price".equals(priceOrder)) {
            filtered.sort((a, b) -> Double.compare(b.price.doubleValue(), a.price.doubleValue()));
          } else if ("Lowest Price".equals(priceOrder)) {
            filtered.sort((a, b) -> Double.compare(a.price.doubleValue(), b.price.doubleValue()));
          } else {
            filtered.sort(
                (a, b) ->
                    Integer.compare(
                        CoreUtilities.rarityRank(a.rarity), CoreUtilities.rarityRank(b.rarity)));
          }
          if ("Lowest Float".equals(floatOrder)) {
            filtered.sort((a, b) -> Double.compare(a.itemFloat, b.itemFloat));
          } else if ("Highest Float".equals(floatOrder)) {
            filtered.sort((a, b) -> Double.compare(b.itemFloat, a.itemFloat));
          }

          app.inventoryScreen.setPagedInventoryItems(
              grid,
              scroll,
              filtered,
              item -> app.inventoryCards.createInventoryCardFast(item, item.getThumb110()),
              0);
        };

    grid.putClientProperty("rebuildGrid", rebuildGrid);
    app.inventoryScreen.restoreViewControls(app.inventoryTabPanel, savedControls);
    javax.swing.Timer searchTimer =
        app.searchControls.createSearchHistoryTimer(searchField, rebuildGrid);
    app.searchControls.installSearchHistoryHandlers(searchField, searchTimer, rebuildGrid);
    priceSortBox.addActionListener(e -> rebuildGrid.run());
    raritySortBox.addActionListener(e -> rebuildGrid.run());
    floatSortBox.addActionListener(e -> rebuildGrid.run());
    stattrakSortBox.addActionListener(e -> rebuildGrid.run());
    equippedSortBox.addActionListener(e -> rebuildGrid.run());
    sideSortBox.addActionListener(e -> rebuildGrid.run());
    collectionSortBox.addActionListener(e -> rebuildGrid.run());
    minFloatField.addKeyListener(
        new KeyAdapter() {
          public void keyReleased(KeyEvent e) {
            searchTimer.restart();
          }
        });
    maxFloatField.addKeyListener(
        new KeyAdapter() {
          public void keyReleased(KeyEvent e) {
            searchTimer.restart();
          }
        });

    SwingUtilities.invokeLater(
        () -> {
          rebuildGrid.run();
          app.inventoryScreen.restoreViewPosition(scroll, savedPosition);
        });
    app.inventoryTabPanel.revalidate();
    app.inventoryTabPanel.repaint();
  }
}
