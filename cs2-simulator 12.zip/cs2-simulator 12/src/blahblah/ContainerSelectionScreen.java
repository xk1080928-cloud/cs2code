package blahblah;

import blahblah.hGui.*;
import java.awt.*;
import java.awt.event.*;
import java.util.ArrayList;
import java.util.List;
import javax.swing.*;

/** Container Selection Screen: focused feature implementation. */
final class ContainerSelectionScreen {
  private final hGui app;

  ContainerSelectionScreen(hGui app) {
    this.app = app;
  }

  void invalidateCs2Inventory() {
    if (app.inventoryTabPanel != null) app.inventoryTabPanel.putClientProperty("cs2Snapshot", null);
  }

  void showCs2SupplyMenu(OwnedSupply supply) {
    JPopupMenu menu = new JPopupMenu();
    menu.setName("cs2SupplyActions");
    JMenuItem unlock = new JMenuItem("Unlock Container");
    unlock.addActionListener(e -> app.containerSelectionScreen.beginCs2UnlockSelection(supply));
    menu.add(unlock);
    if (!supply.key) {
      JMenuItem sell = new JMenuItem("Sell on Market");
      sell.setName("sellOwnedContainer");
      sell.addActionListener(
          e -> {
            if (app.ownedSupplies.contains(supply))
              app.exchangeScreens.navigateExchangeDirectory(
                  app.containerMarketService.item(supply));
          });
      menu.add(sell);
    }
    Point point = app.getMousePosition();
    menu.show(
        app,
        point == null ? app.getWidth() / 2 : point.x,
        point == null ? app.getHeight() / 2 : point.y);
  }

  void beginCs2UnlockSelection(OwnedSupply supply) {
    if (!app.ownedSupplies.contains(supply)) return;
    app.cs2SelectedOpeningContainer = null;
    app.cs2SelectedOpeningKey = null;
    CaseType ct = CaseType.valueOf(supply.caseId);
    if (!supply.key
        && (!app.containerInventoryService.requiresOwnedKey(ct)
            || app.containerInventoryService.ownedSupplyCount(ct, true) == 0)) {
      app.cs2SelectedOpeningContainer = supply.id;
      app.cs2UnlockSelection = null;
      app.cs2Screens.showCs2Container(ct);
      return;
    }
    app.cs2EquipFilter = null;
    app.cs2UnlockSelection = supply;
    app.cs2InventoryPage = 0;
    app.mainTabs.setSelectedIndex(2);
    app.containerSelectionScreen.renderCs2UnlockSelection();
  }

  void renderCs2UnlockSelection() {
    OwnedSupply selected = app.cs2UnlockSelection;
    if (selected == null) return;
    app.inventoryTabPanel.removeAll();
    app.inventoryTabPanel.setLayout(new BorderLayout());
    app.inventoryTabPanel.add(app.cs2Screens.createCs2InventoryNav(), BorderLayout.NORTH);
    JPanel scene = app.cs2Screens.cs2Scene(true);
    scene.setName("cs2MatchingSupplySelection");
    CaseType ct = CaseType.valueOf(selected.caseId);
    List<OwnedSupply> matches = new ArrayList<>();
    for (OwnedSupply s : app.ownedSupplies)
      if (s.caseId.equals(selected.caseId) && s.key != selected.key) matches.add(s);
    JPanel grid = app.cs2Screens.cs2Grid(8, 14, 18);
    grid.setName("cs2MatchingSupplyGrid");
    grid.setBorder(BorderFactory.createEmptyBorder(12, 28, 24, 28));
    int pages = Math.max(1, (matches.size() + 55) / 56);
    app.cs2InventoryPage = Math.max(0, Math.min(app.cs2InventoryPage, pages - 1));
    for (int n = app.cs2InventoryPage * 56;
        n < Math.min(matches.size(), (app.cs2InventoryPage + 1) * 56);
        n++) {
      OwnedSupply opposite = matches.get(n);
      JLabel art = new JLabel("", SwingConstants.CENTER);
      app.cs2Screens.bindCs2SupplyArtwork(ct, opposite.key, art, 150, 104);
      JPanel card =
          app.cs2Screens.createCs2Tile(
              opposite.key ? app.cs2EquipmentScreens.keyName(ct) : ct.name,
              opposite.key ? "Key" : "Container",
              new Color(170, 188, 205),
              art,
              () -> {
                if (!app.ownedSupplies.contains(selected)
                    || !app.ownedSupplies.contains(opposite)) {
                  app.containerSelectionScreen.renderCs2UnlockSelection();
                  return;
                }
                app.cs2SelectedOpeningContainer = selected.key ? opposite.id : selected.id;
                app.cs2SelectedOpeningKey = selected.key ? selected.id : opposite.id;
                app.cs2UnlockSelection = null;
                app.containerSelectionScreen.invalidateCs2Inventory();
                app.cs2Screens.refreshCs2Inventory();
                app.cs2Screens.showCs2Container(ct);
              });
      card.putClientProperty("ownedSupply", opposite);
      grid.add(card);
    }
    JScrollPane scroll = new JScrollPane(grid);
    scroll.setBorder(null);
    scroll.setOpaque(false);
    scroll.getViewport().setOpaque(false);
    scroll.getVerticalScrollBar().setUnitIncrement(20);
    scene.add(scroll, BorderLayout.CENTER);
    JPanel footer = app.cs2Screens.cs2Glass(new FlowLayout());
    JButton
        previous =
            app.cs2Screens.cs2Button(
                "‹",
                false,
                e -> {
                  app.cs2InventoryPage--;
                  app.containerSelectionScreen.renderCs2UnlockSelection();
                }),
        next =
            app.cs2Screens.cs2Button(
                "›",
                false,
                e -> {
                  app.cs2InventoryPage++;
                  app.containerSelectionScreen.renderCs2UnlockSelection();
                });
    previous.setEnabled(app.cs2InventoryPage > 0);
    next.setEnabled(app.cs2InventoryPage + 1 < pages);
    footer.add(previous);
    footer.add(
        app.cs2Screens.cs2Text(
            matches.size() + " matching items  •  " + (app.cs2InventoryPage + 1) + " / " + pages,
            13,
            Theme.TEXT));
    footer.add(next);
    scene.add(footer, BorderLayout.SOUTH);
    app.inventoryTabPanel.add(scene, BorderLayout.CENTER);
    app.inventoryTabPanel.revalidate();
    app.inventoryTabPanel.repaint();
  }

  JPanel createCs2MissionCard() {
    return new MissionBoard(app).build();
  }
}
