package blahblah;

import blahblah.hGui.*;
import java.awt.*;
import java.awt.event.*;
import java.math.BigDecimal;
import java.math.RoundingMode;
import javax.swing.*;

/** Item Inspection Screen: focused feature implementation. */
final class ItemInspectionScreen {
  private final hGui app;

  ItemInspectionScreen(hGui app) {
    this.app = app;
  }

  public void showItemPopup(InventoryItem item) {
    app.itemInspectionScreen.showItemPopup(item, true);
  }

  public void showItemPopup(InventoryItem item, boolean allowMarketActions) {
    if (app.cs2ShellEnabled) {
      app.cs2Screens.showCs2ItemMenu(item);
      return;
    }
    if (item == null) {
      return;
    }
    JDialog dialog = new JDialog((Frame) null, "Inspect Item", true);
    dialog.setSize(700, 760);
    dialog.setLocationRelativeTo(app);
    dialog.setDefaultCloseOperation(JDialog.DISPOSE_ON_CLOSE);

    Color BG = new Color(18, 18, 26);
    Color TEXT = new Color(230, 230, 235);
    Color DIM = Theme.TEXT_DIM;

    JPanel root = new JPanel(new BorderLayout(0, 0));
    root.setBackground(BG);
    root.setBorder(BorderFactory.createLineBorder(Theme.ACCENT_T, 2));

    JPanel header = new JPanel(new BorderLayout(16, 0));
    header.setBackground(Theme.BG_CARD);
    header.setBorder(BorderFactory.createEmptyBorder(16, 18, 16, 18));

    JLabel inspectArtwork = new JLabel("", SwingConstants.CENTER);
    inspectArtwork.setPreferredSize(new Dimension(300, 220));
    inspectArtwork.setBorder(BorderFactory.createLineBorder(Theme.ACCENT_T, 1));
    app.artworkService.getSkinImageFromName(item.name, item.condition, inspectArtwork, 300, 220);
    header.add(inspectArtwork, BorderLayout.WEST);

    JPanel nameMeta = new JPanel();
    nameMeta.setLayout(new BoxLayout(nameMeta, BoxLayout.Y_AXIS));
    nameMeta.setBackground(Theme.BG_CARD);

    String displayName = (item.isStattrak ? "StatTrak " : "") + item.name;
    JLabel nameL =
        new JLabel("<html><body style=\'width:320px\'>" + displayName + "</body></html>");
    nameL.setFont(new Font("Consolas", Font.BOLD, 16));
    nameL.setForeground(item.isStattrak ? new Color(255, 153, 51) : TEXT);
    nameL.setAlignmentX(java.awt.Component.LEFT_ALIGNMENT);

    JLabel rarityL = new JLabel(item.rarity);
    rarityL.setFont(new Font("Consolas", Font.BOLD, 12));
    rarityL.setForeground(Theme.ACCENT_T);
    rarityL.setAlignmentX(java.awt.Component.LEFT_ALIGNMENT);

    JLabel condL =
        new JLabel(app.itemMetadataService.isAgentSkin(item.name) ? "Agent" : item.condition);
    condL.setFont(new Font("Consolas", Font.PLAIN, 12));
    condL.setForeground(DIM);
    condL.setAlignmentX(java.awt.Component.LEFT_ALIGNMENT);

    nameMeta.add(nameL);
    nameMeta.add(Box.createRigidArea(new Dimension(0, 4)));
    nameMeta.add(rarityL);
    nameMeta.add(Box.createRigidArea(new Dimension(0, 3)));
    nameMeta.add(condL);

    app.inventoryScreen.resolveInventoryItemCollection(item);
    if (item.collection != null) {
      JLabel colL = new JLabel(item.collection);
      colL.setFont(new Font("Consolas", Font.ITALIC, 11));
      colL.setForeground(new Color(170, 130, 255));
      colL.setAlignmentX(java.awt.Component.LEFT_ALIGNMENT);
      nameMeta.add(Box.createRigidArea(new Dimension(0, 3)));
      nameMeta.add(colL);
    }
    nameMeta.add(Box.createRigidArea(new Dimension(0, 8)));
    header.add(nameMeta, BorderLayout.CENTER);
    root.add(header, BorderLayout.NORTH);

    final double currentPrice = item.price.doubleValue();
    String rawItemName = item.name;
    if (item.blueGemTier != null && rawItemName.contains("(Blue Gem")) {
      rawItemName = rawItemName.substring(0, rawItemName.indexOf("(Blue Gem")).trim();
    }
    JPanel content = new JPanel();
    content.setLayout(new BoxLayout(content, BoxLayout.Y_AXIS));
    content.setBackground(BG);
    content.setBorder(BorderFactory.createEmptyBorder(14, 18, 10, 18));

    JPanel statsCard = new JPanel(new BorderLayout(0, 10));
    statsCard.setBackground(Theme.BG_CARD);
    statsCard.setBorder(
        BorderFactory.createCompoundBorder(
            BorderFactory.createLineBorder(new Color(50, 50, 70), 1),
            BorderFactory.createEmptyBorder(14, 14, 14, 14)));

    JLabel statsTitle = new JLabel("Item Details");
    statsTitle.setForeground(TEXT);
    statsTitle.setFont(new Font("Consolas", Font.BOLD, 13));
    statsCard.add(statsTitle, BorderLayout.NORTH);

    JPanel statsPanel = new JPanel(new GridLayout(0, 2, 10, 8));
    statsPanel.setBackground(Theme.BG_CARD);

    java.util.List<String[]> statsList = new java.util.ArrayList<>();
    statsList.add(new String[] {"Market Price", String.format("$%.2f", currentPrice)});
    statsList.add(new String[] {"Rarity", item.rarity});
    if (item.collection != null) {
      statsList.add(new String[] {"Collection", item.collection});
    }
    statsList.add(
        new String[] {"Owner", item.currentOwner != null ? item.currentOwner : "Unknown"});
    if (app.itemMetadataService.shouldShowFloatForItem(item.name, item.rarity)) {
      statsList.add(new String[] {"Float", String.format("%.8f", item.itemFloat)});
    }
    if (app.itemMetadataService.shouldShowPatternForItem(item.name, item.rarity)) {
      statsList.add(new String[] {"Pattern ID", String.valueOf(item.patternID)});
    }
    if (item.blueGemTier != null) statsList.add(new String[] {"Blue Gem", item.blueGemTier});

    for (String[] row : statsList) {
      JLabel key = new JLabel(row[0]);
      key.setFont(new Font("Consolas", Font.PLAIN, 11));
      key.setForeground(DIM);
      JLabel val = new JLabel(row[1]);
      val.setFont(new Font("Consolas", Font.BOLD, 11));
      val.setForeground(TEXT);
      statsPanel.add(key);
      statsPanel.add(val);
    }
    statsCard.add(statsPanel, BorderLayout.CENTER);
    content.add(statsCard);
    content.add(Box.createRigidArea(new Dimension(0, 12)));

    String popupOwner =
        item.currentOwner != null && !"UNASSIGNED".equalsIgnoreCase(item.currentOwner)
            ? item.currentOwner
            : "YOU";
    java.util.List<ItemHistoryEntry> ownershipHistory =
        app.ownershipHistoryService.getDisplayHistory(item, popupOwner);
    content.add(
        app.itemInspectionScreen.createItemOwnershipHistoryPanel(
            "Item History", ownershipHistory, Theme.BG_CARD, TEXT, DIM, Theme.ACCENT_T));

    JScrollPane contentScroll = new JScrollPane(content);
    contentScroll.setBorder(null);
    contentScroll.setBackground(BG);
    contentScroll.getViewport().setBackground(BG);
    contentScroll.getVerticalScrollBar().setUnitIncrement(18);
    root.add(contentScroll, BorderLayout.CENTER);

    if (allowMarketActions) {
      JPanel btnOuter = new JPanel(new BorderLayout(0, 6));
      btnOuter.setBackground(BG);
      btnOuter.setBorder(BorderFactory.createEmptyBorder(8, 16, 14, 16));

      JButton listBtn = new JButton("List on Market");

      for (JButton btn : new JButton[] {listBtn}) {
        btn.setBackground(new Color(38, 38, 52));
        btn.setFont(new Font("Consolas", Font.BOLD, 11));
        btn.setForeground(TEXT);
        btn.setFocusPainted(false);
        btn.setBorder(
            BorderFactory.createCompoundBorder(
                BorderFactory.createLineBorder(new Color(60, 60, 80), 1),
                BorderFactory.createEmptyBorder(7, 10, 7, 10)));
        btn.addMouseListener(
            new MouseAdapter() {
              @Override
              public void mouseEntered(MouseEvent e) {
                btn.setBackground(new Color(55, 55, 75));
              }

              @Override
              public void mouseExited(MouseEvent e) {
                btn.setBackground(new Color(38, 38, 52));
              }
            });
      }

      JPanel bottomRow = new JPanel(new GridLayout(1, 1, 8, 0));
      bottomRow.setBackground(BG);
      bottomRow.add(listBtn);
      btnOuter.add(bottomRow, BorderLayout.SOUTH);
      root.add(btnOuter, BorderLayout.SOUTH);

      listBtn.addActionListener(
          e -> {
            JDialog listDialog = new JDialog(dialog, "List on Market", true);
            listDialog.setSize(420, 310);
            listDialog.setLocationRelativeTo(dialog);
            listDialog.setDefaultCloseOperation(JDialog.DISPOSE_ON_CLOSE);

            JPanel lroot = new JPanel(new BorderLayout(0, 0));
            lroot.setBackground(BG);
            lroot.setBorder(BorderFactory.createLineBorder(Theme.ACCENT_T, 2));

            JPanel lheader = new JPanel(new BorderLayout());
            lheader.setBackground(Theme.BG_CARD);
            lheader.setBorder(BorderFactory.createEmptyBorder(12, 16, 12, 16));
            JLabel lTitle = new JLabel("List on Market");
            lTitle.setFont(new Font("Consolas", Font.BOLD, 14));
            lTitle.setForeground(Theme.ACCENT_T);
            JLabel lSkin = new JLabel(displayName + "  ·  " + item.condition);
            lSkin.setFont(new Font("Consolas", Font.PLAIN, 11));
            lSkin.setForeground(DIM);
            lheader.add(lTitle, BorderLayout.NORTH);
            lheader.add(lSkin, BorderLayout.SOUTH);
            lroot.add(lheader, BorderLayout.NORTH);

            JPanel lform = new JPanel(new GridBagLayout());
            lform.setBackground(BG);
            lform.setBorder(BorderFactory.createEmptyBorder(14, 20, 8, 20));
            GridBagConstraints lgc = new GridBagConstraints();
            lgc.insets = new java.awt.Insets(6, 4, 6, 4);
            lgc.fill = GridBagConstraints.HORIZONTAL;

            lgc.gridx = 0;
            lgc.gridy = 0;
            lgc.weightx = 0.4;
            JLabel marketLbl = new JLabel("Marketplace:");
            marketLbl.setFont(new Font("Consolas", Font.PLAIN, 11));
            marketLbl.setForeground(DIM);
            lform.add(marketLbl, lgc);
            lgc.gridx = 1;
            lgc.weightx = 0.6;
            // Only include marketplaces that have at least one listing for this skin/condition
            String[] marketplaceNames =
                java.util.Arrays.stream(MarketplaceProfile.CATALOG)
                    .filter(
                        profile ->
                            app.offerNeonAndMirageScreens.getLowestMarketplacePriceForItem(
                                    item, profile.name)
                                > 0.0)
                    .map(profile -> profile.name)
                    .toArray(String[]::new);
            if (marketplaceNames.length == 0) {
              // Fallback: show all if none have listings (shouldn't normally happen)
              marketplaceNames =
                  java.util.Arrays.stream(MarketplaceProfile.CATALOG)
                      .map(profile -> profile.name)
                      .toArray(String[]::new);
            }
            JComboBox<String> marketBox = new JComboBox<>(marketplaceNames);
            app.uiWidgets.styleComboBox(marketBox);
            lform.add(marketBox, lgc);

            lgc.gridx = 0;
            lgc.gridy = 1;
            lgc.weightx = 0.4;
            JLabel cheapestLbl = new JLabel("Lowest listing:");
            cheapestLbl.setFont(new Font("Consolas", Font.PLAIN, 11));
            cheapestLbl.setForeground(DIM);
            lform.add(cheapestLbl, lgc);
            lgc.gridx = 1;
            lgc.weightx = 0.6;
            JLabel cheapestVal = new JLabel();
            cheapestVal.setFont(new Font("Consolas", Font.BOLD, 11));
            cheapestVal.setForeground(TEXT);
            lform.add(cheapestVal, lgc);

            lgc.gridx = 0;
            lgc.gridy = 2;
            lgc.weightx = 0.4;
            JLabel mktLbl = new JLabel("Reference price:");
            mktLbl.setFont(new Font("Consolas", Font.PLAIN, 11));
            mktLbl.setForeground(DIM);
            lform.add(mktLbl, lgc);
            lgc.gridx = 1;
            lgc.weightx = 0.6;
            JLabel mktVal = new JLabel();
            mktVal.setFont(new Font("Consolas", Font.BOLD, 11));
            mktVal.setForeground(TEXT);
            lform.add(mktVal, lgc);

            // Find the global cheapest listing across all marketplaces once
            double[] globalCheapestPrice = {Double.MAX_VALUE};
            String[] globalCheapestMarket = {""};
            for (MarketplaceProfile profile : MarketplaceProfile.CATALOG) {
              double p =
                  app.offerNeonAndMirageScreens.getLowestMarketplacePriceForItem(
                      item, profile.name);
              if (p > 0 && p < globalCheapestPrice[0]) {
                globalCheapestPrice[0] = p;
                globalCheapestMarket[0] = profile.name;
              }
            }
            if (globalCheapestPrice[0] == Double.MAX_VALUE) {
              mktVal.setText(String.format("$%.2f  ·  estimated item value", currentPrice));
            } else {
              mktVal.setText(
                  String.format("$%.2f  ·  %s", globalCheapestPrice[0], globalCheapestMarket[0]));
            }

            lgc.gridx = 0;
            lgc.gridy = 3;
            lgc.weightx = 0.4;
            JLabel priceLbl = new JLabel("Your price ($):");
            priceLbl.setFont(new Font("Consolas", Font.PLAIN, 11));
            priceLbl.setForeground(DIM);
            lform.add(priceLbl, lgc);
            lgc.gridx = 1;
            lgc.weightx = 0.6;
            JTextField priceField = new JTextField(String.format("%.2f", currentPrice));
            priceField.setBackground(new Color(38, 38, 52));
            priceField.setForeground(TEXT);
            priceField.setCaretColor(TEXT);
            priceField.setFont(new Font("Consolas", Font.BOLD, 11));
            priceField.setBorder(
                BorderFactory.createCompoundBorder(
                    BorderFactory.createLineBorder(new Color(60, 60, 80), 1),
                    BorderFactory.createEmptyBorder(4, 8, 4, 8)));
            lform.add(priceField, lgc);

            lgc.gridx = 0;
            lgc.gridy = 4;
            lgc.gridwidth = 2;
            JLabel estLbl = new JLabel(" ");
            estLbl.setFont(new Font("Consolas", Font.ITALIC, 10));
            estLbl.setForeground(new Color(100, 210, 255));
            lform.add(estLbl, lgc);

            Runnable updateMarketplaceReference =
                () -> {
                  String selectedMarket = (String) marketBox.getSelectedItem();
                  double cheapestListing =
                      app.offerNeonAndMirageScreens.getLowestMarketplacePriceForItem(
                          item, selectedMarket);
                  cheapestVal.setText(
                      cheapestListing > 0
                          ? String.format("$%.2f on %s", cheapestListing, selectedMarket)
                          : "No matching listings");
                };
            marketBox.addActionListener(ev2 -> updateMarketplaceReference.run());
            updateMarketplaceReference.run();

            Runnable updateEstLabel =
                () -> {
                  try {
                    double p = Double.parseDouble(priceField.getText().trim());
                    int t = app.listingSalesService.calculateSellTime(p, currentPrice);
                    estLbl.setText("Est. sell time: ~" + t + "s");
                  } catch (NumberFormatException ex) {
                    estLbl.setText("Enter a valid price");
                  }
                };
            priceField
                .getDocument()
                .addDocumentListener(
                    new javax.swing.event.DocumentListener() {
                      public void insertUpdate(javax.swing.event.DocumentEvent e) {
                        updateEstLabel.run();
                      }

                      public void removeUpdate(javax.swing.event.DocumentEvent e) {
                        updateEstLabel.run();
                      }

                      public void changedUpdate(javax.swing.event.DocumentEvent e) {
                        updateEstLabel.run();
                      }
                    });

            int initTime = app.listingSalesService.calculateSellTime(currentPrice, currentPrice);
            estLbl.setText("Est. sell time: ~" + initTime + "s");

            lroot.add(lform, BorderLayout.CENTER);

            JButton lConfirm = new JButton("List Item");
            JButton lCancel = new JButton("Cancel");
            for (JButton b : new JButton[] {lConfirm, lCancel}) {
              final JButton btn = b;
              btn.setFont(new Font("Consolas", Font.BOLD, 11));
              btn.setBackground(new Color(38, 38, 52));
              btn.setForeground(TEXT);
              btn.setFocusPainted(false);
              btn.setBorder(
                  BorderFactory.createCompoundBorder(
                      BorderFactory.createLineBorder(new Color(60, 60, 80), 1),
                      BorderFactory.createEmptyBorder(7, 16, 7, 16)));
              btn.addMouseListener(
                  new MouseAdapter() {
                    @Override
                    public void mouseEntered(MouseEvent e) {
                      btn.setBackground(new Color(55, 55, 75));
                    }

                    @Override
                    public void mouseExited(MouseEvent e) {
                      btn.setBackground(new Color(38, 38, 52));
                    }
                  });
            }
            lConfirm.setForeground(new Color(80, 220, 120));

            JPanel lbtns = new JPanel(new FlowLayout(FlowLayout.RIGHT, 8, 8));
            lbtns.setBackground(BG);
            lbtns.add(lCancel);
            lbtns.add(lConfirm);
            lroot.add(lbtns, BorderLayout.SOUTH);

            lCancel.addActionListener(ev -> listDialog.dispose());
            lConfirm.addActionListener(
                ev -> {
                  try {
                    double listPrice = Double.parseDouble(priceField.getText().trim());
                    if (listPrice <= 0) {
                      JOptionPane.showMessageDialog(listDialog, "Price must be positive!");
                      return;
                    }
                    int sellTime =
                        app.listingSalesService.calculateSellTime(listPrice, currentPrice);
                    String selectedMarketplace = (String) marketBox.getSelectedItem();
                    app.ownershipHistoryService.addItemHistory(
                        item,
                        System.currentTimeMillis(),
                        "Listed On Market",
                        String.format(
                            "YOU listed it on %s for $%.2f.", selectedMarketplace, listPrice),
                        "YOU");
                    MarketListing playerListing =
                        new MarketListing(item, listPrice, sellTime, true);
                    MarketplaceProfile playerProfile =
                        MarketplaceProfile.byName(selectedMarketplace);
                    playerListing.marketplaceName = playerProfile.name;
                    playerListing.marketplaceType = playerProfile.type;
                    playerListing.marketplaceRating = playerProfile.rating;
                    playerListing.marketplaceReviews = playerProfile.reviews;
                    app.activeListings.add(playerListing);
                    app.inventoryValue =
                        Math.max(0.0, app.inventoryValue - item.price.doubleValue());
                    app.inventoryList.remove(item);
                    app.caseRollService.writeStats();
                    BigDecimal newInventoryValue =
                        BigDecimal.valueOf(app.inventoryValue).setScale(2, RoundingMode.HALF_UP);
                    app.totalInventoryValueLabel.setText("Inventory Value: $" + newInventoryValue);
                    app.bundledArtwork.refreshMainUI();
                    listDialog.dispose();
                    dialog.dispose();
                    JOptionPane.showMessageDialog(
                        app,
                        String.format(
                            "Listed on %s for $%.2f  ·  Est. sell time: ~%ds",
                            selectedMarketplace, listPrice, sellTime));
                    SwingUtilities.invokeLater(() -> app.inventoryScreen.refreshInventoryTab());
                  } catch (NumberFormatException ex) {
                    JOptionPane.showMessageDialog(listDialog, "Invalid price format!");
                  }
                });

            listDialog.setContentPane(lroot);
            listDialog.setVisible(true);
          });
    }

    dialog.setContentPane(root);
    dialog.setVisible(true);
  }

  JPanel createItemOwnershipHistoryPanel(
      String title,
      java.util.List<ItemHistoryEntry> records,
      Color bgCard,
      Color text,
      Color dim,
      Color accent) {
    JPanel panel = new JPanel(new BorderLayout(0, 10));
    panel.setBackground(bgCard);
    panel.setBorder(
        BorderFactory.createCompoundBorder(
            BorderFactory.createLineBorder(new Color(50, 50, 70), 1),
            BorderFactory.createEmptyBorder(14, 14, 14, 14)));

    JLabel titleLabel = new JLabel(title);
    titleLabel.setForeground(accent);
    titleLabel.setFont(new Font("Consolas", Font.BOLD, 13));
    panel.add(titleLabel, BorderLayout.NORTH);

    JPanel list = new JPanel();
    list.setLayout(new BoxLayout(list, BoxLayout.Y_AXIS));
    list.setBackground(bgCard);

    if (records == null || records.isEmpty()) {
      JLabel empty = new JLabel("No tracked ownership history yet");
      empty.setForeground(dim);
      empty.setFont(new Font("Consolas", Font.ITALIC, 11));
      list.add(empty);
    } else {
      for (ItemHistoryEntry record : records) {
        JPanel row = new JPanel(new GridLayout(0, 1, 0, 3));
        row.setBackground(new Color(33, 33, 46));
        row.setBorder(
            BorderFactory.createCompoundBorder(
                BorderFactory.createLineBorder(new Color(56, 56, 74), 1),
                BorderFactory.createEmptyBorder(8, 10, 8, 10)));

        JLabel event = new JLabel(record.detail != null ? record.detail : "history event");
        event.setForeground(text);
        event.setFont(new Font("Consolas", Font.BOLD, 12));

        JLabel time = new JLabel(app.itemInspectionScreen.formatInspectTimestamp(record.timestamp));
        time.setForeground(dim);
        time.setFont(new Font("Consolas", Font.ITALIC, 10));

        row.add(event);
        row.add(time);
        list.add(row);
        list.add(Box.createRigidArea(new Dimension(0, 8)));
      }
    }

    JScrollPane scroll = new JScrollPane(list);
    scroll.setBorder(null);
    scroll.setBackground(bgCard);
    scroll.getViewport().setBackground(bgCard);
    scroll.getVerticalScrollBar().setUnitIncrement(16);
    panel.add(scroll, BorderLayout.CENTER);
    return panel;
  }

  String formatInspectTimestamp(long timestamp) {
    java.text.SimpleDateFormat fmt = new java.text.SimpleDateFormat("MMM d, yyyy h:mm a");
    return fmt.format(new java.util.Date(timestamp));
  }

  public Color getRarityColor(String rarity) {
    if (rarity.contains("Knife")) return new Color(228, 174, 57);
    if (rarity.contains("Gold")) return new Color(228, 174, 57);
    if (rarity.contains("Gloves")) return new Color(228, 174, 57);
    if (rarity.contains("Contraband")) return new Color(235, 137, 42);
    if (rarity.contains("Covert")) return new Color(235, 75, 75);
    if (rarity.contains("Master")) return new Color(235, 75, 75);
    if (rarity.contains("Classified")) return new Color(211, 44, 230);
    if (rarity.contains("Superior")) return new Color(211, 44, 230);
    if (rarity.contains("Restricted")) return new Color(136, 71, 255);
    if (rarity.contains("Exceptional")) return new Color(136, 71, 255);
    if (rarity.contains("Milspec")) return Theme.RARITY_MILSPEC;
    if (rarity.contains("Distinguished")) return Theme.RARITY_MILSPEC;
    if (rarity.contains("Consumer")) return new Color(176, 195, 217);
    if (rarity.contains("Industrial")) return new Color(94, 152, 217);
    return Theme.RARITY_MILSPEC;
  }
}
