package blahblah;

import blahblah.hGui.*;
import java.util.ArrayList;

/** Same DTO as the legacy inventory; used for inaccessible stored skins, with exact identities. */
final class InventoryItemCodec {
  static GameState.SerializableInventoryItem encode(InventoryItem i) {
    GameState.SerializableInventoryItem s = new GameState.SerializableInventoryItem();
    s.name = i.name;
    s.condition = i.condition;
    s.rarity = i.rarity;
    s.price = i.price.doubleValue();
    s.itemFloat = i.itemFloat;
    s.isStattrak = i.isStattrak;
    s.patternID = i.patternID;
    s.blueGemTier = i.blueGemTier;
    s.basePrice = i.basePrice;
    s.collection = i.collection;
    s.createdAt = i.createdAt;
    s.currentOwner = i.currentOwner;
    s.itemId = i.itemId;
    s.history = i.history == null ? new ArrayList<>() : new ArrayList<>(i.history);
    return s;
  }

  static InventoryItem decode(GameState.SerializableInventoryItem s) {
    InventoryItem i =
        new InventoryItem(
            null,
            s.name,
            s.condition,
            s.rarity,
            java.math.BigDecimal.valueOf(s.price),
            s.itemFloat,
            s.isStattrak,
            s.patternID,
            s.blueGemTier,
            s.basePrice);
    i.collection = s.collection;
    i.createdAt = s.createdAt;
    i.currentOwner = s.currentOwner;
    i.itemId = s.itemId;
    i.history = s.history == null ? new ArrayList<>() : new ArrayList<>(s.history);
    return i;
  }
}
