package blahblah;

import blahblah.hGui.*;
import java.awt.*;
import java.awt.event.*;
import javax.swing.*;

/** Extracted reusable model or widget; behavior retained from the original source. */
public class Achievement {
  String id;
  String name;
  String description;
  double reward;
  boolean isUnlocked;
  String category;
  int progress;
  int requirement;

  public Achievement(
      String id, String name, String description, double reward, String category, int requirement) {
    this.id = id;
    this.name = name;
    this.description = description;
    this.reward = reward;
    this.category = category;
    this.requirement = requirement;
    this.isUnlocked = false;
    this.progress = 0;
  }
}
