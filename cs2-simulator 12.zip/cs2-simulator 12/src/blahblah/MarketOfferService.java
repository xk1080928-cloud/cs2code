package blahblah;

import blahblah.hGui.*;
import java.awt.*;
import java.awt.event.*;
import java.util.ArrayList;
import java.util.Comparator;
import java.util.LinkedHashMap;
import java.util.Map;
import javax.swing.*;

/** Market Offer Service: focused feature implementation. */
final class MarketOfferService {
  private final hGui app;

  MarketOfferService(hGui app) {
    this.app = app;
  }

  java.util.List<MarketplaceOfferAggregate> buildMarketplaceAggregates(
      ArrayList<MarketListing> listings) {
    Map<String, MarketplaceOfferAggregate> grouped = new LinkedHashMap<>();
    for (MarketListing listing : listings) {
      if (listing.quantity < 1) continue;
      String key = listing.marketplaceName != null ? listing.marketplaceName : "Marketplace";
      MarketplaceOfferAggregate aggregate =
          grouped.computeIfAbsent(
              key,
              k -> {
                MarketplaceOfferAggregate offer = new MarketplaceOfferAggregate();
                MarketplaceProfile profile = MarketplaceProfile.byName(key);
                offer.marketplaceName = key;
                offer.marketplaceType =
                    listing.marketplaceType != null ? listing.marketplaceType : profile.type;
                offer.lowestPrice = listing.getPrice();
                offer.rating =
                    listing.marketplaceRating > 0 ? listing.marketplaceRating : profile.rating;
                offer.reviews =
                    listing.marketplaceReviews != null
                        ? listing.marketplaceReviews
                        : profile.reviews;
                offer.promoted = listing.promoted || profile.promoted;
                offer.accent = profile.accent;
                offer.accentAlt = profile.accentAlt;
                return offer;
              });
      aggregate.listings.add(listing);
      aggregate.listingCount += app.exchangeStockService.stockUnits(listing);
      double ask = listing.getPrice();
      if (Double.isFinite(ask) && ask > 0)
        aggregate.lowestPrice =
            Double.isFinite(aggregate.lowestPrice) ? Math.min(aggregate.lowestPrice, ask) : ask;
    }
    java.util.List<MarketplaceOfferAggregate> offers = new ArrayList<>(grouped.values());
    offers.sort((a, b) -> Double.compare(a.lowestPrice, b.lowestPrice));
    return offers;
  }

  JPanel createMarketplaceOfferRow(
      String skinName, String conditionToken, MarketplaceOfferAggregate offer, JFrame parent) {
    JPanel row = new JPanel(new BorderLayout(16, 0));
    row.setBackground(new Color(36, 42, 55));
    row.setBorder(
        BorderFactory.createCompoundBorder(
            BorderFactory.createLineBorder(offer.accent, offer.promoted ? 2 : 1),
            BorderFactory.createEmptyBorder(12, 14, 12, 14)));
    row.setAlignmentX(Component.LEFT_ALIGNMENT);
    row.setPreferredSize(new Dimension(0, 112));
    row.setMaximumSize(new Dimension(Integer.MAX_VALUE, 112));

    JPanel left = new JPanel();
    left.setOpaque(false);
    left.setLayout(new BoxLayout(left, BoxLayout.Y_AXIS));
    left.setPreferredSize(new Dimension(175, 0));
    JLabel marketLabel = new JLabel(offer.marketplaceName);
    marketLabel.setFont(new Font("Arial", Font.BOLD, 18));
    marketLabel.setForeground(Color.WHITE);
    JLabel rating = new JLabel(String.format("%.1f  |  %s", offer.rating, offer.marketplaceType));
    rating.setFont(new Font("Arial", Font.PLAIN, 12));
    rating.setForeground(new Color(170, 180, 200));
    left.add(marketLabel);
    left.add(rating);

    JPanel middle = new JPanel(new GridLayout(1, 2, 18, 0));
    middle.setOpaque(false);
    middle.add(
        app.marketOfferService.createOfferStat(
            "active offers", String.valueOf(offer.listingCount)));
    middle.add(
        app.marketOfferService.createOfferStat(
            "from",
            Double.isFinite(offer.lowestPrice)
                ? "$" + String.format("%.2f", offer.lowestPrice)
                : "Quote unavailable"));

    JButton viewOffer = new JButton("VIEW");
    viewOffer.setFont(new Font("Arial", Font.BOLD, 13));
    viewOffer.setPreferredSize(new Dimension(84, 36));
    viewOffer.setBackground(new Color(70, 104, 239));
    viewOffer.setForeground(Color.BLACK);
    viewOffer.setFocusPainted(false);
    viewOffer.addActionListener(
        e ->
            app.marketOfferService.showMarketplaceOfferWindow(
                skinName, conditionToken, offer, parent));

    row.add(left, BorderLayout.WEST);
    row.add(middle, BorderLayout.CENTER);
    row.add(viewOffer, BorderLayout.EAST);
    return row;
  }

  JPanel createOfferStat(String label, String value) {
    JPanel stat = new JPanel();
    stat.setOpaque(false);
    stat.setLayout(new BoxLayout(stat, BoxLayout.Y_AXIS));
    JLabel top = new JLabel(label);
    top.setFont(new Font("Arial", Font.PLAIN, 12));
    top.setForeground(new Color(150, 160, 185));
    JLabel bottom = new JLabel(value);
    bottom.setFont(new Font("Arial", Font.BOLD, 18));
    bottom.setForeground(Color.WHITE);
    stat.add(top);
    stat.add(bottom);
    return stat;
  }

  void showMarketplaceOfferWindow(
      String skinName, String conditionToken, MarketplaceOfferAggregate offer, JFrame parent) {
    if (app.cs2ShellEnabled) {
      if (parent != null && parent != app) parent.dispose();
      app.exchangeScreens.openExchangeMarketplace(
          MarketplaceProfile.byName(offer.marketplaceName), skinName, null);
      return;
    }
    // Sort listings cheapest-first before dispatching to any custom window
    if (offer.listings != null) {
      offer.listings.sort(Comparator.comparingDouble(l -> l.getPrice()));
    }
    String marketplace = offer.marketplaceName != null ? offer.marketplaceName : "";
    switch (marketplace) {
      case "CS.MONEY":
        app.offerHeroAndSellerScreens.showMarketplaceOfferWindowHero(
            skinName, conditionToken, offer, parent);
        return;
      case "SkinSwap":
        app.offerHeroAndSellerScreens.showMarketplaceOfferWindowSellerDesk(
            skinName, conditionToken, offer, parent);
        return;
      case "DMarket":
        app.offerAnalyticsScreens.showMarketplaceOfferWindowAnalytics(
            skinName, conditionToken, offer, parent);
        return;
      case "LIS-SKINS":
        app.offerAnalyticsScreens.showMarketplaceOfferWindowTicketBoard(
            skinName, conditionToken, offer, parent);
        return;
      case "Skins.com":
        app.offerAnalyticsScreens.showMarketplaceOfferWindowSpotlightStack(
            skinName, conditionToken, offer, parent);
        return;
      case "Skin.Land":
        app.offerManifestScreens.showMarketplaceOfferWindowManifest(
            skinName, conditionToken, offer, parent);
        return;
      case "TradeDock":
        app.offerManifestScreens.showMarketplaceOfferWindowCommandTable(
            skinName, conditionToken, offer, parent);
        return;
      case "VaultDrop":
        app.offerManifestScreens.showMarketplaceOfferWindowShowcase(
            skinName, conditionToken, offer, parent);
        return;
      case "Skinport":
        app.offerGalleryScreens.showMarketplaceOfferWindowCapsule(
            skinName, conditionToken, offer, parent);
        return;
      case "Waxpeer":
        app.offerGalleryScreens.showMarketplaceOfferWindowPriceLadder(
            skinName, conditionToken, offer, parent);
        return;
      case "FloatFlip":
        app.offerGalleryScreens.showMarketplaceOfferWindowPosterWall(
            skinName, conditionToken, offer, parent);
        return;
      case "HaloSkins":
        app.offerGalleryScreens.showMarketplaceOfferWindowConcierge(
            skinName, conditionToken, offer, parent);
        return;
      case "NeonGrid":
        app.offerNeonAndMirageScreens.showMarketplaceOfferWindowNeonGrid(
            skinName, conditionToken, offer, parent);
        return;
      case "MirageX":
        app.offerNeonAndMirageScreens.showMarketplaceOfferWindowMirageRun(
            skinName, conditionToken, offer, parent);
        return;
      case "EmberSkins":
        app.offerEmberAndFrostScreens.showMarketplaceOfferWindowEmberBoard(
            skinName, conditionToken, offer, parent);
        return;
      case "FrostBid":
        app.offerEmberAndFrostScreens.showMarketplaceOfferWindowFrostLane(
            skinName, conditionToken, offer, parent);
        return;
      case "RelayMarket":
        app.offerRelayAndVelvetScreens.showMarketplaceOfferWindowRelayFeed(
            skinName, conditionToken, offer, parent);
        return;
      case "VelvetTrade":
        app.offerRelayAndVelvetScreens.showMarketplaceOfferWindowVelvetGallery(
            skinName, conditionToken, offer, parent);
        return;
      default:
        app.offerAnalyticsScreens.showMarketplaceOfferWindowAnalytics(
            skinName, conditionToken, offer, parent);
        return;
    }
  }

  boolean isDirectMarketplaceOffer(MarketplaceOfferAggregate offer) {
    if (offer == null) return false;
    return "INSTANT".equals(offer.marketplaceType);
  }

  void purchaseMarketplaceListing(
      MarketListing listing, MarketplaceOfferAggregate offer, JFrame parent) {
    if (listing == null) return;
    Runnable refreshAction =
        () ->
            app.marketOfferService.refreshMarketplaceOfferWindowAfterPurchase(
                listing.item.name,
                listing.item.condition,
                offer != null ? offer.marketplaceName : null,
                parent);
    if (app.marketOfferService.isDirectMarketplaceOffer(offer)) {
      app.marketPurchaseService.buyItemNow(listing, parent, refreshAction);
    } else {
      app.marketPurchaseService.startMarketplacePurchase(listing, parent, refreshAction);
    }
  }

  void refreshMarketplaceOfferWindowAfterPurchase(
      String skinName, String condition, String marketplaceName, JFrame parent) {
    if (marketplaceName == null || parent == null) return;
    String normalizedName = app.marketGroupingService.getBaseMarketKey(skinName);
    ArrayList<MarketListing> refreshedListings =
        app.marketGroupingService.getCombinedMarketListings(normalizedName);
    LinkedHashMap<String, ArrayList<MarketListing>> tokenMap =
        app.marketHistoryScreen.buildConditionTokenMap(refreshedListings, normalizedName);
    String selectedToken = null;
    if (condition != null && tokenMap.containsKey(condition)) {
      selectedToken = condition;
    } else {
      for (String token : tokenMap.keySet()) {
        if (token.equals(condition) || token.equals("StatTrak " + condition)) {
          selectedToken = token;
          break;
        }
      }
    }
    if (selectedToken == null && !tokenMap.isEmpty()) {
      selectedToken = tokenMap.keySet().iterator().next();
    }
    ArrayList<MarketListing> tokenListings =
        selectedToken == null ? new ArrayList<>() : tokenMap.get(selectedToken);
    MarketplaceOfferAggregate refreshedOffer = null;
    for (MarketplaceOfferAggregate aggregate :
        app.marketOfferService.buildMarketplaceAggregates(tokenListings)) {
      if (marketplaceName.equals(aggregate.marketplaceName)) {
        refreshedOffer = aggregate;
        break;
      }
    }
    parent.dispose();
    if (refreshedOffer != null && refreshedOffer.listingCount > 0) {
      app.marketOfferService.showMarketplaceOfferWindow(
          normalizedName, selectedToken, refreshedOffer, app);
    }
  }

  String getMarketplaceOfferPreferenceKey(MarketplaceOfferAggregate offer, String skinName) {
    String market =
        offer != null && offer.marketplaceName != null ? offer.marketplaceName : "Marketplace";
    String cleanSkinName = skinName != null ? skinName : "";
    if (cleanSkinName.contains("(Blue Gem")) {
      cleanSkinName = cleanSkinName.substring(0, cleanSkinName.indexOf("(Blue Gem")).trim();
    }
    return market + "::" + app.marketGroupingService.getMarketplaceBrowseKey(cleanSkinName);
  }

  JPanel createMarketplaceFilterBar(
      MarketplaceOfferAggregate offer,
      String skinName,
      String conditionToken,
      JFrame frame,
      JFrame parent) {
    JPanel bar = new JPanel(new FlowLayout(FlowLayout.LEFT, 10, 8));
    bar.setBackground(new Color(18, 22, 31));
    bar.setBorder(
        BorderFactory.createCompoundBorder(
            BorderFactory.createMatteBorder(1, 0, 0, 0, offer.accent),
            BorderFactory.createEmptyBorder(2, 12, 2, 12)));

    JLabel sortLabel = new JLabel("Sort");
    sortLabel.setFont(new Font("Arial", Font.BOLD, 11));
    sortLabel.setForeground(new Color(210, 220, 235));
    bar.add(sortLabel);

    JComboBox<String> sortBox =
        new JComboBox<>(
            new String[] {
              "Price: Low to High",
              "Price: High to Low",
              "Float: Low to High",
              "Float: High to Low",
              "Pattern ID: Low to High",
              "Pattern ID: High to Low"
            });
    app.uiWidgets.styleComboBox(sortBox);
    String key = app.marketOfferService.getMarketplaceOfferPreferenceKey(offer, skinName);
    sortBox.setSelectedItem(app.marketplaceSortModes.getOrDefault(key, "Price: Low to High"));
    bar.add(sortBox);

    JLabel patternLabel = new JLabel("Pattern ID");
    patternLabel.setFont(new Font("Arial", Font.BOLD, 11));
    patternLabel.setForeground(new Color(210, 220, 235));
    bar.add(patternLabel);

    JTextField patternField = app.uiWidgets.createDarkTextField(7);
    patternField.setText(app.marketplacePatternFilters.getOrDefault(key, ""));
    patternField.setToolTipText("Enter an exact pattern ID, or leave blank to show all patterns.");
    bar.add(patternField);

    JButton applyBtn = new JButton("Apply");
    app.uiWidgets.styleButton(applyBtn, new Color(42, 82, 72), Color.WHITE, offer.accent);
    applyBtn.addActionListener(
        e -> {
          app.marketplaceSortModes.put(key, (String) sortBox.getSelectedItem());
          String patternText = patternField.getText() != null ? patternField.getText().trim() : "";
          if (patternText.isEmpty()) app.marketplacePatternFilters.remove(key);
          else app.marketplacePatternFilters.put(key, patternText);
          frame.dispose();
          app.marketOfferService.showMarketplaceOfferWindow(
              skinName, conditionToken, offer, parent);
        });
    bar.add(applyBtn);

    JButton clearBtn = new JButton("Clear");
    app.uiWidgets.styleButton(
        clearBtn, new Color(55, 48, 58), Color.WHITE, new Color(120, 130, 150));
    clearBtn.addActionListener(
        e -> {
          app.marketplacePatternFilters.remove(key);
          app.marketplaceSortModes.put(key, "Price: Low to High");
          frame.dispose();
          app.marketOfferService.showMarketplaceOfferWindow(
              skinName, conditionToken, offer, parent);
        });
    bar.add(clearBtn);

    JLabel hint = new JLabel("filters apply to this marketplace view");
    hint.setFont(new Font("Arial", Font.PLAIN, 11));
    hint.setForeground(new Color(135, 145, 165));
    bar.add(hint);
    return bar;
  }

  ArrayList<MarketListing> getSortedOfferListings(MarketplaceOfferAggregate offer) {
    ArrayList<MarketListing> sorted = new ArrayList<>(offer.listings);
    String key =
        app.marketOfferService.getMarketplaceOfferPreferenceKey(
            offer, sorted.isEmpty() ? "" : sorted.get(0).item.name);
    String patternFilter = app.marketplacePatternFilters.getOrDefault(key, "").trim();
    if (!patternFilter.isEmpty()) {
      try {
        int pattern = Integer.parseInt(patternFilter);
        sorted.removeIf(l -> l.item.patternID != pattern);
      } catch (NumberFormatException ex) {
        app.marketplacePatternFilters.remove(key);
      }
    }
    String sortMode = app.marketplaceSortModes.getOrDefault(key, "Price: Low to High");
    switch (sortMode) {
      case "Price: High to Low":
        sorted.sort((a, b) -> Double.compare(b.getPrice(), a.getPrice()));
        break;
      case "Float: Low to High":
        sorted.sort(Comparator.comparingDouble(l -> l.item.itemFloat));
        break;
      case "Float: High to Low":
        sorted.sort((a, b) -> Double.compare(b.item.itemFloat, a.item.itemFloat));
        break;
      case "Pattern ID: Low to High":
        sorted.sort(Comparator.comparingInt(l -> l.item.patternID));
        break;
      case "Pattern ID: High to Low":
        sorted.sort((a, b) -> Integer.compare(b.item.patternID, a.item.patternID));
        break;
      default:
        sorted.sort(Comparator.comparingDouble(l -> l.getPrice()));
        break;
    }
    return sorted;
  }

  String getBlueGemMarketBadge(MarketListing listing) {
    if (listing == null || listing.item == null || listing.item.blueGemTier == null) return "";
    return "  |  " + listing.item.blueGemTier;
  }

  String formatMarketPatternText(MarketListing listing) {
    if (listing == null || listing.item == null) return "Pattern: n/a";
    return "#" + listing.item.patternID + app.marketOfferService.getBlueGemMarketBadge(listing);
  }

  Color getMarketPatternColor(MarketListing listing, Color defaultColor) {
    if (listing != null && listing.item != null && listing.item.blueGemTier != null) {
      return new Color(90, 190, 255);
    }
    return defaultColor;
  }
}
