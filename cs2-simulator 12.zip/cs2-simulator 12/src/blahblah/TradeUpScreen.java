package blahblah;

import blahblah.hGui.*;
import java.awt.*;
import java.awt.event.*;
import java.math.BigDecimal;
import java.math.RoundingMode;
import java.util.ArrayList;
import java.util.Comparator;
import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import javax.swing.*;

/** Trade Up Screen: focused feature implementation. */
final class TradeUpScreen {
  private final hGui app;

  TradeUpScreen(hGui app) {
    this.app = app;
  }

  void refreshTradeUpTab() {
    if (app.cs2ShellEnabled) {
      app.cs2EquipmentScreens.refreshCs2TradeUp();
      return;
    }
    app.tradeUpSelection.removeIf(
        item ->
            !app.inventoryList.contains(item)
                || !app.goldTradeUpService.isTradeUpEligibleForMode(item));
    if (app.inventoryScreen.inventoryContentsUnchanged(app.tradeUpTabPanel)) return;
    List<Object> savedControls = app.inventoryScreen.captureViewControls(app.tradeUpTabPanel);
    Point savedPosition = app.inventoryScreen.captureViewPosition(app.tradeUpTabPanel);

    javax.swing.Timer existingSelTimer =
        (javax.swing.Timer) app.tradeUpTabPanel.getClientProperty("selTimer");
    if (existingSelTimer != null) {
      existingSelTimer.stop();
    }
    app.inventoryScreen.releaseInventoryGridCaches(app.tradeUpTabPanel);
    app.tradeUpTabPanel.removeAll();

    app.tradeUpTabPanel.setBackground(Theme.BG_DARK);

    JPanel controlPanel = new JPanel(new GridLayout(2, 1));
    controlPanel.setBackground(Theme.BG_PANEL);
    controlPanel.setBorder(BorderFactory.createMatteBorder(0, 0, 1, 0, Theme.BORDER));

    JPanel searchPanel = app.uiWidgets.createControlRow();
    JLabel searchLabel = app.uiWidgets.createControlLabel("Search:", true);
    JComboBox<String> searchField = app.searchControls.createSearchFieldWithHistory(20);
    searchPanel.add(searchLabel);
    searchPanel.add(searchField);
    JPanel filterPanel = app.uiWidgets.createControlRow();
    JLabel sortRarityLabel = app.uiWidgets.createControlLabel("Rarity:", false);
    JComboBox<String> raritySortBox =
        app.uiWidgets.createComboBox(
            new String[] {
              "Default", "Consumer", "Industrial", "Milspec", "Restricted", "Classified", "Covert"
            });
    JLabel sortFloatLabel2 = app.uiWidgets.createControlLabel("Float:", false);
    JComboBox<String> floatSortBox =
        app.uiWidgets.createComboBox(new String[] {"Ascending", "Descending"});
    filterPanel.add(sortRarityLabel);
    filterPanel.add(raritySortBox);
    filterPanel.add(sortFloatLabel2);
    filterPanel.add(floatSortBox);

    controlPanel.add(searchPanel);
    controlPanel.add(filterPanel);
    app.developerTools.styleDeveloperPanel(
        controlPanel); // Avoid native white/misaligned combo rendering on macOS.
    app.tradeUpTabPanel.add(controlPanel, BorderLayout.NORTH);

    ArrayList<InventoryItem> selectedItems = app.tradeUpSelection;
    JLabel selectedLabel =
        new JLabel(
            app.goldTradeUpMode
                ? "Gold: select 5 case/Dead Hand Coverts"
                : "Standard: select 10 skins",
            SwingConstants.CENTER);

    selectedLabel.setFont(Theme.CONSOLE_BOLD_13);
    selectedLabel.setForeground(Theme.ACCENT_CT);

    JPanel grid = new JPanel(new GridLayout(0, 1, 8, 8));
    grid.setBackground(Theme.BG_DARK);
    grid.setBorder(BorderFactory.createEmptyBorder(8, 8, 8, 8));
    JScrollPane scroll = new JScrollPane(grid);
    scroll.setHorizontalScrollBarPolicy(ScrollPaneConstants.HORIZONTAL_SCROLLBAR_NEVER);
    scroll.setBackground(Theme.BG_DARK);
    scroll.getViewport().setBackground(Theme.BG_DARK);
    app.tradeCards.optimizeScrollPane(scroll);
    scroll
        .getViewport()
        .addComponentListener(
            new java.awt.event.ComponentAdapter() {
              @Override
              public void componentResized(java.awt.event.ComponentEvent e) {
                app.inventoryCards.updateInventoryGridCardWidths(grid, scroll);
              }
            });

    JPanel bottomPanel = new JPanel(new BorderLayout(8, 0));
    bottomPanel.setBackground(Theme.BG_PANEL);
    bottomPanel.setBorder(
        BorderFactory.createCompoundBorder(
            BorderFactory.createMatteBorder(1, 0, 0, 0, Theme.BORDER),
            BorderFactory.createEmptyBorder(8, 12, 8, 12)));

    JPanel leftBottom = new JPanel(new GridLayout(2, 1, 0, 2));
    leftBottom.setBackground(Theme.BG_PANEL);
    leftBottom.add(selectedLabel);
    JLabel totalPriceLbl = new JLabel("Total value: $0.00", SwingConstants.LEFT);
    totalPriceLbl.setFont(Theme.CONSOLE_PLAIN_12);
    totalPriceLbl.setForeground(Theme.ACCENT_CT);
    leftBottom.add(totalPriceLbl);

    JPanel rightBottom = new JPanel(new FlowLayout(FlowLayout.RIGHT, 8, 0));
    rightBottom.setBackground(Theme.BG_PANEL);
    JButton outcomesBtn = new JButton("VIEW OUTCOMES");
    app.uiWidgets.styleButton(
        outcomesBtn, new Color(70, 100, 160), Theme.BG_DARK, new Color(150, 180, 255));
    outcomesBtn.setFont(Theme.CONSOLE_BOLD_12);
    outcomesBtn.setEnabled(false);
    JButton tradeUpBtn = new JButton(app.goldTradeUpMode ? "GOLD TRADE UP (5)" : "TRADE UP (10)");
    app.uiWidgets.styleButton(tradeUpBtn, Theme.ACCENT_T, Theme.BG_DARK, Theme.ACCENT_T);
    tradeUpBtn.setFont(Theme.CONSOLE_BOLD_14);
    tradeUpBtn.setEnabled(false);
    rightBottom.add(outcomesBtn);
    rightBottom.add(tradeUpBtn);

    bottomPanel.add(leftBottom, BorderLayout.WEST);
    bottomPanel.add(rightBottom, BorderLayout.EAST);

    app.tradeUpTabPanel.add(scroll, BorderLayout.CENTER);
    app.tradeUpTabPanel.add(bottomPanel, BorderLayout.SOUTH);

    grid.putClientProperty("tradeUpSelection", selectedItems);
    Runnable rebuildGrid =
        () -> {
          String search = app.searchControls.getSearchText(searchField);
          String rarityFilter = (String) raritySortBox.getSelectedItem();
          String floatSort = (String) floatSortBox.getSelectedItem();
          Map<String, Boolean> eligibility = new HashMap<>();
          List<InventoryItem> filtered = new ArrayList<>();
          for (InventoryItem item : app.inventoryList) {
            if (!search.isEmpty() && !item.name.toLowerCase(java.util.Locale.ROOT).contains(search))
              continue;
            if (!"Default".equals(rarityFilter) && !item.rarity.contains(rarityFilter)) continue;
            String key =
                item.name + "|" + item.rarity + "|" + item.isStattrak + "|" + item.collection;
            if (eligibility.computeIfAbsent(
                key, k -> app.goldTradeUpService.isTradeUpEligibleForMode(item)))
              filtered.add(item);
          }
          filtered.sort(
              "Ascending".equals(floatSort)
                  ? Comparator.comparingDouble(it -> it.itemFloat)
                  : Comparator.comparingDouble((InventoryItem it) -> it.itemFloat).reversed());
          grid.putClientProperty("tradeUpFilteredItems", filtered);
          grid.putClientProperty("selectionLock", null);
          grid.putClientProperty(
              "pageRenderer",
              (java.util.function.Function<InventoryItem, JPanel>)
                  (item ->
                      app.tradeUpCards.createTradeUpCardFast(
                          item, item.getThumb110(), selectedItems, grid)));
          grid.putClientProperty("pageScroll", scroll);
          app.inventoryScreen.updateTradeUpSelectionView(grid);
        };
    grid.putClientProperty("rebuildGrid", rebuildGrid);
    grid.putClientProperty(
        "selectionChanged", (Runnable) () -> app.inventoryScreen.updateTradeUpSelectionView(grid));

    app.inventoryScreen.restoreViewControls(app.tradeUpTabPanel, savedControls);
    javax.swing.Timer searchTimer =
        app.searchControls.createSearchHistoryTimer(searchField, rebuildGrid);
    app.searchControls.installSearchHistoryHandlers(searchField, searchTimer, rebuildGrid);
    raritySortBox.addActionListener(e -> rebuildGrid.run());
    floatSortBox.addActionListener(e -> rebuildGrid.run());

    tradeUpBtn.addActionListener(
        e -> app.tradeUpScreen.executeTradeUp(selectedItems, app.tradeUpTabPanel));
    outcomesBtn.addActionListener(e -> app.tradeUpScreen.showTradeUpOutcomes(selectedItems));

    Runnable updateSummary =
        () -> {
          app.goldTradeUpMode =
              !selectedItems.isEmpty() && selectedItems.get(0).rarity.contains("Covert");
          tradeUpBtn.setText(app.goldTradeUpMode ? "GOLD TRADE UP (5)" : "TRADE UP (10)");
          selectedLabel.setText(
              (app.goldTradeUpMode ? "Gold: " : "Standard: ")
                  + selectedItems.size()
                  + "/"
                  + (app.goldTradeUpMode ? 5 : 10)
                  + " selected");
          double totalVal = selectedItems.stream().mapToDouble(it -> it.price.doubleValue()).sum();
          totalPriceLbl.setText(String.format("Total value: $%.2f", totalVal));
          boolean ready = selectedItems.size() == (app.goldTradeUpMode ? 5 : 10);
          tradeUpBtn.setEnabled(ready);
          outcomesBtn.setEnabled(selectedItems.size() > 0);
        };
    grid.putClientProperty("selectionSummaryChanged", updateSummary);
    javax.swing.Timer selTimer = new javax.swing.Timer(200, e -> updateSummary.run());
    selTimer.start();
    app.tradeUpTabPanel.putClientProperty("selTimer", selTimer);

    SwingUtilities.invokeLater(
        () -> {
          rebuildGrid.run();
          app.inventoryScreen.restoreViewPosition(scroll, savedPosition);
        });
    app.tradeUpTabPanel.revalidate();
    app.tradeUpTabPanel.repaint();
  }

  Dimension getTradeUpOutcomesWindowSize(Rectangle usable) {
    return new Dimension(
        Math.min(1420, Math.max(1, usable.width - 32)),
        Math.min(860, Math.max(1, usable.height - 48)));
  }

  JLabel createTradeUpSkinArtwork(String skinName, Image fallback, int width, int height) {
    return app.tradeUpScreen.createTradeUpSkinArtwork(skinName, null, fallback, width, height);
  }

  JLabel createTradeUpSkinArtwork(
      String skinName, String condition, Image fallback, int width, int height) {
    String imageName =
        skinName
            .replaceFirst("(?i)^StatTrak(?:™)?\\s+", "")
            .replaceAll("\\s*\\(Blue Gem [^)]+\\)$", "")
            .trim();
    JLabel art = new JLabel("", SwingConstants.CENTER);
    art.setName("tradeUpSkinArtwork");
    art.putClientProperty("tradeUpSkinName", imageName);
    art.setPreferredSize(new Dimension(width, height));
    art.setMinimumSize(new Dimension(width, height));
    art.setHorizontalTextPosition(SwingConstants.CENTER);
    art.setVerticalTextPosition(SwingConstants.BOTTOM);
    art.getAccessibleContext().setAccessibleName("Skin artwork: " + skinName);
    Image initial =
        fallback == null ? app.containerBrowserScreen.createItemPlaceholderImage() : fallback;
    art.setIcon(app.marketItemCards.createContainedImageLabel(initial, width, height).getIcon());
    art.putClientProperty("skinArtworkPlaceholder", fallback == null);
    // Uses downloaded-cache/online PNGs, never bundled skin files.
    // Pending labels are updated independently, without touching activeResultImageLabel.
    app.artworkService.getSkinImageFromName(imageName, condition, art, width, height);
    return art;
  }

  JPanel buildTradeUpResultPanel(InventoryItem item, Runnable closeAction) {
    return app.itemRevealService.panel(item, closeAction);
  }

  void showTradeUpResult(InventoryItem item) {
    app.itemRevealService.tradeUp(item);
  }

  Component findNamedComponent(Component root, String name) {
    if (name.equals(root.getName())) return root;
    if (root instanceof Container)
      for (Component child : ((Container) root).getComponents()) {
        Component found = app.tradeUpScreen.findNamedComponent(child, name);
        if (found != null) return found;
      }
    return null;
  }

  void showTradeUpOutcomes(ArrayList<InventoryItem> selectedItems) {
    JPanel contents;
    try {
      contents = app.tradeUpScreen.buildTradeUpOutcomesPanel(selectedItems);
    } catch (IllegalArgumentException ex) {
      JOptionPane.showMessageDialog(app, ex.getMessage());
      return;
    }
    if (contents == null) return;
    JFrame frame = new JFrame("Trade-Up Outcomes");
    frame.setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
    frame.setSize(
        app.tradeUpScreen.getTradeUpOutcomesWindowSize(
            GraphicsEnvironment.getLocalGraphicsEnvironment().getMaximumWindowBounds()));
    frame.setLocationRelativeTo(app);
    frame.setContentPane(contents);
    frame.setVisible(true);
  }

  JPanel buildTradeUpOutcomesPanel(ArrayList<InventoryItem> selectedItems) {
    if (selectedItems.isEmpty()) return null;
    app.goldTradeUpService.validateTradeUpInputs(selectedItems, false);
    boolean gold = selectedItems.get(0).rarity.contains("Covert");
    String baseRarity = selectedItems.get(0).rarity.replace("StatTrak ", "");
    boolean isStatTrakInput = selectedItems.get(0).isStattrak;

    String newRarity;
    if (baseRarity.equals("Consumer")) newRarity = "Industrial";
    else if (baseRarity.equals("Industrial")) newRarity = "Milspec";
    else if (baseRarity.equals("Milspec")) newRarity = "Restricted";
    else if (baseRarity.equals("Restricted")) newRarity = "Classified";
    else if (baseRarity.equals("Classified")) newRarity = "Covert";
    else if (gold) newRarity = "Gold";
    else {
      throw new IllegalArgumentException("No outcomes for rarity: " + baseRarity);
    }

    Map<String, Double> outcomeOdds = new LinkedHashMap<>();
    if (gold) outcomeOdds.putAll(app.goldTradeUpService.getGoldTradeUpOdds(selectedItems));
    else
      outcomeOdds.putAll(
          app.collectionService.resolveTradeUpOutcomeOdds(selectedItems, baseRarity));
    if (outcomeOdds.isEmpty()) throw new IllegalArgumentException("No outcomes found.");
    String[] names = outcomeOdds.keySet().toArray(new String[0]);
    Map<String, Map<String, Double>> goldSourceWeights = new LinkedHashMap<>();
    if (gold)
      for (InventoryItem input : selectedItems) {
        CaseType ct = app.goldTradeUpService.getGoldTradeUpSource(input);
        String sourceCollection = app.collectionService.getCatalogCollectionName(ct);
        for (Map.Entry<String, Double> e :
            app.goldTradeUpService.getCaseGoldOutcomeOdds(ct).entrySet())
          goldSourceWeights
              .computeIfAbsent(e.getKey(), k -> new LinkedHashMap<>())
              .merge(sourceCollection, e.getValue() / selectedItems.size(), Double::sum);
      }

    double totalNormFloat = 0.0;
    for (InventoryItem item : selectedItems) {
      FloatRange fr = app.catalogParsingService.findFloatRange(item.name);
      double iMin = (fr != null && fr.min != null) ? fr.min : 0.0;
      double iMax = (fr != null && fr.max != null) ? fr.max : 1.0;
      totalNormFloat += (item.itemFloat - iMin) / Math.max(0.0001, iMax - iMin);
    }
    double avgNorm = totalNormFloat / selectedItems.size();

    double inputTotal = selectedItems.stream().mapToDouble(it -> it.price.doubleValue()).sum();
    double marketMulti = (app.marketPriceMultipliers.getOrDefault(newRarity, 1.0));
    double stMult = isStatTrakInput ? 2.0 : 1.0;

    double[] estPrices = new double[names.length];
    double[] estFloats = new double[names.length];
    String[] estConditions = new String[names.length];
    double[] odds = new double[names.length];

    for (int idx = 0; idx < names.length; idx++) {
      String sn = names[idx];
      odds[idx] = outcomeOdds.get(sn);
      FloatRange fr = app.catalogParsingService.findFloatRange(sn);
      double oMin = (fr != null && fr.min != null) ? fr.min : 0.0;
      double oMax = (fr != null && fr.max != null) ? fr.max : 1.0;
      double pFloat = Math.max(oMin, Math.min(oMax, oMin + avgNorm * (oMax - oMin)));
      if (gold) pFloat = app.goldTradeUpService.getGoldTradeUpOutputFloat(selectedItems, sn);
      estFloats[idx] = pFloat;
      String cond;
      if (pFloat < 0.07) cond = "Factory New";
      else if (pFloat <= 0.15) cond = "Minimal Wear";
      else if (pFloat <= 0.38) cond = "Field-Tested";
      else if (pFloat <= 0.45) cond = "Well-Worn";
      else cond = "Battle-Scarred";
      if (gold) cond = app.floatRules.getConditionForFloat(sn, pFloat);
      estConditions[idx] = cond;
      double cMult = app.priceModifiers.getConditionPriceMultiplier(sn, cond);
      estPrices[idx] = app.itemPriceService.getBasePrice(sn) * cMult * marketMulti * stMult;
      if (gold) {
        estPrices[idx] = 0;
        for (Map.Entry<String, Double> source : goldSourceWeights.get(sn).entrySet())
          estPrices[idx] +=
              app.goldTradeUpService.getGoldTradeUpOutputPrice(
                      sn, cond, isStatTrakInput, source.getKey())
                  * source.getValue()
                  / outcomeOdds.get(sn);
      }
    }

    java.util.List<Integer> order = new java.util.ArrayList<>();
    for (int i = 0; i < names.length; i++) order.add(i);
    order.sort((a, b) -> Double.compare(estPrices[b], estPrices[a]));

    double totalEV = 0;
    double profitOdds = 0;
    for (int idx = 0; idx < names.length; idx++) {
      totalEV += estPrices[idx] * odds[idx];
      if (estPrices[idx] > inputTotal) profitOdds += odds[idx];
    }
    double avgReturn = totalEV / inputTotal * 100.0;
    boolean profitable = avgReturn >= 100.0;

    JPanel frame = new JPanel(new BorderLayout());
    frame.setBackground(new Color(20, 20, 28));

    JPanel headerPanel = new JPanel(new GridLayout(0, 1, 0, 2));
    headerPanel.setBackground(new Color(20, 20, 28));
    headerPanel.setBorder(BorderFactory.createEmptyBorder(12, 12, 8, 12));
    JLabel returnLbl =
        new JLabel(String.format("Expected return: %.1f%%", avgReturn), SwingConstants.CENTER);
    returnLbl.setFont(new Font("Consolas", Font.BOLD, 15));
    returnLbl.setForeground(profitable ? new Color(60, 220, 60) : new Color(220, 60, 60));
    JLabel oddsLbl =
        new JLabel(
            String.format("Odds to profit: %.2f%%", profitOdds * 100), SwingConstants.CENTER);
    oddsLbl.setName("tradeUpProfitOdds");
    oddsLbl.putClientProperty("profitProbability", profitOdds);
    oddsLbl.setFont(Theme.CONSOLE_BOLD_16);
    oddsLbl.setForeground(Theme.ACCENT_CT);
    JLabel valueLbl =
        new JLabel(
            String.format("Input cost: $%.2f  |  Average outcome: $%.2f", inputTotal, totalEV),
            SwingConstants.CENTER);
    valueLbl.setForeground(Theme.TEXT_DIM);
    valueLbl.setFont(Theme.CONSOLE_PLAIN_12);
    headerPanel.add(returnLbl);
    headerPanel.add(oddsLbl);
    headerPanel.add(valueLbl);

    frame.add(headerPanel, BorderLayout.NORTH);

    JPanel grid = new JPanel(new GridLayout(0, 5, 10, 10));
    grid.setName("tradeUpOutcomesGrid");
    grid.setBackground(new Color(20, 20, 28));
    grid.setBorder(BorderFactory.createEmptyBorder(8, 12, 12, 12));

    for (int idx : order) {
      String skinName = names[idx];
      double estPrice = estPrices[idx];
      double estFloat = estFloats[idx];
      String cond = estConditions[idx];
      double chance = odds[idx] * 100;
      boolean isProfit = estPrice > inputTotal;
      String colName = gold ? null : app.collectionService.getCollectionName(skinName);

      JPanel card = new JPanel(new BorderLayout(4, 2));
      card.setName("tradeUpOutcomeCard");
      card.putClientProperty("tradeUpOutcomeSkin", skinName);
      card.setPreferredSize(new Dimension(240, 322));
      card.setBackground(isProfit ? new Color(20, 45, 20) : new Color(45, 20, 20));
      card.setBorder(
          BorderFactory.createCompoundBorder(
              BorderFactory.createLineBorder(
                  isProfit ? new Color(60, 180, 60) : new Color(180, 60, 60), 2),
              BorderFactory.createEmptyBorder(8, 8, 8, 8)));

      JLabel nameLbl =
          new JLabel(
              "<html><div style='width:152px;text-align:center;'>"
                  + app.marketItemCards.escapeHtml(skinName).replace("|", "<br>")
                  + "</div></html>",
              SwingConstants.CENTER);
      nameLbl.setFont(new Font("Consolas", Font.BOLD, 12));
      nameLbl.setForeground(Color.WHITE);

      JLabel priceLbl =
          new JLabel(String.format("~$%.2f (%s)", estPrice, cond), SwingConstants.CENTER);
      priceLbl.setFont(new Font("Consolas", Font.PLAIN, 10));
      priceLbl.setForeground(isProfit ? new Color(100, 220, 100) : new Color(220, 100, 100));

      JLabel floatLbl = new JLabel(String.format("Float: %.6f", estFloat), SwingConstants.CENTER);
      floatLbl.setFont(new Font("Consolas", Font.PLAIN, 9));
      floatLbl.setForeground(Theme.ACCENT_CT);

      JLabel chanceLbl =
          new JLabel(
              String.format(gold ? "%.6f%% chance" : "%.1f%% chance", chance),
              SwingConstants.CENTER);
      chanceLbl.setFont(new Font("Consolas", Font.PLAIN, 9));
      chanceLbl.setForeground(new Color(160, 160, 180));

      JLabel profitLbl =
          new JLabel(
              isProfit
                  ? String.format("+$%.2f PROFIT", estPrice - inputTotal)
                  : String.format("-$%.2f LOSS", inputTotal - estPrice),
              SwingConstants.CENTER);
      profitLbl.setFont(new Font("Consolas", Font.BOLD, 10));
      profitLbl.setForeground(isProfit ? new Color(80, 220, 80) : new Color(220, 80, 80));

      JLabel colLbl = new JLabel(colName != null ? colName : "", SwingConstants.CENTER);
      colLbl.setFont(new Font("Consolas", Font.ITALIC, 8));
      colLbl.setForeground(new Color(170, 130, 255));

      JPanel text = new JPanel();
      text.setLayout(new BoxLayout(text, BoxLayout.Y_AXIS));
      text.setOpaque(false);
      JLabel[] rows = {nameLbl, priceLbl, floatLbl, chanceLbl, profitLbl, colLbl};
      int[] heights = {44, 22, 18, 20, 20, 28};
      for (int row = 0; row < rows.length; row++) {
        rows[row].setAlignmentX(Component.CENTER_ALIGNMENT);
        rows[row].setPreferredSize(new Dimension(210, heights[row]));
        rows[row].setMaximumSize(new Dimension(Short.MAX_VALUE, heights[row]));
        text.add(rows[row]);
      }
      JLabel artwork = app.tradeUpScreen.createTradeUpSkinArtwork(skinName, cond, null, 214, 140);
      card.add(artwork, BorderLayout.CENTER);
      card.add(text, BorderLayout.SOUTH);
      grid.add(card);
    }

    JScrollPane scroll = new JScrollPane(grid);
    scroll.getViewport().setBackground(new Color(20, 20, 28));
    scroll.setBorder(null);
    scroll.getVerticalScrollBar().setUnitIncrement(24);
    scroll.setHorizontalScrollBarPolicy(ScrollPaneConstants.HORIZONTAL_SCROLLBAR_AS_NEEDED);
    frame.add(scroll, BorderLayout.CENTER);

    JPanel legend = new JPanel(new FlowLayout(FlowLayout.CENTER, 20, 6));
    legend.setBackground(new Color(25, 25, 33));
    JLabel g = new JLabel("[*] Profit");
    g.setForeground(new Color(80, 200, 80));
    g.setFont(new Font("Consolas", Font.BOLD, 11));
    JLabel r = new JLabel("[*] Loss");
    r.setForeground(new Color(200, 80, 80));
    r.setFont(new Font("Consolas", Font.BOLD, 11));
    legend.add(g);
    legend.add(r);
    frame.add(legend, BorderLayout.SOUTH);
    return frame;
  }

  void executeTradeUp(ArrayList<InventoryItem> selectedItems, JPanel parentPanel) {
    if (app.itemRevealService.tradeUpPending || app.itemRevealService.showing) return;
    try {
      app.goldTradeUpService.validateTradeUpInputs(selectedItems, true);
    } catch (IllegalArgumentException ex) {
      JOptionPane.showMessageDialog(app, ex.getMessage());
      return;
    }
    if (selectedItems.get(0).rarity.contains("Covert")) {
      InventoryItem result;
      try {
        result = app.goldTradeUpService.performGoldTradeUp(selectedItems);
      } catch (IllegalArgumentException ex) {
        JOptionPane.showMessageDialog(app, ex.getMessage());
        return;
      }
      selectedItems.clear();
      app.tradeUpScreen.showTradeUpResult(result);
      app.activitySimulationService.addRecentUnboxedSkin(
          result, "YOU", app.playerAvatar, "Gold Trade Up");
      app.missionProgress.tradeUps++;
      app.missionService.checkTradeUpAchievements(result.rarity.replace("StatTrak ", ""));
      app.missionService.checkInventoryCollectionAchievements();
      app.missionService.checkMissionProgress();
      app.caseRollService.writeStats();
      app.repaint();
      app.tradeUpScreen.refreshTradeUpTab();
      return;
    }
    if (selectedItems.size() != 10) {
      JOptionPane.showMessageDialog(app, "Please select exactly 10 skins!");
      return;
    }
    String baseRarity = selectedItems.get(0).rarity.replace("StatTrak ", "");
    for (InventoryItem item : selectedItems) {
      if (!item.rarity.replace("StatTrak ", "").equals(baseRarity)) {
        JOptionPane.showMessageDialog(app, "All selected skins must be of the same rarity!");
        return;
      }
    }

    String newRarity;
    if (baseRarity.equals("Consumer")) {
      newRarity = "Industrial";
    } else if (baseRarity.equals("Industrial")) {
      newRarity = "Milspec";
    } else if (baseRarity.equals("Milspec")) {
      newRarity = "Restricted";
      app.totMil = Math.max(0, app.totMil - 10);
      app.totRes++;
    } else if (baseRarity.equals("Restricted")) {
      newRarity = "Classified";
      app.totRes = Math.max(0, app.totRes - 10);
      app.totClass++;
    } else if (baseRarity.equals("Classified")) {
      newRarity = "Covert";
      app.totClass = Math.max(0, app.totClass - 10);
      app.totCov++;
    } else {
      JOptionPane.showMessageDialog(app, "Cannot trade up: " + baseRarity);
      return;
    }

    Map<String, Double> outcomeOdds =
        app.collectionService.resolveTradeUpOutcomeOdds(selectedItems, baseRarity);
    if (outcomeOdds.isEmpty()) {
      JOptionPane.showMessageDialog(app, "No outcomes found.");
      return;
    }

    java.util.List<InventoryItem> consumedInputs = new java.util.ArrayList<>(selectedItems);
    double selectedValue = 0;
    for (InventoryItem item : selectedItems) selectedValue += item.price.doubleValue();
    app.inventoryList.removeAll(selectedItems);
    app.inventoryValue = Math.max(0.0, app.inventoryValue - selectedValue);
    app.caseRollService.writeStats();
    app.repaint();

    String skinName = app.goldTradeUpService.sampleTradeUpOdds(outcomeOdds);

    Image skin = app.artworkService.getSkinImageFromName(skinName);
    if (skin == null) skin = app.containerBrowserScreen.createItemPlaceholderImage();

    FloatRange outputFR = app.catalogParsingService.findFloatRange(skinName);
    double outputMin = (outputFR != null && outputFR.min != null) ? outputFR.min : 0.0;
    double outputMax = (outputFR != null && outputFR.max != null) ? outputFR.max : 1.0;
    double totalNorm = 0.0;
    for (InventoryItem item : selectedItems) {
      FloatRange fr = app.catalogParsingService.findFloatRange(item.name);
      double iMin = (fr != null && fr.min != null) ? fr.min : 0.0;
      double iMax = (fr != null && fr.max != null) ? fr.max : 1.0;
      totalNorm += (item.itemFloat - iMin) / Math.max(0.0001, iMax - iMin);
    }
    double avgNorm = totalNorm / selectedItems.size();
    double outputFloat =
        Math.max(outputMin, Math.min(outputMax, outputMin + avgNorm * (outputMax - outputMin)));

    String condition;
    if (outputFloat < 0.07) condition = "Factory New";
    else if (outputFloat <= 0.15) condition = "Minimal Wear";
    else if (outputFloat <= 0.38) condition = "Field-Tested";
    else if (outputFloat <= 0.45) condition = "Well-Worn";
    else condition = "Battle-Scarred";

    double mMult = (app.marketPriceMultipliers.getOrDefault(newRarity, 1.0));
    double bp = app.itemPriceService.getBasePrice(skinName);
    bp *= app.priceModifiers.getConditionPriceMultiplier(skinName, condition);
    bp *= mMult;
    boolean isST =
        app.itemMetadataService.supportsStatTrak(skinName)
            && selectedItems.stream().allMatch(it -> it.isStattrak);
    if (isST) bp *= 2.0;
    String rarityLabel = isST ? "StatTrak " + newRarity : newRarity;

    Image wearImage = app.artworkService.getSkinImageFromName(skinName, condition);
    if (wearImage != null) skin = wearImage;
    int skinWidth = skin.getWidth(null);
    int skinHeight = skin.getHeight(null);
    Image scaledSkin = skin;
    if (skinWidth > 0 && skinHeight > 0) {
      double scl = Math.min(130.0 / skinWidth, 88.0 / skinHeight);
      scaledSkin = HighQualityImages.fit(skin, (int) (skinWidth * scl), (int) (skinHeight * scl));
    }

    int pid = hGui.random.nextInt(1000);
    String bgTier = app.itemPriceService.getBlueGemTier(skinName, pid);
    if (bgTier != null) {
      skinName = skinName + " (" + bgTier + ")";
      bp =
          app.itemPriceService.applyBlueGemMultiplier(
              skinName.replace(" (" + bgTier + ")", ""), pid, bgTier, bp);
    }

    String colName =
        app.collectionService.getCollectionName(
            skinName.replace(bgTier != null ? " (" + bgTier + ")" : "", "").trim());
    InventoryItem result =
        new InventoryItem(
            new ImageIcon(scaledSkin),
            skinName,
            condition,
            rarityLabel,
            BigDecimal.valueOf(bp).setScale(2, RoundingMode.HALF_UP),
            outputFloat,
            isST,
            pid,
            bgTier,
            bp);
    result.collection = colName;
    app.ownershipHistoryService.addItemHistory(
        result,
        System.currentTimeMillis(),
        "Trade Up",
        String.format("trade up completed by YOU for $%.2f", bp),
        "YOU");
    app.globalSupply.contract(consumedInputs, result);
    app.inventoryList.add(result);
    app.activitySimulationService.addRecentUnboxedSkin(result, "YOU", app.playerAvatar, "Trade Up");
    app.coreUtilities.addInventoryValue(bp);
    BigDecimal newAvgFloat = BigDecimal.valueOf(outputFloat).setScale(6, RoundingMode.HALF_UP);
    if (app.lowestFloat > outputFloat) app.lowestFloat = outputFloat;

    selectedItems.clear();
    app.tradeUpScreen.showTradeUpResult(result);
    app.missionProgress.tradeUps++;
    app.missionService.checkTradeUpAchievements(newRarity);
    app.missionService.checkInventoryCollectionAchievements();
    app.missionService.checkMissionProgress();
    app.tradeUpScreen.refreshTradeUpTab();
  }
}
