package blahblah;

import blahblah.hGui.*;
import java.awt.*;
import java.awt.event.*;
import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;
import java.util.stream.Collectors;
import javax.swing.*;

/** Market Item Cards: focused feature implementation. */
final class MarketItemCards {
  private final hGui app;

  MarketItemCards(hGui app) {
    this.app = app;
  }

  JPanel createMarketplaceSkinCard(
      String skinName, ArrayList<MarketListing> listings, JFrame parent) {
    JPanel card = new JPanel(new BorderLayout(0, 10));
    card.setBackground(new Color(33, 39, 52));
    card.setBorder(
        BorderFactory.createCompoundBorder(
            BorderFactory.createLineBorder(new Color(20, 24, 34), 2),
            BorderFactory.createEmptyBorder(12, 12, 0, 12)));
    card.setPreferredSize(new Dimension(195, 305));
    card.setMaximumSize(new Dimension(195, 305));

    String normalizedName = app.marketGroupingService.getMarketplaceBrowseKey(skinName);
    String rarity = app.itemMetadataService.getSkinRarity(normalizedName);
    CaseType cardContainer = app.exchangeStockService.exchangeContainer(normalizedName);
    Color rarityColor = app.itemInspectionScreen.getRarityColor(rarity);
    String collectionName = app.collectionService.getCollectionName(normalizedName);
    boolean statTrakAvailable =
        app.itemMetadataService.supportsStatTrak(normalizedName)
            && listings.stream()
                .anyMatch(
                    l ->
                        l.item.isStattrak && app.itemMetadataService.supportsStatTrak(l.item.name));
    int marketCount = app.marketFilterControls.countDistinctMarketplaces(listings);
    String nonStatTrakPriceText =
        app.marketItemCards.getMarketplacePriceSummaryText(listings, false, normalizedName);
    String statTrakPriceText =
        statTrakAvailable
            ? app.marketItemCards.getMarketplacePriceSummaryText(listings, true, normalizedName)
            : null;
    if (nonStatTrakPriceText == null) nonStatTrakPriceText = "N/A";
    if (statTrakAvailable && statTrakPriceText == null) statTrakPriceText = "N/A";

    // Split skin name into weapon type (top) and finish name (below)
    String weaponType = app.marketFilterControls.extractWeaponType(normalizedName);
    String skinFinish =
        normalizedName.contains(" | ")
            ? normalizedName.substring(normalizedName.indexOf(" | ") + 3).trim()
            : normalizedName;

    JLabel typeLabel = new JLabel(weaponType, SwingConstants.CENTER);
    typeLabel.setFont(new Font("Arial", Font.PLAIN, 11));
    typeLabel.setForeground(new Color(170, 184, 210));
    typeLabel.setAlignmentX(Component.CENTER_ALIGNMENT);
    typeLabel.setToolTipText(normalizedName);

    JLabel finishLabel =
        new JLabel(
            "<html><div style='text-align:center;'>"
                + app.marketItemCards.escapeHtml(skinFinish)
                + "</div></html>",
            SwingConstants.CENTER);
    finishLabel.setFont(new Font("Arial", Font.BOLD, 14));
    finishLabel.setForeground(new Color(235, 238, 245));
    finishLabel.setAlignmentX(Component.CENTER_ALIGNMENT);
    // Use max width only — let height be determined by actual content so no gap forms
    finishLabel.setMaximumSize(new Dimension(196, 60));
    finishLabel.setBorder(BorderFactory.createEmptyBorder(0, 4, 0, 4));

    JPanel titlePanel = new JPanel();
    titlePanel.setOpaque(false);
    titlePanel.setLayout(new BoxLayout(titlePanel, BoxLayout.Y_AXIS));
    typeLabel.setAlignmentX(Component.CENTER_ALIGNMENT);
    finishLabel.setAlignmentX(Component.CENTER_ALIGNMENT);
    titlePanel.add(Box.createRigidArea(new Dimension(0, 2)));
    titlePanel.add(typeLabel);
    titlePanel.add(Box.createRigidArea(new Dimension(0, 3)));
    titlePanel.add(finishLabel);

    JPanel badges = new JPanel(new GridLayout(statTrakAvailable ? 2 : 1, 1, 0, 6));
    badges.setOpaque(false);
    badges.add(app.marketItemCards.createMarketBadge(rarity, rarityColor));
    if (statTrakAvailable) {
      badges.add(
          app.marketItemCards.createMarketBadge("StatTrak Available", new Color(240, 165, 57)));
    }

    JPanel imageWrap = new JPanel(new BorderLayout());
    imageWrap.setOpaque(false);
    imageWrap.setPreferredSize(new Dimension(180, 134));
    Image skinImg = app.artworkService.getSkinImageFromName(normalizedName);
    if (cardContainer != null) {
      JLabel art = new JLabel("", SwingConstants.CENTER);
      app.cs2Screens.bindCs2SupplyArtwork(cardContainer, false, art, 180, 134);
      imageWrap.add(art, BorderLayout.CENTER);
    } else if (skinImg != null) {
      JLabel imgLabel = app.marketItemCards.createContainedImageLabel(skinImg, 180, 134);
      imageWrap.add(imgLabel, BorderLayout.CENTER);
    } else {
      JLabel placeholder = new JLabel("Loading image...", SwingConstants.CENTER);
      placeholder.setForeground(new Color(170, 184, 210));
      imageWrap.add(placeholder, BorderLayout.CENTER);
      // Use the same resolver as the Armoury view.  The former market card
      // only registered a listener, so a local Armoury image with no remote
      // catalog URL stayed on "Loading image..." indefinitely.
      app.artworkService.getSkinImageFromName(normalizedName, placeholder, 180, 134);
    }

    JPanel pricing = new JPanel(new GridLayout(statTrakAvailable ? 3 : 2, 1, 0, 4));
    pricing.setOpaque(false);
    JLabel lowHigh = new JLabel(nonStatTrakPriceText, SwingConstants.CENTER);
    lowHigh.setFont(new Font("Arial", Font.PLAIN, 15));
    lowHigh.setForeground(new Color(235, 238, 245));
    pricing.add(lowHigh);
    app.marketItemCards.registerMarketplacePriceLabel(normalizedName, lowHigh, false);
    if (statTrakAvailable) {
      JLabel statTrakPrice = new JLabel(statTrakPriceText, SwingConstants.CENTER);
      statTrakPrice.setFont(new Font("Arial", Font.PLAIN, 15));
      statTrakPrice.setForeground(new Color(240, 165, 57));
      pricing.add(statTrakPrice);
      app.marketItemCards.registerMarketplacePriceLabel(normalizedName, statTrakPrice, true);
    }
    JLabel collectionLabel =
        new JLabel(collectionName != null ? collectionName : "", SwingConstants.CENTER);
    collectionLabel.setFont(new Font("Arial", Font.PLAIN, 11));
    collectionLabel.setForeground(new Color(170, 184, 210));
    pricing.add(collectionLabel);

    JPanel variantSection =
        normalizedName.contains("Doppler")
            ? app.marketGroupingService.createDopplerVariantCardSection(listings)
            : null;

    JLabel footer =
        new JLabel(
            String.format(
                "%d offers on %d markets",
                app.exchangeStockService.countStock(listings), Math.max(1, marketCount)),
            SwingConstants.CENTER);
    footer.setOpaque(true);
    footer.setBackground(new Color(77, 84, 102));
    footer.setForeground(Color.WHITE);
    footer.setFont(new Font("Arial", Font.BOLD, 12));
    footer.setBorder(BorderFactory.createEmptyBorder(8, 0, 8, 0));

    JPanel top = new JPanel(new BorderLayout());
    top.setOpaque(false);
    top.add(titlePanel, BorderLayout.NORTH);
    top.add(badges, BorderLayout.CENTER);

    card.add(top, BorderLayout.NORTH);
    card.add(imageWrap, BorderLayout.CENTER);
    card.add(pricing, BorderLayout.SOUTH);

    JPanel cardWrap = new JPanel(new BorderLayout(0, 8));
    cardWrap.setOpaque(false);
    cardWrap.add(card, BorderLayout.CENTER);
    if (variantSection != null) {
      cardWrap.add(variantSection, BorderLayout.SOUTH);
    }

    JPanel wrapper = new JPanel(new BorderLayout());
    wrapper.setOpaque(false);
    wrapper.add(cardWrap, BorderLayout.CENTER);
    wrapper.add(footer, BorderLayout.SOUTH);

    MouseAdapter openDetail =
        new MouseAdapter() {
          @Override
          public void mouseClicked(MouseEvent e) {
            app.marketDetailScreen.showDetailedListings(normalizedName, listings, parent);
          }
        };
    app.cs2Screens.installCs2CardClick(wrapper, openDetail);
    wrapper.setCursor(new Cursor(Cursor.HAND_CURSOR));

    return wrapper;
  }

  void registerMarketplacePriceLabel(String browseKey, JLabel label, boolean statTrak) {
    label.putClientProperty("marketStatTrak", statTrak);
    app.marketplacePriceLabels
        .computeIfAbsent(browseKey, ignored -> ConcurrentHashMap.newKeySet())
        .add(label);
  }

  JPanel createMarketBadge(String text, Color color) {
    JPanel badge = new JPanel(new BorderLayout());
    badge.setBackground(color);
    badge.setBorder(BorderFactory.createEmptyBorder(2, 8, 2, 8));
    JLabel label = new JLabel(text, SwingConstants.CENTER);
    label.setFont(new Font("Arial", Font.BOLD, 11));
    label.setForeground(new Color(15, 15, 20));
    badge.add(label, BorderLayout.CENTER);
    return badge;
  }

  String escapeHtml(String text) {
    if (text == null) return "";
    return text.replace("&", "&amp;").replace("<", "&lt;").replace(">", "&gt;");
  }

  JLabel createContainedImageLabel(Image skinImg, int maxWidth, int maxHeight) {
    if (skinImg == null) return new JLabel();
    int iw = skinImg.getWidth(null);
    int ih = skinImg.getHeight(null);
    if (iw <= 0 || ih <= 0) {
      return new JLabel(new ImageIcon(HighQualityImages.fit(skinImg, maxWidth, maxHeight)));
    }
    double scale = Math.min((double) maxWidth / iw, (double) maxHeight / ih);
    int scaledW = Math.max(1, (int) Math.round(iw * scale));
    int scaledH = Math.max(1, (int) Math.round(ih * scale));
    JLabel label = new JLabel(new ImageIcon(HighQualityImages.fit(skinImg, scaledW, scaledH)));
    label.setPreferredSize(new Dimension(maxWidth, maxHeight));
    label.setHorizontalAlignment(SwingConstants.CENTER);
    label.setVerticalAlignment(SwingConstants.CENTER);
    return label;
  }

  String getMarketplacePriceSummaryText(
      ArrayList<MarketListing> listings, boolean statTrakVariant, String skinName) {
    ArrayList<MarketListing> filtered =
        listings.stream()
            .filter(l -> l.item.isStattrak == statTrakVariant)
            .collect(Collectors.toCollection(ArrayList::new));
    if (filtered.isEmpty()) return null;

    Map<String, Double> cheapestByCondition = new LinkedHashMap<>();
    for (MarketListing listing : filtered) {
      String condition = listing.item.condition != null ? listing.item.condition : "Unknown";
      double current = cheapestByCondition.getOrDefault(condition, Double.MAX_VALUE);
      if (listing.getPrice() < current) {
        cheapestByCondition.put(condition, listing.getPrice());
      }
    }
    if (cheapestByCondition.isEmpty()) return null;

    double lowest =
        cheapestByCondition.values().stream().mapToDouble(Double::doubleValue).min().orElse(0.0);
    double highest =
        cheapestByCondition.values().stream().mapToDouble(Double::doubleValue).max().orElse(0.0);
    boolean isAgent = app.itemMetadataService.isAgentSkin(skinName);
    if (isAgent || Math.abs(lowest - highest) < 0.0001) {
      return String.format("$%.2f", lowest);
    }
    return String.format("$%.2f - $%.2f", lowest, highest);
  }
}
