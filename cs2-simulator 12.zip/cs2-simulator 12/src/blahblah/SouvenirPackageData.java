package blahblah;

import blahblah.hGui.*;
import java.awt.*;
import java.awt.event.*;
import java.util.List;
import java.util.Map;
import javax.swing.*;

/** Extracted reusable model or widget; behavior retained from the original source. */
final class SouvenirPackageData {
  final String crateName;
  final String imageUrl;
  final String mapName;
  final int releaseYear;
  final Map<String, List<String>> drops;

  SouvenirPackageData(
      String crateName,
      String imageUrl,
      String mapName,
      int releaseYear,
      Map<String, List<String>> drops) {
    this.crateName = crateName;
    this.imageUrl = imageUrl;
    this.mapName = mapName;
    this.releaseYear = releaseYear;
    this.drops = drops;
  }
}
