package blahblah;

import blahblah.hGui.*;
import java.awt.*;
import java.awt.event.*;
import javax.swing.*;

/** Extracted reusable model or widget; behavior retained from the original source. */
final class Theme {
  static final Color BG_DARK = new Color(12, 12, 20);
  static final Color BG_PANEL = new Color(20, 20, 32);
  static final Color BG_CARD = new Color(28, 28, 42);
  static final Color ACCENT_T = new Color(247, 147, 30);
  static final Color ACCENT_CT = new Color(95, 200, 255);
  static final Color TEXT = new Color(220, 220, 235);
  static final Color TEXT_DIM = new Color(140, 140, 155);
  static final Color BORDER = new Color(45, 45, 60);
  static final Color STATTRAK = new Color(207, 106, 50);
  static final Color CARD_HOVER = new Color(38, 38, 58);
  static final Color SLOT_LABEL = new Color(130, 130, 160);
  static final Color PLACEHOLDER_BG = new Color(18, 18, 28);
  static final Color GOLD = new Color(255, 215, 0);
  static final Color RARITY_GOLD = new Color(228, 174, 57);
  static final Color RARITY_COVERT = new Color(235, 75, 75);
  static final Color RARITY_CLASSIFIED = new Color(211, 44, 230);
  static final Color RARITY_RESTRICTED = new Color(136, 71, 255);
  static final Color RARITY_MILSPEC = new Color(75, 105, 255);
  static final Color ANIM_ARMOURY_CARD = new Color(40, 40, 55);
  static final Color ANIM_TEXT_SHADOW = new Color(0, 0, 0, 180);
  static final Color PROFIT = new Color(0, 160, 0);
  static final Color STATTRAK_TEXT = new Color(255, 140, 0);
  static final BasicStroke STROKE_2 = new BasicStroke(2f);
  static final BasicStroke STROKE_2_5 = new BasicStroke(2.5f);

  static final Font CONSOLE_PLAIN_9 = new Font("Consolas", Font.PLAIN, 9);
  static final Font CONSOLE_BOLD_12 = new Font("Consolas", Font.BOLD, 12);
  static final Font CONSOLE_BOLD_13 = new Font("Consolas", Font.BOLD, 13);
  static final Font CONSOLE_BOLD_14 = new Font("Consolas", Font.BOLD, 14);
  static final Font CONSOLE_BOLD_16 = new Font("Consolas", Font.BOLD, 16);
  static final Font CONSOLE_PLAIN_12 = new Font("Consolas", Font.PLAIN, 12);
  static final Font ARIAL_BOLD_13 = new Font("Arial", Font.BOLD, 13);
}
