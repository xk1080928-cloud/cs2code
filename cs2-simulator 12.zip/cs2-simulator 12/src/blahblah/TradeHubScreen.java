package blahblah;

import blahblah.hGui.*;
import java.awt.*;
import java.awt.event.*;
import java.util.ArrayList;
import java.util.List;
import javax.swing.*;

/** Trade Hub Screen: focused feature implementation. */
final class TradeHubScreen {
  private final hGui app;

  TradeHubScreen(hGui app) {
    this.app = app;
  }

  void updateTradeNotification() {
    if (app.unreadTradesCount > 0) {
      app.tradeNotificationLabel.setText(
          app.unreadTradesCount + " New Trade" + (app.unreadTradesCount > 1 ? "s" : ""));
      app.tradeNotificationLabel.setVisible(true);
    } else {
      app.tradeNotificationLabel.setText("");
      app.tradeNotificationLabel.setVisible(false);
    }
  }

  void showTradesWindow() {
    app.unreadTradesCount = 0;
    app.tradeHubScreen.updateTradeNotification();

    JFrame tradesFrame = new JFrame("Trade Offers");
    tradesFrame.setSize(900, 700);
    tradesFrame.setLocationRelativeTo(app);
    tradesFrame.setLayout(new BorderLayout());

    tradesFrame.setAlwaysOnTop(true);

    JTabbedPane tabbedPane = new JTabbedPane();
    tabbedPane.addTab(
        "Trade Deals (" + app.pendingTrades.size() + ")",
        app.tradeHubScreen.createTradeDealsHubPanel(tradesFrame));
    tabbedPane.addTab(
        "Purchases (" + app.pendingPurchaseTrades.size() + ")",
        app.tradeHubScreen.createPurchaseTradesPanel(tradesFrame));

    tradesFrame.add(tabbedPane, BorderLayout.CENTER);
    tradesFrame.setVisible(true);

    javax.swing.Timer timer =
        new javax.swing.Timer(
            100,
            e -> {
              tradesFrame.setAlwaysOnTop(false);
              tradesFrame.toFront();
              tradesFrame.requestFocus();
            });
    timer.setRepeats(false);
    timer.start();
  }

  JPanel createTradeDealsHubPanel(JFrame parent) {
    JPanel panel = new JPanel(new BorderLayout());
    panel.setBackground(new Color(20, 20, 26));
    JSplitPane split =
        new JSplitPane(
            JSplitPane.VERTICAL_SPLIT,
            app.tradeHubScreen.createPendingTradesPanel(parent),
            app.tradeTransactionService.createTradeHistoryPanel());
    split.setResizeWeight(0.58);
    split.setDividerSize(6);
    panel.add(split, BorderLayout.CENTER);
    return panel;
  }

  JPanel createPurchaseTradesPanel(JFrame parent) {
    JPanel panel = new JPanel(new BorderLayout());
    panel.setBackground(new Color(20, 20, 26));
    if (app.pendingPurchaseTrades.isEmpty()) {
      JLabel empty = new JLabel("No pending marketplace purchases", SwingConstants.CENTER);
      empty.setFont(new Font("Arial", Font.BOLD, 22));
      empty.setForeground(new Color(180, 190, 210));
      panel.add(empty, BorderLayout.CENTER);
      return panel;
    }
    JPanel container = new JPanel();
    container.setLayout(new BoxLayout(container, BoxLayout.Y_AXIS));
    container.setBackground(new Color(25, 25, 35));
    container.setBorder(BorderFactory.createEmptyBorder(12, 12, 12, 12));
    for (TradeOffer trade : new ArrayList<>(app.pendingPurchaseTrades)) {
      container.add(app.tradeHubScreen.createPurchaseTradeCard(trade, parent));
      container.add(Box.createRigidArea(new Dimension(0, 10)));
    }
    JScrollPane scroll = new JScrollPane(container);
    scroll.getVerticalScrollBar().setUnitIncrement(16);
    panel.add(scroll, BorderLayout.CENTER);
    return panel;
  }

  JPanel createPendingTradesPanel(JFrame parent) {
    JPanel panel = new JPanel(new BorderLayout());

    if (app.pendingTrades.isEmpty()) {
      JLabel emptyLabel = new JLabel("No pending trade offers", SwingConstants.CENTER);
      emptyLabel.setFont(new Font("Arial", Font.BOLD, 24));
      panel.add(emptyLabel, BorderLayout.CENTER);
      return panel;
    }

    JPanel container = new JPanel();
    container.setLayout(new BoxLayout(container, BoxLayout.Y_AXIS));
    container.setBackground(Color.DARK_GRAY);
    container.setBorder(BorderFactory.createEmptyBorder(10, 10, 10, 10));

    List<TradeOffer> tradeSnapshot;
    synchronized (app.pendingTrades) {
      tradeSnapshot = new ArrayList<>(app.pendingTrades);
    }
    for (TradeOffer trade : tradeSnapshot) {
      JPanel tradeCard = app.tradeHubScreen.createTradeCard(trade, parent, true);
      tradeCard.setMaximumSize(new Dimension(Integer.MAX_VALUE, 350));
      container.add(tradeCard);
      container.add(Box.createRigidArea(new Dimension(0, 10)));
    }

    JScrollPane scroll = new JScrollPane(container);
    scroll.getVerticalScrollBar().setUnitIncrement(16);
    panel.add(scroll, BorderLayout.CENTER);

    return panel;
  }

  JPanel createTradeCard(TradeOffer trade, JFrame parent, boolean isPending) {
    JPanel card = new JPanel(new BorderLayout());
    card.setBackground(new Color(45, 45, 50));
    card.setBorder(
        BorderFactory.createCompoundBorder(
            BorderFactory.createLineBorder(
                isPending
                    ? Color.ORANGE
                    : (trade.isAccepted ? new Color(50, 200, 50) : new Color(200, 50, 50)),
                3),
            BorderFactory.createEmptyBorder(10, 10, 10, 10)));
    card.setPreferredSize(new Dimension(850, 400));
    card.setMinimumSize(new Dimension(850, 400));

    JPanel topPanel = new JPanel(new BorderLayout());
    topPanel.setBackground(new Color(45, 45, 50));

    JPanel npcInfoPanel = new JPanel(new FlowLayout(FlowLayout.LEFT));
    npcInfoPanel.setBackground(new Color(45, 45, 50));

    JLabel npcAvatarLabel = new JLabel(new ImageIcon(trade.npcAvatar));
    npcInfoPanel.add(npcAvatarLabel);

    JLabel npcNameLabel = new JLabel(trade.npcName);
    npcNameLabel.setFont(new Font("Arial", Font.BOLD, 18));
    npcNameLabel.setForeground(Color.WHITE);
    npcInfoPanel.add(npcNameLabel);

    long secondsAgo = (System.currentTimeMillis() - trade.timestamp) / 1000;
    String timeStr = secondsAgo < 60 ? secondsAgo + "s ago" : (secondsAgo / 60) + "m ago";
    JLabel timeLabel = new JLabel(" - " + timeStr);
    timeLabel.setForeground(Color.LIGHT_GRAY);
    npcInfoPanel.add(timeLabel);

    topPanel.add(npcInfoPanel, BorderLayout.WEST);

    JPanel tradeTypePanel = new JPanel(new FlowLayout(FlowLayout.RIGHT));
    tradeTypePanel.setBackground(new Color(45, 45, 50));

    Color tradeTypeColor = Color.WHITE;

    boolean npcOffersItems = !trade.npcOfferedItems.isEmpty();
    boolean npcOffersMoney = trade.npcOfferedMoney > 0;
    boolean npcRequestsItems = !trade.npcRequestedItems.isEmpty();
    boolean npcRequestsMoney = trade.npcRequestedMoney > 0;

    String tradeKey;

    if (npcOffersItems && npcRequestsMoney && !npcOffersMoney && !npcRequestsItems) {
      tradeKey = "SELLING";
      tradeTypeColor = new Color(100, 200, 100);
    } else if (npcOffersMoney && npcRequestsItems && !npcOffersItems && !npcRequestsMoney) {
      tradeKey = "BUYING";
      tradeTypeColor = new Color(255, 200, 50);
    } else if (npcOffersItems && npcRequestsItems && !npcOffersMoney && !npcRequestsMoney) {
      tradeKey = "TRADING";
      tradeTypeColor = new Color(100, 150, 255);
    } else {
      tradeKey = "MIXED";
      tradeTypeColor = new Color(200, 100, 255);
    }

    String tradeText = app.tradeCards.tradeType(tradeKey);

    JLabel tradeTypeLabel = new JLabel(tradeText);
    tradeTypeLabel.setFont(new Font("Arial", Font.BOLD, 16));
    tradeTypeLabel.setForeground(tradeTypeColor);
    tradeTypeLabel.setBorder(
        BorderFactory.createCompoundBorder(
            BorderFactory.createLineBorder(tradeTypeColor, 2),
            BorderFactory.createEmptyBorder(5, 10, 5, 10)));
    tradeTypePanel.add(tradeTypeLabel);

    topPanel.add(tradeTypePanel, BorderLayout.EAST);

    card.add(topPanel, BorderLayout.NORTH);

    JPanel tradePanel = new JPanel(new GridLayout(1, 2, 10, 0));
    tradePanel.setBackground(new Color(45, 45, 50));
    tradePanel.setPreferredSize(new Dimension(850, 260));

    JPanel npcSide =
        app.tradeCards.createTradeSidePanel(
            trade.npcOfferedItems, trade.npcOfferedMoney, trade.npcAvatar, "NPC Offers", true);
    tradePanel.add(npcSide);

    JPanel yourSide =
        app.tradeCards.createTradeSidePanel(
            trade.npcRequestedItems, trade.npcRequestedMoney, app.playerAvatar, "You Give", false);
    tradePanel.add(yourSide);

    card.add(tradePanel, BorderLayout.CENTER);

    JPanel bottomPanel = new JPanel(new FlowLayout());
    bottomPanel.setBackground(new Color(45, 45, 50));

    if (isPending) {
      JButton acceptBtn = new JButton("ACCEPT TRADE");
      acceptBtn.setBackground(new Color(50, 200, 50));
      acceptBtn.setForeground(Color.GREEN);
      acceptBtn.setFont(new Font("Arial", Font.BOLD, 14));
      acceptBtn.setPreferredSize(new Dimension(200, 40));

      acceptBtn.addMouseListener(
          new MouseAdapter() {
            @Override
            public void mousePressed(MouseEvent e) {}
          });

      JButton declineBtn = new JButton("DECLINE TRADE");
      declineBtn.setBackground(new Color(200, 50, 50));
      declineBtn.setForeground(Color.RED);
      declineBtn.setFont(new Font("Arial", Font.BOLD, 14));
      declineBtn.setPreferredSize(new Dimension(200, 40));

      declineBtn.addMouseListener(
          new MouseAdapter() {
            @Override
            public void mousePressed(MouseEvent e) {}
          });

      acceptBtn.addActionListener(
          e -> {
            app.tradeTransactionService.handleTradeAccept(trade, parent);
          });

      declineBtn.addActionListener(
          e -> {
            app.tradeTransactionService.handleTradeDecline(trade, parent);
          });

      bottomPanel.add(acceptBtn);
      bottomPanel.add(declineBtn);
    } else {
      JLabel statusLabel = new JLabel(trade.isAccepted ? "ACCEPTED" : "DECLINED");
      statusLabel.setFont(new Font("Arial", Font.BOLD, 20));
      statusLabel.setForeground(trade.isAccepted ? new Color(50, 200, 50) : new Color(200, 50, 50));
      bottomPanel.add(statusLabel);
    }

    card.add(bottomPanel, BorderLayout.SOUTH);

    return card;
  }

  JPanel createPurchaseTradeCard(TradeOffer trade, JFrame parent) {
    JPanel card = new JPanel(new BorderLayout());
    MarketplaceProfile profile =
        MarketplaceProfile.byName(
            trade.marketplaceName != null ? trade.marketplaceName : "CS.MONEY");
    card.setBackground(new Color(38, 43, 56));
    card.setBorder(
        BorderFactory.createCompoundBorder(
            BorderFactory.createLineBorder(profile.accent, 2),
            BorderFactory.createEmptyBorder(12, 14, 12, 14)));
    card.setMaximumSize(new Dimension(Integer.MAX_VALUE, 180));

    InventoryItem item = trade.npcOfferedItems.isEmpty() ? null : trade.npcOfferedItems.get(0);

    JLabel title =
        new JLabel(
            (trade.marketplaceName != null ? trade.marketplaceName : "Marketplace")
                + "  •  "
                + (trade.marketplaceType != null ? trade.marketplaceType : "P2P"));
    title.setFont(new Font("Arial", Font.BOLD, 20));
    title.setForeground(Color.WHITE);
    JLabel subtitle =
        new JLabel(
            item != null
                ? item.name
                    + "  •  "
                    + item.condition
                    + "  •  paid $"
                    + String.format("%.2f", trade.settledPrice)
                : "Pending purchase");
    subtitle.setFont(new Font("Arial", Font.PLAIN, 12));
    subtitle.setForeground(new Color(180, 188, 208));

    JPanel info = new JPanel();
    info.setOpaque(false);
    info.setLayout(new BoxLayout(info, BoxLayout.Y_AXIS));
    info.add(title);
    info.add(subtitle);

    JPanel actions = new JPanel(new FlowLayout(FlowLayout.RIGHT, 10, 0));
    actions.setOpaque(false);
    JButton accept = new JButton("ACCEPT DELIVERY");
    accept.setBackground(new Color(70, 164, 92));
    accept.setForeground(Color.BLACK);
    accept.setFocusPainted(false);
    // Disable accept button until the scheduled delivery time has passed
    long now = System.currentTimeMillis();
    boolean deliveryReady = trade.deliveryScheduledTime == 0L || now >= trade.deliveryScheduledTime;
    accept.setEnabled(deliveryReady);
    if (!deliveryReady) {
      long secsLeft = (trade.deliveryScheduledTime - now) / 1000;
      accept.setText("PENDING (" + secsLeft + "s)");
      accept.setBackground(new Color(60, 80, 60));
      // Poll every second to re-enable when ready
      javax.swing.Timer enableTimer = new javax.swing.Timer(1000, null);
      enableTimer.addActionListener(
          ev -> {
            long remaining = trade.deliveryScheduledTime - System.currentTimeMillis();
            if (remaining <= 0) {
              accept.setEnabled(true);
              accept.setText("ACCEPT DELIVERY");
              accept.setBackground(new Color(70, 164, 92));
              enableTimer.stop();
            } else {
              accept.setText("PENDING (" + (remaining / 1000) + "s)");
            }
          });
      enableTimer.start();
    }
    accept.addActionListener(
        e -> app.tradeTransactionService.handlePurchaseTradeAccept(trade, parent));
    JButton cancel = new JButton("CANCEL");
    cancel.setBackground(new Color(133, 63, 63));
    cancel.setForeground(Color.BLACK);
    cancel.setFocusPainted(false);
    cancel.addActionListener(
        e -> app.tradeTransactionService.handlePurchaseTradeDecline(trade, parent));
    actions.add(accept);
    actions.add(cancel);

    card.add(info, BorderLayout.CENTER);
    card.add(actions, BorderLayout.EAST);
    return card;
  }
}
