package blahblah;

import blahblah.hGui.*;
import java.awt.*;
import java.awt.event.*;
import javax.swing.*;

/** Extracted reusable model or widget; behavior retained from the original source. */
class PriceHistoryPoint {
  final double price;
  final int soldQuantity;
  final long timestamp;

  PriceHistoryPoint(double price, int soldQuantity) {
    this(price,soldQuantity,0);
  }

  PriceHistoryPoint(double price,int soldQuantity,long timestamp) {
    this.timestamp=timestamp;
    this.price = price;
    this.soldQuantity = soldQuantity;
  }
}
