package blahblah;

import blahblah.hGui.*;
import java.awt.*;
import java.awt.event.*;
import java.math.BigDecimal;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;
import java.util.LinkedHashMap;
import java.util.LinkedList;
import java.util.List;
import java.util.Map;
import java.util.Queue;
import java.util.Random;
import java.util.Set;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.prefs.Preferences;
import java.util.regex.Pattern;
import javax.swing.*;

/**
 * Shared application state and thin feature dispatchers; all feature algorithms live in separate
 * classes.
 */
@SuppressWarnings("serial")
abstract class SimulatorContext extends JFrame implements ActionListener {
  final hGui app = (hGui) this;
  volatile long worldVersion;
  final GlobalSupply globalSupply = new GlobalSupply(app);
  final BackgroundUnboxing backgroundUnboxing = new BackgroundUnboxing(app);
  final PageTransitions pageTransitions = new PageTransitions(app);
  final CarePackages carePackages = new CarePackages(app);
  final MarketplaceUnitStock marketplaceUnitStock = new MarketplaceUnitStock(app);
  final MarketplaceTabs marketplaceTabs = new MarketplaceTabs(app);
  final StoreScreen storeScreen = new StoreScreen(app);
  final ArmouryArtworkCache armouryArtworkCache = new ArmouryArtworkCache(app);
  final MarketDynamics marketDynamics = new MarketDynamics(app);
  final InventoryToolsService inventoryToolsService = new InventoryToolsService(app);
  final ItemRevealService itemRevealService = new ItemRevealService(app);
  final ContainerMarketService containerMarketService = new ContainerMarketService(app);
  final MarketplaceDirectory marketplaceDirectory = new MarketplaceDirectory(app);
  final MarketplacePricing marketplacePricing = new MarketplacePricing(app);
  final MarketSiteLayouts marketSiteLayouts = new MarketSiteLayouts(app);
  final MarketCardSelection marketCardSelection = new MarketCardSelection(app);
  final MarketplaceGroups marketplaceGroups = new MarketplaceGroups(app);
  final CoreUtilities coreUtilities = new CoreUtilities(app);
  final MarketStockService marketStockService = new MarketStockService(app);
  final ContainerInventoryService containerInventoryService = new ContainerInventoryService(app);
  final Cs2Screens cs2Screens = new Cs2Screens(app);
  final Cs2EquipmentScreens cs2EquipmentScreens = new Cs2EquipmentScreens(app);
  final ContainerSelectionScreen containerSelectionScreen = new ContainerSelectionScreen(app);
  final ExchangeStockService exchangeStockService = new ExchangeStockService(app);
  final ExchangeTransactionService exchangeTransactionService = new ExchangeTransactionService(app);
  final ExchangeWidgets exchangeWidgets = new ExchangeWidgets(app);
  final ExchangeScreens exchangeScreens = new ExchangeScreens(app);
  final ExchangeHomeScreen exchangeHomeScreen = new ExchangeHomeScreen(app);
  final ExchangeCatalogScreens exchangeCatalogScreens = new ExchangeCatalogScreens(app);
  final NavigationService navigationService = new NavigationService(app);
  final UiCatalogData uiCatalogData = new UiCatalogData(app);
  final ApplicationBootstrap applicationBootstrap = new ApplicationBootstrap(app);
  final AvatarService avatarService = new AvatarService(app);
  final UiWidgets uiWidgets = new UiWidgets(app);
  final BundledArtwork bundledArtwork = new BundledArtwork(app);
  final ContainerBrowserScreen containerBrowserScreen = new ContainerBrowserScreen(app);
  final DeveloperTools developerTools = new DeveloperTools(app);
  final GoldTradeUpService goldTradeUpService = new GoldTradeUpService(app);
  final InventoryScreen inventoryScreen = new InventoryScreen(app);
  final TradeUpScreen tradeUpScreen = new TradeUpScreen(app);
  final LoadoutScreen loadoutScreen = new LoadoutScreen(app);
  final LoadoutCards loadoutCards = new LoadoutCards(app);
  final GeneralScreen generalScreen = new GeneralScreen(app);
  final OddsAndChecklistScreen oddsAndChecklistScreen = new OddsAndChecklistScreen(app);
  final SaveService saveService = new SaveService(app);
  final FloatRules floatRules = new FloatRules(app);
  final CollectionService collectionService = new CollectionService(app);
  final ItemPriceService itemPriceService = new ItemPriceService(app);
  final PublicPriceFeeds publicPriceFeeds = new PublicPriceFeeds(app);
  final PriceTables priceTables = new PriceTables(app);
  final CaseRollService caseRollService = new CaseRollService(app);
  final InventoryCards inventoryCards = new InventoryCards(app);
  final OwnershipHistoryService ownershipHistoryService = new OwnershipHistoryService(app);
  final ItemInspectionScreen itemInspectionScreen = new ItemInspectionScreen(app);
  final TradeUpCards tradeUpCards = new TradeUpCards(app);
  final StartupScreen startupScreen = new StartupScreen(app);
  final MarketInitialization marketInitialization = new MarketInitialization(app);
  final StartupPriceService startupPriceService = new StartupPriceService(app);
  final StartupArtworkService startupArtworkService = new StartupArtworkService(app);
  final MarketRuntime marketRuntime = new MarketRuntime(app);
  final PriceModifiers priceModifiers = new PriceModifiers(app);
  final MarketPriceChanges marketPriceChanges = new MarketPriceChanges(app);
  final ListingSalesService listingSalesService = new ListingSalesService(app);
  final MarketGeneration marketGeneration = new MarketGeneration(app);
  final ItemMetadataService itemMetadataService = new ItemMetadataService(app);
  final MarketGroupingService marketGroupingService = new MarketGroupingService(app);
  final MarketHomeFeeds marketHomeFeeds = new MarketHomeFeeds(app);
  final MarketBrowserScreen marketBrowserScreen = new MarketBrowserScreen(app);
  final MarketHomeScreen marketHomeScreen = new MarketHomeScreen(app);
  final MarketFilterControls marketFilterControls = new MarketFilterControls(app);
  final MarketItemCards marketItemCards = new MarketItemCards(app);
  final MarketDetailScreen marketDetailScreen = new MarketDetailScreen(app);
  final MarketHistoryScreen marketHistoryScreen = new MarketHistoryScreen(app);
  final MarketOfferService marketOfferService = new MarketOfferService(app);
  final OfferHeroAndSellerScreens offerHeroAndSellerScreens = new OfferHeroAndSellerScreens(app);
  final OfferAnalyticsScreens offerAnalyticsScreens = new OfferAnalyticsScreens(app);
  final OfferManifestScreens offerManifestScreens = new OfferManifestScreens(app);
  final OfferGalleryScreens offerGalleryScreens = new OfferGalleryScreens(app);
  final OfferNeonAndMirageScreens offerNeonAndMirageScreens = new OfferNeonAndMirageScreens(app);
  final OfferEmberAndFrostScreens offerEmberAndFrostScreens = new OfferEmberAndFrostScreens(app);
  final OfferRelayAndVelvetScreens offerRelayAndVelvetScreens = new OfferRelayAndVelvetScreens(app);
  final MarketPurchaseService marketPurchaseService = new MarketPurchaseService(app);
  final MarketCatalogService marketCatalogService = new MarketCatalogService(app);
  final CatalogLoadingService catalogLoadingService = new CatalogLoadingService(app);
  final CatalogParsingService catalogParsingService = new CatalogParsingService(app);
  final ArtworkService artworkService = new ArtworkService(app);
  final MarketChartData marketChartData = new MarketChartData(app);
  final BufferedMarketSupply marketBuffer = new BufferedMarketSupply(app);
  final SalesHistoryScreen salesHistoryScreen = new SalesHistoryScreen(app);
  final SalesSimulationService salesSimulationService = new SalesSimulationService(app);
  final PlayerPurchasesScreen playerPurchasesScreen = new PlayerPurchasesScreen(app);
  final OpeningArtworkService openingArtworkService = new OpeningArtworkService(app);
  final CaseOpeningScreen caseOpeningScreen = new CaseOpeningScreen(app);
  final OpeningRewardService openingRewardService = new OpeningRewardService(app);
  final TradeGenerationService tradeGenerationService = new TradeGenerationService(app);
  final TradeHubScreen tradeHubScreen = new TradeHubScreen(app);
  final TradeCards tradeCards = new TradeCards(app);
  final TradeTransactionService tradeTransactionService = new TradeTransactionService(app);
  final ActivitySimulationService activitySimulationService = new ActivitySimulationService(app);
  final CollectionScreen collectionScreen = new CollectionScreen(app);
  final AchievementDefinitions achievementDefinitions = new AchievementDefinitions(app);
  final AchievementScreen achievementScreen = new AchievementScreen(app);
  final StatisticsAndAchievements statisticsAndAchievements = new StatisticsAndAchievements(app);
  final LeaderboardService leaderboardService = new LeaderboardService(app);
  final LeaderboardScreen leaderboardScreen = new LeaderboardScreen(app);
  final SearchControls searchControls = new SearchControls(app);
  final RoiScreen roiScreen = new RoiScreen(app);
  final MissionService missionService = new MissionService(app);
  final MissionScreen missionScreen = new MissionScreen(app);
  final ArmouryScreen armouryScreen = new ArmouryScreen(app);
  final ArmouryRedeemService armouryRedeemService = new ArmouryRedeemService(app);
  final ArmouryAnimationScreen armouryAnimationScreen = new ArmouryAnimationScreen(app);

  SimulatorContext(String title) {
    super(title);
  }

  static final int MAX_SALES_HISTORY = 2000;

  static final int MAX_RARE_SALES = 1000;

  static final int MARKET_UPDATE_INTERVAL = 5000;

  static final int SALES_UI_UPDATE_INTERVAL = 7500;

  static final int FAKE_SALES_MIN_DELAY = 200;

  static final int TRADE_GENERATION_MIN = 60000;

  static final int TRADE_GENERATION_RANGE = 60000;

  static final int MAX_SEARCH_HISTORY = 10;

  static final long MARKET_PRICE_CACHE_TTL_MS = 12L * 60L * 60L * 1000L;

  static final long PUBLIC_PRICE_SNAPSHOT_TTL_MS = 30L * 60L * 1000L;

  static final long SKIN_CATALOG_REFRESH_MS = 24L * 60L * 60L * 1000L;

  static final String SKIN_CATALOG_URL =
      "https://raw.githubusercontent.com/ByMykel/CSGO-API/main/public/api/en/skins.json";

  static final String AGENT_CATALOG_URL =
      "https://raw.githubusercontent.com/ByMykel/CSGO-API/main/public/api/en/agents.json";

  static final String CRATE_CATALOG_URL =
      "https://raw.githubusercontent.com/ByMykel/CSGO-API/main/public/api/en/crates.json";

  static final String SAVE_FILE = "csgo_simulator_save.dat";

  static final String SAVE_JSON_FILE = "csgo_simulator_save.json";

  static final Random random = new Random();

  javax.swing.Timer tradeGenerationTimer;

  Image crateImage;

  Image skinImage;

  Image finalSkin;

  Image playerAvatar;

  Image goldIconImage;

  Image[] blueSkins;

  Image[] purpleSkins;

  Image[] pinkSkins;

  Image[] redSkins;

  Image[] knifeSkins;

  Image[] gloveSkins;

  String[] knifeSkinNames = new String[0];

  String[] gloveSkinNames = new String[0];

  Image[] npcAvatars;

  final InventoryIdGenerator inventoryIdGenerator = new InventoryIdGenerator();

  final ImageRepository imageRepository = new ImageRepository(app);

  final Map<String, String> agentRarityCache = new ConcurrentHashMap<>();

  final Map<String, Double> agentBasePriceCache = new ConcurrentHashMap<>();

  final Map<String, SkinMetadata> agentCatalog = new ConcurrentHashMap<>();

  final Map<String, TradeUpCollection> collectionCache =
      java.util.Collections.synchronizedMap(new HashMap<>());

  final Map<CaseType, TradeUpCollection> catalogCaseCollectionCache = new ConcurrentHashMap<>();

  final Preferences marketPricePreferences =
      Preferences.userNodeForPackage(hGui.class).node("csfloat-market-prices");

  final Set<String> marketPriceLookups = ConcurrentHashMap.newKeySet();

  final Set<String> pendingMarketPriceLookups = ConcurrentHashMap.newKeySet();

  boolean marketUpdateInProgress;

  final Set<String> disabledPriceFeeds = ConcurrentHashMap.newKeySet();

  final Map<String, Double> liveBasePrices = new ConcurrentHashMap<>();

  final Map<String, Double> liveVanillaStatTrakPrices = new ConcurrentHashMap<>();

  final Map<String, Double> fallbackBasePrices = new ConcurrentHashMap<>();

  final Map<String, Map<String, Double>> liveConditionPriceMultipliers = new ConcurrentHashMap<>();

  final Map<String, String> publicPriceSnapshots = new ConcurrentHashMap<>();

  final Map<String, Long> publicPriceSnapshotTimes = new ConcurrentHashMap<>();

  final Map<String, Map<String, Integer>> publicPriceSnapshotIndexes = new ConcurrentHashMap<>();

  final Map<String, Object> publicPriceSnapshotLocks = new ConcurrentHashMap<>();

  final Map<String, Long> publicPriceFeedRetryAfter = new ConcurrentHashMap<>();

  final Map<String, String> publicPriceIndexSources = new ConcurrentHashMap<>();

  final Map<String, SkinMetadata> skinCatalog = new ConcurrentHashMap<>();

  final Set<String> remoteImageLoads = ConcurrentHashMap.newKeySet();

  final Set<String> remoteImageGameViewRequests = ConcurrentHashMap.newKeySet();

  final Map<String, Set<JLabel>> pendingRemoteImageLabels = new ConcurrentHashMap<>();

  final Map<String, Set<JLabel>> marketplacePriceLabels = new ConcurrentHashMap<>();

  final java.util.concurrent.CountDownLatch startupCatalogsLoaded =
      new java.util.concurrent.CountDownLatch(3);

  final java.util.concurrent.CountDownLatch skinCatalogLoaded =
      new java.util.concurrent.CountDownLatch(1);

  final Path skinCatalogFile =
      Paths.get(System.getProperty("user.home"), ".csgo-skin-simulator", "skins.json");

  final Path agentCatalogFile =
      Paths.get(System.getProperty("user.home"), ".csgo-skin-simulator", "agents.json");

  final Path crateCatalogFile =
      Paths.get(System.getProperty("user.home"), ".csgo-skin-simulator", "crates.json");

  final ExecutorService marketPriceExecutor =
      Executors.newFixedThreadPool(
          4,
          r -> {
            Thread thread = new Thread(r, "market-price-lookup");
            thread.setDaemon(true);
            return thread;
          });

  final ExecutorService skinCatalogExecutor =
      Executors.newFixedThreadPool(
          3,
          r -> {
            Thread thread = new Thread(r, "catalog-refresh");
            thread.setDaemon(true);
            return thread;
          });

  final ExecutorService remoteImageExecutor =
      Executors.newFixedThreadPool(
          8,
          r -> {
            Thread thread = new Thread(r, "skin-image-download");
            thread.setDaemon(true);
            return thread;
          });

  JButton openCrateButton;

  JButton closeCrateButton;

  JButton autoOpenButton;

  JButton devToolsButton;

  JButton caseSelectorButton;

  JLabel caseRoiLabel;

  volatile boolean marketInitialized;

  JButton tradesButton;

  JButton collectionButton;

  JButton achievementsButton;

  JButton statsButton;

  JButton saveButton;

  JButton loadButton;

  JButton leaderboardButton;

  JButton roiButton;

  JButton missionsButton;

  JButton armouryButton;

  JButton armouryOddsButton;

  JButton collectionChecklistButton;

  JButton imageVerifierButton;

  int playerStars = 999;

  JLabel starsLabel;

  JLabel armouryStarsDisp;

  ArrayList<Mission> activeMissions = new ArrayList<>();

  MissionProgress missionProgress = new MissionProgress();

  JPanel armouryTabPanel;

  int lastArmouryTabIndex = 0;

  JLabel rarityLabel;

  JLabel nameLabel;

  JLabel priceLabel;

  JLabel floatLabel;

  JLabel conditionLabel;

  JLabel lowFloatLabel;

  JLabel patternId;

  JLabel collectionLabel;

  JLabel balanceLabel;

  JLabel profitLabel;

  JLabel tradeNotificationLabel;

  JLabel totalInventoryValueLabel;

  JLabel totalMilspec;

  JLabel totalRestrict;

  JLabel totalClass;

  JLabel totalCovert;

  JLabel totalKnife;

  JLabel totalGlove;

  JTabbedPane mainTabs;

  JPanel startupLoadingOverlay;

  JTextArea startupLoadingStatusLabel;

  JTextArea startupLoadingTimeLabel;

  JLabel startupLoadingPriceDetailsLabel;

  volatile Set<String> startupPriceNames = java.util.Collections.emptySet();

  final Set<String> startupPriceRequestedNames = ConcurrentHashMap.newKeySet();

  volatile int startupPriceTotal, startupPricesLoaded, startupPriceFallbacks;

  volatile boolean startupPriceStageActive;

  volatile long startupPriceFeedBytes, startupPriceFeedTotal;

  volatile String startupPriceFeedStatus = "Waiting for CSFloat";

  JLabel startupLoadingArtworkDetailsLabel;

  JProgressBar startupLoadingProgressBar;

  javax.swing.Timer startupLoadingTimer;

  final java.util.concurrent.atomic.AtomicInteger startupCatalogsCompleted =
      new java.util.concurrent.atomic.AtomicInteger();

  volatile int startupProgressPercent;

  volatile String startupProgressStatus = "Preparing the application...";

  long startupStartedAt;

  boolean startupStartQueued;

  volatile boolean startupWorkStarted, startupArtworkStage;

  boolean startupDisplayRefreshQueued;

  volatile int startupArtworkTotal,
      startupArtworkLoaded,
      startupArtworkFailed,
      startupArtworkFallbacks;

  final Map<String, String> startupResolvedArtworkUrls = new ConcurrentHashMap<>();

  JPanel casesTabPanel;

  JPanel inventoryTabPanel;

  JPanel tradeUpTabPanel;

  JPanel marketTabPanel;

  JPanel generalTabPanel;

  JPanel loadoutTabPanel;

  Map<String, InventoryItem> tLoadout = new java.util.LinkedHashMap<>();

  Map<String, InventoryItem> ctLoadout = new java.util.LinkedHashMap<>();

  JPanel headerPanel;

  JLabel crateImageLabel = null;

  JLabel activeResultImageLabel;

  javax.swing.Timer autoTimer;

  javax.swing.Timer armouryAutoTimer;

  javax.swing.Timer marketTimer;

  javax.swing.Timer salesUpdateTimer;

  javax.swing.Timer fakeSalesTimer;

  javax.swing.Timer inventoryRefreshTimer;

  AnimationPanel animationPanel;

  Window animationFrame;

  boolean armouryAnimating = false;

  ArmouryCollection activeArmouryAutoCollection;

  JButton armouryAutoButton;

  JLabel activeArmouryStarsDisplay;

  boolean isAnimating = false;

  int unreadTradesCount = 0;

  int profitStreakCount = 0;

  int lossStreakCount = 0;

  String gunName;

  String condition;

  String finalSkinName = "";

  String finalCondition = "";

  String finalBlueGemTier;

  int patternID;

  int finalPatternID;

  double itemFloat = 0.0;

  double finalFloat = 0.0;

  double finalPrice = 0.0;

  double bonusPrice;

  double lowestFloat = 1.0;

  double balance = 500000.0;

  double inventoryValue = 0.0;

  double openingProfit = 0.0;

  double totalMarketProfit = 0.0;

  int totalCrates = 0;

  int totalArmouryRedeems = 0;

  int totMil = 0;

  int totRes = 0;

  int totClass = 0;

  int totCov = 0;

  int totKnife = 0;

  int totGlove = 0;

  int totIndustrial = 0;

  int totDistinguished = 0;

  int totExceptional = 0;

  int totSuperior = 0;

  int totMaster = 0;

  final ArrayList<InventoryItem> inventoryList = new ArrayList<>();

  ArrayList<MarketListing> activeListings = new ArrayList<>();

  ArrayList<TradeOffer> pendingTrades = new ArrayList<>();

  ArrayList<TradeOffer> completedTrades = new ArrayList<>();

  ArrayList<TradeOffer> pendingPurchaseTrades = new ArrayList<>();

  LinkedList<SaleRecord> playerPurchases = new LinkedList<>();

  LinkedList<SaleRecord> recentSales = new LinkedList<>();

  LinkedList<SaleRecord> recentUnboxedSkins = new LinkedList<>();

  LinkedList<SaleRecord> rareSales = new LinkedList<>();

  ArrayList<String> unlockedAchievements = new ArrayList<>();

  Map<String, Double> marketPriceMultipliers = new ConcurrentHashMap<>();

  Map<String, ArrayList<Double>> priceHistory = new HashMap<>();

  Map<String, ArrayList<Double>> collectionPriceHistory = new HashMap<>();

  final Map<String, ArrayList<MarketListing>> globalMarketListings = new HashMap<>();

  Map<String, ArrayList<MarketListing>> groupedMarketListingsCache = null;

  int groupedMarketListingsCacheSize = -1;

  Map<String, ArrayList<MarketListing>> persistentBlueGemListings = new HashMap<>();

  Map<String, java.util.List<StripItem>> armouryAnimationPoolCache = new HashMap<>();

  Map<String, Map<String, ArrayList<SaleRecord>>> salesHistory = new HashMap<>();

  Map<String, Achievement> achievements = new HashMap<>();

  Map<String, Integer> globalBlueGemCounts = new HashMap<>();

  Map<String, Map<String, Double>> initialConditionPrices = new HashMap<>();

  Map<String, ArrayList<Double>> skinConditionPriceHistory = new HashMap<>();

  Map<String, String> marketplaceSortModes = new HashMap<>();

  Map<String, String> marketplacePatternFilters = new HashMap<>();

  int marketReplenishTicks = 0;

  Set<String> unboxedSkins = new HashSet<>();

  Queue<String> marketProcessQueue = new LinkedList<>();

  LinkedList<String> searchHistory = new LinkedList<>();

  List<JComboBox<String>> searchBoxes = new ArrayList<>();

  List<LeaderboardEntry> globalLeaderboard = new ArrayList<>();

  CaseType currentCase = CaseType.WEAPON_CASE_ONE;

  static final String[] NPC_USERNAMES = NpcUsernamesData.DATA;

  static final Image[] NPC_AVATAR_POOL;

  static {
    NPC_AVATAR_POOL = new Image[64];
    Color[] avatarColors = {
      new Color(255, 100, 100), new Color(100, 150, 255), new Color(100, 255, 150),
      new Color(255, 200, 100), new Color(200, 100, 255), new Color(255, 150, 200),
      new Color(150, 255, 255), new Color(255, 255, 100), new Color(255, 150, 100),
      new Color(150, 100, 255), new Color(100, 255, 200), new Color(255, 100, 150)
    };
    for (int i = 0; i < NPC_AVATAR_POOL.length; i++) {
      java.awt.image.BufferedImage img =
          new java.awt.image.BufferedImage(48, 48, java.awt.image.BufferedImage.TYPE_INT_ARGB);
      java.awt.Graphics2D g2 = img.createGraphics();
      g2.setRenderingHint(
          java.awt.RenderingHints.KEY_ANTIALIASING, java.awt.RenderingHints.VALUE_ANTIALIAS_ON);
      g2.setColor(avatarColors[i % avatarColors.length]);
      g2.fillOval(4, 4, 40, 40);
      g2.setColor(java.awt.Color.WHITE);
      g2.setFont(new java.awt.Font("Arial", java.awt.Font.BOLD, 20));
      String initial = "" + (char) ('A' + (i % 26));
      java.awt.FontMetrics fm = g2.getFontMetrics();
      int x = (48 - fm.stringWidth(initial)) / 2;
      int y = ((48 - fm.getHeight()) / 2) + fm.getAscent();
      g2.drawString(initial, x, y);
      g2.dispose();
      NPC_AVATAR_POOL[i] = img;
    }
  }

  static final String[] MARKET_WEAR_NAMES = {
    "Factory New", "Minimal Wear", "Field-Tested", "Well-Worn", "Battle-Scarred"
  };

  static final double[] MARKET_WEAR_EDGES = {0.0, 0.07, 0.15, 0.38, 0.45, 1.0};

  static final int MARKET_STOCK_MULTIPLIER = 2;

  final Map<String, Long> lastNpcRestockAt = new HashMap<>();

  final Map<String, Integer> npcRestockCursor = new HashMap<>();

  boolean cs2ShellEnabled;

  JPanel cs2HomePanel;

  String cs2InventorySection = "EVERYTHING", cs2InventorySearch = "";

  int cs2InventoryPage;

  boolean cs2NewestFirst = true;

  JDialog cs2ContainerDialog;

  Runnable cs2PendingOpeningReward;

  JLabel cs2BalanceLabel;

  Map<Integer, JButton> cs2Navigation = new LinkedHashMap<>();

  ArrayList<OwnedSupply> ownedSupplies = new ArrayList<>();

  Map<String, Image> cs2KeyArtwork = new ConcurrentHashMap<>();

  Image cs2Background, cs2BlurredBackground;

  static final BigDecimal CS2_KEY_PRICE = new BigDecimal("2.49");

  Image cs2DefaultCt, cs2DefaultT;

  String cs2InventorySort = "Quality";

  int cs2TradeUpPage;

  String cs2TradeUpQuery = "", cs2TradeUpQuality = "All";

  final long exchangeRunSeed = System.nanoTime();

  Map<String, Integer> exchangeStockPlan = new LinkedHashMap<>();

  Set<String> exchangeSeededBuckets = new HashSet<>();

  Map<String, CaseType> exchangeContainers = new ConcurrentHashMap<>();

  Map<String, List<MarketListing>> exchangeSiteStock = new ConcurrentHashMap<>();

  volatile long exchangeGeneratedStock, exchangePlannedStock;

  JTabbedPane exchangeHostSections;

  InventoryItem exchangePendingSale;

  String cs2EquipFilter;

  boolean cs2EquipT;

  OwnedSupply cs2UnlockSelection;

  final Map<String, JPanel> exchangeOpenSites = new HashMap<>();

  final Map<String, Runnable> exchangeSiteRefresh = new HashMap<>();

  static final double[] EXCHANGE_WEIGHTS = {
    23, 10, 11, 8, 3, 6, 2, 5, 16, 4, 2, 2, 3.5, 1.5, 1, 1, 1.3, .7
  };

  String cs2SelectedOpeningContainer, cs2SelectedOpeningKey;

  static final Map<String, String[]> CS2_KEY_CATALOG = UiCatalogData.createCs2KeyCatalog();

  int cs2SceneryIndex =
      Math.max(
          0,
          Math.min(
              9,
              Preferences.userNodeForPackage(hGui.class).node("interface").getInt("scenery", 0)));

  static final String[] CS2_SCENERY_NAMES = {
    "Dust II",
    "Mirage",
    "Inferno",
    "Nuke",
    "Train",
    "Ancient",
    "Anubis",
    "Vertigo",
    "Overpass",
    "Office"
  };

  static final String[] CS2_SCENERY_0 = Scenery0.DATA;

  static final String[] CS2_SCENERY_1 = Scenery1.DATA;

  static final String[] CS2_SCENERY_2 = Scenery2.DATA;

  static final String[] CS2_SCENERY_3 = Scenery3.DATA;

  static final String[] CS2_SCENERY_4 = Scenery4.DATA;

  static final String[] CS2_SCENERY_5 = Scenery5.DATA;

  static final String[] CS2_SCENERY_6 = Scenery6.DATA;

  static final String[] CS2_SCENERY_7 = Scenery7.DATA;

  static final String[] CS2_SCENERY_8 = Scenery8.DATA;

  static final String[] CS2_SCENERY_9 = Scenery9.DATA;

  static final String[][] CS2_SCENERY_DATA = {
    hGui.CS2_SCENERY_0,
    hGui.CS2_SCENERY_1,
    hGui.CS2_SCENERY_2,
    hGui.CS2_SCENERY_3,
    hGui.CS2_SCENERY_4,
    hGui.CS2_SCENERY_5,
    hGui.CS2_SCENERY_6,
    hGui.CS2_SCENERY_7,
    hGui.CS2_SCENERY_8,
    hGui.CS2_SCENERY_9
  };

  static final Map<String, String> CS2_DEFAULT_WEAPONS = UiCatalogData.createCs2DefaultWeapons();

  static final Map<String, String> DOPPLER_FILES = new HashMap<>();

  static {
    DOPPLER_FILES.put("Karambit | Doppler (Phase 1)", "karamp1.png");
    DOPPLER_FILES.put("Karambit | Doppler (Phase 2)", "karamp2.png");
    DOPPLER_FILES.put("Karambit | Doppler (Phase 3)", "karamp3.png");
    DOPPLER_FILES.put("Karambit | Doppler (Phase 4)", "karamp4.png");
    DOPPLER_FILES.put("Karambit | Doppler (Sapphire)", "sapphirekaram.png");
    DOPPLER_FILES.put("Karambit | Doppler (Ruby)", "rubykaram.png");
    DOPPLER_FILES.put("Karambit | Doppler (Black Pearl)", "blackpearlkaram.png");
    DOPPLER_FILES.put("M9 Bayonet | Doppler (Phase 1)", "mninep1.png");
    DOPPLER_FILES.put("M9 Bayonet | Doppler (Phase 2)", "mninep2.png");
    DOPPLER_FILES.put("M9 Bayonet | Doppler (Phase 3)", "mninep3.png");
    DOPPLER_FILES.put("M9 Bayonet | Doppler (Phase 4)", "mninep4.png");
    DOPPLER_FILES.put("M9 Bayonet | Doppler (Sapphire)", "sapphiremnine.png");
    DOPPLER_FILES.put("M9 Bayonet | Doppler (Ruby)", "rubymnine.png");
    DOPPLER_FILES.put("M9 Bayonet | Doppler (Black Pearl)", "blackpearlmnine.png");
    DOPPLER_FILES.put("Butterfly Knife | Doppler (Phase 1)", "butterflydopplerphase1.png");
    DOPPLER_FILES.put("Butterfly Knife | Doppler (Phase 2)", "butterflydopplerphase2.png");
    DOPPLER_FILES.put("Butterfly Knife | Doppler (Phase 3)", "butterflydopplerphase3.png");
    DOPPLER_FILES.put("Butterfly Knife | Doppler (Phase 4)", "butterflydopplerphase4.png");
    DOPPLER_FILES.put("Butterfly Knife | Doppler (Sapphire)", "butterflysapphire.png");
    DOPPLER_FILES.put("Butterfly Knife | Doppler (Ruby)", "butterflyruby.png");
    DOPPLER_FILES.put("Butterfly Knife | Doppler (Black Pearl)", "butterflyblackpearl.png");
    DOPPLER_FILES.put(
        "Butterfly Knife | Gamma Doppler (Phase 1)", "butterflygammadopplerphase1.png");
    DOPPLER_FILES.put(
        "Butterfly Knife | Gamma Doppler (Phase 2)", "butterflygammadopplerphase2.png");
    DOPPLER_FILES.put(
        "Butterfly Knife | Gamma Doppler (Phase 3)", "butterflygammadopplerphase3.png");
    DOPPLER_FILES.put(
        "Butterfly Knife | Gamma Doppler (Phase 4)", "butterflygammadopplerphase4.png");
    DOPPLER_FILES.put("Butterfly Knife | Gamma Doppler (Emerald)", "butterflyemerald.png");
  }

  @Override
  public void paint(Graphics g) {
    super.paint(g);
  }

  static final Map<String, Integer> CONTAINER_RELEASE_DATES =
      Map.ofEntries(
          Map.entry("Huntsman Weapon Case", 20140502),
          Map.entry("CS:GO Weapon Case", 20130814),
          Map.entry("eSports 2013 Case", 20130814),
          Map.entry("Operation Bravo Case", 20130920),
          Map.entry("CS:GO Weapon Case 2", 20131108),
          Map.entry("eSports 2013 Winter Case", 20131219),
          Map.entry("Winter Offensive Weapon Case", 20131219),
          Map.entry("CS:GO Weapon Case 3", 20140213),
          Map.entry("Operation Phoenix Weapon Case", 20140221),
          Map.entry("Operation Breakout Weapon Case", 20140623),
          Map.entry("eSports 2014 Summer Case", 20140710),
          Map.entry("Operation Vanguard Weapon Case", 20141112),
          Map.entry("Chroma Case", 20150108),
          Map.entry("Chroma 2 Case", 20150415),
          Map.entry("Falchion Case", 20150528),
          Map.entry("Shadow Case", 20150915),
          Map.entry("Revolver Case", 20151130),
          Map.entry("Operation Wildfire Case", 20160119),
          Map.entry("Chroma 3 Case", 20160419),
          Map.entry("Gamma Case", 20160610),
          Map.entry("Gamma 2 Case", 20160808),
          Map.entry("Glove Case", 20161102),
          Map.entry("Spectrum Case", 20170301),
          Map.entry("Operation Hydra Case", 20170421),
          Map.entry("Spectrum 2 Case", 20170906),
          Map.entry("Clutch Case", 20171220),
          Map.entry("Horizon Case", 20180607),
          Map.entry("Danger Zone Case", 20181207),
          Map.entry("Prisma Case", 20190305),
          Map.entry("Shattered Web Case", 20191119),
          Map.entry("CS20 Case", 20191014),
          Map.entry("Prisma 2 Case", 20200331),
          Map.entry("Fracture Case", 20200713),
          Map.entry("Operation Broken Fang Case", 20201203),
          Map.entry("Snakebite Case", 20210504),
          Map.entry("Operation Riptide Case", 20210922),
          Map.entry("Dreams & Nightmares Case", 20220121),
          Map.entry("Recoil Case", 20220704),
          Map.entry("Revolution Case", 20230210),
          Map.entry("Kilowatt Case", 20240207),
          Map.entry("Gallery Case", 20241002),
          Map.entry("Fever Case", 20250331),
          Map.entry("Sealed Genesis Terminal", 20250916),
          Map.entry("Sealed Dead Hand Terminal", 20260311));

  final Map<String, DevCaseOverride> devCaseOverrides = new HashMap<>();

  boolean devFreeCaseOpenings;

  double currentOpeningCost;

  boolean goldTradeUpMode;

  static final int INVENTORY_PAGE_SIZE = 60;

  static final int INVENTORY_CARD_CACHE_SIZE = 180;

  final ArrayList<InventoryItem> tradeUpSelection = new ArrayList<>();

  static final String[] T_SLOTS_PISTOL = {"Glock-18"};

  static final String[] T_SLOTS_OTHER = {
    "Tec-9", "Desert Eagle", "P250", "CZ75-Auto", "Dual Berettas", "R8 Revolver"
  };

  static final String[] T_SLOTS_SMG = {"MAC-10", "P90", "UMP-45", "PP-Bizon", "MP7", "MP5-SD"};

  static final String[] T_SLOTS_HEAVY = {"XM1014", "Nova", "Sawed-Off", "Negev", "M249"};

  static final String[] T_SLOTS_RIFLE = {"AK-47", "Galil AR", "SG 553", "AWP", "SSG 08", "G3SG1"};

  static final String[] CT_SLOTS_PISTOL = {"USP-S", "P2000"};

  static final String[] CT_SLOTS_OTHER = {
    "P250", "Five-SeveN", "CZ75-Auto", "Desert Eagle", "R8 Revolver", "Dual Berettas"
  };

  static final String[] CT_SLOTS_SMG = {"MP9", "MP7", "MP5-SD", "UMP-45", "P90", "PP-Bizon"};

  static final String[] CT_SLOTS_HEAVY = {"Nova", "XM1014", "MAG-7", "M249", "Negev"};

  static final String[] CT_SLOTS_RIFLE = {
    "FAMAS", "M4A4", "M4A1-S", "AUG", "SSG 08", "AWP", "SCAR-20"
  };

  static final String AGENT_SLOT_T = "Agent_T";

  static final String AGENT_SLOT_CT = "Agent_CT";

  int loadoutSelectedSide = 0;

  int loadoutScrollYT = 0;

  int loadoutScrollYCT = 0;

  JScrollPane loadoutScrollPaneT = null;

  JScrollPane loadoutScrollPaneCT = null;

  String loadoutVisibilityFilter = "All Slots";

  public void actionPerformed(ActionEvent e) {
    generalScreen.actionPerformed(e);
  }

  static final TradeUpCollection[] TRADE_UP_COLLECTIONS = {
    new TradeUpCollection(
        "Weapon Case One",
        new String[] {"MP7 | Skulls", "AUG | Wings", "SG 553 | Ultraviolet"},
        new String[] {"Glock-18 | Dragon Tattoo", "M4A1-S | Dark Water", "USP-S | Dark Water"},
        new String[] {"Desert Eagle | Hypnotic", "AK-47 | Case Hardened"},
        new String[] {"AWP | Lightning Strike"}),
    new TradeUpCollection(
        "Bravo Collection",
        new String[] {
          "Galil AR | Shattered",
          "SG 553 | Wave Spray",
          "G3SG1 | Demeter",
          "Nova | Tempest",
          "Dual Berettas | Black Limba"
        },
        new String[] {
          "MAC-10 | Graven", "M4A1-S | Bright Water", "M4A4 | Zirka", "USP-S | Overgrowth"
        },
        new String[] {"AWP | Graphite", "P90 | Emerald Dragon", "P2000 | Ocean Foam"},
        new String[] {"Desert Eagle | Golden Koi", "AK-47 | Fire Serpent"}),
    new TradeUpCollection(
        "Breakout Collection",
        new String[] {
          "Negev | Desert-Strike",
          "UMP-45 | Labyrinth",
          "P2000 | Ivory",
          "MP7 | Urban Hazard",
          "SSG 08 | Abyss"
        },
        new String[] {"Nova | Koi", "PP-Bizon | Osiris", "CZ75-Auto | Tigris", "P250 | Supernova"},
        new String[] {
          "Five-SeveN | Fowl Play", "Desert Eagle | Conspiracy", "Glock-18 | Water Elemental"
        },
        new String[] {"P90 | Asiimov", "M4A1-S | Cyrex"}),
    new TradeUpCollection(
        "Spectrum Collection",
        new String[] {
          "Desert Eagle | Oxide Blaze",
          "Five-SeveN | Capillary",
          "SCAR-20 | Blueprint",
          "P250 | Ripple",
          "MP7 | Akoben",
          "Sawed-Off | Zander",
          "PP-Bizon | Jungle Slipstream"
        },
        new String[] {
          "Galil AR | Crimson Tsunami",
          "XM1014 | Seasons",
          "UMP-45 | Scaffold",
          "MAC-10 | Last Dive",
          "M249 | Emerald Poison Dart"
        },
        new String[] {"M4A1-S | Decimator", "AWP | Fever Dream", "CZ75-Auto | Xiangliu"},
        new String[] {"USP-S | Neo Noir", "AK-47 | Bloodsport"}),
    new TradeUpCollection(
        "Kilowatt Collection",
        new String[] {
          "MAC-10 | Light Box",
          "Nova | Dark Sigil",
          "Dual Berettas | Hideout",
          "SSG 08 | Dezastre",
          "UMP-45 | Motorized",
          "Tec-9 | Slag",
          "XM1014 | Irezumi"
        },
        new String[] {
          "M4A4 | Etch Lord",
          "Glock-18 | Block-18",
          "Five-SeveN | Hybrid",
          "MP7 | Just Smile",
          "Sawed-Off | Analog Input"
        },
        new String[] {"M4A1-S | Black Lotus", "USP-S | Jawbreaker", "Zeus x27 | Olympus"},
        new String[] {"AK-47 | Inheritance", "AWP | Chrome Cannon"}),
    new TradeUpCollection(
        "Revolution Collection",
        new String[] {
          "MP9 | Featherweight",
          "MAG-7 | Insomnia",
          "P250 | Re.built",
          "MP5-SD | Liquidation",
          "SCAR-20 | Fragments",
          "SG 553 | Cyberforce",
          "Tec-9 | Rebel"
        },
        new String[] {
          "M4A1-S | Emphorosaur-S",
          "Glock-18 | Umbral Rabbit",
          "MAC-10 | Sakkaku",
          "P90 | Neoqueen",
          "R8 Revolver | Banana Cannon"
        },
        new String[] {"AWP | Duality", "P2000 | Wicked Sick", "UMP-45 | Wild Child"},
        new String[] {"M4A4 | Temukau", "AK-47 | Head Shot"}),
  };

  static final Map<String, FloatRange> FLOAT_LIMITS = FloatLimitsData.DATA;

  static final Map<String, List<Integer>> FLIP_KNIFE_BG =
      Map.of(
          "T1", List.of(670),
          "T2", List.of(321, 151, 592, 661, 555),
          "T3", List.of(828, 955, 179, 387, 844, 168, 868, 363, 791, 750, 823, 103, 760),
          "T4",
              List.of(
                  557, 426, 935, 892, 349, 575, 704, 648, 888, 724, 147, 481, 403, 450, 850, 775,
                  281, 82, 428, 396, 497, 795, 126, 2, 525, 344, 985, 81, 512, 468, 381, 74, 434,
                  849, 862, 847, 809, 310, 698, 447, 927, 65, 790, 948, 685, 453, 200, 978, 236,
                  970, 894, 306, 235, 645, 950, 172, 139, 519, 202, 333, 14, 149, 782, 814, 227,
                  463, 617, 9, 397, 389, 92, 178, 442, 493, 470, 708, 215, 261, 627, 443, 622, 564,
                  122, 34, 286, 187, 806, 843, 242, 558, 788));

  static final Map<String, List<Integer>> M9_BG =
      Map.of(
          "T1", List.of(601, 58, 150, 239, 349, 403, 406, 417, 503, 523, 585, 634, 675, 897),
          "T2",
              List.of(
                  21, 91, 107, 117, 166, 167, 202, 224, 253, 269, 281, 288, 336, 346, 354, 355, 366,
                  430, 449, 517, 550, 613, 628, 715, 793, 813, 867, 880, 946),
          "T3",
              List.of(
                  4, 41, 59, 88, 108, 124, 141, 157, 173, 204, 210, 227, 229, 243, 249, 286, 293,
                  295, 298, 319, 345, 356, 372, 393, 476, 490, 525, 529, 533, 546, 553, 598, 610,
                  790, 821, 837, 859, 866, 887, 908, 910, 915, 933, 959),
          "T4",
              List.of(
                  2, 63, 64, 97, 103, 113, 136, 138, 156, 162, 176, 177, 179, 209, 246, 251, 292,
                  308, 351, 353, 369, 401, 413, 445, 473, 475, 496, 506, 507, 516, 518, 524, 526,
                  556, 564, 573, 619, 632, 651, 674, 681, 698, 706, 735, 759, 764, 779, 783, 794,
                  808, 811, 835, 869, 871, 902, 904, 916, 941, 963, 968, 989));

  static final Map<String, List<Integer>> AK_BG =
      Map.of(
          "T1", List.of(661, 151, 168, 179, 321, 387, 555, 592, 617, 670, 760, 809, 828, 955),
          "T2",
              List.of(
                  4, 13, 28, 32, 65, 74, 81, 82, 92, 103, 122, 139, 147, 172, 189, 205, 228, 256,
                  323, 341, 426, 430, 442, 463, 479, 512, 525, 526, 532, 541, 571, 578, 605, 627,
                  695, 698, 708, 713, 750, 752, 791, 844, 868, 887, 888, 892, 903, 905, 922, 950,
                  969, 978, 996),
          "T3",
              List.of(
                  34, 112, 278, 310, 312, 363, 381, 413, 428, 429, 450, 519, 557, 586, 610, 647,
                  685, 689, 690, 733, 754, 770, 819, 823, 856, 862, 872, 878, 935, 1000));

  static final Map<String, List<Integer>> BUTTERFLY_BG =
      Map.of(
          "T1", List.of(182, 494, 838),
          "T2", List.of(194, 283, 694, 703, 838, 891, 913, 917),
          "T3",
              List.of(
                  29, 194, 214, 263, 283, 330, 371, 396, 398, 478, 488, 494, 510, 612, 638, 652,
                  694, 703, 717, 749, 800, 868, 881, 891, 913, 917, 928),
          "T4",
              List.of(
                  27, 38, 42, 43, 61, 72, 73, 78, 92, 98, 112, 130, 147, 256, 282, 318, 320, 335,
                  358, 407, 411, 424, 426, 457, 458, 474, 499, 515, 534, 618, 628, 629, 642, 643,
                  655, 664, 702, 705, 711, 721, 767, 768, 770, 782, 798, 799, 808, 811, 839, 846,
                  858, 872, 885, 902, 907, 913, 919, 924, 958, 964, 965));

  static final Map<String, List<Integer>> KUKRI_BG =
      Map.of(
          "T1",
              List.of(
                  494, 575, 770, 652, 618, 917, 844, 112, 891, 838, 868, 510, 330, 631, 985, 808),
          "T2", List.of(130, 283, 335, 721, 798, 702, 841, 371, 38, 881, 638, 811, 643, 682, 61),
          "T3",
              List.of(
                  468, 664, 182, 629, 989, 488, 334, 823, 426, 282, 73, 515, 694, 547, 916, 858,
                  749, 854, 630, 499, 375, 256, 442, 961, 116, 919, 306, 902, 853, 522, 776, 411,
                  92, 809, 262, 612, 885, 505, 398, 528, 194, 576, 711, 642, 883, 768, 708, 34, 414,
                  347, 657, 14, 713, 74, 698, 453, 273, 89, 188, 457, 98, 907, 616, 800, 42, 263,
                  243, 244, 175, 318, 305, 134, 281),
          "T4",
              List.of(
                  803, 782, 788, 497, 269, 322, 964, 965, 176, 321, 236, 108, 658, 56, 905, 470,
                  310, 556, 214, 860, 20, 27, 622, 445, 976, 72, 927, 875, 4, 387, 852, 429, 828,
                  177, 341, 753, 557, 147, 458, 507, 311, 849, 816, 953, 633, 153, 955, 109, 866,
                  191, 899, 541, 888, 609, 846, 924, 935, 106, 598, 55, 509, 914, 25, 775, 637, 670,
                  358, 958, 741, 942, 57, 381, 138, 245, 397, 820, 801, 513, 208, 542, 780, 563,
                  596, 179, 339, 320, 377, 11, 395, 101, 655, 717, 700, 254, 53, 672, 29, 168, 928,
                  365, 727, 85, 826, 297, 918, 463, 483, 527, 416, 893, 248, 478, 545, 697, 548,
                  396));

  final Map<String, Double> basePriceCache =
      new java.util.LinkedHashMap<String, Double>(256, 0.75f, true) {
        protected boolean removeEldestEntry(Map.Entry<String, Double> e) {
          return size() > 300;
        }
      };

  static final Pattern MARKET_NUMERIC_PRICE = Pattern.compile("\\d+(?:\\.\\d+)?");

  final Map<String, String> caseQuoteDescriptions = new ConcurrentHashMap<>();

  final Set<String> verifiedCaseQuotes = ConcurrentHashMap.newKeySet();

  boolean caseQuotesResolved;

  int runtimeRestockCursor;

  final Map<String, String> rarityCache = new ConcurrentHashMap<>();

  final Set<String> armourySkinNameCache = new HashSet<>();

  boolean armouryCacheBuilt = false;

  final Set<String> souvenirPackageSkinNameCache = ConcurrentHashMap.newKeySet();

  volatile boolean souvenirPackageSkinCacheBuilt = false;

  static final int MARKET_HOME_UNBOX_MIN_INTERVAL = 30;

  static final int MARKET_HOME_UNBOX_MAX_INTERVAL = 150;

  static final int MARKET_HOME_SOLD_MIN_INTERVAL = 30;

  static final int MARKET_HOME_SOLD_MAX_INTERVAL = 150;

  final Set<MarketHomeUnboxFeed> activeHomeArtworkFeeds = ConcurrentHashMap.newKeySet();

  static final int MARKET_HOME_UNBOX_ROWS = 6;

  volatile List<MarketplaceOfferAggregate> marketplaceSummarySnapshot =
      java.util.Collections.emptyList();

  volatile int trackedMarketSkinCount;

  static final Map<String, String> SKIN_TO_FILE;

  static {
    SKIN_TO_FILE = new HashMap<>();
    SKIN_TO_FILE.put("Karambit | Slaughter", "karam.png");
    SKIN_TO_FILE.put("M9 Bayonet | Crimson Web", "mnine.png");
    SKIN_TO_FILE.put("Flip Knife | Vanilla", "flipvanil.png");
    SKIN_TO_FILE.put("Gut Knife | Fade", "gutfade.png");
    SKIN_TO_FILE.put("Bayonet | Scorched", "bayscorch.png");
    SKIN_TO_FILE.put("Bayonet | Boreal Forest", "1bayoboreal.png");
    SKIN_TO_FILE.put("Bayonet | Fade", "1bayofade.png");
    SKIN_TO_FILE.put("Flip Knife | Case Hardened", "1flipcasehard.png");
    SKIN_TO_FILE.put("Gut Knife | Forest DDPAT", "1gutforestddpat.png");
    SKIN_TO_FILE.put("Gut Knife | Safari Mesh", "1gutsafari.png");
    SKIN_TO_FILE.put("Karambit | Night", "1karambluesteel.png");
    SKIN_TO_FILE.put("Karambit | Crimson Web", "1karamcrimson.png");
    SKIN_TO_FILE.put("Karambit | Scorched", "1karamscorched.png");
    SKIN_TO_FILE.put("Karambit | Urban Masked", "1karamurban.png");
    SKIN_TO_FILE.put("M9 Bayonet | Blue Steel", "1mninebluesteel.png");
    SKIN_TO_FILE.put("M9 Bayonet | Case Hardened", "1mninecasehard.png");
    SKIN_TO_FILE.put("M9 Bayonet | Slaughter", "1mnineslaughter.png");
    SKIN_TO_FILE.put("Butterfly Knife | Case Hardened", "butterflycasehard.png");
    SKIN_TO_FILE.put("Butterfly Knife | Crimson Web", "butterflycrimsonweb.png");
    SKIN_TO_FILE.put("Butterfly Knife | Fade", "butterflyfade.png");
    SKIN_TO_FILE.put("Butterfly Knife | Safari Mesh", "butterflysafari.png");
    SKIN_TO_FILE.put("Butterfly Knife | Slaughter", "butterflyslaughter.png");
    SKIN_TO_FILE.put("Butterfly Knife | Urban Masked", "butterflyurban.png");
    SKIN_TO_FILE.put("Butterfly Knife | Vanilla", "butterflyvanilla.png");
    SKIN_TO_FILE.put("Butterfly Knife | Doppler", "butterflydopplerphase1.png");
    SKIN_TO_FILE.put("Butterfly Knife | Gamma Doppler", "butterflygammadopplerphase1.png");
    SKIN_TO_FILE.put("Butterfly Knife | Marble Fade", "butterflymarblefade.png");
    SKIN_TO_FILE.put("Butterfly Knife | Lore", "butterflylore.png");
    SKIN_TO_FILE.put("Kukri Knife | Urban Masked", "kukriurbanmasked.png");
    SKIN_TO_FILE.put("Kukri Knife | Stained", "kukristained.png");
    SKIN_TO_FILE.put("Kukri Knife | Slaughter", "kukrislaughter.png");
    SKIN_TO_FILE.put("Kukri Knife | Scorched", "kukriscorched.png");
    SKIN_TO_FILE.put("Kukri Knife | Safari Mesh", "kukrisafarimesh.png");
    SKIN_TO_FILE.put("Kukri Knife | Night Stripe", "kukrinightstripe.png");
    SKIN_TO_FILE.put("Kukri Knife | Fade", "kukrifade.png");
    SKIN_TO_FILE.put("Kukri Knife | Crimson Web", "kukricrimsonweb.png");
    SKIN_TO_FILE.put("Kukri Knife | Case Hardened", "kukricasehardened.png");
    SKIN_TO_FILE.put("AWP | Lightning Strike", "covertcasedone1.png");
    SKIN_TO_FILE.put("Desert Eagle | Golden Koi", "covertcasedone1 (1).png");
    SKIN_TO_FILE.put("AK-47 | Fire Serpent", "covertcasedone2.png");
    SKIN_TO_FILE.put("P90 | Asiimov", "breakoutp90asi.png");
    SKIN_TO_FILE.put("M4A1-S | Cyrex", "breakoutcyrex.png");

    SKIN_TO_FILE.put("Desert Eagle | Hypnotic", "classifiedcasedone1.png");
    SKIN_TO_FILE.put("P90 | Emerald Dragon", "classifiedcasedone1 (1).png");
    SKIN_TO_FILE.put("AK-47 | Case Hardened", "classifiedcasedone2.png");
    SKIN_TO_FILE.put("P2000 | Ocean Foam", "classifiedcasedone2 (1).png");
    SKIN_TO_FILE.put("AWP | Graphite", "classifiedcasedone3.png");
    SKIN_TO_FILE.put("Five-SeveN | Fowl Play", "breakoutfiveseven.png");
    SKIN_TO_FILE.put("Desert Eagle | Conspiracy", "breakoutdeagle.png");
    SKIN_TO_FILE.put("Glock-18 | Water Elemental", "breakoutwaterele.png");

    SKIN_TO_FILE.put("Glock-18 | Dragon Tattoo", "restrictedcasedone1.png");
    SKIN_TO_FILE.put("MAC-10 | Graven", "restrictedcasedone1 (1).png");
    SKIN_TO_FILE.put("M4A1-S | Dark Water", "restrictedcasedone2.png");
    SKIN_TO_FILE.put("M4A1-S | Bright Water", "restrictedcasedone2 (1).png");
    SKIN_TO_FILE.put("USP-S | Dark Water", "restrictedcasedone3.png");
    SKIN_TO_FILE.put("M4A4 | Zirka", "restrictedcasedone3 (1).png");
    SKIN_TO_FILE.put("USP-S | Overgrowth", "restrictedcasedone4.png");
    SKIN_TO_FILE.put("Nova | Koi", "breakoutnovakoi.png");
    SKIN_TO_FILE.put("PP-Bizon | Osiris", "breakoutppbizon.png");
    SKIN_TO_FILE.put("CZ75-Auto | Tigris", "breakoutcztigris.png");
    SKIN_TO_FILE.put("P250 | Supernova", "breakoutp250supernova.png");

    SKIN_TO_FILE.put("MP7 | Skulls", "milcasedone1.png");
    SKIN_TO_FILE.put("AUG | Wings", "milcasedone2.png");
    SKIN_TO_FILE.put("Galil AR | Shattered", "milcasedone2 (1).png");
    SKIN_TO_FILE.put("SG 553 | Ultraviolet", "milcasedone3.png");
    SKIN_TO_FILE.put("SG 553 | Wave Spray", "milcasedone3 (1).png");
    SKIN_TO_FILE.put("G3SG1 | Demeter", "milcasedone4.png");
    SKIN_TO_FILE.put("Nova | Tempest", "milcasedone5.png");
    SKIN_TO_FILE.put("Dual Berettas | Black Limba", "milcasedone6.png");
    SKIN_TO_FILE.put("Negev | Desert-Strike", "breakoutnegevdesert.png");
    SKIN_TO_FILE.put("UMP-45 | Labyrinth", "breakoutump45lab.png");
    SKIN_TO_FILE.put("P2000 | Ivory", "breakoutp2000ivory.png");
    SKIN_TO_FILE.put("MP7 | Urban Hazard", "breakoutmp7urbanhazard.png");
    SKIN_TO_FILE.put("SSG 08 | Abyss", "breakoutsgg08abyss.png");
    SKIN_TO_FILE.put("Butterfly Knife | Ultraviolet", "butterflyultraviolet.png");
    SKIN_TO_FILE.put("Huntsman Knife | Marble Fade", "huntsmanmarblefade.png");
    SKIN_TO_FILE.put("Huntsman Knife | Tiger Tooth", "huntsmantigertooth.png");
    SKIN_TO_FILE.put("Bowie Knife | Marble Fade", "bowiemarblefade.png");
    SKIN_TO_FILE.put("Bowie Knife | Urban Masked", "bowieurbanmasked.png");
    SKIN_TO_FILE.put("Bowie Knife | Stained", "bowiestained.png");
    SKIN_TO_FILE.put("Bowie Knife | Scorched", "bowiescorched.png");
    SKIN_TO_FILE.put("Bowie Knife | Lore", "bowielore.png");
    SKIN_TO_FILE.put("Bowie Knife | Forest DDPAT", "bowieforestddpat.png");
    SKIN_TO_FILE.put("Bowie Knife | Fade", "bowiefade.png");
    SKIN_TO_FILE.put("Bowie Knife | Crimson Web", "bowiecrimsonweb.png");
    SKIN_TO_FILE.put("Bowie Knife | Boreal Forest", "bowieborealforest.png");
    SKIN_TO_FILE.put("Bowie Knife | Blue Steel", "bowiebluesteel.png");
    SKIN_TO_FILE.put("Bowie Knife | Black Laminate", "bowieblacklaminate.png");
    SKIN_TO_FILE.put("Bowie Knife | Tiger Tooth", "bowietigertooth.png");
    SKIN_TO_FILE.put("Falchion Knife | Marble Fade", "falchionmarblefade.png");
    SKIN_TO_FILE.put("Falchion Knife | Tiger Tooth", "falchiontigertooth.png");

    SKIN_TO_FILE.put("AK-47 | Bloodsport", "specakbloodsport.png");
    SKIN_TO_FILE.put("USP-S | Neo Noir", "specneonoir.png");
    SKIN_TO_FILE.put("AK-47 | Inheritance", "kiloak47inheritance.png");
    SKIN_TO_FILE.put("AWP | Chrome Cannon", "kiloawpchromecannon.png");
    SKIN_TO_FILE.put("M4A1-S | Black Lotus", "kilom4a1sblacklotus.png");
    SKIN_TO_FILE.put("USP-S | Jawbreaker", "kilouspsjawbreaker.png");
    SKIN_TO_FILE.put("Zeus x27 | Olympus", "kilozeusx27olympus.png");
    SKIN_TO_FILE.put("M4A4 | Etch Lord", "kilom4a4etchlord.png");
    SKIN_TO_FILE.put("Glock-18 | Block-18", "kiloglock18block18.png");
    SKIN_TO_FILE.put("Five-SeveN | Hybrid", "kilofivesevenhybrid.png");
    SKIN_TO_FILE.put("MP7 | Just Smile", "kilomp7justsmile.png");
    SKIN_TO_FILE.put("Sawed-Off | Analog Input", "kilosawedoffanaloginput.png");
    SKIN_TO_FILE.put("MAC-10 | Light Box", "kilomac10lightbox.png");
    SKIN_TO_FILE.put("Nova | Dark Sigil", "kilonovadarksigil.png");
    SKIN_TO_FILE.put("Dual Berettas | Hideout", "kilodualberettashideout.png");
    SKIN_TO_FILE.put("SSG 08 | Dezastre", "kilossg08dezastre.png");
    SKIN_TO_FILE.put("UMP-45 | Motorized", "kiloump45motorized.png");
    SKIN_TO_FILE.put("Tec-9 | Slag", "kilotec9slag.png");
    SKIN_TO_FILE.put("XM1014 | Irezumi", "kiloxm1014irezumi.png");

    SKIN_TO_FILE.put("CZ75-Auto | Xiangliu", "speccz75autoxiangliu.png");
    SKIN_TO_FILE.put("AWP | Fever Dream", "specawpfeverdream.png");
    SKIN_TO_FILE.put("M4A1-S | Decimator", "specm4a1sdecimator.png");

    SKIN_TO_FILE.put("M249 | Emerald Poison Dart", "specM249emeraldpoisondart.png");
    SKIN_TO_FILE.put("MAC-10 | Last Dive", "specmac10lastdive.png");
    SKIN_TO_FILE.put("UMP-45 | Scaffold", "specump45scaffold.png");
    SKIN_TO_FILE.put("XM1014 | Seasons", "specxm1014seasons.png");
    SKIN_TO_FILE.put("Galil AR | Crimson Tsunami", "specgalilcrimsontsunami.png");

    SKIN_TO_FILE.put("PP-Bizon | Jungle Slipstream", "specppbizonjungleslipstream.png");
    SKIN_TO_FILE.put("Sawed-Off | Zander", "specsawedoffzander.png");
    SKIN_TO_FILE.put("MP7 | Akoben", "specmp7akoben.png");
    SKIN_TO_FILE.put("P250 | Ripple", "specp250ripple.png");
    SKIN_TO_FILE.put("SCAR-20 | Blueprint", "specscar20blueprint.png");
    SKIN_TO_FILE.put("Five-SeveN | Capillary", "specfivesevencapillary.png");
    SKIN_TO_FILE.put("Desert Eagle | Oxide Blaze", "specdeagleoxideblaze.png");

    SKIN_TO_FILE.put("Bloodhound Gloves | Bronzed", "bloodhoundglovesbronzed.png");
    SKIN_TO_FILE.put("Bloodhound Gloves | Charred", "bloodhoundglovescharred.png");
    SKIN_TO_FILE.put("Bloodhound Gloves | Guerrilla", "bloodhoundglovesguerrilla.png");
    SKIN_TO_FILE.put("Bloodhound Gloves | Snakebite", "bloodhoundglovessnakebite.png");
    SKIN_TO_FILE.put("Driver Gloves | Convoy", "driverglovesconvoy.png");
    SKIN_TO_FILE.put("Driver Gloves | Crimson Weave", "driverglovescrimsonweave.png");
    SKIN_TO_FILE.put("Driver Gloves | Diamondback", "driverglovesdiamondback.png");
    SKIN_TO_FILE.put("Driver Gloves | Lunar Weave", "drivergloveslunarweave.png");
    SKIN_TO_FILE.put("Hand Wraps | Badlands", "handwrapsbadlands.png");
    SKIN_TO_FILE.put("Hand Wraps | Leather", "handwrapsleather.png");
    SKIN_TO_FILE.put("Hand Wraps | Slaughter", "handwrapsslaughter.png");
    SKIN_TO_FILE.put("Hand Wraps | Spruce DDPAT", "handwrapsspruceddpat.png");
    SKIN_TO_FILE.put("Moto Gloves | Boom!", "motoglovesboom.png");
    SKIN_TO_FILE.put("Moto Gloves | Cool Mint", "motoglovescoolmint.png");
    SKIN_TO_FILE.put("Moto Gloves | Eclipse", "motogloveseclipse.png");
    SKIN_TO_FILE.put("Moto Gloves | Spearmint", "motoglovesspearmint.png");
    SKIN_TO_FILE.put("Specialist Gloves | Crimson Kimono", "specialistglovescrimsonkimono.png");
    SKIN_TO_FILE.put("Specialist Gloves | Emerald Web", "specialistglovesemeraldweb.png");
    SKIN_TO_FILE.put("Specialist Gloves | Forest DDPAT", "specialistglovesforestddpat.png");
    SKIN_TO_FILE.put("Specialist Gloves | Foundation", "specialistglovesfoundation.png");
    SKIN_TO_FILE.put("Sport Gloves | Arid", "sportsglovesarid.png");
    SKIN_TO_FILE.put("Sport Gloves | Hedge Maze", "sportsgloveshedgemaze.png");
    SKIN_TO_FILE.put("Sport Gloves | Pandora's Box", "sportsglovespandorasbox.png");
    SKIN_TO_FILE.put("Sport Gloves | Superconductor", "sportsglovessuperconductor.png");
    SKIN_TO_FILE.put("Hydra Gloves | Rattler", "hydraglovesrattler.png");
    SKIN_TO_FILE.put("Hydra Gloves | Mangrove", "hydraglovesmangrove.png");
    SKIN_TO_FILE.put("Hydra Gloves | Emerald", "hydraglovesemerald.png");
    SKIN_TO_FILE.put("Hydra Gloves | Case Hardened", "hydraglovescasehardened.png");
    SKIN_TO_FILE.put("Hand Wraps | Overprint", "handwrapsoverprint.png");
    SKIN_TO_FILE.put("Hand Wraps | Duct Tape", "handwrapsducttape.png");
    SKIN_TO_FILE.put("Hand Wraps | Cobalt Skulls", "handwrapscobaltskulls.png");
    SKIN_TO_FILE.put("Hand Wraps | Arboreal", "handwrapsarboreal.png");
    SKIN_TO_FILE.put("Driver Gloves | Racing Green", "driverglovesracinggreen.png");
    SKIN_TO_FILE.put("Driver Gloves | Overtake", "driverglovesovertake.png");
    SKIN_TO_FILE.put("Driver Gloves | King Snake", "drivergloveskingsnake.png");
    SKIN_TO_FILE.put("Driver Gloves | Imperial Plaid", "driverglovesimperialplaid.png");
    SKIN_TO_FILE.put("Sport Gloves | Vice", "sportglovesvice.png");
    SKIN_TO_FILE.put("Sport Gloves | Omega", "sportglovesomega.png");
    SKIN_TO_FILE.put("Sport Gloves | Bronze Morph", "sportglovesbronzomorph.png");
    SKIN_TO_FILE.put("Sport Gloves | Amphibious", "sportglovesAmphibious.png");
    SKIN_TO_FILE.put("Specialist Gloves | Mogul", "specialistglovesmogul.png");
    SKIN_TO_FILE.put("Specialist Gloves | Fade", "specialistglovesfade.png");
    SKIN_TO_FILE.put("Specialist Gloves | Crimson Web", "specialistglovescrimsonweb.png");
    SKIN_TO_FILE.put("Specialist Gloves | Buckshot", "specialistglovesbuckshot.png");
    SKIN_TO_FILE.put("Moto Gloves | Turtle", "motoglovesturtle.png");
    SKIN_TO_FILE.put("Moto Gloves | Transport", "motoglovestransport.png");
    SKIN_TO_FILE.put("Moto Gloves | POW!", "motoglovespow!.png");
    SKIN_TO_FILE.put("Moto Gloves | Polygon", "motoglovespolygon.png");

    SKIN_TO_FILE.put("M4A4 | Temukau", "revm4a4temukau.png");
    SKIN_TO_FILE.put("AK-47 | Head Shot", "revak47headshot.png");
    SKIN_TO_FILE.put("AWP | Duality", "revawpduality.png");
    SKIN_TO_FILE.put("P2000 | Wicked Sick", "revp2000wickedsick.png");
    SKIN_TO_FILE.put("UMP-45 | Wild Child", "revump45wildchild.png");
    SKIN_TO_FILE.put("M4A1-S | Emphorosaur-S", "revemphorosaur-s.png");
    SKIN_TO_FILE.put("Glock-18 | Umbral Rabbit", "revglock18umbralrabbit.png");
    SKIN_TO_FILE.put("MAC-10 | Sakkaku", "revmac10sakkaku.png");
    SKIN_TO_FILE.put("P90 | Neoqueen", "revp90neoqueen.png");
    SKIN_TO_FILE.put("R8 Revolver | Banana Cannon", "revr8revolverbananacannon.png");
    SKIN_TO_FILE.put("Tec-9 | Rebel", "revtec9rebel.png");
    SKIN_TO_FILE.put("MP9 | Featherweight", "revmp9featherweight.png");
    SKIN_TO_FILE.put("MAG-7 | Insomnia", "revmag7insomnia.png");
    SKIN_TO_FILE.put("P250 | Re.built", "revp250re,built.png");
    SKIN_TO_FILE.put("MP5-SD | Liquidation", "revmp5sdliquidation.png");
    SKIN_TO_FILE.put("SCAR-20 | Fragments", "revscar20fragments.png");
    SKIN_TO_FILE.put("SG 553 | Cyberforce", "revsg553cyberforce.png");
  }

  static final Map<String, Double> ACHROMA_FALLBACK_BASE_PRICES =
      Map.ofEntries(
          Map.entry("AK-47 | Breakthrough", 1.83),
          Map.entry("AUG | Creep", 0.14),
          Map.entry("AWP | The End", 9.11),
          Map.entry("PP-Bizon | Bizoom", 0.03),
          Map.entry("Desert Eagle | The Daily Deagle", 0.20),
          Map.entry("Dual Berettas | Silver Pour", 0.03),
          Map.entry("FAMAS | Vendetta", 0.03),
          Map.entry("Glock-18 | Trace Lock", 0.80),
          Map.entry("P2000 | Grip Tape", 0.15),
          Map.entry("M249 | Sleet", 0.03),
          Map.entry("M4A4 | Aeolian Dark", 0.03),
          Map.entry("MAC-10 | Snow Splash", 0.03),
          Map.entry("MP5-SD | Snow Splash", 0.03),
          Map.entry("MP9 | Dizzy", 0.03),
          Map.entry("Nova | Currents", 0.03),
          Map.entry("P250 | Sleet", 0.03),
          Map.entry("P90 | Aeolian Light", 0.13),
          Map.entry("R8 Revolver | Dark Chamber", 0.03),
          Map.entry("SCAR-20 | Zinc", 0.03),
          Map.entry("SSG 08 | Sans Comic", 0.03));

  static final String ACHROMA_SKIN_SNAPSHOT = AchromaSkinSnapshotData.DATA;

  static final String[] REQUESTED_MARKET_SKINS = RequestedMarketSkinsData.DATA;

  static final String[] REQUESTED_MARKET_COLLECTIONS = RequestedMarketCollectionsData.DATA;

  final Map<String, TradeUpCollection> requestedMarketCollections = new LinkedHashMap<>();

  final Map<String, Set<String>> requestedMarketSkinCollections = new HashMap<>();

  final Map<String, Double> requestedMarketBasePrices = new HashMap<>();

  static final String TERMINAL_CRATE_SNAPSHOT = TerminalCrateSnapshotData.DATA;

  static final String TERMINAL_SKIN_SNAPSHOT = TerminalSkinSnapshotData.DATA;

  static final String WEAR_IMAGE_SEPARATOR = "\u001fwear=";

  static final String WEAR_IMAGE_ROOT =
      "https://raw.githubusercontent.com/seyfooksck/cs2-skins-list/main/skins/";

  final Map<String, String> artworkNameAliases = new ConcurrentHashMap<>();

  final Map<String, String> wearImageBasePaths = new ConcurrentHashMap<>();

  final Map<String, Long> unavailableRemoteImageUrls = new ConcurrentHashMap<>();

  final Map<String, String[]> availableConditionsCache =
      new java.util.concurrent.ConcurrentHashMap<>();

  static final int SIMULATED_SALE_HISTORY_SIZE = 96;

  final Map<String, SimulatedSalesState> simulatedSalesStates = new ConcurrentHashMap<>();

  final Map<String, List<SimulatedSalesState>> simulatedSalesBySkin = new ConcurrentHashMap<>();

  volatile boolean simulatedSalesReady;

  java.util.concurrent.ScheduledExecutorService simulatedSalesExecutor;

  final Queue<String> fairSalesQueue = new LinkedList<>();

  final Map<String, Integer> fairSaleConditionCursor = new HashMap<>();

  final Map<String, Image> containerArtwork = new ConcurrentHashMap<>();

  final Map<String, String> startupArtworkFallbackDetails = new ConcurrentHashMap<>();

  final Map<String, String> startupArtworkUnavailableDetails = new ConcurrentHashMap<>();

  JButton startupArtworkReportButton;

  volatile Map<String, Image> openingArtwork = java.util.Collections.emptyMap();

  volatile String openingArtworkCaseId;

  boolean openingArtworkPreparing;

  Map<String, ArrayList<MarketListing>> leaderboardSamplingPools;

  long leaderboardSamplingPoolsBuiltAt;

  static final Object[][] ALL_MISSION_TEMPLATES = AllMissionTemplatesData.DATA;

  static final ArmouryCollection[] ARMOURY_COLLECTIONS = ArmouryCollectionsData.DATA;

  static final TradeUpCollection[] ARMOURY_TRADE_UP_COLLECTIONS =
      ArmouryTradeUpCollectionsData.DATA;
}
