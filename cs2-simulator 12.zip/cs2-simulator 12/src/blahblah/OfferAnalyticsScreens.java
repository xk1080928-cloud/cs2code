package blahblah;

import blahblah.hGui.*;
import java.awt.*;
import java.awt.event.*;
import java.util.ArrayList;
import javax.swing.*;

/** Offer Analytics Screens: focused feature implementation. */
final class OfferAnalyticsScreens {
  private final hGui app;

  OfferAnalyticsScreens(hGui app) {
    this.app = app;
  }

  void showMarketplaceOfferWindowAnalytics(
      String skinName, String conditionToken, MarketplaceOfferAggregate offer, JFrame parent) {
    JFrame frame =
        app.offerNeonAndMirageScreens.createMarketplaceFrame(
            offer, skinName, conditionToken, parent, new Color(8, 14, 18));

    frame.add(
        app.offerHeroAndSellerScreens.createOfferHeader(
            offer.marketplaceName + " Live Board",
            skinName + "  ·  " + conditionToken,
            offer,
            "▶ LIVE"),
        BorderLayout.NORTH);

    ArrayList<MarketListing> sorted = app.marketOfferService.getSortedOfferListings(offer);
    double minPrice = sorted.stream().mapToDouble(l -> l.getPrice()).min().orElse(0);
    double maxPrice = sorted.stream().mapToDouble(l -> l.getPrice()).max().orElse(1);
    double avgFloat = sorted.stream().mapToDouble(l -> l.item.itemFloat).average().orElse(0);
    boolean isAgentAnalytics = app.itemMetadataService.isAgentSkin(skinName);

    // ── KPI bar ──
    JPanel kpi = new JPanel(new GridLayout(1, isAgentAnalytics ? 4 : 5, 1, 0));
    kpi.setBackground(new Color(6, 10, 14));
    kpi.setBorder(BorderFactory.createMatteBorder(0, 0, 1, 0, new Color(0, 180, 160)));
    kpi.add(
        app.offerAnalyticsScreens.createTerminalKPI(
            "BEST ASK", "$" + String.format("%.2f", minPrice), new Color(0, 220, 180)));
    kpi.add(
        app.offerAnalyticsScreens.createTerminalKPI(
            "WORST ASK", "$" + String.format("%.2f", maxPrice), new Color(220, 80, 80)));
    if (!isAgentAnalytics) {
      kpi.add(
          app.offerAnalyticsScreens.createTerminalKPI(
              "AVG FLOAT", String.format("%.6f", avgFloat), new Color(0, 180, 160)));
    }
    kpi.add(
        app.offerAnalyticsScreens.createTerminalKPI(
            "DEPTH", sorted.size() + " sellers", new Color(0, 180, 160)));
    kpi.add(
        app.offerAnalyticsScreens.createTerminalKPI(
            "SPREAD", "$" + String.format("%.2f", maxPrice - minPrice), new Color(200, 160, 0)));

    // ── Table header ──
    int colCount = isAgentAnalytics ? 3 : 5;
    JPanel thead = new JPanel(new GridLayout(1, colCount, 0, 0));
    thead.setBackground(new Color(10, 18, 22));
    thead.setBorder(
        BorderFactory.createCompoundBorder(
            BorderFactory.createMatteBorder(0, 0, 1, 0, new Color(0, 80, 70)),
            BorderFactory.createEmptyBorder(6, 14, 6, 14)));
    String[] colHeaders =
        isAgentAnalytics
            ? new String[] {"#", "SELLER", "ASK"}
            : new String[] {"#", "SELLER", "FLOAT", "PATTERN", "ASK"};
    for (String col : colHeaders) {
      JLabel h = new JLabel(col);
      h.setFont(new Font("Consolas", Font.BOLD, 10));
      h.setForeground(new Color(0, 160, 140));
      thead.add(h);
    }

    // ── Table rows ──
    JPanel tbody = new JPanel();
    tbody.setLayout(new BoxLayout(tbody, BoxLayout.Y_AXIS));
    tbody.setBackground(new Color(8, 14, 18));

    for (int i = 0; i < sorted.size(); i++) {
      MarketListing listing = sorted.get(i);
      tbody.add(
          app.offerAnalyticsScreens.createAnalyticsTableRow(
              i + 1, listing, offer, frame, minPrice, maxPrice, isAgentAnalytics));
    }

    JPanel tableWrap = new JPanel(new BorderLayout());
    tableWrap.setBackground(new Color(8, 14, 18));
    tableWrap.add(thead, BorderLayout.NORTH);
    tableWrap.add(tbody, BorderLayout.CENTER);

    JScrollPane scroll = new JScrollPane(tableWrap);
    scroll.setBorder(null);
    scroll.getViewport().setBackground(new Color(8, 14, 18));
    scroll.getVerticalScrollBar().setUnitIncrement(20);

    JPanel center = new JPanel(new BorderLayout());
    center.setBackground(new Color(8, 14, 18));
    center.add(kpi, BorderLayout.NORTH);
    center.add(scroll, BorderLayout.CENTER);
    frame.add(center, BorderLayout.CENTER);
    frame.setVisible(true);
  }

  JPanel createTerminalKPI(String label, String value, Color color) {
    JPanel p = new JPanel(new BorderLayout(0, 4));
    p.setBackground(new Color(10, 16, 20));
    p.setBorder(BorderFactory.createEmptyBorder(12, 16, 12, 16));
    JLabel lbl = new JLabel(label);
    lbl.setFont(new Font("Consolas", Font.PLAIN, 10));
    lbl.setForeground(new Color(80, 120, 120));
    JLabel val = new JLabel(value);
    val.setFont(new Font("Consolas", Font.BOLD, 17));
    val.setForeground(color);
    p.add(lbl, BorderLayout.NORTH);
    p.add(val, BorderLayout.CENTER);
    return p;
  }

  JPanel createAnalyticsTableRow(
      int rank,
      MarketListing listing,
      MarketplaceOfferAggregate offer,
      JFrame parent,
      double minPrice,
      double maxPrice,
      boolean isAgent) {
    int colCount = isAgent ? 3 : 5;
    JPanel row = new JPanel(new GridLayout(1, colCount, 0, 0));
    Color bg = rank % 2 == 0 ? new Color(10, 18, 22) : new Color(8, 14, 18);
    row.setBackground(bg);
    row.setMaximumSize(new Dimension(Integer.MAX_VALUE, 38));
    row.setBorder(BorderFactory.createEmptyBorder(0, 14, 0, 14));

    // Relative price heat: green=cheap, red=expensive
    double pct = maxPrice > minPrice ? (listing.getPrice() - minPrice) / (maxPrice - minPrice) : 0;
    Color priceColor = new Color((int) (80 + pct * 160), (int) (220 - pct * 160), 100);

    row.add(
        app.offerAnalyticsScreens.styledMono(String.format("%02d", rank), new Color(60, 100, 100)));
    row.add(
        app.offerAnalyticsScreens.styledMono(
            listing.sellerName != null ? listing.sellerName : "—", new Color(180, 200, 210)));
    if (!isAgent) {
      row.add(
          app.offerAnalyticsScreens.styledMono(
              String.format("%.6f", listing.item.itemFloat), new Color(0, 180, 160)));
      row.add(
          app.offerAnalyticsScreens.styledMono(
              app.marketOfferService.formatMarketPatternText(listing),
              app.marketOfferService.getMarketPatternColor(listing, new Color(140, 160, 180))));
    }

    JButton buy =
        app.offerNeonAndMirageScreens.createMarketplaceActionButton(
            listing, offer, parent, "$" + String.format("%.2f", listing.getPrice()));
    buy.setBackground(new Color(0, 40, 34));
    buy.setForeground(priceColor);
    buy.setBorder(BorderFactory.createEmptyBorder(4, 8, 4, 8));
    row.add(buy);
    return row;
  }

  JLabel styledMono(String text, Color color) {
    JLabel l = new JLabel(text);
    l.setFont(new Font("Consolas", Font.PLAIN, 12));
    l.setForeground(color);
    return l;
  }

  void showMarketplaceOfferWindowTicketBoard(
      String skinName, String conditionToken, MarketplaceOfferAggregate offer, JFrame parent) {
    JFrame frame =
        app.offerNeonAndMirageScreens.createMarketplaceFrame(
            offer, skinName, conditionToken, parent, new Color(28, 18, 12));
    frame.add(
        app.offerHeroAndSellerScreens.createOfferHeader(
            offer.marketplaceName + " Tickets",
            conditionToken + "  ·  handpicked seller cards",
            offer,
            "Direct Queue"),
        BorderLayout.NORTH);

    JPanel board = new JPanel(new GridLayout(0, 2, 14, 14));
    board.setBackground(new Color(28, 18, 12));
    board.setBorder(BorderFactory.createEmptyBorder(18, 18, 18, 18));
    for (MarketListing listing : app.marketOfferService.getSortedOfferListings(offer)) {
      board.add(app.offerAnalyticsScreens.createTicketCard(listing, offer, frame));
    }

    JScrollPane scroll = new JScrollPane(board);
    scroll.setBorder(null);
    scroll.getViewport().setBackground(new Color(28, 18, 12));
    scroll.getVerticalScrollBar().setUnitIncrement(20);
    frame.add(scroll, BorderLayout.CENTER);
    frame.setVisible(true);
  }

  JPanel createTicketCard(MarketListing listing, MarketplaceOfferAggregate offer, JFrame parent) {
    JPanel card = new JPanel(new BorderLayout(0, 0));
    card.setBackground(new Color(38, 26, 16));
    card.setBorder(
        BorderFactory.createCompoundBorder(
            BorderFactory.createLineBorder(offer.accent, 1),
            BorderFactory.createEmptyBorder(0, 0, 0, 0)));
    card.setMinimumSize(new Dimension(0, 90));
    card.setPreferredSize(new Dimension(0, 90));
    // Main body
    JPanel body = new JPanel(new BorderLayout(10, 0));
    body.setBackground(new Color(38, 26, 16));
    body.setBorder(BorderFactory.createEmptyBorder(14, 14, 14, 0));

    JLabel seller = new JLabel(listing.sellerName != null ? listing.sellerName : "Seller");
    seller.setFont(new Font("Arial", Font.BOLD, 14));
    seller.setForeground(Color.WHITE);
    boolean isAgentTicket = app.itemMetadataService.isAgentSkin(listing.item.name);
    String subText =
        isAgentTicket
            ? "Agent"
            : ("<html>Float: "
                + String.format("%.5f", listing.item.itemFloat)
                + "<br>Pattern "
                + app.marketOfferService.formatMarketPatternText(listing)
                + "</html>");
    JLabel sub = new JLabel(subText);
    sub.setFont(new Font("Consolas", Font.PLAIN, 11));
    sub.setForeground(new Color(180, 140, 100));
    JPanel bodyLeft = new JPanel(new GridLayout(2, 1, 0, 4));
    bodyLeft.setOpaque(false);
    bodyLeft.add(seller);
    bodyLeft.add(sub);
    body.add(bodyLeft, BorderLayout.CENTER);

    // Dashed separator (perforation)
    JPanel sep =
        new JPanel() {
          @Override
          protected void paintComponent(Graphics g) {
            super.paintComponent(g);
            Graphics2D g2 = (Graphics2D) g;
            g2.setColor(new Color(80, 60, 40));
            g2.setStroke(
                new BasicStroke(
                    1, BasicStroke.CAP_BUTT, BasicStroke.JOIN_BEVEL, 0, new float[] {4, 4}, 0));
            g2.drawLine(getWidth() / 2, 4, getWidth() / 2, getHeight() - 4);
          }
        };
    sep.setPreferredSize(new Dimension(16, 0));
    sep.setOpaque(false);

    // Stub (right side)
    JPanel stub = new JPanel(new BorderLayout(0, 6));
    stub.setBackground(new Color(50, 34, 18));
    stub.setPreferredSize(new Dimension(110, 0));
    stub.setBorder(BorderFactory.createEmptyBorder(14, 10, 14, 10));
    JLabel priceStub = new JLabel("$" + String.format("%.2f", listing.getPrice()));
    priceStub.setFont(new Font("Consolas", Font.BOLD, 20));
    priceStub.setForeground(offer.accent);
    priceStub.setHorizontalAlignment(SwingConstants.CENTER);
    JButton buyBtn =
        app.offerNeonAndMirageScreens.createMarketplaceActionButton(
            listing, offer, parent, "BUY NOW");
    buyBtn.setMaximumSize(new Dimension(90, 30));
    stub.add(priceStub, BorderLayout.CENTER);
    stub.add(buyBtn, BorderLayout.SOUTH);

    card.add(body, BorderLayout.CENTER);
    card.add(sep, BorderLayout.CENTER); // layered — actual separator is cosmetic via paint
    card.add(stub, BorderLayout.EAST);
    return card;
  }

  void showMarketplaceOfferWindowSpotlightStack(
      String skinName, String conditionToken, MarketplaceOfferAggregate offer, JFrame parent) {
    JFrame frame =
        app.offerNeonAndMirageScreens.createMarketplaceFrame(
            offer, skinName, conditionToken, parent, new Color(10, 20, 16));
    frame.add(
        app.offerHeroAndSellerScreens.createOfferHeader(
            offer.marketplaceName + " Spotlight",
            skinName + "  ·  storefront stack",
            offer,
            "Fast Stock"),
        BorderLayout.NORTH);

    JPanel stack = new JPanel();
    stack.setLayout(new BoxLayout(stack, BoxLayout.Y_AXIS));
    stack.setBackground(new Color(10, 20, 16));
    stack.setBorder(BorderFactory.createEmptyBorder(16, 16, 16, 16));

    for (MarketListing listing : app.marketOfferService.getSortedOfferListings(offer)) {
      stack.add(app.offerAnalyticsScreens.createSpotlightStackRow(listing, offer, frame));
      stack.add(Box.createRigidArea(new Dimension(0, 10)));
    }

    JScrollPane scroll = new JScrollPane(stack);
    scroll.setBorder(null);
    scroll.getViewport().setBackground(new Color(10, 20, 16));
    scroll.getVerticalScrollBar().setUnitIncrement(20);
    frame.add(scroll, BorderLayout.CENTER);
    frame.setVisible(true);
  }

  JPanel createSpotlightStackRow(
      MarketListing listing, MarketplaceOfferAggregate offer, JFrame parent) {
    JPanel card = new JPanel(new BorderLayout(14, 0));
    card.setBackground(new Color(14, 28, 22));
    card.setMaximumSize(new Dimension(Integer.MAX_VALUE, 80));
    card.setBorder(
        BorderFactory.createCompoundBorder(
            BorderFactory.createLineBorder(new Color(30, 70, 50), 1),
            BorderFactory.createEmptyBorder(10, 14, 10, 14)));

    // Float quality bar (left edge accent)
    float f = (float) listing.item.itemFloat;
    Color floatColor =
        f < 0.07
            ? new Color(0, 220, 120)
            : f < 0.15
                ? new Color(140, 220, 60)
                : f < 0.38
                    ? new Color(220, 200, 0)
                    : f < 0.45 ? new Color(220, 120, 0) : new Color(180, 60, 60);
    JPanel floatBar = new JPanel();
    floatBar.setBackground(floatColor);
    floatBar.setPreferredSize(new Dimension(4, 0));

    // Center info
    JPanel info = new JPanel(new GridLayout(2, 1, 0, 3));
    info.setOpaque(false);
    boolean isAgentSpotlight = app.itemMetadataService.isAgentSkin(listing.item.name);
    JLabel topLine =
        new JLabel(
            (listing.sellerName != null ? listing.sellerName : "Seller")
                + (isAgentSpotlight
                    ? ""
                    : "  ·  " + app.marketOfferService.formatMarketPatternText(listing)));
    topLine.setFont(new Font("Arial", Font.BOLD, 13));
    topLine.setForeground(Color.WHITE);
    JLabel botLine =
        new JLabel(
            isAgentSpotlight
                ? "Agent  ·  Fast Stock"
                : "Float " + String.format("%.6f", listing.item.itemFloat) + "  · Fast Stock");
    botLine.setFont(new Font("Consolas", Font.PLAIN, 11));
    botLine.setForeground(new Color(80, 170, 120));
    info.add(topLine);
    info.add(botLine);

    // Price + button
    JPanel right = new JPanel(new BorderLayout(10, 0));
    right.setOpaque(false);
    JLabel price = new JLabel("$" + String.format("%.2f", listing.getPrice()));
    price.setFont(new Font("Consolas", Font.BOLD, 20));
    price.setForeground(floatColor);
    price.setHorizontalAlignment(SwingConstants.RIGHT);
    JButton btn =
        app.offerNeonAndMirageScreens.createMarketplaceActionButton(
            listing, offer, parent, "ADD TO CART");
    btn.setPreferredSize(new Dimension(120, 36));
    right.add(price, BorderLayout.CENTER);
    right.add(btn, BorderLayout.EAST);

    card.add(floatBar, BorderLayout.WEST);
    card.add(info, BorderLayout.CENTER);
    card.add(right, BorderLayout.EAST);
    return card;
  }
}
