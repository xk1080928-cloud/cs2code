package blahblah;

import blahblah.hGui.*;
import java.awt.*;
import java.awt.event.*;
import java.math.BigDecimal;
import java.math.RoundingMode;
import java.util.ArrayList;
import java.util.List;
import javax.swing.*;

/** Trade Generation Service: focused feature implementation. */
final class TradeGenerationService {
  private final hGui app;

  TradeGenerationService(hGui app) {
    this.app = app;
  }

  void startTradeGenerationTimer() {
    if (app.tradeGenerationTimer != null) {
      app.tradeGenerationTimer.stop();
    }
    app.tradeGenerationTimer =
        new javax.swing.Timer(
            hGui.TRADE_GENERATION_MIN + hGui.random.nextInt(hGui.TRADE_GENERATION_RANGE),
            e -> {
              SwingUtilities.invokeLater(
                  () -> {
                    app.tradeGenerationService.generateRandomTrade();
                    int nextDelay =
                        hGui.TRADE_GENERATION_MIN
                            + hGui.random.nextInt(hGui.TRADE_GENERATION_RANGE);
                    app.tradeGenerationTimer.setDelay(nextDelay);
                  });
            });
    app.tradeGenerationTimer.start();
  }

  void generateRandomTrade() {
    List<InventoryItem> tradeInventory = app.cs2EquipmentScreens.collectibleInventory();
    if (tradeInventory.isEmpty() && app.balance <= 0) {
      return;
    }

    final int MAX_ATTEMPTS = 15;

    for (int attempt = 0; attempt < MAX_ATTEMPTS; attempt++) {

      String[] npcNames = {
        "xX_DarkWolf_Xx", "its_ya_boi_69", "ProGamer2008",
        "Shadow_Killerz", "lolNoScopeXD", "urWorstNightmare",
        "cooldude_123", "xxsniperxx", "EpicFailGuy",
        "ILovePizzaLOL", "DragonSlayer_99", "masterchief_real",
        "NotAFurryIPromise", "MrStealYoWin", "TryHard_Mode",
        "Owned_U_Once", "BasedGamer", "TooGood4U",
        "KidDestroyer420", "ClutchOrKick", "NoobSlayer_XD",
        "xXPureSkillXx", "HeadshotMachine", "EZClapsOnly",
        "LagMadeMeDie", "MomSaidNoMic", "DefinitelyPro",
        "ClickAndPray", "WallbangKing", "TryHardSince09",
        "ScopeAndHope", "KeyboardWarrior", "RespawnLegend",
        "PingIsTrash", "OneTapOrCry", "RankedAnxiety",
        "SilverButMad", "JustBetterBro", "AimAssistPls",
        "SkillIssueLOL", "FragDaddy", "SprayAndPray",
        "EcoRoundHero", "SmokeDiff", "FlashMeDaddy",
        "BombHasBeenPlanted", "FakeDefuse", "KnifeOnlyBTW",
        "ShiftWalking", "PreFireGod", "WidePeekEnjoyer",
        "CrosshairPlacement", "AngleHolder", "CTSideEnjoyer",
        "TSideWarlord", "EntryFragOrDie", "TradeMeBro",
        "LastAliveAgain", "ClutchingTime", "SaveRoundPls",
        "BuyNextRound", "ForceBuyKing", "DeagleMain",
        "AKTapper", "AWPMerchant", "ScopedIn",
        "DryPeekLegend", "UtilityDiff", "RetakeMaster",
        "PostPlantGod", "AntiEcoVictim", "PeekersAdvantage",
        "EcoWarrior", "BottomFragHero", "TopFragNoImpact",
        "SoloQueuePain", "MutedTeammate", "AFKForDinner",
        "LostToPistols", "JumpShotEnjoyer", "ReloadingNow",
        "MissedSprayAgain", "FlickOrFeed", "ShiftKeyBroken",
        "RadarBlind", "FootstepReader", "SmokeMisplaced",
        "PopflashFail", "NadeDamageEnjoyer", "TeamFlashKing",
        "AccidentalJump", "NoScopeDreams", "WhiffedAgain",
        "RunningHeadshot", "LuckyOneTap", "BuyArmorPls",
        "DroppedMyAK", "KnifeOutMid", "BoostGoneWrong",
        "MidRushB", "RotateTooLate", "WrongSiteAgain",
        "HoldingFlank", "PushedThroughSmoke", "DrySwingOnly",
        "UtilitySaving", "DroppedTheBomb", "FakeStratCaller",
        "BaitedByTeammate", "LastPlaceAgain", "WarmupLegend",
        "ColdHandsIRL", "MousepadTooSmall", "SensitivityCrisis",
        "CrosshairTooBig", "CrosshairTooSmall", "FPSDropEnjoyer",
        "AltTabbedMidRound", "DiscordMutedMe", "CalloutsConfused",
        "LostTheClutch", "AlmostAce", "EcoAceDreamer",
        "KnifeKillSeeker", "JumpThrowFail", "ForgotToReload",
        "AFKAtSpawn", "WrongBuyAgain", "HelmetForgotten",
        "ScopedTooLong", "WideSwingOnly", "TimingHatesMe",
        "OneBulletLeft", "LagSpikeNow", "DisconnectedAgain"
      };

      String npcName = npcNames[hGui.random.nextInt(npcNames.length)];
      Image npcAvatar = app.npcAvatars[hGui.random.nextInt(app.npcAvatars.length)];

      ArrayList<InventoryItem> offered = new ArrayList<>();
      ArrayList<InventoryItem> requested = new ArrayList<>();
      double offeredMoney = 0;
      double requestedMoney = 0;

      boolean canUseMoneyTrades = app.balance > 0;
      boolean shouldOfferBlueGem = hGui.random.nextDouble() < 0.10;

      int tradeType;
      if (tradeInventory.isEmpty()) {
        tradeType = canUseMoneyTrades ? 4 : 1;
      } else {
        tradeType = hGui.random.nextInt(shouldOfferBlueGem ? 5 : 4) + 1;
      }

      if (tradeType == 1) {
        int count = 1 + hGui.random.nextInt(Math.min(2, tradeInventory.size()));
        double requestedValue = 0;

        while (requested.size() < count) {
          InventoryItem item = tradeInventory.get(hGui.random.nextInt(tradeInventory.size()));
          if (!requested.contains(item)) {
            requested.add(item);
            requestedValue += item.price.doubleValue();
          }
        }

        double targetValue = requestedValue * (0.85 + hGui.random.nextDouble() * 0.20);
        double currentValue = 0;

        for (int i = 0; i < 15 && currentValue < targetValue * 0.90; i++) {
          InventoryItem item = app.tradeGenerationService.generateRandomNPCItem();
          double price = item.price.doubleValue();
          if (currentValue + price > targetValue * 1.15) break;
          offered.add(item);
          currentValue += price;
        }

      } else if (tradeType == 2) {
        int count = 1 + hGui.random.nextInt(Math.min(2, tradeInventory.size()));
        double totalValue = 0;

        while (requested.size() < count) {
          InventoryItem item = tradeInventory.get(hGui.random.nextInt(tradeInventory.size()));
          if (!requested.contains(item)) {
            requested.add(item);
            totalValue += item.price.doubleValue();
          }
        }

        offeredMoney = totalValue * (0.85 + hGui.random.nextDouble() * 0.15);

      } else if (tradeType == 3) {
        InventoryItem yourItem = tradeInventory.get(hGui.random.nextInt(tradeInventory.size()));
        requested.add(yourItem);

        double targetValue =
            yourItem.price.doubleValue() * (0.90 + hGui.random.nextDouble() * 0.20);
        double currentValue = 0;

        for (int i = 0; i < 15 && currentValue < targetValue * 0.90; i++) {
          InventoryItem item = app.tradeGenerationService.generateRandomNPCItem();
          double price = item.price.doubleValue();
          if (currentValue + price > targetValue * 1.15) break;
          offered.add(item);
          currentValue += price;
        }

      } else if (tradeType == 4 && canUseMoneyTrades) {
        InventoryItem item = app.tradeGenerationService.generateRandomNPCItem();
        offered.add(item);
        double value = item.price.doubleValue();

        if (hGui.random.nextDouble() < 0.3) {
          InventoryItem extra = app.tradeGenerationService.generateRandomNPCItem();
          offered.add(extra);
          value += extra.price.doubleValue();
        }

        requestedMoney = Math.min(app.balance, value * (0.95 + hGui.random.nextDouble() * 0.10));

      } else if (tradeType == 5 && canUseMoneyTrades) {
        InventoryItem blueGem = app.tradeGenerationService.generateRandomBlueGemItem();
        offered.add(blueGem);
        double gemValue = blueGem.price.doubleValue();

        if (hGui.random.nextDouble() < 0.5 || tradeInventory.isEmpty()) {
          requestedMoney =
              Math.min(app.balance, gemValue * (0.90 + hGui.random.nextDouble() * 0.05));
        } else {
          double targetValue = gemValue * (0.95 + hGui.random.nextDouble() * 0.10);
          double currentValue = 0;

          for (int i = 0; i < 20 && currentValue < targetValue * 0.85; i++) {
            InventoryItem item = tradeInventory.get(hGui.random.nextInt(tradeInventory.size()));
            if (!requested.contains(item)) {
              requested.add(item);
              currentValue += item.price.doubleValue();
            }
          }

          if (currentValue < targetValue * 0.70) {
            requested.clear();
            requestedMoney =
                Math.min(app.balance, gemValue * (0.90 + hGui.random.nextDouble() * 0.05));
          }
        }
      }

      if ((offered.isEmpty() && offeredMoney == 0)
          || (requested.isEmpty() && requestedMoney == 0)) {
        continue;
      }

      if (requestedMoney > app.balance) continue;
      if (app.balance <= 0 && requestedMoney > 0) continue;

      double offeredTotal =
          offeredMoney + offered.stream().mapToDouble(i -> i.price.doubleValue()).sum();

      double requestedTotal =
          requestedMoney + requested.stream().mapToDouble(i -> i.price.doubleValue()).sum();

      if (offeredTotal <= 0 || requestedTotal <= 0) continue;

      double ratio = offeredTotal / requestedTotal;
      if (ratio < 0.60 || ratio > 1.40) continue;

      TradeOffer trade =
          new TradeOffer(npcName, npcAvatar, offered, offeredMoney, requested, requestedMoney);
      synchronized (app.pendingTrades) {
        app.pendingTrades.add(trade);
      }
      app.unreadTradesCount++;
      app.tradeHubScreen.updateTradeNotification();
      return;
    }
  }

  InventoryItem generateRandomBlueGemItem() {
    String[] blueGemSkins = {
      "AK-47 | Case Hardened",
      "Flip Knife | Case Hardened",
      "M9 Bayonet | Case Hardened",
      "Butterfly Knife | Case Hardened",
      "Kukri Knife | Case Hardened"
    };

    String skinName = blueGemSkins[hGui.random.nextInt(blueGemSkins.length)];
    String rarity = app.itemMetadataService.getSkinRarity(skinName);
    boolean isKnife = rarity.equals("Knife");
    double basePrice = app.itemPriceService.getBasePrice(skinName);

    String tier;
    double tierRoll = hGui.random.nextDouble();
    if (tierRoll < 0.05) {
      tier = "T1";
    } else if (tierRoll < 0.20) {
      tier = "T2";
    } else if (tierRoll < 0.50) {
      tier = "T3";
    } else {
      tier = "T4";
    }

    int patternID = 0;
    if (skinName.contains("Flip Knife")) {
      List<Integer> patterns = hGui.FLIP_KNIFE_BG.get(tier);
      if (patterns != null && !patterns.isEmpty()) {
        patternID = patterns.get(hGui.random.nextInt(patterns.size()));
      }
    } else if (skinName.contains("M9 Bayonet")) {
      List<Integer> patterns = hGui.M9_BG.get(tier);
      if (patterns != null && !patterns.isEmpty()) {
        patternID = patterns.get(hGui.random.nextInt(patterns.size()));
      }
    } else if (skinName.contains("AK-47")) {
      List<Integer> patterns = hGui.AK_BG.get(tier);
      if (patterns != null && !patterns.isEmpty()) {
        patternID = patterns.get(hGui.random.nextInt(patterns.size()));
      }
    } else if (skinName.contains("Butterfly Knife")) {
      List<Integer> patterns = hGui.BUTTERFLY_BG.get(tier);
      if (patterns != null && !patterns.isEmpty()) {
        patternID = patterns.get(hGui.random.nextInt(patterns.size()));
      }
    } else if (skinName.contains("Kukri Knife")) {
      List<Integer> patterns = hGui.KUKRI_BG.get(tier);
      if (patterns != null && !patterns.isEmpty()) {
        patternID = patterns.get(hGui.random.nextInt(patterns.size()));
      }
    }

    String[] availableConditions = app.floatRules.getAvailableConditions(skinName);
    String condition = availableConditions[hGui.random.nextInt(availableConditions.length)];
    double itemFloat = app.marketGeneration.generateFloatForCondition(skinName, condition);

    double price = basePrice;
    price *= app.priceModifiers.getConditionPriceMultiplier(skinName, condition);

    String blueGemTier = "Blue Gem " + tier;
    price = app.itemPriceService.applyBlueGemMultiplier(skinName, patternID, blueGemTier, price);

    boolean isStattrak =
        app.itemMetadataService.supportsStatTrak(skinName) && hGui.random.nextDouble() < 0.10;
    if (isStattrak) {
      if (isKnife) {
        price *= 1.15;
      } else {
        price *= 3.0;
      }
    }

    double marketMulti = (app.marketPriceMultipliers.getOrDefault(rarity, 1.0));
    price *= marketMulti;

    double trueBasePrice = price / marketMulti;

    Image skinImg = app.artworkService.getSkinImageFromName(skinName, condition);

    String displayRarity = isStattrak ? "StatTrak " + rarity : rarity;
    String fullSkinName = skinName + " (" + blueGemTier + ")";

    return new InventoryItem(
        skinImg != null ? new ImageIcon(skinImg) : null,
        fullSkinName,
        condition,
        displayRarity,
        BigDecimal.valueOf(price).setScale(2, RoundingMode.HALF_UP),
        itemFloat,
        isStattrak,
        patternID,
        blueGemTier,
        trueBasePrice);
  }

  InventoryItem generateRandomNPCItem() {
    String[] allSkins = {
      "Karambit | Slaughter",
      "M9 Bayonet | Crimson Web",
      "Flip Knife | Vanilla",
      "Gut Knife | Fade",
      "Bayonet | Scorched",
      "Bayonet | Boreal Forest",
      "Bayonet | Fade",
      "Flip Knife | Case Hardened",
      "Gut Knife | Forest DDPAT",
      "Gut Knife | Safari Mesh",
      "Karambit | Night",
      "Karambit | Crimson Web",
      "Karambit | Scorched",
      "Karambit | Urban Masked",
      "M9 Bayonet | Blue Steel",
      "M9 Bayonet | Case Hardened",
      "M9 Bayonet | Slaughter",
      "Karambit | Doppler (Phase 1)",
      "Karambit | Doppler (Phase 2)",
      "Karambit | Doppler (Phase 3)",
      "Karambit | Doppler (Phase 4)",
      "M9 Bayonet | Doppler (Phase 1)",
      "M9 Bayonet | Doppler (Phase 2)",
      "M9 Bayonet | Doppler (Phase 3)",
      "M9 Bayonet | Doppler (Phase 4)",
      "Butterfly Knife | Case Hardened",
      "Butterfly Knife | Crimson Web",
      "Butterfly Knife | Fade",
      "Butterfly Knife | Safari Mesh",
      "Butterfly Knife | Slaughter",
      "Butterfly Knife | Urban Masked",
      "Butterfly Knife | Vanilla",
      "Butterfly Knife | Ultraviolet",
      "Butterfly Knife | Doppler (Phase 1)",
      "Butterfly Knife | Doppler (Phase 2)",
      "Butterfly Knife | Doppler (Phase 3)",
      "Butterfly Knife | Doppler (Phase 4)",
      "Butterfly Knife | Gamma Doppler (Phase 1)",
      "Butterfly Knife | Gamma Doppler (Phase 2)",
      "Butterfly Knife | Gamma Doppler (Phase 3)",
      "Butterfly Knife | Gamma Doppler (Phase 4)",
      "Butterfly Knife | Gamma Doppler (Emerald)",
      "Butterfly Knife | Marble Fade",
      "Butterfly Knife | Lore",
      "Kukri Knife | Urban Masked",
      "Kukri Knife | Stained",
      "Kukri Knife | Slaughter",
      "Kukri Knife | Scorched",
      "Kukri Knife | Safari Mesh",
      "Kukri Knife | Night Stripe",
      "Kukri Knife | Fade",
      "Kukri Knife | Crimson Web",
      "Kukri Knife | Case Hardened",
      "Huntsman Knife | Marble Fade",
      "Huntsman Knife | Tiger Tooth",
      "Bowie Knife | Marble Fade",
      "Bowie Knife | Urban Masked",
      "Bowie Knife | Stained",
      "Bowie Knife | Scorched",
      "Bowie Knife | Lore",
      "Bowie Knife | Forest DDPAT",
      "Bowie Knife | Fade",
      "Bowie Knife | Crimson Web",
      "Bowie Knife | Boreal Forest",
      "Bowie Knife | Blue Steel",
      "Bowie Knife | Black Laminate",
      "Bowie Knife | Tiger Tooth",
      "Falchion Knife | Marble Fade",
      "Falchion Knife | Tiger Tooth",
      "Bloodhound Gloves | Bronzed",
      "Bloodhound Gloves | Charred",
      "Bloodhound Gloves | Guerrilla",
      "Bloodhound Gloves | Snakebite",
      "Driver Gloves | Convoy",
      "Driver Gloves | Crimson Weave",
      "Driver Gloves | Diamondback",
      "Driver Gloves | Lunar Weave",
      "Hand Wraps | Badlands",
      "Hand Wraps | Leather",
      "Hand Wraps | Slaughter",
      "Hand Wraps | Spruce DDPAT",
      "Moto Gloves | Boom!",
      "Moto Gloves | Cool Mint",
      "Moto Gloves | Eclipse",
      "Moto Gloves | Spearmint",
      "Specialist Gloves | Crimson Kimono",
      "Specialist Gloves | Emerald Web",
      "Specialist Gloves | Forest DDPAT",
      "Specialist Gloves | Foundation",
      "Sport Gloves | Arid",
      "Sport Gloves | Hedge Maze",
      "Sport Gloves | Pandora's Box",
      "Sport Gloves | Superconductor",
      "Hydra Gloves | Rattler",
      "Hydra Gloves | Mangrove",
      "Hydra Gloves | Emerald",
      "Hydra Gloves | Case Hardened",
      "Hand Wraps | Overprint",
      "Hand Wraps | Duct Tape",
      "Hand Wraps | Cobalt Skulls",
      "Hand Wraps | Arboreal",
      "Driver Gloves | Racing Green",
      "Driver Gloves | Overtake",
      "Driver Gloves | King Snake",
      "Driver Gloves | Imperial Plaid",
      "Sport Gloves | Vice",
      "Sport Gloves | Omega",
      "Sport Gloves | Bronze Morph",
      "Sport Gloves | Amphibious",
      "Specialist Gloves | Mogul",
      "Specialist Gloves | Fade",
      "Specialist Gloves | Crimson Web",
      "Specialist Gloves | Buckshot",
      "Moto Gloves | Turtle",
      "Moto Gloves | Transport",
      "Moto Gloves | POW!",
      "Moto Gloves | Polygon",
      "AWP | Lightning Strike",
      "Desert Eagle | Golden Koi",
      "AK-47 | Fire Serpent",
      "P90 | Asiimov",
      "M4A1-S | Cyrex",
      "AK-47 | Bloodsport",
      "USP-S | Neo Noir",
      "Desert Eagle | Hypnotic",
      "P90 | Emerald Dragon",
      "AK-47 | Case Hardened",
      "P2000 | Ocean Foam",
      "AWP | Graphite",
      "Five-SeveN | Fowl Play",
      "Desert Eagle | Conspiracy",
      "Glock-18 | Water Elemental",
      "CZ75-Auto | Xiangliu",
      "AWP | Fever Dream",
      "M4A1-S | Decimator",
      "Glock-18 | Dragon Tattoo",
      "MAC-10 | Graven",
      "M4A1-S | Dark Water",
      "M4A1-S | Bright Water",
      "USP-S | Dark Water",
      "M4A4 | Zirka",
      "USP-S | Overgrowth",
      "Nova | Koi",
      "PP-Bizon | Osiris",
      "CZ75-Auto | Tigris",
      "P250 | Supernova",
      "M249 | Emerald Poison Dart",
      "MAC-10 | Last Dive",
      "UMP-45 | Scaffold",
      "XM1014 | Seasons",
      "Galil AR | Crimson Tsunami",
      "MP7 | Skulls",
      "AUG | Wings",
      "Galil AR | Shattered",
      "SG 553 | Ultraviolet",
      "SG 553 | Wave Spray",
      "G3SG1 | Demeter",
      "Nova | Tempest",
      "Dual Berettas | Black Limba",
      "Negev | Desert-Strike",
      "UMP-45 | Labyrinth",
      "P2000 | Ivory",
      "MP7 | Urban Hazard",
      "SSG 08 | Abyss",
      "PP-Bizon | Jungle Slipstream",
      "Sawed-Off | Zander",
      "MP7 | Akoben",
      "P250 | Ripple",
      "SCAR-20 | Blueprint",
      "Five-SeveN | Capillary",
      "Desert Eagle | Oxide Blaze"
    };

    String skinName = allSkins[hGui.random.nextInt(allSkins.length)];
    String rarity = app.itemMetadataService.getSkinRarity(skinName);
    double basePrice = app.itemPriceService.getBasePrice(skinName);

    String[] availableConditions = app.floatRules.getAvailableConditions(skinName);
    String condition = availableConditions[hGui.random.nextInt(availableConditions.length)];
    double itemFloat = app.marketGeneration.generateFloatForCondition(skinName, condition);

    double price = basePrice;

    boolean isGloves = rarity.equals("Gloves");
    boolean isKnife = rarity.equals("Knife");

    if (isGloves) {
      double gloveBasePrice = app.itemPriceService.getBasePrice(skinName);
      price = app.priceTables.calculateGlovePrice(skinName, condition, gloveBasePrice);
      double gloveVariance = 0.90 + (hGui.random.nextDouble() * 0.20);
      price *= gloveVariance;
    } else {
      price *= app.priceModifiers.getConditionPriceMultiplier(skinName, condition);
    }

    boolean isStattrak =
        app.itemMetadataService.supportsStatTrak(skinName) && hGui.random.nextDouble() < 0.10;
    if (isStattrak) {
      if (isKnife) {
        price *= 1.15;
      } else {
        price *= 2.0;
      }
    }

    double marketMulti = (app.marketPriceMultipliers.getOrDefault(rarity, 1.0));
    price *= marketMulti;

    Image skinImg = app.artworkService.getSkinImageFromName(skinName, condition);
    String displayRarity = isStattrak ? "StatTrak " + rarity : rarity;

    return new InventoryItem(
        skinImg != null ? new ImageIcon(skinImg) : null,
        skinName,
        condition,
        displayRarity,
        BigDecimal.valueOf(price).setScale(2, RoundingMode.HALF_UP),
        itemFloat,
        isStattrak,
        hGui.random.nextInt(1000),
        null,
        price);
  }
}
