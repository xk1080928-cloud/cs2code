package blahblah;

import blahblah.hGui.*;
import java.awt.*;
import java.awt.event.*;
import java.util.concurrent.atomic.AtomicLong;
import javax.swing.*;

/** Extracted reusable model or widget; behavior retained from the original source. */
final class InventoryIdGenerator {
  final AtomicLong nextId = new AtomicLong(1L);

  String nextId() {
    return "itm-" + nextId.getAndIncrement();
  }

  void observeExistingId(String itemId) {
    if (itemId == null || !itemId.startsWith("itm-")) return;
    try {
      long parsed = Long.parseLong(itemId.substring(4));
      nextId.accumulateAndGet(parsed + 1L, Math::max);
    } catch (NumberFormatException ignored) {
    }
  }
}
