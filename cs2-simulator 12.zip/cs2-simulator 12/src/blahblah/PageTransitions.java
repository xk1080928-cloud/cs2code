package blahblah;

import java.awt.*;
import java.awt.event.*;
import java.awt.image.BufferedImage;
import java.util.*;
import javax.swing.*;

/** Actual-tab-only slide/reveal. One cached incoming component render, never a screen capture. */
final class PageTransitions {
  static final int DURATION_MS = 280;
  private final hGui app;
  private final Map<JTabbedPane, Integer> watched = new WeakHashMap<>();
  private javax.swing.Timer timer;
  private JComponent overlay;
  private AWTEventListener additions;
  private long generation;

  PageTransitions(hGui app) {
    this.app = app;
  }

  void install() {
    if (additions != null) return;
    watch(app.getContentPane());
    additions =
        e -> {
          if (e instanceof ContainerEvent) {
            Component c = ((ContainerEvent) e).getChild();
            if (SwingUtilities.isDescendingFrom(c, app)) watch(c);
          }
        };
    Toolkit.getDefaultToolkit().addAWTEventListener(additions, AWTEvent.CONTAINER_EVENT_MASK);
    app.addWindowListener(
        new WindowAdapter() {
          public void windowClosed(WindowEvent e) {
            stop();
            Toolkit.getDefaultToolkit().removeAWTEventListener(additions);
          }
        });
  }

  private void watch(Component component) {
    if (component instanceof JTabbedPane) {
      JTabbedPane pane = (JTabbedPane) component;
      if (!watched.containsKey(pane)) {
        watched.put(pane, pane.getSelectedIndex());
        pane.addChangeListener(
            e -> {
              int next = pane.getSelectedIndex();
              Integer previous = watched.put(pane, next);
              if (previous != null && previous != next && next >= 0 && pane.isShowing())
                animate(pane);
            });
      }
    }
    if (component instanceof Container)
      for (Component child : ((Container) component).getComponents()) watch(child);
  }
  // Content updates, purchases, filters and refreshes are deliberately not transitions.
  void begin() {}

  void finish() {}

  void inventorySection(String before, String after) {
    if (!java.util.Objects.equals(before, after) && app.mainTabs.getSelectedIndex() == 2)
      animate(
          app.inventoryTabPanel,
          () ->
              app.mainTabs.getSelectedIndex() == 2
                  && java.util.Objects.equals(app.cs2InventorySection, after));
  }

  private void animate(JTabbedPane pane) {
    Component selected = pane.getSelectedComponent();
    animate(selected, () -> pane.isShowing() && pane.getSelectedComponent() == selected);
  }

  private void animate(Component selected, java.util.function.BooleanSupplier valid) {
    if (selected == null
        || !selected.isShowing()
        || !app.isShowing()
        || app.itemRevealService.showing
        || app.armouryAnimating) return;
    stop();
    long token = generation;
    final long[] began = {0};
    final BufferedImage[] scene = {null};
    overlay =
        new JComponent() {
          public boolean contains(int x, int y) {
            return false;
          }

          protected void paintComponent(Graphics graphics) {
            if (began[0] == 0) began[0] = System.nanoTime();
            float p = Math.min(1f, (System.nanoTime() - began[0]) / (DURATION_MS * 1_000_000f));
            float ease = 1 - (1 - p) * (1 - p) * (1 - p);
            putClientProperty("transitionProgress", p);
            Graphics2D g = (Graphics2D) graphics.create();
            g.setColor(new Color(24, 36, 42));
            g.fillRect(0, 0, getWidth(), getHeight());
            if (scene[0] != null) {
              g.setComposite(AlphaComposite.SrcOver.derive(.65f + .35f * ease));
              g.drawImage(scene[0], Math.round(32 * (1 - ease)), 0, null);
            }
            g.dispose();
          }
        };
    overlay.setName("pageTransitionOverlay");
    // Keep the overlay detectable immediately, but render only after navigation/layout has
    // finished.
    app.getLayeredPane().add(overlay, JLayeredPane.DRAG_LAYER);
    SwingUtilities.invokeLater(
        () -> {
          if (token != generation || overlay == null) return;
          if (!valid.getAsBoolean()) {
            stop();
            return;
          }
          app.validate();
          if (selected.getWidth() < 1 || selected.getHeight() < 1) {
            stop();
            return;
          }
          Point origin = SwingUtilities.convertPoint(selected, 0, 0, app.getLayeredPane());
          overlay.setBounds(origin.x, origin.y, selected.getWidth(), selected.getHeight());
          scene[0] =
              new BufferedImage(
                  selected.getWidth(), selected.getHeight(), BufferedImage.TYPE_INT_RGB);
          Graphics2D g = scene[0].createGraphics();
          selected.printAll(g);
          g.dispose();
          overlay.repaint();
          timer =
              new javax.swing.Timer(
                  16,
                  e -> {
                    if (!app.isShowing()
                        || (began[0] != 0
                            && System.nanoTime() - began[0] >= DURATION_MS * 1_000_000L)) stop();
                    else if (overlay != null) overlay.repaint();
                  });
          timer.setCoalesce(true);
          timer.start();
        });
  }

  void stop() {
    generation++;
    if (timer != null) {
      timer.stop();
      timer = null;
    }
    if (overlay != null) {
      Rectangle area = overlay.getBounds();
      app.getLayeredPane().remove(overlay);
      overlay = null;
      app.getLayeredPane().repaint(area);
    }
  }
}
