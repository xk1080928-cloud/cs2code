package blahblah;

import blahblah.hGui.*;
import java.awt.*;
import java.awt.event.*;
import javax.swing.*;

/** Price Tables: focused feature implementation. */
final class PriceTables {
  private final hGui app;

  PriceTables(hGui app) {
    this.app = app;
  }

  double getBasePriceInner(String skinName) {
    Double requestedFallback =
        app.requestedMarketBasePrices.get(
            app.marketCatalogService.marketCollectionSkinKey(skinName));
    if (requestedFallback != null) return requestedFallback;

    Double achromaFallback = hGui.ACHROMA_FALLBACK_BASE_PRICES.get(skinName);
    if (achromaFallback != null) return achromaFallback;
    String lowerName = skinName.toLowerCase();
    boolean isSapphire = lowerName.contains("sapphire");
    boolean isRuby = lowerName.contains("ruby");
    boolean isBlackPearl = lowerName.contains("black pearl");
    boolean isEmeraldGamma = lowerName.contains("gamma doppler") && lowerName.contains("emerald");
    boolean isGem = isSapphire || isRuby || isBlackPearl;
    double agentBasePrice = app.itemMetadataService.getAgentBasePrice(skinName);
    if (agentBasePrice > 0) {
      return agentBasePrice;
    }
    if ("M4A4 | Howl".equalsIgnoreCase(skinName.trim())) {
      return 5000.00;
    }
    if (app.floatRules.isVanillaKnife(skinName)) {
      String knife = skinName.toLowerCase(java.util.Locale.ROOT);
      if (knife.startsWith("karambit")) return 1600.00;
      if (knife.startsWith("butterfly knife")) return 1500.00;
      if (knife.startsWith("m9 bayonet")) return 1000.00;
      if (knife.startsWith("bayonet")) return 600.00;
      if (knife.startsWith("talon knife")) return 800.00;
      if (knife.startsWith("skeleton knife")) return 650.00;
      if (knife.startsWith("flip knife")) return 180.00;
      return 220.00;
    }
    if (isEmeraldGamma || isGem) {
      String baseVariant = skinName.replaceAll(" \\((?:Sapphire|Ruby|Black Pearl|Emerald)\\)$", "");
      // Ordinary finishes such as MP9 | Ruby Poison Dart contain "Ruby"
      // but are not Doppler gems. Never recurse when no suffix was removed.
      if (!baseVariant.equals(skinName)) return app.itemPriceService.getBasePrice(baseVariant);
    }

    if (skinName.contains("Gloves") || skinName.contains("Hand Wraps")) {
      return app.priceTables.getGloveBasePrice(skinName);

    } else if (skinName.equals("Karambit | Slaughter")) {
      return 1150.00;

    } else if (skinName.equals("M9 Bayonet | Crimson Web")) {
      return 650.00;

    } else if (skinName.equals("Flip Knife | Vanilla")) {
      return 180.00;

    } else if (skinName.equals("Gut Knife | Fade")) {
      return 230.00;

    } else if (skinName.equals("Bayonet | Scorched")) {
      return 230.00;

    } else if (skinName.equals("Bayonet | Boreal Forest")) {
      return 195.00;

    } else if (skinName.equals("Bayonet | Fade")) {
      return 660.00;

    } else if (skinName.equals("Flip Knife | Case Hardened")) {
      return 250.00;

    } else if (skinName.equals("Gut Knife | Forest DDPAT")) {
      return 90.00;

    } else if (skinName.equals("Gut Knife | Safari Mesh")) {
      return 90.00;

    } else if (skinName.equals("Karambit | Night")) {
      return 700.00;

    } else if (skinName.equals("Karambit | Crimson Web")) {
      return 650.00;

    } else if (skinName.equals("Karambit | Scorched")) {
      return 320.00;

    } else if (skinName.equals("Karambit | Urban Masked")) {
      return 300.00;

    } else if (skinName.equals("M9 Bayonet | Blue Steel")) {
      return 380.00;

    } else if (skinName.equals("M9 Bayonet | Case Hardened")) {
      return 420.00;

    } else if (skinName.equals("M9 Bayonet | Slaughter")) {
      return 650.00;

    } else if (skinName.contains("M9 Bayonet | Doppler")) {

      if (skinName.contains("Phase 1")) {
        return 1000.00;
      } else if (skinName.contains("Phase 2")) {
        return 1500.00;
      } else if (skinName.contains("Phase 3")) {
        return 1100.00;
      } else if (skinName.contains("Phase 4")) {
        return 1150.00;
      }
      return 1000.0;

    } else if (skinName.contains("Karambit | Doppler")) {

      if (skinName.contains("Phase 1")) {
        return 1300.00;
      } else if (skinName.contains("Phase 2")) {
        return 2300.00;
      } else if (skinName.contains("Phase 3")) {
        return 1400.00;
      } else if (skinName.contains("Phase 4")) {
        return 1350.00;
      }
      return 1300.0;

    } else if (skinName.equals("Butterfly Knife | Case Hardened")) {
      return 750.00;

    } else if (skinName.equals("Butterfly Knife | Crimson Web")) {
      return 700.00;

    } else if (skinName.equals("Butterfly Knife | Fade")) {
      return 1200.00;

    } else if (skinName.equals("Butterfly Knife | Slaughter")) {
      return 1300.00;

    } else if (skinName.equals("Butterfly Knife | Safari Mesh")) {
      return 450.00;

    } else if (skinName.equals("Butterfly Knife | Urban Masked")) {
      return 480.00;

    } else if (skinName.equals("Butterfly Knife | Vanilla")) {
      return 1500.00;

    } else if (skinName.equals("Butterfly Knife | Ultraviolet")) {
      return 550.00;

    } else if (skinName.contains("Butterfly Knife | Doppler")) {
      if (skinName.contains("Phase 1")) {
        return 1800.00;
      } else if (skinName.contains("Phase 2")) {
        return 3100.00;
      } else if (skinName.contains("Phase 3")) {
        return 2000.00;
      } else if (skinName.contains("Phase 4")) {
        return 2500.00;
      }
      return 1800;

    } else if (skinName.contains("Butterfly Knife | Gamma Doppler")) {
      if (skinName.contains("Phase 1")) {
        return 1700.00;
      } else if (skinName.contains("Phase 2")) {
        return 1850.00;
      } else if (skinName.contains("Phase 3")) {
        return 1900.00;
      } else if (skinName.contains("Phase 4")) {
        return 1750.00;
      }
      return 1700;

    } else if (skinName.equals("Butterfly Knife | Marble Fade")) {
      return 1200.00;

    } else if (skinName.equals("Butterfly Knife | Lore")) {
      return 600.00;

    } else if (skinName.equals("Kukri Knife | Urban Masked")) {
      return 50.00;

    } else if (skinName.equals("Kukri Knife | Stained")) {
      return 70.00;

    } else if (skinName.equals("Kukri Knife | Slaughter")) {
      return 130.00;

    } else if (skinName.equals("Kukri Knife | Scorched")) {
      return 60.00;

    } else if (skinName.equals("Kukri Knife | Safari Mesh")) {
      return 40.00;

    } else if (skinName.equals("Kukri Knife | Night Stripe")) {
      return 50.00;

    } else if (skinName.equals("Kukri Knife | Fade")) {
      return 190.00;

    } else if (skinName.equals("Kukri Knife | Crimson Web")) {
      return 100.00;

    } else if (skinName.equals("Kukri Knife | Case Hardened")) {
      return 100.00;

    } else if (skinName.equals("Huntsman Knife | Marble Fade")) {
      return 200.00;

    } else if (skinName.equals("Huntsman Knife | Tiger Tooth")) {
      return 160.00;

    } else if (skinName.equals("Bowie Knife | Marble Fade")) {
      return 200.00;

    } else if (skinName.equals("Bowie Knife | Urban Masked")) {
      return 60.00;

    } else if (skinName.equals("Bowie Knife | Stained")) {
      return 80.00;

    } else if (skinName.equals("Bowie Knife | Scorched")) {
      return 65.00;

    } else if (skinName.equals("Bowie Knife | Lore")) {
      return 100.00;

    } else if (skinName.equals("Bowie Knife | Forest DDPAT")) {
      return 55.00;

    } else if (skinName.equals("Bowie Knife | Fade")) {
      return 200.00;

    } else if (skinName.equals("Bowie Knife | Crimson Web")) {
      return 100.00;

    } else if (skinName.equals("Bowie Knife | Boreal Forest")) {
      return 60.00;

    } else if (skinName.equals("Bowie Knife | Blue Steel")) {
      return 100.00;

    } else if (skinName.equals("Bowie Knife | Black Laminate")) {
      return 60.00;

    } else if (skinName.equals("Bowie Knife | Tiger Tooth")) {
      return 150.00;

    } else if (skinName.equals("Falchion Knife | Marble Fade")) {
      return 200.00;

    } else if (skinName.equals("Falchion Knife | Tiger Tooth")) {
      return 170.00;

    } else if (skinName.equals("AWP | Lightning Strike")) {
      return 180.00;

    } else if (skinName.equals("Desert Eagle | Golden Koi")) {
      return 150.00;

    } else if (skinName.equals("AK-47 | Fire Serpent")) {
      return 800.00;

    } else if (skinName.equals("P90 | Asiimov")) {
      return 135.00;

    } else if (skinName.equals("M4A1-S | Cyrex")) {
      return 145.00;

    } else if (skinName.equals("AK-47 | Bloodsport")) {
      return 180.00;

    } else if (skinName.equals("USP-S | Neo Noir")) {
      return 125.00;

    } else if (skinName.equals("AK-47 | Inheritance")) {
      return 50.00;

    } else if (skinName.equals("AWP | Chrome Cannon")) {
      return 30.00;

    } else if (skinName.equals("Desert Eagle | Hypnotic")) {
      return 90.00;

    } else if (skinName.equals("P90 | Emerald Dragon")) {
      return 100.00;

    } else if (skinName.equals("AK-47 | Case Hardened")) {
      return 195.00;

    } else if (skinName.equals("P2000 | Ocean Foam")) {
      return 140.00;

    } else if (skinName.equals("AWP | Graphite")) {
      return 130.00;

    } else if (skinName.equals("Five-SeveN | Fowl Play")) {
      return 18.00;

    } else if (skinName.equals("Desert Eagle | Conspiracy")) {
      return 35.00;

    } else if (skinName.equals("Glock-18 | Water Elemental")) {
      return 45.00;

    } else if (skinName.equals("CZ75-Auto | Xiangliu")) {
      return 18.00;

    } else if (skinName.equals("AWP | Fever Dream")) {
      return 19.00;

    } else if (skinName.equals("M4A1-S | Decimator")) {
      return 50.00;

    } else if (skinName.equals("M4A1-S | Black Lotus")) {
      return 5.00;

    } else if (skinName.equals("USP-S | Jawbreaker")) {
      return 4.00;

    } else if (skinName.equals("Zeus x27 | Olympus")) {
      return 4.00;

    } else if (skinName.equals("Glock-18 | Dragon Tattoo")) {
      return 45.00;

    } else if (skinName.equals("MAC-10 | Graven")) {
      return 30.00;

    } else if (skinName.equals("M4A1-S | Dark Water")) {
      return 34.00;

    } else if (skinName.equals("M4A1-S | Bright Water")) {
      return 32.00;

    } else if (skinName.equals("USP-S | Dark Water")) {
      return 38.00;

    } else if (skinName.equals("M4A4 | Zirka")) {
      return 50.00;

    } else if (skinName.equals("USP-S | Overgrowth")) {
      return 32.00;

    } else if (skinName.equals("Nova | Koi")) {
      return 4.50;

    } else if (skinName.equals("PP-Bizon | Osiris")) {
      return 6.00;

    } else if (skinName.equals("CZ75-Auto | Tigris")) {
      return 7.50;

    } else if (skinName.equals("P250 | Supernova")) {
      return 4.00;

    } else if (skinName.equals("M249 | Emerald Poison Dart")) {
      return 3.00;

    } else if (skinName.equals("MAC-10 | Last Dive")) {
      return 4.00;

    } else if (skinName.equals("UMP-45 | Scaffold")) {
      return 3.50;

    } else if (skinName.equals("XM1014 | Seasons")) {
      return 3.50;

    } else if (skinName.equals("Galil AR | Crimson Tsunami")) {
      return 9;

    } else if (skinName.equals("M4A4 | Etch Lord")) {
      return 1.00;

    } else if (skinName.equals("Glock-18 | Block-18")) {
      return 0.75;

    } else if (skinName.equals("Five-SeveN | Hybrid")) {
      return 0.50;

    } else if (skinName.equals("MP7 | Just Smile")) {
      return 0.40;

    } else if (skinName.equals("Sawed-Off | Analog Input")) {
      return 0.35;

    } else if (skinName.equals("MP7 | Skulls")) {
      return 12.00;

    } else if (skinName.equals("AUG | Wings")) {
      return 10.00;

    } else if (skinName.equals("Galil AR | Shattered")) {
      return 6.00;

    } else if (skinName.equals("SG 553 | Ultraviolet")) {
      return 8.00;

    } else if (skinName.equals("SG 553 | Wave Spray")) {
      return 5.00;

    } else if (skinName.equals("G3SG1 | Demeter")) {
      return 7.00;

    } else if (skinName.equals("Nova | Tempest")) {
      return 4.00;

    } else if (skinName.equals("Dual Berettas | Black Limba")) {
      return 6.00;

    } else if (skinName.equals("Negev | Desert-Strike")) {
      return 0.80;

    } else if (skinName.equals("UMP-45 | Labyrinth")) {
      return 1.40;

    } else if (skinName.equals("P2000 | Ivory")) {
      return 1.60;

    } else if (skinName.equals("MP7 | Urban Hazard")) {
      return 1.30;

    } else if (skinName.equals("SSG 08 | Abyss")) {
      return 1.80;

    } else if (skinName.equals("PP-Bizon | Jungle Slipstream")) {
      return 0.50;

    } else if (skinName.equals("Sawed-Off | Zander")) {
      return 0.50;

    } else if (skinName.equals("MP7 | Akoben")) {
      return 0.50;

    } else if (skinName.equals("P250 | Ripple")) {
      return 0.50;

    } else if (skinName.equals("SCAR-20 | Blueprint")) {
      return 0.50;

    } else if (skinName.equals("Five-SeveN | Capillary")) {
      return 0.50;

    } else if (skinName.equals("Desert Eagle | Oxide Blaze")) {
      return 0.75;

    } else if (skinName.equals("MAC-10 | Light Box")) {
      return 0.15;

    } else if (skinName.equals("Nova | Dark Sigil")) {
      return 0.10;

    } else if (skinName.equals("Dual Berettas | Hideout")) {
      return 0.08;

    } else if (skinName.equals("SSG 08 | Dezastre")) {
      return 0.05;

    } else if (skinName.equals("UMP-45 | Motorized")) {
      return 0.07;

    } else if (skinName.equals("Tec-9 | Slag")) {
      return 0.10;

    } else if (skinName.equals("XM1014 | Irezumi")) {
      return 0.05;

    } else if (skinName.equals("AK-47 | B the Monster")) {
      return 300.0;
    } else if (skinName.equals("AWP | CMYK")) {
      return 500.0;
    } else if (skinName.equals("M4A1-S | Fade")) {
      return 400.0;
    } else if (skinName.equals("Glock-18 | AXIA")) {
      return 50.0;
    } else if (skinName.equals("Galil AR | Rainbow Spoon")) {
      return 50.0;
    } else if (skinName.equals("Zeus x27 | Dragon Snore")) {
      return 40.0;
    } else if (skinName.equals("AWP | Crakow!")) {
      return 55.0;
    } else if (skinName.equals("Desert Eagle | Starcade")) {
      return 90.0;
    } else if (skinName.equals("AUG | Lil' Pig")) {
      return 60.0;
    } else if (skinName.equals("UMP-45 | Crimson Foil")) {
      return 5.0;
    } else if (skinName.equals("MP9 | Arctic Tri-Tone")) {
      return 5.0;
    } else if (skinName.equals("Five-SeveN | Heat Treated")) {
      return 10.0;
    } else if (skinName.equals("USP-S | Alpine Camo")) {
      return 1.5;
    } else if (skinName.equals("SSG 08 | Zeno")) {
      return 1.8;
    } else if (skinName.equals("XM1014 | Monster Melt")) {
      return 8.0;
    } else if (skinName.equals("Dual Berettas | Sweet Little Angels")) {
      return 8.0;
    } else if (skinName.equals("AUG | Eye of Zapems")) {
      return 8.0;
    } else if (skinName.equals("Nova | Wurst Holle")) {
      return 1.0;
    } else if (skinName.equals("MAC-10 | Pipsqueak")) {
      return 2.0;
    } else if (skinName.equals("P90 | Attack Vector")) {
      return 10.0;
    } else if (skinName.equals("M4A4 | Polysoup")) {
      return 15.0;
    } else if (skinName.equals("CZ75-Auto | Slalom")) {
      return 10.0;
    } else if (skinName.equals("XM1014 | Halftone Shift")) {
      return 3.0;
    } else if (skinName.equals("SG 553 | Berry Gel Coat")) {
      return 3.5;
    } else if (skinName.equals("P250 | Small Game")) {
      return 2.0;
    } else if (skinName.equals("Nova | Yorkshire")) {
      return 2.0;
    } else if (skinName.equals("MP5-SD | Savannah Halftone")) {
      return 0.20;
    } else if (skinName.equals("PP-Bizon | Cold Cell")) {
      return 0.15;
    } else if (skinName.equals("Glock-18 | Teal Graf")) {
      return 1.5;
    } else if (skinName.equals("Galil AR | Metallic Squeezer")) {
      return 1.2;
    } else if (skinName.equals("MP5-SD | Neon Squeezer")) {
      return 0.18;
    } else if (skinName.equals("P90 | Wash me")) {
      return 0.20;
    } else if (skinName.equals("SCAR-20 | Wild Berry")) {
      return 2.0;
    } else if (skinName.equals("AK-47 | Crossfade")) {
      return 3.5;
    } else if (skinName.equals("SSG 08 | Halftone Whorl")) {
      return 0.40;
    } else if (skinName.equals("P2000 | Coral Halftone")) {
      return 0.60;
    } else if (skinName.equals("MP7 | Astrolabe")) {
      return 0.90;
    } else if (skinName.equals("M249 | Spectrogram")) {
      return 0.8;
    } else if (skinName.equals("Galil AR | NV")) {
      return 3.5;
    } else if (skinName.equals("FAMAS | Halftone Wash")) {
      return 0.45;
    } else if (skinName.equals("AK-47 | Olive Polycam")) {
      return 0.80;
    } else if (skinName.equals("FAMAS | Half Sleeve")) {
      return 0.50;
    } else if (skinName.equals("MAG-7 | Wildwood")) {
      return 0.25;
    } else if (skinName.equals("Tec-9 | Tiger Stencil")) {
      return 0.40;
    } else if (skinName.equals("Negev | Wall Bang")) {
      return 0.10;
    } else if (skinName.equals("M4A1-S | Wash me plz")) {
      return 0.12;
    } else if (skinName.equals("Five-SeveN | Midnight Paintover")) {
      return 0.08;
    } else if (skinName.equals("Desert Eagle | Tilted")) {
      return 0.15;
    } else if (skinName.equals("M4A4 | Temukau")) {
      return 35.00;
    } else if (skinName.equals("AK-47 | Head Shot")) {
      return 30.00;
    } else if (skinName.equals("AWP | Duality")) {
      return 4.00;
    } else if (skinName.equals("P2000 | Wicked Sick")) {
      return 3.00;
    } else if (skinName.equals("UMP-45 | Wild Child")) {
      return 2.50;
    } else if (skinName.equals("M4A1-S | Emphorosaur-S")) {
      return 0.50;
    } else if (skinName.equals("Glock-18 | Umbral Rabbit")) {
      return 0.30;
    } else if (skinName.equals("MAC-10 | Sakkaku")) {
      return 0.35;
    } else if (skinName.equals("P90 | Neoqueen")) {
      return 0.25;
    } else if (skinName.equals("R8 Revolver | Banana Cannon")) {
      return 0.28;
    } else if (skinName.equals("Tec-9 | Rebel")) {
      return 0.05;
    } else if (skinName.equals("MP9 | Featherweight")) {
      return 0.04;
    } else if (skinName.equals("MAG-7 | Insomnia")) {
      return 0.06;
    } else if (skinName.equals("P250 | Re.built")) {
      return 0.07;
    } else if (skinName.equals("MP5-SD | Liquidation")) {
      return 0.08;
    } else if (skinName.equals("SCAR-20 | Fragments")) {
      return 0.03;
    } else if (skinName.equals("SG 553 | Cyberforce")) {
      return 0.04;
    } else {
      return 5.00;
    }
  }

  double getGloveBasePrice(String gloveName) {
    if (gloveName.equals("Bloodhound Gloves | Bronzed")) {
      return 100.0;
    } else if (gloveName.equals("Bloodhound Gloves | Charred")) {
      return 100.0;
    } else if (gloveName.equals("Bloodhound Gloves | Guerrilla")) {
      return 150.0;
    } else if (gloveName.equals("Bloodhound Gloves | Snakebite")) {
      return 200.0;
    } else if (gloveName.equals("Driver Gloves | Convoy")) {
      return 100.0;
    } else if (gloveName.equals("Driver Gloves | Crimson Weave")) {
      return 400.0;
    } else if (gloveName.equals("Driver Gloves | Diamondback")) {
      return 150.0;
    } else if (gloveName.equals("Driver Gloves | Lunar Weave")) {
      return 225.0;
    } else if (gloveName.equals("Hand Wraps | Badlands")) {
      return 150.0;
    } else if (gloveName.equals("Hand Wraps | Leather")) {
      return 250.0;
    } else if (gloveName.equals("Hand Wraps | Slaughter")) {
      return 250.0;
    } else if (gloveName.equals("Hand Wraps | Spruce DDPAT")) {
      return 125.0;
    } else if (gloveName.equals("Moto Gloves | Boom!")) {
      return 125.0;
    } else if (gloveName.equals("Moto Gloves | Cool Mint")) {
      return 250.0;
    } else if (gloveName.equals("Moto Gloves | Eclipse")) {
      return 125.0;
    } else if (gloveName.equals("Moto Gloves | Spearmint")) {
      return 500.0;
    } else if (gloveName.equals("Specialist Gloves | Crimson Kimono")) {
      return 1500.0;
    } else if (gloveName.equals("Specialist Gloves | Emerald Web")) {
      return 550.0;
    } else if (gloveName.equals("Specialist Gloves | Forest DDPAT")) {
      return 125.0;
    } else if (gloveName.equals("Specialist Gloves | Foundation")) {
      return 250.0;
    } else if (gloveName.equals("Sport Gloves | Arid")) {
      return 400.0;
    } else if (gloveName.equals("Sport Gloves | Hedge Maze")) {
      return 3000.0;
    } else if (gloveName.equals("Sport Gloves | Pandora's Box")) {
      return 3100.0;
    } else if (gloveName.equals("Sport Gloves | Superconductor")) {
      return 1200.0;
    } else if (gloveName.equals("Hydra Gloves | Rattler")) {
      return 30.0;
    } else if (gloveName.equals("Hydra Gloves | Mangrove")) {
      return 30.0;
    } else if (gloveName.equals("Hydra Gloves | Emerald")) {
      return 50.0;
    } else if (gloveName.equals("Hydra Gloves | Case Hardened")) {
      return 70.0;
    } else if (gloveName.equals("Hand Wraps | Overprint")) {
      return 120.0;
    } else if (gloveName.equals("Hand Wraps | Duct Tape")) {
      return 50.0;
    } else if (gloveName.equals("Hand Wraps | Cobalt Skulls")) {
      return 220.0;
    } else if (gloveName.equals("Hand Wraps | Arboreal")) {
      return 50.0;
    } else if (gloveName.equals("Driver Gloves | Racing Green")) {
      return 35.0;
    } else if (gloveName.equals("Driver Gloves | Overtake")) {
      return 57.0;
    } else if (gloveName.equals("Driver Gloves | King Snake")) {
      return 160.0;
    } else if (gloveName.equals("Driver Gloves | Imperial Plaid")) {
      return 185.0;
    } else if (gloveName.equals("Sport Gloves | Vice")) {
      return 400.0;
    } else if (gloveName.equals("Sport Gloves | Omega")) {
      return 215.0;
    } else if (gloveName.equals("Sport Gloves | Bronze Morph")) {
      return 110.0;
    } else if (gloveName.equals("Sport Gloves | Amphibious")) {
      return 330.0;
    } else if (gloveName.equals("Specialist Gloves | Mogul")) {
      return 120.0;
    } else if (gloveName.equals("Specialist Gloves | Fade")) {
      return 200.0;
    } else if (gloveName.equals("Specialist Gloves | Crimson Web")) {
      return 150.0;
    } else if (gloveName.equals("Specialist Gloves | Buckshot")) {
      return 50.0;
    } else if (gloveName.equals("Moto Gloves | Turtle")) {
      return 80.0;
    } else if (gloveName.equals("Moto Gloves | Transport")) {
      return 40.0;
    } else if (gloveName.equals("Moto Gloves | POW!")) {
      return 120.0;
    } else if (gloveName.equals("Moto Gloves | Polygon")) {
      return 130.0;
    }
    return 100.0;
  }

  double calculateGlovePrice(String gloveName, String condition, double basePrice) {
    return basePrice * app.priceModifiers.getConditionPriceMultiplier(gloveName, condition);
  }
}
