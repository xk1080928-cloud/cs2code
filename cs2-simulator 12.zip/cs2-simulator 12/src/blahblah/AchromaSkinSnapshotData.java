package blahblah;

import blahblah.hGui.*;
import java.awt.*;
import java.awt.event.*;
import javax.swing.*;

/** Embedded data kept in Java so no extra resource folder is required. */
final class AchromaSkinSnapshotData {
  static final String DATA =
      "["
          + String.join(
              ",",
              new String[] {
                "{\"name\":\"AK-47 |"
                    + " Breakthrough\",\"category\":{\"id\":\"csgo_inventory_weapon_category_rifles\",\"name\":\"Rifles\"},\"min_float\":0,\"max_float\":0.75,\"rarity\":{\"id\":\"rarity_mythical_weapon\",\"name\":\"Restricted\",\"color\":\"#8847ff\"},\"crates\":[],\"image\":\"https://community.akamai.steamstatic.com/economy/image/i0CoZ81Ui0m-9KwlBY1L_18myuGuq1wfhWSaZgMttyVfPaERSR0Wqmu7LAocGIGz3UqlXOLrxM-vMGmW8VNxu5Dx60noTyLwlcK3wipC6s20baB-H_yaCW-Ej-olseI8Gyq1kBkh4GrVz4queXySPAd0XJEkQ7UMu0TrldaxYbzjsw3Ay9USrh0CgFA\"}",
                "{\"name\":\"AUG |"
                    + " Creep\",\"category\":{\"id\":\"csgo_inventory_weapon_category_rifles\",\"name\":\"Rifles\"},\"min_float\":0,\"max_float\":0.8,\"rarity\":{\"id\":\"rarity_rare_weapon\",\"name\":\"Mil-Spec"
                    + " Grade\",\"color\":\"#4b69ff\"},\"crates\":[],\"image\":\"https://community.akamai.steamstatic.com/economy/image/i0CoZ81Ui0m-9KwlBY1L_18myuGuq1wfhWSaZgMttyVfPaERSR0Wqmu7LAocGIGz3UqlXOLrxM-vMGmW8VNxu5Dx60noTyLwi5Hf7i1e0PO7b5tuMvWWHlicyOl-pK9oSnnnkRl34WqBwtavcH6TagRxWZR2E7FYuhm9wIblZr60slHXjYtM02yg2RFs1ez8\"}",
                "{\"name\":\"AWP | The"
                    + " End\",\"category\":{\"id\":\"csgo_inventory_weapon_category_rifles\",\"name\":\"Rifles\"},\"min_float\":0,\"max_float\":1,\"rarity\":{\"id\":\"rarity_legendary_weapon\",\"name\":\"Classified\",\"color\":\"#d32ce6\"},\"crates\":[],\"image\":\"https://community.akamai.steamstatic.com/economy/image/i0CoZ81Ui0m-9KwlBY1L_18myuGuq1wfhWSaZgMttyVfPaERSR0Wqmu7LAocGIGz3UqlXOLrxM-vMGmW8VNxu5Dx60noTyLwiYbf7i1e0PC5V7BlJc-WAGOvwPlmj-1gSCGn20hytjzSy4r_cy_FZlB1DJdxE7QN50bql4LuNL7g4gTYj9lGnir9iyJXrnE8dWNkiOM\"}",
                "{\"name\":\"PP-Bizon |"
                    + " Bizoom\",\"category\":{\"id\":\"csgo_inventory_weapon_category_smgs\",\"name\":\"SMGs\"},\"min_float\":0,\"max_float\":0.58,\"rarity\":{\"id\":\"rarity_common_weapon\",\"name\":\"Consumer"
                    + " Grade\",\"color\":\"#b0c3d9\"},\"crates\":[],\"image\":\"https://community.akamai.steamstatic.com/economy/image/i0CoZ81Ui0m-9KwlBY1L_18myuGuq1wfhWSaZgMttyVfPaERSR0Wqmu7LAocGIGz3UqlXOLrxM-vMGmW8VNxu5Dx60noTyLzl4zv8x1T9veRa6V_H-eBD3evw-dsv-9WQyC0nQlp6zzdzI6rIHOealMiCJolEOVb5EPrx9PuN7_i5lHW2d9NySj2jy9N6DErvbhOwQNAJg\"}",
                "{\"name\":\"Desert Eagle | The Daily"
                    + " Deagle\",\"category\":{\"id\":\"csgo_inventory_weapon_category_pistols\",\"name\":\"Pistols\"},\"min_float\":0,\"max_float\":0.58,\"rarity\":{\"id\":\"rarity_rare_weapon\",\"name\":\"Mil-Spec"
                    + " Grade\",\"color\":\"#4b69ff\"},\"crates\":[],\"image\":\"https://community.akamai.steamstatic.com/economy/image/i0CoZ81Ui0m-9KwlBY1L_18myuGuq1wfhWSaZgMttyVfPaERSR0Wqmu7LAocGIGz3UqlXOLrxM-vMGmW8VNxu5Dx60noTyL1m5fn8Sdk5-urV6dsMs-EHGaA_uJ_t-l9AXm3kxh162qHy9-pd3PEagMmDJMkRuEK4BG4x9zhZe-07gPdiotMyivgznQej0ovEM4\"}",
                "{\"name\":\"Dual Berettas | Silver"
                    + " Pour\",\"category\":{\"id\":\"csgo_inventory_weapon_category_pistols\",\"name\":\"Pistols\"},\"min_float\":0,\"max_float\":0.678431,\"rarity\":{\"id\":\"rarity_common_weapon\",\"name\":\"Consumer"
                    + " Grade\",\"color\":\"#b0c3d9\"},\"crates\":[],\"image\":\"https://community.akamai.steamstatic.com/economy/image/i0CoZ81Ui0m-9KwlBY1L_18myuGuq1wfhWSaZgMttyVfPaERSR0Wqmu7LAocGIGz3UqlXOLrxM-vMGmW8VNxu5Dx60noTyL0kp_0-B1I4PeRaad_OfyaDViWzeFh495lRi67gVN3tmnTn4yreXvFZgYjD8QlE-QK4EGxkda0Ze20tQbZ2Y9CyS_5iC1K8G81tJXDIHOE\"}",
                "{\"name\":\"FAMAS |"
                    + " Vendetta\",\"category\":{\"id\":\"csgo_inventory_weapon_category_rifles\",\"name\":\"Rifles\"},\"min_float\":0,\"max_float\":0.6,\"rarity\":{\"id\":\"rarity_uncommon_weapon\",\"name\":\"Industrial"
                    + " Grade\",\"color\":\"#5e98d9\"},\"crates\":[],\"image\":\"https://community.akamai.steamstatic.com/economy/image/i0CoZ81Ui0m-9KwlBY1L_18myuGuq1wfhWSaZgMttyVfPaERSR0Wqmu7LAocGIGz3UqlXOLrxM-vMGmW8VNxu5Dx60noTyL3n5vh7h1I4PeRarNSIvySHXOvzedxuPUnSS-3wEx362jWw9eodnLGaFMhCZUlQO5etBe_k9XlNuvkslDcg91FxDK-0H3uRMe02w\"}",
                "{\"name\":\"Glock-18 | Trace"
                    + " Lock\",\"category\":{\"id\":\"csgo_inventory_weapon_category_pistols\",\"name\":\"Pistols\"},\"min_float\":0,\"max_float\":0.7,\"rarity\":{\"id\":\"rarity_mythical_weapon\",\"name\":\"Restricted\",\"color\":\"#8847ff\"},\"crates\":[],\"image\":\"https://community.akamai.steamstatic.com/economy/image/i0CoZ81Ui0m-9KwlBY1L_18myuGuq1wfhWSaZgMttyVfPaERSR0Wqmu7LAocGIGz3UqlXOLrxM-vMGmW8VNxu5Dx60noTyL2kpnj9h1T-825YK15Jc-WCmCV0tF6ueZhW2fiw0Ujt2yGy4ysIHzEaQUlWJJyE-dbsBK5x4XjM7ix7gDeiYkUmy6okGoXubB2-hmv\"}",
                "{\"name\":\"P2000 | Grip"
                    + " Tape\",\"category\":{\"id\":\"csgo_inventory_weapon_category_pistols\",\"name\":\"Pistols\"},\"min_float\":0,\"max_float\":0.75,\"rarity\":{\"id\":\"rarity_rare_weapon\",\"name\":\"Mil-Spec"
                    + " Grade\",\"color\":\"#4b69ff\"},\"crates\":[],\"image\":\"https://community.akamai.steamstatic.com/economy/image/i0CoZ81Ui0m-9KwlBY1L_18myuGuq1wfhWSaZgMttyVfPaERSR0Wqmu7LAocGIGz3UqlXOLrxM-vMGmW8VNxu5Dx60noTyL5lYayrXIL0OGhbZt9cqDDXliX0-dmo95lRi67gVMlsj7SmNiuIHmfaA4gDZEhQeBZuxa7m4CxYu-w7geL2osRxS6qiSIc8G81tBwotro2\"}",
                "{\"name\":\"M249 |"
                    + " Sleet\",\"category\":{\"id\":\"csgo_inventory_weapon_category_heavy\",\"name\":\"Heavy\"},\"min_float\":0,\"max_float\":0.7,\"rarity\":{\"id\":\"rarity_common_weapon\",\"name\":\"Consumer"
                    + " Grade\",\"color\":\"#b0c3d9\"},\"crates\":[],\"image\":\"https://community.akamai.steamstatic.com/economy/image/i0CoZ81Ui0m-9KwlBY1L_18myuGuq1wfhWSaZgMttyVfPaERSR0Wqmu7LAocGIGz3UqlXOLrxM-vMGmW8VNxu5Dx60noTyL8zMK5wipC6s2jOvA0H_OSHFiH0-9mj7JWQyC0nQlp6zzQwtiudHvCO1MlDJByQuIC4UO7lta0Zuy0swPZiNhDxSv33C0f6zErvbjSvv-GUg\"}",
                "{\"name\":\"M4A4 | Aeolian"
                    + " Dark\",\"category\":{\"id\":\"csgo_inventory_weapon_category_rifles\",\"name\":\"Rifles\"},\"min_float\":0,\"max_float\":0.65,\"rarity\":{\"id\":\"rarity_uncommon_weapon\",\"name\":\"Industrial"
                    + " Grade\",\"color\":\"#5e98d9\"},\"crates\":[],\"image\":\"https://community.akamai.steamstatic.com/economy/image/i0CoZ81Ui0m-9KwlBY1L_18myuGuq1wfhWSaZgMttyVfPaERSR0Wqmu7LAocGIGz3UqlXOLrxM-vMGmW8VNxu5Dx60noTyL8ypexwipC6s2vard5MvGQGlibz-Fij-w9cCW6khUz_TvQnt37cS_EaQAgDMciEbVb4EK4ktzvZb_ltlOI3o4RmHmt23xKvSh1o7FVNKLRyHM\"}",
                "{\"name\":\"MAC-10 | Snow"
                    + " Splash\",\"category\":{\"id\":\"csgo_inventory_weapon_category_smgs\",\"name\":\"SMGs\"},\"min_float\":0,\"max_float\":0.6,\"rarity\":{\"id\":\"rarity_uncommon_weapon\",\"name\":\"Industrial"
                    + " Grade\",\"color\":\"#5e98d9\"},\"crates\":[],\"image\":\"https://community.akamai.steamstatic.com/economy/image/i0CoZ81Ui0m-9KwlBY1L_18myuGuq1wfhWSaZgMttyVfPaERSR0Wqmu7LAocGIGz3UqlXOLrxM-vMGmW8VNxu5Dx60noTyL8n5WxrR1T9veRa6V_H-eBD3fE_uJ_t-l9ASrklhkk4Wrdm9msIy3DblVyA5cmQLMDtxS_ltPmYe_msgbeiY5EziTgznQeYbrm-7Y\"}",
                "{\"name\":\"MP5-SD | Snow"
                    + " Splash\",\"category\":{\"id\":\"csgo_inventory_weapon_category_smgs\",\"name\":\"SMGs\"},\"min_float\":0,\"max_float\":0.6,\"rarity\":{\"id\":\"rarity_uncommon_weapon\",\"name\":\"Industrial"
                    + " Grade\",\"color\":\"#5e98d9\"},\"crates\":[],\"image\":\"https://community.akamai.steamstatic.com/economy/image/i0CoZ81Ui0m-9KwlBY1L_18myuGuq1wfhWSaZgMttyVfPaERSR0Wqmu7LAocGIGz3UqlXOLrxM-vMGmW8VNxu5Dx60noTyL8jsPz-R1T9veRZbQ4H_OSHFiH0-9m5N5lRi67gVMk5WXQztarIHiVbQ8lApF2F7QN5xS_xtfnNujqswTWidhAnyr3jngc8G81tMzA05Bb\"}",
                "{\"name\":\"MP9 |"
                    + " Dizzy\",\"category\":{\"id\":\"csgo_inventory_weapon_category_smgs\",\"name\":\"SMGs\"},\"min_float\":0,\"max_float\":0.65,\"rarity\":{\"id\":\"rarity_common_weapon\",\"name\":\"Consumer"
                    + " Grade\",\"color\":\"#b0c3d9\"},\"crates\":[],\"image\":\"https://community.akamai.steamstatic.com/economy/image/i0CoZ81Ui0m-9KwlBY1L_18myuGuq1wfhWSaZgMttyVfPaERSR0Wqmu7LAocGIGz3UqlXOLrxM-vMGmW8VNxu5Dx60noTyL8js_f7i1e0PaqeKV5H-OEB3Wc_uxhj-1gSCGn204k5mXQwoz4dnrDaQ92CMB3R7FZtxa4mtfkZuyx5gHb2YNNz336jyxXrnE8H46mzhg\"}",
                "{\"name\":\"Nova |"
                    + " Currents\",\"category\":{\"id\":\"csgo_inventory_weapon_category_heavy\",\"name\":\"Heavy\"},\"min_float\":0,\"max_float\":0.65,\"rarity\":{\"id\":\"rarity_common_weapon\",\"name\":\"Consumer"
                    + " Grade\",\"color\":\"#b0c3d9\"},\"crates\":[],\"image\":\"https://community.akamai.steamstatic.com/economy/image/i0CoZ81Ui0m-9KwlBY1L_18myuGuq1wfhWSaZgMttyVfPaERSR0Wqmu7LAocGIGz3UqlXOLrxM-vMGmW8VNxu5Dx60noTyL_kYDhwipC6s2pbatvKeKXHVicyOl-pK87TSrqzBwisWXTz9qvJXnFOgcnW5J1RLEPuhe_mtHgPuqws1SPi4tA02yg2UgVtCWp\"}",
                "{\"name\":\"P250 |"
                    + " Sleet\",\"category\":{\"id\":\"csgo_inventory_weapon_category_pistols\",\"name\":\"Pistols\"},\"min_float\":0,\"max_float\":0.7,\"rarity\":{\"id\":\"rarity_common_weapon\",\"name\":\"Consumer"
                    + " Grade\",\"color\":\"#b0c3d9\"},\"crates\":[],\"image\":\"https://community.akamai.steamstatic.com/economy/image/i0CoZ81Ui0m-9KwlBY1L_18myuGuq1wfhWSaZgMttyVfPaERSR0Wqmu7LAocGIGz3UqlXOLrxM-vMGmW8VNxu5Dx60noTyLhzMOwwipC6s2tabZSN-KSHljD_uJ_t-l9AXCwxhwi6j_Syoysc36TbAAhXpYiRuIPshLsk4bnYemw7wCKiNoUyC7gznQekhpLnpY\"}",
                "{\"name\":\"P90 | Aeolian"
                    + " Light\",\"category\":{\"id\":\"csgo_inventory_weapon_category_smgs\",\"name\":\"SMGs\"},\"min_float\":0,\"max_float\":0.65,\"rarity\":{\"id\":\"rarity_rare_weapon\",\"name\":\"Mil-Spec"
                    + " Grade\",\"color\":\"#4b69ff\"},\"crates\":[],\"image\":\"https://community.akamai.steamstatic.com/economy/image/i0CoZ81Ui0m-9KwlBY1L_18myuGuq1wfhWSaZgMttyVfPaERSR0Wqmu7LAocGIGz3UqlXOLrxM-vMGmW8VNxu5Dx60noTyLhx8bf9Tte0POse7B_IfOHMWyezvpJvOhuRz39zER2tWvVyd2qdXOeaVN2WJV3Qu9Z50GwxNa1NLji4gPfjINDziv8iDQJsHgxRzCSnw\"}",
                "{\"name\":\"R8 Revolver | Dark"
                    + " Chamber\",\"category\":{\"id\":\"csgo_inventory_weapon_category_pistols\",\"name\":\"Pistols\"},\"min_float\":0,\"max_float\":0.80339,\"rarity\":{\"id\":\"rarity_uncommon_weapon\",\"name\":\"Industrial"
                    + " Grade\",\"color\":\"#5e98d9\"},\"crates\":[],\"image\":\"https://community.akamai.steamstatic.com/economy/image/i0CoZ81Ui0m-9KwlBY1L_18myuGuq1wfhWSaZgMttyVfPaERSR0Wqmu7LAocGIGz3UqlXOLrxM-vMGmW8VNxu5Dx60noTyLjm4Dv8TRe_c29Z6dlH-OeAWyV_ulkufF6cCW6khUz_WqGmNatdnzDbAR0CcR2FLQO4UKxxNfuM-rj4QzX3YsTziuqiHgf7351o7FV2A-FKGc\"}",
                "{\"name\":\"SCAR-20 |"
                    + " Zinc\",\"category\":{\"id\":\"csgo_inventory_weapon_category_rifles\",\"name\":\"Rifles\"},\"min_float\":0,\"max_float\":0.6,\"rarity\":{\"id\":\"rarity_common_weapon\",\"name\":\"Consumer"
                    + " Grade\",\"color\":\"#b0c3d9\"},\"crates\":[],\"image\":\"https://community.akamai.steamstatic.com/economy/image/i0CoZ81Ui0m-9KwlBY1L_18myuGuq1wfhWSaZgMttyVfPaERSR0Wqmu7LAocGIGz3UqlXOLrxM-vMGmW8VNxu5Dx60noTyLinZfyr3Jk5-urV6dlMv-eC1iCyP5mvORWQyC0nQlpsD7Qydr6dSjEO1MnD5RzRuUIskPpl9zmN-7i5FbYj49NmXj4jXhP6TErvbhHIJnnmg\"}",
                "{\"name\":\"SSG 08 | Sans"
                    + " Comic\",\"category\":{\"id\":\"csgo_inventory_weapon_category_rifles\",\"name\":\"Rifles\"},\"min_float\":0,\"max_float\":0.5,\"rarity\":{\"id\":\"rarity_common_weapon\",\"name\":\"Consumer"
                    + " Grade\",\"color\":\"#b0c3d9\"},\"crates\":[],\"image\":\"https://community.akamai.steamstatic.com/economy/image/i0CoZ81Ui0m-9KwlBY1L_18myuGuq1wfhWSaZgMttyVfPaERSR0Wqmu7LAocGIGz3UqlXOLrxM-vMGmW8VNxu5Dx60noTyLijZGwpR1T9veRa6tgKfOsHW-R0etlj-1gSCGn20wl5W3VmImqcCmWOlAjXpolR-MP50Wwl9DmMOix5QXZ2d5EzSWqi3tXrnE8nx7Jn58\"}"
              })
          + "]";
}
