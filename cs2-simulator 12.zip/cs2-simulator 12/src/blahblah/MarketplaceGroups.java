package blahblah;

import java.util.*;

/**
 * Bounded catalog groups reference real stock lots; collapsing never changes or duplicates stock.
 */
final class MarketplaceGroups {
  private final hGui app;

  MarketplaceGroups(hGui app) {
    this.app = app;
  }

  static final class Group {
    final String key;
    final List<MarketListing> lots = new ArrayList<>();

    Group(String key) {
      this.key = key;
    }

    MarketListing head() {
      return lots.get(0);
    }

    int units() {
      long n = 0;
      for (MarketListing l : lots) n += Math.max(0, l.quantity);
      return (int) Math.min(Integer.MAX_VALUE, n);
    }
  }

  List<Group> group(List<MarketListing> input) {
    Map<String, Group> groups = new LinkedHashMap<>();
    for (MarketListing lot : input) {
      if (lot.quantity <= 0) continue;
      if ((!Double.isFinite(lot.getPrice()) || lot.getPrice() <= 0)
          && app.exchangeStockService.exchangeContainer(lot.item.name) == null) continue;
      String key = MarketplacePricing.variant(lot.item);
      // Float/pattern live in individual offers. Containers with the same variant are a single
      // stack.
      groups.computeIfAbsent(key, Group::new).lots.add(lot);
    }
    for (Group group : groups.values())
      group.lots.sort(Comparator.comparingDouble(app.marketplaceUnitStock::floorAsk));
    return new ArrayList<>(groups.values());
  }

  Map<String, List<InventoryItem>> owned(List<InventoryItem> items) {
    Map<String, List<InventoryItem>> groups = new LinkedHashMap<>();
    for (InventoryItem item : items)
      groups.computeIfAbsent(MarketplacePricing.variant(item), k -> new ArrayList<>()).add(item);
    return groups;
  }
}
