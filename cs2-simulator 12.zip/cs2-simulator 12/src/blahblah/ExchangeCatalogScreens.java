package blahblah;

import blahblah.hGui.*;
import java.awt.*;
import java.awt.event.*;
import java.util.ArrayList;
import java.util.Comparator;
import java.util.List;
import javax.swing.*;

/** Exchange Catalog Screens: focused feature implementation. */
final class ExchangeCatalogScreens {
  private final hGui app;

  ExchangeCatalogScreens(hGui app) {
    this.app = app;
  }

  JPanel createExchangeListingCard(
      MarketplaceProfile p, MarketListing lot, Runnable action, boolean swap) {
    JPanel card = app.exchangeWidgets.exchangePanel(p, new BorderLayout(0, 8));
    card.setName("exchangeListingCard");
    card.putClientProperty("marketListing", lot);
    int style = app.exchangeTransactionService.exchangeStyle(p);
    Color accent = app.exchangeWidgets.exchangeAccent(p),
        rarity = app.itemInspectionScreen.getRarityColor(lot.item.rarity.replace("StatTrak ", ""));
    Color bg = app.exchangeWidgets.exchangeBackground(p);
    card.setBackground(
        new Color(
            Math.min(255, bg.getRed() + 9),
            Math.min(255, bg.getGreen() + 9),
            Math.min(255, bg.getBlue() + 10)));
    card.setBorder(
        BorderFactory.createCompoundBorder(
            BorderFactory.createMatteBorder(
                style == 12 ? 1 : 0,
                style == 17 ? 2 : 0,
                style == 16 ? 1 : 3,
                style == 12 ? 1 : 0,
                style == 16 ? accent : rarity),
            BorderFactory.createEmptyBorder(10, 11, 10, 11)));
    card.setPreferredSize(new Dimension(190, 266));
    JLabel art = new JLabel("", SwingConstants.CENTER);
    art.setPreferredSize(new Dimension(180, 120));
    CaseType ct = app.exchangeStockService.exchangeContainer(lot.item.name);
    if (ct == null)
      app.artworkService.getSkinImageFromName(lot.item.name, lot.item.condition, art, 180, 120);
    else app.cs2Screens.bindCs2SupplyArtwork(ct, false, art, 180, 120);
    String title = (lot.item.isStattrak ? "ST™ " : "") + lot.item.name;
    JLabel name =
        app.exchangeWidgets.exchangeLabel(
            "<html>" + app.marketItemCards.escapeHtml(title) + "</html>", 12, Color.WHITE);
    name.setToolTipText(title);
    JLabel price =
        app.exchangeWidgets.exchangeLabel(
            !Double.isFinite(lot.getPrice())
                ? "Quote unavailable"
                : String.format(
                    "$%,.2f",
                    swap ? app.exchangeTransactionService.swapSiteValue(lot) : lot.getPrice()),
            20,
            Color.WHITE);
    if ("Karambit | Doppler (Ruby)".equals(lot.item.name) && "Minimal Wear".equals(lot.item.condition))
      price.setToolTipText("Simulated offer. Illiquid MW outliers use a modeled wear-discounted Ruby FN reference, not a live MW quote.");
    if (ct != null)
      price.setToolTipText(
          app.caseQuoteDescriptions.getOrDefault(ct.id, "Verified public cash quote unavailable"));
    JLabel qty =
        app.exchangeWidgets.exchangeLabel(
            String.format("%s  •  %,d available", lot.item.condition, lot.quantity),
            10,
            Theme.TEXT_DIM);
    qty.setName("exchangeLotQuantity");
    JPanel details = app.cs2Screens.cs2Glass(new GridLayout(0, 1, 0, 5));
    details.add(price);
    details.add(name);
    details.add(qty);
    if (ct == null && !app.floatRules.hasNoFloatWear(lot.item.name)) {
      JComponent wear = app.exchangeWidgets.exchangeWearStrip(lot.item.itemFloat);
      details.add(wear);
    }
    if (style == 1 || style == 5) {
      card.add(name, BorderLayout.NORTH);
      card.add(art);
      details.remove(name);
      card.add(details, BorderLayout.SOUTH);
    } else if (style == 16) {
      card.add(qty, BorderLayout.NORTH);
      details.remove(qty);
      card.add(art);
      card.add(details, BorderLayout.SOUTH);
    } else {
      card.add(art);
      card.add(details, BorderLayout.SOUTH);
    }
    if (action != null)
      app.cs2Screens.installCs2CardClick(
          card,
          new MouseAdapter() {
            public void mouseClicked(MouseEvent e) {
              if (SwingUtilities.isLeftMouseButton(e)) action.run();
            }
          });
    return card;
  }

  boolean exchangeMatchesCategory(MarketListing l, String category) {
    String rarity = l.item.rarity.replace("StatTrak ", "");
    switch (category) {
      case "Knives":
        return "Knife".equals(rarity);
      case "Gloves":
        return "Gloves".equals(rarity);
      case "Cases":
        return app.exchangeStockService.exchangeContainer(l.item.name) != null;
      case "Agents":
        return app.itemMetadataService.isAgentSkin(l.item.name);
      case "Rifles":
        return java.util.Arrays.asList(hGui.CT_SLOTS_RIFLE)
                .contains(app.marketFilterControls.extractWeaponType(l.item.name))
            || java.util.Arrays.asList(hGui.T_SLOTS_RIFLE)
                .contains(app.marketFilterControls.extractWeaponType(l.item.name));
      case "Pistols":
        return java.util.Arrays.asList(hGui.CT_SLOTS_PISTOL)
                .contains(app.marketFilterControls.extractWeaponType(l.item.name))
            || java.util.Arrays.asList(hGui.CT_SLOTS_OTHER)
                .contains(app.marketFilterControls.extractWeaponType(l.item.name))
            || java.util.Arrays.asList(hGui.T_SLOTS_PISTOL)
                .contains(app.marketFilterControls.extractWeaponType(l.item.name))
            || java.util.Arrays.asList(hGui.T_SLOTS_OTHER)
                .contains(app.marketFilterControls.extractWeaponType(l.item.name));
      default:
        return true;
    }
  }

  JPanel createExchangeBuy(MarketplaceProfile p, String initialSearch) {
    return new MarketplaceBuyScreen(app).create(p, initialSearch);
  }

  JPanel createExchangeSell(MarketplaceProfile p, InventoryItem preselect) {
    JPanel root = app.exchangeWidgets.exchangePanel(p, new BorderLayout(20, 12));
    root.setName("exchangeSell");
    root.setBorder(BorderFactory.createEmptyBorder(20, 22, 18, 22));
    JTextField search = app.exchangeWidgets.exchangeSearch("");
    search.setName("exchangeSellSearch");
    root.add(search, BorderLayout.NORTH);
    JPanel grid = app.cs2Screens.cs2Grid(5, 12, 14);
    grid.setName("exchangeSellGrid");
    root.add(app.exchangeWidgets.exchangeScroll(grid));
    JPanel desk = app.exchangeWidgets.exchangePanel(p, new BorderLayout(0, 16));
    desk.setPreferredSize(new Dimension(275, 0));
    desk.setBorder(
        BorderFactory.createCompoundBorder(
            BorderFactory.createMatteBorder(0, 2, 0, 0, app.exchangeWidgets.exchangeAccent(p)),
            BorderFactory.createEmptyBorder(16, 18, 16, 0)));
    InventoryItem[] selected = {preselect};
    JPanel summary = app.cs2Screens.cs2Glass(new GridLayout(0, 1, 0, 14));
    desk.add(summary, BorderLayout.NORTH);
    JPanel acts = app.cs2Screens.cs2Glass(new GridLayout(0, 1, 0, 12));
    JTextField ask =
        app.exchangeWidgets.exchangeSearch(
            preselect == null
                ? ""
                : String.format(
                    java.util.Locale.US, "%.2f", app.marketplacePricing.suggested(p, preselect)));
    ask.setName("exchangeSellAsk");
    ask.putClientProperty("placeholder", "Asking price");
    boolean automatic = MarketplacePricing.automatic(p.name);
    ask.setEditable(!automatic);
    ask.setToolTipText(
        automatic
            ? "This site automatically quotes the same price for a skin, wear and StatTrak variant."
            : "Set your asking price; you may undercut the cheapest comparable offer.");
    acts.add(
        app.exchangeWidgets.exchangeLabel(
            automatic ? "Automatic site price (USD)" : "Your asking price (USD)",
            12,
            Theme.TEXT_DIM));
    if (!automatic) {
      JButton undercut =
          app.exchangeWidgets.exchangeButton(
              p,
              "Lowest − $0.01",
              () -> {
                if (selected[0] != null)
                  ask.setText(
                      String.format(
                          java.util.Locale.US,
                          "%.2f",
                          app.marketplacePricing.suggested(p, selected[0])));
              });
      undercut.setName("exchangeUndercut");
      acts.add(undercut);
    }
    acts.add(ask);
    JLabel proceeds =
        app.exchangeWidgets.exchangeLabel("", 13, app.exchangeWidgets.exchangeAccent(p));
    acts.add(proceeds);
    desk.add(acts);
    Runnable updateSummary =
        () -> {
          summary.removeAll();
          InventoryItem i = selected[0];
          summary.add(
              app.exchangeWidgets.exchangeLabel(
                  "SELL ON " + p.name.toUpperCase(java.util.Locale.ROOT), 17, Color.WHITE));
          summary.add(
              app.exchangeWidgets.exchangeLabel(
                  i == null
                      ? "Choose a skin from your inventory"
                      : "<html>" + app.marketItemCards.escapeHtml(i.name) + "</html>",
                  15,
                  Theme.TEXT));
          if (i != null && automatic && !Double.isFinite(app.marketplacePricing.quote(p, i)))
            ask.setText("Quote unavailable");
          else if (i != null && automatic)
            ask.setText(
                String.format(java.util.Locale.US, "%.2f", app.marketplacePricing.quote(p, i)));
          if (i != null)
            summary.add(
                app.exchangeWidgets.exchangeLabel(
                    String.format("Reference $%,.2f", i.price.doubleValue()), 14, Color.WHITE));
          summary.add(
              app.exchangeWidgets.exchangeLabel(
                  String.format(
                      "Quick sell: %.0f%% deduction",
                      app.exchangeTransactionService.exchangeQuickSellLoss(p) * 100),
                  12,
                  Theme.TEXT_DIM));
          summary.add(
              app.exchangeWidgets.exchangeLabel(
                  String.format(
                      "List: %.1f%% fee when sold",
                      app.exchangeTransactionService.exchangeListingFee(p) * 100),
                  12,
                  Theme.TEXT_DIM));
          summary.revalidate();
          summary.repaint();
        };
    Runnable net =
        () -> {
          try {
            double price = Double.parseDouble(ask.getText());
            if (!Double.isFinite(price) || price <= 0) throw new IllegalArgumentException();
            proceeds.setText(
                String.format(
                    "You receive $%,.2f after fee",
                    price * (1 - app.exchangeTransactionService.exchangeListingFee(p))));
          } catch (Exception e) {
            proceeds.setText("Enter an asking price");
          }
        };
    app.exchangeWidgets.exchangeDebounce(ask, net);
    JButton quick =
        app.exchangeWidgets.exchangeButton(
            p,
            "QUICK SELL",
            () -> {
              InventoryItem i = selected[0];
              if (i == null) return;
              double quote = app.marketplacePricing.quickSellQuote(p, i);
              if (JOptionPane.showConfirmDialog(
                      app,
                      String.format(
                          "Quick sell %s for $%,.2f?\n%.0f%% deduction. Paid immediately.",
                          i.name,
                          quote,
                          app.exchangeTransactionService.exchangeQuickSellLoss(p) * 100),
                      "Quick sell",
                      JOptionPane.YES_NO_OPTION)
                  == JOptionPane.YES_OPTION)
                try {
                  app.exchangeTransactionService.commitExchangeQuickSell(p, i, quote);
                  selected[0] = null;
                  ((Runnable) root.getClientProperty("refreshExchange")).run();
                } catch (Exception e) {
                  JOptionPane.showMessageDialog(app, e.getMessage());
                }
            });
    JButton list =
        app.exchangeWidgets.exchangeButton(
            p,
            "LIST FOR SALE",
            () -> {
              try {
                InventoryItem i = selected[0];
                if (i == null) throw new IllegalArgumentException("Choose a skin first.");
                double value = Double.parseDouble(ask.getText());
                if (JOptionPane.showConfirmDialog(
                        app,
                        String.format(
                            "List %s for $%,.2f?\nNet proceeds after %.1f%% fee: $%,.2f",
                            i.name,
                            value,
                            app.exchangeTransactionService.exchangeListingFee(p) * 100,
                            value * (1 - app.exchangeTransactionService.exchangeListingFee(p))),
                        "Confirm listing",
                        JOptionPane.YES_NO_OPTION)
                    == JOptionPane.YES_OPTION) {
                  app.exchangeTransactionService.commitExchangeListing(p, i, value);
                  selected[0] = null;
                  ((Runnable) root.getClientProperty("refreshExchange")).run();
                }
              } catch (Exception e) {
                JOptionPane.showMessageDialog(app, e.getMessage());
              }
            });
    acts.add(quick);
    acts.add(list);
    root.add(
        desk,
        app.exchangeTransactionService.exchangeStyle(p) % 2 == 0
            ? BorderLayout.EAST
            : BorderLayout.WEST);
    int[] page = {0};
    JLabel status = app.exchangeWidgets.exchangeLabel("", 12, Theme.TEXT_DIM);
    JPanel paging = app.cs2Screens.cs2Glass(new FlowLayout());
    JButton prev = app.exchangeWidgets.exchangeButton(p, "‹", () -> {}),
        next = app.exchangeWidgets.exchangeButton(p, "›", () -> {});
    paging.add(prev);
    paging.add(status);
    paging.add(next);
    root.add(paging, BorderLayout.SOUTH);
    Runnable render =
        () -> {
          if (selected[0] != null && !app.containerMarketService.owns(selected[0]))
            selected[0] = null;
          List<InventoryItem> items = new ArrayList<>();
          for (InventoryItem i : app.containerMarketService.sellableInventory())
            if (!app.cs2EquipmentScreens.isDefaultWeaponItem(i)
                && i.name
                    .toLowerCase(java.util.Locale.ROOT)
                    .contains(search.getText().toLowerCase(java.util.Locale.ROOT))) items.add(i);
          if (selected[0] != null && selected[0].itemId != null)
            for (int n = 0; n < items.size(); n++)
              if (selected[0].itemId.equals(items.get(n).itemId)) items.set(n, selected[0]);
          List<List<InventoryItem>> stacks =
              new ArrayList<>(app.marketplaceGroups.owned(items).values());
          int pages = Math.max(1, (stacks.size() + 29) / 30);
          page[0] = Math.max(0, Math.min(page[0], pages - 1));
          grid.removeAll();
          for (int n = page[0] * 30; n < Math.min(stacks.size(), (page[0] + 1) * 30); n++) {
            List<InventoryItem> stack = stacks.get(n);
            InventoryItem i = stack.get(0);
            java.util.function.Consumer<InventoryItem> choose =
                item -> {
                  selected[0] = item;
                  ask.setText(
                      String.format(
                          java.util.Locale.US, "%.2f", app.marketplacePricing.suggested(p, item)));
                  ((Runnable) root.getClientProperty("refreshExchange")).run();
                };
            JPanel card =
                app.cs2Screens.createCs2SkinCard(
                    i,
                    () -> {
                      if (stack.size() == 1) choose.accept(i);
                      else
                        new MarketplaceStackPicker(app)
                            .owned(p, root, stack, item -> item == selected[0], choose, true);
                    });
            JPanel wrap = app.exchangeWidgets.exchangePanel(p, new BorderLayout());
            wrap.add(card);
            wrap.add(
                app.exchangeWidgets.exchangeLabel(
                    stack.size() + "× owned / choose individual skin", 12, Theme.TEXT_DIM),
                BorderLayout.SOUTH);
            wrap.putClientProperty("ownedStack", stack);
            app.marketCardSelection.select(
                wrap, stack.contains(selected[0]), app.exchangeWidgets.exchangeAccent(p));
            grid.add(wrap);
          }
          status.setText(
              items.size()
                  + " skins / "
                  + stacks.size()
                  + " stacks  •  "
                  + (page[0] + 1)
                  + " / "
                  + pages);
          prev.setEnabled(page[0] > 0);
          next.setEnabled(page[0] + 1 < pages);
          quick.setEnabled(
              selected[0] != null
                  && Double.isFinite(app.marketplacePricing.quickSellQuote(p, selected[0])));
          list.setEnabled(
              selected[0] != null
                  && (!automatic || Double.isFinite(app.marketplacePricing.quote(p, selected[0]))));
          updateSummary.run();
          net.run();
          grid.revalidate();
          grid.repaint();
        };
    prev.addActionListener(
        e -> {
          page[0]--;
          render.run();
        });
    next.addActionListener(
        e -> {
          page[0]++;
          render.run();
        });
    app.exchangeWidgets.exchangeDebounce(
        search,
        () -> {
          page[0] = 0;
          render.run();
        });
    root.putClientProperty("refreshExchange", render);
    JPanel sellBody = app.exchangeWidgets.exchangePanel(p, new BorderLayout());
    sellBody.add(app.exchangeWidgets.exchangeScroll(grid));
    app.marketSiteLayouts.compose(p, root, search, sellBody, desk, paging, "Sell");
    render.run();
    return root;
  }

  JPanel createExchangeSwap(MarketplaceProfile p) {
    JPanel root = app.exchangeWidgets.exchangePanel(p, new BorderLayout(0, 12));
    root.setName("exchangeSwap");
    root.setBorder(BorderFactory.createEmptyBorder(18, 20, 18, 20));
    List<InventoryItem> given = new ArrayList<>();
    List<MarketListing> wanted = new ArrayList<>();
    JPanel halves = app.exchangeWidgets.exchangePanel(p, new GridLayout(1, 2, 20, 0));
    JPanel left = app.exchangeWidgets.exchangePanel(p, new BorderLayout(0, 12)),
        right = app.exchangeWidgets.exchangePanel(p, new BorderLayout(0, 12));
    left.setName("exchangeSwapUserHalf");
    right.setName("exchangeSwapSiteHalf");
    JTextField userSearch = app.exchangeWidgets.exchangeSearch(""),
        siteSearch = app.exchangeWidgets.exchangeSearch("");
    JLabel userTotal = app.exchangeWidgets.exchangeLabel("You offer  $0.00", 19, Color.WHITE),
        siteTotal = app.exchangeWidgets.exchangeLabel("You receive  $0.00", 19, Color.WHITE);
    JPanel lh = app.cs2Screens.cs2Glass(new GridLayout(0, 1, 0, 10)),
        rh = app.cs2Screens.cs2Glass(new GridLayout(0, 1, 0, 10));
    lh.add(userTotal);
    lh.add(
        app.exchangeWidgets.exchangeLabel(
            "YOUR INVENTORY  /  Reference +5%", 12, app.exchangeWidgets.exchangeAccent(p)));
    lh.add(userSearch);
    rh.add(siteTotal);
    rh.add(
        app.exchangeWidgets.exchangeLabel(
            p.name.toUpperCase(java.util.Locale.ROOT) + "  /  Reference +10–15%",
            12,
            app.exchangeWidgets.exchangeAccent(p)));
    rh.add(siteSearch);
    left.add(lh, BorderLayout.NORTH);
    right.add(rh, BorderLayout.NORTH);
    JPanel ug = app.cs2Screens.cs2Grid(3, 10, 12), sg = app.cs2Screens.cs2Grid(3, 10, 12);
    ug.setName("exchangeSwapUserGrid");
    sg.setName("exchangeSwapSiteGrid");
    left.add(app.exchangeWidgets.exchangeScroll(ug));
    right.add(app.exchangeWidgets.exchangeScroll(sg));
    halves.add(left);
    halves.add(right);
    root.add(halves);
    JPanel footer = app.exchangeWidgets.exchangePanel(p, new BorderLayout(12, 0));
    JLabel difference =
        app.exchangeWidgets.exchangeLabel(
            "Select skins on both sides", 16, app.exchangeWidgets.exchangeAccent(p));
    difference.setName("exchangeSwapDifference");
    footer.add(difference);
    JButton commit =
        app.exchangeWidgets.exchangeButton(
            p,
            "CONFIRM " + app.exchangeWidgets.exchangeSwapTab(p).toUpperCase(java.util.Locale.ROOT),
            () -> {});
    commit.setName("exchangeSwapConfirm");
    footer.add(commit, BorderLayout.EAST);
    root.add(footer, BorderLayout.SOUTH);
    double[] debit = {0};
    Runnable totals =
        () -> {
          double credit = 0, cost = 0;
          for (InventoryItem i : given) credit += app.exchangeTransactionService.swapUserValue(i);
          for (MarketListing l : wanted) cost += app.exchangeTransactionService.swapSiteValue(l);
          debit[0] =
              app.coreUtilities.money(cost).subtract(app.coreUtilities.money(credit)).doubleValue();
          userTotal.setText(String.format("You offer  $%,.2f  (%d)", credit, given.size()));
          siteTotal.setText(String.format("You receive  $%,.2f  (%d)", cost, wanted.size()));
          difference.setText(
              debit[0] >= 0
                  ? String.format("Top-up required: $%,.2f", debit[0])
                  : String.format("Balance returned: $%,.2f", -debit[0]));
          commit.setEnabled(!given.isEmpty() && !wanted.isEmpty() && debit[0] <= app.balance);
        };
    int[] up = {0}, sp = {0};
    Runnable[] render = {null};
    JPanel ulp = app.cs2Screens.cs2Glass(new FlowLayout()),
        slp = app.cs2Screens.cs2Glass(new FlowLayout());
    JLabel un = app.exchangeWidgets.exchangeLabel("", 12, Theme.TEXT_DIM),
        sn = app.exchangeWidgets.exchangeLabel("", 12, Theme.TEXT_DIM);
    JButton ub = app.exchangeWidgets.exchangeButton(p, "‹", () -> {}),
        uf = app.exchangeWidgets.exchangeButton(p, "›", () -> {}),
        sb = app.exchangeWidgets.exchangeButton(p, "‹", () -> {}),
        sf = app.exchangeWidgets.exchangeButton(p, "›", () -> {});
    ulp.add(ub);
    ulp.add(un);
    ulp.add(uf);
    slp.add(sb);
    slp.add(sn);
    slp.add(sf);
    left.add(ulp, BorderLayout.SOUTH);
    right.add(slp, BorderLayout.SOUTH);
    render[0] =
        () -> {
          given.removeIf(i -> !app.inventoryList.contains(i));
          wanted.removeIf(l -> !app.exchangeTransactionService.isExchangeLotAvailable(l));
          List<InventoryItem> users = new ArrayList<>();
          for (InventoryItem i : app.inventoryList)
            if (!app.cs2EquipmentScreens.isDefaultWeaponItem(i)
                && i.name
                    .toLowerCase(java.util.Locale.ROOT)
                    .contains(userSearch.getText().toLowerCase(java.util.Locale.ROOT)))
              users.add(i);
          List<MarketListing> site = new ArrayList<>();
          for (MarketListing l :
              app.exchangeSiteStock.getOrDefault(p.name, java.util.Collections.emptyList()))
            if (!l.isPlayerListing
                && l.quantity > 0
                && app.exchangeStockService.exchangeContainer(l.item.name) == null
                && l.item
                    .name
                    .toLowerCase(java.util.Locale.ROOT)
                    .contains(siteSearch.getText().toLowerCase(java.util.Locale.ROOT))) site.add(l);
          site.sort(Comparator.comparingDouble(MarketListing::getPrice).reversed());
          List<List<InventoryItem>> userStacks =
              new ArrayList<>(app.marketplaceGroups.owned(users).values());
          List<MarketplaceGroups.Group> siteStacks = app.marketplaceGroups.group(site);
          int ups = Math.max(1, (userStacks.size() + 17) / 18),
              sps = Math.max(1, (siteStacks.size() + 17) / 18);
          up[0] = Math.max(0, Math.min(up[0], ups - 1));
          sp[0] = Math.max(0, Math.min(sp[0], sps - 1));
          ug.removeAll();
          sg.removeAll();
          java.util.function.Consumer<InventoryItem> chooseUser =
              item -> {
                if (given.contains(item)) given.remove(item);
                else given.add(item);
                render[0].run();
              };
          java.util.function.Consumer<MarketListing> chooseLot =
              lot -> {
                if (wanted.contains(lot)) wanted.remove(lot);
                else wanted.add(lot);
                render[0].run();
              };
          for (int n = up[0] * 18; n < Math.min(userStacks.size(), (up[0] + 1) * 18); n++) {
            List<InventoryItem> stack = userStacks.get(n);
            InventoryItem i = stack.get(0);
            JPanel card =
                app.cs2Screens.createCs2SkinCard(
                    i,
                    () -> {
                      if (stack.size() == 1) chooseUser.accept(i);
                      else
                        new MarketplaceStackPicker(app)
                            .owned(p, root, stack, given::contains, chooseUser, false);
                    });
            JPanel wrap = app.exchangeWidgets.exchangePanel(p, new BorderLayout());
            wrap.add(card);
            long selectedCount = stack.stream().filter(given::contains).count();
            wrap.add(
                app.exchangeWidgets.exchangeLabel(
                    String.format(
                        "%d× / %d selected / $%,.2f each",
                        stack.size(),
                        selectedCount,
                        app.exchangeTransactionService.swapUserValue(i)),
                    12,
                    Color.WHITE),
                BorderLayout.SOUTH);
            wrap.putClientProperty("ownedStack", stack);
            app.marketCardSelection.select(
                wrap, selectedCount > 0, app.exchangeWidgets.exchangeAccent(p));
            ug.add(wrap);
          }
          for (int n = sp[0] * 18; n < Math.min(siteStacks.size(), (sp[0] + 1) * 18); n++) {
            MarketplaceGroups.Group stack = siteStacks.get(n);
            MarketListing lot = stack.head();
            JPanel card =
                app.exchangeCatalogScreens.createExchangeListingCard(
                    p,
                    lot,
                    () -> {
                      new MarketplaceStackPicker(app)
                          .lots(p, root, stack, wanted::contains, chooseLot);
                    },
                    true);
            new MarketplaceBuyScreen(app)
                .setQuantity(
                    card,
                    lot.item.condition
                        + " / "
                        + stack.units()
                        + " available / "
                        + wanted.stream()
                            .filter(
                                w -> stack.lots.contains(w.stockParent != null ? w.stockParent : w))
                            .count()
                        + " selected");
            card.putClientProperty("marketGroup", stack);
            app.marketCardSelection.select(
                card,
                wanted.stream()
                    .anyMatch(w -> stack.lots.contains(w.stockParent != null ? w.stockParent : w)),
                app.exchangeWidgets.exchangeAccent(p));
            sg.add(card);
          }
          un.setText((up[0] + 1) + " / " + ups);
          sn.setText((sp[0] + 1) + " / " + sps);
          ub.setEnabled(up[0] > 0);
          uf.setEnabled(up[0] + 1 < ups);
          sb.setEnabled(sp[0] > 0);
          sf.setEnabled(sp[0] + 1 < sps);
          totals.run();
          ug.revalidate();
          ug.repaint();
          sg.revalidate();
          sg.repaint();
        };
    ub.addActionListener(
        e -> {
          up[0]--;
          render[0].run();
        });
    uf.addActionListener(
        e -> {
          up[0]++;
          render[0].run();
        });
    sb.addActionListener(
        e -> {
          sp[0]--;
          render[0].run();
        });
    sf.addActionListener(
        e -> {
          sp[0]++;
          render[0].run();
        });
    app.exchangeWidgets.exchangeDebounce(
        userSearch,
        () -> {
          up[0] = 0;
          render[0].run();
        });
    app.exchangeWidgets.exchangeDebounce(
        siteSearch,
        () -> {
          sp[0] = 0;
          render[0].run();
        });
    commit.addActionListener(
        e -> {
          totals.run();
          double shown = debit[0];
          if (JOptionPane.showConfirmDialog(
                  app,
                  String.format(
                      "Swap %d skins for %d skins?\n%s $%,.2f",
                      given.size(),
                      wanted.size(),
                      shown >= 0 ? "Cash required:" : "Cash returned:",
                      Math.abs(shown)),
                  "Confirm swap",
                  JOptionPane.YES_NO_OPTION)
              == JOptionPane.YES_OPTION)
            try {
              app.exchangeTransactionService.commitExchangeSwap(
                  p, new ArrayList<>(given), new ArrayList<>(wanted), shown);
              given.clear();
              wanted.clear();
              render[0].run();
            } catch (Exception ex) {
              JOptionPane.showMessageDialog(app, ex.getMessage());
              render[0].run();
            }
        });
    root.putClientProperty("refreshExchange", render[0]);
    app.marketSiteLayouts.swap(p, root, left, right, footer);
    render[0].run();
    return root;
  }
}
