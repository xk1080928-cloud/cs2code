package blahblah;

import blahblah.hGui.*;
import java.awt.*;
import java.awt.event.*;
import javax.swing.*;

/** Extracted reusable model or widget; behavior retained from the original source. */
final class FloatRange {
  final Double min;
  final Double max;

  FloatRange(Double min, Double max) {
    this.min = min;
    this.max = max;
  }
}
