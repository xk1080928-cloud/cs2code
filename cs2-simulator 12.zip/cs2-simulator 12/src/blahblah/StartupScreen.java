package blahblah;

import blahblah.hGui.*;
import java.awt.*;
import java.awt.event.*;
import javax.swing.*;

/** Startup Screen: focused feature implementation. */
final class StartupScreen {
  private final hGui app;

  StartupScreen(hGui app) {
    this.app = app;
  }

  void beginStartupLoading() {
    app.startupStartedAt = System.currentTimeMillis();
    app.startupProgressPercent = 0;
    app.startupProgressStatus = "Preparing the interface...";
    app.startupLoadingOverlay = app.startupScreen.createStartupLoadingOverlay();
    app.setGlassPane(app.startupLoadingOverlay);
    app.startupLoadingOverlay.setVisible(true);
    app.startupLoadingTimer =
        new javax.swing.Timer(1000, e -> app.startupScreen.refreshStartupLoadingDisplay());
    app.startupLoadingTimer.start();
  }

  JPanel createStartupLoadingOverlay() {
    JPanel overlay =
        new JPanel(new GridBagLayout()) {
          @Override
          protected void paintComponent(Graphics g) {
            Graphics2D g2 = (Graphics2D) g.create();
            g2.setPaint(
                new GradientPaint(0, 0, Theme.BG_DARK, 0, getHeight(), new Color(16, 20, 30)));
            g2.fillRect(0, 0, getWidth(), getHeight());
            g2.dispose();
            super.paintComponent(g);
            app.startupScreen.queueStartupAfterFirstPaint();
          }
        };
    overlay.setOpaque(false);

    JPanel card =
        new JPanel(new GridBagLayout()) {
          @Override
          public Dimension getPreferredSize() {
            Dimension natural = super.getPreferredSize();
            return new Dimension(560, Math.max(430, natural.height));
          }

          @Override
          protected void paintComponent(Graphics graphics) {
            Graphics2D g2 = (Graphics2D) graphics.create();
            g2.setColor(Theme.BG_PANEL);
            g2.fillRect(0, 0, getWidth(), getHeight());
            g2.setColor(Theme.ACCENT_CT);
            g2.fillRect(0, 0, 3, getHeight());
            g2.dispose();
            super.paintComponent(graphics);
          }
        };
    card.setOpaque(false);
    card.setBorder(
        BorderFactory.createCompoundBorder(
            BorderFactory.createLineBorder(Theme.BORDER, 1),
            BorderFactory.createEmptyBorder(24, 30, 24, 30)));
    card.setMinimumSize(new Dimension(400, 360));

    GridBagConstraints constraints = new GridBagConstraints();
    constraints.gridx = 0;
    constraints.fill = GridBagConstraints.HORIZONTAL;
    constraints.weightx = 1.0;
    constraints.insets = new Insets(8, 4, 8, 4);

    JLabel title = new JLabel("CS:GO  //  CASE SIMULATOR", SwingConstants.CENTER);
    title.setForeground(new Color(105, 220, 255));
    title.setFont(new Font("Consolas", Font.BOLD, 20));
    constraints.gridy = 0;
    card.add(title, constraints);

    JLabel subtitle =
        new JLabel("Preparing cases, inventory, and market data", SwingConstants.CENTER);
    subtitle.setForeground(new Color(139, 178, 205));
    subtitle.setFont(new Font("Consolas", Font.PLAIN, 12));
    constraints.gridy = 1;
    card.add(subtitle, constraints);

    app.startupLoadingStatusLabel =
        app.startupScreen.createStartupTextArea(
            app.startupProgressStatus, 3, Theme.CONSOLE_BOLD_14, Theme.TEXT);
    app.startupLoadingStatusLabel.setName("startupStatusText");
    constraints.gridy = 2;
    constraints.insets = new Insets(16, 4, 6, 4);
    card.add(app.startupLoadingStatusLabel, constraints);

    app.startupLoadingProgressBar =
        new JProgressBar(0, 100) {
          @Override
          protected void paintComponent(Graphics graphics) {
            Graphics2D g = (Graphics2D) graphics.create();
            g.setColor(new Color(8, 10, 18));
            g.fillRoundRect(0, 0, getWidth(), getHeight(), 8, 8);
            int fill = (int) Math.round(getWidth() * getPercentComplete());
            g.setColor(new Color(190, 96, 0));
            g.fillRoundRect(0, 0, fill, getHeight(), 8, 8);
            g.setRenderingHint(
                RenderingHints.KEY_TEXT_ANTIALIASING, RenderingHints.VALUE_TEXT_ANTIALIAS_ON);
            g.setFont(new Font("Dialog", Font.BOLD, 16));
            String text = getValue() + "%";
            FontMetrics fm = g.getFontMetrics();
            int x = (getWidth() - fm.stringWidth(text)) / 2,
                y = (getHeight() - fm.getHeight()) / 2 + fm.getAscent();
            g.setColor(Color.BLACK);
            g.drawString(text, x + 1, y + 1);
            g.setColor(Color.WHITE);
            g.drawString(text, x, y);
            g.dispose();
          }
        };
    app.startupLoadingProgressBar.setValue(app.startupProgressPercent);
    app.startupLoadingProgressBar.setStringPainted(true);
    app.startupLoadingProgressBar.setForeground(Theme.ACCENT_T);
    app.startupLoadingProgressBar.setBackground(Theme.BG_DARK);
    app.startupLoadingProgressBar.setBorderPainted(false);
    app.startupLoadingProgressBar.setString(app.startupProgressPercent + "%");
    app.startupLoadingProgressBar.setPreferredSize(new Dimension(420, 38));
    app.startupLoadingProgressBar.setMinimumSize(new Dimension(200, 38));
    constraints.gridy = 3;
    constraints.insets = new Insets(8, 4, 8, 4);
    card.add(app.startupLoadingProgressBar, constraints);

    app.startupLoadingPriceDetailsLabel =
        new JLabel("Skin prices loaded: 0 / 0", SwingConstants.CENTER);
    app.startupLoadingPriceDetailsLabel.setName("startupPriceCounter");
    app.startupLoadingPriceDetailsLabel.setForeground(Theme.ACCENT_CT);
    app.startupLoadingPriceDetailsLabel.setFont(Theme.CONSOLE_PLAIN_12);
    constraints.gridy = 4;
    card.add(app.startupLoadingPriceDetailsLabel, constraints);
    app.startupLoadingArtworkDetailsLabel = new JLabel(" ", SwingConstants.CENTER);
    app.startupLoadingArtworkDetailsLabel.setForeground(Theme.TEXT_DIM);
    app.startupLoadingArtworkDetailsLabel.setFont(Theme.CONSOLE_PLAIN_12);
    constraints.gridy = 5;
    card.add(app.startupLoadingArtworkDetailsLabel, constraints);
    app.startupArtworkReportButton = new JButton("Image loading details");
    app.startupArtworkReportButton.setName("startupArtworkReport");
    app.uiWidgets.styleButton(
        app.startupArtworkReportButton, Theme.BG_DARK, Theme.ACCENT_CT, Theme.BORDER);
    app.startupArtworkReportButton.addActionListener(
        e -> app.openingArtworkService.showArtworkLoadReport());
    constraints.gridy = 6;
    card.add(app.startupArtworkReportButton, constraints);
    app.startupLoadingTimeLabel =
        app.startupScreen.createStartupTextArea(
            "Elapsed: 0 sec. Estimated time remaining: calculating...",
            2,
            Theme.CONSOLE_PLAIN_12,
            Theme.ACCENT_CT);
    constraints.gridy = 7;
    card.add(app.startupLoadingTimeLabel, constraints);
    JLabel footer = new JLabel("", SwingConstants.CENTER);
    footer.setForeground(new Color(91, 123, 150));
    footer.setFont(new Font("Consolas", Font.PLAIN, 10));
    constraints.gridy = 8;
    constraints.insets = new Insets(10, 4, 2, 4);
    card.add(footer, constraints);

    overlay.add(card);
    return overlay;
  }

  JTextArea createStartupTextArea(String text, int rows, Font font, Color color) {
    JTextArea area = new JTextArea(text, rows, 38);
    area.setLineWrap(true);
    area.setWrapStyleWord(true);
    area.setEditable(false);
    area.setFocusable(false);
    area.setOpaque(false);
    area.setFont(font);
    area.setForeground(color);
    area.setBorder(BorderFactory.createEmptyBorder(2, 2, 2, 2));
    area.setMinimumSize(new Dimension(0, rows * (font.getSize() + 5)));
    return area;
  }

  void setStartupWrappedText(JTextArea area, String text, int minimumRows) {
    area.setText(text);
    int width = area.getWidth() > 20 ? area.getWidth() - 8 : 470;
    FontMetrics metrics = area.getFontMetrics(area.getFont());
    int lines = 1, used = 0, space = metrics.charWidth(' ');
    for (String word : text.split("\\s+")) {
      int size = metrics.stringWidth(word);
      if (used != 0 && used + space + size > width) {
        lines++;
        used = 0;
      }
      if (size > width) {
        lines += (size - 1) / width;
        used = size % width;
      } else used += (used == 0 ? 0 : space) + size;
    }
    int rows = Math.max(minimumRows, lines);
    area.setRows(rows);
    area.setMinimumSize(new Dimension(0, rows * metrics.getHeight() + 4));
    area.revalidate();
  }

  void queueStartupAfterFirstPaint() {
    if (app.startupStartQueued) return;
    app.startupStartQueued = true;
    // invokeLater runs after the current complete paint pass, including the 0% bar.
    SwingUtilities.invokeLater(
        () -> {
          if (app.startupWorkStarted || !app.isDisplayable()) return;
          app.startupWorkStarted = true;
          app.marketInitialization.startMarketFluctuationTimer();
        });
  }

  void setStartupProgress(int progress, String status) {
    synchronized (app) {
      int boundedProgress = Math.max(0, Math.min(99, progress));
      if (boundedProgress >= app.startupProgressPercent) {
        app.startupProgressPercent = boundedProgress;
        app.startupProgressStatus = status;
      }
      if (app.startupDisplayRefreshQueued) return;
      app.startupDisplayRefreshQueued = true;
    }
    SwingUtilities.invokeLater(
        () -> {
          synchronized (app) {
            app.startupDisplayRefreshQueued = false;
          }
          app.startupScreen.refreshStartupLoadingDisplay();
        });
  }

  void recordStartupCatalogLoaded() {
    int completed = app.startupCatalogsCompleted.incrementAndGet();
    app.startupCatalogsLoaded.countDown();
    app.startupScreen.setStartupProgress(
        1 + (int) Math.round(4.0 * completed / 3),
        "Loading skin and container catalogs (" + completed + " of 3)...");
  }

  void refreshStartupLoadingDisplay() {
    if (app.startupLoadingOverlay == null || !app.startupLoadingOverlay.isVisible()) return;
    int progress = app.startupProgressPercent;
    app.startupScreen.setStartupWrappedText(
        app.startupLoadingStatusLabel, app.startupProgressStatus, 3);
    app.startupLoadingStatusLabel.setToolTipText(app.startupProgressStatus);
    if (app.startupPriceStageActive) app.startupPriceService.refreshStartupPriceCounters();
    if (app.startupLoadingPriceDetailsLabel != null) {
      String detail =
          "Skin prices loaded: "
              + app.startupPricesLoaded
              + " / "
              + app.startupPriceTotal
              + "   Fallback: "
              + app.startupPriceFallbacks;
      String transfer =
          app.startupPriceStageActive
              ? (app.startupPriceFeedStatus == null
                  ? "Waiting for CSFloat"
                  : app.startupPriceFeedStatus)
              : "";
      if (app.startupPriceStageActive && app.startupPriceFeedBytes > 0)
        transfer +=
            " · "
                + app.startupPriceFeedBytes / 1024
                + " KB"
                + (app.startupPriceFeedTotal > 0
                    ? " / " + app.startupPriceFeedTotal / 1024 + " KB"
                    : " received");
      app.startupLoadingPriceDetailsLabel.setText(
          "<html><center>"
              + app.marketItemCards.escapeHtml(detail)
              + (transfer.isEmpty() ? "" : "<br>" + app.marketItemCards.escapeHtml(transfer))
              + "</center></html>");
    }
    if (app.startupLoadingArtworkDetailsLabel != null && app.startupArtworkStage)
      app.startupLoadingArtworkDetailsLabel.setText(
          "<html><center>Skin PNGs loaded: "
              + app.startupArtworkLoaded
              + " / "
              + app.startupArtworkTotal
              + "<br>Fallback: "
              + app.startupArtworkFallbacks
              + "   Unavailable: "
              + app.startupArtworkFailed
              + "<br>Checked: "
              + (app.startupArtworkLoaded + app.startupArtworkFailed)
              + " / "
              + app.startupArtworkTotal
              + "</center></html>");
    if (app.startupArtworkReportButton != null)
      app.startupArtworkReportButton.setText(
          "Image details ("
              + app.startupArtworkFallbacks
              + " fallback / "
              + app.startupArtworkFailed
              + " unavailable)");
    app.startupLoadingProgressBar.setValue(progress);
    app.startupLoadingProgressBar.setString(progress + "%");

    long elapsedSeconds = Math.max(0L, (System.currentTimeMillis() - app.startupStartedAt) / 1000L);
    long estimatedRemainingSeconds;
    if (elapsedSeconds < 2L || progress <= 5) {
      app.startupScreen.setStartupWrappedText(
          app.startupLoadingTimeLabel,
          "Elapsed: "
              + app.startupScreen.formatStartupDuration(elapsedSeconds)
              + ". Estimated time remaining: measuring startup throughput...",
          2);
      return;
    } else {
      estimatedRemainingSeconds =
          Math.round(elapsedSeconds * (100.0 - progress) / Math.max(1, progress));
      estimatedRemainingSeconds = Math.max(1L, estimatedRemainingSeconds);
    }
    app.startupScreen.setStartupWrappedText(
        app.startupLoadingTimeLabel,
        "Elapsed: "
            + app.startupScreen.formatStartupDuration(elapsedSeconds)
            + ". Estimated time remaining: about "
            + app.startupScreen.formatStartupDuration(estimatedRemainingSeconds),
        2);
  }

  String formatStartupDuration(long seconds) {
    if (seconds < 60) return seconds + " sec";
    long minutes = seconds / 60;
    long remainingSeconds = seconds % 60;
    return remainingSeconds == 0 ? minutes + " min" : minutes + " min " + remainingSeconds + " sec";
  }

  void finishStartupLoading() {
    app.startupProgressPercent = 100;
    app.startupProgressStatus = "Ready!";
    app.startupScreen.refreshStartupLoadingDisplay();
    if (app.startupLoadingTimer != null) app.startupLoadingTimer.stop();
    if (app.startupLoadingOverlay != null) app.startupLoadingOverlay.setVisible(false);
  }
}
