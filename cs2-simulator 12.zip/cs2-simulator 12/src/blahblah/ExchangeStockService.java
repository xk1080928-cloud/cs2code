package blahblah;

import blahblah.hGui.*;
import java.awt.*;
import java.awt.event.*;
import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.concurrent.ConcurrentHashMap;
import javax.swing.*;

/** Exchange Stock Service: focused feature implementation. */
final class ExchangeStockService {
  private final hGui app;

  ExchangeStockService(hGui app) {
    this.app = app;
  }

  CaseType exchangeContainer(String name) {
    if (name == null || app.exchangeContainers == null) return null;
    return app.exchangeContainers.get(name);
  }

  int stockUnits(MarketListing lot) {
    return lot == null ? 0 : Math.max(0, lot.quantity);
  }

  int countStock(java.util.Collection<MarketListing> lots) {
    long n = 0;
    for (MarketListing lot : lots) n += app.exchangeStockService.stockUnits(lot);
    return (int) Math.min(Integer.MAX_VALUE, n);
  }

  long mixExchange(long x) {
    x = (x ^ (x >>> 30)) * 0xBF58476D1CE4E5B9L;
    x = (x ^ (x >>> 27)) * 0x94D049BB133111EBL;
    return x ^ (x >>> 31);
  }

  String[] prepareExchangeStockPlan(String[] initial) {
    Set<String> names = new java.util.TreeSet<>(String.CASE_INSENSITIVE_ORDER);
    names.addAll(java.util.Arrays.asList(initial));
    names.addAll(app.requestedMarketSkinCollections.keySet());
    names.addAll(app.agentCatalog.keySet());
    for (ArmouryCollection col : hGui.ARMOURY_COLLECTIONS)
      for (String[] tier :
          new String[][] {
            col.consumerNames,
            col.industrialNames,
            col.milspecNames,
            col.restrictedNames,
            col.classifiedNames,
            col.covertNames
          }) if (tier != null) names.addAll(java.util.Arrays.asList(tier));
    app.exchangeStockPlan.clear();
    app.exchangeSeededBuckets.clear();
    app.exchangeGeneratedStock = app.marketStockService.getTotalMarketListingCount();
    app.exchangePlannedStock = app.exchangeGeneratedStock;
    long baseline = 0;
    for (String name : names) {
      baseline += app.marketStockService.fullMarketSupplyBudget(name, false);
      if (app.itemMetadataService.supportsStatTrak(name))
        baseline += app.marketStockService.fullMarketSupplyBudget(name, true);
    }
    double scale = 10_000_000.0 / Math.max(1, baseline);
    for (String name : names)
      for (int st = 0; st < (app.itemMetadataService.supportsStatTrak(name) ? 2 : 1); st++) {
        String key = st == 1 ? "StatTrak " + name : name;
        long hash = app.exchangeStockService.mixExchange(app.exchangeRunSeed ^ key.hashCode());
        double u = (hash >>> 11) * 0x1.0p-53;
        double variation = .82 + .36 * u;
        int quantity =
            Math.max(
                1,
                (int)
                    Math.round(
                        app.marketStockService.fullMarketSupplyBudget(name, st == 1)
                            * scale
                            * variation));
        app.exchangeStockPlan.put(key, quantity);
        app.exchangePlannedStock += quantity;
      }
    app.startupScreen.setStartupProgress(
        40,
        String.format(
            "Generating listings: %,d / %,d",
            app.exchangeGeneratedStock, app.exchangePlannedStock));
    return names.toArray(new String[0]);
  }

  void seedExchangeBucket(String key, ArrayList<MarketListing> lots) {
    if (app.exchangeSeededBuckets.contains(key)) return;
    Integer target = app.exchangeStockPlan.get(key);
    if (target == null) return;
    List<MarketListing> npc = new ArrayList<>();
    for (MarketListing lot : lots) if (!lot.isPlayerListing) npc.add(lot);
    if (npc.isEmpty()) return;
    int before = 0;
    for (MarketListing lot : npc) before += lot.quantity;
    int base = target / npc.size(), extra = target % npc.size();
    for (int i = 0; i < npc.size(); i++)
      npc.get(i).quantity = Math.max(1, base + (i < extra ? 1 : 0));
    app.exchangeGeneratedStock += app.exchangeStockService.countStock(npc);
    app.exchangeSeededBuckets.add(key);
  }

  MarketplaceProfile weightedExchangeProfile(String key, int index) {
    long h =
        app.exchangeStockService.mixExchange(
            app.exchangeRunSeed ^ ((long) key.hashCode() << 32) ^ index);
    double sum = 0;
    for (double w : hGui.EXCHANGE_WEIGHTS) sum += w;
    double value = (h >>> 11) * 0x1.0p-53 * sum;
    for (int n = 0; n < hGui.EXCHANGE_WEIGHTS.length; n++) {
      value -= hGui.EXCHANGE_WEIGHTS[n];
      if (value <= 0) return MarketplaceProfile.CATALOG[n];
    }
    return MarketplaceProfile.CATALOG[0];
  }

  void seedExchangeContainers() {
    for (CaseType ct : CaseType.values()) {
      String name = ct.catalogCrateName();
      app.exchangeContainers.put(name, ct);
      app.exchangeContainers.put(ct.name, ct);
      app.availableConditionsCache.remove(name);
      ContainerMarketService.publish(
          ct, app.startupArtworkService.hasPurchasableCaseQuote(ct) ? ct.price : null);
      ArrayList<MarketListing> bucket =
          app.globalMarketListings.computeIfAbsent(name, k -> new ArrayList<>());
      if (bucket.stream().anyMatch(l -> !l.isPlayerListing && l.quantity > 0)) continue;
      for (int m = 0; m < MarketplaceProfile.CATALOG.length; m++) {
        MarketplaceProfile p = MarketplaceProfile.CATALOG[m];
        InventoryItem item =
            new InventoryItem(
                null,
                name,
                "Normal",
                "Container",
                app.coreUtilities.money(ct.price),
                0,
                false,
                0,
                null,
                ct.price,
                true);
        MarketListing lot = new MarketListing(item, ct.price, 120, false);
        app.marketStockService.assignMarketplaceProfile(lot, p);
        lot.setPrice(ct.price);
        lot.item.price = app.coreUtilities.money(ct.price);
        lot.quantity =
            Math.max(
                1,
                (int)
                    Math.round(
                        hGui.EXCHANGE_WEIGHTS[m]
                            * (ct.isSouvenir ? 9 : 110)
                            * (0.85 + hGui.random.nextDouble() * .3)));
        bucket.add(lot);
      }
    }
  }

  void rebuildExchangeIndex() {
    Map<String, List<MarketListing>> next = new LinkedHashMap<>();
    for (MarketplaceProfile p : MarketplaceProfile.CATALOG) next.put(p.name, new ArrayList<>());
    for (ArrayList<MarketListing> bucket : app.globalMarketListings.values())
      synchronized (bucket) {
        for (MarketListing lot : bucket)
          if (lot != null && lot.quantity > 0)
            next.computeIfAbsent(lot.marketplaceName, k -> new ArrayList<>()).add(lot);
      }
    app.exchangeSiteStock = new ConcurrentHashMap<>(next);
  }

  static boolean supportsExchangeSwap(String name) {
    return java.util.Arrays.asList(
            "SkinSwap", "Skin.Land", "NeonGrid", "RelayMarket", "VelvetTrade")
        .contains(name);
  }
}
