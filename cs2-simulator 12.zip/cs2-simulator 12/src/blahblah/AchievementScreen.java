package blahblah;

import blahblah.hGui.*;
import java.awt.*;
import java.awt.event.*;
import javax.swing.*;

/** Achievement Screen: focused feature implementation. */
final class AchievementScreen {
  private final hGui app;

  AchievementScreen(hGui app) {
    this.app = app;
  }

  void unlockAchievement(String achievementId) {
    Achievement achievement = app.achievements.get(achievementId);
    if (achievement != null && !achievement.isUnlocked) {
      achievement.isUnlocked = true;
      app.unlockedAchievements.add(achievementId);
      app.balance += achievement.reward;
      app.uiWidgets.updateBalanceLabel();

      app.achievementScreen.showAchievementNotification(achievement);
    }
  }

  void showAchievementNotification(Achievement achievement) {

    JPanel notif = new JPanel(new BorderLayout(6, 0));
    notif.setBackground(new Color(28, 28, 38));
    notif.setBorder(
        BorderFactory.createCompoundBorder(
            BorderFactory.createLineBorder(new Color(255, 210, 30), 2),
            BorderFactory.createEmptyBorder(8, 10, 8, 10)));
    notif.setCursor(new Cursor(Cursor.HAND_CURSOR));
    notif.setToolTipText("Click to dismiss");

    JLabel icon = new JLabel("WIN", SwingConstants.CENTER);
    icon.setFont(new Font("Consolas", Font.BOLD, 18));
    notif.add(icon, BorderLayout.WEST);

    JPanel textPanel = new JPanel(new GridLayout(3, 1, 0, 1));
    textPanel.setBackground(new Color(28, 28, 38));

    JLabel titleLbl = new JLabel("ACHIEVEMENT UNLOCKED");
    titleLbl.setFont(new Font("Consolas", Font.BOLD, 10));
    titleLbl.setForeground(new Color(255, 210, 30));

    JLabel nameLbl = new JLabel(achievement.name);
    nameLbl.setFont(new Font("Consolas", Font.BOLD, 12));
    nameLbl.setForeground(Color.WHITE);

    JLabel rewardLbl =
        new JLabel(
            "+" + String.format("$%.0f", achievement.reward) + "  -  " + achievement.description);
    rewardLbl.setFont(new Font("Consolas", Font.PLAIN, 10));
    rewardLbl.setForeground(new Color(100, 220, 100));

    textPanel.add(titleLbl);
    textPanel.add(nameLbl);
    textPanel.add(rewardLbl);
    notif.add(textPanel, BorderLayout.CENTER);

    int w = 320, h = 72;
    JLayeredPane layered = app.getLayeredPane();
    int x = 12;
    int y = layered.getHeight() - h - 12;
    notif.setBounds(x, y, w, h);
    layered.add(notif, JLayeredPane.POPUP_LAYER);
    layered.revalidate();
    layered.repaint();

    MouseAdapter dismiss =
        new MouseAdapter() {
          @Override
          public void mouseClicked(MouseEvent e) {
            layered.remove(notif);
            layered.repaint();
          }
        };
    notif.addMouseListener(dismiss);
    for (Component c : notif.getComponents()) c.addMouseListener(dismiss);
    for (Component c : textPanel.getComponents()) c.addMouseListener(dismiss);

    javax.swing.Timer timer =
        new javax.swing.Timer(
            4000,
            e -> {
              layered.remove(notif);
              layered.repaint();
            });
    timer.setRepeats(false);
    timer.start();
  }

  void showAchievementsWindow() {
    JFrame achievementsFrame = new JFrame("Achievements");
    achievementsFrame.setSize(1000, 800);
    achievementsFrame.setLocationRelativeTo(app);
    achievementsFrame.setLayout(new BorderLayout());

    achievementsFrame.setAlwaysOnTop(true);

    JPanel headerPanel = new JPanel(new GridLayout(2, 1));
    headerPanel.setBackground(new Color(30, 30, 35));
    headerPanel.setBorder(BorderFactory.createEmptyBorder(10, 10, 10, 10));

    JLabel titleLabel = new JLabel("Achievements", SwingConstants.CENTER);
    titleLabel.setFont(new Font("Arial", Font.BOLD, 24));
    titleLabel.setForeground(Color.WHITE);

    int unlockedCount = app.unlockedAchievements.size();
    int totalCount = app.achievements.size();
    double completionPercent = (unlockedCount * 100.0) / totalCount;

    JLabel statsLabel =
        new JLabel(
            String.format(
                "Unlocked: %d / %d (%.1f%%)", unlockedCount, totalCount, completionPercent),
            SwingConstants.CENTER);
    statsLabel.setFont(new Font("Arial", Font.BOLD, 18));
    statsLabel.setForeground(Color.CYAN);

    headerPanel.add(titleLabel);
    headerPanel.add(statsLabel);
    achievementsFrame.add(headerPanel, BorderLayout.NORTH);

    JTabbedPane tabbedPane = new JTabbedPane();

    tabbedPane.addTab("All", app.achievementScreen.createAchievementCategoryPanel("All"));
    tabbedPane.addTab("Unboxing", app.achievementScreen.createAchievementCategoryPanel("Unboxing"));
    tabbedPane.addTab("Value", app.achievementScreen.createAchievementCategoryPanel("Value"));
    tabbedPane.addTab("Market", app.achievementScreen.createAchievementCategoryPanel("Market"));
    tabbedPane.addTab("Trading", app.achievementScreen.createAchievementCategoryPanel("Trading"));
    tabbedPane.addTab("Special", app.achievementScreen.createAchievementCategoryPanel("Special"));
    tabbedPane.addTab(
        "Collection", app.achievementScreen.createAchievementCategoryPanel("Collection"));
    tabbedPane.addTab("Float", app.achievementScreen.createAchievementCategoryPanel("Float"));
    tabbedPane.addTab("Streak", app.achievementScreen.createAchievementCategoryPanel("Streak"));

    achievementsFrame.add(tabbedPane, BorderLayout.CENTER);
    achievementsFrame.setVisible(true);

    javax.swing.Timer timer =
        new javax.swing.Timer(
            100,
            e -> {
              achievementsFrame.setAlwaysOnTop(false);
              achievementsFrame.toFront();
              achievementsFrame.requestFocus();
            });
    timer.setRepeats(false);
    timer.start();
  }

  JPanel createAchievementCategoryPanel(String category) {
    JPanel panel = new JPanel(new BorderLayout());
    panel.setBackground(new Color(35, 35, 40));

    JPanel grid = new JPanel(new GridLayout(0, 2, 10, 10));
    grid.setBackground(new Color(35, 35, 40));
    grid.setBorder(BorderFactory.createEmptyBorder(10, 10, 10, 10));

    for (Achievement achievement : app.achievements.values()) {
      if (category.equals("All") || achievement.category.equals(category)) {
        JPanel achievementCard = app.achievementScreen.createAchievementCard(achievement);
        grid.add(achievementCard);
      }
    }

    JScrollPane scroll = new JScrollPane(grid);
    scroll.getVerticalScrollBar().setUnitIncrement(16);
    scroll.setBorder(null);
    scroll.getViewport().setBackground(new Color(35, 35, 40));
    panel.add(scroll, BorderLayout.CENTER);

    return panel;
  }

  JPanel createAchievementCard(Achievement achievement) {
    JPanel card = new JPanel(new BorderLayout());
    card.setBackground(new Color(50, 50, 55));
    card.setPreferredSize(new Dimension(450, 150));

    Color borderColor = achievement.isUnlocked ? Color.YELLOW : Color.GRAY;
    card.setBorder(
        BorderFactory.createCompoundBorder(
            BorderFactory.createLineBorder(borderColor, 3),
            BorderFactory.createEmptyBorder(10, 10, 10, 10)));

    JPanel leftPanel = new JPanel(new BorderLayout());
    leftPanel.setBackground(new Color(50, 50, 55));
    leftPanel.setPreferredSize(new Dimension(80, 130));

    JLabel iconLabel;
    if (achievement.isUnlocked) {
      iconLabel = new JLabel("", SwingConstants.CENTER);
      iconLabel.setFont(new Font("Arial", Font.BOLD, 60));
      iconLabel.setForeground(Color.YELLOW);
    } else {
      iconLabel = new JLabel("?", SwingConstants.CENTER);
      iconLabel.setFont(new Font("Arial", Font.BOLD, 60));
      iconLabel.setForeground(Color.GRAY);
    }
    leftPanel.add(iconLabel, BorderLayout.CENTER);
    card.add(leftPanel, BorderLayout.WEST);

    JPanel infoPanel = new JPanel(new GridLayout(5, 1));
    infoPanel.setBackground(new Color(50, 50, 55));
    infoPanel.setBorder(BorderFactory.createEmptyBorder(5, 10, 5, 10));

    JLabel nameLabel = new JLabel(achievement.isUnlocked ? achievement.name : "???");
    nameLabel.setFont(new Font("Arial", Font.BOLD, 16));
    nameLabel.setForeground(achievement.isUnlocked ? Color.WHITE : Color.GRAY);

    JLabel descLabel = new JLabel(achievement.isUnlocked ? achievement.description : "Locked");
    descLabel.setFont(new Font("Arial", Font.PLAIN, 12));
    descLabel.setForeground(achievement.isUnlocked ? Color.LIGHT_GRAY : Color.DARK_GRAY);

    JLabel categoryLabel = new JLabel("Category: " + achievement.category);
    categoryLabel.setFont(new Font("Arial", Font.ITALIC, 11));
    categoryLabel.setForeground(Color.CYAN);

    JLabel progressLabel;
    if (achievement.requirement > 1) {
      progressLabel =
          new JLabel(
              String.format("Progress: %d / %d", achievement.progress, achievement.requirement));
      progressLabel.setFont(new Font("Arial", Font.PLAIN, 11));
      progressLabel.setForeground(achievement.isUnlocked ? Color.GREEN : Color.ORANGE);
    } else {
      progressLabel = new JLabel("");
    }

    JLabel rewardLabel =
        new JLabel(
            achievement.isUnlocked
                ? "Reward: $" + String.format("%.2f", achievement.reward)
                : "Reward: ???");
    rewardLabel.setFont(new Font("Arial", Font.BOLD, 14));
    rewardLabel.setForeground(achievement.isUnlocked ? Color.GREEN : Color.GRAY);

    infoPanel.add(nameLabel);
    infoPanel.add(descLabel);
    infoPanel.add(categoryLabel);
    infoPanel.add(progressLabel);
    infoPanel.add(rewardLabel);

    card.add(infoPanel, BorderLayout.CENTER);

    return card;
  }
}
