package blahblah;

import blahblah.hGui.*;
import java.awt.*;
import java.awt.event.*;
import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.nio.charset.StandardCharsets;
import java.text.Normalizer;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.prefs.Preferences;
import java.util.regex.Matcher;
import java.util.regex.Pattern;
import java.util.zip.GZIPInputStream;
import javax.swing.*;

/** Public Price Feeds: focused feature implementation. */
final class PublicPriceFeeds {
  private final hGui app;

  PublicPriceFeeds(hGui app) {
    this.app = app;
  }

  String getDopplerVariant(String skinName) {
    if (skinName == null || !skinName.contains("Doppler")) return null;
    Matcher matcher =
        Pattern.compile("\\((Phase [1-4]|Sapphire|Ruby|Black Pearl|Emerald)\\)\\s*$")
            .matcher(skinName);
    return matcher.find() ? matcher.group(1) : null;
  }

  Object publicPriceProviderLock(String provider) {
    return app.publicPriceSnapshotLocks.computeIfAbsent(provider, ignored -> new Object());
  }

  Map<String, Integer> getCoherentCsfloatIndex(String response) {
    synchronized (app.publicPriceFeeds.publicPriceProviderLock("csfloat")) {
      Map<String, Integer> index = app.publicPriceSnapshotIndexes.get("csfloat");
      if (index == null || app.publicPriceIndexSources.get("csfloat") != response) {
        index = app.publicPriceFeeds.buildPublicPriceSnapshotIndex(response);
        app.publicPriceSnapshotIndexes.put("csfloat", index);
        app.publicPriceIndexSources.put("csfloat", response);
      }
      return index;
    }
  }

  String getPublicPriceSnapshot(String provider) throws IOException {
    // Never synchronize network I/O on the JFrame: progress/UI callbacks use its monitor.
    synchronized (app.publicPriceFeeds.publicPriceProviderLock(provider)) {
      String cached = app.publicPriceSnapshots.get(provider);
      Long cachedAt = app.publicPriceSnapshotTimes.get(provider);
      if (cached != null
          && cachedAt != null
          && System.currentTimeMillis() - cachedAt < hGui.PUBLIC_PRICE_SNAPSHOT_TTL_MS)
        return cached;
      Long retry = app.publicPriceFeedRetryAfter.get(provider);
      if (app.disabledPriceFeeds.contains(provider)
          || (retry != null && retry > System.currentTimeMillis())) {
        if (cached != null) return cached; // Retain a valid older snapshot during an outage.
        throw new IOException(
            "The " + provider + " price feed is temporarily unavailable (retry cooldown)");
      }
      HttpURLConnection connection =
          (HttpURLConnection)
              java.net
                  .URI
                  .create("https://prices.csgotrader.app/latest/" + provider + ".json")
                  .toURL()
                  .openConnection();
      connection.setRequestMethod("GET");
      connection.setRequestProperty("Accept", "application/json");
      connection.setRequestProperty("Accept-Encoding", "gzip");
      connection.setRequestProperty("User-Agent", "CSGO-Skin-Simulator/1.0");
      connection.setConnectTimeout(10000);
      connection.setReadTimeout(30000);
      try {
        app.startupPriceFeedStatus = "Downloading CSFloat feed";
        app.startupPriceFeedBytes = 0;
        app.startupPriceFeedTotal = 0;
        int status = connection.getResponseCode();
        if (status < 200 || status >= 300) {
          if (status >= 400 && status < 500 && status != 429) app.disabledPriceFeeds.add(provider);
          throw new IOException("CSFloat feed returned HTTP " + status);
        }
        app.startupPriceFeedTotal = connection.getContentLengthLong();
        InputStream counted =
            new java.io.FilterInputStream(connection.getInputStream()) {
              @Override
              public int read() throws IOException {
                int b = in.read();
                if (b >= 0) app.startupPriceFeedBytes++;
                return b;
              }

              @Override
              public int read(byte[] bytes, int offset, int length) throws IOException {
                int n = in.read(bytes, offset, length);
                if (n > 0) app.startupPriceFeedBytes += n;
                return n;
              }
            };
        String snapshot = app.publicPriceFeeds.readPublicPriceFeedBody(counted);
        app.publicPriceSnapshots.put(provider, snapshot);
        app.publicPriceSnapshotTimes.put(provider, System.currentTimeMillis());
        app.publicPriceSnapshotIndexes.remove(provider);
        app.publicPriceIndexSources.remove(provider);
        app.publicPriceFeedRetryAfter.remove(provider);
        app.startupPriceFeedStatus = "CSFloat feed ready; resolving skin prices";
        return snapshot;
      } catch (IOException ex) {
        app.publicPriceFeedRetryAfter.put(provider, System.currentTimeMillis() + 60000L);
        System.err.println("CSFloat feed unavailable; retry cooldown enabled: " + ex.getMessage());
        app.startupPriceFeedStatus =
            cached == null
                ? "CSFloat unavailable; using fallback prices"
                : "CSFloat unavailable; using cached feed";
        if (cached != null) return cached;
        throw ex;
      } finally {
        connection.disconnect();
      }
    }
  }

  String readPublicPriceFeedBody(InputStream stream) throws IOException {
    // Some mirrors return gzip bytes without Content-Encoding; inspect bytes, not only the header.
    java.io.PushbackInputStream peek = new java.io.PushbackInputStream(stream, 2);
    int first = peek.read(), second = peek.read();
    if (second >= 0) peek.unread(second);
    if (first >= 0) peek.unread(first);
    InputStream decoded = first == 0x1f && second == 0x8b ? new GZIPInputStream(peek) : peek;
    StringBuilder body = new StringBuilder();
    try (BufferedReader reader =
        new BufferedReader(new InputStreamReader(decoded, StandardCharsets.UTF_8))) {
      char[] buffer = new char[16384];
      int n;
      while ((n = reader.read(buffer)) != -1) body.append(buffer, 0, n);
    }
    return body.toString();
  }

  Double findCsfloatSnapshotPrice(String response, String marketHashName, String dopplerVariant) {
    Map<String, Integer> snapshotIndex = app.publicPriceFeeds.getCoherentCsfloatIndex(response);
    String normalizedTarget = app.publicPriceFeeds.normalizeMarketHashName(marketHashName);
    Integer valueStart = snapshotIndex.get(normalizedTarget);
    Double price =
        valueStart == null
            ? null
            : app.publicPriceFeeds.parseMarketPriceValue(response, valueStart, dopplerVariant);
    if (price != null) return price;

    if (app.itemMetadataService.isAgentSkin(marketHashName.replaceFirst("^★\\s*", ""))) {
      for (Map.Entry<String, Integer> entry : snapshotIndex.entrySet()) {
        String normalizedCandidate = entry.getKey();
        if (!normalizedCandidate.startsWith(normalizedTarget)
            || normalizedCandidate.length() - normalizedTarget.length() > 32) continue;
        price =
            app.publicPriceFeeds.parseMarketPriceValue(response, entry.getValue(), dopplerVariant);
        if (price != null) return price;
      }
    }
    return null;
  }

  Map<String, Integer> buildPublicPriceSnapshotIndex(String response) {
    Map<String, Integer> index = new HashMap<>();
    Matcher keyMatcher = Pattern.compile("\"((?:\\\\.|[^\"\\\\])*)\"\\s*:\\s*").matcher(response);
    while (keyMatcher.find()) {
      String name = app.catalogParsingService.unescapeCatalogString(keyMatcher.group(1));
      index.putIfAbsent(app.publicPriceFeeds.normalizeMarketHashName(name), keyMatcher.end());
    }
    return index;
  }

  String normalizeMarketHashName(String name) {
    String normalized =
        Normalizer.normalize(name, Normalizer.Form.NFD)
            .replaceAll("\\p{M}+", "")
            .toLowerCase(java.util.Locale.ROOT);
    return normalized.replaceAll("[^a-z0-9]", "");
  }

  Double parseMarketPriceValue(String response, int valueStart, String dopplerVariant) {
    if (valueStart >= response.length()) return null;
    if (Character.isDigit(response.charAt(valueStart))) {
      if (dopplerVariant != null) return null;
      Matcher numericPrice =
          hGui.MARKET_NUMERIC_PRICE.matcher(response).region(valueStart, response.length());
      if (!numericPrice.lookingAt()) return null;
      double price = Double.parseDouble(numericPrice.group());
      return Double.isFinite(price) && price > 0.0 ? price : null;
    }
    if (response.charAt(valueStart) != '{') return null;
    int objectStart = valueStart;
    int objectEnd = app.publicPriceFeeds.findJsonObjectEnd(response, objectStart);
    if (objectEnd < 0) return null;
    String itemData = response.substring(objectStart, objectEnd + 1);
    if (dopplerVariant != null) {
      String dopplerData = app.publicPriceFeeds.findJsonObjectField(itemData, "doppler");
      if (dopplerData == null) {
        String startingAtData = app.publicPriceFeeds.findJsonObjectField(itemData, "starting_at");
        if (startingAtData != null) {
          dopplerData = app.publicPriceFeeds.findJsonObjectField(startingAtData, "doppler");
        }
      }
      if (dopplerData == null) return null;
      Matcher variantPrice =
          Pattern.compile("\"" + Pattern.quote(dopplerVariant) + "\"\\s*:\\s*(\\d+(?:\\.\\d+)?)")
              .matcher(dopplerData);
      if (!variantPrice.find()) return null;
      double price = Double.parseDouble(variantPrice.group(1));
      return Double.isFinite(price) && price > 0.0 ? price : null;
    }
    Double topPrice = app.publicPriceFeeds.topLevelPriceNumber(itemData, "price");
    if (topPrice != null) return topPrice;
    Double directStart = app.publicPriceFeeds.topLevelPriceNumber(itemData, "starting_at");
    if (directStart != null) return directStart;
    String startObject = app.publicPriceFeeds.findJsonObjectField(itemData, "starting_at");
    if (startObject != null) {
      Double v = app.publicPriceFeeds.topLevelPriceNumber(startObject, "price");
      if (v != null) return v;
    }
    Double suggested = app.publicPriceFeeds.topLevelPriceNumber(itemData, "suggested_price");
    if (suggested != null) return suggested;

    return null;
  }

  Double topLevelPriceNumber(String object, String field) {
    int depth = 0;
    boolean quoted = false, escaped = false;
    for (int i = 0; i < object.length(); i++) {
      char ch = object.charAt(i);
      if (quoted) {
        if (escaped) escaped = false;
        else if (ch == '\\') escaped = true;
        else if (ch == '"') quoted = false;
        continue;
      }
      if (ch == '{' || ch == '[') {
        depth++;
        continue;
      }
      if (ch == '}' || ch == ']') {
        depth--;
        continue;
      }
      if (ch == '"') {
        if (depth == 1 && object.startsWith("\"" + field + "\"", i)) {
          int v = i + field.length() + 2;
          while (v < object.length() && Character.isWhitespace(object.charAt(v))) v++;
          if (v < object.length() && object.charAt(v) == ':') {
            v++;
            while (v < object.length() && Character.isWhitespace(object.charAt(v))) v++;
            Matcher number = hGui.MARKET_NUMERIC_PRICE.matcher(object).region(v, object.length());
            if (number.lookingAt()) {
              double price = Double.parseDouble(number.group());
              if (Double.isFinite(price) && price > 0) return price;
            }
          }
        }
        quoted = true;
      }
    }
    return null;
  }

  String findJsonObjectField(String jsonObject, String fieldName) {
    Matcher fieldMatcher =
        Pattern.compile("\"" + Pattern.quote(fieldName) + "\"\\s*:\\s*").matcher(jsonObject);
    if (!fieldMatcher.find()) return null;
    int valueStart = fieldMatcher.end();
    if (valueStart >= jsonObject.length() || jsonObject.charAt(valueStart) != '{') return null;
    int valueEnd = app.publicPriceFeeds.findJsonObjectEnd(jsonObject, valueStart);
    return valueEnd < 0 ? null : jsonObject.substring(valueStart, valueEnd + 1);
  }

  int findJsonObjectEnd(String json, int start) {
    if (start < 0 || start >= json.length() || json.charAt(start) != '{') return -1;
    int depth = 0;
    boolean inString = false;
    boolean escaped = false;
    for (int i = start; i < json.length(); i++) {
      char ch = json.charAt(i);
      if (inString) {
        if (escaped) escaped = false;
        else if (ch == '\\') escaped = true;
        else if (ch == '"') inString = false;
      } else if (ch == '"') {
        inString = true;
      } else if (ch == '{') {
        depth++;
      } else if (ch == '}' && --depth == 0) {
        return i;
      }
    }
    return -1;
  }

  void updateBasePriceFromMarket(String skinName, MarketPriceData marketPrice) {
    double newBasePrice = marketPrice.basePrice;
    if (!Double.isFinite(newBasePrice) || newBasePrice <= 0.0) return;
    boolean agentPriceUpdated = app.itemMetadataService.isAgentSkin(skinName);
    if (agentPriceUpdated) {
      app.publicPriceFeeds.updateAgentBasePrice(skinName, newBasePrice);
      if (!app.itemPriceService.isStartupQuoteOnly()
          && app.mainTabs != null
          && app.mainTabs.getSelectedIndex() == 1) app.armouryScreen.refreshArmouryTab();
    }
    double oldBasePrice;
    Map<String, Double> previousConditionMultipliers =
        app.liveConditionPriceMultipliers.put(skinName, marketPrice.conditionMultipliers);
    app.liveBasePrices.put(skinName, newBasePrice);
    if (marketPrice.vanillaStatTrakPrice != null && marketPrice.vanillaStatTrakPrice > 0.0)
      app.liveVanillaStatTrakPrices.put(skinName, marketPrice.vanillaStatTrakPrice);
    if (app.itemPriceService.marketPricePreferenceKey("p", skinName).length()
        <= Preferences.MAX_KEY_LENGTH) {
      app.marketPricePreferences.putDouble(
          app.itemPriceService.marketPricePreferenceKey("p", skinName), newBasePrice);
      app.marketPricePreferences.putLong(
          app.itemPriceService.marketPricePreferenceKey("t", skinName), System.currentTimeMillis());
    }
    synchronized (app.basePriceCache) {
      Double cached = app.basePriceCache.put(skinName, newBasePrice);
      Double fallback = app.fallbackBasePrices.remove(skinName);
      oldBasePrice = cached != null && cached > 0.0 ? cached : (fallback == null ? 0.0 : fallback);
    }
    // Stock defaults may already exist. They must not turn startup quote resolution into
    // thousands of ROI calculations, Inventory refreshes and window repaints on the EDT.
    if (app.itemPriceService.isStartupQuoteOnly()) return;
    if (oldBasePrice <= 0.0) {
      app.artworkService.updateMarketplacePriceLabels(skinName);
      app.publicPriceFeeds.updateCaseRoiIfPriceChanged(skinName);
      return;
    }

    double ratio = newBasePrice / oldBasePrice;
    if (!Double.isFinite(ratio) || ratio <= 0.0) {
      app.artworkService.updateMarketplacePriceLabels(skinName);
      app.publicPriceFeeds.updateCaseRoiIfPriceChanged(skinName);
      return;
    }
    String normalizedName = app.leaderboardService.normalizeSkinName(skinName);
    String statTrakName = app.leaderboardService.normalizeSkinName("StatTrak " + normalizedName);
    if (!app.marketInitialized)
      synchronized (app.globalMarketListings) {
        for (String key :
            new java.util.LinkedHashSet<>(java.util.Arrays.asList(normalizedName, statTrakName))) {
          ArrayList<MarketListing> bucket = app.globalMarketListings.get(key);
          if (bucket == null) continue;
          for (MarketListing listing : bucket) {
            if (listing.isPlayerListing) continue; // Never rewrite a player's ask.
            if (app.exchangeStockService.exchangeContainer(listing.item.name) != null) continue;
            if (app.floatRules.isVanillaKnife(skinName)) {
              double value =
                  app.marketStockService.getVanillaVariantBasePrice(
                          skinName, listing.item.isStattrak, newBasePrice)
                      * app.marketInitialization.getMarketMultiplier(
                          "Knife", app.collectionService.getCollectionName(skinName))
                      * (0.96 + hGui.random.nextDouble() * 0.08);
              listing.setPrice(app.coreUtilities.money(value).doubleValue());
              listing.item.price = app.coreUtilities.money(value);
              listing.item.basePrice = newBasePrice;
              listing.item.itemFloat = 0.0;
              listing.item.condition = "Normal";
              continue;
            }
            double conditionRatio =
                app.priceModifiers.getConditionPriceMultiplier(
                        skinName, listing.item.condition, marketPrice.conditionMultipliers)
                    / app.priceModifiers.getConditionPriceMultiplier(
                        skinName, listing.item.condition, previousConditionMultipliers);
            double itemRatio = ratio * conditionRatio;
            listing.setPrice(listing.listPrice * itemRatio);
            listing.item.price =
                app.coreUtilities.money(listing.item.price.doubleValue() * itemRatio);
            listing.item.basePrice *= ratio;
          }
        }
        app.marketStockService.invalidateGroupedMarketListingsCache();
      }

    synchronized (app.inventoryList) {
      for (InventoryItem item : app.inventoryList) {
        if (app.cs2EquipmentScreens.isDefaultWeaponItem(item)) continue;
        if (normalizedName.equals(app.leaderboardService.normalizeSkinName(item.name))
            && item.blueGemTier == null) {
          if (app.floatRules.isVanillaKnife(skinName)) {
            item.price =
                app.coreUtilities.money(
                    app.marketStockService.getVanillaVariantBasePrice(
                            skinName, item.isStattrak, newBasePrice)
                        * app.marketInitialization.getMarketMultiplier(
                            "Knife", app.collectionService.getCollectionName(skinName)));
            item.basePrice = newBasePrice;
            continue;
          }
          double conditionRatio =
              app.priceModifiers.getConditionPriceMultiplier(
                      skinName, item.condition, marketPrice.conditionMultipliers)
                  / app.priceModifiers.getConditionPriceMultiplier(
                      skinName, item.condition, previousConditionMultipliers);
          item.price = app.coreUtilities.money(item.price.doubleValue() * ratio * conditionRatio);
          item.basePrice *= ratio;
        }
      }
      app.inventoryValue =
          app.inventoryList.stream()
              .filter(item -> !app.cs2EquipmentScreens.isDefaultWeaponItem(item))
              .mapToDouble(item -> item.price.doubleValue())
              .sum();
    }
    app.coreUtilities.refreshInventoryValueLabel();
    if (app.mainTabs != null && app.mainTabs.getSelectedIndex() == 2)
      app.inventoryScreen.refreshInventoryTab();
    app.artworkService.updateMarketplacePriceLabels(skinName);
    app.publicPriceFeeds.updateCaseRoiIfPriceChanged(skinName);
    app.bundledArtwork.refreshMainUI();
  }

  void updateAgentBasePrice(String skinName, double price) {
    String agentKey = app.itemMetadataService.normalizeAgentLookupKey(skinName);
    app.agentBasePriceCache.put(agentKey, price);
    if (hGui.ARMOURY_COLLECTIONS == null) return;
    for (ArmouryCollection collection : hGui.ARMOURY_COLLECTIONS) {
      if (!collection.isAgents) continue;
      app.publicPriceFeeds.updateAgentTierPrice(
          collection.milspecNames, collection.milspecPrices, agentKey, price);
      app.publicPriceFeeds.updateAgentTierPrice(
          collection.restrictedNames, collection.restrictedPrices, agentKey, price);
      app.publicPriceFeeds.updateAgentTierPrice(
          collection.classifiedNames, collection.classifiedPrices, agentKey, price);
      app.publicPriceFeeds.updateAgentTierPrice(
          collection.covertNames, collection.covertPrices, agentKey, price);
    }
  }

  void updateAgentTierPrice(String[] names, double[] prices, String agentKey, double price) {
    if (names == null || prices == null) return;
    for (int i = 0; i < names.length && i < prices.length; i++) {
      if (agentKey.equals(app.itemMetadataService.normalizeAgentLookupKey(names[i]))) {
        prices[i] = price;
      }
    }
  }

  void updateCaseRoiIfPriceChanged(String skinName) {
    if (app.caseRoiLabel == null || app.currentCase == null || skinName == null) return;
    String normalized =
        app.leaderboardService.normalizeSkinName(skinName.replace("StatTrak ", "").trim());
    boolean affectsCurrentCase =
        app.currentCase.rareDropNames.stream()
            .anyMatch(
                name ->
                    app.leaderboardService.normalizeSkinName(name).equalsIgnoreCase(normalized));
    if (!affectsCurrentCase) {
      affectsCurrentCase =
          app.currentCase.regularDropNames.values().stream()
              .flatMap(List::stream)
              .anyMatch(
                  name ->
                      app.leaderboardService.normalizeSkinName(name).equalsIgnoreCase(normalized));
    }
    if (affectsCurrentCase) app.collectionService.updateSelectedCaseRoi();
  }
}
