package blahblah;

import java.io.Serializable;
import java.util.*;
import java.util.concurrent.ThreadLocalRandom;
import javax.swing.SwingUtilities;

/**
 * Soft stock band on the existing five-second market worker; never an instant one-for-one refill.
 */
final class BufferedMarketSupply {
  static final double BAND = .10, QUIET = .0025;
  static final int MAX_LOTS = 128;
  private final hGui app;

  BufferedMarketSupply(hGui app) {
    this.app = app;
  }

  static final class State implements Serializable {
    private static final long serialVersionUID = 1L;
    long baseline, aim, nextReview, nextAim, relisted, issued;
    int cursor;
    int policyVersion;
  }

  State state() {
    if (app.inventoryToolsService.state.marketBuffer == null)
      app.inventoryToolsService.state.marketBuffer = new State();
    return app.inventoryToolsService.state.marketBuffer;
  }

  void initialize(long count) {
    if (state().baseline > 0) return;
    state().baseline = count >= 9_000_000 ? 10_000_000 : Math.max(1, count);
    state().aim = state().baseline;
    long now = System.currentTimeMillis();
    state().nextReview = now + 15_000;
    state().nextAim = now + 120_000;
  }

  long lower() {
    return Math.max(1, (long) (state().baseline * (1 - BAND)));
  }

  long upper() {
    return Math.max(1, (long) (state().baseline * (1 + BAND)));
  }

  private static final class Candidate {
    final String key;
    InventoryItem item;
    double price;
    long listed;
    int lots;

    Candidate(String key) {
      this.key = key;
    }
  }

  private static final class Book {
    final LinkedHashMap<String, Candidate> variants = new LinkedHashMap<>();
    long total;
  }

  private void onEdt(Runnable work) {
    if (SwingUtilities.isEventDispatchThread()) {
      work.run();
      return;
    }
    try {
      SwingUtilities.invokeAndWait(work);
    } catch (InterruptedException ex) {
      Thread.currentThread().interrupt();
      throw new IllegalStateException(ex);
    } catch (java.lang.reflect.InvocationTargetException ex) {
      throw new IllegalStateException(ex.getCause());
    }
  }

  private Book snapshot() {
    Book book = new Book();
    List<ArrayList<MarketListing>> buckets = new ArrayList<>();
    onEdt(() -> buckets.addAll(app.globalMarketListings.values()));
    Set<MarketListing> seen = Collections.newSetFromMap(new IdentityHashMap<>());
    for (ArrayList<MarketListing> bucket : buckets)
      if (bucket != null)
        synchronized (bucket) {
          for (MarketListing lot : bucket) {
            if (lot == null || lot.item == null || lot.quantity <= 0 || !seen.add(lot)) continue;
            String key = MarketplacePricing.variant(lot.item);
            Candidate c = book.variants.computeIfAbsent(key, Candidate::new);
            c.listed += lot.quantity;
            book.total += lot.quantity;
            if (!lot.isPlayerListing) {
              c.lots++;
              double price = app.marketplaceUnitStock.floorAsk(lot);
              if (Double.isFinite(price) && price > 0 && (c.item == null || price > c.price)) {
                c.item = lot.item;
                c.price = price;
              }
            }
          }
        }
    // Entirely bought-out variants remain eligible for relisting; no permanent empty catalog holes.
    for (Map.Entry<String, Long> entry : app.globalSupply.quantities().entrySet())
      if (entry.getValue() > 0
          && (!book.variants.containsKey(entry.getKey())
              || book.variants.get(entry.getKey()).item == null)) {
        String[] parts = entry.getKey().split("\u001f", -1);
        if (parts.length != 3) continue;
        double price = app.globalSupply.reference(entry.getKey());
        if (!Double.isFinite(price) || price <= 0) continue;
        String rarity =
            app.exchangeStockService.exchangeContainer(parts[0]) == null
                ? app.itemMetadataService.getSkinRarity(parts[0])
                : "Container";
        double f =
            app.floatRules.hasNoFloatWear(parts[0])
                ? 0
                : app.marketGeneration.generateFloatForCondition(parts[0], parts[1]);
        Candidate c = book.variants.computeIfAbsent(entry.getKey(), Candidate::new);
        c.price = price;
        c.item =
            new InventoryItem(
                null,
                parts[0],
                parts[1],
                rarity,
                app.coreUtilities.money(price),
                f,
                Boolean.parseBoolean(parts[2]),
                0,
                null,
                price,
                true);
        book.variants.put(c.key, c);
      }
    return book;
  }

  void tick() {
    tick(System.currentTimeMillis());
  }

  void tick(long now) {
    if (!app.globalSupply.ready()) return;
    final long version = app.worldVersion;
    Book book = snapshot();
    final long[] budget = {0};
    onEdt(
        () -> {
          if (version != app.worldVersion) return;
          if (state().baseline <= 0)
            initialize(app.exchangePlannedStock > 0 ? app.exchangePlannedStock : book.total);
          State s = state();
          if (s.policyVersion < 2) {
            if (s.baseline >= 9_000_000) {
              s.baseline = 10_000_000;
              s.aim = 10_000_000;
            }
            s.policyVersion = 2;
          }
          // Recover proactively well before the wider 9M lower band, not after losing a million.
          boolean emergency = book.total < s.baseline * .985;
          if (now < s.nextReview && !emergency) return;
          s.nextReview = now + ThreadLocalRandom.current().nextLong(10_000, 15_001);
          if (now >= s.nextAim) {
            s.aim = (long) (s.baseline * (.995 + ThreadLocalRandom.current().nextDouble() * .010));
            s.nextAim = now + ThreadLocalRandom.current().nextLong(120_000, 240_001);
          }
          long deficit = s.aim - book.total;
          if (book.total >= upper() || deficit <= Math.max(1, (long) (s.baseline * QUIET))) return;
          long maxBatch =
              Math.max(
                  1,
                  (long)
                      (s.baseline
                          * (emergency
                              ? (.015 + ThreadLocalRandom.current().nextDouble() * .005)
                              : (.008 + ThreadLocalRandom.current().nextDouble() * .004))));
          budget[0] = Math.min(deficit, maxBatch);
        });
    if (budget[0] <= 0) return;
    List<Candidate> choices = new ArrayList<>(book.variants.values());
    if (choices.isEmpty()) return;
    final long[] remaining = {budget[0]}, mint = {Math.max(1, (long) (state().baseline * .0001))};
    int offset = Math.floorMod(state().cursor, choices.size());
    // First exhaust reusable NPC reserves across the book. Only then allow tightly capped issuance.
    for (int pass = 0; pass < 5 && remaining[0] > 0; pass++) {
      final boolean issue = pass == 4;
      if (issue) {
        final long[] free = {0};
        onEdt(
            () ->
                free[0] =
                    Math.max(
                        0,
                        app.globalSupply.total()
                            - book.total
                            - (budget[0] - remaining[0])
                            - app.globalSupply.personalTotal()));
        if (free[0] > Math.max(1, state().baseline / 10_000)) break;
      }
      for (int first = 0; first < choices.size() && remaining[0] > 0; first += 8) {
        int start = first, end = Math.min(first + 8, choices.size());
        onEdt(
            () -> {
              if (version != app.worldVersion) {
                remaining[0] = 0;
                return;
              }
              for (int n = start; n < end && remaining[0] > 0; n++) {
                Candidate c = choices.get((offset + n) % choices.size());
                int added = place(c, remaining[0], issue, mint);
                remaining[0] -= added;
                state().cursor++;
              }
            });
      }
    }
    onEdt(
        () -> {
          if (version == app.worldVersion) {
            app.marketStockService.invalidateGroupedMarketListingsCache();
            app.exchangeStockService.rebuildExchangeIndex();
          }
        });
  }

  private boolean canIssue(InventoryItem i) {
    return !i.isStattrak
        && (i.rarity.equals("Consumer")
            || i.rarity.equals("Industrial")
            || i.rarity.equals("Milspec")
            || i.rarity.equals("Container"));
  }

  private int place(Candidate candidate, long budget, boolean issue, long[] mint) {
    InventoryItem src = candidate.item;
    if (src == null || !Double.isFinite(candidate.price) || candidate.price <= 0) return 0;
    CaseType container = app.exchangeStockService.exchangeContainer(src.name);
    if (container != null) {
      Double quote = ContainerMarketService.quote(src.name);
      if (quote != null && (!Double.isFinite(quote) || quote <= 0)) return 0;
    }
    String bucketKey = (src.isStattrak ? "StatTrak " : "") + src.name;
    ArrayList<MarketListing> bucket = app.globalMarketListings.get(bucketKey);
    long listed = 0;
    int lots = 0;
    if (bucket != null)
      synchronized (bucket) {
        for (MarketListing l : bucket)
          if (l.quantity > 0 && candidate.key.equals(MarketplacePricing.variant(l.item))) {
            listed += l.quantity;
            if (!l.isPlayerListing) lots++;
          }
      }
    if (lots >= MAX_LOTS) return 0;
    long reserve = app.globalSupply.unlisted(src, listed);
    long available = reserve;
    long minimumLot = Math.max(8, app.globalSupply.quantity(candidate.key) / 100);
    // Let reserves accumulate. Relisting 1–2 units as fresh parents would strand book depth.
    if (!issue && reserve < minimumLot) return 0;
    if (issue) {
      if (reserve > 0 || mint[0] <= 0 || !canIssue(src)) return 0;
      available =
          Math.min(mint[0], Math.max(1, (long) (app.globalSupply.quantity(candidate.key) * .001)));
    }
    int quantity = (int) Math.min(Math.min(budget, available), 512);
    if (quantity <= 0 || (!issue && quantity < minimumLot)) return 0;
    double target =
        MarketDynamics.cents(
            candidate.price * (.9985 + ThreadLocalRandom.current().nextDouble() * .0055));
    if (target <= 0) return 0;
    InventoryItem item =
        new InventoryItem(
            null,
            src.name,
            src.condition,
            src.rarity,
            app.coreUtilities.money(target),
            src.itemFloat,
            src.isStattrak,
            src.patternID,
            src.blueGemTier,
            src.basePrice,
            true);
    item.collection = src.collection;
    MarketListing lot = new MarketListing(item, target, 120, true);
    lot.isPlayerListing = false;
    lot.quantity = quantity;
    app.marketStockService.assignMarketplaceProfile(lot, MarketplaceProfile.randomForListing());
    double floor = app.marketplaceUnitStock.floorAsk(lot);
    if (!Double.isFinite(floor) || floor <= 0) return 0;
    lot.setPrice(target / (floor / target));
    lot.item.price = app.coreUtilities.money(lot.getPrice());
    if (issue) {
      app.globalSupply.created(item, quantity);
      mint[0] -= quantity;
      state().issued += quantity;
    } else state().relisted += quantity;
    if (bucket == null) {
      bucket = new ArrayList<>();
      app.globalMarketListings.put(bucketKey, bucket);
    }
    synchronized (bucket) {
      bucket.add(lot);
    }
    return quantity;
  }
}
