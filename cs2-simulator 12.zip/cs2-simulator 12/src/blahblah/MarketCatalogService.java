package blahblah;

import blahblah.hGui.*;
import java.awt.*;
import java.awt.event.*;
import java.util.List;
import java.util.Map;
import java.util.Set;
import javax.swing.*;

/** Market Catalog Service: focused feature implementation. */
final class MarketCatalogService {
  private final hGui app;

  MarketCatalogService(hGui app) {
    this.app = app;
  }

  static String unpackMarketCatalog(String[] chunks) {
    try (java.util.zip.GZIPInputStream stream =
        new java.util.zip.GZIPInputStream(
            new java.io.ByteArrayInputStream(
                java.util.Base64.getDecoder().decode(String.join("", chunks))))) {
      return new String(stream.readAllBytes(), java.nio.charset.StandardCharsets.UTF_8);
    } catch (java.io.IOException | IllegalArgumentException ex) {
      throw new IllegalStateException("Invalid bundled market catalog", ex);
    }
  }

  String marketCollectionIdentity(String name) {
    if (name == null) return "";
    String key =
        name.toLowerCase(java.util.Locale.ROOT)
            .replaceFirst("^the\\s+", "")
            .replaceFirst("\\s+collection$", "")
            .replace("&", "and")
            .replace("dust ii", "dust 2")
            .replaceAll("[^a-z0-9]", "");
    if (key.equals("2024overpass")) return "overpass2024";
    if (key.equals("2025train")) return "train2025";
    return key;
  }

  String canonicalMarketCollectionName(String name) {
    String key = app.marketCatalogService.marketCollectionIdentity(name);
    for (ArmouryCollection col : hGui.ARMOURY_COLLECTIONS) {
      if (!col.isAgents && key.equals(app.marketCatalogService.marketCollectionIdentity(col.name)))
        return col.name;
    }
    for (String registered : app.requestedMarketCollections.keySet()) {
      if (key.equals(app.marketCatalogService.marketCollectionIdentity(registered)))
        return registered;
    }
    return name;
  }

  String marketCollectionSkinKey(String name) {
    if (name == null) return "";
    return app.catalogParsingService
        .normalizeCatalogSkinName(
            name.replaceFirst("(?i)^StatTrak(?:™)?\\s+", "").replaceFirst("(?i)^Souvenir\\s+", ""))
        .replaceAll("(?i)\\s*\\((?:Phase [1-4]|Emerald|Ruby|Sapphire|Black Pearl)\\)$", "")
        .trim();
  }

  boolean belongsToMarketplaceCollection(String skinName, String selected) {
    String identity = app.marketCatalogService.marketCollectionIdentity(selected);
    Set<String> memberships =
        app.requestedMarketSkinCollections.get(
            app.marketCatalogService.marketCollectionSkinKey(skinName));
    if (memberships != null) {
      for (String col : memberships)
        if (identity.equals(app.marketCatalogService.marketCollectionIdentity(col))) return true;
    }
    String primary = app.collectionService.getCollectionName(skinName);
    return primary != null
        && identity.equals(app.marketCatalogService.marketCollectionIdentity(primary));
  }

  void registerRequestedMarketCollections() {
    String snapshot = MarketCatalogService.unpackMarketCatalog(hGui.REQUESTED_MARKET_SKINS);
    app.catalogParsingService.applyExternalSkinCatalog(snapshot);
    int cursor = 0;
    while ((cursor = snapshot.indexOf('{', cursor)) >= 0) {
      int end = app.publicPriceFeeds.findJsonObjectEnd(snapshot, cursor);
      if (end < 0) break;
      String object = snapshot.substring(cursor, end + 1);
      String name = app.catalogParsingService.extractCatalogString(object, "name", false);
      Double price = app.catalogParsingService.extractCatalogNumber(object, "fallback_base_price");
      if (name != null && price != null && price > 0)
        app.requestedMarketBasePrices.put(
            app.catalogParsingService.normalizeCatalogSkinName(name), price);
      cursor = end + 1;
    }
    String collections =
        MarketCatalogService.unpackMarketCatalog(hGui.REQUESTED_MARKET_COLLECTIONS);
    cursor = 0;
    while ((cursor = collections.indexOf('{', cursor)) >= 0) {
      int end = app.publicPriceFeeds.findJsonObjectEnd(collections, cursor);
      if (end < 0) break;
      String object = collections.substring(cursor, end + 1);
      String name =
          app.marketCatalogService.canonicalMarketCollectionName(
              app.catalogParsingService.extractCatalogString(object, "name", false));
      Map<String, List<String>> tiers = app.catalogLoadingService.extractCrateRegularDrops(object);
      TradeUpCollection col =
          new TradeUpCollection(
              name,
              tiers.get("Consumer").toArray(new String[0]),
              tiers.get("Industrial").toArray(new String[0]),
              tiers.get("Milspec").toArray(new String[0]),
              tiers.get("Restricted").toArray(new String[0]),
              tiers.get("Classified").toArray(new String[0]),
              tiers.get("Covert").toArray(new String[0]));
      app.requestedMarketCollections.put(name, col);
      for (List<String> tier : tiers.values()) {
        for (String skin : tier)
          app.requestedMarketSkinCollections
              .computeIfAbsent(
                  app.marketCatalogService.marketCollectionSkinKey(skin),
                  key -> new java.util.LinkedHashSet<>())
              .add(name);
      }
      cursor = end + 1;
    }
    app.collectionCache.clear();
    app.availableConditionsCache.clear();
    app.rarityCache.clear();
    app.marketStockService.invalidateGroupedMarketListingsCache();
  }

  boolean usesCatalogArmouryArtwork(ArmouryCollection col) {
    return col != null
        && ("The Achroma Collection".equals(col.name)
            || "The Arabesque Collection".equals(col.name)
            || "The Spy Tech Collection".equals(col.name));
  }

  void registerBundledArmouryCollections() {
    app.catalogParsingService.applyExternalSkinCatalog(hGui.ACHROMA_SKIN_SNAPSHOT);
  }

  void registerBundledTerminals() {
    app.catalogParsingService.applyExternalSkinCatalog(hGui.TERMINAL_SKIN_SNAPSHOT);
    app.catalogLoadingService.applyExternalCrateCatalog(hGui.TERMINAL_CRATE_SNAPSHOT);
  }
}
