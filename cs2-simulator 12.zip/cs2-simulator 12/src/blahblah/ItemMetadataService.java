package blahblah;

import blahblah.hGui.*;
import java.awt.*;
import java.awt.event.*;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import javax.swing.*;

/** Item Metadata Service: focused feature implementation. */
final class ItemMetadataService {
  private final hGui app;

  ItemMetadataService(hGui app) {
    this.app = app;
  }

  String normalizeAgentLookupKey(String skinName) {
    return skinName.replace("StatTrak ", "").replaceAll("[^a-zA-Z0-9]+", "").toLowerCase().trim();
  }

  void ensureAgentCaches() {
    if (!app.agentRarityCache.isEmpty() || hGui.ARMOURY_COLLECTIONS == null) return;
    for (ArmouryCollection col : hGui.ARMOURY_COLLECTIONS) {
      if (!col.isAgents) continue;
      String[] rarities = {"Distinguished", "Exceptional", "Superior", "Master"};
      String[][] names = {
        col.milspecNames, col.restrictedNames, col.classifiedNames, col.covertNames
      };
      double[][] prices = {
        col.milspecPrices, col.restrictedPrices, col.classifiedPrices, col.covertPrices
      };
      for (int i = 0; i < rarities.length; i++) {
        if (names[i] == null) continue;
        for (int j = 0; j < names[i].length; j++) {
          String key = app.itemMetadataService.normalizeAgentLookupKey(names[i][j]);
          app.agentRarityCache.put(key, rarities[i]);
          if (prices[i] != null && j < prices[i].length) {
            app.agentBasePriceCache.put(key, prices[i][j]);
          }
        }
      }
    }
  }

  String getAgentRarity(String skinName) {
    app.itemMetadataService.ensureAgentCaches();
    String key = app.itemMetadataService.normalizeAgentLookupKey(skinName);
    String rarity = app.agentRarityCache.get(key);
    if (rarity != null) return rarity;
    SkinMetadata metadata =
        app.agentCatalog.get(app.catalogParsingService.normalizeCatalogSkinName(skinName));
    return metadata == null ? null : metadata.rarity;
  }

  double getAgentBasePrice(String skinName) {
    app.itemMetadataService.ensureAgentCaches();
    String key = app.itemMetadataService.normalizeAgentLookupKey(skinName);
    Double livePrice = app.liveBasePrices.get(skinName);
    if (livePrice != null && livePrice > 0.0) return livePrice;
    Double cached = app.agentBasePriceCache.get(key);
    if (cached != null) return cached;
    String rarity = app.itemMetadataService.getAgentRarity(skinName);
    double fallback;
    if ("Distinguished".equals(rarity)) fallback = 12.0;
    else if ("Exceptional".equals(rarity)) fallback = 20.0;
    else if ("Superior".equals(rarity)) fallback = 50.0;
    else if ("Master".equals(rarity)) fallback = 125.0;
    else return 0.0;
    app.agentBasePriceCache.put(key, fallback);
    return fallback;
  }

  boolean isAgentSkin(String skinName) {
    return app.itemMetadataService.getAgentRarity(skinName) != null;
  }

  boolean shouldShowFloatForItem(String skinName, String rarity) {
    return !app.itemMetadataService.isAgentSkin(skinName)
        && !app.floatRules.isVanillaKnife(skinName);
  }

  boolean shouldShowPatternForItem(String skinName, String rarity) {
    return !app.itemMetadataService.isAgentSkin(skinName);
  }

  int getArmouryRedeemCost(ArmouryCollection col) {
    // Weapon collection offers in CS2's Armory cost four credits.  Agents
    // are a legacy custom offer in this simulator and retain their cost.
    return col != null && col.isAgents ? 15 : 4;
  }

  double[] getArmouryRarityWeights(ArmouryCollection col) {
    if (col != null && col.isAgents) {
      return CaseRollService.calculateCollectionTierOddsHighToLow(
          new boolean[] {true, true, true, true});
    }
    if (col != null && col.consumer != null && col.consumer.length > 0) {
      return CaseRollService.calculateCollectionTierOddsHighToLow(
          new boolean[] {
            true, true, true, true, true, col.covert != null && col.covert.length > 0
          });
    }
    // Sport & Field, Overpass 2024, and Graphic Design begin at Industrial,
    // so their five populated rarities are normalized without a Consumer roll.
    return CaseRollService.calculateCollectionTierOddsHighToLow(
        new boolean[] {true, true, true, true, true});
  }

  String getSkinRarity(String skinName) {
    if (app.exchangeStockService.exchangeContainer(skinName) != null) return "Container";
    String cached = app.rarityCache.get(skinName);
    if (cached != null) return cached;
    String original = skinName;
    skinName = app.catalogParsingService.stripSouvenirPrefix(skinName);
    if ("M4A4 | Howl".equalsIgnoreCase(skinName.trim())) {
      app.rarityCache.put(original, "Contraband");
      return "Contraband";
    }

    String spaceless =
        skinName
            .replace("StatTrak ", "")
            .replace("StatTrak ", "")
            .replaceAll("[^a-zA-Z0-9\\s\\-|]+", "")
            .trim();

    if (spaceless.contains("Bloodhound Gloves")
        || spaceless.contains("Driver Gloves")
        || spaceless.contains("Broken Fang Gloves")
        || spaceless.contains("Hydra Gloves")
        || spaceless.contains("Hand Wraps")
        || spaceless.contains("Moto Gloves")
        || spaceless.contains("Specialist Gloves")
        || spaceless.contains("Sport Gloves")) {
      app.rarityCache.put(original, "Gloves");
      return "Gloves";
    }

    if (spaceless.contains("Karambit")
        || spaceless.contains("M9 Bayonet")
        || spaceless.contains("Flip Knife")
        || spaceless.contains("Gut Knife")
        || spaceless.contains("Butterfly Knife")
        || spaceless.contains("Bayonet")
        || spaceless.contains("Huntsman Knife")
        || spaceless.contains("Bowie Knife")
        || spaceless.contains("Falchion Knife")
        || spaceless.contains("Kukri Knife")
        || spaceless.contains("Classic Knife")
        || spaceless.contains("Navaja Knife")
        || spaceless.contains("Nomad Knife")
        || spaceless.contains("Paracord Knife")
        || spaceless.contains("Shadow Daggers")
        || spaceless.contains("Skeleton Knife")
        || spaceless.contains("Stiletto Knife")
        || spaceless.contains("Survival Knife")
        || spaceless.contains("Talon Knife")
        || spaceless.contains("Ursus Knife")) {
      app.rarityCache.put(original, "Knife");
      return "Knife";
    }

    String agentRarity = app.itemMetadataService.getAgentRarity(spaceless);
    if (agentRarity != null) {
      app.rarityCache.put(original, agentRarity);
      return agentRarity;
    }

    String catalogName = app.catalogParsingService.normalizeCatalogSkinName(skinName);
    catalogName = catalogName.replaceFirst("(?i)^StatTrak™?\\s*", "");
    int catalogVariantStart = catalogName.lastIndexOf(" (");
    if (catalogVariantStart > 0) catalogName = catalogName.substring(0, catalogVariantStart).trim();
    SkinMetadata catalogMetadata = app.skinCatalog.get(catalogName);
    if (catalogMetadata != null) {
      if ("Knives".equals(catalogMetadata.category)) {
        app.rarityCache.put(original, "Knife");
        return "Knife";
      }
      if ("Gloves".equals(catalogMetadata.category)) {
        app.rarityCache.put(original, "Gloves");
        return "Gloves";
      }
      String catalogRarity =
          catalogMetadata.rarity == null
              ? null
              : app.collectionService.catalogRarityTier(catalogMetadata.rarity);
      if (catalogRarity != null) {
        app.rarityCache.put(original, catalogRarity);
        return catalogRarity;
      }
    }

    String armouryRarity = app.itemMetadataService.getArmouryCollectionRarity(skinName);
    if (armouryRarity != null) {
      app.rarityCache.put(original, armouryRarity);
      return armouryRarity;
    }

    String normName = spaceless.toLowerCase().replace(" ", "").replace("|", "").replace("-", "");

    String[][] rarityGroups = {
      {
        "Covert",
        "AWP|LightningStrike",
        "DesertEagle|GoldenKoi",
        "AK47|FireSerpent",
        "P90|Asiimov",
        "M4A1S|Cyrex",
        "AK47|Bloodsport",
        "USPS|NeoNoir",
        "M4A1S|Fade",
        "AK47|BtheMonster",
        "AWP|CMYK",
        "AK47|Inheritance",
        "AWP|ChromeCannon",
        "M4A4|Temukau",
        "AK47|HeadShot"
      },
      {
        "Classified",
        "DesertEagle|Hypnotic",
        "P90|EmeraldDragon",
        "AK47|CaseHardened",
        "P2000|OceanFoam",
        "AWP|Graphite",
        "FiveSeveN|FowlPlay",
        "DesertEagle|Conspiracy",
        "Glock18|WaterElemental",
        "CZ75Auto|Xiangliu",
        "AWP|FeverDream",
        "M4A1S|Decimator",
        "Glock18|AXIA",
        "GalilAR|RainbowSpoon",
        "Zeusx27|DragonSnore",
        "AWP|Crakow",
        "DesertEagle|Starcade",
        "AUG|LilPig",
        "M4A1S|BlackLotus",
        "USPS|Jawbreaker",
        "Zeusx27|Olympus",
        "AWP|Duality",
        "P2000|WickedSick",
        "UMP45|WildChild"
      },
      {
        "Restricted",
        "Glock18|DragonTattoo",
        "MAC10|Graven",
        "M4A1S|DarkWater",
        "M4A1S|BrightWater",
        "USPS|DarkWater",
        "M4A4|Zirka",
        "USPS|Overgrowth",
        "Nova|Koi",
        "PPBizon|Osiris",
        "CZ75Auto|Tigris",
        "P250|Supernova",
        "M249|EmeraldPoisonDart",
        "MAC10|LastDive",
        "UMP45|Scaffold",
        "XM1014|Seasons",
        "GalilAR|CrimsonTsunami",
        "UMP45|CrimsonFoil",
        "MP9|ArcticTriTone",
        "FiveSeveN|HeatTreated",
        "XM1014|MonsterMelt",
        "DualBerettas|SweetLittleAngels",
        "AUG|EyeofZapems",
        "P90|AttackVector",
        "M4A4|Polysoup",
        "CZ75Auto|Slalom",
        "M4A4|EtchLord",
        "Glock18|Block18",
        "FiveSeveN|Hybrid",
        "MP7|JustSmile",
        "SawedOff|AnalogInput",
        "M4A1S|EmphorosaurS",
        "Glock18|UmbralRabbit",
        "MAC10|Sakkaku",
        "P90|Neoqueen",
        "R8Revolver|BananaCannon"
      },
      {
        "Milspec",
        "MP7|Skulls",
        "AUG|Wings",
        "GalilAR|Shattered",
        "SG553|Ultraviolet",
        "SG553|WaveSpray",
        "G3SG1|Demeter",
        "Nova|Tempest",
        "DualBerettas|BlackLimba",
        "Negev|DesertStrike",
        "UMP45|Labyrinth",
        "P2000|Ivory",
        "MP7|UrbanHazard",
        "SSG08|Abyss",
        "PPBizon|JungleSlipstream",
        "SawedOff|Zander",
        "MP7|Akoben",
        "P250|Ripple",
        "SCAR20|Blueprint",
        "FiveSeveN|Capillary",
        "DesertEagle|OxideBlaze",
        "USPS|AlpineCamo",
        "SSG08|Zeno",
        "P250|SmallGame",
        "Nova|Yorkshire",
        "Nova|WurstHolle",
        "MAC10|Pipsqueak",
        "Glock18|TealGraf",
        "GalilAR|MetallicSqueezer",
        "XM1014|HalftoneShift",
        "SG553|BerryGelCoat",
        "SCAR20|WildBerry",
        "AK47|Crossfade",
        "MAC10|LightBox",
        "Nova|DarkSigil",
        "DualBerettas|Hideout",
        "SSG08|Dezastre",
        "UMP45|Motorized",
        "Tec9|Slag",
        "XM1014|Irezumi",
        "MP9|Featherweight",
        "MAG7|Insomnia",
        "P250|Rebuilt",
        "MP5SD|Liquidation",
        "SCAR20|Fragments",
        "SG553|Cyberforce",
        "Tec9|Rebel"
      },
      {
        "Industrial",
        "MP5SD|SavannahHalftone",
        "PPBizon|ColdCell",
        "Tec9|TigerStencil",
        "MAG7|Wildwood",
        "FAMAS|HalfSleeve",
        "AK47|OlivePolycam",
        "MP5SD|NeonSqueezer",
        "P90|Washme",
        "Negev|WallBang",
        "M4A1S|Washmeplz",
        "FiveSeveN|MidnightPaintover",
        "DesertEagle|Tilted",
        "SSG08|HalftoneWhorl",
        "P2000|CoralHalftone",
        "MP7|Astrolabe",
        "M249|Spectrogram",
        "GalilAR|NV",
        "FAMAS|HalftoneWash"
      }
    };

    for (String[] group : rarityGroups) {
      String rarity = group[0];
      for (int gi = 1; gi < group.length; gi++) {
        String normSkin =
            group[gi].toLowerCase().replace(" ", "").replace("|", "").replace("-", "");
        if (normName.equals(normSkin) || normName.contains(normSkin)) {
          app.rarityCache.put(original, rarity);
          return rarity;
        }
      }
    }

    app.rarityCache.put(original, "Milspec");
    return "Milspec";
  }

  String getArmouryCollectionRarity(String skinName) {
    String normalizedName =
        skinName == null
            ? ""
            : skinName
                .replaceFirst("(?i)^StatTrak\\s+", "")
                .replaceFirst("(?i)^Souvenir\\s+", "")
                .trim();
    if (normalizedName.isEmpty() || hGui.ARMOURY_COLLECTIONS == null) return null;
    for (ArmouryCollection collection : hGui.ARMOURY_COLLECTIONS) {
      if (collection.isAgents) continue;
      if (app.itemMetadataService.containsArmourySkin(collection.consumerNames, normalizedName))
        return "Consumer";
      if (app.itemMetadataService.containsArmourySkin(collection.industrialNames, normalizedName))
        return "Industrial";
      if (app.itemMetadataService.containsArmourySkin(collection.milspecNames, normalizedName))
        return "Milspec";
      if (app.itemMetadataService.containsArmourySkin(collection.restrictedNames, normalizedName))
        return "Restricted";
      if (app.itemMetadataService.containsArmourySkin(collection.classifiedNames, normalizedName))
        return "Classified";
      if (app.itemMetadataService.containsArmourySkin(collection.covertNames, normalizedName))
        return "Covert";
    }
    return null;
  }

  boolean containsArmourySkin(String[] names, String skinName) {
    if (names == null) return false;
    for (String name : names) {
      if (name != null && name.equalsIgnoreCase(skinName)) return true;
    }
    return false;
  }

  boolean isArmourySkin(String skinName) {
    if (hGui.ARMOURY_COLLECTIONS == null) return false;
    if (!app.armouryCacheBuilt) {
      for (ArmouryCollection ac : hGui.ARMOURY_COLLECTIONS) {
        String[][] allNames = {
          ac.covertNames, ac.classifiedNames, ac.restrictedNames,
          ac.milspecNames, ac.industrialNames, ac.consumerNames
        };
        for (String[] tier : allNames) {
          if (tier == null) continue;
          for (String n : tier) {
            if (n != null) app.armourySkinNameCache.add(n.toLowerCase());
          }
        }
      }
      app.armouryCacheBuilt = true;
    }
    String bare =
        skinName
            .replaceFirst("(?i)^StatTrak\\s+", "")
            .replaceFirst("(?i)^Souvenir\\s+", "")
            .trim()
            .toLowerCase();
    return app.armourySkinNameCache.contains(bare);
  }

  boolean isSouvenirPackageSkin(String skinName) {
    if (skinName == null) return false;
    if (!app.souvenirPackageSkinCacheBuilt) {
      synchronized (app.souvenirPackageSkinNameCache) {
        if (!app.souvenirPackageSkinCacheBuilt) {
          app.souvenirPackageSkinNameCache.clear();
          for (CaseType caseType : CaseType.values()) {
            if (!caseType.isSouvenir) continue;
            for (List<String> tier : caseType.regularDropNames.values()) {
              for (String packageSkin : tier) {
                app.souvenirPackageSkinNameCache.add(
                    packageSkin
                        .replaceFirst("(?i)^Souvenir\\s+", "")
                        .trim()
                        .toLowerCase(java.util.Locale.ROOT));
              }
            }
          }
          app.souvenirPackageSkinCacheBuilt = true;
        }
      }
    }
    String bare =
        skinName
            .replaceFirst("(?i)^StatTrak\\s+", "")
            .replaceFirst("(?i)^Souvenir\\s+", "")
            .trim()
            .toLowerCase(java.util.Locale.ROOT);
    return app.souvenirPackageSkinNameCache.contains(bare);
  }

  boolean supportsStatTrak(String skinName) {
    return skinName != null
        && !skinName.startsWith("Souvenir ")
        && !app.itemMetadataService.isAgentSkin(skinName)
        && !"Gloves".equals(app.itemMetadataService.getSkinRarity(skinName))
        && !app.requestedMarketSkinCollections.containsKey(
            app.marketCatalogService.marketCollectionSkinKey(skinName))
        && !app.itemMetadataService.isArmourySkin(skinName)
        && !app.itemMetadataService.isSouvenirPackageSkin(skinName);
  }

  void normalizeUnsupportedStatTrakListings() {
    synchronized (app.globalMarketListings) {
      for (Map.Entry<String, ArrayList<MarketListing>> entry :
          new ArrayList<>(app.globalMarketListings.entrySet())) {
        String key = entry.getKey();
        if (key == null || !key.startsWith("StatTrak ")) continue;
        String regularKey =
            app.leaderboardService.normalizeSkinName(key.substring("StatTrak ".length()));
        if (app.itemMetadataService.supportsStatTrak(regularKey)) continue;
        ArrayList<MarketListing> invalidListings = entry.getValue();
        ArrayList<MarketListing> regularListings =
            app.globalMarketListings.computeIfAbsent(regularKey, ignored -> new ArrayList<>());
        if (invalidListings != null) {
          for (MarketListing listing : invalidListings) {
            if (listing == null || listing.item == null) continue;
            listing.item.isStattrak = false;
            listing.item.rarity = listing.item.rarity.replace("StatTrak ", "").trim();
            regularListings.add(listing);
          }
        }
        app.globalMarketListings.remove(key);
      }
      // Older saves can also have an impossible StatTrak flag inside a
      // regular bucket.  Correct the item itself as well as its map key.
      for (ArrayList<MarketListing> listings : app.globalMarketListings.values()) {
        if (listings == null) continue;
        for (MarketListing listing : listings) {
          if (listing == null || listing.item == null || !listing.item.isStattrak) continue;
          if (!app.itemMetadataService.supportsStatTrak(listing.item.name)) {
            listing.item.isStattrak = false;
            listing.item.rarity = listing.item.rarity.replace("StatTrak ", "").trim();
          }
        }
      }
      app.marketStockService.invalidateGroupedMarketListingsCache();
    }
  }

  void removeImpossibleWearListings() {
    boolean changed = false;
    synchronized (app.globalMarketListings) {
      for (ArrayList<MarketListing> listings : app.globalMarketListings.values()) {
        if (listings == null) continue;
        changed |=
            listings.removeIf(
                listing ->
                    listing != null
                        && !listing.isPlayerListing
                        && listing.item != null
                        && !app.marketPurchaseService.isConditionValidForSkin(
                            listing.item.name, listing.item.condition));
      }
      if (changed) app.marketStockService.invalidateGroupedMarketListingsCache();
    }
  }

  void replenishThinMarketListings() {
    // Runtime maintenance is time-gated and adds only a small batch per skin.
    app.marketPriceChanges.ensureMinimumListings();
  }

  double getLowestListingPrice(String lookupKey, String desiredCondition) {
    ArrayList<MarketListing> listings = app.globalMarketListings.get(lookupKey);
    if (listings == null)
      listings = app.globalMarketListings.get(lookupKey.replace("StatTrak ", ""));
    if (listings == null) return 0;
    double lowest = Double.MAX_VALUE;
    for (MarketListing ml : listings) {
      if (ml.isPlayerListing) continue;
      boolean condMatch =
          desiredCondition.equals("Any") || ml.item.condition.equals(desiredCondition);
      if (condMatch && ml.getPrice() < lowest) lowest = ml.getPrice();
    }
    return lowest == Double.MAX_VALUE ? 0 : lowest;
  }
}
