package blahblah;

import blahblah.hGui.*;
import java.awt.*;
import java.awt.event.*;
import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.Comparator;
import java.util.List;
import java.util.Map;
import javax.swing.*;

/** Cs2 Screens: focused feature implementation. */
final class Cs2Screens {
  private final hGui app;
  private final java.util.Map<Image, java.util.Map<Long, Image>> scaledImages =
      new java.util.WeakHashMap<>();

  Cs2Screens(hGui app) {
    this.app = app;
  }

  Image cs2DefaultAgent(boolean t) {
    return null;
  }

  Font cs2Font(int style, int size) {
    return new Font("SansSerif", style, size);
  }

  JLabel cs2Text(String text, int size, Color color) {
    JLabel l = new JLabel(text);
    l.setFont(app.cs2Screens.cs2Font(Font.PLAIN, size));
    l.setForeground(color);
    return l;
  }

  JButton cs2Button(String text, boolean primary, ActionListener action) {
    JButton b = new JButton(text);
    b.setFont(app.cs2Screens.cs2Font(Font.BOLD, 13));
    b.setForeground(Color.WHITE);
    b.setBackground(primary ? new Color(43, 125, 89) : new Color(43, 49, 53));
    b.setFocusPainted(false);
    b.setBorder(BorderFactory.createEmptyBorder(11, 19, 11, 19));
    b.setCursor(Cursor.getPredefinedCursor(Cursor.HAND_CURSOR));
    if (action != null) b.addActionListener(action);
    return b;
  }

  void paintCs2Scene(Graphics g, int width, int height, boolean subdued) {
    Graphics2D p = (Graphics2D) g.create();
    if (app.cs2Background == null) app.cs2Background = app.uiCatalogData.decodeCs2Background();
    if (app.cs2Background != null) {
      Image background = app.cs2Background;
      p.setRenderingHint(
          RenderingHints.KEY_INTERPOLATION, RenderingHints.VALUE_INTERPOLATION_BICUBIC);
      double scale =
          Math.max(
              width / (double) background.getWidth(null),
              height / (double) background.getHeight(null));
      int w = (int) (background.getWidth(null) * scale),
          h = (int) (background.getHeight(null) * scale);
      p.drawImage(background, (width - w) / 2, (height - h) / 2, w, h, null);
    } else {
      p.setPaint(
          new GradientPaint(0, 0, new Color(94, 116, 123), width, height, new Color(67, 62, 48)));
      p.fillRect(0, 0, width, height);
    }
    p.setColor(new Color(13, 21, 27, subdued ? 135 : 30));
    p.fillRect(0, 0, width, height);
    p.setPaint(
        new GradientPaint(
            0, height / 2, new Color(0, 0, 0, 0), 0, height, new Color(8, 14, 19, 180)));
    p.fillRect(0, 0, width, height);
    p.dispose();
  }

  JPanel cs2Scene(boolean subdued) {
    return new JPanel(new BorderLayout()) {
      private java.awt.image.BufferedImage cached;
      private int scenery = -1;

      protected void paintComponent(Graphics g) {
        if (getWidth() < 1 || getHeight() < 1) return;
        if (cached == null
            || cached.getWidth() != getWidth()
            || cached.getHeight() != getHeight()
            || scenery != app.cs2SceneryIndex) {
          cached =
              new java.awt.image.BufferedImage(
                  getWidth(), getHeight(), java.awt.image.BufferedImage.TYPE_INT_RGB);
          Graphics2D b = cached.createGraphics();
          app.cs2Screens.paintCs2Scene(b, getWidth(), getHeight(), subdued);
          b.dispose();
          scenery = app.cs2SceneryIndex;
        }
        g.drawImage(cached, 0, 0, null);
      }
    };
  }

  JPanel cs2Grid(int columns, int gapX, int gapY) {
    ScrollablePanel p = new ScrollablePanel();
    p.setLayout(new GridLayout(0, columns, gapX, gapY));
    p.setOpaque(false);
    return p;
  }

  JPanel cs2Glass(LayoutManager layout) {
    JPanel p = new JPanel(layout);
    p.setOpaque(false);
    return p;
  }

  void installCs2Shell() {
    app.cs2ShellEnabled = true;
    app.setTitle("Counter-Strike • Simulator");
    app.setMinimumSize(new Dimension(1024, 650));
    app.setUndecorated(true);
    app.setExtendedState(JFrame.MAXIMIZED_BOTH);
    Rectangle screen =
        GraphicsEnvironment.getLocalGraphicsEnvironment()
            .getDefaultScreenDevice()
            .getDefaultConfiguration()
            .getBounds();
    app.setBounds(screen);
    app.getRootPane()
        .getInputMap(JComponent.WHEN_IN_FOCUSED_WINDOW)
        .put(KeyStroke.getKeyStroke(KeyEvent.VK_F11, 0), "cs2Fullscreen");
    app.getRootPane()
        .getActionMap()
        .put(
            "cs2Fullscreen",
            new AbstractAction() {
              public void actionPerformed(ActionEvent e) {
                if (app.getExtendedState() == JFrame.NORMAL)
                  app.setExtendedState(JFrame.MAXIMIZED_BOTH);
                else {
                  app.setExtendedState(JFrame.NORMAL);
                  app.setSize(1280, 800);
                  app.setLocationRelativeTo(null);
                }
              }
            });
    app.mainTabs.setUI(
        new javax.swing.plaf.basic.BasicTabbedPaneUI() {
          @Override
          protected int calculateTabAreaHeight(int placement, int runs, int height) {
            return 0;
          }

          @Override
          protected void paintTabArea(Graphics g, int placement, int selected) {}
        });
    app.mainTabs.setBorder(BorderFactory.createEmptyBorder());
    app.mainTabs.setComponentAt(0, app.cs2HomePanel = app.cs2Screens.createCs2Home());
    app.mainTabs.setComponentAt(1, new JPanel());
    app.mainTabs.setComponentAt(3, new JPanel());
    app.mainTabs.setComponentAt(6, app.generalTabPanel);
    app.storeScreen.install();
    app.remove(app.headerPanel);
    app.headerPanel = new JPanel(new BorderLayout());
    app.headerPanel.setBackground(new Color(37, 44, 48));
    app.headerPanel.setBorder(BorderFactory.createEmptyBorder(0, 18, 0, 18));
    app.headerPanel.setPreferredSize(new Dimension(0, 64));
    JPanel left = app.cs2Screens.cs2Glass(new FlowLayout(FlowLayout.LEFT, 4, 11));
    left.add(
        app.cs2Screens.cs2Button(
            "⌂",
            false,
            e -> {
              if (!app.isAnimating) {
                app.mainTabs.setSelectedIndex(0);
                app.cs2Screens.refreshCs2Home();
              }
            }));
    left.add(
        app.cs2Screens.cs2Button(
            "⚙",
            false,
            e -> {
              if (!app.isAnimating && !app.openingArtworkPreparing) app.storeScreen.open("MISC");
            }));
    left.add(
        app.cs2Screens.cs2Button(
            "×",
            false,
            e ->
                app.dispatchEvent(
                    new java.awt.event.WindowEvent(
                        app, java.awt.event.WindowEvent.WINDOW_CLOSING))));
    for (Component c : left.getComponents())
      if (c instanceof JButton) {
        c.setPreferredSize(new Dimension(58, 46));
        c.setFont(app.cs2Screens.cs2Font(Font.BOLD, 23));
        ((JButton) c).setBorder(BorderFactory.createEmptyBorder(8, 10, 8, 10));
      }
    app.headerPanel.add(left, BorderLayout.WEST);
    JPanel nav = app.cs2Screens.cs2Glass(new FlowLayout(FlowLayout.CENTER, 6, 10));
    String[] names = {"INVENTORY", "LOADOUT", "PLAY", "STORE"};
    int[] indices = {2, 5, -1, 4};
    for (int i = 0; i < names.length; i++) {
      final int index = indices[i];
      JButton b =
          app.cs2Screens.cs2Button(
              names[i],
              false,
              e -> {
                if (!app.isAnimating && !app.openingArtworkPreparing)
                  app.navigationService.navigateCs2Top(index);
              });
      b.setFont(app.cs2Screens.cs2Font(Font.PLAIN, 19));
      b.setName("cs2Nav" + names[i]);
      if (index < 0) {
        b.setEnabled(false);
        b.setToolTipText("Playable mode is not available yet.");
      } else app.cs2Navigation.put(index, b);
      nav.add(b);
    }
    app.headerPanel.add(nav, BorderLayout.CENTER);
    app.cs2BalanceLabel =
        app.cs2Screens.cs2Text(String.format("$%,.2f", app.balance), 17, new Color(205, 227, 200));
    app.headerPanel.add(app.cs2BalanceLabel, BorderLayout.EAST);
    app.add(app.headerPanel, BorderLayout.NORTH);
    app.mainTabs.addChangeListener(
        e -> {
          int selected = app.mainTabs.getSelectedIndex();
          if (selected == 2) SwingUtilities.invokeLater(() -> app.itemRevealService.showPending());
          for (Map.Entry<Integer, JButton> item : app.cs2Navigation.entrySet()) {
            item.getValue()
                .setForeground(item.getKey() == selected ? new Color(149, 207, 232) : Color.WHITE);
            item.getValue()
                .setBackground(
                    item.getKey() == selected ? new Color(53, 75, 86) : new Color(43, 49, 53));
          }
        });
    app.mainTabs.setSelectedIndex(0);
    app.autoOpenButton.setVisible(false);
    app.cs2Screens.refreshCs2Inventory();
  }

  JPanel createCs2Home() {
    JPanel root = app.cs2Screens.cs2Scene(false);
    root.setName("cs2Home");
    JPanel corner = app.cs2Screens.cs2Glass(new BorderLayout(0, 12));
    corner.setBorder(BorderFactory.createEmptyBorder(0, 22, 12, 0));
    corner.add(app.containerSelectionScreen.createCs2MissionCard(), BorderLayout.NORTH);
    JButton choose =
        app.cs2Screens.cs2Button(
            "SCENERY • " + hGui.CS2_SCENERY_NAMES[app.cs2SceneryIndex] + " ▾", false, null);
    choose.setName("cs2SceneryButton");
    choose.addActionListener(
        e -> {
          JPopupMenu menu = new JPopupMenu();
          for (int i = 0; i < hGui.CS2_SCENERY_NAMES.length; i++) {
            final int index = i;
            JMenuItem item =
                new JMenuItem((i == app.cs2SceneryIndex ? "✓ " : "") + hGui.CS2_SCENERY_NAMES[i]);
            item.addActionListener(event -> app.uiCatalogData.selectCs2Scenery(index));
            menu.add(item);
          }
          menu.show(choose, 0, -menu.getPreferredSize().height);
        });
    corner.add(choose, BorderLayout.SOUTH);
    JPanel left = app.cs2Screens.cs2Glass(new BorderLayout());
    left.add(corner, BorderLayout.SOUTH);
    root.add(left, BorderLayout.WEST);
    return root;
  }

  String defaultCs2Agent(boolean t) {
    for (String name : app.agentCatalog.keySet())
      if (t
          ? (name.contains("Phoenix") || name.contains("Professional"))
          : (name.contains("SAS") || name.contains("SEAL"))) return name;
    return app.agentCatalog.isEmpty() ? null : app.agentCatalog.keySet().iterator().next();
  }

  void refreshCs2Home() {
    if (!app.cs2ShellEnabled) return;
    app.cs2HomePanel = app.cs2Screens.createCs2Home();
    app.mainTabs.setComponentAt(0, app.cs2HomePanel);
  }

  void selectCs2InventorySection(String section) {
    String previousSection = app.cs2InventorySection;
    boolean wasInventory = app.mainTabs.getSelectedIndex() == 2;
    app.pageTransitions.begin();
    app.inventoryToolsService.closeBrowser();
    app.cs2InventorySection = section;
    app.cs2InventoryPage = 0;
    app.inventoryTabPanel.putClientProperty("cs2Snapshot", null);
    app.mainTabs.setSelectedIndex(2);
    app.cs2Screens.refreshCs2Inventory();
    app.pageTransitions.finish();
    if (wasInventory) app.pageTransitions.inventorySection(previousSection, section);
  }

  void navigateInventoryTradeUp() {
    if (app.cs2ShellEnabled) app.cs2Screens.selectCs2InventorySection("TRADE UP");
    else app.mainTabs.setSelectedIndex(3);
  }

  JPanel createCs2InventoryNav() {
    JPanel nav = new JPanel(new FlowLayout(FlowLayout.CENTER, 6, 7));
    nav.setBackground(new Color(35, 43, 47));
    for (String section :
        new String[] {"EVERYTHING", "EQUIPMENT", "CONTAINERS", "TRADE UP", "STEAM MARKET"}) {
      JButton b =
          app.cs2Screens.cs2Button(
              section,
              false,
              e -> {
                if (section.equals("STEAM MARKET")) {
                  app.storeScreen.open("MARKET");
                  return;
                }
                app.inventoryToolsService.closeBrowser();
                app.cs2EquipFilter = null;
                app.cs2UnlockSelection = null;
                app.cs2InventorySearch = "";
                app.cs2Screens.selectCs2InventorySection(section);
              });
      b.setName("cs2Inventory" + section);
      if (section.equals(app.cs2InventorySection)) b.setBackground(new Color(64, 91, 107));
      nav.add(b);
    }
    return nav;
  }

  void refreshCs2Inventory() {
    if (app.inventoryToolsService.browsingUnit != null) {
      app.inventoryToolsService.renderBrowser();
      return;
    }
    if (app.cs2UnlockSelection != null) {
      app.containerSelectionScreen.renderCs2UnlockSelection();
      return;
    }
    app.cs2EquipmentScreens.ensureDefaultWeaponInventory();
    List<Object> viewSnapshot = new ArrayList<>(app.inventoryList);
    if (app.ownedSupplies != null) viewSnapshot.addAll(app.ownedSupplies);
    viewSnapshot.addAll(app.inventoryToolsService.state.tools);
    viewSnapshot.add(app.cs2InventorySection);
    viewSnapshot.add(app.cs2EquipFilter);
    viewSnapshot.add(app.cs2EquipT);
    viewSnapshot.add(new java.util.LinkedHashMap<>(app.tLoadout));
    viewSnapshot.add(new java.util.LinkedHashMap<>(app.ctLoadout));
    if (!"TRADE UP".equals(app.cs2InventorySection)
        && viewSnapshot.equals(app.inventoryTabPanel.getClientProperty("cs2Snapshot"))) return;
    app.inventoryTabPanel.putClientProperty("cs2Snapshot", viewSnapshot);
    app.inventoryTabPanel.removeAll();
    app.inventoryTabPanel.setLayout(new BorderLayout());
    app.inventoryTabPanel.add(app.cs2Screens.createCs2InventoryNav(), BorderLayout.NORTH);
    if ("TRADE UP".equals(app.cs2InventorySection)) {
      app.cs2EquipmentScreens.refreshCs2TradeUp();
      app.tradeUpTabPanel.setVisible(true);
      app.inventoryTabPanel.add(app.tradeUpTabPanel, BorderLayout.CENTER);
      app.inventoryTabPanel.revalidate();
      app.inventoryTabPanel.repaint();
      return;
    }
    JPanel body = app.cs2Screens.cs2Scene(true),
        top = app.cs2Screens.cs2Glass(new BorderLayout(16, 0));
    top.setBorder(BorderFactory.createEmptyBorder(16, 28, 12, 28));
    JTextField search = new JTextField(app.cs2InventorySearch, 24);
    search.setName("cs2InventorySearch");
    search.setFont(app.cs2Screens.cs2Font(Font.PLAIN, 14));
    search.setBackground(new Color(53, 61, 65));
    search.setForeground(Color.WHITE);
    search.setCaretColor(Color.WHITE);
    search.setBorder(BorderFactory.createEmptyBorder(9, 12, 9, 12));
    JComboBox<String> sort =
        app.uiWidgets.createComboBox(
            new String[] {
              "Quality", "Newest", "Alphabetical", "Equip Slot", "Collection", "Equipped"
            });
    sort.setSelectedItem(app.cs2InventorySort);
    sort.setName("cs2InventorySort");
    if (app.cs2EquipFilter != null) {
      JButton back =
          app.cs2Screens.cs2Button(
              "← " + app.cs2EquipFilter + " • Equip " + (app.cs2EquipT ? "T" : "CT"),
              false,
              e -> {
                app.cs2EquipFilter = null;
                app.cs2Screens.selectCs2InventorySection("EVERYTHING");
              });
      top.add(back, BorderLayout.CENTER);
    }
    top.add(search, BorderLayout.WEST);
    top.add(sort, BorderLayout.EAST);
    body.add(top, BorderLayout.NORTH);
    JPanel grid = app.cs2Screens.cs2Grid(8, 14, 18);
    grid.setName("cs2InventoryGrid");
    grid.setOpaque(false);
    grid.setBorder(BorderFactory.createEmptyBorder(10, 28, 24, 28));
    JScrollPane scroll = new JScrollPane(grid);
    scroll.setOpaque(false);
    scroll.getViewport().setOpaque(false);
    scroll.setBorder(null);
    scroll.getViewport().setOpaque(false);
    scroll.getVerticalScrollBar().setUnitIncrement(28);
    SmoothScroll.install(scroll);
    body.add(scroll, BorderLayout.CENTER);
    JPanel footer = app.cs2Screens.cs2Glass(new BorderLayout());
    footer.setBorder(BorderFactory.createEmptyBorder(8, 28, 14, 28));
    JLabel count = app.cs2Screens.cs2Text("", 13, new Color(210, 216, 218));
    footer.add(count, BorderLayout.CENTER);
    JButton prev = app.cs2Screens.cs2Button("‹", false, null),
        next = app.cs2Screens.cs2Button("›", false, null);
    JPanel pages = app.cs2Screens.cs2Glass(new FlowLayout());
    pages.add(prev);
    pages.add(next);
    footer.add(pages, BorderLayout.EAST);
    body.add(footer, BorderLayout.SOUTH);
    Runnable render =
        () -> {
          List<Object> items =
              app.cs2Screens.filteredCs2Inventory(app.cs2InventorySection, app.cs2InventorySearch);
          items.sort(app.cs2Screens.cs2InventoryComparator());
          int total = items.size(), pageCount = Math.max(1, (total + 59) / 60);
          app.cs2InventoryPage = Math.max(0, Math.min(pageCount - 1, app.cs2InventoryPage));
          grid.removeAll();
          int start = app.cs2InventoryPage * 60, end = Math.min(total, start + 60);
          int cols = 8;
          grid.setLayout(new GridLayout(0, cols, 14, 18));
          for (int i = start; i < end; i++) {
            Object item = items.get(i);
            JPanel inventoryCard =
                (item instanceof InventoryToolsState.Tool
                    ? app.inventoryToolsService.card((InventoryToolsState.Tool) item)
                    : item instanceof OwnedSupply
                        ? app.cs2Screens.createCs2SupplyCard((OwnedSupply) item)
                        : app.cs2Screens.createCs2SkinCard(
                            (InventoryItem) item,
                            () -> app.cs2Screens.showCs2ItemMenu((InventoryItem) item)));
            if (item instanceof InventoryItem)
              installCs2CardClick(
                  inventoryCard,
                  new MouseAdapter() {
                    public void mouseClicked(MouseEvent e) {
                      if (SwingUtilities.isRightMouseButton(e) || e.isControlDown())
                        showCs2ItemMenu((InventoryItem) item);
                    }
                  });
            grid.add(inventoryCard);
          }
          long stock =
              items.stream()
                  .filter(
                      i ->
                          i instanceof InventoryItem
                              && app.cs2EquipmentScreens.isDefaultWeaponItem((InventoryItem) i))
                  .count();
          count.setText(
              (total - stock)
                  + " collectible items"
                  + (stock > 0 ? " + " + stock + " stock equipment" : "")
                  + "  •  Page "
                  + (app.cs2InventoryPage + 1)
                  + " / "
                  + pageCount
                  + String.format("  •  Skin value $%,.2f", app.inventoryValue));
          prev.setEnabled(app.cs2InventoryPage > 0);
          next.setEnabled(app.cs2InventoryPage + 1 < pageCount);
          grid.revalidate();
          grid.repaint();
        };
    javax.swing.Timer debounce =
        new javax.swing.Timer(
            180,
            e -> {
              app.cs2InventorySearch = search.getText();
              app.cs2InventoryPage = 0;
              render.run();
            });
    debounce.setRepeats(false);
    search
        .getDocument()
        .addDocumentListener(
            new javax.swing.event.DocumentListener() {
              public void insertUpdate(javax.swing.event.DocumentEvent e) {
                debounce.restart();
              }

              public void removeUpdate(javax.swing.event.DocumentEvent e) {
                debounce.restart();
              }

              public void changedUpdate(javax.swing.event.DocumentEvent e) {
                debounce.restart();
              }
            });
    sort.addActionListener(
        e -> {
          app.cs2InventorySort = (String) sort.getSelectedItem();
          app.cs2InventoryPage = 0;
          render.run();
        });
    prev.addActionListener(
        e -> {
          app.cs2InventoryPage--;
          render.run();
        });
    next.addActionListener(
        e -> {
          app.cs2InventoryPage++;
          render.run();
        });
    scroll
        .getViewport()
        .addComponentListener(
            new ComponentAdapter() {
              public void componentResized(ComponentEvent e) {
                int cols = 8;
                if (((GridLayout) grid.getLayout()).getColumns() != cols) {
                  grid.setLayout(new GridLayout(0, cols, 14, 18));
                  grid.revalidate();
                }
              }
            });
    app.inventoryTabPanel.add(body, BorderLayout.CENTER);
    render.run();
    app.inventoryTabPanel.revalidate();
    app.inventoryTabPanel.repaint();
  }

  List<Object> filteredCs2Inventory(String section, String query) {
    String q = query.toLowerCase(java.util.Locale.ROOT);
    List<Object> items = new ArrayList<>();
    if ("EQUIPMENT".equals(section) || "STORAGE UNITS".equals(section)) {
      for (InventoryToolsState.Tool t : app.inventoryToolsService.state.tools)
        if ((!"STORAGE UNITS".equals(section) || t.storage)
            && app.inventoryToolsService.title(t).toLowerCase(java.util.Locale.ROOT).contains(q))
          items.add(t);
      return items;
    }
    if ("EVERYTHING".equals(section) && app.cs2EquipFilter == null)
      for (InventoryToolsState.Tool t : app.inventoryToolsService.state.tools)
        if (app.inventoryToolsService.title(t).toLowerCase(java.util.Locale.ROOT).contains(q))
          items.add(t);
    if (!"CONTAINERS".equals(section))
      for (InventoryItem item : app.inventoryList)
        if (app.inventoryToolsService
                .displayName(item)
                .toLowerCase(java.util.Locale.ROOT)
                .contains(q)
            && (app.cs2EquipFilter == null
                || app.cs2EquipmentScreens.matchesEquipSlot(item, app.cs2EquipFilter)))
          items.add(item);
    if (app.cs2EquipFilter == null && !"EQUIPMENT".equals(section) && app.ownedSupplies != null)
      for (OwnedSupply s : app.ownedSupplies) {
        CaseType ct = CaseType.valueOf(s.caseId);
        if ((ct.name + (s.key ? " key" : "")).toLowerCase(java.util.Locale.ROOT).contains(q))
          items.add(s);
      }
    return items;
  }

  String cs2ItemName(Object o) {
    if (o instanceof InventoryToolsState.Tool)
      return app.inventoryToolsService.title((InventoryToolsState.Tool) o);
    return o instanceof InventoryItem
        ? ((InventoryItem) o).name
        : CaseType.valueOf(((OwnedSupply) o).caseId).name + (((OwnedSupply) o).key ? " Key" : "");
  }

  long cs2CreatedAt(Object o) {
    if (o instanceof InventoryToolsState.Tool) return ((InventoryToolsState.Tool) o).createdAt;
    return o instanceof InventoryItem ? ((InventoryItem) o).createdAt : ((OwnedSupply) o).createdAt;
  }

  double cs2ItemPrice(Object o) {
    if (o instanceof InventoryToolsState.Tool) return InventoryToolsService.PRICE;
    return o instanceof InventoryItem
        ? ((InventoryItem) o).price.doubleValue()
        : ((OwnedSupply) o).purchasePrice;
  }

  Comparator<Object> cs2InventoryComparator() {
    return Comparator.comparingInt(
            (Object o) ->
                o instanceof InventoryItem
                        && app.cs2EquipmentScreens.isDefaultWeaponItem((InventoryItem) o)
                    ? 1
                    : 0)
        .thenComparing(inventoryOrder());
  }

  private Comparator<Object> inventoryOrder() {
    Comparator<Object> names =
        Comparator.comparing(app.cs2Screens::cs2ItemName, String.CASE_INSENSITIVE_ORDER);
    switch (app.cs2InventorySort) {
      case "Newest":
        return Comparator.comparingLong(app.cs2Screens::cs2CreatedAt)
            .reversed()
            .thenComparing(names);
      case "Alphabetical":
        return names;
      case "Equip Slot":
        return Comparator.comparing(app.cs2Screens::inventorySlot).thenComparing(names);
      case "Collection":
        return Comparator.comparing(
                app.cs2Screens::inventoryCollection, String.CASE_INSENSITIVE_ORDER)
            .thenComparing(names);
      case "Equipped":
        return Comparator.comparingInt(app.cs2Screens::inventoryEquipped)
            .reversed()
            .thenComparing(names);
      default:
        return Comparator.comparingInt(app.cs2Screens::inventoryQuality)
            .reversed()
            .thenComparing(names);
    }
  }

  int inventoryQuality(Object o) {
    if (!(o instanceof InventoryItem)) return o instanceof OwnedSupply ? 1 : 0;
    InventoryItem i = (InventoryItem) o;
    if (app.cs2EquipmentScreens.isDefaultWeaponItem(i)) return 0;
    String r = i.rarity == null ? "" : i.rarity;
    if (r.contains("Knife") || r.contains("Glove")) return 8;
    if (r.contains("Contraband")) return 7;
    if (r.contains("Covert") || r.contains("Master")) return 6;
    if (r.contains("Classified") || r.contains("Superior")) return 5;
    if (r.contains("Restricted") || r.contains("Exceptional")) return 4;
    if (r.contains("Mil-Spec") || r.contains("Milspec") || r.contains("Distinguished")) return 3;
    if (r.contains("Industrial")) return 2;
    return 1;
  }

  String inventorySlot(Object o) {
    if (!(o instanceof InventoryItem)) return "ZZZ / " + cs2ItemName(o);
    InventoryItem i = (InventoryItem) o;
    if (i.rarity.contains("Knife")) return "Knife";
    if (i.rarity.contains("Glove")) return "Gloves";
    return app.marketFilterControls.extractWeaponType(i.name);
  }

  String inventoryCollection(Object o) {
    if (!(o instanceof InventoryItem)) return "ZZZ / Other";
    String name = app.inventoryScreen.resolveInventoryItemCollection((InventoryItem) o);
    return name == null || name.isEmpty() || name.equals("None") ? "ZZZ / Other" : name;
  }

  int inventoryEquipped(Object o) {
    return o instanceof InventoryItem
            && (app.tLoadout.containsValue(o) || app.ctLoadout.containsValue(o))
        ? 1
        : 0;
  }

  JPanel createCs2Tile(String name, String subtitle, Color rarity, JLabel image, Runnable click) {
    JPanel tile = app.cs2Screens.cs2Glass(new BorderLayout(0, 5));
    tile.setPreferredSize(new Dimension(158, 155));
    tile.setOpaque(false);
    tile.setName("cs2ItemCard");
    JPanel well =
        new JPanel(new BorderLayout()) {
          @Override
          protected void paintChildren(Graphics graphics) {
            super.paintChildren(graphics);
            Graphics2D p = (Graphics2D) graphics.create();
            p.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
            int x = getWidth() - 17;
            for (String side : new String[] {"equippedT", "equippedCT"})
              if (Boolean.TRUE.equals(tile.getClientProperty(side))) {
                p.setColor(
                    "equippedT".equals(side) ? new Color(234, 190, 74) : new Color(100, 178, 238));
                p.fillOval(x, 8, 9, 9);
                x -= 15;
              }
            p.dispose();
          }

          @Override
          protected void paintComponent(Graphics g) {
            Graphics2D p = (Graphics2D) g.create();
            p.setColor(new Color(105, 109, 113));
            p.fillRect(0, 0, getWidth(), getHeight());
            p.setPaint(
                new GradientPaint(
                    0,
                    0,
                    new Color(0, 0, 0, 110),
                    0,
                    Math.max(1, Math.min(28, getHeight() / 3)),
                    new Color(0, 0, 0, 0)));
            p.fillRect(0, 0, getWidth(), Math.max(1, Math.min(28, getHeight() / 3)));
            p.dispose();
          }
        };
    well.setBackground(new Color(105, 109, 113));
    well.setOpaque(true);
    well.setName("cs2CardWell");
    well.setBorder(BorderFactory.createMatteBorder(0, 0, 4, 0, rarity));
    well.setPreferredSize(new Dimension(158, 112));
    well.add(image);
    tile.add(well, BorderLayout.CENTER);
    JPanel text = app.cs2Screens.cs2Glass(new GridLayout(2, 1));
    JLabel title = app.cs2Screens.cs2Text(name, 11, Color.WHITE);
    title.setToolTipText(name);
    text.add(title);
    text.add(app.cs2Screens.cs2Text(subtitle, 10, new Color(190, 198, 202)));
    tile.add(text, BorderLayout.SOUTH);
    tile.setCursor(Cursor.getPredefinedCursor(Cursor.HAND_CURSOR));
    if (click != null) {
      MouseAdapter handler =
          new MouseAdapter() {
            public void mouseClicked(MouseEvent e) {
              if (SwingUtilities.isLeftMouseButton(e) && !e.isControlDown()) click.run();
            }

            public void mouseEntered(MouseEvent e) {
              well.setBorder(BorderFactory.createMatteBorder(0, 0, 4, 0, rarity.brighter()));
            }

            public void mouseExited(MouseEvent e) {
              well.setBorder(BorderFactory.createMatteBorder(0, 0, 4, 0, rarity));
            }
          };
      app.cs2Screens.installCs2CardClick(tile, handler);
    }
    return tile;
  }

  void installCs2CardClick(Component c, MouseAdapter handler) {
    c.addMouseListener(handler);
    c.setCursor(Cursor.getPredefinedCursor(Cursor.HAND_CURSOR));
    if (c instanceof Container)
      for (Component child : ((Container) c).getComponents())
        app.cs2Screens.installCs2CardClick(child, handler);
  }

  JPanel createCs2SkinCard(InventoryItem item, Runnable action) {
    JLabel image = new JLabel("", SwingConstants.CENTER);
    CaseType container = app.exchangeStockService.exchangeContainer(item.name);
    if (container != null) app.cs2Screens.bindCs2SupplyArtwork(container, false, image, 150, 105);
    else app.artworkService.getSkinImageFromName(item.name, item.condition, image, 150, 105);
    String[] parts = ItemPresentation.name(app, item).split(" \\| ", 2);
    JPanel tile =
        app.cs2Screens.createCs2Tile(
            app.inventoryToolsService.state.customNames.containsKey(item.itemId)
                ? "“" + app.inventoryToolsService.state.customNames.get(item.itemId) + "”"
                : parts[0],
            parts.length > 1 ? parts[1] : item.condition,
            app.cs2EquipmentScreens.itemColor(item),
            image,
            action);
    tile.putClientProperty("inventoryItem", item);
    tile.putClientProperty("equippedCT", app.cs2EquipmentScreens.isEquipped(item, false));
    tile.putClientProperty("equippedT", app.cs2EquipmentScreens.isEquipped(item, true));
    if (app.inventoryToolsService.state.customNames.containsKey(item.itemId))
      tile.setToolTipText(app.inventoryToolsService.displayName(item));
    if (container != null) {
      Double quote = ContainerMarketService.quote(item.name);
      tile.setToolTipText(
          item.name
              + " • "
              + (quote != null && Double.isFinite(quote)
                  ? String.format("$%.2f", quote)
                  : "Quote unavailable"));
      return tile;
    }
    tile.setToolTipText(
        item.name
            + " • "
            + item.condition
            + String.format(" • %.8f • $%.2f", item.itemFloat, item.price.doubleValue()));
    return tile;
  }

  void bindCs2SupplyArtwork(CaseType ct, boolean key, JLabel target, int width, int height) {
    String id = (key ? "case-key-" : "case-selector-") + ct.id;
    String[] info = hGui.CS2_KEY_CATALOG.get(ct.catalogCrateName());
    String url = key ? (info == null ? null : info[1]) : ct.imageUrl;
    Image image = key ? app.cs2EquipmentScreens.getCs2KeyImage(ct) : app.imageRepository.get(id);
    if (image != null) {
      target.setIcon(new ImageIcon(app.cs2Screens.scaleCs2Image(image, width, height)));
      target.setText("");
    } else {
      target.setText(url == null ? "Artwork unavailable" : "Loading image…");
      target.setForeground(Theme.TEXT_DIM);
    }
    app.artworkService.registerPendingRemoteImageLabel(id, target, width, height);
    if (image == null && url != null) app.imageRepository.loadRemote(id, url, false);
  }

  JPanel createCs2SupplyCard(OwnedSupply supply) {
    CaseType ct = CaseType.valueOf(supply.caseId);
    JLabel image = new JLabel("", SwingConstants.CENTER);
    app.cs2Screens.bindCs2SupplyArtwork(ct, supply.key, image, 150, 104);
    return app.cs2Screens.createCs2Tile(
        supply.key ? app.cs2EquipmentScreens.keyName(ct) : ct.name,
        supply.key ? "Key" : "Container",
        new Color(170, 188, 205),
        image,
        () -> app.containerSelectionScreen.showCs2SupplyMenu(supply));
  }

  synchronized Image scaleCs2Image(Image image, int width, int height) {
    int w = image.getWidth(null), h = image.getHeight(null);
    if (w <= 0 || h <= 0) return image;
    long key = ((long) width << 32) | (height & 0xffffffffL);
    java.util.Map<Long, Image> sizes =
        scaledImages.computeIfAbsent(
            image,
            k ->
                new java.util.LinkedHashMap<Long, Image>() {
                  protected boolean removeEldestEntry(java.util.Map.Entry<Long, Image> e) {
                    return size() > 4;
                  }
                });
    Image ready = sizes.get(key);
    if (ready != null) return ready;
    double scale = Math.min(width / (double) w, height / (double) h);
    Image result = HighQualityImages.fit(image, width, height);
    sizes.put(key, result);
    return result;
  }

  void showCs2ItemMenu(InventoryItem item) {
    app.inventoryToolsService.showPopupAtCursor(buildCs2ItemMenu(item));
  }

  JPopupMenu buildCs2ItemMenu(InventoryItem item) {
    JPopupMenu menu = app.inventoryToolsService.popup();
    app.inventoryToolsService.add(menu, "Inspect", () -> showCs2Inspect(item));
    app.inventoryToolsService.add(
        menu,
        "View in Loadout",
        () -> {
          app.mainTabs.setSelectedIndex(5);
          app.cs2EquipmentScreens.refreshCs2Loadout();
        });
    for (boolean t : new boolean[] {true, false})
      if (app.loadoutScreen.isUsableOnSide(item, t)
          && (app.cs2EquipFilter == null || t == app.cs2EquipT))
        app.inventoryToolsService.add(
            menu,
            t ? "Replace on T" : "Replace on CT",
            () -> {
              String slot = app.cs2EquipmentScreens.equipmentSlot(item, t);
              (t ? app.tLoadout : app.ctLoadout).put(slot, item);
              app.containerSelectionScreen.invalidateCs2Inventory();
              app.cs2Screens.refreshCs2Inventory();
              app.cs2EquipmentScreens.refreshCs2Loadout();
              app.saveService.saveProgress();
            });
    menu.addSeparator();
    if (app.inventoryToolsService.canRename(item)) {
      app.inventoryToolsService.add(
          menu, "Apply Name Tag", () -> app.inventoryToolsService.renameItem(item));
      if (app.inventoryToolsService.state.customNames.containsKey(item.itemId))
        app.inventoryToolsService.add(
            menu,
            "Remove Name",
            () -> {
              app.inventoryToolsService.state.customNames.remove(item.itemId);
              app.inventoryToolsService.changed();
            });
    }
    if (app.loadoutScreen.isTradeUpEligibleItem(item))
      app.inventoryToolsService.add(
          menu,
          "Use With Trade Up Contract",
          () -> {
            app.goldTradeUpMode = item.rarity.contains("Covert");
            app.tradeUpSelection.clear();
            app.tradeUpSelection.add(item);
            navigateInventoryTradeUp();
          });
    for (boolean t : new boolean[] {true, false})
      if (app.loadoutScreen.isUsableOnSide(item, t)) {
        java.util.Set<String> favorites = app.inventoryToolsService.favorites(t);
        app.inventoryToolsService.add(
            menu,
            (favorites.contains(item.itemId) ? "Remove from" : "Add to")
                + " Favorites for "
                + (t ? "T" : "CT"),
            () -> {
              if (!favorites.remove(item.itemId)) favorites.add(item.itemId);
              app.saveService.saveProgress();
            });
      }
    if (app.inventoryToolsService.storable(item))
      app.inventoryToolsService.add(
          menu, "Move to Storage Unit", () -> app.inventoryToolsService.moveToUnit(item));
    if (!app.cs2EquipmentScreens.isDefaultWeaponItem(item)) {
      menu.addSeparator();
      app.inventoryToolsService.add(
          menu, "Sell on Market", () -> app.exchangeScreens.navigateExchangeDirectory(item));
    }
    return menu;
  }

  void showCs2Inspect(InventoryItem item) {
    app.artworkService.refreshInventoryItemArtwork(item);
    JDialog d =
        new JDialog(
            app.cs2ContainerDialog != null && app.cs2ContainerDialog.isShowing()
                ? app.cs2ContainerDialog
                : app,
            "Inspect",
            Dialog.ModalityType.APPLICATION_MODAL);
    app.cs2Screens.configureCs2Dialog(d);
    FadePanel result =
        app.cs2Screens.createCs2RewardPanel(
            item.image == null ? null : item.image.getImage(),
            app.cs2EquipmentScreens.inspectionName(item),
            app.cs2EquipmentScreens.itemColor(item),
            app.uiWidgets.buildItemInfoHtml(
                item.rarity,
                item.condition,
                item.itemFloat,
                item.patternID,
                app.inventoryScreen.resolveInventoryItemCollection(item),
                false),
            e -> d.dispose(),
            "Item inspection");
    JPanel inspectScene = (JPanel) result.getComponent(0);
    inspectScene.add(
        ItemPresentation.identity(app, item, 27, "inspectItem", true), BorderLayout.NORTH);
    InspectImageView inspection =
        new InspectImageView(item.image == null ? null : item.image.getImage());
    inspectScene.add(inspection, BorderLayout.CENTER);
    app.activeResultImageLabel = inspection;
    JPanel inspectFooter =
        (JPanel) ((BorderLayout) inspectScene.getLayout()).getLayoutComponent(BorderLayout.SOUTH);
    JPanel mouseControls = cs2Glass(new FlowLayout(FlowLayout.CENTER, 12, 0));
    mouseControls.add(
        cs2Text("2D image · Drag to move · Scroll to zoom", 12, new Color(209, 217, 219)));
    JButton reset = cs2Button("RESET VIEW", false, e -> inspection.reset());
    reset.setName("inspectResetView");
    mouseControls.add(reset);
    inspectFooter.add(mouseControls, BorderLayout.CENTER);
    String customName = app.inventoryToolsService.state.customNames.get(item.itemId);
    if (customName != null) {
      JPanel scene = (JPanel) result.getComponent(0);
      Component heading = ((BorderLayout) scene.getLayout()).getLayoutComponent(BorderLayout.NORTH);
      JPanel names = cs2Glass(new BorderLayout(0, 10));
      names.add(heading, BorderLayout.NORTH);
      JLabel label = cs2Text("“" + customName + "”", 20, Color.WHITE);
      label.setName("inspectCustomName");
      label.setHorizontalAlignment(SwingConstants.CENTER);
      names.add(label, BorderLayout.SOUTH);
      scene.add(names, BorderLayout.NORTH);
    }
    result.setAlpha(1f);
    d.add(result);
    app.artworkService.getSkinImageFromName(
        item.name, item.condition, app.activeResultImageLabel, 820, 490);
    d.setVisible(true);
  }

  void configureCs2Dialog(JDialog d) {
    d.setUndecorated(true);
    Color backing = new Color(20, 26, 30);
    d.setBackground(backing);
    d.getRootPane().setOpaque(true);
    d.getRootPane().setBackground(backing);
    d.getLayeredPane().setOpaque(true);
    d.getLayeredPane().setBackground(backing);
    d.setSize(app.getSize());
    d.setLocation(app.getLocation());
    d.setLayout(new BorderLayout());
    d.getContentPane().setBackground(new Color(20, 26, 30));
    d.setDefaultCloseOperation(JDialog.DISPOSE_ON_CLOSE);
    d.getRootPane()
        .getInputMap(JComponent.WHEN_IN_FOCUSED_WINDOW)
        .put(KeyStroke.getKeyStroke(KeyEvent.VK_ESCAPE, 0), "close");
    d.getRootPane()
        .getActionMap()
        .put(
            "close",
            new AbstractAction() {
              public void actionPerformed(ActionEvent e) {
                d.dispose();
              }
            });
  }

  FadePanel createCs2RewardPanel(
      Image image, String name, Color rarity, String info, ActionListener close) {
    return app.cs2Screens.createCs2RewardPanel(image, name, rarity, info, close, "");
  }

  FadePanel createCs2RewardPanel(
      Image image, String name, Color rarity, String info, ActionListener close, String caption) {
    FadePanel result = new FadePanel(new BorderLayout());
    JPanel scene = app.cs2Screens.cs2Scene(true);
    scene.setBorder(BorderFactory.createEmptyBorder(40, 80, 30, 80));
    JLabel title = app.cs2Screens.cs2Text(name, 30, Color.WHITE);
    title.setHorizontalAlignment(SwingConstants.CENTER);
    title.setBorder(
        BorderFactory.createCompoundBorder(
            BorderFactory.createEmptyBorder(0, 100, 0, 100),
            BorderFactory.createMatteBorder(0, 0, 4, 0, rarity)));
    scene.add(title, BorderLayout.NORTH);
    JLabel art = new JLabel("", SwingConstants.CENTER);
    if (image != null) art.setIcon(new ImageIcon(app.cs2Screens.scaleCs2Image(image, 820, 490)));
    app.activeResultImageLabel = art;
    scene.add(art, BorderLayout.CENTER);
    JPanel bottom = app.cs2Screens.cs2Glass(new BorderLayout(12, 0));
    bottom.setBorder(BorderFactory.createEmptyBorder(15, 80, 0, 80));
    bottom.add(app.uiWidgets.createInfoBadge(info), BorderLayout.WEST);
    bottom.add(app.cs2Screens.cs2Text(caption, 14, new Color(209, 217, 219)), BorderLayout.CENTER);
    bottom.add(app.cs2Screens.cs2Button("CLOSE", false, close), BorderLayout.EAST);
    scene.add(bottom, BorderLayout.SOUTH);
    result.add(scene);
    return result;
  }

  void showContainerOutcomeMenu(String skin, String rarity) {
    JPopupMenu menu = new JPopupMenu();
    JMenuItem inspect = new JMenuItem("Inspect");
    inspect.addActionListener(
        e -> {
          String wear = app.floatRules.hasNoFloatWear(skin) ? "Normal" : "Factory New";
          double[] bounds = app.marketStockService.getMarketWearBounds(skin);
          double previewFloat = app.floatRules.hasNoFloatWear(skin) ? 0 : Math.max(0, bounds[0]);
          wear =
              app.floatRules.hasNoFloatWear(skin)
                  ? "Normal"
                  : app.floatRules.getConditionForFloat(skin, previewFloat);
          InventoryItem preview =
              new InventoryItem(
                  null,
                  skin,
                  wear,
                  rarity,
                  java.math.BigDecimal.ZERO,
                  previewFloat,
                  false,
                  0,
                  null,
                  0);
          app.cs2Screens.showCs2Inspect(preview);
        });
    menu.add(inspect);
    Point pointer =
        MouseInfo.getPointerInfo() == null ? null : MouseInfo.getPointerInfo().getLocation();
    Component host = app.cs2ContainerDialog != null ? app.cs2ContainerDialog : app;
    if (pointer == null) pointer = new Point(host.getWidth() / 2, host.getHeight() / 2);
    else SwingUtilities.convertPointFromScreen(pointer, host);
    menu.show(host, pointer.x, pointer.y);
  }

  void showCs2Container(CaseType ct) {
    if (app.isAnimating
        || app.openingArtworkPreparing
        || app.containerInventoryService.ownedSupplyCount(ct, false) == 0) return;
    app.currentCase = ct;
    if (!ct.id.equals(app.openingArtworkCaseId)) {
      app.openingArtworkPreparing = true;
      final long version = app.worldVersion;
      app.setCursor(Cursor.getPredefinedCursor(Cursor.WAIT_CURSOR));
      new SwingWorker<Void, Void>() {
        protected Void doInBackground() {
          app.openingArtworkService.prepareOpeningArtwork(ct);
          return null;
        }

        protected void done() {
          app.openingArtworkPreparing = false;
          app.setCursor(Cursor.getDefaultCursor());
          try {
            get();
            if (version == app.worldVersion && app.isShowing() && app.currentCase == ct)
              app.cs2Screens.showCs2Container(ct);
          } catch (Exception ex) {
            System.err.println("Container artwork preparation failed: " + ex);
            JOptionPane.showMessageDialog(
                app, "Could not prepare container artwork. Please retry.");
          }
        }
      }.execute();
      return;
    }
    app.crateImage = app.containerBrowserScreen.getContainerImage(ct);
    if (app.cs2SelectedOpeningContainer != null
        && app.ownedSupplies.stream()
            .noneMatch(
                supply ->
                    supply.id.equals(app.cs2SelectedOpeningContainer)
                        && supply.caseId.equals(ct.id))) {
      app.cs2SelectedOpeningContainer = null;
      app.cs2SelectedOpeningKey = null;
    }
    JDialog d = new JDialog(app, "Unlock " + ct.name, true);
    app.cs2ContainerDialog = d;
    app.cs2Screens.configureCs2Dialog(d);
    JPanel content = app.cs2Screens.createCs2ContainerPanel(ct, d);
    content.setOpaque(true);
    content.setBackground(new Color(20, 26, 30));
    d.setContentPane(content);
    d.validate();
    d.setVisible(true);
  }

  JPanel createCs2ContainerPanel(CaseType ct, JDialog owner) {
    JPanel root = app.cs2Screens.cs2Scene(true);
    JPanel centre = app.cs2Screens.cs2Glass(new BorderLayout());
    JPanel heading = app.cs2Screens.cs2Glass(new GridLayout(3, 1, 0, 8));
    heading.setBorder(BorderFactory.createEmptyBorder(30, 0, 15, 0));
    for (JLabel label :
        new JLabel[] {
          app.cs2Screens.cs2Text("Unlock Container", 34, Color.WHITE),
          app.cs2Screens.cs2Text("Unlock " + ct.name, 20, Color.WHITE),
          app.cs2Screens.cs2Text(
              "ⓘ  This container can only be opened once", 13, new Color(219, 221, 218))
        }) {
      label.setHorizontalAlignment(SwingConstants.CENTER);
      heading.add(label);
    }
    centre.add(heading, BorderLayout.NORTH);
    JLabel crate = new JLabel("", SwingConstants.CENTER);
    app.cs2Screens.bindCs2SupplyArtwork(ct, false, crate, 550, 320);
    centre.add(crate, BorderLayout.CENTER);
    root.add(centre, BorderLayout.CENTER);
    JPanel lower = app.cs2Screens.cs2Glass(new BorderLayout(0, 14));
    lower.setBorder(BorderFactory.createEmptyBorder(10, 40, 20, 40));
    JPanel outcomes = app.cs2Screens.cs2Glass(new BorderLayout(0, 10));
    JPanel caption = app.cs2Screens.cs2Glass(new BorderLayout());
    caption.add(
        app.cs2Screens.cs2Text("Contains one of the following:", 13, Color.WHITE),
        BorderLayout.WEST);

    outcomes.add(caption, BorderLayout.NORTH);
    JPanel items =
        new JPanel(new GridLayout(0, 10, 12, 10)) {
          @Override
          public Dimension getPreferredSize() {
            int rows = Math.max(1, (getComponentCount() + 9) / 10);
            return new Dimension(100, rows * 140);
          }
        };
    items.setOpaque(false);
    items.setName("cs2ContainerContents");
    for (String tier :
        new String[] {"Consumer", "Industrial", "Milspec", "Restricted", "Classified", "Covert"})
      for (String skin :
          ct.regularDropNames.getOrDefault(tier, java.util.Collections.emptyList())) {
        JLabel art = new JLabel("", SwingConstants.CENTER);
        app.artworkService.getSkinImageFromName(skin, null, art, 116, 72);
        String[] parts = skin.split(" \\| ", 2);
        items.add(
            app.cs2Screens.createCs2Tile(
                parts[0],
                parts.length > 1 ? parts[1] : "",
                app.itemInspectionScreen.getRarityColor(tier),
                art,
                () -> showContainerOutcomeMenu(skin, tier)));
      }
    if (!ct.rareDropNames.isEmpty()) {
      JLabel gold =
          new JLabel(
              new ImageIcon(
                  app.cs2Screens.scaleCs2Image(
                      app.goldIconImage == null
                          ? app.containerBrowserScreen.createItemPlaceholderImage()
                          : app.goldIconImage,
                      112,
                      72)));
      items.add(
          app.cs2Screens.createCs2Tile(
              "★ Rare Special Item ★", ct.goldDropLabel(), Theme.GOLD, gold, null));
    }
    JScrollPane contents = new JScrollPane(items);
    contents.setOpaque(false);
    contents.getViewport().setOpaque(false);
    contents.setBorder(null);
    contents.setHorizontalScrollBarPolicy(ScrollPaneConstants.HORIZONTAL_SCROLLBAR_NEVER);
    contents.setPreferredSize(new Dimension(0, 280));
    outcomes.add(contents, BorderLayout.CENTER);
    lower.add(outcomes, BorderLayout.CENTER);
    JPanel bottom = app.cs2Screens.cs2Glass(new BorderLayout(20, 0));
    JPanel keyLine = app.cs2Screens.cs2Glass(new FlowLayout(FlowLayout.LEFT, 10, 0));
    if (app.containerInventoryService.requiresOwnedKey(ct)) {
      JLabel keyArt = new JLabel("", SwingConstants.CENTER);
      keyArt.setPreferredSize(new Dimension(90, 50));
      app.cs2Screens.bindCs2SupplyArtwork(ct, true, keyArt, 75, 45);
      keyLine.add(keyArt);
    }
    JLabel required =
        app.cs2Screens.cs2Text(
            app.containerInventoryService.requiresOwnedKey(ct)
                ? "Use " + app.cs2EquipmentScreens.keyName(ct)
                : "No key required",
            17,
            Color.WHITE);
    keyLine.add(required);
    bottom.add(keyLine, BorderLayout.WEST);
    JPanel actions = app.cs2Screens.cs2Glass(new FlowLayout(FlowLayout.RIGHT));
    boolean missing =
        app.containerInventoryService.requiresOwnedKey(ct)
            && app.containerInventoryService.ownedSupplyCount(ct, true) == 0;
    JButton unlock = app.cs2Screens.cs2Button(missing ? "BUY KEY" : "UNLOCK CONTAINER", true, null);
    unlock.setName("cs2UnlockContainer");
    unlock.addActionListener(
        e -> {
          if (app.containerInventoryService.ownedSupplyCount(ct, false) == 0) {
            owner.dispose();
            return;
          }
          if (app.containerInventoryService.requiresOwnedKey(ct)
              && app.containerInventoryService.ownedSupplyCount(ct, true) == 0) {
            app.cs2Screens.showCs2KeyPurchase(ct, owner);
            return;
          }
          unlock.setEnabled(false);
          owner.getRootPane().putClientProperty("unlockControl", unlock);
          app.caseOpeningScreen.openCrateWithAnimation();
        });
    actions.add(unlock);
    actions.add(app.cs2Screens.cs2Button("CLOSE", false, e -> owner.dispose()));
    bottom.add(actions, BorderLayout.EAST);
    lower.add(bottom, BorderLayout.SOUTH);
    root.add(lower, BorderLayout.SOUTH);
    return root;
  }

  void showCs2KeyPurchase(CaseType ct, JDialog owner) {
    JSpinner quantity = new JSpinner(new SpinnerNumberModel(1, 1, 20, 1));
    JPanel form = new JPanel(new GridLayout(0, 1, 8, 8));
    form.add(new JLabel(app.cs2EquipmentScreens.keyName(ct) + " — $2.49 each"));
    form.add(new JLabel("Quantity (1–20)"));
    form.add(quantity);
    JLabel total = new JLabel("Total: $2.49");
    quantity.addChangeListener(
        e ->
            total.setText(
                "Total: $"
                    + hGui.CS2_KEY_PRICE.multiply(
                        BigDecimal.valueOf(((Number) quantity.getValue()).intValue()))));
    form.add(total);
    if (JOptionPane.showConfirmDialog(
            owner, form, "Buy case keys", JOptionPane.OK_CANCEL_OPTION, JOptionPane.PLAIN_MESSAGE)
        != JOptionPane.OK_OPTION) return;
    try {
      quantity.commitEdit();
      app.containerInventoryService.buyOwnedSupplies(
          ct, true, ((Number) quantity.getValue()).intValue());
      app.containerInventoryService.cs2PurchaseChanged();
      owner.setContentPane(app.cs2Screens.createCs2ContainerPanel(ct, owner));
      owner.revalidate();
      owner.repaint();
    } catch (Exception ex) {
      JOptionPane.showMessageDialog(
          owner, ex.getMessage(), "Key purchase", JOptionPane.WARNING_MESSAGE);
    }
  }

  JPanel createCs2MarketContainerCard(CaseType ct) {
    JLabel art = new JLabel("", SwingConstants.CENTER);
    art.setName("caseMarketArt-" + ct.id);
    app.cs2Screens.bindCs2SupplyArtwork(ct, false, art, 210, 145);
    JPanel card = new JPanel(new BorderLayout(0, 10));
    card.setName("caseMarketCard-" + ct.id);
    card.setBackground(Theme.BG_CARD);
    card.setBorder(BorderFactory.createEmptyBorder(14, 14, 14, 14));
    card.setPreferredSize(new Dimension(240, 260));
    JPanel info = new JPanel(new GridLayout(0, 1, 0, 6));
    info.setOpaque(false);
    info.add(app.cs2Screens.cs2Text(ct.name, 14, Theme.TEXT));
    JLabel price =
        app.cs2Screens.cs2Text(
            app.startupArtworkService.caseQuoteLabel(ct)
                + " USD • "
                + (ct.isTerminal ? "Terminal" : ct.isSouvenir ? "Souvenir" : "Case"),
            13,
            Theme.ACCENT_CT);
    price.setName("caseMarketPrice-" + ct.id);
    price.setToolTipText(
        app.caseQuoteDescriptions.getOrDefault(
            ct.id, "CSFloat USD listing quote, not Steam wallet pricing; key not included"));
    info.add(price);
    card.add(info, BorderLayout.NORTH);
    card.add(art);
    JButton buy =
        app.cs2Screens.cs2Button(
            app.startupArtworkService.hasPurchasableCaseQuote(ct)
                ? "BUY  " + app.startupArtworkService.caseQuoteLabel(ct)
                : "QUOTE UNAVAILABLE",
            true,
            e -> app.cs2Screens.buyCs2MarketContainer(ct));
    buy.setName("caseMarketBuy-" + ct.id);
    buy.setEnabled(app.startupArtworkService.hasPurchasableCaseQuote(ct));
    card.add(buy, BorderLayout.SOUTH);
    return card;
  }

  void buyCs2MarketContainer(CaseType ct) {
    final double shownPrice = ct.price;
    JSpinner quantity = new JSpinner(new SpinnerNumberModel(1, 1, 100, 1));
    JPanel form = new JPanel(new GridLayout(0, 1, 0, 8));
    form.add(
        new JLabel(
            ct.name
                + " • "
                + app.startupArtworkService.caseQuoteLabel(ct)
                + " USD each (key not included)"));
    form.add(quantity);
    JLabel total = new JLabel("Total: " + app.startupArtworkService.caseQuoteLabel(ct));
    quantity.addChangeListener(
        e ->
            total.setText(
                "Total: $"
                    + app.coreUtilities
                        .money(shownPrice)
                        .multiply(BigDecimal.valueOf(((Number) quantity.getValue()).intValue()))));
    form.add(total);
    if (JOptionPane.showConfirmDialog(
            app, form, "Buy container", JOptionPane.OK_CANCEL_OPTION, JOptionPane.PLAIN_MESSAGE)
        != JOptionPane.OK_OPTION) return;
    try {
      quantity.commitEdit();
      if (Double.compare(shownPrice, ct.price) != 0)
        throw new IllegalArgumentException(
            "The market quote changed. Reopen the purchase to confirm the new total.");
      app.containerInventoryService.buyOwnedSupplies(
          ct, false, ((Number) quantity.getValue()).intValue());
      app.containerInventoryService.cs2PurchaseChanged();
    } catch (Exception ex) {
      JOptionPane.showMessageDialog(
          app, ex.getMessage(), "Container purchase", JOptionPane.WARNING_MESSAGE);
    }
  }
}
