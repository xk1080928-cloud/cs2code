package blahblah;

import blahblah.hGui.*;
import java.awt.*;
import java.awt.event.*;
import java.util.ArrayList;
import javax.swing.*;

/** Trade Cards: focused feature implementation. */
final class TradeCards {
  private final hGui app;

  TradeCards(hGui app) {
    this.app = app;
  }

  String tradeType(String type) {
    String[] lines;

    if (type.equals("BUYING")) {
      lines =
          new String[] {
            "Hey! I’ve been eyeing that skin - how about some cash for it?",
            "I like your taste in skins. Want to sell one for this price?",
            "That skin would fit my loadout perfectly. Care to make a deal?",
            "You seem like a good trader - I’ll pay well for that item.",
            "I’ve got money ready. Interested in selling?",
            "Been watching the market all day - your skin caught my eye.",
            "I’ll give you a clean offer, no lowballing.",
            "That piece is underrated. I’ll take it off your hands.",
            "Cash talks - and I’m talking right now.",
            "You won’t find a better buyer today.",
            "I’ve been hunting this exact skin for a while.",
            "Let’s skip the back-and-forth and make this quick.",
            "I don’t mind paying for quality.",
            "That skin won’t sit long - especially with my offer.",
            "Sell it now and walk away happy."
          };

    } else if (type.equals("SELLING")) {
      lines =
          new String[] {
            "Hey! I picked up some skins - wanna buy them off me?",
            "Got a few skins you might like. Interested for this price?",
            "I know quality when I see it. These skins could be yours.",
            "Looking to offload some skins. Think you can afford them?",
            "These skins deserve a good owner - want them?",
            "Fresh pulls, solid floats. Take a look.",
            "Market’s dry - I’ve got the good stuff.",
            "You won’t see these listed cheap very often.",
            "I’m moving inventory fast. Don’t sleep on this.",
            "Clean skins, fair price. Simple deal.",
            "Hard to find skins, easy decision.",
            "These won’t last long at this price.",
            "I could list them, but I’d rather deal direct.",
            "Solid value if you know the market.",
            "Perfect pickup if you’re upgrading your loadout."
          };

    } else if (type.equals("TRADING")) {
      lines =
          new String[] {
            "How about a straight trade? No money involved.",
            "I’ve got something you might want - let’s swap.",
            "You trade smart, I trade smart. Fair exchange?",
            "Skin for skin. Clean and simple.",
            "Let’s trade items - win-win.",
            "No cash needed, just a clean swap.",
            "I’ll match value - no funny business.",
            "Both sides walk away happy.",
            "Different skins, same worth. Interested?",
            "This trade makes sense if you think about it.",
            "Keeps both our inventories balanced.",
            "No fees, no waiting - just trade.",
            "Swaps like this don’t show up often.",
            "Equal value, different style.",
            "Sometimes trading beats selling."
          };

    } else {
      lines =
          new String[] {
            "Let’s make a deal - items and cash involved.",
            "A bit of money, a bit of skins. Fair trade?",
            "This one’s a mixed offer, but I think it’s solid.",
            "Not a simple trade, but a profitable one.",
            "Hear me out - this deal could be worth it.",
            "Cash plus skins usually gets things done.",
            "I’m flexible - let’s meet in the middle.",
            "Not everything has to be one-sided.",
            "Value lines up if you look closely.",
            "This deal’s better than it looks.",
            "Balances out nicely if you do the math.",
            "A little creativity makes this work.",
            "Not a boring deal, but a smart one.",
            "There’s upside here if you play it right.",
            "Mixed trades separate good traders from great ones."
          };
    }

    return lines[hGui.random.nextInt(lines.length)];
  }

  JPanel createTradeSidePanel(
      ArrayList<InventoryItem> items, double money, Image avatar, String title, boolean isNPC) {
    JPanel panel = new JPanel(new BorderLayout());
    panel.setBackground(new Color(35, 35, 40));
    panel.setBorder(BorderFactory.createLineBorder(Color.GRAY, 2));

    JPanel titlePanel = new JPanel(new FlowLayout(FlowLayout.LEFT));
    titlePanel.setBackground(new Color(35, 35, 40));
    titlePanel.add(new JLabel(new ImageIcon(HighQualityImages.fit(avatar, 32, 32))));
    JLabel titleLabel = new JLabel(title);
    titleLabel.setFont(new Font("Arial", Font.BOLD, 14));
    titleLabel.setForeground(Color.WHITE);
    titlePanel.add(titleLabel);
    panel.add(titlePanel, BorderLayout.NORTH);

    JPanel itemsPanel = new JPanel();
    itemsPanel.setLayout(new BoxLayout(itemsPanel, BoxLayout.Y_AXIS));
    itemsPanel.setBackground(new Color(35, 35, 40));
    itemsPanel.setBorder(BorderFactory.createEmptyBorder(10, 10, 10, 10));

    if (money > 0) {
      JPanel moneyPanel = new JPanel(new FlowLayout(FlowLayout.LEFT));
      moneyPanel.setBackground(new Color(50, 50, 55));
      moneyPanel.setBorder(BorderFactory.createLineBorder(Color.YELLOW, 2));
      moneyPanel.setMaximumSize(new Dimension(Integer.MAX_VALUE, 80));

      JLabel moneyIcon = new JLabel("$");
      moneyIcon.setFont(new Font("Arial", Font.BOLD, 48));
      moneyIcon.setForeground(Color.YELLOW);
      moneyPanel.add(moneyIcon);

      JLabel moneyLabel = new JLabel("$" + String.format("%.2f", money));
      moneyLabel.setFont(new Font("Arial", Font.BOLD, 24));
      moneyLabel.setForeground(Color.YELLOW);
      moneyPanel.add(moneyLabel);

      itemsPanel.add(moneyPanel);
      itemsPanel.add(Box.createRigidArea(new Dimension(0, 5)));
    }

    for (InventoryItem item : items) {
      JPanel itemCard = new JPanel(new BorderLayout());
      itemCard.setBackground(new Color(50, 50, 55));

      if (item.blueGemTier != null) {
        itemCard.setBorder(BorderFactory.createLineBorder(Color.CYAN, 3));
      } else {
        itemCard.setBorder(
            BorderFactory.createLineBorder(
                app.itemInspectionScreen.getRarityColor(item.rarity), 2));
      }

      itemCard.setMaximumSize(new Dimension(Integer.MAX_VALUE, 100));
      itemCard.setPreferredSize(new Dimension(350, 100));

      JLabel tradeArtwork = new JLabel("", SwingConstants.CENTER);
      tradeArtwork.setPreferredSize(new Dimension(100, 75));
      app.artworkService.getSkinImageFromName(item.name, item.condition, tradeArtwork, 100, 75);
      itemCard.add(tradeArtwork, BorderLayout.WEST);

      JPanel infoPanel = new JPanel(new GridLayout(4, 1));
      infoPanel.setBackground(new Color(50, 50, 55));
      infoPanel.setBorder(BorderFactory.createEmptyBorder(5, 10, 5, 10));

      JLabel nameLabel;
      if (item.isStattrak) {
        nameLabel = new JLabel("<html> StatTrak " + item.name + "</html>");
        nameLabel.setFont(new Font("Arial", Font.BOLD, 11));
        nameLabel.setForeground(new Color(255, 153, 51));
      } else {
        nameLabel = new JLabel("<html>" + item.name + "</html>");
        nameLabel.setFont(new Font("Arial", Font.BOLD, 11));
        nameLabel.setForeground(Color.WHITE);
      }

      JLabel condLabel =
          new JLabel(
              app.itemMetadataService.shouldShowFloatForItem(item.name, item.rarity)
                  ? item.condition + " | Float: " + String.format("%.4f", item.itemFloat)
                  : "Agent");
      condLabel.setFont(new Font("Arial", Font.PLAIN, 10));
      condLabel.setForeground(Color.LIGHT_GRAY);

      JLabel priceLabel = new JLabel("$" + item.price);
      priceLabel.setFont(new Font("Arial", Font.BOLD, 12));
      priceLabel.setForeground(Color.YELLOW);

      JLabel specialLabel;
      if (item.blueGemTier != null) {
        specialLabel = new JLabel(item.blueGemTier + " (Fixed Price)");
        specialLabel.setFont(new Font("Arial", Font.BOLD, 10));
        specialLabel.setForeground(Color.CYAN);
      } else {
        specialLabel = new JLabel("Pattern: #" + item.patternID);
        specialLabel.setFont(new Font("Arial", Font.PLAIN, 10));
        specialLabel.setForeground(Color.LIGHT_GRAY);
      }

      infoPanel.add(nameLabel);
      infoPanel.add(condLabel);
      infoPanel.add(priceLabel);
      infoPanel.add(specialLabel);

      itemCard.add(infoPanel, BorderLayout.CENTER);
      itemsPanel.add(itemCard);
      itemsPanel.add(Box.createRigidArea(new Dimension(0, 5)));
    }

    JScrollPane scroll = new JScrollPane(itemsPanel);
    scroll.setBackground(new Color(35, 35, 40));
    scroll.getVerticalScrollBar().setUnitIncrement(16);
    scroll.setBorder(null);
    panel.add(scroll, BorderLayout.CENTER);

    if (money == 0 && !items.isEmpty()) {
      double totalValue = items.stream().mapToDouble(it -> it.price.doubleValue()).sum();
      JPanel valuePanel = new JPanel(new FlowLayout(FlowLayout.CENTER));
      valuePanel.setBackground(new Color(35, 35, 40));
      JLabel valueLabel = new JLabel("Total: $" + String.format("%.2f", totalValue));
      valueLabel.setFont(new Font("Arial", Font.BOLD, 14));
      valueLabel.setForeground(Color.CYAN);
      valuePanel.add(valueLabel);
      panel.add(valuePanel, BorderLayout.SOUTH);
    }
    return panel;
  }

  void optimizeScrollPane(JScrollPane scroll) {
    scroll.getVerticalScrollBar().setUnitIncrement(20);
    scroll.getVerticalScrollBar().setBlockIncrement(100);

    scroll.getViewport().setScrollMode(JViewport.SIMPLE_SCROLL_MODE);
  }
}
