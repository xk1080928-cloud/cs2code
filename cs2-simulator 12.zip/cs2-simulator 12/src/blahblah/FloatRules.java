package blahblah;

import blahblah.hGui.*;
import java.awt.*;
import java.awt.event.*;
import javax.swing.*;

/** Float Rules: focused feature implementation. */
final class FloatRules {
  private final hGui app;

  FloatRules(hGui app) {
    this.app = app;
  }

  public void resetCrate() {
    app.openCrateButton.setEnabled(
        app.balance >= app.developerTools.getCaseOpeningCost(app.currentCase));
    app.openCrateButton.setVisible(true);
    app.closeCrateButton.setVisible(false);
    app.autoOpenButton.setVisible(false);
    app.autoOpenButton.setEnabled(true);
    app.skinImage = null;
    app.crateImage = app.containerBrowserScreen.getContainerImage(app.currentCase);
    app.containerBrowserScreen.updateCrateImageDisplay();
    app.rarityLabel.setText("");
    app.nameLabel.setText("");
    app.priceLabel.setText("");
    app.floatLabel.setText("");
    app.conditionLabel.setText("");
    app.patternId.setText("");
    app.collectionLabel.setText("");
    app.lowFloatLabel.setVisible(false);
    app.developerTools.layoutCaseOpeningControls();
    app.repaint();
  }

  double applyFloatLimits(String skinName, double value) {
    if (app.floatRules.isVanillaKnife(skinName)) return 0.0;
    FloatRange r = app.catalogParsingService.findFloatRange(skinName);
    if (r == null) return value;
    double min = (r.min == null) ? 0.00 : r.min;
    double max = (r.max == null) ? 1.00 : r.max;
    double normalized = Math.max(0.0, Math.min(1.0, value));
    return min + normalized * (max - min);
  }

  boolean isVanillaKnife(String skinName) {
    return skinName != null
        && "Knife".equals(app.itemMetadataService.getSkinRarity(skinName))
        && skinName.trim().endsWith("| Vanilla");
  }

  boolean hasNoFloatWear(String skinName) {
    return app.exchangeStockService.exchangeContainer(skinName) != null
        || app.floatRules.isVanillaKnife(skinName)
        || app.itemMetadataService.isAgentSkin(skinName);
  }

  String getConditionForFloat(String skinName, double itemFloat) {
    if (app.floatRules.hasNoFloatWear(skinName)) return "Normal";
    return MarketStockService.wearConditionForFloat(itemFloat);
  }

  String[] getAvailableConditions(String skinName) {
    if (app.exchangeStockService.exchangeContainer(skinName) != null)
      return new String[] {"Normal"};
    String[] cached = app.availableConditionsCache.get(skinName);
    if (cached != null) return cached;
    if (app.itemMetadataService.isAgentSkin(skinName)) {
      String[] res = new String[] {"Normal"};
      app.availableConditionsCache.put(skinName, res);
      return res;
    }
    if (app.floatRules.isVanillaKnife(skinName)) {
      String[] res = new String[] {"Normal"};
      app.availableConditionsCache.put(skinName, res);
      return res;
    }
    if (skinName.contains("Gloves") || skinName.contains("Hand Wraps")) {
      String[] res =
          new String[] {
            "Factory New", "Minimal Wear", "Field-Tested", "Well-Worn", "Battle-Scarred"
          };
      app.availableConditionsCache.put(skinName, res);
      return res;
    }

    FloatRange fr = app.catalogParsingService.findFloatRange(skinName);

    if (fr == null) {
      return new String[] {
        "Factory New", "Minimal Wear", "Field-Tested", "Well-Worn", "Battle-Scarred"
      };
    }

    double min = (fr.min != null) ? fr.min : 0.0;
    double max = (fr.max != null) ? fr.max : 1.0;

    java.util.ArrayList<String> conditions = new java.util.ArrayList<>();

    if (min < 0.07 && max > 0.00) conditions.add("Factory New");

    if (min < 0.15 && max > 0.07) conditions.add("Minimal Wear");

    if (min < 0.38 && max > 0.15) conditions.add("Field-Tested");

    if (min < 0.45 && max > 0.38) conditions.add("Well-Worn");

    if (max > 0.45) conditions.add("Battle-Scarred");

    String[] result = conditions.toArray(new String[0]);
    if (app.availableConditionsCache.size() < 500)
      app.availableConditionsCache.put(skinName, result);
    return result;
  }
}
