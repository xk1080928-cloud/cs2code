package blahblah;

import blahblah.hGui.*;
import java.awt.*;
import java.awt.event.*;
import java.util.ArrayList;
import javax.swing.*;

/** Offer Relay And Velvet Screens: focused feature implementation. */
final class OfferRelayAndVelvetScreens {
  private final hGui app;

  OfferRelayAndVelvetScreens(hGui app) {
    this.app = app;
  }

  void showMarketplaceOfferWindowRelayFeed(
      String skinName, String conditionToken, MarketplaceOfferAggregate offer, JFrame parent) {
    JFrame frame =
        app.offerNeonAndMirageScreens.createMarketplaceFrame(
            offer, skinName, conditionToken, parent, new Color(6, 10, 6));
    frame.add(
        app.offerHeroAndSellerScreens.createOfferHeader(
            offer.marketplaceName + " Relay Feed",
            skinName + "  ·  live transaction feed",
            offer,
            "● LIVE"),
        BorderLayout.NORTH);

    ArrayList<MarketListing> sorted = app.marketOfferService.getSortedOfferListings(offer);

    // Ticker bar
    JPanel ticker = new JPanel(new BorderLayout());
    ticker.setBackground(new Color(8, 18, 8));
    ticker.setBorder(
        BorderFactory.createCompoundBorder(
            BorderFactory.createMatteBorder(0, 0, 1, 0, new Color(0, 160, 0)),
            BorderFactory.createEmptyBorder(6, 14, 6, 14)));
    double lo = sorted.stream().mapToDouble(l -> l.getPrice()).min().orElse(0);
    double hi = sorted.stream().mapToDouble(l -> l.getPrice()).max().orElse(0);
    JLabel tickerTxt =
        new JLabel(
            "FEED  ●  BEST: $"
                + String.format("%.2f", lo)
                + "  ●  WORST: $"
                + String.format("%.2f", hi)
                + "  ●  DEPTH: "
                + sorted.size()
                + " sellers  ●  MARKET: "
                + offer.marketplaceName);
    tickerTxt.setFont(new Font("Consolas", Font.PLAIN, 11));
    tickerTxt.setForeground(new Color(0, 200, 0));
    ticker.add(tickerTxt, BorderLayout.CENTER);

    JPanel feed = new JPanel();
    feed.setLayout(new BoxLayout(feed, BoxLayout.Y_AXIS));
    feed.setBackground(new Color(6, 10, 6));
    feed.setBorder(BorderFactory.createEmptyBorder(8, 14, 14, 14));

    int seq = 1000 + sorted.size();
    for (MarketListing listing : sorted) {
      feed.add(app.offerRelayAndVelvetScreens.createRelayFeedRow(seq--, listing, offer, frame));
    }

    JScrollPane scroll = new JScrollPane(feed);
    scroll.setBorder(null);
    scroll.getViewport().setBackground(new Color(6, 10, 6));
    scroll.getVerticalScrollBar().setUnitIncrement(20);

    JPanel center = new JPanel(new BorderLayout());
    center.setBackground(new Color(6, 10, 6));
    center.add(ticker, BorderLayout.NORTH);
    center.add(scroll, BorderLayout.CENTER);
    frame.add(center, BorderLayout.CENTER);
    frame.setVisible(true);
  }

  JPanel createRelayFeedRow(
      int seq, MarketListing listing, MarketplaceOfferAggregate offer, JFrame parent) {
    JPanel row = new JPanel(new BorderLayout(10, 0));
    row.setBackground(new Color(8, 14, 8));
    row.setMaximumSize(new Dimension(Integer.MAX_VALUE, 36));
    row.setBorder(
        BorderFactory.createCompoundBorder(
            BorderFactory.createMatteBorder(0, 0, 1, 0, new Color(20, 40, 20)),
            BorderFactory.createEmptyBorder(6, 10, 6, 10)));

    JLabel seqLbl = new JLabel("[" + seq + "]");
    seqLbl.setFont(new Font("Consolas", Font.PLAIN, 10));
    seqLbl.setForeground(new Color(0, 100, 0));
    seqLbl.setPreferredSize(new Dimension(62, 0));

    JLabel info =
        new JLabel(
            "SELLER="
                + (listing.sellerName != null ? listing.sellerName : "null")
                + (app.itemMetadataService.isAgentSkin(listing.item.name)
                    ? ""
                    : ("  FLOAT="
                        + String.format("%.6f", listing.item.itemFloat)
                        + "  PAT="
                        + app.marketOfferService.formatMarketPatternText(listing))));
    info.setFont(new Font("Consolas", Font.PLAIN, 12));
    info.setForeground(new Color(0, 200, 0));

    JButton btn =
        app.offerNeonAndMirageScreens.createMarketplaceActionButton(
            listing, offer, parent, "$" + String.format("%.2f", listing.getPrice()) + " →");
    btn.setBackground(new Color(0, 40, 0));
    btn.setForeground(new Color(0, 220, 0));
    btn.setFont(new Font("Consolas", Font.BOLD, 12));
    btn.setBorder(BorderFactory.createLineBorder(new Color(0, 120, 0), 1));
    btn.setPreferredSize(new Dimension(120, 28));

    row.add(seqLbl, BorderLayout.WEST);
    row.add(info, BorderLayout.CENTER);
    row.add(btn, BorderLayout.EAST);
    return row;
  }

  void showMarketplaceOfferWindowVelvetGallery(
      String skinName, String conditionToken, MarketplaceOfferAggregate offer, JFrame parent) {
    JFrame frame =
        app.offerNeonAndMirageScreens.createMarketplaceFrame(
            offer, skinName, conditionToken, parent, new Color(26, 10, 20));
    frame.add(
        app.offerHeroAndSellerScreens.createOfferHeader(
            offer.marketplaceName + " Velvet Gallery",
            conditionToken + "  ·  curated offer salon",
            offer,
            "✦ VELVET SELECT"),
        BorderLayout.NORTH);

    JPanel gallery = new JPanel(new GridLayout(0, 5, 12, 12));
    gallery.setBackground(new Color(26, 10, 20));
    gallery.setBorder(BorderFactory.createEmptyBorder(18, 18, 18, 18));
    for (MarketListing listing : app.marketOfferService.getSortedOfferListings(offer)) {
      gallery.add(app.offerRelayAndVelvetScreens.createVelvetCard(listing, offer, frame));
    }

    JScrollPane scroll = new JScrollPane(gallery);
    scroll.setBorder(null);
    scroll.getViewport().setBackground(new Color(26, 10, 20));
    scroll.getVerticalScrollBar().setUnitIncrement(20);
    frame.add(scroll, BorderLayout.CENTER);
    frame.setVisible(true);
  }

  JPanel createVelvetCard(MarketListing listing, MarketplaceOfferAggregate offer, JFrame parent) {
    JPanel card = new JPanel(new BorderLayout(0, 0));
    card.setBackground(new Color(38, 16, 30));
    card.setBorder(BorderFactory.createLineBorder(new Color(100, 40, 80), 1));

    // Gradient-feel top band
    JPanel topBand = new JPanel(new BorderLayout());
    topBand.setBackground(new Color(60, 20, 46));
    topBand.setBorder(BorderFactory.createEmptyBorder(10, 14, 10, 14));
    JLabel sellerLbl =
        new JLabel("✦  " + (listing.sellerName != null ? listing.sellerName : "Seller"));
    sellerLbl.setFont(new Font("Arial", Font.BOLD, 14));
    sellerLbl.setForeground(new Color(240, 200, 160));
    topBand.add(sellerLbl, BorderLayout.CENTER);

    // Card body
    JPanel body = new JPanel(new GridLayout(3, 1, 0, 6));
    body.setOpaque(false);
    body.setBorder(BorderFactory.createEmptyBorder(12, 14, 12, 14));

    boolean isAgentVelvet = app.itemMetadataService.isAgentSkin(listing.item.name);
    JLabel floatLbl =
        new JLabel(
            isAgentVelvet ? "Agent" : ("Float   " + String.format("%.6f", listing.item.itemFloat)));
    floatLbl.setFont(new Font("Consolas", Font.PLAIN, 11));
    floatLbl.setForeground(new Color(180, 130, 160));

    JLabel patternLbl =
        new JLabel(
            isAgentVelvet
                ? ""
                : ("Pattern  " + app.marketOfferService.formatMarketPatternText(listing)));
    patternLbl.setFont(new Font("Consolas", Font.PLAIN, 11));
    patternLbl.setForeground(
        app.marketOfferService.getMarketPatternColor(listing, new Color(160, 110, 140)));

    JLabel price = new JLabel("$" + String.format("%.2f", listing.getPrice()));
    price.setFont(new Font("Consolas", Font.BOLD, 22));
    price.setForeground(new Color(220, 185, 80));

    body.add(floatLbl);
    body.add(patternLbl);
    body.add(price);

    // Footer buy
    JPanel footer = new JPanel(new BorderLayout());
    footer.setBackground(new Color(50, 20, 40));
    footer.setBorder(BorderFactory.createEmptyBorder(8, 14, 8, 14));
    JButton btn =
        app.offerNeonAndMirageScreens.createMarketplaceActionButton(
            listing, offer, parent, "ACQUIRE  →");
    btn.setBackground(new Color(80, 30, 60));
    btn.setForeground(new Color(220, 185, 80));
    btn.setFont(new Font("Arial", Font.BOLD, 12));
    footer.add(btn, BorderLayout.CENTER);

    card.add(topBand, BorderLayout.NORTH);
    card.add(body, BorderLayout.CENTER);
    card.add(footer, BorderLayout.SOUTH);
    return card;
  }
}
