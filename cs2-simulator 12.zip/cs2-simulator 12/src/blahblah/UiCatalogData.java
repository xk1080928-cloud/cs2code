package blahblah;

import blahblah.hGui.*;
import java.awt.*;
import java.awt.event.*;
import java.io.IOException;
import java.util.LinkedHashMap;
import java.util.Map;
import java.util.prefs.Preferences;
import javax.swing.*;

/** Ui Catalog Data: focused feature implementation. */
final class UiCatalogData {
  private final hGui app;

  UiCatalogData(hGui app) {
    this.app = app;
  }

  static Map<String, String[]> createCs2KeyCatalog() {
    Map<String, String[]> map = new LinkedHashMap<>();
    map.put(
        "CS:GO Weapon Case",
        new String[] {
          "CS:GO Case Key",
          "https://community.akamai.steamstatic.com/economy/image/i0CoZ81Ui0m-9KwlBY1L_18myuGuq1wfhWSaZgMttyVfPaERSR0Wqmu7LAocGJG51EejH-HRwtquO0SU5EVwy4zx8xe1EU_3yZfj_HEM7POoOfI0IvOQXzWRkesg5rc_HyzqlkR_5GrRw92obzvJOU2RiCYH"
        });
    map.put(
        "Operation Bravo Case",
        new String[] {
          "CS:GO Case Key",
          "https://community.akamai.steamstatic.com/economy/image/i0CoZ81Ui0m-9KwlBY1L_18myuGuq1wfhWSaZgMttyVfPaERSR0Wqmu7LAocGJG51EejH-HRwtquO0SU5EVwy4zx8xe1EU_3yZfj_HEM7POoOfI0IvOQXzWRkesg5rc_HyzqlkR_5GrRw92obzvJOU2RiCYH"
        });
    map.put(
        "CS:GO Weapon Case 2",
        new String[] {
          "CS:GO Case Key",
          "https://community.akamai.steamstatic.com/economy/image/i0CoZ81Ui0m-9KwlBY1L_18myuGuq1wfhWSaZgMttyVfPaERSR0Wqmu7LAocGJG51EejH-HRwtquO0SU5EVwy4zx8xe1EU_3yZfj_HEM7POoOfI0IvOQXzWRkesg5rc_HyzqlkR_5GrRw92obzvJOU2RiCYH"
        });
    map.put(
        "CS:GO Weapon Case 3",
        new String[] {
          "CS:GO Case Key",
          "https://community.akamai.steamstatic.com/economy/image/i0CoZ81Ui0m-9KwlBY1L_18myuGuq1wfhWSaZgMttyVfPaERSR0Wqmu7LAocGJG51EejH-HRwtquO0SU5EVwy4zx8xe1EU_3yZfj_HEM7POoOfI0IvOQXzWRkesg5rc_HyzqlkR_5GrRw92obzvJOU2RiCYH"
        });
    map.put(
        "eSports 2013 Case",
        new String[] {
          "eSports Key",
          "https://community.akamai.steamstatic.com/economy/image/i0CoZ81Ui0m-9KwlBY1L_18myuGuq1wfhWSaZgMttyVfPaERSR0Wqmu7LAocGJG51EejH-HRwtquO0SU5EVwy4zx82b0URjyl5fswnMVufGrbPU5JaDKCDaUkOgktrQ7Tn_nzR905DnXztr_InrBbwIhA8NzQflK7EeRo_iSDw"
        });
    map.put(
        "eSports 2013 Winter Case",
        new String[] {
          "eSports Key",
          "https://community.akamai.steamstatic.com/economy/image/i0CoZ81Ui0m-9KwlBY1L_18myuGuq1wfhWSaZgMttyVfPaERSR0Wqmu7LAocGJG51EejH-HRwtquO0SU5EVwy4zx82b0URjyl5fswnMVufGrbPU5JaDKCDaUkOgktrQ7Tn_nzR905DnXztr_InrBbwIhA8NzQflK7EeRo_iSDw"
        });
    map.put(
        "eSports 2014 Summer Case",
        new String[] {
          "eSports Key",
          "https://community.akamai.steamstatic.com/economy/image/i0CoZ81Ui0m-9KwlBY1L_18myuGuq1wfhWSaZgMttyVfPaERSR0Wqmu7LAocGJG51EejH-HRwtquO0SU5EVwy4zx82b0URjyl5fswnMVufGrbPU5JaDKCDaUkOgktrQ7Tn_nzR905DnXztr_InrBbwIhA8NzQflK7EeRo_iSDw"
        });
    map.put(
        "Sticker Capsule",
        new String[] {
          "CS:GO Capsule Key",
          "https://community.akamai.steamstatic.com/economy/image/i0CoZ81Ui0m-9KwlBY1L_18myuGuq1wfhWSaZgMttyVfPaERSR0Wqmu7LAocGJG51EejH-XAysmqMGmo5kR04ILL4Vz-D0zwysW2-CAC6aT4PvQ_IaiVWjDCwOpw4uBvTn_jxU9w4m3QzNyucSiJLlh3DeKCsoM"
        });
    map.put(
        "Sticker Capsule 2",
        new String[] {
          "CS:GO Capsule Key",
          "https://community.akamai.steamstatic.com/economy/image/i0CoZ81Ui0m-9KwlBY1L_18myuGuq1wfhWSaZgMttyVfPaERSR0Wqmu7LAocGJG51EejH-XAysmqMGmo5kR04ILL4Vz-D0zwysW2-CAC6aT4PvQ_IaiVWjDCwOpw4uBvTn_jxU9w4m3QzNyucSiJLlh3DeKCsoM"
        });
    map.put(
        "Winter Offensive Weapon Case",
        new String[] {
          "Winter Offensive Case Key",
          "https://community.akamai.steamstatic.com/economy/image/i0CoZ81Ui0m-9KwlBY1L_18myuGuq1wfhWSaZgMttyVfPaERSR0Wqmu7LAocGJG51EejH_XGwt6kCnCS_Gl2-4r5_1fuVQTOz9jmrHQDu6H3bv0-cqfECj-SkrYg6bg4HyjgkBhx52SAn9upcnLCOlQkFNIuEhuT0jjg"
        });
    map.put(
        "Operation Phoenix Weapon Case",
        new String[] {
          "Operation Phoenix Case Key",
          "https://community.akamai.steamstatic.com/economy/image/i0CoZ81Ui0m-9KwlBY1L_18myuGuq1wfhWSaZgMttyVfPaERSR0Wqmu7LAocGJG51EejH_XGwt6kCnCS_Gl2-4r5_1fuVQTOzNjkrCBZuquoO6JpeaaVWjTDk7ch6bcwHyrjzRkk4GzRnNitJX-falJ1FNIuEtlTaEjz"
        });
    map.put(
        "Community Sticker Capsule 1",
        new String[] {
          "Community Sticker Capsule 1 Key",
          "https://community.akamai.steamstatic.com/economy/image/i0CoZ81Ui0m-9KwlBY1L_18myuGuq1wfhWSaZgMttyVfPaERSR0Wqmu7LAocGJG51EejH-XAysmqMGmo5kR04ILL4Vz-fh7-k5v18ytP9qL_JvU-cKGSXTXFk7Zw4uc6F3GxzE4h4znXyY6vIiqVbQMnAsAmTO4PtBmm0oqwRC691G8"
        });
    map.put(
        "Huntsman Weapon Case",
        new String[] {
          "Huntsman Case Key",
          "https://community.akamai.steamstatic.com/economy/image/i0CoZ81Ui0m-9KwlBY1L_18myuGuq1wfhWSaZgMttyVfPaERSR0Wqmu7LAocGJG51EejH_XGwt6kCnCS_Gl2-4r5_1fuVQTOzdizqnAPuPD2Pvc5JanKDGPHkbgnteU-Gizql09-6z6HytyoI3mTPFNyFNIuEuluvl-B"
        });
    map.put(
        "Operation Breakout Weapon Case",
        new String[] {
          "Operation Breakout Case Key",
          "https://community.akamai.steamstatic.com/economy/image/i0CoZ81Ui0m-9KwlBY1L_18myuGuq1wfhWSaZgMttyVfPaERSR0Wqmu7LAocGJG51EejH_XGwt6kCnCS_Gl2-4r5_1fuVQTOyti5qnQM7KT9Ovc-JKjKVjKTxb4v4LM6Hyixxx8hsm_cm4qpdC7EOlUgFNIuEnH1Y6Cs"
        });
    map.put(
        "Operation Vanguard Weapon Case",
        new String[] {
          "Operation Vanguard Case Key",
          "https://community.akamai.steamstatic.com/economy/image/i0CoZ81Ui0m-9KwlBY1L_18myuGuq1wfhWSaZgMttyVfPaERSR0Wqmu7LAocGJG51EejH_XGwt6kCnCS_Gl2-4r5_1fuVQTOy9jh-3devaT3Pf06dfbDWWPFxOh0trE7Syzqx0pztmSHy9-tcC3Bb1BzFNIuEovaMLzT"
        });
    map.put(
        "Chroma Case",
        new String[] {
          "Chroma Case Key",
          "https://community.akamai.steamstatic.com/economy/image/i0CoZ81Ui0m-9KwlBY1L_18myuGuq1wfhWSaZgMttyVfPaERSR0Wqmu7LAocGJG51EejH_XGwt6kCnCS_Gl2-4r5_1fuVQTOyNjmrHAJvKKrbKduI6DGXGSRmbcm6eRoHHmxlkp25WqBzYugIi2TawEgFNIuEmzks21O"
        });
    map.put(
        "Chroma 2 Case",
        new String[] {
          "Chroma 2 Case Key",
          "https://community.akamai.steamstatic.com/economy/image/i0CoZ81Ui0m-9KwlBY1L_18myuGuq1wfhWSaZgMttyVfPaERSR0Wqmu7LAocGJG51EejH_XGwt6kCnCS_Gl2-4r5_1fuVQTOydjjriNfv_CoP6U_cKTBWmLGlewvteJoFnixkUR36z7Vytv9dC7DbVBzFNIuEiI2cace"
        });
    map.put(
        "Falchion Case",
        new String[] {
          "Falchion Case Key",
          "https://community.akamai.steamstatic.com/economy/image/i0CoZ81Ui0m-9KwlBY1L_18myuGuq1wfhWSaZgMttyVfPaERSR0Wqmu7LAocGJG51EejH_XGwt6kCnCS_Gl2-4r5_1fuVQTOxtiy-3oL7KX8OP1vJKDLWzTDmbsl4rdtGyjlwkx1tmnVzdahcCqQaVdxFNIuEsgFjBec"
        });
    map.put(
        "Shadow Case",
        new String[] {
          "Shadow Case Key",
          "https://community.akamai.steamstatic.com/economy/image/i0CoZ81Ui0m-9KwlBY1L_18myuGuq1wfhWSaZgMttyVfPaERSR0Wqmu7LAocGJG51EejH_XGwt6kCnCS_Gl2-4r5_1fuVQTOx9jjpHIDuqD_OfQ1I6WQCD7Jw-p15bA_HSrllkQlsmWBztmsc3LGaFclFNIuEgBJHmEi"
        });
    map.put(
        "Revolver Case",
        new String[] {
          "Revolver Case Key",
          "https://community.akamai.steamstatic.com/economy/image/i0CoZ81Ui0m-9KwlBY1L_18myuGuq1wfhWSaZgMttyVfPaERSR0Wqmu7LAocGJG51EejH_XGwt6kCnCS_Gl2-4r5_1fuVQTOz8auqSYKu6uqMPNvcaKRXDHJxbkv4bI_HSzhwE9-sD-Dm4n9c3KSOAdzW4wwG7Bmrkl-Lg"
        });
    map.put(
        "Chroma 3 Case",
        new String[] {
          "Chroma 3 Case Key",
          "https://community.akamai.steamstatic.com/economy/image/i0CoZ81Ui0m-9KwlBY1L_18myuGuq1wfhWSaZgMttyVfPaERSR0Wqmu7LAocGJG51EejH_XGwt6kCnCS_Gl2-4r5_1fuVQTOz8SupXtev6D4Ovc9dajDC2PEw7d3tLZsGX3mzE1242iBnNytdn3DaAEhDowwG7A3Nq-aQg"
        });
    map.put(
        "Gamma Case",
        new String[] {
          "Gamma Case Key",
          "https://community.akamai.steamstatic.com/economy/image/i0CoZ81Ui0m-9KwlBY1L_18myuGuq1wfhWSaZgMttyVfPaERSR0Wqmu7LAocGJG51EejH_XGwt6kCnCS_Gl2-4r5_1fuVQTOz8WuqiYJu_SqOqE6JKbGCzfDlewisrI8S3_ilhki422GzYv_InuVa1cmDIwwG7BeWz5bbg"
        });
    map.put(
        "Gamma 2 Case",
        new String[] {
          "Gamma 2 Case Key",
          "https://community.akamai.steamstatic.com/economy/image/i0CoZ81Ui0m-9KwlBY1L_18myuGuq1wfhWSaZgMttyVfPaERSR0Wqmu7LAocGJG51EejH_XGwt6kCnCS_Gly9Yr562a1DxipzJDm_idaufCrOvY0JKCXXzHDxbYi57M8TCq2kUh_5DnXyI2vd32JLlh34_DxdDM"
        });
    map.put(
        "Glove Case",
        new String[] {
          "Glove Case Key",
          "https://community.akamai.steamstatic.com/economy/image/i0CoZ81Ui0m-9KwlBY1L_18myuGuq1wfhWSaZgMttyVfPaERSR0Wqmu7LAocGJG51EejH_XGwt6kCnCS_Gl2-4r5_1fuVQTOz8OurnteuKWoP6c7JKHCWjeWluwks-M_GnnixBt3tjmGy4qhd3qWaQB0C4wwG7AWpVEqKA"
        });
    map.put(
        "Spectrum Case",
        new String[] {
          "Spectrum Case Key",
          "https://community.akamai.steamstatic.com/economy/image/i0CoZ81Ui0m-9KwlBY1L_18myuGuq1wfhWSaZgMttyVfPaERSR0Wqmu7LAocGJG51EejH_XGwt6kCnCS_Gl2-4r5_1fuVQTOz8CuqXBdvqT7O_docKbLXTCSlrxytrJrFyjnw0oh5mnRmdz8cX2QblcpD4wwG7D3MEXVUg"
        });
    map.put(
        "Operation Hydra Case",
        new String[] {
          "Operation Hydra Case Key",
          "https://community.akamai.steamstatic.com/economy/image/i0CoZ81Ui0m-9KwlBY1L_18myuGuq1wfhWSaZgMttyVfPaERSR0Wqmu7LAocGJG51EejH_XGwt6kCnCS_Gl2-4r5_1fuVQTOz8GurHVevfSoPvw6I_WSV2PFkOoi5uM8Syyyk0sismyAyY6seHPCZgR2DIwwG7B4ztXgpA"
        });
    map.put(
        "Spectrum 2 Case",
        new String[] {
          "Spectrum 2 Case Key",
          "https://community.akamai.steamstatic.com/economy/image/i0CoZ81Ui0m-9KwlBY1L_18myuGuq1wfhWSaZgMttyVfPaERSR0Wqmu7LAocGJG51EejH_XGwt6kCnCS_Gl2-4r5_1fuVQTOz86urSYLt6P9Pqdpc6iXDWbEkLxz6LI4S37qx0h1tmzczNiteSnFOwVxXowwG7CU5pMrTA"
        });
    map.put(
        "Clutch Case",
        new String[] {
          "Clutch Case Key",
          "https://community.akamai.steamstatic.com/economy/image/i0CoZ81Ui0m-9KwlBY1L_18myuGuq1wfhWSaZgMttyVfPaERSR0Wqmu7LAocGJG51EejH_XGwt6kCnCS_Gl2-4r5_1fuVQTOz8-upSZZ6auqa_ZreamRWD_IlbkgtOVvHiqwzB4i4WuGm9erdn-TPwAlWIwwG7AW_X5tIg"
        });
    map.put(
        "Horizon Case",
        new String[] {
          "Horizon Case Key",
          "https://community.akamai.steamstatic.com/economy/image/i0CoZ81Ui0m-9KwlBY1L_18myuGuq1wfhWSaZgMttyVfPaERSR0Wqmu7LAocGJG51EejH_XGwt6kCnCS_Gl2-4r5_1fuVQTOzMaurSMN66H4OvVvJqWXD2bCxOog5-Q_FnjhxUV05WuGm9f6eH3CZg8kDowwG7AXJjGJeQ"
        });
    map.put(
        "Danger Zone Case",
        new String[] {
          "Danger Zone Case Key",
          "https://community.akamai.steamstatic.com/economy/image/i0CoZ81Ui0m-9KwlBY1L_18myuGuq1wfhWSaZgMttyVfPaERSR0Wqmu7LAocGJG51EejH_XGwt6kCnCS_Gl2-4r5_1fuVQTOzMeuqXRdvqWrPKdocaTKWj7Jlrwm5ONqGnrgwBlz4mrQn42hJCmXOlByX4wwG7BFhaYOyg"
        });
    map.put(
        "Prisma Case",
        new String[] {
          "Prisma Case Key",
          "https://community.akamai.steamstatic.com/economy/image/i0CoZ81Ui0m-9KwlBY1L_18myuGuq1wfhWSaZgMttyVfPaERSR0Wqmu7LAocGJG51EejH_XGwt6kCnCS_Gl2-4r5_1fuVQTOzMSu_3YO7qv9baZsI6HLDDfDlrci6LlvGS-1wkkj4WrUntz7ci_BZlUlA4wwG7AAkCiCfw"
        });
    map.put(
        "Shattered Web Case",
        new String[] {
          "Shattered Web Case Key",
          "https://community.akamai.steamstatic.com/economy/image/i0CoZ81Ui0m-9KwlBY1L_18myuGuq1wfhWSaZgMttyVfPaERSR0Wqmu7LAocGJG51EejH_XGwt6kCnCS_Gl2-4r5_1fuVQTOzMWuriFe6qX4P6A7daCXVz7BkLkl4bYxHn-1kEl_5m_Uy4v8eHuTOw8mWIwwG7BMCWiOJg"
        });
    map.put(
        "CS20 Case",
        new String[] {
          "CS20 Case Key",
          "https://community.akamai.steamstatic.com/economy/image/i0CoZ81Ui0m-9KwlBY1L_18myuGuq1wfhWSaZgMttyVfPaERSR0Wqmu7LAocGJG51EejH_XGwt6kCnCS_Gl2-4r5_1fuVQTOzMKuriAKvfCqbaU5dKLDXGSUxewm4uVtHCiwkU4jtzyHnN2uInmUbFcjCowwG7A5-gjpcQ"
        });
    map.put(
        "Prisma 2 Case",
        new String[] {
          "Prisma 2 Case Key",
          "https://community.akamai.steamstatic.com/economy/image/i0CoZ81Ui0m-9KwlBY1L_18myuGuq1wfhWSaZgMttyVfPaERSR0Wqmu7LAocGJG51EejH_XGwt6kCnCS_Gl2-4r5_1fuVQTOzMOurHJd7qf-PfY6IvPHWDeUwOwm5uc5S362wkx-sWTUzN77eHLFPVByDowwG7DfJsFt9w"
        });
    map.put(
        "Fracture Case",
        new String[] {
          "Fracture Case Key",
          "https://community.akamai.steamstatic.com/economy/image/i0CoZ81Ui0m-9KwlBY1L_18myuGuq1wfhWSaZgMttyVfPaERSR0Wqmu7LAocGJG51EejH_XGwt6kCnCS_Gl2-4r5_1fuVQTOzMCu_nNdvKb-aqU1JKLDCz_Ix-hzsrk9Sn3qkRsh5j6GnNytdimTOA92XowwG7AcG87xrg"
        });
    map.put(
        "Operation Broken Fang Case",
        new String[] {
          "Operation Broken Fang Case Key",
          "https://community.akamai.steamstatic.com/economy/image/i0CoZ81Ui0m-9KwlBY1L_18myuGuq1wfhWSaZgMttyVfPaERSR0Wqmu7LAocGJG51EejH_XGwt6kCnCS_Gl2-4r5_1fuVQTOzMGu_iYM6aKqaaY0dKGVCzHEwrl05-Q_SS3qwxt16mvVw4qtdH2ebgcmW4wwG7CKFhi3hA"
        });
    map.put(
        "Snakebite Case",
        new String[] {
          "Snakebite Case Key",
          "https://community.akamai.steamstatic.com/economy/image/i0CoZ81Ui0m-9KwlBY1L_18myuGuq1wfhWSaZgMttyVfPaERSR0Wqmu7LAocGJG51EejH_XGwt6kCnCS_Gl2-4r5_1fuVQTOzM6u_CdYvPD-MKY8d6XCCDaWkbgl6LhvSi3lxBtz62SAmN74In-WZlB2XIwwG7D172bdjQ"
        });
    map.put(
        "Operation Riptide Case",
        new String[] {
          "Operation Riptide Case Key",
          "https://community.akamai.steamstatic.com/economy/image/i0CoZ81Ui0m-9KwlBY1L_18myuGuq1wfhWSaZgMttyVfPaERSR0Wqmu7LAocGJG51EejH_XGwt6kCnCS_Gl2-4r5_1fuVQTOzM-u-HsC7fP7aac4caXGXGSSkLYg57MwGXG2xkV_6mjSmduhJXOfalMmDIwwG7AEuoxIIA"
        });
    map.put(
        "Dreams & Nightmares Case",
        new String[] {
          "Dreams & Nightmares Case Key",
          "https://community.akamai.steamstatic.com/economy/image/i0CoZ81Ui0m-9KwlBY1L_18myuGuq1wfhWSaZgMttyVfPaERSR0Wqmu7LAocGJG51EejH_XGwt6kCnCS_Gl2-4r5_1fuVQTOzcauqicPvPP_PKU4JKaQWGPCl7kutOQ-SS2wxBl-4j_RmI2seHLDZwEnXowwG7Az4p8gTQ"
        });
    map.put(
        "Recoil Case",
        new String[] {
          "Recoil Case Key",
          "https://cdn.steamstatic.com/apps/730/icons/econ/tools/crate_key_community_31.52815f7f63fa935a0bdec2533215f75b05f6748a.png"
        });
    map.put(
        "Revolution Case",
        new String[] {
          "Revolution Case Key",
          "https://community.akamai.steamstatic.com/economy/image/i0CoZ81Ui0m-9KwlBY1L_18myuGuq1wfhWSaZgMttyVfPaERSR0Wqmu7LAocGJG51EejH_XGwt6kCnCS_Gl2-4r5_1fuVQTOzcSu-yMC7ab8a_VoJfaXWjTAlewk6Lc5H3jnwEVztTzRyNypeH2QawMgD4wwG7BC9K7nsw"
        });
    map.put(
        "Kilowatt Case",
        new String[] {
          "Kilowatt Case Key",
          "https://community.akamai.steamstatic.com/economy/image/i0CoZ81Ui0m-9KwlBY1L_18myuGuq1wfhWSaZgMttyVfPaERSR0Wqmu7LAocGJG51EejH_XGwt6kCnCS_Gl2-4r5_1fuVQTOzcWu-HIN6qH6PPA-IvGRWWOUkrh35eU6Fivmlk0l52WAwtaoc3_COFIkCYwwG7C5B38Dbw"
        });
    map.put(
        "Operation Wildfire Case",
        new String[] {
          "Operation Wildfire Case Key",
          "https://community.akamai.steamstatic.com/economy/image/i0CoZ81Ui0m-9KwlBY1L_18myuGuq1wfhWSaZgMttyVfPaERSR0Wqmu7LAocGJG51EejH_XGwt6kCnCS_Gl2-4r5_1fuVQTOz8eurCde7aqvMPU-JfbECDPFxbwh5OMxGHrkxEp2smTQy9muJy6TPVIhXowwG7A6KpQCEg"
        });
    map.put(
        "Gallery Case",
        new String[] {
          "Gallery Case Key",
          "https://cdn.steamstatic.com/apps/730/icons/econ/tools/crate_key_community_34.cfa210efbf1849e33aaebc9b3d0202bc762868a2.png"
        });
    map.put(
        "Fever Case",
        new String[] {
          "Fever Case Key",
          "https://community.akamai.steamstatic.com/economy/image/i0CoZ81Ui0m-9KwlBY1L_18myuGuq1wfhWSaZgMttyVfPaERSR0Wqmu7LAocGJG51EejH_XGwt6kCnCS_Gl2-4r5_1fuVQTOzcOupSQI6qD7PaA9eaWSWGTElup157M9TXjrk0Qm5z7dyYmocHzFaQYiAowwG7BxOVabyw"
        });
    return java.util.Collections.unmodifiableMap(map);
  }

  Image decodeCs2Background() {
    try {
      return javax.imageio.ImageIO.read(
          new java.io.ByteArrayInputStream(
              java.util.Base64.getDecoder()
                  .decode(String.join("", hGui.CS2_SCENERY_DATA[app.cs2SceneryIndex]))));
    } catch (IOException ex) {
      return null;
    }
  }

  void selectCs2Scenery(int index) {
    if (index < 0 || index >= hGui.CS2_SCENERY_NAMES.length)
      throw new IllegalArgumentException("Choose one of the ten scenery maps");
    app.cs2SceneryIndex = index;
    app.cs2Background = null;
    app.cs2BlurredBackground = null;
    Preferences.userNodeForPackage(hGui.class).node("interface").putInt("scenery", index);
    if (app.mainTabs.getSelectedIndex() == 0) app.cs2Screens.refreshCs2Home();
    app.repaint();
  }

  static Map<String, String> createCs2DefaultWeapons() {
    Map<String, String> map = new LinkedHashMap<>();
    map.put(
        "AK-47",
        "https://community.akamai.steamstatic.com/economy/image/i0CoZ81Ui0m-9KwlBY1L_18myuGuq1wfhWSaZgMttyVfPaERSR0Wqmu7LAocGJKz2lu_XuWbwcuyMESA4Fdl-4nnpU7iQA3-kKnh9nYMoaCvMfxudKGVC2bIwLku5bFsHn2xzU1w4W_Tm9-ucn2eaQZxWcYmR-IU8k7vea-fOvM");
    map.put(
        "AUG",
        "https://community.akamai.steamstatic.com/economy/image/i0CoZ81Ui0m-9KwlBY1L_18myuGuq1wfhWSaZgMttyVfPaERSR0Wqmu7LAocGJKz2lu_XuWbwcuyMESA4Fdl-4nnpU7iQA3-kKnh6CUV7ff8PP08eanED2LHlLh06ec-TnjmkUUmsGXRn4n8cimTPVB0XsR1RPlK7Ee4GsImgw");
    map.put(
        "AWP",
        "https://community.akamai.steamstatic.com/economy/image/i0CoZ81Ui0m-9KwlBY1L_18myuGuq1wfhWSaZgMttyVfPaERSR0Wqmu7LAocGJKz2lu_XuWbwcuyMESA4Fdl-4nnpU7iQA3-kKnh6jIVtqr4PqBoI_ORVjXFkeguseMwGXGwwUV_4GmHyd2qdH-WbFAmApsiQPlK7EcMn7y-CQ");
    map.put(
        "CZ75-Auto",
        "https://community.akamai.steamstatic.com/economy/image/i0CoZ81Ui0m-9KwlBY1L_18myuGuq1wfhWSaZgMttyVfPaERSR0Wqmu7LAocGJKz2lu_XuWbwcuyMESA4Fdl-4nnpU7iQA3-kKnj53UO7ryvaac0dKiVW2XBlrwmsuA6GH3hkE9062qEz9aoeCmVawchW8dwEe4MrFDmxWPDR_Ga");
    map.put(
        "Desert Eagle",
        "https://community.akamai.steamstatic.com/economy/image/i0CoZ81Ui0m-9KwlBY1L_18myuGuq1wfhWSaZgMttyVfPaERSR0Wqmu7LAocGJKz2lu_XuWbwcuyMESA4Fdl-4nnpU7iQA3-kKnk-CNc4_fgOfA8cfGRDTfGku13seI4Fyq2wUQm5DjWzo38IH3BO1N2W5MmTe5etw74zINmLLSKdA");
    map.put(
        "Dual Berettas",
        "https://community.akamai.steamstatic.com/economy/image/i0CoZ81Ui0m-9KwlBY1L_18myuGuq1wfhWSaZgMttyVfPaERSR0Wqmu7LAocGJKz2lu_XuWbwcuyMESA4Fdl-4nnpU7iQA3-kKnl8StP6ryvOqJpJqjACjbBkb93srg-Fn7ilBhysWXSyNarJSqUZlIpCMclTbMCrFDmxYRwJ9Kk");
    map.put(
        "FAMAS",
        "https://community.akamai.steamstatic.com/economy/image/i0CoZ81Ui0m-9KwlBY1L_18myuGuq1wfhWSaZgMttyVfPaERSR0Wqmu7LAocGJKz2lu_XuWbwcuyMESA4Fdl-4nnpU7iQA3-kKnm_C9a_Lz4OvY8dKLGXDKRmOtw5ORrTni3lhl06mqAn4ypJHvBalQlC8AhE-ICrFDmxTHPFtPP");
    map.put(
        "Five-SeveN",
        "https://community.akamai.steamstatic.com/economy/image/i0CoZ81Ui0m-9KwlBY1L_18myuGuq1wfhWSaZgMttyVfPaERSR0Wqmu7LAocGJKz2lu_XuWbwcuyMESA4Fdl-4nnpU7iQA3-kKnm9DRe_Pe4baojePHHWz7GwL4jsbVvTHnilE1w5WrVzo39JH6QOFUnC8RxROMN4ESwlMqnab24YkBbtQ");
    map.put(
        "G3SG1",
        "https://community.akamai.steamstatic.com/economy/image/i0CoZ81Ui0m-9KwlBY1L_18myuGuq1wfhWSaZgMttyVfPaERSR0Wqmu7LAocGJKz2lu_XuWbwcuyMESA4Fdl-4nnpU7iQA3-kKnnrjFcvrz4P_U6efbAWT7BmOou57AxHHjjx0gk4zjQztqtJC7FaVUoW5okTLQNrFDmxakCozSV");
    map.put(
        "Galil AR",
        "https://community.akamai.steamstatic.com/economy/image/i0CoZ81Ui0m-9KwlBY1L_18myuGuq1wfhWSaZgMttyVfPaERSR0Wqmu7LAocGJKz2lu_XuWbwcuyMESA4Fdl-4nnpU7iQA3-kKnn_C5S4_O8JvZrIaPKV2ORx7d3trg7Gnjmlxl04WTTyoyqeXKUPFVzCsN1FuMJuxam0oqwr0aqT-w");
    map.put(
        "Glock-18",
        "https://community.akamai.steamstatic.com/economy/image/i0CoZ81Ui0m-9KwlBY1L_18myuGuq1wfhWSaZgMttyVfPaERSR0Wqmu7LAocGJKz2lu_XuWbwcuyMESA4Fdl-4nnpU7iQA3-kKnn8S1Y5Lz9O_M5d_LHDz6WmOp04-U8THmwzU0l6ziDyd__IC3DO1IgXJJwE7NfrFDmxU9v5GXb");
    map.put(
        "M249",
        "https://community.akamai.steamstatic.com/economy/image/i0CoZ81Ui0m-9KwlBY1L_18myuGuq1wfhWSaZgMttyVfPaERSR0Wqmu7LAocGJKz2lu_XuWbwcuyMESA4Fdl-4nnpU7iQA3-kKntr3YCoaarbfc_IvHDWWLClb8g5OA7F3y1l0xw6juBzdeoJX6fZ1IoWcciQ-UU8k7vtOr9c-I");
    map.put(
        "M4A4",
        "https://community.akamai.steamstatic.com/economy/image/i0CoZ81Ui0m-9KwlBY1L_18myuGuq1wfhWSaZgMttyVfPaERSR0Wqmu7LAocGJKz2lu_XuWbwcuyMESA4Fdl-4nnpU7iQA3-kKntqSMKofH_O_Y-JfSVV2XBkLolsbZvTCqxx0sk4DjUnNipdSiQagcgXJQlRLEU8k7vIDSSpqI");
    map.put(
        "M4A1-S",
        "https://community.akamai.steamstatic.com/economy/image/i0CoZ81Ui0m-9KwlBY1L_18myuGuq1wfhWSaZgMttyVfPaERSR0Wqmu7LAocGJKz2lu_XuWbwcuyMESA4Fdl-4nnpU7iQA3-kKntqSMK0OGnZKFjI_WBQD_Cleh0teA_F37qkERy52rWm9yhdynGblMgD5AkQrZeuhXtkt3iMOv8p1uJZpwq8Vo");
    map.put(
        "MAC-10",
        "https://raw.githubusercontent.com/ByMykel/counter-strike-image-tracker/main/static/panorama/images/econ/weapons/base_weapons/weapon_mac10_png.png");
    map.put(
        "MAG-7",
        "https://community.akamai.steamstatic.com/economy/image/i0CoZ81Ui0m-9KwlBY1L_18myuGuq1wfhWSaZgMttyVfPaERSR0Wqmu7LAocGJKz2lu_XuWbwcuyMESA4Fdl-4nnpU7iQA3-kKnt_CUMoav3MP1oeanBXWLAmeoitbk-HHrjl0hztW7Xy4n7dirDag4hXJB4EeUU8k7vG_ZoUEk");
    map.put(
        "MP5-SD",
        "https://raw.githubusercontent.com/ByMykel/counter-strike-image-tracker/main/static/panorama/images/econ/weapons/base_weapons/weapon_mp5sd_png.png");
    map.put(
        "MP7",
        "https://community.akamai.steamstatic.com/economy/image/i0CoZ81Ui0m-9KwlBY1L_18myuGuq1wfhWSaZgMttyVfPaERSR0Wqmu7LAocGJKz2lu_XuWbwcuyMESA4Fdl-4nnpU7iQA3-kKnt7XUVvfOoPqA1eKHEVjXFlr0ituM_SnqwwR9w4mXVyIn6dnKRblV1D5AhTPlK7EelyO1yEg");
    map.put(
        "MP9",
        "https://community.akamai.steamstatic.com/economy/image/i0CoZ81Ui0m-9KwlBY1L_18myuGuq1wfhWSaZgMttyVfPaERSR0Wqmu7LAocGJKz2lu_XuWbwcuyMESA4Fdl-4nnpU7iQA3-kKnt7XsVv6T9OvE9dKLKCD_Ex74h5bY6Tnrgl0hzt2rXm4qseXyWaAMgWJJ2EflK7Ec0i602wg");
    map.put(
        "Negev",
        "https://community.akamai.steamstatic.com/economy/image/i0CoZ81Ui0m-9KwlBY1L_18myuGuq1wfhWSaZgMttyVfPaERSR0Wqmu7LAocGJKz2lu_XuWbwcuyMESA4Fdl-4nnpU7iQA3-kKnu-CVe-bz3P6I1caTGDzTFk7gh5rg6Tn3rkBwm4zjSwo3_Ii-fZgIjA8dwELFZrFDmxWhBRARX");
    map.put(
        "Nova",
        "https://raw.githubusercontent.com/ByMykel/counter-strike-image-tracker/main/static/panorama/images/econ/weapons/base_weapons/weapon_nova_png.png");
    map.put(
        "P2000",
        "https://community.akamai.steamstatic.com/economy/image/i0CoZ81Ui0m-9KwlBY1L_18myuGuq1wfhWSaZgMttyVfPaERSR0Wqmu7LAocGJKz2lu_XuWbwcuyMESA4Fdl-4nnpU7iQA3-kKno9jIJv6L-Jqc_cKjEWDDDlLx3trVrH3qykEtz4TjQno6td3uVbVRyWZR2EbEKtRCm0oqwKXhPxN4");
    map.put(
        "P250",
        "https://community.akamai.steamstatic.com/economy/image/i0CoZ81Ui0m-9KwlBY1L_18myuGuq1wfhWSaZgMttyVfPaERSR0Wqmu7LAocGJKz2lu_XuWbwcuyMESA4Fdl-4nnpU7iQA3-kKnwr3cLoaf4avNvJqKXXmKUlrp0s-U9HCvgw0V05WSDw96pIC6VOw92X8QkROAU8k7vNwsvFQ4");
    map.put(
        "P90",
        "https://community.akamai.steamstatic.com/economy/image/i0CoZ81Ui0m-9KwlBY1L_18myuGuq1wfhWSaZgMttyVfPaERSR0Wqmu7LAocGJKz2lu_XuWbwcuyMESA4Fdl-4nnpU7iQA3-kKnwpHIVvfOsPfI9dqDCWDDGkb4j5OU_Fy_kx0l1tj6DnoqseC2TP1cpAsF2QPlK7EcMYXqtDg");
    map.put(
        "PP-Bizon",
        "https://community.akamai.steamstatic.com/economy/image/i0CoZ81Ui0m-9KwlBY1L_18myuGuq1wfhWSaZgMttyVfPaERSR0Wqmu7LAocGJKz2lu_XuWbwcuyMESA4Fdl-4nnpU7iQA3-kKni9DhU4bz-PKZocPTBW2GWlbZw4bM7SS2xwER1smSEnIv6dS_GbFBxDJd0RLFbrFDmxaLGO5J-");
    map.put(
        "R8 Revolver",
        "https://community.akamai.steamstatic.com/economy/image/i0CoZ81Ui0m-9KwlBY1L_18myuGuq1wfhWSaZgMttyVfPaERSR0Wqmu7LAocGJKz2lu_XuWbwcuyMESA4Fdl-4nnpU7iQA3-kKny-DRU4-Sreuo8cvTLCzKRmbkk4ONtGijilk8k4znWy9v8JCiUaQIiWZpyQ-AJtEa7jJS5YM17OTN5");
    map.put(
        "Sawed-Off",
        "https://community.akamai.steamstatic.com/economy/image/i0CoZ81Ui0m-9KwlBY1L_18myuGuq1wfhWSaZgMttyVfPaERSR0Wqmu7LAocGJKz2lu_XuWbwcuyMESA4Fdl-4nnpU7iQA3-kKnz_DVe6_2obuo_JqHACzaSk-1wtrMwTi3nkUly6m-ByYr4Jy2fP1cgA8dxFLRfu0LqjJS5YC4vtNQk");
    map.put(
        "SCAR-20",
        "https://community.akamai.steamstatic.com/economy/image/i0CoZ81Ui0m-9KwlBY1L_18myuGuq1wfhWSaZgMttyVfPaERSR0Wqmu7LAocGJKz2lu_XuWbwcuyMESA4Fdl-4nnpU7iQA3-kKnz_iNJvaLgbqY_JqbKV2TExL11s7JoGnjkl05-4TvUw96vdHiQOwZ1AsMiQuMOtQ74zINGfpXf5Q");
    map.put(
        "SG 553",
        "https://raw.githubusercontent.com/ByMykel/counter-strike-image-tracker/main/static/panorama/images/econ/weapons/base_weapons/weapon_sg556_png.png");
    map.put(
        "SSG 08",
        "https://community.akamai.steamstatic.com/economy/image/i0CoZ81Ui0m-9KwlBY1L_18myuGuq1wfhWSaZgMttyVfPaERSR0Wqmu7LAocGJKz2lu_XuWbwcuyMESA4Fdl-4nnpU7iQA3-kKnz7iULt7z2MPY1eaWVCDHGlrgksuQ_HS3lxhkh4m-Gm9b6ICjCPQ4hDMF3EOJerFDmxXJ24aAg");
    map.put(
        "Tec-9",
        "https://community.akamai.steamstatic.com/economy/image/i0CoZ81Ui0m-9KwlBY1L_18myuGuq1wfhWSaZgMttyVfPaERSR0Wqmu7LAocGJKz2lu_XuWbwcuyMESA4Fdl-4nnpU7iQA3-kKn0-CECofb2MKY9IvPGWjPAkrwi5Lk4Tn3nzUwlsGnVzI6pdymQbVAjW8d0F-IU8k7vdMx23Ho");
    map.put(
        "UMP-45",
        "https://community.akamai.steamstatic.com/economy/image/i0CoZ81Ui0m-9KwlBY1L_18myuGuq1wfhWSaZgMttyVfPaERSR0Wqmu7LAocGJKz2lu_XuWbwcuyMESA4Fdl-4nnpU7iQA3-kKn18DIPurz6MPducqDGCDPIw7l05LA7SXyylkh25z-Dm9agJHKSZgciDZt3F7JerFDmxeILsNGi");
    map.put(
        "USP-S",
        "https://community.akamai.steamstatic.com/economy/image/i0CoZ81Ui0m-9KwlBY1L_18myuGuq1wfhWSaZgMttyVfPaERSR0Wqmu7LAocGJKz2lu_XuWbwcuyMESA4Fdl-4nnpU7iQA3-kKn17jJk_PuibapuJeLdWGLFwL8i4eVsFiqxxUt34jmHnoysJ3qVOAYgCJZwQrRb5EPul4XlYvSiuVIHgy4Xvg");
    map.put(
        "XM1014",
        "https://raw.githubusercontent.com/ByMykel/counter-strike-image-tracker/main/static/panorama/images/econ/weapons/base_weapons/weapon_xm1014_png.png");
    map.put(
        "CT Knife",
        "https://community.akamai.steamstatic.com/economy/image/i0CoZ81Ui0m-9KwlBY1L_18myuGuq1wfhWSaZgMttyVfPaERSR0Wqmu7LAocGJKz2lu_XuWbwcuyMESA4Fdl-4nnpU7iQA3-kKnr8ytd6rz5PvI9dPbGX2HGl7dw4LYxHn3mlkshtWmHzI74IyqVbQQnWZN1Q7QLrFDmxYFVbevc");
    map.put(
        "T Knife",
        "https://community.akamai.steamstatic.com/economy/image/i0CoZ81Ui0m-9KwlBY1L_18myuGuq1wfhWSaZgMttyVfPaERSR0Wqmu7LAocGJKz2lu_XuWbwcuyMESA4Fdl-4nnpU7iQA3-kKnr8ytd6s26JqJodqWRXjXBlLt05bM7TX21kx91527RnN-teXzFPQYpD5ckQbYM4BCm0oqwrVaqAqg");
    map.put(
        "CT Gloves",
        "https://raw.githubusercontent.com/ByMykel/counter-strike-image-tracker/main/static/panorama/images/econ/weapons/base_weapons/ct_gloves_png.png");
    map.put(
        "T Gloves",
        "https://raw.githubusercontent.com/ByMykel/counter-strike-image-tracker/main/static/panorama/images/econ/weapons/base_weapons/t_gloves_png.png");
    return java.util.Collections.unmodifiableMap(map);
  }
}
