package blahblah;

import blahblah.hGui.*;
import java.awt.*;
import java.awt.event.*;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.regex.Matcher;
import java.util.regex.Pattern;
import javax.swing.*;

/** Catalog Parsing Service: focused feature implementation. */
final class CatalogParsingService {
  private final hGui app;

  CatalogParsingService(hGui app) {
    this.app = app;
  }

  int applyExternalAgentCatalog(String json) {
    if (json == null || json.trim().isEmpty()) return 0;
    int arrayStart = json.indexOf('[');
    if (arrayStart < 0) return 0;
    app.itemMetadataService.ensureAgentCaches();
    app.agentCatalog.clear();
    Map<String, List<String>> namesByRarity = new HashMap<>();
    for (String rarity : new String[] {"Distinguished", "Exceptional", "Superior", "Master"}) {
      namesByRarity.put(rarity, new ArrayList<>());
    }

    int loaded = 0;
    int cursor = arrayStart + 1;
    while (cursor < json.length()) {
      int objectStart = json.indexOf('{', cursor);
      if (objectStart < 0) break;
      int objectEnd = app.publicPriceFeeds.findJsonObjectEnd(json, objectStart);
      if (objectEnd < 0) break;
      String object = json.substring(objectStart, objectEnd + 1);
      String name = app.catalogParsingService.extractCatalogString(object, "name", false);
      String imageUrl = app.catalogParsingService.extractCatalogString(object, "image", true);
      String rarityObject = app.publicPriceFeeds.findJsonObjectField(object, "rarity");
      String rarity =
          rarityObject == null
              ? null
              : app.catalogParsingService.extractCatalogString(rarityObject, "name", false);
      if (name != null && namesByRarity.containsKey(rarity)) {
        String skinName = app.catalogParsingService.normalizeCatalogSkinName(name);
        app.agentCatalog.put(
            skinName,
            new SkinMetadata(
                imageUrl, null, null, "Agents", rarity, java.util.Collections.emptySet()));
        app.artworkNameAliases.put(app.artworkService.artworkAliasKey(skinName), skinName);
        namesByRarity.get(rarity).add(skinName);
        loaded++;
      }
      cursor = objectEnd + 1;
    }

    ArmouryCollection agentsCollection = null;
    for (ArmouryCollection collection : hGui.ARMOURY_COLLECTIONS) {
      if (collection.isAgents) {
        agentsCollection = collection;
        break;
      }
    }
    if (agentsCollection == null) {
      throw new IllegalStateException("The Agents Collection is missing from ARMOURY_COLLECTIONS.");
    }
    final ArmouryCollection targetCollection = agentsCollection;

    for (List<String> names : namesByRarity.values()) names.sort(String.CASE_INSENSITIVE_ORDER);
    String[] distinguishedNames = namesByRarity.get("Distinguished").toArray(new String[0]);
    String[] exceptionalNames = namesByRarity.get("Exceptional").toArray(new String[0]);
    String[] superiorNames = namesByRarity.get("Superior").toArray(new String[0]);
    String[] masterNames = namesByRarity.get("Master").toArray(new String[0]);
    String[] distinguishedFiles = new String[distinguishedNames.length];
    String[] exceptionalFiles = new String[exceptionalNames.length];
    String[] superiorFiles = new String[superiorNames.length];
    String[] masterFiles = new String[masterNames.length];
    java.util.Arrays.fill(distinguishedFiles, "agent");
    java.util.Arrays.fill(exceptionalFiles, "agent");
    java.util.Arrays.fill(superiorFiles, "agent");
    java.util.Arrays.fill(masterFiles, "agent");
    double[] distinguishedPrices =
        app.catalogParsingService.agentPrices(distinguishedNames, "Distinguished");
    double[] exceptionalPrices =
        app.catalogParsingService.agentPrices(exceptionalNames, "Exceptional");
    double[] superiorPrices = app.catalogParsingService.agentPrices(superiorNames, "Superior");
    double[] masterPrices = app.catalogParsingService.agentPrices(masterNames, "Master");
    Runnable applyCatalog =
        () -> {
          targetCollection.milspecNames = distinguishedNames;
          targetCollection.restrictedNames = exceptionalNames;
          targetCollection.classifiedNames = superiorNames;
          targetCollection.covertNames = masterNames;
          targetCollection.milspec = distinguishedFiles;
          targetCollection.restricted = exceptionalFiles;
          targetCollection.classified = superiorFiles;
          targetCollection.covert = masterFiles;
          targetCollection.milspecPrices = distinguishedPrices;
          targetCollection.restrictedPrices = exceptionalPrices;
          targetCollection.classifiedPrices = superiorPrices;
          targetCollection.covertPrices = masterPrices;
          targetCollection.thumbnailFile = null;
          app.agentRarityCache.clear();
          app.agentBasePriceCache.clear();
          app.armourySkinNameCache.clear();
          app.armouryCacheBuilt = false;
          app.collectionCache.clear();
        };
    if (SwingUtilities.isEventDispatchThread()) {
      applyCatalog.run();
    } else {
      try {
        SwingUtilities.invokeAndWait(applyCatalog);
      } catch (InterruptedException e) {
        Thread.currentThread().interrupt();
        throw new IllegalStateException("Interrupted while applying the CS2 agent catalog.", e);
      } catch (java.lang.reflect.InvocationTargetException e) {
        throw new IllegalStateException("Could not apply the CS2 agent catalog.", e.getCause());
      }
    }
    return loaded;
  }

  double[] agentPrices(String[] names, String rarity) {
    double fallbackPrice;
    switch (rarity) {
      case "Distinguished":
        fallbackPrice = 5.0;
        break;
      case "Exceptional":
        fallbackPrice = 20.0;
        break;
      case "Superior":
        fallbackPrice = 50.0;
        break;
      case "Master":
        fallbackPrice = 125.0;
        break;
      default:
        throw new IllegalArgumentException("Unsupported agent rarity: " + rarity);
    }
    double[] prices = new double[names.length];
    for (int i = 0; i < names.length; i++) {
      Double persistedPrice = app.itemPriceService.loadCachedMarketBasePrice(names[i]);
      prices[i] =
          persistedPrice != null
              ? persistedPrice
              : app.agentBasePriceCache.getOrDefault(
                  app.itemMetadataService.normalizeAgentLookupKey(names[i]), fallbackPrice);
      long cachedAt = app.marketPricePreferences.getLong("t." + names[i], 0L);
      if (persistedPrice == null
          || System.currentTimeMillis() - cachedAt >= hGui.MARKET_PRICE_CACHE_TTL_MS
          || !app.liveConditionPriceMultipliers.containsKey(names[i])) {
        app.itemPriceService.scheduleMarketPriceLookup(names[i], prices[i]);
      }
    }
    return prices;
  }

  String extractPrimaryCollectionName(String object) {
    int field = object.indexOf("\"collections\"");
    if (field < 0) return null;
    int array = object.indexOf('[', field), end = array < 0 ? -1 : object.indexOf(']', array);
    int first = array < 0 ? -1 : object.indexOf('{', array);
    if (first < 0 || end < first) return null;
    int close = app.publicPriceFeeds.findJsonObjectEnd(object, first);
    if (close < first) return null;
    return app.catalogParsingService.extractCatalogString(
        object.substring(first, close + 1), "name", false);
  }

  int applyExternalSkinCatalog(String json) {
    if (json == null || json.trim().isEmpty()) return 0;
    int arrayStart = json.indexOf('[');
    if (arrayStart < 0) return 0;
    int loaded = 0;
    int cursor = arrayStart + 1;
    while (cursor < json.length()) {
      int objectStart = json.indexOf('{', cursor);
      if (objectStart < 0) break;
      int objectEnd = app.publicPriceFeeds.findJsonObjectEnd(json, objectStart);
      if (objectEnd < 0) break;
      String object = json.substring(objectStart, objectEnd + 1);
      String rawName = app.catalogParsingService.extractCatalogString(object, "name", false);
      String imageUrl = app.catalogParsingService.extractCatalogString(object, "image", true);
      String phase = app.catalogParsingService.extractCatalogString(object, "phase", false);
      Double minFloat = app.catalogParsingService.extractCatalogNumber(object, "min_float");
      Double maxFloat = app.catalogParsingService.extractCatalogNumber(object, "max_float");
      String categoryObject = app.publicPriceFeeds.findJsonObjectField(object, "category");
      String rarityObject = app.publicPriceFeeds.findJsonObjectField(object, "rarity");
      String category =
          categoryObject == null
              ? null
              : app.catalogParsingService.extractCatalogString(categoryObject, "name", false);
      String rarity =
          rarityObject == null
              ? null
              : app.catalogParsingService.extractCatalogString(rarityObject, "name", false);
      Set<String> crateNames = app.catalogParsingService.extractCatalogCrateNames(object);
      if (rawName != null) {
        String skinName = app.catalogParsingService.normalizeCatalogSkinName(rawName);
        if ("Knives".equals(category) && !skinName.contains("|")) {
          skinName += " | Vanilla";
        }
        if ("Knives".equals(category) && phase != null && !phase.isBlank()) {
          skinName += " (" + phase.trim() + ")";
        }
        if (!skinName.isEmpty()) {
          app.skinCatalog.put(
              skinName,
              new SkinMetadata(
                  imageUrl,
                  minFloat,
                  maxFloat,
                  category,
                  rarity,
                  crateNames,
                  app.catalogParsingService.extractPrimaryCollectionName(object)));
          app.artworkNameAliases.put(app.artworkService.artworkAliasKey(skinName), skinName);
          String weapon = app.publicPriceFeeds.findJsonObjectField(object, "weapon");
          String weaponId =
              weapon == null
                  ? null
                  : app.catalogParsingService.extractCatalogString(weapon, "id", false);
          String paint = app.catalogParsingService.extractCatalogRootString(object, "paint_index");
          if (paint == null) {
            Double numericPaint =
                app.catalogParsingService.extractCatalogNumber(object, "paint_index");
            if (numericPaint != null) paint = String.valueOf(numericPaint.intValue());
          }
          if (weaponId != null && paint != null && paint.matches("[0-9]+"))
            app.wearImageBasePaths.put(
                skinName, weaponId.replaceFirst("^weapon_", "") + "/" + paint);
          loaded++;
          boolean validMin =
              minFloat != null && Double.isFinite(minFloat) && minFloat >= 0.0 && minFloat <= 1.0;
          boolean validMax =
              maxFloat != null && Double.isFinite(maxFloat) && maxFloat >= 0.0 && maxFloat <= 1.0;
          if (validMin && validMax && minFloat > maxFloat) {
            validMin = false;
            validMax = false;
          }
          if (validMin || validMax) {
            Double catalogMin = validMin ? minFloat : null;
            Double catalogMax = validMax ? maxFloat : null;
            boolean authoritativeFloatCaps =
                true; // Valid catalog caps supersede legacy defaults for every skin.
            hGui.FLOAT_LIMITS.compute(
                skinName,
                (key, existing) -> {
                  Double mergedMin =
                      authoritativeFloatCaps && catalogMin != null
                          ? catalogMin
                          : existing != null && existing.min != null ? existing.min : catalogMin;
                  Double mergedMax =
                      authoritativeFloatCaps && catalogMax != null
                          ? catalogMax
                          : existing != null && existing.max != null ? existing.max : catalogMax;
                  if (mergedMin != null && mergedMax != null && mergedMin > mergedMax) {
                    return existing;
                  }
                  return new FloatRange(mergedMin, mergedMax);
                });
          }
        }
      }
      cursor = objectEnd + 1;
    }
    app.availableConditionsCache.clear();
    app.rarityCache.clear();
    app.collectionCache.clear();
    app.catalogCaseCollectionCache.clear();
    return loaded;
  }

  Set<String> extractCatalogCrateNames(String object) {
    Matcher cratesMatcher =
        Pattern.compile("\"crates\"\\s*:\\s*\\[(.*?)\\]", Pattern.DOTALL).matcher(object);
    if (!cratesMatcher.find()) return java.util.Collections.emptySet();
    Set<String> crateNames = new HashSet<>();
    Matcher nameMatcher =
        Pattern.compile("\"name\"\\s*:\\s*\"((?:\\\\.|[^\"\\\\])*)\"")
            .matcher(cratesMatcher.group(1));
    while (nameMatcher.find())
      crateNames.add(app.catalogParsingService.unescapeCatalogString(nameMatcher.group(1)));
    return crateNames;
  }

  String extractCatalogString(String object, String fieldName, boolean lastMatch) {
    Pattern pattern =
        Pattern.compile("\"" + Pattern.quote(fieldName) + "\"\\s*:\\s*\"((?:\\\\.|[^\"\\\\])*)\"");
    Matcher matcher = pattern.matcher(object);
    String value = null;
    while (matcher.find()) {
      value = matcher.group(1);
      if (!lastMatch) break;
    }
    return value == null ? null : app.catalogParsingService.unescapeCatalogString(value);
  }

  String extractCatalogRootString(String jsonObject, String fieldName) {
    int objectDepth = 0;
    int arrayDepth = 0;
    for (int i = 0; i < jsonObject.length(); i++) {
      char ch = jsonObject.charAt(i);
      if (ch == '{') {
        objectDepth++;
        continue;
      }
      if (ch == '}') {
        objectDepth--;
        continue;
      }
      if (ch == '[') {
        arrayDepth++;
        continue;
      }
      if (ch == ']') {
        arrayDepth--;
        continue;
      }
      if (ch != '"' || objectDepth != 1 || arrayDepth != 0) continue;

      int keyStart = ++i;
      boolean escaped = false;
      while (i < jsonObject.length()) {
        char keyChar = jsonObject.charAt(i);
        if (escaped) escaped = false;
        else if (keyChar == '\\') escaped = true;
        else if (keyChar == '"') break;
        i++;
      }
      if (i >= jsonObject.length()) return null;
      String key =
          app.catalogParsingService.unescapeCatalogString(jsonObject.substring(keyStart, i));
      int valueStart = i + 1;
      while (valueStart < jsonObject.length()
          && Character.isWhitespace(jsonObject.charAt(valueStart))) valueStart++;
      if (valueStart >= jsonObject.length() || jsonObject.charAt(valueStart) != ':') continue;
      valueStart++;
      while (valueStart < jsonObject.length()
          && Character.isWhitespace(jsonObject.charAt(valueStart))) valueStart++;
      if (!fieldName.equals(key)
          || valueStart >= jsonObject.length()
          || jsonObject.charAt(valueStart) != '"') continue;

      int stringStart = ++valueStart;
      escaped = false;
      while (valueStart < jsonObject.length()) {
        char valueChar = jsonObject.charAt(valueStart);
        if (escaped) escaped = false;
        else if (valueChar == '\\') escaped = true;
        else if (valueChar == '"') {
          return app.catalogParsingService.unescapeCatalogString(
              jsonObject.substring(stringStart, valueStart));
        }
        valueStart++;
      }
      return null;
    }
    return null;
  }

  Double extractCatalogNumber(String object, String fieldName) {
    Matcher matcher =
        Pattern.compile("\"" + Pattern.quote(fieldName) + "\"\\s*:\\s*(-?\\d+(?:\\.\\d+)?|null)")
            .matcher(object);
    if (!matcher.find() || "null".equals(matcher.group(1))) return null;
    try {
      return Double.valueOf(matcher.group(1));
    } catch (NumberFormatException e) {
      return null;
    }
  }

  String unescapeCatalogString(String value) {
    StringBuilder result = new StringBuilder(value.length());
    for (int i = 0; i < value.length(); i++) {
      char ch = value.charAt(i);
      if (ch != '\\' || i + 1 >= value.length()) {
        result.append(ch);
        continue;
      }
      char escaped = value.charAt(++i);
      switch (escaped) {
        case '"':
          result.append('"');
          break;
        case '\\':
          result.append('\\');
          break;
        case '/':
          result.append('/');
          break;
        case 'b':
          result.append('\b');
          break;
        case 'f':
          result.append('\f');
          break;
        case 'n':
          result.append('\n');
          break;
        case 'r':
          result.append('\r');
          break;
        case 't':
          result.append('\t');
          break;
        case 'u':
          if (i + 4 < value.length()) {
            try {
              result.append((char) Integer.parseInt(value.substring(i + 1, i + 5), 16));
              i += 4;
            } catch (NumberFormatException e) {
              result.append('u');
            }
          } else {
            result.append('u');
          }
          break;
        default:
          result.append(escaped);
      }
    }
    return result.toString();
  }

  String normalizeCatalogSkinName(String name) {
    String normalized = name.trim().replaceFirst("^★\\s*", "");
    normalized = normalized.replaceFirst("^StatTrak™\\s*", "");
    normalized = normalized.replaceFirst("^StatTrak\\s*", "");
    return normalized.trim();
  }

  String stripSouvenirPrefix(String skinName) {
    return skinName == null ? null : skinName.replaceFirst("(?i)^Souvenir\\s+", "").trim();
  }

  FloatRange findFloatRange(String skinName) {
    if (skinName == null) return null;
    String normalized =
        app.catalogParsingService.stripSouvenirPrefix(
            skinName.replaceFirst("(?i)^StatTrak™?\\s*", ""));
    FloatRange range = hGui.FLOAT_LIMITS.get(normalized);
    if (range != null) return range;
    for (Map.Entry<String, FloatRange> entry : hGui.FLOAT_LIMITS.entrySet()) {
      if (normalized.startsWith(entry.getKey())) return entry.getValue();
    }
    String catalogName = app.catalogParsingService.normalizeCatalogSkinName(normalized);
    int variantStart = catalogName.lastIndexOf(" (");
    if (variantStart > 0) catalogName = catalogName.substring(0, variantStart).trim();
    SkinMetadata metadata = app.skinCatalog.get(catalogName);
    if (metadata != null
        && metadata.minFloat != null
        && metadata.maxFloat != null
        && Double.isFinite(metadata.minFloat)
        && Double.isFinite(metadata.maxFloat)
        && metadata.minFloat >= 0.0
        && metadata.maxFloat <= 1.0
        && metadata.minFloat < metadata.maxFloat) {
      return new FloatRange(metadata.minFloat, metadata.maxFloat);
    }
    return null;
  }
}
