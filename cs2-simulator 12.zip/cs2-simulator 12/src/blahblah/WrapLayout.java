package blahblah;

import blahblah.hGui.*;
import java.awt.*;
import java.awt.event.*;
import javax.swing.*;

/** Extracted reusable model or widget; behavior retained from the original source. */
public class WrapLayout extends FlowLayout {
  public WrapLayout(int align, int hgap, int vgap) {
    super(align, hgap, vgap);
  }

  @Override
  public Dimension preferredLayoutSize(java.awt.Container target) {
    return layoutSize(target, true);
  }

  @Override
  public Dimension minimumLayoutSize(java.awt.Container target) {
    Dimension min = layoutSize(target, false);
    min.width -= (getHgap() + 1);
    return min;
  }

  Dimension layoutSize(java.awt.Container target, boolean preferred) {
    synchronized (target.getTreeLock()) {
      int targetWidth = target.getSize().width;
      if (targetWidth == 0) targetWidth = Integer.MAX_VALUE;
      int hgap = getHgap(), vgap = getVgap();
      java.awt.Insets insets = target.getInsets();
      int maxWidth = targetWidth - insets.left - insets.right - hgap * 2;
      Dimension dim = new Dimension(0, 0);
      int rowWidth = 0, rowHeight = 0;
      int nmembers = target.getComponentCount();
      for (int i = 0; i < nmembers; i++) {
        java.awt.Component m = target.getComponent(i);
        if (m.isVisible()) {
          Dimension d = preferred ? m.getPreferredSize() : m.getMinimumSize();
          if (rowWidth + d.width > maxWidth && rowWidth > 0) {
            dim.width = Math.max(dim.width, rowWidth);
            dim.height += rowHeight + vgap;
            rowWidth = 0;
            rowHeight = 0;
          }
          rowWidth += d.width + hgap;
          rowHeight = Math.max(rowHeight, d.height);
        }
      }
      dim.width = Math.max(dim.width, rowWidth);
      dim.height += rowHeight + insets.top + insets.bottom + vgap * 2;
      return dim;
    }
  }
}
