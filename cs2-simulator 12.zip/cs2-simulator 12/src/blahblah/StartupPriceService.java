package blahblah;

import blahblah.hGui.*;
import java.awt.*;
import java.awt.event.*;
import java.util.Set;
import javax.swing.*;

/** Startup Price Service: focused feature implementation. */
final class StartupPriceService {
  private final hGui app;

  StartupPriceService(hGui app) {
    this.app = app;
  }

  Set<String> getStartupArtworkNames() {
    Set<String> names = new java.util.TreeSet<>();
    for (String name : app.collectionScreen.getAllPossibleSkins())
      names.add(app.artworkService.canonicalArtworkName(name));
    for (String name : app.skinCatalog.keySet())
      names.add(app.artworkService.canonicalArtworkName(name));
    for (String name : app.agentCatalog.keySet())
      names.add(app.artworkService.canonicalArtworkName(name));
    names.remove("");
    return names;
  }

  void awaitStartupPriceLookups() throws InterruptedException {
    while (!app.pendingMarketPriceLookups.isEmpty()) Thread.sleep(50);
  }

  void prepareStartupPriceTracking(Set<String> names) {
    app.startupPriceNames =
        java.util.Collections.unmodifiableSet(new java.util.LinkedHashSet<>(names));
    app.startupPriceRequestedNames.clear();
    app.startupPriceTotal = names.size();
    app.startupPricesLoaded = 0;
    app.startupPriceFallbacks = 0;
    app.startupPriceStageActive = true;
  }

  void refreshStartupPriceCounters() {
    int loaded = 0, fallback = 0;
    for (String name : app.startupPriceNames) {
      if (!app.startupPriceRequestedNames.contains(name)) continue;
      Double price = app.liveBasePrices.get(name);
      if (price != null && Double.isFinite(price) && price > 0) loaded++;
      else if (!app.pendingMarketPriceLookups.contains(name)) fallback++;
    }
    app.startupPricesLoaded = loaded;
    app.startupPriceFallbacks = fallback;
  }

  void reportStartupPriceProgress() {
    app.startupPriceService.refreshStartupPriceCounters();
    int completed = app.startupPricesLoaded + app.startupPriceFallbacks;
    app.startupScreen.setStartupProgress(
        10 + (int) Math.round(30.0 * completed / Math.max(1, app.startupPriceTotal)),
        "Skin prices loaded: "
            + app.startupPricesLoaded
            + " / "
            + app.startupPriceTotal
            + (app.startupPriceFallbacks == 0
                ? ""
                : " (fallback: " + app.startupPriceFallbacks + ")"));
  }

  void preloadStartupSkinPrices() throws InterruptedException {
    if (SwingUtilities.isEventDispatchThread())
      throw new IllegalStateException("Price preload must run off the EDT");
    Set<String> names = app.startupPriceService.getStartupArtworkNames();
    if (!app.startupPriceStageActive || !app.startupPriceNames.equals(names))
      app.startupPriceService.prepareStartupPriceTracking(names);
    app.startupScreen.setStartupProgress(10, "Skin prices loaded: 0 / " + app.startupPriceTotal);
    int queued = 0;
    for (String name : names) {
      if (Thread.currentThread().isInterrupted()) throw new InterruptedException();
      app.itemPriceService.getBasePrice(
          name); // Existing cached/feed/fallback pricing rules remain unchanged.
      app.startupPriceRequestedNames.add(name);
      if (++queued % 32 == 0) app.startupPriceService.reportStartupPriceProgress();
    }
    while (true) {
      app.startupPriceService.reportStartupPriceProgress();
      if (app.startupPricesLoaded + app.startupPriceFallbacks == names.size()
          && names.stream().noneMatch(app.pendingMarketPriceLookups::contains)) break;
      Thread.sleep(100);
    }
    app.startupPriceService.awaitStartupPriceLookups();
    app.startupPriceService.refreshStartupPriceCounters();
    app.startupPriceStageActive = false;
  }
}
