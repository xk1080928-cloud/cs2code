package blahblah;

import java.awt.*;
import java.awt.event.*;
import javax.swing.*;

/** Mouse-controlled genuine PNG inspection, explicitly 2D; not a simulated 3D rotation. */
final class InspectImageView extends JLabel {
  private Image source;
  private double zoom = 1, panX, panY;
  private Point anchor;

  InspectImageView(Image initial) {
    setName("inspectImageView");
    setHorizontalAlignment(CENTER);
    setPreferredSize(new Dimension(820, 490));
    source = initial;
    setCursor(Cursor.getPredefinedCursor(Cursor.MOVE_CURSOR));
    setToolTipText("2D image: drag to pan, scroll to zoom, double-click to reset");
    MouseAdapter mouse =
        new MouseAdapter() {
          public void mousePressed(MouseEvent e) {
            if (SwingUtilities.isLeftMouseButton(e)) anchor = e.getPoint();
          }

          public void mouseReleased(MouseEvent e) {
            anchor = null;
          }

          public void mouseDragged(MouseEvent e) {
            if (anchor != null) {
              panX += e.getX() - anchor.x;
              panY += e.getY() - anchor.y;
              anchor = e.getPoint();
              constrain();
              repaint();
            }
          }

          public void mouseClicked(MouseEvent e) {
            if (SwingUtilities.isLeftMouseButton(e) && e.getClickCount() == 2) reset();
          }

          public void mouseWheelMoved(MouseWheelEvent e) {
            double before = zoom;
            zoom = Math.max(.5, Math.min(4, zoom * Math.pow(1.12, -e.getPreciseWheelRotation())));
            double ratio = zoom / before;
            panX = (panX - (e.getX() - getWidth() / 2.0)) * ratio + e.getX() - getWidth() / 2.0;
            panY = (panY - (e.getY() - getHeight() / 2.0)) * ratio + e.getY() - getHeight() / 2.0;
            constrain();
            e.consume();
            repaint();
          }
        };
    addMouseListener(mouse);
    addMouseMotionListener(mouse);
    addMouseWheelListener(mouse);
    publish();
  }

  public void setIcon(Icon icon) {
    super.setIcon(icon);
    Object original = getClientProperty("artworkSourceImage");
    if (original instanceof Image) source = (Image) original;
    else if (icon instanceof ImageIcon) source = ((ImageIcon) icon).getImage();
    repaint();
  }

  Image sourceImage() {
    return source;
  }

  void reset() {
    zoom = 1;
    panX = panY = 0;
    anchor = null;
    publish();
    repaint();
  }

  private void constrain() {
    panX = Math.max(-getWidth() * .8, Math.min(getWidth() * .8, panX));
    panY = Math.max(-getHeight() * .8, Math.min(getHeight() * .8, panY));
    publish();
  }

  private void publish() {
    putClientProperty("inspectZoom", zoom);
    putClientProperty("inspectPanX", panX);
    putClientProperty("inspectPanY", panY);
  }

  protected void paintComponent(Graphics graphics) {
    if (source == null || source.getWidth(null) <= 0 || source.getHeight(null) <= 0) {
      super.paintComponent(graphics);
      return;
    }
    Graphics2D g = (Graphics2D) graphics.create();
    g.setRenderingHint(
        RenderingHints.KEY_INTERPOLATION, RenderingHints.VALUE_INTERPOLATION_BICUBIC);
    g.setRenderingHint(RenderingHints.KEY_RENDERING, RenderingHints.VALUE_RENDER_QUALITY);
    double fit =
        Math.min(
            Math.max(1, getWidth() - 32) / (double) source.getWidth(null),
            Math.max(1, getHeight() - 24) / (double) source.getHeight(null));
    double w = source.getWidth(null) * fit * zoom, h = source.getHeight(null) * fit * zoom;
    g.translate((getWidth() - w) / 2 + panX, (getHeight() - h) / 2 + panY);
    g.scale(fit * zoom, fit * zoom);
    g.drawImage(source, 0, 0, null);
    g.dispose();
  }
}
