package blahblah;

import blahblah.hGui.*;
import java.awt.*;
import java.awt.event.*;
import java.util.ArrayList;
import java.util.Comparator;
import java.util.List;
import java.util.Set;
import java.util.concurrent.ConcurrentHashMap;
import java.util.stream.Collectors;
import javax.swing.*;

/** Artwork Service: focused feature implementation. */
final class ArtworkService {
  private final hGui app;

  ArtworkService(hGui app) {
    this.app = app;
  }

  void refreshAfterCatalogLoad() {
    app.catalogCaseCollectionCache.clear();
    app.collectionCache.clear();
    if (app.currentCase != null) {
      app.crateImage = app.containerBrowserScreen.getContainerImage(app.currentCase);
      app.containerBrowserScreen.updateCrateImageDisplay();
    }
    if (!app.marketInitialized) {
      app.containerBrowserScreen.rebuildCaseBoxes();
      if (app.mainTabs != null && app.mainTabs.getSelectedIndex() == 1)
        app.armouryScreen.refreshArmouryTab();
      return;
    }
  }

  void refreshForLoadedSkinImage() {
    if (app.mainTabs == null) return;
    switch (app.mainTabs.getSelectedIndex()) {
      case 1:
        app.armouryTabPanel.repaint();
        break;
      case 2:
        app.inventoryTabPanel.repaint();
        break;
      case 3:
        app.tradeUpTabPanel.repaint();
        break;
      case 4:
        app.marketTabPanel.repaint();
        break;
      case 5:
        app.loadoutScreen.refreshLoadoutTab();
        break;
      case 6:
        app.generalScreen.refreshGeneralTab();
        break;
      default:
        app.bundledArtwork.refreshMainUI();
    }
  }

  void registerPendingRemoteImageLabel(String skinName, JLabel label) {
    app.artworkService.registerPendingRemoteImageLabel(skinName, label, 180, 104);
  }

  void registerPendingRemoteImageLabel(String skinName, JLabel label, int width, int height) {
    Object previous = label.getClientProperty("remoteImageRequestKey");
    if (previous instanceof String && !skinName.equals(previous)) {
      Set<JLabel> old = app.pendingRemoteImageLabels.get((String) previous);
      if (old != null) {
        old.remove(label);
        if (old.isEmpty()) app.pendingRemoteImageLabels.remove((String) previous, old);
      }
    }
    label.putClientProperty("remoteImageRequestKey", skinName);
    label.putClientProperty("remoteImageWidth", width);
    label.putClientProperty("remoteImageHeight", height);
    Image cached = app.imageRepository.get(skinName);
    if (cached != null) {
      label.putClientProperty("artworkSourceImage", cached);
      label.setIcon(app.marketItemCards.createContainedImageLabel(cached, width, height).getIcon());
      label.setText("");
      return;
    }
    app.pendingRemoteImageLabels
        .computeIfAbsent(skinName, ignored -> ConcurrentHashMap.newKeySet())
        .add(label);
    cached = app.imageRepository.get(skinName);
    if (cached != null) app.artworkService.updatePendingRemoteImageLabels(skinName, cached);
  }

  boolean updatePendingRemoteImageLabels(String skinName, Image image) {
    Set<JLabel> labels = app.pendingRemoteImageLabels.remove(skinName);
    if (labels == null || labels.isEmpty()) return false;
    for (JLabel label : labels) {
      Object requested = label.getClientProperty("remoteImageRequestKey");
      if (requested != null && !skinName.equals(requested)) continue;
      Object widthValue = label.getClientProperty("remoteImageWidth");
      Object heightValue = label.getClientProperty("remoteImageHeight");
      int width = widthValue instanceof Integer ? (Integer) widthValue : 196;
      int height = heightValue instanceof Integer ? (Integer) heightValue : 138;
      label.putClientProperty("artworkSourceImage", image);
      label.setIcon(app.marketItemCards.createContainedImageLabel(image, width, height).getIcon());
      label.setText("");
      label.putClientProperty("skinArtworkPlaceholder", false);
      label.revalidate();
      label.repaint();
    }
    return true;
  }

  void updateMarketplacePriceLabels(String skinName) {
    String browseKey = app.marketGroupingService.getMarketplaceBrowseKey(skinName);
    Set<JLabel> labels = app.marketplacePriceLabels.get(browseKey);
    if (labels == null || labels.isEmpty()) return;
    ArrayList<MarketListing> listings =
        app.marketGroupingService.getCombinedBrowseListings(browseKey);
    for (JLabel label : labels) {
      boolean statTrak = Boolean.TRUE.equals(label.getClientProperty("marketStatTrak"));
      label.setText(
          app.marketItemCards.getMarketplacePriceSummaryText(listings, statTrak, browseKey));
    }
  }

  String artworkAliasKey(String name) {
    return java.text.Normalizer.normalize(name, java.text.Normalizer.Form.NFD)
        .toLowerCase(java.util.Locale.ROOT)
        .replaceAll("\\p{M}+", "")
        .replaceAll("[^a-z0-9]", "");
  }

  String canonicalArtworkName(String name) {
    if (name == null) return "";
    String clean =
        app.catalogParsingService
            .normalizeCatalogSkinName(app.catalogParsingService.stripSouvenirPrefix(name))
            .replaceAll("\\s*\\(Blue Gem [^)]+\\)$", "")
            .trim();
    // Preserve genuine distinct names such as Sunset Storm 壱 / 弐 before lossy punctuation aliases.
    if (app.skinCatalog.containsKey(clean) || app.agentCatalog.containsKey(clean)) return clean;
    return app.artworkNameAliases.getOrDefault(app.artworkService.artworkAliasKey(clean), clean);
  }

  String artworkSkin(String key) {
    int wear = key.indexOf(hGui.WEAR_IMAGE_SEPARATOR);
    return wear < 0 ? key : key.substring(0, wear);
  }

  String artworkWear(String key) {
    int wear = key.indexOf(hGui.WEAR_IMAGE_SEPARATOR);
    return wear < 0 ? null : key.substring(wear + hGui.WEAR_IMAGE_SEPARATOR.length());
  }

  String wearImageAbbreviation(String condition) {
    if (condition == null) return null;
    switch (condition) {
      case "Factory New":
        return "fn";
      case "Minimal Wear":
        return "mw";
      case "Field-Tested":
        return "ft";
      case "Well-Worn":
        return "ww";
      case "Battle-Scarred":
        return "bs";
      default:
        return null;
    }
  }

  String getSkinArtworkKey(String skin, String condition) {
    String name = app.artworkService.canonicalArtworkName(skin);
    return app.artworkService.wearImageAbbreviation(condition) == null
        ? name
        : name + hGui.WEAR_IMAGE_SEPARATOR + condition;
  }

  SkinMetadata getArtworkMetadata(String skin) {
    SkinMetadata metadata = app.skinCatalog.get(skin);
    if (metadata == null) metadata = app.agentCatalog.get(skin);
    if (metadata == null) metadata = app.artworkService.findDopplerVariantMetadata(skin);
    if (metadata == null) {
      int variant = skin.lastIndexOf(" (");
      if (variant > 0) metadata = app.skinCatalog.get(skin.substring(0, variant));
    }
    return metadata;
  }

  String getWearImageUrl(String skin, String condition) {
    String name = app.artworkService.canonicalArtworkName(skin),
        abbreviation = app.artworkService.wearImageAbbreviation(condition);
    if (abbreviation == null || app.floatRules.isVanillaKnife(name)) return null;
    String verified = VerifiedWearArtwork.url(name, condition);
    if (verified != null) return verified;
    String path = app.wearImageBasePaths.get(name);
    // An unspecified Doppler uses exactly the same default phase as the standard catalog artwork.
    if (path == null && name.endsWith("Doppler"))
      path = app.wearImageBasePaths.get(name + " (Phase 1)");
    return path == null ? null : hGui.WEAR_IMAGE_ROOT + path + "/" + abbreviation + ".png";
  }

  Image getRemoteSkinArtwork(String skin, String condition, boolean notifyGameViews) {
    String name = app.artworkService.canonicalArtworkName(skin),
        key = app.artworkService.getSkinArtworkKey(name, condition);
    Image cached = app.imageRepository.get(key);
    if (cached != null) return cached;
    SkinMetadata metadata = app.artworkService.getArtworkMetadata(name);
    String standardUrl = metadata == null ? null : metadata.imageUrl;
    String wearUrl = app.artworkService.getWearImageUrl(name, condition);
    String primary = wearUrl != null ? wearUrl : standardUrl;
    if (primary != null && primary.startsWith("https://"))
      app.imageRepository.loadRemote(
          key, primary, notifyGameViews, wearUrl == null ? null : standardUrl);
    cached = app.imageRepository.get(key);
    return cached != null ? cached : app.imageRepository.get(name);
  }

  Image getSkinImageFromName(String skin, String condition) {
    if (skin != null && skin.endsWith(" | Default"))
      return app.cs2EquipmentScreens.defaultWeaponImage(skin);
    CaseType ct = app.exchangeStockService.exchangeContainer(skin);
    if (ct != null) return app.imageRepository.get("case-selector-" + ct.id);
    return app.artworkService.getRemoteSkinArtwork(skin, condition, true);
  }

  Image getSkinImageFromName(String skin, String condition, JLabel target, int width, int height) {
    if (skin != null && skin.endsWith(" | Default")) {
      Image im = app.cs2EquipmentScreens.defaultWeaponImage(skin);
      String id = "cs2-stock-" + skin.substring(0, skin.length() - 10);
      app.artworkService.registerPendingRemoteImageLabel(id, target, width, height);
      if (im != null) {
        target.putClientProperty("artworkSourceImage", im);
        target.setIcon(new ImageIcon(app.cs2Screens.scaleCs2Image(im, width, height)));
        target.setText("");
      } else {
        target.setText("Loading image…");
        String weapon = skin.substring(0, skin.length() - 10);
        String url = hGui.CS2_DEFAULT_WEAPONS.get(weapon);
        if (url != null) app.imageRepository.loadRemote(id, url, false);
      }
      target.putClientProperty("skinArtworkKey", id);
      return im;
    }
    CaseType ct = app.exchangeStockService.exchangeContainer(skin);
    if (ct != null) {
      app.cs2Screens.bindCs2SupplyArtwork(ct, false, target, width, height);
      return app.imageRepository.get("case-selector-" + ct.id);
    }
    String key = app.artworkService.getSkinArtworkKey(skin, condition);
    Image image = app.artworkService.getRemoteSkinArtwork(skin, condition, true);
    if (image != null) {
      target.putClientProperty("artworkSourceImage", image);
      target.setIcon(app.marketItemCards.createContainedImageLabel(image, width, height).getIcon());
      target.setText("");
      target.putClientProperty("skinArtworkPlaceholder", false);
    } else {
      Object previous = target.getClientProperty("remoteImageRequestKey");
      if (previous != null && !key.equals(previous)) target.setIcon(null);
      if (target.getIcon() == null) {
        target.setIcon(
            app.marketItemCards
                .createContainedImageLabel(
                    app.containerBrowserScreen.createItemPlaceholderImage(), width, height)
                .getIcon());
        target.putClientProperty("skinArtworkPlaceholder", true);
      }
      target.setText("Loading image…");
      target.setForeground(Theme.TEXT_DIM);
    }
    // Register the wear key even when a provisional standard image is already visible.
    app.artworkService.registerPendingRemoteImageLabel(key, target, width, height);
    target.putClientProperty("skinArtworkKey", key);
    target.setToolTipText(null);
    return image;
  }

  void refreshInventoryItemArtwork(InventoryItem item) {
    if (item == null || app.imageRepository == null) return;
    Image image = app.artworkService.getSkinImageFromName(item.name, item.condition);
    if (image != null && (item.image == null || item.image.getImage() != image)) {
      item.image = new ImageIcon(image);
      item.thumb110x75 = null;
      item.thumb130x88 = null;
    }
  }

  Image getSkinImageFromName(String skinName) {
    if (skinName != null && skinName.endsWith(" | Default"))
      return app.cs2EquipmentScreens.defaultWeaponImage(skinName);
    CaseType ct = app.exchangeStockService.exchangeContainer(skinName);
    if (ct != null) return app.imageRepository.get("case-selector-" + ct.id);
    return app.artworkService.getRemoteSkinArtwork(skinName, null, true);
  }

  SkinMetadata findDopplerVariantMetadata(String catalogName) {
    if (!catalogName.contains("Doppler")
        || catalogName.contains("Phase")
        || catalogName.contains("Sapphire")
        || catalogName.contains("Ruby")
        || catalogName.contains("Black Pearl")
        || catalogName.contains("Emerald")) {
      return null;
    }
    String prefix = catalogName + " (";
    List<String> variants =
        app.skinCatalog.keySet().stream()
            .filter(name -> name.regionMatches(true, 0, prefix, 0, prefix.length()))
            .sorted(
                Comparator.comparing((String name) -> !name.contains("(Phase 1)"))
                    .thenComparing(String.CASE_INSENSITIVE_ORDER))
            .collect(Collectors.toList());
    return variants.isEmpty() ? null : app.skinCatalog.get(variants.get(0));
  }

  Image getSkinImageFromName(String skinName, JLabel target, int width, int height) {
    return app.artworkService.getSkinImageFromName(skinName, null, target, width, height);
  }
}
