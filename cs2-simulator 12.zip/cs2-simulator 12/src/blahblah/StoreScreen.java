package blahblah;

import blahblah.hGui.*;
import java.awt.*;
import javax.swing.*;

/** One Store destination; legacy internal tab indices are retained for saved UI compatibility. */
final class StoreScreen {
  private final hGui app;
  JTabbedPane sections;
  private JPanel armoury;
  private JPanel tools;
  private JPanel home;

  StoreScreen(hGui app) {
    this.app = app;
  }

  void install() {
    app.mainTabs.setComponentAt(4, new JPanel());
    sections = new JTabbedPane();
    sections.setName("storeSections");
    sections.setBackground(new Color(35, 43, 47));
    sections.setForeground(Color.WHITE);
    sections.setBorder(BorderFactory.createEmptyBorder());
    sections.setUI(
        new javax.swing.plaf.basic.BasicTabbedPaneUI() {
          protected int calculateTabAreaHeight(int placement, int runs, int height) {
            return 0;
          }

          protected void paintTabArea(Graphics g, int placement, int selected) {}

          protected void paintContentBorder(Graphics g, int placement, int selected) {}
        });
    home = new JPanel(new BorderLayout());
    sections.addTab("HOME", home);
    refreshHome();
    sections.addTab("MARKET", app.marketTabPanel);
    tools = new JPanel(new BorderLayout());
    sections.addTab("TOOLS", tools);
    armoury = ArmouryBrowserScreen.scene();
    sections.addTab("ARMOURY", armoury);
    JPanel root = new JPanel(new BorderLayout());
    root.setName("cs2Store");
    JPanel navigation = new JPanel(new FlowLayout(FlowLayout.CENTER, 8, 5));
    navigation.setBackground(new Color(35, 43, 47));
    for (int n = 0; n < sections.getTabCount(); n++) {
      final int index = n;
      JButton button =
          app.cs2Screens.cs2Button(
              sections.getTitleAt(n), false, e -> sections.setSelectedIndex(index));
      button.setName("storeSection" + sections.getTitleAt(n));
      navigation.add(button);
    }
    Runnable colors =
        () -> {
          for (int n = 0; n < navigation.getComponentCount(); n++) {
            JButton button = (JButton) navigation.getComponent(n);
            button.setBackground(
                n == sections.getSelectedIndex() ? new Color(53, 75, 86) : new Color(35, 43, 47));
            button.setForeground(
                n == sections.getSelectedIndex() ? new Color(149, 207, 232) : Color.WHITE);
          }
        };
    sections.addChangeListener(e -> colors.run());
    root.add(navigation, BorderLayout.NORTH);
    root.add(sections);
    app.mainTabs.setComponentAt(4, root);
    app.mainTabs.setTitleAt(4, "Store");
    sections.setSelectedIndex(0);
    colors.run();
    sections.addChangeListener(
        e -> {
          if (sections.getSelectedIndex() == 0) refreshHome();
          if (sections.getSelectedIndex() == 2) {
            tools.removeAll();
            tools.add(app.inventoryToolsService.storePanel());
            tools.revalidate();
            tools.repaint();
          }
          if (sections.getSelectedIndex() == 3) armouryHome();
        });
  }

  void open(String section) {
    if ("MISC".equals(section)) {
      app.navigationService.navigateCs2Top(6);
      return;
    }
    app.pageTransitions.begin();
    // Constructor-bypassing test fixtures and the legacy shell need no reparenting.
    if (sections != null) {
      for (int i = 0; i < sections.getTabCount(); i++)
        if (sections.getTitleAt(i).equals(section)) sections.setSelectedIndex(i);
    }
    if (app.mainTabs != null) app.mainTabs.setSelectedIndex(4);
    if ("ARMOURY".equals(section) && armoury != null) armouryHome();
    if ("HOME".equals(section)) refreshHome();
    app.pageTransitions.finish();
  }

  void refreshHome() {
    if (home == null) return;
    home.removeAll();
    home.add(app.carePackages.home());
    home.revalidate();
    home.repaint();
  }

  JPanel armouryHost() {
    return armoury;
  }

  void armouryHome() {
    new ArmouryBrowserScreen(app, armoury).render(app.lastArmouryTabIndex);
  }
}
