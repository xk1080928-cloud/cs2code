package blahblah;

import blahblah.hGui.*;
import java.awt.*;
import java.awt.event.*;
import java.util.ArrayList;
import javax.swing.*;

/** Offer Gallery Screens: focused feature implementation. */
final class OfferGalleryScreens {
  private final hGui app;

  OfferGalleryScreens(hGui app) {
    this.app = app;
  }

  void showMarketplaceOfferWindowCapsule(
      String skinName, String conditionToken, MarketplaceOfferAggregate offer, JFrame parent) {
    JFrame frame =
        app.offerNeonAndMirageScreens.createMarketplaceFrame(
            offer, skinName, conditionToken, parent, new Color(26, 12, 12));
    frame.add(
        app.offerHeroAndSellerScreens.createOfferHeader(
            offer.marketplaceName + " Capsules",
            skinName + "  ·  sealed deal cards",
            offer,
            "⚡ INSTANT"),
        BorderLayout.NORTH);

    JPanel list = new JPanel();
    list.setLayout(new BoxLayout(list, BoxLayout.Y_AXIS));
    list.setBackground(new Color(26, 12, 12));
    list.setBorder(BorderFactory.createEmptyBorder(16, 16, 16, 16));

    for (MarketListing listing : app.marketOfferService.getSortedOfferListings(offer)) {
      list.add(app.offerGalleryScreens.createCapsulePill(listing, offer, frame));
      list.add(Box.createRigidArea(new Dimension(0, 10)));
    }

    JScrollPane scroll = new JScrollPane(list);
    scroll.setBorder(null);
    scroll.getViewport().setBackground(new Color(26, 12, 12));
    scroll.getVerticalScrollBar().setUnitIncrement(20);
    frame.add(scroll, BorderLayout.CENTER);
    frame.setVisible(true);
  }

  JPanel createCapsulePill(MarketListing listing, MarketplaceOfferAggregate offer, JFrame parent) {
    JPanel pill = new JPanel(new BorderLayout(0, 0));
    pill.setBackground(new Color(38, 18, 18));
    pill.setMaximumSize(new Dimension(Integer.MAX_VALUE, 80));
    pill.setBorder(
        BorderFactory.createCompoundBorder(
            BorderFactory.createLineBorder(new Color(120, 40, 40), 1),
            BorderFactory.createEmptyBorder(0, 0, 0, 0)));

    // Left price blob
    JPanel priceBg =
        new JPanel(new BorderLayout()) {
          @Override
          protected void paintComponent(Graphics g) {
            Graphics2D g2 = (Graphics2D) g.create();
            g2.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
            g2.setColor(offer.accent);
            g2.fillRect(0, 0, getWidth(), getHeight());
            g2.dispose();
          }
        };
    priceBg.setOpaque(false);
    priceBg.setPreferredSize(new Dimension(120, 0));
    JLabel priceLabel = new JLabel("$" + String.format("%.2f", listing.getPrice()));
    priceLabel.setFont(new Font("Consolas", Font.BOLD, 20));
    priceLabel.setForeground(new Color(15, 10, 10));
    priceLabel.setHorizontalAlignment(SwingConstants.CENTER);
    priceBg.add(priceLabel, BorderLayout.CENTER);

    // Center info
    JPanel info = new JPanel(new GridLayout(2, 1, 0, 4));
    info.setOpaque(false);
    info.setBorder(BorderFactory.createEmptyBorder(12, 16, 12, 16));
    JLabel seller = new JLabel(listing.sellerName != null ? listing.sellerName : "Seller");
    seller.setFont(new Font("Arial", Font.BOLD, 14));
    seller.setForeground(Color.WHITE);
    JLabel detail =
        new JLabel(
            app.itemMetadataService.isAgentSkin(listing.item.name)
                ? "Agent"
                : ("Float "
                    + String.format("%.5f", listing.item.itemFloat)
                    + "  ·  "
                    + app.marketOfferService.formatMarketPatternText(listing)));
    detail.setFont(new Font("Consolas", Font.PLAIN, 11));
    detail.setForeground(new Color(180, 100, 100));
    info.add(seller);
    info.add(detail);

    // CTA
    JButton btn =
        app.offerNeonAndMirageScreens.createMarketplaceActionButton(
            listing, offer, parent, "GRAB IT");
    btn.setPreferredSize(new Dimension(110, 80));
    btn.setFont(new Font("Arial", Font.BOLD, 13));

    pill.add(priceBg, BorderLayout.WEST);
    pill.add(info, BorderLayout.CENTER);
    pill.add(btn, BorderLayout.EAST);
    return pill;
  }

  void showMarketplaceOfferWindowPriceLadder(
      String skinName, String conditionToken, MarketplaceOfferAggregate offer, JFrame parent) {
    JFrame frame =
        app.offerNeonAndMirageScreens.createMarketplaceFrame(
            offer, skinName, conditionToken, parent, new Color(20, 16, 8));
    frame.add(
        app.offerHeroAndSellerScreens.createOfferHeader(
            offer.marketplaceName + " Ladder",
            conditionToken + "  ·  price-ranked depth",
            offer,
            "ORDER BOOK"),
        BorderLayout.NORTH);

    ArrayList<MarketListing> sorted = app.marketOfferService.getSortedOfferListings(offer);
    double minP = sorted.stream().mapToDouble(l -> l.getPrice()).min().orElse(0);
    double maxP = sorted.stream().mapToDouble(l -> l.getPrice()).max().orElse(1);

    JPanel ladder = new JPanel();
    ladder.setLayout(new BoxLayout(ladder, BoxLayout.Y_AXIS));
    ladder.setBackground(new Color(20, 16, 8));
    ladder.setBorder(BorderFactory.createEmptyBorder(16, 16, 16, 16));

    int rank = 1;
    for (MarketListing listing : sorted) {
      ladder.add(
          app.offerGalleryScreens.createLadderRung(rank++, listing, offer, frame, minP, maxP));
      ladder.add(Box.createRigidArea(new Dimension(0, 3)));
    }

    JScrollPane scroll = new JScrollPane(ladder);
    scroll.setBorder(null);
    scroll.getViewport().setBackground(new Color(20, 16, 8));
    scroll.getVerticalScrollBar().setUnitIncrement(20);
    frame.add(scroll, BorderLayout.CENTER);
    frame.setVisible(true);
  }

  JPanel createLadderRung(
      int rank,
      MarketListing listing,
      MarketplaceOfferAggregate offer,
      JFrame parent,
      double minP,
      double maxP) {
    double pct = maxP > minP ? (listing.getPrice() - minP) / (maxP - minP) : 0;
    final double fillPct = pct;

    JPanel rung =
        new JPanel(new BorderLayout(0, 0)) {
          @Override
          protected void paintComponent(Graphics g) {
            super.paintComponent(g);
            // Fill bar from left indicating price depth
            int fillW = (int) (getWidth() * 0.6 * fillPct);
            g.setColor(new Color(60, 40, 10));
            g.fillRect(0, 0, fillW, getHeight());
          }
        };
    rung.setBackground(new Color(26, 20, 10));
    rung.setMaximumSize(new Dimension(Integer.MAX_VALUE, 44));
    rung.setBorder(
        BorderFactory.createCompoundBorder(
            BorderFactory.createMatteBorder(0, 0, 1, 0, new Color(50, 38, 16)),
            BorderFactory.createEmptyBorder(8, 14, 8, 14)));

    JLabel rankLbl = new JLabel(String.format("B%03d", rank));
    rankLbl.setFont(new Font("Consolas", Font.BOLD, 12));
    rankLbl.setForeground(new Color(160, 120, 40));
    rankLbl.setPreferredSize(new Dimension(54, 0));

    boolean isAgentLadder = app.itemMetadataService.isAgentSkin(listing.item.name);
    JLabel info =
        new JLabel(
            (listing.sellerName != null ? listing.sellerName : "Seller")
                + (isAgentLadder
                    ? ""
                    : ("   Float: "
                        + String.format("%.5f", listing.item.itemFloat)
                        + "   "
                        + app.marketOfferService.formatMarketPatternText(listing))));
    info.setFont(new Font("Consolas", Font.PLAIN, 12));
    info.setForeground(new Color(200, 170, 100));

    JPanel right = new JPanel(new BorderLayout(8, 0));
    right.setOpaque(false);
    JLabel price = new JLabel("$" + String.format("%.2f", listing.getPrice()));
    price.setFont(new Font("Consolas", Font.BOLD, 16));
    price.setForeground(offer.accent);
    price.setHorizontalAlignment(SwingConstants.RIGHT);
    JButton btn =
        app.offerNeonAndMirageScreens.createMarketplaceActionButton(listing, offer, parent, "BID");
    btn.setPreferredSize(new Dimension(70, 32));
    right.add(price, BorderLayout.CENTER);
    right.add(btn, BorderLayout.EAST);

    rung.add(rankLbl, BorderLayout.WEST);
    rung.add(info, BorderLayout.CENTER);
    rung.add(right, BorderLayout.EAST);
    return rung;
  }

  void showMarketplaceOfferWindowPosterWall(
      String skinName, String conditionToken, MarketplaceOfferAggregate offer, JFrame parent) {
    JFrame frame =
        app.offerNeonAndMirageScreens.createMarketplaceFrame(
            offer, skinName, conditionToken, parent, new Color(8, 22, 24));
    frame.add(
        app.offerHeroAndSellerScreens.createOfferHeader(
            offer.marketplaceName + " Wall", conditionToken + "  ·  drop wall", offer, "FLIP WALL"),
        BorderLayout.NORTH);

    JPanel wall = new JPanel(new GridLayout(0, 5, 12, 12));
    wall.setBackground(new Color(8, 22, 24));
    wall.setBorder(BorderFactory.createEmptyBorder(18, 18, 18, 18));
    for (MarketListing listing : app.marketOfferService.getSortedOfferListings(offer)) {
      wall.add(app.offerGalleryScreens.createPosterCard(listing, offer, frame));
    }

    JScrollPane scroll = new JScrollPane(wall);
    scroll.setBorder(null);
    scroll.getViewport().setBackground(new Color(8, 22, 24));
    scroll.getVerticalScrollBar().setUnitIncrement(20);
    frame.add(scroll, BorderLayout.CENTER);
    frame.setVisible(true);
  }

  JPanel createPosterCard(MarketListing listing, MarketplaceOfferAggregate offer, JFrame parent) {
    JPanel card = new JPanel(new BorderLayout(0, 0));
    card.setBackground(new Color(12, 32, 36));
    card.setBorder(BorderFactory.createLineBorder(new Color(0, 100, 110), 1));
    card.setCursor(java.awt.Cursor.getPredefinedCursor(java.awt.Cursor.HAND_CURSOR));
    card.addMouseListener(
        new MouseAdapter() {
          @Override
          public void mouseClicked(MouseEvent e) {
            app.marketOfferService.purchaseMarketplaceListing(listing, offer, parent);
          }

          @Override
          public void mouseEntered(MouseEvent e) {
            card.setBackground(new Color(16, 42, 46));
          }

          @Override
          public void mouseExited(MouseEvent e) {
            card.setBackground(new Color(12, 32, 36));
          }
        });

    // Top area — seller info
    JPanel top = new JPanel(new BorderLayout(0, 4));
    top.setOpaque(false);
    top.setBorder(BorderFactory.createEmptyBorder(14, 14, 12, 14));
    JLabel seller = new JLabel(listing.sellerName != null ? listing.sellerName : "SELLER");
    seller.setFont(new Font("Arial", Font.BOLD, 14));
    seller.setForeground(Color.WHITE);
    boolean isAgentPoster = app.itemMetadataService.isAgentSkin(listing.item.name);
    JLabel float_ =
        new JLabel(
            isAgentPoster ? "Agent" : ("Float  " + String.format("%.6f", listing.item.itemFloat)));
    float_.setFont(new Font("Consolas", Font.PLAIN, 11));
    float_.setForeground(new Color(0, 200, 210));
    JLabel pattern =
        new JLabel(
            isAgentPoster
                ? ""
                : ("Pattern  " + app.marketOfferService.formatMarketPatternText(listing)));
    pattern.setFont(new Font("Consolas", Font.PLAIN, 11));
    pattern.setForeground(
        app.marketOfferService.getMarketPatternColor(listing, new Color(0, 170, 180)));
    JPanel topText = new JPanel(new GridLayout(3, 1, 0, 3));
    topText.setOpaque(false);
    topText.add(seller);
    topText.add(float_);
    topText.add(pattern);
    top.add(topText, BorderLayout.CENTER);

    // Bottom — price block full width
    JPanel bottom = new JPanel(new BorderLayout(0, 0));
    bottom.setBackground(offer.accent);
    bottom.setBorder(BorderFactory.createEmptyBorder(12, 14, 12, 14));
    JLabel price = new JLabel("$" + String.format("%.2f", listing.getPrice()));
    price.setFont(new Font("Consolas", Font.BOLD, 26));
    price.setForeground(new Color(10, 20, 22));
    JButton btn =
        app.offerNeonAndMirageScreens.createMarketplaceActionButton(listing, offer, parent, "BUY");
    btn.setBackground(new Color(8, 18, 20));
    btn.setForeground(offer.accent);
    btn.setFont(new Font("Arial", Font.BOLD, 13));
    bottom.add(price, BorderLayout.CENTER);
    bottom.add(btn, BorderLayout.EAST);

    card.add(top, BorderLayout.CENTER);
    card.add(bottom, BorderLayout.SOUTH);
    return card;
  }

  void showMarketplaceOfferWindowConcierge(
      String skinName, String conditionToken, MarketplaceOfferAggregate offer, JFrame parent) {
    JFrame frame =
        app.offerNeonAndMirageScreens.createMarketplaceFrame(
            offer, skinName, conditionToken, parent, new Color(22, 14, 28));
    frame.add(
        app.offerHeroAndSellerScreens.createOfferHeader(
            offer.marketplaceName + " Concierge",
            skinName + "  ·  guided seller lane",
            offer,
            "✦ HALO SERVICE"),
        BorderLayout.NORTH);

    ArrayList<MarketListing> sorted = app.marketOfferService.getSortedOfferListings(offer);

    // Left — seller cards
    JPanel left = new JPanel();
    left.setLayout(new BoxLayout(left, BoxLayout.Y_AXIS));
    left.setBackground(new Color(22, 14, 28));
    left.setBorder(BorderFactory.createEmptyBorder(16, 16, 16, 16));
    for (MarketListing listing : sorted) {
      left.add(app.offerGalleryScreens.createConciergeCard(listing, offer, frame));
      left.add(Box.createRigidArea(new Dimension(0, 10)));
    }

    JScrollPane scroll = new JScrollPane(left);
    scroll.setBorder(null);
    scroll.getViewport().setBackground(new Color(22, 14, 28));
    scroll.getVerticalScrollBar().setUnitIncrement(20);

    // Right — trust panel
    JPanel right = new JPanel();
    right.setLayout(new BoxLayout(right, BoxLayout.Y_AXIS));
    right.setPreferredSize(new Dimension(230, 0));
    right.setBackground(new Color(30, 20, 38));
    right.setBorder(
        BorderFactory.createCompoundBorder(
            BorderFactory.createMatteBorder(0, 1, 0, 0, new Color(80, 50, 110)),
            BorderFactory.createEmptyBorder(20, 18, 20, 18)));

    JLabel trustHeader = new JLabel("TRUST SCORE");
    trustHeader.setFont(new Font("Arial", Font.BOLD, 11));
    trustHeader.setForeground(new Color(160, 130, 200));
    JLabel stars = new JLabel(app.offerNeonAndMirageScreens.buildStars(offer.rating));
    stars.setFont(new Font("Arial", Font.BOLD, 22));
    stars.setForeground(new Color(220, 180, 80));
    JLabel ratingNum = new JLabel(String.format("%.1f out of 5.0", offer.rating));
    ratingNum.setFont(new Font("Arial", Font.PLAIN, 12));
    ratingNum.setForeground(new Color(180, 160, 210));

    right.add(trustHeader);
    right.add(Box.createRigidArea(new Dimension(0, 8)));
    right.add(stars);
    right.add(ratingNum);
    right.add(Box.createRigidArea(new Dimension(0, 20)));
    right.add(
        app.offerHeroAndSellerScreens.createInfoBlock("REVIEWS", offer.reviews, offer.accent));
    right.add(Box.createRigidArea(new Dimension(0, 14)));
    right.add(
        app.offerHeroAndSellerScreens.createInfoBlock(
            "DELIVERY", offer.marketplaceType, offer.accent));
    right.add(Box.createRigidArea(new Dimension(0, 14)));
    right.add(
        app.offerHeroAndSellerScreens.createInfoBlock(
            "LISTINGS", String.valueOf(offer.listingCount), offer.accent));
    right.add(Box.createRigidArea(new Dimension(0, 14)));
    right.add(
        app.offerHeroAndSellerScreens.createInfoBlock(
            "MARKET", offer.marketplaceName, offer.accent));

    JSplitPane split = new JSplitPane(JSplitPane.HORIZONTAL_SPLIT, scroll, right);
    split.setResizeWeight(0.76);
    split.setDividerSize(3);
    split.setBorder(null);
    frame.add(split, BorderLayout.CENTER);
    frame.setVisible(true);
  }

  JPanel createConciergeCard(
      MarketListing listing, MarketplaceOfferAggregate offer, JFrame parent) {
    JPanel card = new JPanel(new BorderLayout(14, 0));
    card.setBackground(new Color(30, 20, 40));
    card.setMaximumSize(new Dimension(Integer.MAX_VALUE, 78));
    card.setBorder(
        BorderFactory.createCompoundBorder(
            BorderFactory.createLineBorder(new Color(80, 50, 110), 1),
            BorderFactory.createEmptyBorder(14, 16, 14, 16)));

    JPanel info = new JPanel(new GridLayout(2, 1, 0, 4));
    info.setOpaque(false);
    JLabel name = new JLabel("✦  " + (listing.sellerName != null ? listing.sellerName : "Seller"));
    name.setFont(new Font("Arial", Font.BOLD, 14));
    name.setForeground(Color.WHITE);
    boolean isAgentConcierge = app.itemMetadataService.isAgentSkin(listing.item.name);
    JLabel detail =
        new JLabel(
            isAgentConcierge
                ? "Agent"
                : ("Float "
                    + String.format("%.6f", listing.item.itemFloat)
                    + "   ·   Pattern "
                    + app.marketOfferService.formatMarketPatternText(listing)));
    detail.setFont(new Font("Consolas", Font.PLAIN, 11));
    detail.setForeground(new Color(160, 130, 200));
    info.add(name);
    info.add(detail);

    JPanel right = new JPanel(new BorderLayout(10, 0));
    right.setOpaque(false);
    JLabel price = new JLabel("$" + String.format("%.2f", listing.getPrice()));
    price.setFont(new Font("Consolas", Font.BOLD, 20));
    price.setForeground(new Color(220, 185, 80));
    price.setHorizontalAlignment(SwingConstants.RIGHT);
    JButton btn =
        app.offerNeonAndMirageScreens.createMarketplaceActionButton(
            listing, offer, parent, "RESERVE");
    btn.setPreferredSize(new Dimension(110, 36));
    right.add(price, BorderLayout.CENTER);
    right.add(btn, BorderLayout.EAST);

    card.add(info, BorderLayout.CENTER);
    card.add(right, BorderLayout.EAST);
    return card;
  }
}
