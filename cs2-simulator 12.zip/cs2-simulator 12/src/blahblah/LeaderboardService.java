package blahblah;

import blahblah.hGui.*;
import java.awt.*;
import java.awt.event.*;
import java.math.BigDecimal;
import java.math.RoundingMode;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;
import javax.swing.*;

/** Leaderboard Service: focused feature implementation. */
final class LeaderboardService {
  private final hGui app;

  LeaderboardService(hGui app) {
    this.app = app;
  }

  String normalizeSkinName(String name) {
    if (name == null || name.isEmpty()) return "";
    String clean = name.replaceAll("[\\p{Cc}&&[^\\t\\n\\r]]", "");
    clean = clean.replaceAll("\\s+", " ").trim();
    return clean;
  }

  String getFloatRuleKey(String skinName) {
    String key =
        app.leaderboardService
            .normalizeSkinName(app.activitySimulationService.cleanStatTrakEncoding(skinName))
            .replace("StatTrak ", "")
            .trim();
    return key.replaceAll("\\s*\\(Blue Gem [^)]+\\)$", "").trim();
  }

  FloatRange getFloatRangeForSkin(String skinName) {
    return app.catalogParsingService.findFloatRange(
        app.leaderboardService.getFloatRuleKey(skinName));
  }

  String wearFromFloat(double value) {
    if (value < 0.07) return "Factory New";
    if (value <= 0.15) return "Minimal Wear";
    if (value <= 0.38) return "Field-Tested";
    if (value <= 0.45) return "Well-Worn";
    return "Battle-Scarred";
  }

  boolean isFloatValidForSkinAndCondition(String skinName, String condition, double value) {
    if (app.itemMetadataService.isAgentSkin(skinName)) return true;
    FloatRange fr = app.leaderboardService.getFloatRangeForSkin(skinName);
    double min = fr != null && fr.min != null ? fr.min : 0.0;
    double max = fr != null && fr.max != null ? fr.max : 1.0;
    double epsilon = 0.0000001;
    return value >= min - epsilon
        && value <= max + epsilon
        && condition != null
        && condition.equals(app.leaderboardService.wearFromFloat(value));
  }

  String fallbackConditionForSkin(String skinName, String condition) {
    String[] validConditions =
        app.floatRules.getAvailableConditions(
            app.leaderboardService.getFloatRuleKey(skinName));
    if (validConditions.length == 0) return "Factory New";
    if (condition != null) {
      for (String valid : validConditions) {
        if (valid.equals(condition)) return condition;
      }
    }
    return validConditions[
        Math.min(validConditions.length - 1, Math.max(0, validConditions.length / 2))];
  }

  InventoryItem cloneLeaderboardItem(InventoryItem src, double listPrice) {
    if (src == null) return null;
    ImageIcon copyImage = src.image == null ? null : new ImageIcon(src.image.getImage());
    String condition = src.condition;
    double clonedFloat = src.itemFloat;
    if (!app.marketPurchaseService.isConditionValidForSkin(src.name, condition)) {
      condition = app.leaderboardService.fallbackConditionForSkin(src.name, condition);
      clonedFloat =
          app.marketGeneration.generateFloatForCondition(
              app.leaderboardService.getFloatRuleKey(src.name), condition);
    } else if (!app.leaderboardService.isFloatValidForSkinAndCondition(
        src.name, condition, clonedFloat)) {
      clonedFloat =
          app.marketGeneration.generateFloatForCondition(
              app.leaderboardService.getFloatRuleKey(src.name), condition);
    }
    InventoryItem item =
        new InventoryItem(
            copyImage,
            src.name,
            condition,
            src.rarity,
            BigDecimal.valueOf(listPrice).setScale(2, RoundingMode.HALF_UP),
            clonedFloat,
            src.isStattrak,
            src.patternID,
            src.blueGemTier,
            src.basePrice);
    item.collection = app.inventoryScreen.resolveInventoryItemCollection(src);
    if (src.history != null && !src.history.isEmpty()) {
      item.history = new ArrayList<>(src.history);
    }
    item.currentOwner = src.currentOwner;
    return item;
  }

  void applyLeaderboardMarketPrice(InventoryItem item) {
    if (item == null || item.price == null) return;
    if (app.globalMarketListings.isEmpty()) {
      app.marketGeneration.generateGlobalMarketListings();
    }

    if (!app.marketPurchaseService.isConditionValidForSkin(item.name, item.condition)) {
      item.condition = app.leaderboardService.fallbackConditionForSkin(item.name, item.condition);
      item.itemFloat =
          app.marketGeneration.generateFloatForCondition(
              app.leaderboardService.getFloatRuleKey(item.name), item.condition);
    } else if (!app.leaderboardService.isFloatValidForSkinAndCondition(
        item.name, item.condition, item.itemFloat)) {
      item.itemFloat =
          app.marketGeneration.generateFloatForCondition(
              app.leaderboardService.getFloatRuleKey(item.name), item.condition);
    }

    String lookupKey =
        app.leaderboardService.normalizeSkinName(
            item.isStattrak ? "StatTrak " + item.name : item.name);
    String desiredCondition =
        app.itemMetadataService.isAgentSkin(item.name) ? "Agent" : item.condition;
    double marketPrice = app.itemMetadataService.getLowestListingPrice(lookupKey, desiredCondition);
    if (marketPrice <= 0) {
      marketPrice = app.itemMetadataService.getLowestListingPrice(lookupKey, "Any");
    }
    if (marketPrice <= 0) {
      marketPrice = app.listingSalesService.getCurrentMarketPrice(item);
    }
    if (marketPrice > 0) {
      item.price = BigDecimal.valueOf(marketPrice).setScale(2, RoundingMode.HALF_UP);
    }
  }

  String getLeaderboardMarketBucket(double price) {
    if (price >= 50000.0) return "high";
    if (price >= 5000.0) return "mid";
    return "low";
  }

  Map<String, ArrayList<MarketListing>> buildLeaderboardSamplingPools() {
    Map<String, ArrayList<MarketListing>> pools = new HashMap<>();
    for (String key : new String[] {"all", "high", "mid", "low"}) pools.put(key, new ArrayList<>());
    for (ArrayList<MarketListing> bucket : app.globalMarketListings.values()) {
      if (bucket == null) continue;
      for (MarketListing listing : bucket) {
        if (listing == null
            || listing.item == null
            || listing.isPlayerListing
            || !Double.isFinite(listing.getPrice())
            || listing.getPrice() <= 0) continue;
        pools.get("all").add(listing);
        pools
            .get(app.leaderboardService.getLeaderboardMarketBucket(listing.getPrice()))
            .add(listing);
      }
    }
    app.leaderboardSamplingPoolsBuiltAt = System.currentTimeMillis();
    return pools;
  }

  MarketListing pickLeaderboardSample(List<MarketListing> pool, Set<String> excluded) {
    if (pool == null || pool.isEmpty()) return null;
    for (int attempt = 0; attempt < 128; attempt++) {
      MarketListing listing = pool.get(hGui.random.nextInt(pool.size()));
      String key = (listing.item.isStattrak ? "StatTrak " : "") + listing.item.name;
      ArrayList<MarketListing> live = app.globalMarketListings.get(key);
      if (!excluded.contains(key)
          && live != null
          && live.contains(listing)
          && Double.isFinite(listing.getPrice())
          && listing.getPrice() > 0) return listing;
    }
    // Rejection sampling stays uniform. A reservoir fallback handles nearly exhausted pools
    // without changing exclusions, giving up on a valid bucket, or looping forever.
    MarketListing picked = null;
    int eligible = 0;
    for (MarketListing listing : pool) {
      String key = (listing.item.isStattrak ? "StatTrak " : "") + listing.item.name;
      ArrayList<MarketListing> live = app.globalMarketListings.get(key);
      if (!excluded.contains(key)
          && Double.isFinite(listing.getPrice())
          && listing.getPrice() > 0
          && live != null
          && live.contains(listing)
          && hGui.random.nextInt(++eligible) == 0) picked = listing;
    }
    return picked;
  }

  InventoryItem sampleMarketListingItem(String preferredBucket, List<String> excludedKeys) {
    if (app.globalMarketListings.isEmpty()) app.marketGeneration.generateGlobalMarketListings();
    if (app.leaderboardSamplingPools == null
        || System.currentTimeMillis() - app.leaderboardSamplingPoolsBuiltAt > 60000L)
      app.leaderboardSamplingPools = app.leaderboardService.buildLeaderboardSamplingPools();
    Set<String> excluded =
        excludedKeys == null ? java.util.Collections.emptySet() : new HashSet<>(excludedKeys);
    MarketListing picked =
        app.leaderboardService.pickLeaderboardSample(
            app.leaderboardSamplingPools.get(preferredBucket), excluded);
    if (picked == null)
      picked =
          app.leaderboardService.pickLeaderboardSample(
              app.leaderboardSamplingPools.get("all"), excluded);
    return picked == null
        ? null
        : app.leaderboardService.cloneLeaderboardItem(picked.item, picked.getPrice());
  }

  void addLeaderboardBucketItems(
      ArrayList<InventoryItem> items, int count, String bucket, List<String> excludedKeys) {
    for (int i = 0; i < count; i++) {
      InventoryItem item = app.leaderboardService.sampleMarketListingItem(bucket, excludedKeys);
      if (item == null) break;
      items.add(item);
      excludedKeys.add(
          app.leaderboardService.normalizeSkinName(
              item.isStattrak ? "StatTrak " + item.name : item.name));
    }
  }

  String getPreferredLeaderboardBucketForTier(int wealthTier) {
    if (wealthTier <= 0) return "high";
    if (wealthTier == 1) return "mid";
    return "low";
  }

  ArrayList<InventoryItem> generateLeaderboardInventory(int wealthTier) {
    int itemCount;
    switch (wealthTier) {
      case 0:
        itemCount = 24 + hGui.random.nextInt(10);
        break;
      case 1:
        itemCount = 20 + hGui.random.nextInt(8);
        break;
      case 2:
        itemCount = 16 + hGui.random.nextInt(8);
        break;
      case 3:
        itemCount = 13 + hGui.random.nextInt(6);
        break;
      default:
        itemCount = 10 + hGui.random.nextInt(6);
        break;
    }

    ArrayList<InventoryItem> items = new ArrayList<>();
    ArrayList<String> excludedKeys = new ArrayList<>();
    int highCount;
    int midCount;
    int lowCount;
    switch (wealthTier) {
      case 0:
        highCount = Math.max(3, itemCount / 4);
        midCount = Math.max(5, itemCount / 3);
        break;
      case 1:
        highCount = Math.max(2, itemCount / 5);
        midCount = Math.max(4, itemCount / 3);
        break;
      case 2:
        highCount = Math.max(1, itemCount / 6);
        midCount = Math.max(3, itemCount / 3);
        break;
      default:
        highCount = Math.max(1, itemCount / 8);
        midCount = Math.max(2, itemCount / 3);
        break;
    }
    lowCount = Math.max(1, itemCount - highCount - midCount);

    app.leaderboardService.addLeaderboardBucketItems(items, highCount, "high", excludedKeys);
    app.leaderboardService.addLeaderboardBucketItems(items, midCount, "mid", excludedKeys);
    app.leaderboardService.addLeaderboardBucketItems(items, lowCount, "low", excludedKeys);
    while (items.size() < itemCount) {
      InventoryItem extra = app.leaderboardService.sampleMarketListingItem("mid", excludedKeys);
      if (extra == null) break;
      items.add(extra);
      excludedKeys.add(
          app.leaderboardService.normalizeSkinName(
              extra.isStattrak ? "StatTrak " + extra.name : extra.name));
    }
    return items;
  }

  void normalizeNpcLeaderboardBand(
      LeaderboardEntry entry, double minValue, double maxValue, int wealthTier) {
    if (entry == null || entry.inventoryItems == null || entry.inventoryItems.isEmpty()) return;
    app.leaderboardService.refreshLeaderboardEntryMarketValues(entry);

    int safety = 0;
    while (entry.inventoryValue > maxValue && entry.inventoryItems.size() > 1 && safety++ < 200) {
      int removeIndex = 0;
      double highest = -1.0;
      for (int i = 0; i < entry.inventoryItems.size(); i++) {
        double price = entry.inventoryItems.get(i).price.doubleValue();
        if (price > highest) {
          highest = price;
          removeIndex = i;
        }
      }
      entry.inventoryItems.remove(removeIndex);
      app.leaderboardService.refreshLeaderboardEntryMarketValues(entry);
    }

    safety = 0;
    while (entry.inventoryValue < minValue && safety++ < 200) {
      ArrayList<String> excludedKeys = new ArrayList<>();
      for (InventoryItem item : entry.inventoryItems) {
        excludedKeys.add(
            app.leaderboardService.normalizeSkinName(
                item.isStattrak ? "StatTrak " + item.name : item.name));
      }
      InventoryItem nextItem =
          app.leaderboardService.sampleMarketListingItem(
              app.leaderboardService.getPreferredLeaderboardBucketForTier(wealthTier),
              excludedKeys);
      if (nextItem == null) break;
      entry.inventoryItems.add(nextItem);
      app.leaderboardService.refreshLeaderboardEntryMarketValues(entry);
    }
  }

  void normalizeNpcLeaderboardBands() {
    ArrayList<LeaderboardEntry> npcs = new ArrayList<>();
    for (LeaderboardEntry entry : app.globalLeaderboard) {
      if (!entry.isPlayer) npcs.add(entry);
    }
    npcs.sort((a, b) -> Double.compare(b.inventoryValue, a.inventoryValue));
    if (npcs.isEmpty()) return;

    app.leaderboardService.normalizeNpcLeaderboardBand(npcs.get(0), 900000.0, 1200000.0, 0);
    if (npcs.size() > 1)
      app.leaderboardService.normalizeNpcLeaderboardBand(npcs.get(1), 420000.0, 620000.0, 1);
    if (npcs.size() > 2)
      app.leaderboardService.normalizeNpcLeaderboardBand(npcs.get(2), 250000.0, 380000.0, 2);
    if (npcs.size() > 3)
      app.leaderboardService.normalizeNpcLeaderboardBand(npcs.get(3), 180000.0, 300000.0, 3);
    if (npcs.size() > 4)
      app.leaderboardService.normalizeNpcLeaderboardBand(npcs.get(4), 140000.0, 240000.0, 4);
  }

  double calculateInventoryTotal(List<InventoryItem> items) {
    double total = 0.0;
    for (InventoryItem item : items) {
      if (item != null && item.price != null) {
        total += item.price.doubleValue();
      }
    }
    return total;
  }

  void refreshLeaderboardEntryMarketValues(LeaderboardEntry entry) {
    if (entry == null
        || entry.isPlayer
        || entry.inventoryItems == null
        || entry.inventoryItems.isEmpty()) return;
    for (InventoryItem item : entry.inventoryItems) {
      app.leaderboardService.applyLeaderboardMarketPrice(item);
    }
    entry.inventoryValue = app.leaderboardService.calculateInventoryTotal(entry.inventoryItems);
  }

  void refreshAllLeaderboardMarketValues() {
    for (LeaderboardEntry entry : app.globalLeaderboard) {
      if (entry.isPlayer) {
        entry.inventoryValue = app.inventoryValue;
      } else {
        app.leaderboardService.refreshLeaderboardEntryMarketValues(entry);
      }
    }
  }

  LeaderboardEntry createNpcLeaderboardEntry(String username, Image avatar, int wealthTier) {
    ArrayList<InventoryItem> items =
        app.leaderboardService.generateLeaderboardInventory(wealthTier);
    double total = app.leaderboardService.calculateInventoryTotal(items);
    return new LeaderboardEntry(username, total, avatar, false, items);
  }

  String generateUniqueLeaderboardName(Set<String> usedNames, int index) {
    String base = hGui.NPC_USERNAMES[hGui.random.nextInt(hGui.NPC_USERNAMES.length)];
    String candidate = base;
    int suffix = 2;
    while (usedNames.contains(candidate)) {
      candidate = base + " " + suffix++;
    }
    usedNames.add(candidate);
    return candidate;
  }

  void generateLeaderboard() {
    app.globalLeaderboard.clear();

    if (app.npcAvatars == null || app.playerAvatar == null) {
      System.err.println("Avatars not loaded yet, skipping leaderboard generation");
      return;
    }

    if (app.inventoryValue > 0) {
      app.globalLeaderboard.add(
          new LeaderboardEntry("YOU", app.inventoryValue, app.playerAvatar, true));
    }

    Set<String> usedNames = new HashSet<>();
    usedNames.add("YOU");

    app.leaderboardSamplingPools = app.leaderboardService.buildLeaderboardSamplingPools();
    int generated = 0;
    int[] tierCounts = {1, 9, 25, 65, 100};
    for (int tier = 0; tier < tierCounts.length; tier++) {
      for (int i = 0; i < tierCounts[tier]; i++) {
        String name = app.leaderboardService.generateUniqueLeaderboardName(usedNames, i);
        Image avatar = app.npcAvatars[hGui.random.nextInt(app.npcAvatars.length)];
        app.globalLeaderboard.add(
            app.leaderboardService.createNpcLeaderboardEntry(name, avatar, tier));
        if (app.startupWorkStarted && !app.marketInitialized && (++generated % 5 == 0))
          app.startupScreen.setStartupProgress(
              94, "Building NPC inventories and leaderboards (" + generated + " / 200)...");
      }
    }

    app.leaderboardService.normalizeNpcLeaderboardBands();
    app.globalLeaderboard.sort((a, b) -> Double.compare(b.inventoryValue, a.inventoryValue));

    for (int i = 0; i < app.globalLeaderboard.size(); i++) {
      app.globalLeaderboard.get(i).rank = i + 1;
    }
  }
}
