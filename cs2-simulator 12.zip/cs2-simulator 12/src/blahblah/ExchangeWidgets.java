package blahblah;

import blahblah.hGui.*;
import java.awt.*;
import java.awt.event.*;
import javax.swing.*;

/** Exchange Widgets: focused feature implementation. */
final class ExchangeWidgets {
  private final hGui app;

  ExchangeWidgets(hGui app) {
    this.app = app;
  }

  JComponent exchangeWearStrip(double value) {
    JComponent strip =
        new JComponent() {
          protected void paintComponent(Graphics g) {
            int w = getWidth(), y = Math.max(2, getHeight() / 2 - 3);
            double[] edges = {0, .07, .15, .38, .45, 1};
            Color[] colors = {
              new Color(79, 180, 85),
              new Color(153, 204, 79),
              new Color(223, 204, 78),
              new Color(225, 146, 73),
              new Color(217, 85, 95)
            };
            for (int i = 0; i < 5; i++) {
              g.setColor(colors[i]);
              int x = (int) (edges[i] * w), end = (int) (edges[i + 1] * w);
              g.fillRect(x, y, end - x, 6);
            }
            int x = (int) (Math.max(0, Math.min(1, value)) * (w - 1));
            g.setColor(Color.WHITE);
            g.fillPolygon(new int[] {x - 4, x + 4, x}, new int[] {y - 5, y - 5, y + 1}, 3);
          }
        };
    strip.setPreferredSize(new Dimension(160, 14));
    strip.setToolTipText(String.format("Float %.8f", value));
    return strip;
  }

  void styleExchangeTabs(JTabbedPane tabs, MarketplaceProfile p) {
    tabs.setUI(
        new javax.swing.plaf.basic.BasicTabbedPaneUI() {
          protected void installDefaults() {
            super.installDefaults();
            tabInsets = new Insets(12, 24, 12, 24);
            contentBorderInsets = new Insets(0, 0, 0, 0);
            tabAreaInsets = new Insets(0, 12, 0, 12);
          }

          protected void paintTabBackground(
              Graphics g, int placement, int index, int x, int y, int w, int h, boolean selected) {
            g.setColor(app.exchangeWidgets.exchangeBackground(p));
            g.fillRect(x, y, w, h);
            if (selected) {
              g.setColor(app.exchangeWidgets.exchangeAccent(p));
              g.fillRect(x, y + h - 3, w, 3);
            }
          }

          protected void paintTabBorder(
              Graphics g, int placement, int index, int x, int y, int w, int h, boolean selected) {}

          protected void paintContentBorder(Graphics g, int placement, int selected) {}

          protected void paintFocusIndicator(
              Graphics g,
              int placement,
              Rectangle[] rects,
              int index,
              Rectangle icon,
              Rectangle text,
              boolean selected) {}
        });
    tabs.setOpaque(true);
    tabs.setBackground(app.exchangeWidgets.exchangeBackground(p));
    tabs.setForeground(Color.WHITE);
  }

  Color exchangeBackground(MarketplaceProfile p) {
    Color[] colors = {
      new Color(17, 20, 31),
      new Color(25, 24, 36),
      new Color(16, 26, 29),
      new Color(24, 25, 28),
      new Color(18, 29, 24),
      new Color(26, 23, 28),
      new Color(21, 29, 33),
      new Color(14, 24, 35),
      new Color(31, 36, 35),
      new Color(27, 29, 25),
      new Color(15, 31, 36),
      new Color(29, 25, 39),
      new Color(10, 23, 27),
      new Color(35, 28, 26),
      new Color(34, 22, 18),
      new Color(22, 31, 39),
      new Color(18, 25, 21),
      new Color(32, 22, 33)
    };
    return colors[app.exchangeTransactionService.exchangeStyle(p)];
  }

  Color exchangeAccent(MarketplaceProfile p) {
    if (p.name.equals("SkinSwap")) return new Color(238, 77, 93);
    if (p.name.equals("Skinport")) return new Color(77, 184, 205);
    if (p.name.equals("Skin.Land")) return new Color(255, 145, 57);
    return p.accent;
  }

  String exchangeTagline(MarketplaceProfile p) {
    return new String[] {
          "A new finish. A new perspective.",
          "YOUR SKINS. YOUR NEXT MOVE.",
          "The trading floor never sleeps.",
          "Rare finds. Straightforward deals.",
          "Build your next loadout.",
          "A better home for your skins.",
          "Your cargo. Ready for departure.",
          "Discover what belongs in your vault.",
          "Find your next favourite.",
          "The peer-to-peer price exchange.",
          "Every decimal tells a story.",
          "Exceptional skins. Personal service.",
          "UPGRADE YOUR SIGNAL.",
          "Find the unexpected.",
          "Bring the heat to your loadout.",
          "A cooler way to shop.",
          "LIVE INVENTORY / READY TO RELAY",
          "The collector’s private gallery."
        }
        [app.exchangeTransactionService.exchangeStyle(p)];
  }

  String exchangeSwapTab(MarketplaceProfile p) {
    switch (p.name) {
      case "SkinSwap":
        return "Trade";
      case "Skin.Land":
        return "Swap skins";
      case "NeonGrid":
        return "Exchange";
      case "RelayMarket":
        return "Relay";
      default:
        return "Trade room";
    }
  }

  JPanel exchangePanel(MarketplaceProfile p, LayoutManager layout) {
    JPanel panel = new JPanel(layout);
    panel.setBackground(app.exchangeWidgets.exchangeBackground(p));
    return panel;
  }

  JLabel exchangeLabel(String text, int size, Color color) {
    JLabel l = app.cs2Screens.cs2Text(text, size, color);
    return l;
  }

  JButton exchangeButton(MarketplaceProfile p, String text, Runnable action) {
    JButton b = app.cs2Screens.cs2Button(text, false, e -> action.run());
    b.setBackground(app.exchangeWidgets.exchangeAccent(p).darker().darker());
    b.setBorder(
        BorderFactory.createCompoundBorder(
            BorderFactory.createLineBorder(app.exchangeWidgets.exchangeAccent(p).darker()),
            BorderFactory.createEmptyBorder(9, 13, 9, 13)));
    return b;
  }

  JScrollPane exchangeScroll(Component component) {
    JScrollPane s = new JScrollPane(component);
    s.setBorder(null);
    s.getViewport().setBackground(new Color(20, 24, 30));
    s.getVerticalScrollBar().setUnitIncrement(26);
    s.setHorizontalScrollBarPolicy(ScrollPaneConstants.HORIZONTAL_SCROLLBAR_NEVER);
    return s;
  }

  JTextField exchangeSearch(String text) {
    JTextField t =
        new JTextField(text) {
          protected void paintComponent(Graphics g) {
            super.paintComponent(g);
            if (getText().isEmpty() && !hasFocus()) {
              g.setColor(new Color(137, 145, 157));
              Object hint = getClientProperty("placeholder");
              g.drawString(
                  hint == null ? "Search for an item…" : hint.toString(),
                  12,
                  (getHeight() + g.getFontMetrics().getAscent()) / 2 - 2);
            }
          }
        };
    t.setForeground(Color.WHITE);
    t.setBackground(new Color(37, 42, 49));
    t.setCaretColor(Color.WHITE);
    t.setBorder(
        BorderFactory.createCompoundBorder(
            BorderFactory.createLineBorder(new Color(62, 67, 78)),
            BorderFactory.createEmptyBorder(9, 12, 9, 12)));
    return t;
  }

  void exchangeDebounce(JTextField t, Runnable action) {
    javax.swing.Timer timer = new javax.swing.Timer(220, e -> action.run());
    timer.setRepeats(false);
    t.getDocument()
        .addDocumentListener(
            new javax.swing.event.DocumentListener() {
              public void insertUpdate(javax.swing.event.DocumentEvent e) {
                timer.restart();
              }

              public void removeUpdate(javax.swing.event.DocumentEvent e) {
                timer.restart();
              }

              public void changedUpdate(javax.swing.event.DocumentEvent e) {
                timer.restart();
              }
            });
  }
}
