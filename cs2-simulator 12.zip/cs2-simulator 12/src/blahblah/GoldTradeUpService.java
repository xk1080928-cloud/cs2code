package blahblah;

import blahblah.hGui.*;
import java.awt.*;
import java.awt.event.*;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.Set;
import javax.swing.*;

/** Gold Trade Up Service: focused feature implementation. */
final class GoldTradeUpService {
  private final hGui app;

  GoldTradeUpService(hGui app) {
    this.app = app;
  }

  CaseType getGoldTradeUpSource(InventoryItem item) {
    if (item == null
        || item.name == null
        || item.rarity == null
        || !"Covert".equals(item.rarity.replace("StatTrak ", ""))
        || item.name.toLowerCase(java.util.Locale.ROOT).contains("souvenir")
        || (item.collection != null
            && item.collection.toLowerCase(java.util.Locale.ROOT).contains("souvenir")))
      return null;
    String name =
        app.catalogParsingService.normalizeCatalogSkinName(
            item.name.replaceFirst("(?i)^StatTrak(?:™)?\\s+", ""));
    CaseType match = null;
    for (CaseType ct : CaseType.values()) {
      if (ct.isSouvenir || ct.rareDropNames.isEmpty()) continue;
      // Only Dead Hand is an eligible terminal; cases must actually have a special pool.
      if (ct.isTerminal && !"Sealed Dead Hand Terminal".equalsIgnoreCase(ct.crateName)) continue;
      if (!ct.isTerminal && !ct.crateName.toLowerCase(java.util.Locale.ROOT).contains("case"))
        continue;
      if (!ct.regularDropNames
          .getOrDefault("Covert", java.util.Collections.emptyList())
          .contains(name)) continue;
      if (app.goldTradeUpService.getCaseGoldOutcomeOdds(ct).isEmpty()) continue;
      if (item.collection != null
          && item.collection.equalsIgnoreCase(app.collectionService.getCatalogCollectionName(ct)))
        return ct;
      if (match != null) return null; // Never guess between ambiguous source collections.
      match = ct;
    }
    return match;
  }

  double[] getCaseGoldWeightProfile(CaseType source, String skin) {
    if (source == null && skin != null) {
      for (CaseType ct : CaseType.values())
        if (!ct.isSouvenir && ct.rareDropNames.contains(skin)) {
          source = ct;
          break;
        }
    }
    String crate = source == null ? "" : source.crateName.toLowerCase(java.util.Locale.ROOT);
    if (crate.contains("chroma")) return new double[] {0.1195, 0.095, 0.01, 0.0025, 0.0};
    if (crate.contains("spectrum")) return new double[] {0.1665, 0.0335, 0.015, 0.0035, 0.0};
    if (crate.contains("prisma") || crate.equals("fever case"))
      return new double[] {0.166944, 0.033, 0.015, 0.00328, 0.0};
    if (crate.contains("gamma")
        || crate.contains("riptide")
        || crate.contains("dreams & nightmares")
        || (skin != null && skin.contains("Gamma Doppler")))
      return new double[] {0.1665, 0.0385, 0.0, 0.0, 0.0135};
    // A standalone simulated Doppler still uses its knife-generation profile.
    if (skin != null && skin.endsWith(" | Doppler")) {
      if (skin.startsWith("Talon Knife")
          || skin.startsWith("Ursus Knife")
          || skin.startsWith("Navaja Knife")
          || skin.startsWith("Stiletto Knife")
          || skin.startsWith("Skeleton Knife")
          || skin.startsWith("Survival Knife")
          || skin.startsWith("Paracord Knife")
          || skin.startsWith("Nomad Knife"))
        return new double[] {0.166944, 0.033, 0.015, 0.00328, 0.0};
      if (skin.startsWith("Butterfly Knife")
          || skin.startsWith("Falchion Knife")
          || skin.startsWith("Bowie Knife")
          || skin.startsWith("Huntsman Knife")
          || skin.startsWith("Shadow Daggers"))
        return new double[] {0.1665, 0.0335, 0.015, 0.0035, 0.0};
      return new double[] {0.1195, 0.095, 0.01, 0.0025, 0.0};
    }
    return null; // Non-Doppler cases retain equal weights for their ordinary rare items.
  }

  Map<String, Double> getGoldFinishWeights(CaseType source, String skin) {
    Map<String, Double> weights = new LinkedHashMap<>();
    if (skin == null) return weights;
    double[] profile = app.goldTradeUpService.getCaseGoldWeightProfile(source, skin);
    if (skin.contains("Doppler") && !skin.contains("(")) {
      for (int phase = 1; phase <= 4; phase++)
        weights.put(skin + " (Phase " + phase + ")", profile[1]);
      if (skin.contains("Gamma Doppler")) weights.put(skin + " (Emerald)", profile[4]);
      else {
        weights.put(skin + " (Sapphire)", profile[2]);
        weights.put(skin + " (Ruby)", profile[2]);
        weights.put(skin + " (Black Pearl)", profile[3]);
      }
    } else weights.put(skin, profile == null ? 1.0 : profile[0]);
    return weights;
  }

  Map<String, Double> normalizeGoldWeights(Map<String, Double> weights) {
    Map<String, Double> odds = new LinkedHashMap<>();
    double total = weights.values().stream().mapToDouble(Double::doubleValue).sum();
    if (total > 0)
      for (Map.Entry<String, Double> e : weights.entrySet())
        if (e.getValue() > 0) odds.put(e.getKey(), e.getValue() / total);
    return odds;
  }

  Map<String, Double> getDopplerVariantOdds(String skin) {
    return app.goldTradeUpService.normalizeGoldWeights(
        app.goldTradeUpService.getGoldFinishWeights(null, skin));
  }

  Map<String, Double> getUnboxingDopplerVariantOdds(String skin) {
    Map<String, Double> odds = new LinkedHashMap<>();
    if (skin != null && skin.contains("Doppler") && !skin.contains("(")) {
      for (int phase = 1; phase <= 4; phase++) odds.put(skin + " (Phase " + phase + ")", 0.23);
      if (skin.contains("Gamma Doppler")) odds.put(skin + " (Emerald)", 0.08);
      else {
        odds.put(skin + " (Sapphire)", 0.035);
        odds.put(skin + " (Ruby)", 0.035);
        odds.put(skin + " (Black Pearl)", 0.01);
      }
    } else if (skin != null) odds.put(skin, 1.0);
    return odds;
  }

  Map<String, Double> getCaseUnboxingGoldOutcomeOdds(CaseType ct, String categoryFilter) {
    Map<String, Double> weights = new LinkedHashMap<>();
    if (ct == null || ct.isSouvenir) return weights;
    for (String name : new java.util.LinkedHashSet<>(ct.rareDropNames)) {
      String category = ct.rareDropCategories.getOrDefault(name, ct.rareDropCategory);
      if (!("Knives".equals(category) || "Gloves".equals(category))) continue;
      if (categoryFilter != null && !categoryFilter.equals(category)) continue;
      // Preserve the existing base-finish probability; change only the conditional phase/gem split.
      double finishWeight =
          app.goldTradeUpService.getGoldFinishWeights(ct, name).values().stream()
              .mapToDouble(Double::doubleValue)
              .sum();
      for (Map.Entry<String, Double> variant :
          app.goldTradeUpService.getUnboxingDopplerVariantOdds(name).entrySet())
        weights.merge(variant.getKey(), finishWeight * variant.getValue(), Double::sum);
    }
    return app.goldTradeUpService.normalizeGoldWeights(weights);
  }

  String sampleTradeUpOdds(Map<String, Double> odds) {
    if (odds.isEmpty()) throw new IllegalArgumentException("No verified outcomes are available.");
    double total = odds.values().stream().mapToDouble(Double::doubleValue).sum();
    double roll = hGui.random.nextDouble() * total;
    String last = null;
    for (Map.Entry<String, Double> e : odds.entrySet()) {
      last = e.getKey();
      roll -= e.getValue();
      if (roll < 0) return last;
    }
    return last;
  }

  Map<String, Double> getCaseGoldOutcomeOdds(CaseType ct) {
    return app.goldTradeUpService.getCaseGoldOutcomeOdds(ct, null);
  }

  Map<String, Double> getCaseGoldOutcomeOdds(CaseType ct, String categoryFilter) {
    Map<String, Double> weights = new LinkedHashMap<>();
    if (ct == null || ct.isSouvenir) return weights;
    for (String name : new java.util.LinkedHashSet<>(ct.rareDropNames)) {
      String category = ct.rareDropCategories.getOrDefault(name, ct.rareDropCategory);
      if (!("Knives".equals(category) || "Gloves".equals(category))) continue;
      if (categoryFilter != null && !categoryFilter.equals(category)) continue;
      for (Map.Entry<String, Double> e :
          app.goldTradeUpService.getGoldFinishWeights(ct, name).entrySet())
        weights.merge(e.getKey(), e.getValue(), Double::sum);
    }
    return app.goldTradeUpService.normalizeGoldWeights(weights);
  }

  Map<String, Double> getGoldTradeUpOdds(List<InventoryItem> inputs) {
    Map<String, Double> odds = new LinkedHashMap<>();
    if (inputs.isEmpty()) return odds;
    for (InventoryItem item : inputs) {
      CaseType ct = app.goldTradeUpService.getGoldTradeUpSource(item);
      if (ct == null)
        throw new IllegalArgumentException(
            "Gold contracts require case Covert skins or Dead Hand Covert skins with a verified"
                + " knife/glove pool.");
      for (Map.Entry<String, Double> outcome :
          app.goldTradeUpService.getCaseGoldOutcomeOdds(ct).entrySet())
        odds.merge(outcome.getKey(), outcome.getValue() / inputs.size(), Double::sum);
    }
    return odds;
  }

  boolean isTradeUpEligibleForMode(InventoryItem item) {
    boolean eligible =
        item.rarity.contains("Covert")
            ? getGoldTradeUpSource(item) != null
            : app.loadoutScreen.isTradeUpEligibleItem(item);
    if (!eligible) return false;
    if (app.tradeUpSelection == null || app.tradeUpSelection.isEmpty()) return true;
    InventoryItem first = app.tradeUpSelection.get(0);
    return item.rarity.replace("StatTrak ", "").equals(first.rarity.replace("StatTrak ", ""))
        && item.isStattrak == first.isStattrak;
  }

  int getTradeUpRequiredCount(List<InventoryItem> inputs) {
    return inputs.isEmpty()
        ? (app.goldTradeUpMode ? 5 : 10)
        : inputs.get(0).rarity.contains("Covert") ? 5 : 10;
  }

  void validateTradeUpInputs(List<InventoryItem> inputs, boolean complete) {
    if (inputs.isEmpty()) throw new IllegalArgumentException("Select skins for the contract.");
    int required = app.goldTradeUpService.getTradeUpRequiredCount(inputs);
    if (inputs.size() > required || (complete && inputs.size() != required))
      throw new IllegalArgumentException("Please select exactly " + required + " skins!");
    Set<InventoryItem> unique =
        java.util.Collections.newSetFromMap(
            new java.util.IdentityHashMap<InventoryItem, Boolean>());
    InventoryItem first = inputs.get(0);
    for (InventoryItem item : inputs) {
      if (item == null || !unique.add(item) || !app.inventoryList.contains(item))
        throw new IllegalArgumentException(
            "Each input must be a different item currently in your inventory.");
      if (!app.loadoutScreen.isTradeUpEligibleItem(item)
          || !item.rarity.replace("StatTrak ", "").equals(first.rarity.replace("StatTrak ", ""))
          || item.isStattrak != first.isStattrak)
        throw new IllegalArgumentException(
            "All skins must have the same eligible rarity and StatTrak status.");
      if (required == 5 && app.goldTradeUpService.getGoldTradeUpSource(item) == null)
        throw new IllegalArgumentException(
            "This Covert skin does not have an eligible case/Dead Hand gold pool.");
    }
  }

  double getGoldTradeUpOutputFloat(List<InventoryItem> inputs, String output) {
    if (app.floatRules.hasNoFloatWear(output)) return 0.0;
    double normalized = 0;
    for (InventoryItem input : inputs) {
      double[] bounds = app.marketStockService.getMarketWearBounds(input.name);
      normalized +=
          Math.max(
              0,
              Math.min(1, (input.itemFloat - bounds[0]) / Math.max(0.0001, bounds[1] - bounds[0])));
    }
    double[] bounds = app.marketStockService.getMarketWearBounds(output);
    return Math.max(
        bounds[0],
        Math.min(bounds[1], bounds[0] + normalized / inputs.size() * (bounds[1] - bounds[0])));
  }

  String getGoldTradeUpOutputRarity(String skin) {
    for (CaseType ct : CaseType.values())
      for (String base : ct.rareDropNames)
        if (skin.equals(base) || skin.startsWith(base + " ("))
          return "Gloves".equals(ct.rareDropCategories.getOrDefault(base, ct.rareDropCategory))
              ? "Gloves"
              : "Knife";
    throw new IllegalArgumentException("Unknown gold outcome: " + skin);
  }

  double getGoldTradeUpOutputPrice(String name, String wear, boolean statTrak, String collection) {
    String rarity = app.goldTradeUpService.getGoldTradeUpOutputRarity(name);
    double base = app.itemPriceService.getBasePrice(name);
    double price =
        "Gloves".equals(rarity)
            ? app.priceTables.calculateGlovePrice(name, wear, base)
            : base
                * (app.floatRules.hasNoFloatWear(name)
                    ? 1.0
                    : app.priceModifiers.getConditionPriceMultiplier(name, wear));
    price *= app.marketInitialization.getMarketMultiplier(rarity, collection);
    if (statTrak && app.itemMetadataService.supportsStatTrak(name)) price *= 2.0;
    return price;
  }

  InventoryItem performGoldTradeUp(List<InventoryItem> inputs) {
    app.goldTradeUpService.validateTradeUpInputs(inputs, true);
    if (app.goldTradeUpService.getTradeUpRequiredCount(inputs) != 5)
      throw new IllegalArgumentException("Gold contracts require five Covert skins.");
    // Choose an input uniformly FIRST. A larger output pool must not buy a larger collection share.
    CaseType source =
        app.goldTradeUpService.getGoldTradeUpSource(inputs.get(hGui.random.nextInt(inputs.size())));
    String name =
        app.goldTradeUpService.sampleTradeUpOdds(
            app.goldTradeUpService.getCaseGoldOutcomeOdds(source));
    String rarity = app.goldTradeUpService.getGoldTradeUpOutputRarity(name);
    boolean statTrak =
        inputs.get(0).isStattrak
            && "Knife".equals(rarity)
            && app.itemMetadataService.supportsStatTrak(name);
    double fl = app.goldTradeUpService.getGoldTradeUpOutputFloat(inputs, name);
    String wear = app.floatRules.getConditionForFloat(name, fl);
    String collection = app.collectionService.getCatalogCollectionName(source);
    double price =
        app.goldTradeUpService.getGoldTradeUpOutputPrice(name, wear, statTrak, collection);
    double base = app.itemPriceService.getBasePrice(name);
    int pattern = hGui.random.nextInt(1000);
    String gem = app.itemPriceService.getBlueGemTier(name, pattern);
    if (gem != null) price = app.itemPriceService.applyBlueGemMultiplier(name, pattern, gem, price);
    if (!Double.isFinite(price) || price <= 0)
      throw new IllegalArgumentException(
          "No valid price for this outcome; inputs were not consumed.");
    Image art = app.artworkService.getSkinImageFromName(name, wear);
    InventoryItem result =
        new InventoryItem(
            new ImageIcon(
                art == null ? app.containerBrowserScreen.createItemPlaceholderImage() : art),
            gem == null ? name : name + " (" + gem + ")",
            wear,
            statTrak ? "StatTrak " + rarity : rarity,
            app.coreUtilities.money(price),
            fl,
            statTrak,
            pattern,
            gem,
            base);
    result.collection = null;
    app.ownershipHistoryService.addItemHistory(
        result,
        System.currentTimeMillis(),
        "Gold Trade Up",
        "Five-Covert gold contract completed by YOU from "
            + source.crateName
            + String.format(" for $%.2f", result.price.doubleValue()),
        "YOU");
    app.globalSupply.contract(new java.util.ArrayList<>(inputs),result);
    double spent = inputs.stream().mapToDouble(it -> it.price.doubleValue()).sum();
    synchronized (app.inventoryList) {
      app.inventoryList.removeAll(inputs);
      app.inventoryList.add(result);
    }
    app.coreUtilities.setInventoryValueRounded(
        Math.max(0.0, app.inventoryValue - spent) + result.price.doubleValue());
    app.totCov = Math.max(0, app.totCov - 5);
    if ("Gloves".equals(rarity)) app.totGlove++;
    else app.totKnife++;
    app.lowestFloat = Math.min(app.lowestFloat, fl);
    if (app.inventoryTabPanel != null)
      app.inventoryTabPanel.putClientProperty("inventorySnapshot", null);
    if (app.tradeUpTabPanel != null)
      app.tradeUpTabPanel.putClientProperty("inventorySnapshot", null);
    return result;
  }
}
