package blahblah;

import java.awt.*;
import java.awt.image.BufferedImage;
import javax.swing.*;

/** Single-pass scene crossfade; a dark backing prevents native white flashes at alpha zero. */
final class FadePanel extends JPanel {
  float alpha = 1.0f;
  private BufferedImage backdrop;
  private BufferedImage scene;

  FadePanel(LayoutManager layout) {
    super(layout);
    setBackground(new Color(12, 16, 21));
  }

  void setBackdrop(BufferedImage image) { backdrop = image; }
  void clearBackdrop() { backdrop = null; }

  void setAlpha(float alpha) {
    this.alpha = Math.max(0.0f, Math.min(1.0f, alpha));
    repaint();
  }

  @Override public void paint(Graphics graphics) {
    Graphics2D g = (Graphics2D) graphics.create();
    g.setColor(getBackground());
    g.fillRect(0, 0, getWidth(), getHeight());
    if (backdrop != null) g.drawImage(backdrop, 0, 0, getWidth(), getHeight(), null);
    if (alpha >= 1f) {
      super.paint(g);
      scene = null;
    } else if (alpha > 0 && getWidth() > 0 && getHeight() > 0) {
      if (scene == null || scene.getWidth() != getWidth() || scene.getHeight() != getHeight())
        scene = new BufferedImage(getWidth(), getHeight(), BufferedImage.TYPE_INT_ARGB);
      Graphics2D layer = scene.createGraphics();
      layer.setComposite(AlphaComposite.Clear);
      layer.fillRect(0, 0, scene.getWidth(), scene.getHeight());
      layer.setComposite(AlphaComposite.SrcOver);
      RepaintManager manager = RepaintManager.currentManager(this);
      boolean buffered = manager.isDoubleBufferingEnabled();
      manager.setDoubleBufferingEnabled(false);
      try { super.paint(layer); }
      finally { manager.setDoubleBufferingEnabled(buffered); layer.dispose(); }
      g.setComposite(AlphaComposite.SrcOver.derive(alpha));
      g.drawImage(scene, 0, 0, null); // flatten once: overlapping child backgrounds cannot double-fade
    }
    g.dispose();
  }
}
