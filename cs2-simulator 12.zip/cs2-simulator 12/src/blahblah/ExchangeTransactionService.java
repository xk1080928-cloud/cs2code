package blahblah;

import blahblah.hGui.*;
import java.awt.*;
import java.awt.event.*;
import java.math.BigDecimal;
import java.math.RoundingMode;
import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Set;
import javax.swing.*;

/** Exchange Transaction Service: focused feature implementation. */
final class ExchangeTransactionService {
  private final hGui app;

  ExchangeTransactionService(hGui app) {
    this.app = app;
  }

  double exchangeQuickSellLoss(MarketplaceProfile p) {
    return new double[] {
          .12, .14, .10, .09, .16, .11, .15, .13, .08, .12, .17, .14, .10, .13, .09, .12, .11, .15
        }
        [app.exchangeTransactionService.exchangeStyle(p)];
  }

  double exchangeListingFee(MarketplaceProfile p) {
    return new double[] {
          .05, .04, .04, .03, .05, .035, .045, .05, .025, .03, .04, .045, .035, .04, .03, .035, .04,
          .045
        }
        [app.exchangeTransactionService.exchangeStyle(p)];
  }

  int exchangeStyle(MarketplaceProfile p) {
    for (int i = 0; i < MarketplaceProfile.CATALOG.length; i++)
      if (MarketplaceProfile.CATALOG[i].name.equals(p.name)) return i;
    return 0;
  }

  double swapUserValue(InventoryItem item) {
    return app.coreUtilities.money(item.price.doubleValue() * 1.05).doubleValue();
  }

  double exchangeSwapMarkup(InventoryItem item) {
    double value = Math.max(0, item.price.doubleValue());
    if (value >= 1000) return .15;
    int rarity =
        java.util.Arrays.asList(
                "Consumer",
                "Industrial",
                "Milspec",
                "Restricted",
                "Classified",
                "Covert",
                "Knife",
                "Gloves",
                "Contraband")
            .indexOf(item.rarity.replace("StatTrak ", ""));
    return Math.min(
        .15,
        .10
            + Math.max(0, Math.min(1, Math.log10(1 + value) / 4.0)) * .035
            + Math.max(0, rarity) * .002);
  }

  double swapSiteValue(MarketListing lot) {
    return app.coreUtilities
        .money(lot.getPrice() * (1 + app.exchangeTransactionService.exchangeSwapMarkup(lot.item)))
        .doubleValue();
  }

  InventoryItem materializeExchangeItem(MarketListing lot, double paid) {
    InventoryItem src = lot.item;
    InventoryItem out =
        new InventoryItem(
            src.image,
            src.name,
            src.condition,
            src.rarity,
            app.coreUtilities.money(src.price.doubleValue()),
            src.itemFloat,
            src.isStattrak,
            src.patternID,
            src.blueGemTier,
            src.basePrice);

    out.collection = src.collection;
    out.currentOwner = "YOU";
    app.ownershipHistoryService.ensureInventoryItemTracking(out);
    String sourceId =
        src.itemId != null
            ? src.itemId
            : lot.stockParent != null ? lot.stockParent.item.itemId : null;
    if (sourceId != null && app.inventoryToolsService.state.customNames.containsKey(sourceId))
      app.inventoryToolsService.state.customNames.put(
          out.itemId, app.inventoryToolsService.state.customNames.get(sourceId));
    app.ownershipHistoryService.addItemHistory(
        out,
        System.currentTimeMillis(),
        "Bought From " + lot.marketplaceName,
        String.format("Purchased for $%.2f", paid),
        "YOU");
    return out;
  }

  boolean isExchangeLotAvailable(MarketListing lot) {
    if (lot == null || lot.quantity < 1 || lot.isPlayerListing) return false;
    if (lot.stockParent != null)
      return app.marketplaceUnitStock.available(lot) && isExchangeLotAvailable(lot.stockParent);
    ArrayList<MarketListing> b =
        app.globalMarketListings.get(
            lot.item.isStattrak ? "StatTrak " + lot.item.name : lot.item.name);
    return b != null && b.contains(lot);
  }

  void consumeExchangeLot(MarketListing lot) {
    if(lot==null||!Double.isFinite(lot.getPrice())||lot.getPrice()<=0)throw new IllegalArgumentException("This offer has no available price quote.");
    if (!app.exchangeTransactionService.isExchangeLotAvailable(lot))
      throw new IllegalArgumentException("This offer is no longer available.");
    if (lot.stockParent != null) {
      MarketListing parent = lot.stockParent;
      app.marketplaceUnitStock.consume(lot);
      if (parent.quantity == 0) {
        ArrayList<MarketListing> bucket =
            app.globalMarketListings.get(
                parent.item.isStattrak ? "StatTrak " + parent.item.name : parent.item.name);
        if (bucket != null) bucket.remove(parent);
      }
      app.marketStockService.invalidateGroupedMarketListingsCache();
      return;
    }
    if (app.marketplaceUnitStock.hasState(lot)) {
      consumeExchangeLot(app.marketplaceUnitStock.unit(lot, 0));
      return;
    }
    lot.quantity--;
    if (lot.quantity == 0) {
      ArrayList<MarketListing> b =
          app.globalMarketListings.get(
              lot.item.isStattrak ? "StatTrak " + lot.item.name : lot.item.name);
      b.remove(lot);
    } else {
      InventoryItem old = lot.item;
      lot.item =
          new InventoryItem(
              null,
              old.name,
              old.condition,
              old.rarity,
              app.coreUtilities.money(lot.getPrice()),
              app.floatRules.hasNoFloatWear(old.name)
                  ? 0
                  : app.marketGeneration.generateFloatForCondition(old.name, old.condition),
              old.isStattrak,
              hGui.random.nextInt(1000),
              null,
              old.basePrice,
              true);
      lot.item.collection = old.collection;
    }
    app.marketStockService.invalidateGroupedMarketListingsCache();
  }

  InventoryItem commitExchangePurchase(MarketListing lot, double displayedPrice) {
    synchronized (app) {
      if (!app.exchangeTransactionService.isExchangeLotAvailable(lot)
          || !Double.isFinite(displayedPrice)
          || displayedPrice <= 0
          || app.coreUtilities
                  .money(lot.getPrice())
                  .compareTo(app.coreUtilities.money(displayedPrice))
              != 0) throw new IllegalArgumentException("The offer changed. Refresh and try again.");
      if (app.coreUtilities.money(app.balance).compareTo(app.coreUtilities.money(displayedPrice))
          < 0) throw new IllegalArgumentException("Insufficient balance.");
      InventoryItem item =
          app.exchangeTransactionService.materializeExchangeItem(lot, displayedPrice);
      CaseType container = app.exchangeStockService.exchangeContainer(item.name);
      app.salesSimulationService.recordMarketListingSale(lot, "YOU", app.playerAvatar);
      app.playerPurchases.add(
          app.salesSimulationService.createSaleRecordFromListing(lot, "YOU", app.playerAvatar));
      app.exchangeTransactionService.consumeExchangeLot(lot);
      app.balance =
          app.coreUtilities
              .money(app.balance)
              .subtract(app.coreUtilities.money(displayedPrice))
              .doubleValue();
      if (container != null) {
        OwnedSupply supply = new OwnedSupply(container, false, displayedPrice);
        app.ownedSupplies.add(supply);
        app.itemRevealService.received(supply);
      } else if ("P2P".equals(lot.marketplaceType)) {
        TradeOffer delivery =
            new TradeOffer(
                lot.sellerName,
                lot.sellerAvatar,
                new ArrayList<>(java.util.Collections.singletonList(item)),
                0,
                new ArrayList<>(),
                0);
        delivery.isMarketplacePurchase = true;
        delivery.isInstantDelivery = false;
        delivery.marketplaceName = lot.marketplaceName;
        delivery.marketplaceType = lot.marketplaceType;
        delivery.settledPrice = displayedPrice;
        int delay = 30000 + hGui.random.nextInt(91000);
        delivery.deliveryScheduledTime = System.currentTimeMillis() + delay;
        app.pendingPurchaseTrades.add(delivery);
        app.unreadTradesCount++;
        app.tradeHubScreen.updateTradeNotification();
        javax.swing.Timer notification =
            new javax.swing.Timer(
                delay, e -> app.priceModifiers.showDeliveryReadyNotification(delivery));
        notification.setRepeats(false);
        notification.start();
      } else {
        app.inventoryList.add(item);
        app.itemRevealService.received(item);
        app.coreUtilities.addInventoryValue(item.price.doubleValue());
      }
      if (app.playerPurchases.size() > hGui.MAX_SALES_HISTORY) app.playerPurchases.removeFirst();
      app.missionProgress.marketSpent += displayedPrice;
      app.missionService.checkMissionProgress();
      app.exchangeTransactionService.exchangeTransactionChanged();
      return item;
    }
  }

  void exchangeTransactionChanged() {
    app.marketStockService.invalidateGroupedMarketListingsCache();
    app.containerSelectionScreen.invalidateCs2Inventory();
    app.uiWidgets.updateBalanceLabel();
    if (app.cs2BalanceLabel != null)
      app.cs2BalanceLabel.setText(String.format("$%,.2f", app.balance));
    app.cs2Screens.refreshCs2Inventory();
    app.saveService.saveProgress();
    app.marketHomeScreen.refreshMarketplaceSummarySnapshot();
  }

  void unEquipExchangeItem(InventoryItem item) {
    app.ctLoadout.values().removeIf(v -> v == item);
    app.tLoadout.values().removeIf(v -> v == item);
    app.tradeUpSelection.remove(item);
  }

  double commitExchangeQuickSell(MarketplaceProfile p, InventoryItem item, double shown) {
    synchronized (app) {
      if (!app.containerMarketService.owns(item)
          || app.cs2EquipmentScreens.isDefaultWeaponItem(item)
          || !Double.isFinite(shown)
          || shown <= 0) throw new IllegalArgumentException("Select an owned, sellable skin.");
      double quote = app.marketplacePricing.quickSellQuote(p, item);
      if (app.coreUtilities.money(quote).compareTo(app.coreUtilities.money(shown)) != 0)
        throw new IllegalArgumentException("The valuation changed. Review the new quote.");
      app.containerMarketService.remove(item);
      app.exchangeTransactionService.unEquipExchangeItem(item);
      app.balance =
          app.coreUtilities.money(app.balance).add(app.coreUtilities.money(quote)).doubleValue();
      app.missionProgress.marketSellCount++;
      app.ownershipHistoryService.addItemHistory(
          item, System.currentTimeMillis(), "Quick Sold", p.name + " paid $" + quote, p.name);
      MarketListing sold = new MarketListing(item, quote, 0, true);
      sold.marketplaceName = p.name;
      sold.marketplaceType = p.type;
      app.salesSimulationService.recordMarketListingSale(sold, p.name, null);
      app.totalMarketProfit += Math.max(0, quote - item.basePrice);
      app.missionService.checkMissionProgress();
      if (app.achievements.containsKey("first_sale")
          && !app.achievements.get("first_sale").isUnlocked)
        app.achievementScreen.unlockAchievement("first_sale");
      app.missionService.checkMarketAchievements();
      app.exchangeTransactionService.exchangeTransactionChanged();
      return quote;
    }
  }

  MarketListing commitExchangeListing(MarketplaceProfile p, InventoryItem item, double ask) {
    synchronized (app) {
      if (!app.containerMarketService.owns(item)
          || app.cs2EquipmentScreens.isDefaultWeaponItem(item)
          || !Double.isFinite(ask)
          || ask <= 0
          || ask > 1e12)
        throw new IllegalArgumentException(
            "Choose an owned skin and a valid positive asking price.");
      if (MarketplacePricing.automatic(p.name)) {
        double fixed = app.marketplacePricing.quote(p, item);
        if (app.coreUtilities.money(ask).compareTo(app.coreUtilities.money(fixed)) != 0)
          throw new IllegalArgumentException(
              "The automatic site quote changed. Refresh before listing.");
        ask = fixed;
      }
      MarketListing listing =
          new MarketListing(
              item,
              app.coreUtilities.money(ask).doubleValue(),
              app.listingSalesService.calculateSellTime(ask, item.price.doubleValue()),
              true);
      listing.marketplaceName = p.name;
      listing.marketplaceType = p.type;
      listing.marketplaceRating = p.rating;
      listing.marketplaceReviews = p.reviews;
      listing.saleFee = app.exchangeTransactionService.exchangeListingFee(p);
      app.containerMarketService.remove(item);
      app.exchangeTransactionService.unEquipExchangeItem(item);
      app.activeListings.add(listing);
      String key = item.isStattrak ? "StatTrak " + item.name : item.name;
      app.globalMarketListings.computeIfAbsent(key, k -> new ArrayList<>()).add(listing);
      app.exchangeSiteStock.computeIfAbsent(p.name, k -> new ArrayList<>()).add(listing);
      app.ownershipHistoryService.addItemHistory(
          item,
          System.currentTimeMillis(),
          "Listed On Market",
          String.format("%s asking $%.2f; fee %.1f%%", p.name, ask, listing.saleFee * 100),
          "YOU");
      app.exchangeTransactionService.exchangeTransactionChanged();
      return listing;
    }
  }

  double commitExchangeSwap(
      MarketplaceProfile p,
      List<InventoryItem> given,
      List<MarketListing> wanted,
      double displayedDebit) {
    synchronized (app) {
      if (!ExchangeStockService.supportsExchangeSwap(p.name) || given.isEmpty() || wanted.isEmpty())
        throw new IllegalArgumentException("Select skins on both sides.");
      Set<InventoryItem> unique = new HashSet<>(given);
      Set<MarketListing> uniqueLots = new HashSet<>(wanted);
      if (unique.size() != given.size() || uniqueLots.size() != wanted.size())
        throw new IllegalArgumentException("Duplicate selection.");
      for (InventoryItem i : given)
        if (!app.inventoryList.contains(i) || app.cs2EquipmentScreens.isDefaultWeaponItem(i))
          throw new IllegalArgumentException("One of your selected skins is no longer available.");
      for (MarketListing l : wanted)
        if (!app.exchangeTransactionService.isExchangeLotAvailable(l)
            || !p.name.equals(l.marketplaceName)
            || app.exchangeStockService.exchangeContainer(l.item.name) != null)
          throw new IllegalArgumentException("One of the requested skins is no longer available.");
      BigDecimal credit = BigDecimal.ZERO, cost = BigDecimal.ZERO;
      for (InventoryItem i : given)
        credit =
            credit.add(app.coreUtilities.money(app.exchangeTransactionService.swapUserValue(i)));
      for (MarketListing l : wanted)
        cost = cost.add(app.coreUtilities.money(app.exchangeTransactionService.swapSiteValue(l)));
      BigDecimal debit = cost.subtract(credit);
      if (!Double.isFinite(displayedDebit)
          || debit.compareTo(BigDecimal.valueOf(displayedDebit).setScale(2, RoundingMode.HALF_UP))
              != 0)
        throw new IllegalArgumentException("The swap valuation changed. Review the totals.");
      if (debit.signum() > 0 && app.coreUtilities.money(app.balance).compareTo(debit) < 0)
        throw new IllegalArgumentException("Insufficient balance for the difference.");
      List<InventoryItem> received = new ArrayList<>();
      for (MarketListing l : wanted)
        received.add(
            app.exchangeTransactionService.materializeExchangeItem(
                l, app.exchangeTransactionService.swapSiteValue(l)));
      for (MarketListing l : wanted) app.exchangeTransactionService.consumeExchangeLot(l);
      for (InventoryItem i : given) {
        app.inventoryList.remove(i);
        app.exchangeTransactionService.unEquipExchangeItem(i);
        app.inventoryValue = Math.max(0, app.inventoryValue - i.price.doubleValue());
        app.ownershipHistoryService.addItemHistory(
            i, System.currentTimeMillis(), "Swapped", p.name, p.name);
        double reference = i.price.doubleValue();
        MarketListing resale = new MarketListing(i, reference, 120, false);
        app.marketStockService.assignMarketplaceProfile(resale, p);
        resale.setPrice(reference);
        i.price = app.coreUtilities.money(reference);
        app.globalMarketListings
            .computeIfAbsent(i.isStattrak ? "StatTrak " + i.name : i.name, k -> new ArrayList<>())
            .add(resale);
        app.exchangeSiteStock.computeIfAbsent(p.name, k -> new ArrayList<>()).add(resale);
      }
      for (InventoryItem i : received) {
        app.inventoryList.add(i);
        app.itemRevealService.received(i);
        app.coreUtilities.addInventoryValue(i.price.doubleValue());
      }
      app.balance = app.coreUtilities.money(app.balance).subtract(debit).doubleValue();
      app.exchangeTransactionService.exchangeTransactionChanged();
      return debit.doubleValue();
    }
  }
}
