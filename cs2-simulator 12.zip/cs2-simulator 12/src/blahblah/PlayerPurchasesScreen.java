package blahblah;

import blahblah.hGui.*;
import java.awt.*;
import java.awt.event.*;
import javax.swing.*;
import javax.swing.table.AbstractTableModel;

/** Player Purchases Screen: focused feature implementation. */
final class PlayerPurchasesScreen {
  private final hGui app;

  PlayerPurchasesScreen(hGui app) {
    this.app = app;
  }

  JPanel createPlayerPurchasesPanel() {
    Color BG_ROW = new Color(30, 30, 40);
    Color BG_ROW_ALT = new Color(25, 25, 35);
    Color HEADER_BG = new Color(35, 50, 70);

    JPanel panel = new JPanel(new BorderLayout());
    panel.setBackground(Theme.BG_DARK);

    String[] columns = {"Time", "Skin", "Condition", "Float", "Price", "Special"};
    AbstractTableModel model =
        new AbstractTableModel() {
          @Override
          public int getRowCount() {
            return app.playerPurchases.size();
          }

          @Override
          public int getColumnCount() {
            return columns.length;
          }

          @Override
          public String getColumnName(int column) {
            return columns[column];
          }

          @Override
          public boolean isCellEditable(int row, int column) {
            return false;
          }

          @Override
          public Object getValueAt(int row, int column) {
            int realIdx = app.playerPurchases.size() - 1 - row;
            if (realIdx < 0 || realIdx >= app.playerPurchases.size()) return "";
            SaleRecord sale = app.playerPurchases.get(realIdx);
            switch (column) {
              case 0:
                long secondsAgo = (System.currentTimeMillis() - sale.timestamp) / 1000;
                return secondsAgo < 60
                    ? secondsAgo + "s ago"
                    : secondsAgo < 3600
                        ? (secondsAgo / 60) + "m ago"
                        : (secondsAgo / 3600) + "h ago";
              case 1:
                return sale.skinName;
              case 2:
                return sale.condition;
              case 3:
                return String.format("%.6f", sale.itemFloat);
              case 4:
                return "$" + String.format("%.2f", sale.price);
              case 5:
                return sale.specialVariant != null ? sale.specialVariant : "-";
              default:
                return "";
            }
          }
        };

    JTable table = new JTable(model);
    table.setRowHeight(26);
    table.setFont(new Font("Consolas", Font.PLAIN, 11));
    table.setBackground(BG_ROW);
    table.setForeground(Theme.TEXT);
    table.setGridColor(new Color(40, 40, 55));
    table.setSelectionBackground(new Color(50, 80, 110));
    table.setSelectionForeground(Color.WHITE);
    table.getTableHeader().setBackground(HEADER_BG);
    table.getTableHeader().setForeground(Theme.ACCENT_CT);
    table.getTableHeader().setFont(new Font("Consolas", Font.BOLD, 11));
    table.setShowHorizontalLines(true);
    table.setShowVerticalLines(false);

    table.setDefaultRenderer(
        Object.class,
        new javax.swing.table.DefaultTableCellRenderer() {
          @Override
          public java.awt.Component getTableCellRendererComponent(
              JTable t, Object v, boolean sel, boolean foc, int row, int col) {
            super.getTableCellRendererComponent(t, v, sel, foc, row, col);
            setBackground(sel ? new Color(50, 80, 110) : (row % 2 == 0 ? BG_ROW : BG_ROW_ALT));
            setForeground(col == 4 ? new Color(255, 210, 60) : Theme.TEXT);
            setBorder(BorderFactory.createEmptyBorder(0, 4, 0, 4));
            return this;
          }
        });
    table.getColumnModel().getColumn(0).setPreferredWidth(80);
    table.getColumnModel().getColumn(1).setPreferredWidth(250);
    table.getColumnModel().getColumn(2).setPreferredWidth(120);
    table.getColumnModel().getColumn(3).setPreferredWidth(100);
    table.getColumnModel().getColumn(4).setPreferredWidth(80);
    table.getColumnModel().getColumn(5).setPreferredWidth(150);

    JScrollPane scroll = new JScrollPane(table);
    scroll.getViewport().setBackground(Theme.BG_DARK);
    scroll.setBorder(null);
    panel.add(scroll, BorderLayout.CENTER);

    JLabel infoLabel = new JLabel("  Your Purchase History", SwingConstants.LEFT);
    infoLabel.setFont(new Font("Consolas", Font.BOLD, 13));
    infoLabel.setForeground(Theme.ACCENT_CT);
    infoLabel.setOpaque(true);
    infoLabel.setBackground(HEADER_BG);
    infoLabel.setBorder(BorderFactory.createEmptyBorder(8, 8, 8, 8));
    panel.add(infoLabel, BorderLayout.NORTH);

    final int[] lastKnownSize = {-1};
    javax.swing.Timer updateTimer =
        new javax.swing.Timer(
            1000,
            e -> {
              if (app.playerPurchases.size() != lastKnownSize[0]) {
                lastKnownSize[0] = app.playerPurchases.size();
                model.fireTableDataChanged();
              } else {
                int lastRow = model.getRowCount() - 1;
                if (lastRow >= 0) {
                  model.fireTableRowsUpdated(0, lastRow);
                }
              }
            });

    panel.addHierarchyListener(
        e -> {
          if ((e.getChangeFlags() & java.awt.event.HierarchyEvent.SHOWING_CHANGED) != 0
              && !panel.isShowing()) {
            updateTimer.stop();
          }
        });
    updateTimer.start();

    return panel;
  }
}
