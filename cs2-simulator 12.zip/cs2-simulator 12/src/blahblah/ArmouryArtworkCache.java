package blahblah;

import java.awt.*;
import java.awt.image.BufferedImage;
import java.util.*;
import java.util.concurrent.ConcurrentHashMap;
import javax.swing.*;

/**
 * Small permanently retained catalog previews, populated during startup rather than first click.
 */
final class ArmouryArtworkCache {
  private final hGui app;
  private final Set<String> names = ConcurrentHashMap.newKeySet();
  private final Map<String, Image> previews = new ConcurrentHashMap<>();
  private final Map<String, java.util.List<java.lang.ref.WeakReference<JLabel>>> labels =
      new ConcurrentHashMap<>();

  ArmouryArtworkCache(hGui app) {
    this.app = app;
    refreshNames();
  }

  private void refreshNames() {
    for (ArmouryCollection c : hGui.ARMOURY_COLLECTIONS)
      for (String[] tier : ArmouryBrowserScreen.tiers(c))
        if (tier != null)
          for (String name : tier) {
            names.add(name);
            if (app.artworkService != null)
              names.add(app.artworkService.canonicalArtworkName(name));
          }
  }

  void remember(String key, Image image) {
    if (key == null || image == null) return;
    key = app.artworkService.canonicalArtworkName(app.artworkService.artworkSkin(key));
    Image bundled = BundledAgentPreviews.image(key);
    if (bundled != null) image = bundled;
    if (previews.containsKey(key)) return;
    if (!names.contains(key)) refreshNames();
    if (!names.contains(key)) return;
    int w = image.getWidth(null), h = image.getHeight(null);
    if (w < 1 || h < 1) return;
    double scale = Math.min(260.0 / w, 118.0 / h);
    BufferedImage thumb =
        new BufferedImage(
            Math.max(1, (int) (w * scale)),
            Math.max(1, (int) (h * scale)),
            BufferedImage.TYPE_INT_ARGB);
    Graphics2D g = thumb.createGraphics();
    g.setRenderingHint(
        RenderingHints.KEY_INTERPOLATION, RenderingHints.VALUE_INTERPOLATION_BICUBIC);
    g.drawImage(image, 0, 0, thumb.getWidth(), thumb.getHeight(), null);
    g.dispose();
    previews.putIfAbsent(key, thumb);
    String ready = key;
    SwingUtilities.invokeLater(
        () -> {
          java.util.List<java.lang.ref.WeakReference<JLabel>> targets = labels.get(ready);
          if (targets != null)
            targets.removeIf(
                ref -> {
                  JLabel label = ref.get();
                  if (label != null) label.repaint();
                  return label == null;
                });
        });
  }

  void warm() {
    refreshNames();
    for (String name : names) {
      if (previews.containsKey(name)) continue;
      Image agent = BundledAgentPreviews.image(name);
      if (agent != null) {
        remember(name, agent);
        continue;
      }
      Image resident = app.imageRepository.get(name);
      if (resident != null) {
        remember(name, resident);
        continue;
      }
      SkinMetadata metadata =
          app.artworkService.getArtworkMetadata(app.artworkService.canonicalArtworkName(name));
      if (metadata == null || metadata.imageUrl == null) continue;
      String resolved =
          app.startupResolvedArtworkUrls.getOrDefault(metadata.imageUrl, metadata.imageUrl);
      if (app.imageRepository.isCachedOnDisk(resolved))
        try {
          remember(name, app.imageRepository.readRemoteCachedImage(resolved));
        } catch (java.io.IOException ignored) {
          /* runtime artwork report retains actual failures */
        }
    }
  }

  JLabel label(String name) {
    final String key = app.artworkService.canonicalArtworkName(name);
    Image cached = BundledAgentPreviews.image(name);
    if (cached == null) cached = app.artworkService.getSkinImageFromName(name);
    if (cached != null) remember(name, cached);
    JLabel result =
        new JLabel() {
          protected void paintComponent(Graphics graphics) {
            super.paintComponent(graphics);
            Image image = previews.get(key);
            if (image == null) {
              graphics.setColor(new Color(181, 205, 213));
              graphics.setFont(new Font("SansSerif", Font.PLAIN, 11));
              String text = "Loading artwork…";
              graphics.drawString(
                  text,
                  Math.max(2, (getWidth() - graphics.getFontMetrics().stringWidth(text)) / 2),
                  getHeight() / 2);
              return;
            }
            int w = image.getWidth(null), h = image.getHeight(null);
            double scale =
                Math.min(
                    Math.max(1, getWidth() - 8) / (double) w,
                    Math.max(1, getHeight() - 4) / (double) h);
            int iw = Math.max(1, (int) (w * scale)), ih = Math.max(1, (int) (h * scale));
            Graphics2D g = (Graphics2D) graphics.create();
            g.setRenderingHint(
                RenderingHints.KEY_INTERPOLATION, RenderingHints.VALUE_INTERPOLATION_BICUBIC);
            g.drawImage(image, (getWidth() - iw) / 2, (getHeight() - ih) / 2, iw, ih, null);
            g.dispose();
          }
        };
    result.setName("armouryArtwork");
    result.putClientProperty("catalogName", name);
    labels
        .computeIfAbsent(key, k -> new java.util.concurrent.CopyOnWriteArrayList<>())
        .add(new java.lang.ref.WeakReference<>(result));
    return result;
  }

  boolean contains(String name) {
    return previews.containsKey(app.artworkService.canonicalArtworkName(name));
  }

  int size() {
    return previews.size();
  }
}
