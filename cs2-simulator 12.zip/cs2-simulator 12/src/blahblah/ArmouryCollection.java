package blahblah;

import blahblah.hGui.*;
import java.awt.*;
import java.awt.event.*;
import javax.swing.*;

/** Extracted reusable model or widget; behavior retained from the original source. */
public class ArmouryCollection {
  String name;
  String[] consumer;
  String[] consumerNames;
  double[] consumerPrices;
  String[] industrial;
  String[] industrialNames;
  double[] industrialPrices;
  String[] milspec;
  String[] milspecNames;
  double[] milspecPrices;
  String[] restricted;
  String[] restrictedNames;
  double[] restrictedPrices;
  String[] classified;
  String[] classifiedNames;
  double[] classifiedPrices;
  String[] covert;
  String[] covertNames;
  double[] covertPrices;
  String thumbnailFile;
  boolean isAgents;

  ArmouryCollection(
      String name,
      String[] industrial,
      String[] industrialNames,
      double[] industrialPrices,
      String[] milspec,
      String[] milspecNames,
      double[] milspecPrices,
      String[] restricted,
      String[] restrictedNames,
      double[] restrictedPrices,
      String[] classified,
      String[] classifiedNames,
      double[] classifiedPrices,
      String[] covert,
      String[] covertNames,
      double[] covertPrices) {
    this.name = name;
    this.isAgents = false;
    this.consumer = null;
    this.consumerNames = null;
    this.consumerPrices = null;
    this.industrial = industrial;
    this.industrialNames = industrialNames;
    this.industrialPrices = industrialPrices;
    this.milspec = milspec;
    this.milspecNames = milspecNames;
    this.milspecPrices = milspecPrices;
    this.restricted = restricted;
    this.restrictedNames = restrictedNames;
    this.restrictedPrices = restrictedPrices;
    this.classified = classified;
    this.classifiedNames = classifiedNames;
    this.classifiedPrices = classifiedPrices;
    this.covert = covert;
    this.covertNames = covertNames;
    this.covertPrices = covertPrices;
    this.thumbnailFile = covert != null && covert.length > 0 ? covert[0] + ".png" : null;
  }

  ArmouryCollection(
      String name,
      String[] industrial,
      String[] industrialNames,
      double[] industrialPrices,
      String[] milspec,
      String[] milspecNames,
      double[] milspecPrices,
      String[] restricted,
      String[] restrictedNames,
      double[] restrictedPrices,
      String[] classified,
      String[] classifiedNames,
      double[] classifiedPrices,
      String[] covert,
      String[] covertNames,
      double[] covertPrices,
      String[] consumer,
      String[] consumerNames,
      double[] consumerPrices) {
    this(
        name,
        industrial,
        industrialNames,
        industrialPrices,
        milspec,
        milspecNames,
        milspecPrices,
        restricted,
        restrictedNames,
        restrictedPrices,
        classified,
        classifiedNames,
        classifiedPrices,
        covert,
        covertNames,
        covertPrices);
    this.consumer = consumer;
    this.consumerNames = consumerNames;
    this.consumerPrices = consumerPrices;
  }

  ArmouryCollection(
      String name,
      boolean agentsFlag,
      String[] distinguished,
      String[] distinguishedNames,
      double[] distinguishedPrices,
      String[] exceptional,
      String[] exceptionalNames,
      double[] exceptionalPrices,
      String[] superior,
      String[] superiorNames,
      double[] superiorPrices,
      String[] master,
      String[] masterNames,
      double[] masterPrices) {
    this.name = name;
    this.isAgents = agentsFlag;
    this.consumer = null;
    this.consumerNames = null;
    this.consumerPrices = null;
    this.industrial = null;
    this.industrialNames = null;
    this.industrialPrices = null;
    this.milspec = distinguished;
    this.milspecNames = distinguishedNames;
    this.milspecPrices = distinguishedPrices;
    this.restricted = exceptional;
    this.restrictedNames = exceptionalNames;
    this.restrictedPrices = exceptionalPrices;
    this.classified = superior;
    this.classifiedNames = superiorNames;
    this.classifiedPrices = superiorPrices;
    this.covert = master;
    this.covertNames = masterNames;
    this.covertPrices = masterPrices;
    this.thumbnailFile = master != null && master.length > 0 ? master[0] + ".png" : null;
  }
}
