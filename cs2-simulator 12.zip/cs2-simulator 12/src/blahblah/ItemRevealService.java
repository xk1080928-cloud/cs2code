package blahblah;

import blahblah.hGui.*;
import java.awt.*;
import java.awt.event.*;
import java.util.*;
import java.util.List;
import javax.swing.*;

/** Shared rarity-lit NEW ITEM stage for contracts and acknowledged marketplace deliveries. */
final class ItemRevealService {
  private final hGui app;
  boolean showing, tradeUpPending;

  ItemRevealService(hGui app) {
    this.app = app;
  }

  void received(InventoryItem i) {
    app.ownershipHistoryService.ensureInventoryItemTracking(i);
    app.inventoryToolsService.state.newItems.add(i.itemId);
  }

  void received(OwnedSupply s) {
    app.inventoryToolsService.state.newItems.add("supply:" + s.id);
  }

  JPanel panel(InventoryItem item, Runnable close) {
    return panel(item, close, true);
  }

  JPanel panel(InventoryItem item, Runnable close, boolean showInfo) {
    app.inventoryScreen.resolveInventoryItemCollection(item);
    Color rarity = app.itemInspectionScreen.getRarityColor(item.rarity);
    final long animationEpoch = System.nanoTime();
    JPanel root =
        new JPanel(new BorderLayout(0, 0)) {
          protected void paintComponent(Graphics graphics) {
            Graphics2D g = (Graphics2D) graphics.create();
            int w = getWidth(), h = getHeight();
            g.setColor(new Color(12, 10, 14));
            g.fillRect(0, 0, w, h);
            Color center =
                new Color(
                    Math.max(24, rarity.getRed() / 2),
                    Math.max(10, rarity.getGreen() / 3),
                    Math.max(12, rarity.getBlue() / 3));
            g.setPaint(
                new RadialGradientPaint(
                    w * .53f,
                    h * .47f,
                    Math.max(1, w * .72f),
                    new float[] {0, .55f, 1},
                    new Color[] {
                      center,
                      new Color(center.getRed() / 3, center.getGreen() / 3, center.getBlue() / 3),
                      new Color(8, 8, 12)
                    }));
            g.fillRect(0, 0, w, h);
            double rotation = (System.nanoTime() - animationEpoch) / 1e9 * Math.PI * 2 / 100;
            putClientProperty("backgroundRotation", rotation);
            Graphics2D lines = (Graphics2D) g.create();
            lines.rotate(rotation, w * .53, h * .48);
            lines.setStroke(new BasicStroke(1));
            for (int n = 0; n < 14; n++) {
              lines.setColor(
                  new Color(rarity.getRed(), rarity.getGreen(), rarity.getBlue(), 14 + n % 4 * 5));
              int x = (n * 149 + 17) % Math.max(1, w);
              int y = (n * 61 + 38) % Math.max(1, h);
              lines.drawLine(x, y, (int) (w * .53), (int) (h * .48));
            }
            lines.dispose();
            g.setColor(rarity);
            g.fillRect(0, 0, 7, h);
            g.dispose();
          }
        };
    root.setName("tradeUpResultPanel");
    javax.swing.Timer orbitLines = new javax.swing.Timer(33, e -> root.repaint());
    orbitLines.setCoalesce(true);
    root.addHierarchyListener(
        e -> {
          if ((e.getChangeFlags() & java.awt.event.HierarchyEvent.SHOWING_CHANGED) != 0) {
            if (root.isShowing()) orbitLines.start();
            else orbitLines.stop();
          }
        });
    root.setBorder(BorderFactory.createEmptyBorder(22, 30, 16, 26));
    JLabel title = app.cs2Screens.cs2Text("NEW ITEM", 32, rarity);
    title.setFont(app.cs2Screens.cs2Font(Font.BOLD, 32));
    root.add(title, BorderLayout.NORTH);
    JPanel center = app.cs2Screens.cs2Glass(new BorderLayout());
    JLabel art;
    CaseType ct = app.exchangeStockService.exchangeContainer(item.name);
    if (ct != null) {
      art = new JLabel("", SwingConstants.CENTER);
      app.cs2Screens.bindCs2SupplyArtwork(ct, false, art, 540, 275);
    } else
      art =
          app.tradeUpScreen.createTradeUpSkinArtwork(
              item.name,
              item.condition,
              item.image == null ? null : item.image.getImage(),
              540,
              275);
    art.setPreferredSize(new Dimension(540, 275));
    center.add(art);
    JPanel identity = ItemPresentation.identity(app, item, 19, "tradeUpResult", false);
    identity.setBorder(BorderFactory.createEmptyBorder(0, 4, 20, 0));
    center.add(identity, BorderLayout.SOUTH);
    root.add(center);
    JPanel footer = app.cs2Screens.cs2Glass(new BorderLayout(12, 0));
    footer.setBorder(
        BorderFactory.createCompoundBorder(
            BorderFactory.createMatteBorder(1, 0, 0, 0, new Color(255, 255, 255, 45)),
            BorderFactory.createEmptyBorder(12, 4, 0, 0)));
    String info =
        app.uiWidgets.buildItemInfoHtml(
            item.rarity, item.condition, item.itemFloat, item.patternID, item.collection, false);
    JComponent badge = app.uiWidgets.createInfoBadge(info);
    badge.setName("tradeUpResultInfo");
    badge.putClientProperty("itemInfoHtml", info);
    if (showInfo) footer.add(badge, BorderLayout.WEST);
    JPanel actions = app.cs2Screens.cs2Glass(new FlowLayout(FlowLayout.RIGHT, 10, 0));
    if (app.inventoryList.contains(item) && ct == null)
      actions.add(
          app.cs2Screens.cs2Button(
              "VIEW IN LOADOUT",
              false,
              e -> {
                close.run();
                app.mainTabs.setSelectedIndex(5);
              }));
    JButton done = app.cs2Screens.cs2Button("CONTINUE", false, e -> close.run());
    done.setName("tradeUpResultClose");
    actions.add(done);
    footer.add(actions, BorderLayout.EAST);
    root.add(footer, BorderLayout.SOUTH);
    return root;
  }

  void tradeUp(InventoryItem item) {
    if (tradeUpPending) return;
    if (app.inventoryToolsService.state.pendingTradeRewards == null)
      app.inventoryToolsService.state.pendingTradeRewards = new ArrayList<>();
    if (app.inventoryList.remove(item))
      app.coreUtilities.setInventoryValueRounded(
          Math.max(0, app.inventoryValue - item.price.doubleValue()));
    app.inventoryToolsService.state.pendingTradeRewards.add(InventoryItemCodec.encode(item));
    presentTradeUp(item);
  }

  private void presentTradeUp(InventoryItem item) {
    tradeUpPending = true;
    app.navigationService.mainInventory();
    app.saveService.saveProgressAsync();
    final long version = app.worldVersion;
    javax.swing.Timer delay =
        new javax.swing.Timer(
            PageTransitions.DURATION_MS + 180,
            e -> {
              if (version != app.worldVersion) {
                tradeUpPending = false;
                resumeTradeUp();
                return;
              }
              try {
                show(List.of(item), false);
              } finally {
                tradeUpPending = false;
                app.cs2EquipmentScreens.refreshCs2TradeUp();
              }
            });
    delay.setRepeats(false);
    delay.start();
  }

  void resumeTradeUp() {
    if (tradeUpPending || !app.marketInitialized || !app.isShowing()) return;
    List<hGui.GameState.SerializableInventoryItem> pending =
        app.inventoryToolsService.state.pendingTradeRewards;
    if (pending != null && !pending.isEmpty())
      SwingUtilities.invokeLater(
          () -> {
            if (!tradeUpPending && !showing)
              presentTradeUp(InventoryItemCodec.decode(pending.get(0)));
          });
  }

  private void commitPending(InventoryItem item) {
    List<hGui.GameState.SerializableInventoryItem> pending =
        app.inventoryToolsService.state.pendingTradeRewards;
    if (pending == null
        || pending.stream().noneMatch(p -> java.util.Objects.equals(p.itemId, item.itemId))) return;
    if (app.inventoryList.stream()
        .noneMatch(i -> java.util.Objects.equals(i.itemId, item.itemId))) {
      app.inventoryList.add(item);
      app.coreUtilities.addInventoryValue(item.price.doubleValue());
    }
    pending.removeIf(p -> java.util.Objects.equals(p.itemId, item.itemId));
    app.missionService.checkInventoryCollectionAchievements();
    app.containerSelectionScreen.invalidateCs2Inventory();
    app.cs2Screens.refreshCs2Inventory();
    app.saveService.saveProgressAsync();
  }

  void showPending() {
    if (showing
        || tradeUpPending
        || app.isAnimating
        || !app.isShowing()
        || app.mainTabs.getSelectedIndex() != 2) return;
    List<InventoryItem> items = new ArrayList<>();
    List<String> stale = new ArrayList<>();
    for (String id : new ArrayList<>(app.inventoryToolsService.state.newItems)) {
      InventoryItem found = null;
      for (InventoryItem i : app.inventoryList)
        if (id.equals(i.itemId)) {
          found = i;
          break;
        }
      if (found == null && id.startsWith("supply:"))
        for (OwnedSupply s : app.ownedSupplies)
          if (id.equals("supply:" + s.id) && !s.key) {
            found = app.containerMarketService.item(s);
            break;
          }
      if (found != null) items.add(found);
      else stale.add(id);
    }
    app.inventoryToolsService.state.newItems.removeAll(stale);
    if (!items.isEmpty()) show(items, true);
  }

  void show(List<InventoryItem> items, boolean acknowledge) {
    show(items, acknowledge, null);
  }

  void show(List<InventoryItem> items, boolean acknowledge, String source) {
    if (items.isEmpty() || showing) return;
    showing = true;
    JDialog d =
        new JDialog(
            app,
            "Armoury Redeem".equals(source)
                ? "New Item"
                : acknowledge ? "New Items" : "Trade-Up Complete",
            true);
    d.setDefaultCloseOperation(JDialog.DISPOSE_ON_CLOSE);
    Component oldGlass = app.getGlassPane();
    boolean oldVisible = oldGlass.isVisible();
    JPanel dim =
        new JPanel() {
          protected void paintComponent(Graphics g) {
            g.setColor(new Color(0, 0, 0, 135));
            g.fillRect(0, 0, getWidth(), getHeight());
          }
        };
    dim.setName("itemRevealDim");
    dim.setOpaque(false);
    app.setGlassPane(dim);
    dim.setVisible(true);
    JPanel host = new JPanel(new BorderLayout());
    host.setBackground(new Color(10, 10, 13));
    int[] index = {0};
    Runnable[] render = {null};
    Runnable[] restartFade = {() -> {}};
    render[0] =
        () -> {
          host.removeAll();
          JPanel item = panel(items.get(index[0]), d::dispose, !"Armoury Redeem".equals(source));
          if (source != null && !"Armoury Redeem".equals(source)) {
            Component title =
                ((BorderLayout) item.getLayout()).getLayoutComponent(BorderLayout.NORTH);
            if (title instanceof JLabel) ((JLabel) title).setText(source);
            item.putClientProperty("rewardSource", source);
          }
          host.add(item);
          if (items.size() > 1) {
            JButton prev =
                app.cs2Screens.cs2Button(
                    "‹",
                    false,
                    e -> {
                      index[0] = (index[0] + items.size() - 1) % items.size();
                      render[0].run();
                      restartFade[0].run();
                    });
            JButton next =
                app.cs2Screens.cs2Button(
                    "›",
                    false,
                    e -> {
                      index[0] = (index[0] + 1) % items.size();
                      render[0].run();
                      restartFade[0].run();
                    });
            prev.setName("newItemsPrevious");
            next.setName("newItemsNext");
            JPanel center =
                (JPanel) ((BorderLayout) item.getLayout()).getLayoutComponent(BorderLayout.CENTER);
            for (JButton arrow : new JButton[] {prev, next}) {
              arrow.setContentAreaFilled(false);
              arrow.setOpaque(false);
              arrow.setFont(app.cs2Screens.cs2Font(Font.BOLD, 28));
              arrow.setBorder(BorderFactory.createEmptyBorder(0, 8, 0, 8));
            }
            center.add(prev, BorderLayout.WEST);
            center.add(next, BorderLayout.EAST);
            Component identity =
                ((BorderLayout) center.getLayout()).getLayoutComponent(BorderLayout.SOUTH);
            JPanel line = app.cs2Screens.cs2Glass(new BorderLayout());
            line.add(identity);
            JLabel counter =
                app.cs2Screens.cs2Text((index[0] + 1) + " / " + items.size(), 14, Color.WHITE);
            counter.setVerticalAlignment(SwingConstants.BOTTOM);
            counter.setBorder(BorderFactory.createEmptyBorder(0, 8, 20, 0));
            line.add(counter, BorderLayout.EAST);
            center.add(line, BorderLayout.SOUTH);
          }
          Component done = app.tradeUpScreen.findNamedComponent(host, "tradeUpResultClose");
          if (done instanceof JButton) d.getRootPane().setDefaultButton((JButton) done);
          host.revalidate();
          host.repaint();
        };
    render[0].run();
    final float[] alpha = {0};
    JLayer<JPanel> fade =
        new JLayer<>(
            host,
            new javax.swing.plaf.LayerUI<JPanel>() {
              public void paint(Graphics graphics, JComponent c) {
                Graphics2D g = (Graphics2D) graphics.create();
                g.setColor(new Color(10, 10, 13));
                g.fillRect(0, 0, c.getWidth(), c.getHeight());
                g.setComposite(AlphaComposite.SrcOver.derive(alpha[0]));
                super.paint(g, c);
                g.dispose();
              }
            });
    long[] began = {System.nanoTime()};
    fade.setName("itemRevealFade");
    javax.swing.Timer fadeTimer =
        new javax.swing.Timer(
            16,
            e -> {
              alpha[0] = Math.min(1f, (System.nanoTime() - began[0]) / 350_000_000f);
              fade.putClientProperty("revealAlpha", alpha[0]);
              fade.repaint();
              if (alpha[0] >= 1) ((javax.swing.Timer) e.getSource()).stop();
            });
    fadeTimer.setCoalesce(true);
    int[] sequence = {0};
    restartFade[0] =
        () -> {
          alpha[0] = 0;
          began[0] = System.nanoTime();
          fade.putClientProperty("revealAlpha", 0f);
          fade.putClientProperty("revealAnimationSequence", ++sequence[0]);
          fadeTimer.restart();
          fade.repaint();
        };
    java.util.concurrent.atomic.AtomicBoolean settled =
        new java.util.concurrent.atomic.AtomicBoolean();
    Runnable settle =
        () -> {
          if (!settled.compareAndSet(false, true)) return;
          for (InventoryItem item : items) commitPending(item);
          fadeTimer.stop();
          if (app.getGlassPane() == dim) {
            app.setGlassPane(oldGlass);
            oldGlass.setVisible(oldVisible);
            app.getRootPane().revalidate();
            app.getRootPane().repaint();
          }
          showing = false;
          if (acknowledge) {
            for (InventoryItem item : items) {
              app.inventoryToolsService.state.newItems.remove(item.itemId);
              app.carePackages.state().pending.remove(item.itemId);
            }
            app.saveService.saveProgressAsync();
          }
          if (!app.carePackages.state().pending.isEmpty()) app.carePackages.queuePresentation();
        };
    d.addWindowListener(
        new WindowAdapter() {
          public void windowOpened(WindowEvent e) {
            for (InventoryItem item : items) commitPending(item);
          }

          public void windowClosed(WindowEvent e) {
            settle.run();
          }
        });
    d.setContentPane(fade);
    d.setSize(Math.min(940, app.getWidth() - 100), Math.min(585, app.getHeight() - 100));
    d.setLocationRelativeTo(app);
    d.getRootPane()
        .registerKeyboardAction(
            e -> d.dispose(), KeyStroke.getKeyStroke("ESCAPE"), JComponent.WHEN_IN_FOCUSED_WINDOW);
    // Lay out and paint the dim layer BEFORE entering the modal secondary loop.
    // Otherwise native owner repaint can arrive after the reward's first frame.
    app.validate();
    dim.setSize(app.getRootPane().getSize());
    dim.revalidate();
    dim.paintImmediately(0, 0, dim.getWidth(), dim.getHeight());
    Toolkit.getDefaultToolkit().sync();
    fadeTimer.start();
    try {
      d.setVisible(true);
    } finally {
      settle.run();
    }
  }
}
