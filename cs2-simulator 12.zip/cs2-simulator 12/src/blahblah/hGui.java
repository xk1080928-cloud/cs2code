package blahblah;

import blahblah.hGui.*;
import java.awt.*;
import java.awt.event.*;
import java.util.ArrayList;
import java.util.Map;
import java.util.Set;
import javax.swing.*;

/** Application entry point and serialization-compatible legacy nested save types. */
@SuppressWarnings("serial")
public class hGui extends SimulatorContext {

  public static void main(String[] args) {
    System.setProperty("sun.java2d.uiScale.enabled", "true");
    System.setProperty("awt.useSystemAAFontSettings", "on");
    System.setProperty("swing.aatext", "true");
    SwingUtilities.invokeLater(
        () -> {
          hGui gui = new hGui();
          gui.setVisible(true);
        });
  }

  public static class ItemHistoryEntry implements java.io.Serializable {
    static final long serialVersionUID = 1L;
    long timestamp;
    String title;
    String detail;
    String owner;

    public ItemHistoryEntry(long timestamp, String title, String detail, String owner) {
      this.timestamp = timestamp;
      this.title = title;
      this.detail = detail;
      this.owner = owner;
    }
  }

  static final class OwnedSupply implements java.io.Serializable {
    static final long serialVersionUID = 1L;
    final String id, caseId;
    final boolean key;
    final double purchasePrice;
    final long createdAt;

    OwnedSupply(CaseType ct, boolean key, double price) {
      this(ct, key, price, java.util.UUID.randomUUID().toString(), System.currentTimeMillis());
    }

    OwnedSupply(CaseType ct, boolean key, double price, String identity, long created) {
      id = identity;
      caseId = ct.id;
      this.key = key;
      purchasePrice = price;
      createdAt = created;
    }
  }

  public hGui() {
    super("CSGO Case Unboxing Emulator");
    app.applicationBootstrap.initialize();
  }

  static class GameState implements java.io.Serializable {
    static final long serialVersionUID = 6L;

    InventoryToolsState inventoryTools;
    double balance;
    double inventoryValue;
    double openingProfit;
    double totalMarketProfit;
    int totalCrates;
    int totalArmouryRedeems;
    int totMil, totRes, totClass, totCov, totKnife, totGlove;
    int totIndustrial, totDistinguished, totExceptional, totSuperior, totMaster;
    double lowestFloat;
    String currentCaseType;
    ArrayList<OwnedSupply> ownedSupplies;
    int playerStars;

    Map<String, CaseTypeStats> caseStats;

    ArrayList<SerializableInventoryItem> inventory;
    ArrayList<SerializableInventoryItem> activeListingItems;
    ArrayList<Double> activeListingPrices;
    ArrayList<String> activeListingMarkets;
    ArrayList<Double> activeListingFees;
    ArrayList<String> unlockedAchievements;
    Set<String> unboxedSkins;
    Map<String, Integer> achievementProgress;
    Map<String, String> tLoadoutKeys;
    Map<String, String> ctLoadoutKeys;

    static class CaseTypeStats implements java.io.Serializable {
      static final long serialVersionUID = 1L;
      int timesOpened;
      double totalSpent;
      double totalReceived;
    }

    static class SerializableInventoryItem implements java.io.Serializable {
      static final long serialVersionUID = 1L;
      String name, condition, rarity, blueGemTier, collection;
      double price, itemFloat, basePrice;
      boolean isStattrak;
      int patternID;
      long createdAt;
      String currentOwner;
      String itemId;
      ArrayList<ItemHistoryEntry> history;
    }
  }
}
