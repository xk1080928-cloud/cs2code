package blahblah;

import blahblah.hGui.*;
import java.awt.*;
import java.awt.event.*;
import java.math.BigDecimal;
import java.math.RoundingMode;
import java.util.LinkedList;
import javax.swing.*;

/** Core Utilities: focused feature implementation. */
final class CoreUtilities {
  private final hGui app;

  CoreUtilities(hGui app) {
    this.app = app;
  }

  static int rarityRank(String rarity) {
    String clean = rarity == null ? "" : rarity.replace("StatTrak ", "");
    switch (clean) {
      case "Knife":
        return 1;
      case "Gloves":
        return 2;
      case "Covert":
      case "Master":
        return 3;
      case "Classified":
      case "Superior":
        return 4;
      case "Restricted":
      case "Exceptional":
        return 5;
      case "Milspec":
      case "Distinguished":
        return 6;
      case "Industrial":
        return 7;
      default:
        return 99;
    }
  }

  BigDecimal money(double value) {
    return BigDecimal.valueOf(Math.max(0.0, value)).setScale(2, RoundingMode.HALF_UP);
  }

  void setInventoryValueRounded(double value) {
    app.inventoryValue = app.coreUtilities.money(value).doubleValue();
    app.coreUtilities.refreshInventoryValueLabel();
  }

  void addInventoryValue(double amount) {
    app.coreUtilities.setInventoryValueRounded(app.inventoryValue + amount);
  }

  void refreshInventoryValueLabel() {
    if (app.totalInventoryValueLabel != null) {
      app.totalInventoryValueLabel.setText(
          "Inventory Value: $" + app.coreUtilities.money(app.inventoryValue));
    }
  }

  void trimSaleHistory(LinkedList<SaleRecord> history, int maxSize) {
    if (history == null || maxSize < 0) return;
    synchronized (history) {
      while (history.size() > maxSize && !history.isEmpty()) {
        history.removeFirst();
      }
    }
  }

  void addSaleHistoryRecord(LinkedList<SaleRecord> history, SaleRecord sale, int maxSize) {
    if (history == null || sale == null) return;
    synchronized (history) {
      history.addLast(sale);
      while (history.size() > maxSize && !history.isEmpty()) history.removeFirst();
    }
  }
}
