package blahblah;

import blahblah.hGui.*;
import java.awt.*;
import java.awt.event.*;
import java.math.BigDecimal;
import java.math.RoundingMode;
import javax.swing.*;

/** Opening Reward Service: focused feature implementation. */
final class OpeningRewardService {
  private final hGui app;

  OpeningRewardService(hGui app) {
    this.app = app;
  }

  void generateFinalSkinDetails(CrateRollResult rollResult) {
    String item = rollResult.rarityName;
    boolean isStatTrakRoll = rollResult.isStatTrak;
    String selectedSkinName = "";
    Image originalSkin = null;

    if (item.equals("Gloves")) {
      app.totGlove++;
      app.missionProgress.glovesUnboxed++;
    } else if (item.equals("Knife")) app.totKnife++;
    else if (item.equals("Covert")) {
      app.totCov++;
      app.missionProgress.covertsUnboxed++;
    } else if (item.equals("Classified")) {
      app.totClass++;
      app.missionProgress.classifiedsUnboxed++;
    } else if (item.equals("Restricted")) app.totRes++;
    else if (item.equals("Milspec")) app.totMil++;
    selectedSkinName = rollResult.forcedSkinName;
    if (selectedSkinName == null)
      selectedSkinName =
          "Knife".equals(item) || "Gloves".equals(item)
              ? app.collectionService.getRandomCaseGoldDrop(
                  app.currentCase, "Knife".equals(item) ? "Knives" : "Gloves")
              : app.collectionService.chooseCaseDrop(app.currentCase, item);

    double itemFloat = app.floatRules.applyFloatLimits(selectedSkinName, hGui.random.nextDouble());
    String rarityKey = item.replace("StatTrak ", "");
    double marketMulti = (app.marketPriceMultipliers.getOrDefault(rarityKey, 1.0));
    double basePrice = app.itemPriceService.getBasePrice(selectedSkinName);

    app.finalCondition = app.floatRules.getConditionForFloat(selectedSkinName, itemFloat);
    originalSkin = app.artworkService.getSkinImageFromName(selectedSkinName, app.finalCondition);
    if (originalSkin == null)
      originalSkin = app.containerBrowserScreen.createItemPlaceholderImage();

    double variance = 0.85 + (hGui.random.nextDouble() * 0.3);
    double bonusPrice = basePrice * marketMulti * variance * rollResult.priceMultiplier;

    if (item.contains("Gloves")) {
      double gloveBasePrice = app.itemPriceService.getBasePrice(selectedSkinName);
      bonusPrice =
          app.priceTables.calculateGlovePrice(selectedSkinName, app.finalCondition, gloveBasePrice);
      bonusPrice *= marketMulti * variance;
    } else {
      bonusPrice *=
          app.priceModifiers.getConditionPriceMultiplier(selectedSkinName, app.finalCondition);
    }

    if (isStatTrakRoll && !item.contains("Gloves")) {
      if (item.contains("Knife")) {
        if (selectedSkinName.contains("Crimson Web")) {
          bonusPrice *= 1.0;
        } else if (selectedSkinName.contains("Doppler")) {
          bonusPrice *= 0.80;
        } else {
          bonusPrice *= 0.95;
        }
      } else {
        double stGunMult = 1.70 + hGui.random.nextDouble() * 0.30;
        bonusPrice *= stGunMult;
      }
    }

    int patternID = hGui.random.nextInt(1000);
    String blueGemTier = app.itemPriceService.getBlueGemTier(selectedSkinName, patternID);
    if (blueGemTier != null) {
      selectedSkinName = selectedSkinName + " (" + blueGemTier + ")";
      bonusPrice =
          app.itemPriceService.applyBlueGemMultiplier(
              selectedSkinName, patternID, blueGemTier, bonusPrice);
    }

    bonusPrice =
        app.itemPriceService.capPriceToMarket(
            selectedSkinName, app.finalCondition, isStatTrakRoll, bonusPrice, blueGemTier);

    app.finalSkin = originalSkin;
    app.finalSkinName = selectedSkinName;
    app.finalPrice = bonusPrice;
    app.finalFloat = itemFloat;
    app.finalPatternID = patternID;
    app.finalBlueGemTier = blueGemTier;
  }

  void displayFinalResult(CrateRollResult rollResult, boolean updateLegacyResultView) {
    if (app.finalSkin == null)
      app.finalSkin = app.containerBrowserScreen.createItemPlaceholderImage();
    String item = rollResult.rarityName;
    boolean isStatTrakRoll = rollResult.isStatTrak;
    if (updateLegacyResultView) {
      app.crateImage = app.containerBrowserScreen.getContainerImage(app.currentCase);

      if (app.finalSkin != null) {
        int maxWidth = 280;
        int maxHeight = 200;
        int origWidth = app.finalSkin.getWidth(null);
        int origHeight = app.finalSkin.getHeight(null);
        if (origWidth > 0 && origHeight > 0) {
          double scale = Math.min((double) maxWidth / origWidth, (double) maxHeight / origHeight);
          int newWidth = (int) (origWidth * scale);
          int newHeight = (int) (origHeight * scale);
          app.skinImage = HighQualityImages.fit(app.finalSkin, newWidth, newHeight);
        }
      }
      app.containerBrowserScreen.updateCrateImageDisplay();
    }

    app.activitySimulationService.addUnboxedSkin(app.finalSkinName);

    String displayName = app.finalSkinName;
    if (isStatTrakRoll && !item.contains("Gloves")) {
      displayName = "StatTrak " + app.finalSkinName;
    }

    if (updateLegacyResultView) {
      app.rarityLabel.setForeground(rollResult.rarityColor);
      if (isStatTrakRoll && !item.contains("Gloves")) {
        app.rarityLabel.setText("StatTrak " + item);
      } else {
        app.rarityLabel.setText(item);
      }

      app.nameLabel.setMaximumSize(new Dimension(Integer.MAX_VALUE, 44));
      app.nameLabel.setPreferredSize(new Dimension(780, 44));

      if (isStatTrakRoll && !item.contains("Gloves")) {
        app.nameLabel.setForeground(new Color(255, 140, 0));
      } else {
        app.nameLabel.setForeground(new Color(230, 230, 235));
      }

      {
        int fontSize = 28;
        Font testFont = new Font("Consolas", Font.BOLD, fontSize);
        java.awt.FontMetrics fm = app.nameLabel.getFontMetrics(testFont);
        while (fontSize > 14 && fm.stringWidth(displayName) > 755) {
          fontSize -= 2;
          testFont = new Font("Consolas", Font.BOLD, fontSize);
          fm = app.nameLabel.getFontMetrics(testFont);
        }
        app.nameLabel.setFont(testFont);
      }
      app.nameLabel.setText(
          "<html><span style='white-space: nowrap;'>" + displayName + "</span></html>");

      app.missionService.updateCaseResultLabels(
          app.rarityLabel.getText(),
          app.finalSkinName,
          app.finalFloat,
          app.finalCondition,
          app.collectionService.getCollectionName(app.finalSkinName));
      app.patternId.setText("Pattern: " + app.finalPatternID);
    }

    if (!app.itemMetadataService.isAgentSkin(app.finalSkinName)
        && !app.floatRules.isVanillaKnife(app.finalSkinName)
        && app.lowestFloat > app.finalFloat) {
      app.lowestFloat = app.finalFloat;
    }

    app.coreUtilities.addInventoryValue(app.finalPrice);

    app.searchControls.updateLeaderboard();

    BigDecimal newInventoryValue = app.coreUtilities.money(app.inventoryValue);

    app.lowFloatLabel.setText(String.format("Lowest Float: %.10f", app.lowestFloat));
    app.totalInventoryValueLabel.setText("Inventory Value: $" + newInventoryValue);

    app.caseRollService.writeStats();

    String cleanItemRarity;

    if (isStatTrakRoll && !item.contains("Gloves")) {
      cleanItemRarity = "StatTrak " + item;
    } else {
      cleanItemRarity = item;
    }

    Image storeImg5 = app.finalSkin; // Retain the native PNG, not a permanent 130px thumbnail.
    InventoryItem unboxedItem =
        new InventoryItem(
            new ImageIcon(
                storeImg5 == null
                    ? app.containerBrowserScreen.createItemPlaceholderImage()
                    : storeImg5),
            app.finalSkinName,
            app.finalCondition,
            cleanItemRarity,
            BigDecimal.valueOf(app.finalPrice).setScale(2, RoundingMode.HALF_UP),
            app.finalFloat,
            (isStatTrakRoll && !item.contains("Gloves")),
            app.finalPatternID,
            app.finalBlueGemTier,
            app.finalPrice);
    unboxedItem.collection = app.collectionService.getCollectionName(app.finalSkinName);
    app.ownershipHistoryService.addItemHistory(
        unboxedItem, System.currentTimeMillis(), "Unboxed", "Unboxed by YOU", "YOU");
    app.activitySimulationService.addRecentUnboxedSkin(unboxedItem);
    app.globalSupply.created(unboxedItem);
    app.inventoryList.add(unboxedItem);
    app.missionService.checkInventoryCollectionAchievements();

    app.currentCase.totalReceived += app.finalPrice;
    app.openingProfit += (app.finalPrice - app.currentOpeningCost);

    BigDecimal roundedProfit =
        BigDecimal.valueOf(app.openingProfit).setScale(2, RoundingMode.HALF_UP);

    if (roundedProfit.signum() >= 0) {
      app.profitLabel.setForeground(Theme.PROFIT);
      app.profitLabel.setText("Opening Profit: +$" + roundedProfit);
    } else {
      app.profitLabel.setForeground(Color.RED);
      app.profitLabel.setText("Opening Profit: -$" + roundedProfit.abs());
    }

    app.itemPriceService.trackOpeningStreak();

    app.statisticsAndAchievements.checkUnboxingAchievements(
        item,
        app.finalSkinName,
        app.finalPrice,
        app.finalFloat,
        app.finalBlueGemTier,
        app.totMil,
        app.totRes,
        app.totClass,
        app.totCov,
        app.totKnife,
        rollResult.isStatTrak);

    app.openCrateButton.setVisible(!updateLegacyResultView);
    app.closeCrateButton.setVisible(updateLegacyResultView);
    app.autoOpenButton.setVisible(false);
    app.autoOpenButton.setEnabled(true);
    app.mainTabs.setEnabled(true);

    app.repaint();
  }
}
