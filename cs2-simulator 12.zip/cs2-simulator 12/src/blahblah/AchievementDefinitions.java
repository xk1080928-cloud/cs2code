package blahblah;

import blahblah.hGui.*;
import java.awt.*;
import java.awt.event.*;
import javax.swing.*;

/** Achievement Definitions: focused feature implementation. */
final class AchievementDefinitions {
  private final hGui app;

  AchievementDefinitions(hGui app) {
    this.app = app;
  }

  void initializeAchievements() {
    app.achievements.put(
        "first_blue",
        new Achievement(
            "first_blue", "First Steps", "Unbox your first Mil-Spec item", 50.0, "Unboxing", 1));
    app.achievements.put(
        "first_purple",
        new Achievement(
            "first_purple", "Moving Up", "Unbox your first Restricted item", 100.0, "Unboxing", 1));
    app.achievements.put(
        "first_pink",
        new Achievement(
            "first_pink",
            "Getting Rare",
            "Unbox your first Classified item",
            250.0,
            "Unboxing",
            1));
    app.achievements.put(
        "first_red",
        new Achievement(
            "first_red", "Jackpot!", "Unbox your first Covert item", 500.0, "Unboxing", 1));
    app.achievements.put(
        "first_knife",
        new Achievement(
            "first_knife", "The Dream", "Unbox your first Knife", 2000.0, "Unboxing", 1));
    app.achievements.put(
        "open_100",
        new Achievement("open_100", "Crate Enthusiast", "Open 100 crates", 500.0, "Unboxing", 100));
    app.achievements.put(
        "open_500",
        new Achievement("open_500", "Crate Addict", "Open 500 crates", 2500.0, "Unboxing", 500));
    app.achievements.put(
        "open_1000",
        new Achievement(
            "open_1000", "Unboxing Legend", "Open 1000 crates", 10000.0, "Unboxing", 1000));

    app.achievements.put(
        "unbox_1000",
        new Achievement("unbox_1000", "Big Win", "Unbox an item worth $1000+", 1000.0, "Value", 1));
    app.achievements.put(
        "unbox_5000",
        new Achievement(
            "unbox_5000", "Mega Win", "Unbox an item worth $5000+", 5000.0, "Value", 1));
    app.achievements.put(
        "unbox_10000",
        new Achievement(
            "unbox_10000", "Insane Luck", "Unbox an item worth $10,000+", 15000.0, "Value", 1));
    app.achievements.put(
        "inventory_50k",
        new Achievement(
            "inventory_50k", "Collector", "Reach $50,000 inventory value", 5000.0, "Value", 1));
    app.achievements.put(
        "inventory_100k",
        new Achievement(
            "inventory_100k",
            "Rich Trader",
            "Reach $100,000 inventory value",
            10000.0,
            "Value",
            1));
    app.achievements.put(
        "inventory_500k",
        new Achievement(
            "inventory_500k",
            "Wealthy Investor",
            "Reach $500,000 inventory value",
            50000.0,
            "Value",
            1));

    app.achievements.put(
        "float_0001",
        new Achievement(
            "float_0001", "Factory Fresh", "Unbox an item with float < 0.001", 500.0, "Float", 1));
    app.achievements.put(
        "float_00001",
        new Achievement(
            "float_00001", "Perfection", "Unbox an item with float < 0.0001", 2000.0, "Float", 1));
    app.achievements.put(
        "float_000001",
        new Achievement(
            "float_000001",
            "Impossible",
            "Unbox an item with float < 0.00001",
            10000.0,
            "Float",
            1));

    app.achievements.put(
        "first_sale",
        new Achievement(
            "first_sale", "First Sale", "Sell your first item on market", 100.0, "Market", 1));
    app.achievements.put(
        "market_profit_10k",
        new Achievement(
            "market_profit_10k",
            "Market Trader",
            "Make $10,000 profit from market sales",
            1000.0,
            "Market",
            1));
    app.achievements.put(
        "first_trade",
        new Achievement(
            "first_trade", "Trading Debut", "Complete your first trade", 200.0, "Trading", 1));
    app.achievements.put(
        "profitable_trade",
        new Achievement(
            "profitable_trade", "Good Deal", "Complete a profitable trade", 500.0, "Trading", 1));
    app.achievements.put(
        "trade_10",
        new Achievement("trade_10", "Active Trader", "Complete 10 trades", 1000.0, "Trading", 10));
    app.achievements.put(
        "trade_50",
        new Achievement("trade_50", "Trading Expert", "Complete 50 trades", 5000.0, "Trading", 50));

    app.achievements.put(
        "blue_gem",
        new Achievement("blue_gem", "Gem Hunter", "Unbox a Blue Gem item", 3000.0, "Special", 1));
    app.achievements.put(
        "blue_gem_t1",
        new Achievement("blue_gem_t1", "Gem Master", "Unbox a T1 Blue Gem", 15000.0, "Special", 1));
    app.achievements.put(
        "doppler",
        new Achievement("doppler", "Phase Shift", "Unbox a Doppler knife", 2000.0, "Special", 1));
    app.achievements.put(
        "sapphire",
        new Achievement(
            "sapphire", "Gem of the Sea", "Unbox a Sapphire Doppler", 20000.0, "Special", 1));
    app.achievements.put(
        "ruby",
        new Achievement("ruby", "Blood Diamond", "Unbox a Ruby Doppler", 20000.0, "Special", 1));
    app.achievements.put(
        "black_pearl",
        new Achievement(
            "black_pearl", "Dark Gem", "Unbox a Black Pearl Doppler", 25000.0, "Special", 1));
    app.achievements.put(
        "stattrak_knife",
        new Achievement(
            "stattrak_knife", "StatTrak Blade", "Unbox a StatTrak Knife", 5000.0, "Special", 1));

    app.achievements.put(
        "collect_10",
        new Achievement(
            "collect_10",
            "Starting Collection",
            "Unlock 10 unique skins",
            500.0,
            "Collection",
            10));
    app.achievements.put(
        "collect_25",
        new Achievement(
            "collect_25",
            "Growing Collection",
            "Unlock 25 unique skins",
            1500.0,
            "Collection",
            25));
    app.achievements.put(
        "collect_50",
        new Achievement(
            "collect_50", "Serious Collector", "Unlock 50 unique skins", 5000.0, "Collection", 50));
    app.achievements.put(
        "collect_all",
        new Achievement(
            "collect_all",
            "Complete Collection",
            "Unlock all skins",
            50000.0,
            "Collection",
            app.collectionScreen.getAllPossibleSkins().size()));

    app.achievements.put(
        "profit_streak",
        new Achievement(
            "profit_streak",
            "Hot Streak",
            "Make profit on 10 cases in a row",
            2000.0,
            "Streak",
            10));
    app.achievements.put(
        "loss_streak",
        new Achievement(
            "loss_streak", "Bad Luck", "Lose money on 10 cases in a row", 500.0, "Streak", 10));

    app.achievements.put(
        "first_glove",
        new Achievement(
            "first_glove", "Glove Game", "Unbox your first pair of Gloves", 2000.0, "Unboxing", 1));
    app.achievements.put(
        "glove_collector",
        new Achievement(
            "glove_collector", "Hand Fashion", "Unbox 10 pairs of Gloves", 5000.0, "Unboxing", 10));
    app.achievements.put(
        "glove_master",
        new Achievement(
            "glove_master", "Glove Master", "Unbox 25 pairs of Gloves", 15000.0, "Unboxing", 25));
    app.achievements.put(
        "rare_gloves",
        new Achievement(
            "rare_gloves", "Premium Hands", "Unbox Gloves worth $2000+", 3000.0, "Value", 1));
    app.achievements.put(
        "hedge_maze",
        new Achievement(
            "hedge_maze", "Maze Runner", "Unbox Sport Gloves | Hedge Maze", 10000.0, "Special", 1));
    app.achievements.put(
        "crimson_kimono",
        new Achievement(
            "crimson_kimono",
            "Kimono Collector",
            "Unbox Specialist Gloves | Crimson Kimono",
            10000.0,
            "Special",
            1));
    app.achievements.put(
        "pandoras_box",
        new Achievement(
            "pandoras_box",
            "Pandora's Box",
            "Unbox Sport Gloves | Pandora's Box",
            10000.0,
            "Special",
            1));

    app.achievements.put(
        "open_2500",
        new Achievement(
            "open_2500", "Crate Fanatic", "Open 2,500 cases", 10000.0, "Unboxing", 2500));
    app.achievements.put(
        "open_5000",
        new Achievement(
            "open_5000", "Case Obsessed", "Open 5,000 cases", 25000.0, "Unboxing", 5000));
    app.achievements.put(
        "open_10000",
        new Achievement(
            "open_10000", "The Grinder", "Open 10,000 cases", 75000.0, "Unboxing", 10000));

    app.achievements.put(
        "unbox_50000",
        new Achievement(
            "unbox_50000", "Jackpot King", "Unbox an item worth $50,000+", 10000.0, "Value", 1));
    app.achievements.put(
        "balance_10k",
        new Achievement(
            "balance_10k", "Comfortable", "Accumulate $10,000 balance", 500.0, "Value", 1));
    app.achievements.put(
        "inventory_1m",
        new Achievement(
            "inventory_1m",
            "Millionaire Collector",
            "Reach $1,000,000 inventory value",
            50000.0,
            "Value",
            1));
    app.achievements.put(
        "total_profit_100k",
        new Achievement(
            "total_profit_100k",
            "Profit Lord",
            "Earn $100,000 total profit from market sales",
            5000.0,
            "Market",
            1));

    app.achievements.put(
        "market_sell_100",
        new Achievement(
            "market_sell_100",
            "Market Veteran",
            "List and sell 100 items on the market",
            3000.0,
            "Market",
            100));
    app.achievements.put(
        "market_sell_500",
        new Achievement(
            "market_sell_500",
            "Market Mogul",
            "List and sell 500 items on the market",
            15000.0,
            "Market",
            500));
    app.achievements.put(
        "tradeup_10",
        new Achievement(
            "tradeup_10", "Upgrade Path", "Complete 10 trade-ups", 1000.0, "Trading", 10));
    app.achievements.put(
        "tradeup_50",
        new Achievement(
            "tradeup_50", "Contract Pro", "Complete 50 trade-ups", 5000.0, "Trading", 50));
    app.achievements.put(
        "tradeup_100",
        new Achievement(
            "tradeup_100", "Contract Legend", "Complete 100 trade-ups", 20000.0, "Trading", 100));
    app.achievements.put(
        "tradeup_knife",
        new Achievement(
            "tradeup_knife", "Blade Crafter", "Trade up into a Covert skin", 2000.0, "Trading", 1));

    app.achievements.put(
        "fn_collection",
        new Achievement(
            "fn_collection",
            "Factory Fresh Collection",
            "Own 10 Factory New items at once",
            2000.0,
            "Collection",
            10));
    app.achievements.put(
        "low_float_5",
        new Achievement(
            "low_float_5",
            "Float Fanatic",
            "Own 5 items with float below 0.005",
            3000.0,
            "Collection",
            5));

    app.achievements.put(
        "knife_5",
        new Achievement(
            "knife_5", "Knife Collection", "Unbox 5 knives total", 8000.0, "Special", 5));
    app.achievements.put(
        "knife_10",
        new Achievement("knife_10", "Arsenal", "Unbox 10 knives total", 20000.0, "Special", 10));
    app.achievements.put(
        "knife_3types",
        new Achievement(
            "knife_3types",
            "Diverse Blade",
            "Own 3 different knife types simultaneously",
            5000.0,
            "Special",
            3));

    app.achievements.put(
        "stattrak_gloves",
        new Achievement(
            "stattrak_gloves",
            "Wait, That's Illegal",
            "Own a StatTrak pair of gloves",
            5000.0,
            "Special",
            1));
    app.achievements.put(
        "all_dopplers",
        new Achievement(
            "all_dopplers", "Phase Master", "Unbox all 4 Doppler phases", 10000.0, "Special", 4));
    app.achievements.put(
        "blue_gem_knife",
        new Achievement(
            "blue_gem_knife", "Blue Steel Dreams", "Unbox a knife Blue Gem", 8000.0, "Special", 1));
    app.achievements.put(
        "fire_serpent",
        new Achievement(
            "fire_serpent",
            "Serpent\'s Bite",
            "Unbox or buy an AK-47 | Fire Serpent",
            5000.0,
            "Special",
            1));
    app.achievements.put(
        "lightning_strike",
        new Achievement(
            "lightning_strike",
            "Storm Chaser",
            "Unbox an AWP | Lightning Strike",
            3000.0,
            "Special",
            1));

    app.achievements.put(
        "armoury_25",
        new Achievement(
            "armoury_25",
            "Star Hoarder",
            "Redeem 25 items from the Armoury",
            2000.0,
            "Armoury",
            25));
    app.achievements.put(
        "armoury_50",
        new Achievement(
            "armoury_50",
            "Armoury Elite",
            "Redeem 50 items from the Armoury",
            5000.0,
            "Armoury",
            50));
    app.achievements.put(
        "stars_100",
        new Achievement(
            "stars_100", "Star Collector", "Earn 100 Stars total", 1000.0, "Armoury", 100));
    app.achievements.put(
        "stars_500",
        new Achievement(
            "stars_500", "Star Millionaire", "Earn 500 Stars total", 5000.0, "Armoury", 500));

    app.achievements.put(
        "loadout_full_t",
        new Achievement(
            "loadout_full_t",
            "T-Side Drip",
            "Equip a skin in every T-Side loadout slot",
            2000.0,
            "Loadout",
            1));
    app.achievements.put(
        "loadout_full_ct",
        new Achievement(
            "loadout_full_ct",
            "CT-Side Drip",
            "Equip a skin in every CT-Side loadout slot",
            2000.0,
            "Loadout",
            1));

    app.achievements.put(
        "loss_streak_25",
        new Achievement(
            "loss_streak_25",
            "Rock Bottom",
            "Open 25 cases without a Covert or better",
            1000.0,
            "Streak",
            25));
    app.achievements.put(
        "profit_streak_20",
        new Achievement(
            "profit_streak_20", "Lucky Run", "Profit on 20 cases in a row", 5000.0, "Streak", 20));
    app.achievements.put(
        "open_25000",
        new Achievement(
            "open_25000", "Industrial Scale", "Open 25,000 cases", 250000.0, "Unboxing", 25000));
    app.achievements.put(
        "unbox_250000",
        new Achievement(
            "unbox_250000",
            "Life Changing Pull",
            "Unbox an item worth $250,000+",
            75000.0,
            "Value",
            1));
    app.achievements.put(
        "inventory_5m",
        new Achievement(
            "inventory_5m",
            "Private Museum",
            "Reach $5,000,000 inventory value",
            250000.0,
            "Value",
            1));
    app.achievements.put(
        "tradeup_250",
        new Achievement(
            "tradeup_250", "Contract Immortal", "Complete 250 trade-ups", 50000.0, "Trading", 250));
    app.achievements.put(
        "market_sell_1000",
        new Achievement(
            "market_sell_1000",
            "Exchange Tycoon",
            "List and sell 1,000 items on the market",
            40000.0,
            "Market",
            1000));
  }
}
