package blahblah;

import blahblah.hGui.*;
import java.awt.*;
import java.awt.event.*;
import java.util.ArrayList;
import javax.swing.*;

/** Trade Up Cards: focused feature implementation. */
final class TradeUpCards {
  private final hGui app;

  TradeUpCards(hGui app) {
    this.app = app;
  }

  public void tradeUp() {
    if (app.mainTabs != null) app.cs2Screens.navigateInventoryTradeUp();
    if (app.tradeUpTabPanel != null) {
      app.tradeUpTabPanel.putClientProperty("inventorySnapshot", null);
      app.tradeUpScreen.refreshTradeUpTab();
    }
  }

  JPanel createTradeUpCardFast(
      InventoryItem item,
      ImageIcon cachedImage,
      ArrayList<InventoryItem> selectedItems,
      JPanel grid) {
    ImageIcon oldImage = item.image;
    app.artworkService.refreshInventoryItemArtwork(item);
    if (oldImage != item.image) cachedImage = item.getThumb110();
    JPanel card = new JPanel(new BorderLayout());
    card.setBackground(new Color(30, 30, 40));
    card.setPreferredSize(new Dimension(220, 185));
    card.setMaximumSize(new Dimension(220, 185));
    card.setBorder(
        BorderFactory.createLineBorder(app.itemInspectionScreen.getRarityColor(item.rarity), 2));

    JLabel imgLabel;
    if (cachedImage != null) {
      imgLabel = new JLabel(cachedImage);
    } else if (item.image != null) {
      Image scaled = item.getThumb110().getImage();
      imgLabel = new JLabel(new ImageIcon(scaled));
    } else {
      String cleanName = item.name.replace("StatTrak ", "").replace("* ", "").trim();
      if (item.blueGemTier != null && cleanName.contains("(Blue Gem"))
        cleanName = cleanName.substring(0, cleanName.indexOf("(Blue Gem")).trim();
      Image img = app.artworkService.getSkinImageFromName(cleanName, item.condition);
      if (img != null) {
        Image scaled = HighQualityImages.fit(img, 110, 75);
        imgLabel = new JLabel(new ImageIcon(scaled));
        item.image = new ImageIcon(img);
      } else {
        imgLabel = new JLabel("?", SwingConstants.CENTER);
        imgLabel.setForeground(Color.WHITE);
      }
    }
    imgLabel.setHorizontalAlignment(SwingConstants.CENTER);
    imgLabel.setPreferredSize(new Dimension(110, 75));
    String remoteName = app.artworkService.getSkinArtworkKey(item.name, item.condition);
    if (app.imageRepository.get(remoteName) == null)
      app.artworkService.registerPendingRemoteImageLabel(remoteName, imgLabel, 110, 75);
    card.putClientProperty("inventoryArtwork", imgLabel);
    card.putClientProperty("inventoryImageSource", item.image);
    card.putClientProperty("inventoryItem", item);
    card.putClientProperty("inventoryRemoteName", remoteName);

    String displayName = item.isStattrak ? "ST " + item.name : item.name;
    JLabel n = new JLabel(displayName, SwingConstants.CENTER);
    n.setForeground(item.isStattrak ? new Color(255, 153, 51) : Color.WHITE);
    n.setFont(new Font("Consolas", Font.BOLD, 10));

    JLabel c = new JLabel(item.condition, SwingConstants.CENTER);
    c.setForeground(Color.LIGHT_GRAY);
    c.setFont(new Font("Consolas", Font.PLAIN, 9));

    JLabel f = new JLabel(String.format("Float: %.6f", item.itemFloat), SwingConstants.CENTER);
    f.setForeground(Theme.ACCENT_CT);
    f.setFont(new Font("Consolas", Font.PLAIN, 9));

    JLabel r = new JLabel(item.rarity, SwingConstants.CENTER);
    r.setForeground(app.itemInspectionScreen.getRarityColor(item.rarity));
    r.setFont(new Font("Consolas", Font.PLAIN, 9));

    app.inventoryScreen.resolveInventoryItemCollection(item);
    JLabel col = new JLabel(item.collection != null ? item.collection : "", SwingConstants.CENTER);
    col.setForeground(new Color(170, 130, 255));
    col.setFont(new Font("Consolas", Font.ITALIC, 8));

    JPanel text = new JPanel(new GridLayout(5, 1, 0, 0));
    text.setBackground(new Color(22, 22, 30));
    text.setBorder(BorderFactory.createEmptyBorder(2, 2, 2, 2));
    text.add(n);
    text.add(c);
    text.add(r);
    text.add(f);
    text.add(col);

    card.add(imgLabel, BorderLayout.CENTER);
    card.add(text, BorderLayout.SOUTH);
    card.putClientProperty("tradeUpText", text);

    if (selectedItems.contains(item)) {
      card.setBackground(new Color(20, 60, 20));
      text.setBackground(new Color(15, 45, 15));
      card.setBorder(BorderFactory.createLineBorder(new Color(80, 220, 80), 3));
    }

    card.addMouseListener(
        new MouseAdapter() {
          @Override
          public void mouseClicked(MouseEvent e) {
            if (selectedItems.contains(item)) {
              selectedItems.remove(item);
              card.setBackground(new Color(30, 30, 40));
              text.setBackground(new Color(22, 22, 30));
              card.setBorder(
                  BorderFactory.createLineBorder(
                      app.itemInspectionScreen.getRarityColor(item.rarity), 2));
              card.setEnabled(true);
              Object rb = grid.getClientProperty("selectionChanged");
              if (rb instanceof Runnable) ((Runnable) rb).run();
            } else {
              if (!selectedItems.isEmpty()) {
                String lockedRarity = selectedItems.get(0).rarity;
                if (!item.rarity.equals(lockedRarity)
                    || item.isStattrak != selectedItems.get(0).isStattrak) {
                  JOptionPane.showMessageDialog(
                      grid.getTopLevelAncestor(),
                      "All skins must match: "
                          + lockedRarity
                          + "\n(StatTrak and non-StatTrak cannot be mixed)");
                  return;
                }
              }
              if (selectedItems.size() < (item.rarity.contains("Covert") ? 5 : 10)) {
                selectedItems.add(item);
                card.setBackground(new Color(20, 60, 20));
                text.setBackground(new Color(15, 45, 15));
                card.setBorder(BorderFactory.createLineBorder(new Color(80, 220, 80), 3));
                Object rb = grid.getClientProperty("selectionChanged");
                if (rb instanceof Runnable) ((Runnable) rb).run();
              } else {
                JOptionPane.showMessageDialog(
                    grid.getTopLevelAncestor(),
                    "You can only select " + (item.rarity.contains("Covert") ? 5 : 10) + " skins!");
              }
            }
          }

          @Override
          public void mouseEntered(MouseEvent e) {
            if (!selectedItems.contains(item)) card.setBackground(new Color(40, 40, 55));
          }

          @Override
          public void mouseExited(MouseEvent e) {
            if (!selectedItems.contains(item)) card.setBackground(new Color(30, 30, 40));
          }
        });
    return card;
  }
}
