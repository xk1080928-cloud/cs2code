package blahblah;

import blahblah.hGui.*;
import java.awt.*;
import java.awt.event.*;
import java.math.BigDecimal;
import java.math.RoundingMode;
import javax.swing.*;

/** Trade Transaction Service: focused feature implementation. */
final class TradeTransactionService {
  private final hGui app;

  TradeTransactionService(hGui app) {
    this.app = app;
  }

  void handleTradeAccept(TradeOffer trade, JFrame parent) {
    for (InventoryItem requestedItem : trade.npcRequestedItems) {
      if (!app.inventoryList.contains(requestedItem)) {
        JOptionPane.showMessageDialog(
            parent,
            "You no longer have " + requestedItem.name + "!",
            "Trade Failed",
            JOptionPane.ERROR_MESSAGE);
        return;
      }
    }

    if (trade.npcRequestedMoney > app.balance) {
      JOptionPane.showMessageDialog(
          parent,
          "Insufficient funds! Need $" + String.format("%.2f", trade.npcRequestedMoney),
          "Trade Failed",
          JOptionPane.ERROR_MESSAGE);
      return;
    }

    double offeredValue =
        trade.npcOfferedMoney
            + trade.npcOfferedItems.stream().mapToDouble(i -> i.price.doubleValue()).sum();
    double requestedValue =
        trade.npcRequestedMoney
            + trade.npcRequestedItems.stream().mapToDouble(i -> i.price.doubleValue()).sum();

    boolean isProfitable = offeredValue > requestedValue;

    for (InventoryItem item : trade.npcRequestedItems) {
      app.inventoryList.remove(item);
      app.inventoryValue = Math.max(0.0, app.inventoryValue - item.price.doubleValue());
    }

    app.balance -= trade.npcRequestedMoney;
    app.balance += trade.npcOfferedMoney;

    for (InventoryItem item : trade.npcOfferedItems) {
      app.inventoryList.add(item);
      app.inventoryValue += item.price.doubleValue();
    }
    app.missionService.checkInventoryCollectionAchievements();

    trade.isAccepted = true;
    synchronized (app.pendingTrades) {
      app.pendingTrades.remove(trade);
    }
    app.completedTrades.add(trade);

    app.uiWidgets.updateBalanceLabel();
    app.caseRollService.writeStats();
    BigDecimal newInventoryValue =
        BigDecimal.valueOf(app.inventoryValue).setScale(2, RoundingMode.HALF_UP);
    app.totalInventoryValueLabel.setText("Inventory Value: $" + newInventoryValue);

    app.crateImage = app.containerBrowserScreen.getContainerImage(app.currentCase);
    app.skinImage = null;

    app.searchControls.updateLeaderboard();
    app.bundledArtwork.refreshMainUI();

    JOptionPane.showMessageDialog(
        parent, "Trade completed successfully!", "Success", JOptionPane.INFORMATION_MESSAGE);

    parent.dispose();

    if (!app.achievements.get("first_trade").isUnlocked) {
      app.achievementScreen.unlockAchievement("first_trade");
    }

    if (isProfitable && !app.achievements.get("profitable_trade").isUnlocked) {
      app.achievementScreen.unlockAchievement("profitable_trade");
    }

    long acceptedTrades = app.completedTrades.stream().filter(t -> t.isAccepted).count();
    app.achievements.get("trade_10").progress = (int) acceptedTrades;
    app.achievements.get("trade_50").progress = (int) acceptedTrades;
    if (acceptedTrades == 10 && !app.achievements.get("trade_10").isUnlocked) {
      app.achievementScreen.unlockAchievement("trade_10");
    }
    if (acceptedTrades == 50 && !app.achievements.get("trade_50").isUnlocked) {
      app.achievementScreen.unlockAchievement("trade_50");
    }
  }

  void handlePurchaseTradeAccept(TradeOffer trade, JFrame parent) {
    if (trade.npcOfferedItems.isEmpty()) return;
    InventoryItem item = trade.npcOfferedItems.get(0);
    if (item.image == null) {
      Image img = app.artworkService.getSkinImageFromName(item.name, item.condition);
      if (img != null) item.image = new ImageIcon(img);
    }
    String sellerName =
        trade.npcName != null && !trade.npcName.trim().isEmpty()
            ? trade.npcName
            : (trade.marketplaceName != null
                ? trade.marketplaceName + " Seller"
                : "Marketplace Seller");
    String purchaseMarket =
        trade.marketplaceName != null && !trade.marketplaceName.trim().isEmpty()
            ? trade.marketplaceName
            : "Marketplace";
    app.ownershipHistoryService.ensureTrackedHistoryForDisplay(item, sellerName);
    app.ownershipHistoryService.addItemHistory(
        item,
        System.currentTimeMillis() - 1000L,
        "Listed On Market",
        String.format(
            "Listed on market for $%.2f by %s",
            trade.settledPrice > 0 ? trade.settledPrice : item.price.doubleValue(), sellerName),
        sellerName);
    app.ownershipHistoryService.addItemHistory(
        item,
        System.currentTimeMillis(),
        "Bought From " + purchaseMarket,
        String.format(
            "Bought from %s by YOU for $%.2f",
            purchaseMarket, trade.settledPrice > 0 ? trade.settledPrice : item.price.doubleValue()),
        "YOU");
    app.inventoryList.add(item);
    app.itemRevealService.received(item);
    app.inventoryValue += trade.settledPrice > 0 ? trade.settledPrice : item.price.doubleValue();
    app.pendingPurchaseTrades.remove(trade);
    trade.isAccepted = true;
    app.completedTrades.add(trade);
    MarketListing purchaseListing =
        new MarketListing(
            item, trade.settledPrice > 0 ? trade.settledPrice : item.price.doubleValue(), 0, true);
    purchaseListing.marketplaceName = purchaseMarket;
    app.playerPurchases.add(
        app.salesSimulationService.createSaleRecordFromListing(
            purchaseListing, "YOU", app.playerAvatar));
    if (app.playerPurchases.size() > hGui.MAX_SALES_HISTORY) {
      app.playerPurchases.removeFirst();
    }
    app.uiWidgets.updateBalanceLabel();
    app.caseRollService.writeStats();
    app.searchControls.updateLeaderboard();
    app.bundledArtwork.refreshMainUI();
    JOptionPane.showMessageDialog(parent, "Purchase delivered.");
    parent.dispose();
  }

  void handlePurchaseTradeDecline(TradeOffer trade, JFrame parent) {
    app.pendingPurchaseTrades.remove(trade);
    trade.isDeclined = true;
    app.completedTrades.add(trade);
    app.balance += trade.settledPrice;
    app.uiWidgets.updateBalanceLabel();
    app.caseRollService.writeStats();
    app.bundledArtwork.refreshMainUI();
    JOptionPane.showMessageDialog(parent, "Purchase cancelled and refunded.");
    parent.dispose();
  }

  void handleTradeDecline(TradeOffer trade, JFrame parent) {
    trade.isDeclined = true;
    synchronized (app.pendingTrades) {
      app.pendingTrades.remove(trade);
    }
    app.completedTrades.add(trade);

    JOptionPane.showMessageDialog(
        parent, "Trade declined.", "Declined", JOptionPane.INFORMATION_MESSAGE);

    parent.dispose();
  }

  JPanel createTradeHistoryPanel() {
    JPanel panel = new JPanel(new BorderLayout());

    if (app.completedTrades.isEmpty()) {
      JLabel emptyLabel = new JLabel("No trade history", SwingConstants.CENTER);
      emptyLabel.setFont(new Font("Arial", Font.BOLD, 24));
      panel.add(emptyLabel, BorderLayout.CENTER);
      return panel;
    }

    JPanel container = new JPanel();
    container.setLayout(new BoxLayout(container, BoxLayout.Y_AXIS));
    container.setBackground(Color.DARK_GRAY);
    container.setBorder(BorderFactory.createEmptyBorder(10, 10, 10, 10));

    for (int i = app.completedTrades.size() - 1; i >= 0; i--) {
      TradeOffer trade = app.completedTrades.get(i);
      JPanel tradeCard = app.tradeHubScreen.createTradeCard(trade, null, false);
      tradeCard.setMaximumSize(new Dimension(Integer.MAX_VALUE, 350));
      container.add(tradeCard);
      container.add(Box.createRigidArea(new Dimension(0, 10)));
    }

    JScrollPane scroll = new JScrollPane(container);
    scroll.getVerticalScrollBar().setUnitIncrement(16);
    panel.add(scroll, BorderLayout.CENTER);

    return panel;
  }
}
