package blahblah;

import blahblah.hGui.*;
import java.awt.*;
import java.awt.event.*;
import javax.swing.*;

/** Extracted reusable model or widget; behavior retained from the original source. */
final class StartupArtworkResult {
  final boolean loaded, fallback;

  StartupArtworkResult(boolean loaded, boolean fallback) {
    this.loaded = loaded;
    this.fallback = fallback;
  }
}
