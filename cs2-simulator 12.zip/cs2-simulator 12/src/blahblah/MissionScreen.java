package blahblah;

import blahblah.hGui.*;
import java.awt.*;
import java.awt.event.*;
import javax.swing.*;

/** Mission Screen: focused feature implementation. */
final class MissionScreen {
  private final hGui app;

  MissionScreen(hGui app) {
    this.app = app;
  }

  void showMissionsWindow() {
    if (app.activeMissions.isEmpty()) app.missionService.generateNewMissions();

    JFrame frame = new JFrame("Missions");
    Rectangle usable = GraphicsEnvironment.getLocalGraphicsEnvironment().getMaximumWindowBounds();
    frame.setSize(Math.min(1000, usable.width - 48), Math.min(800, usable.height - 48));
    frame.setMinimumSize(
        new Dimension(Math.min(880, usable.width - 48), Math.min(620, usable.height - 48)));
    frame.setName("missionsWindow");
    frame.setLocationRelativeTo(app);
    frame.setLayout(new BorderLayout());
    frame.getContentPane().setBackground(new Color(10, 10, 18));

    JPanel header = new JPanel(new BorderLayout());
    header.setBackground(new Color(18, 18, 30));
    header.setBorder(
        BorderFactory.createCompoundBorder(
            BorderFactory.createMatteBorder(0, 0, 2, 0, new Color(100, 180, 255)),
            BorderFactory.createEmptyBorder(14, 20, 14, 20)));
    JLabel titleLbl = new JLabel("*  MISSIONS  *", SwingConstants.CENTER);
    titleLbl.setFont(new Font("Consolas", Font.BOLD, 22));
    titleLbl.setForeground(Theme.GOLD);
    JLabel subLbl =
        new JLabel(
            "Complete missions for Stars + XP. Every 100 XP earns a Care Package.",
            SwingConstants.CENTER);
    subLbl.setFont(new Font("Consolas", Font.PLAIN, 11));
    subLbl.setForeground(new Color(140, 160, 200));
    JLabel starsLbl = new JLabel("Your Stars: " + app.playerStars + " *", SwingConstants.CENTER);
    starsLbl.setFont(new Font("Consolas", Font.BOLD, 14));
    starsLbl.setForeground(Theme.GOLD);
    JPanel headerSub = new JPanel(new GridLayout(2, 1, 0, 4));
    headerSub.setBackground(new Color(18, 18, 30));
    headerSub.add(subLbl);
    headerSub.add(starsLbl);
    header.add(titleLbl, BorderLayout.NORTH);
    header.add(headerSub, BorderLayout.CENTER);
    frame.add(header, BorderLayout.NORTH);

    JPanel missionPanel = new JPanel();
    missionPanel.setLayout(new BoxLayout(missionPanel, BoxLayout.Y_AXIS));
    missionPanel.setBackground(Theme.BG_DARK);
    missionPanel.setBorder(BorderFactory.createEmptyBorder(16, 20, 16, 20));

    app.missionService.checkMissionProgress();

    for (Mission m : app.activeMissions) {
      JPanel card = new JPanel(new BorderLayout(12, 6));
      card.setBackground(m.completed ? new Color(20, 50, 20) : new Color(22, 22, 36));
      card.setBorder(
          BorderFactory.createCompoundBorder(
              BorderFactory.createLineBorder(
                  m.completed ? new Color(80, 200, 80) : new Color(50, 55, 80), 2),
              BorderFactory.createEmptyBorder(14, 16, 14, 16)));
      card.setName("missionCard-" + m.id);
      card.setPreferredSize(new Dimension(880, 140));
      card.setMinimumSize(new Dimension(0, 140));
      card.setMaximumSize(new Dimension(Integer.MAX_VALUE, 170));

      JPanel badge = new JPanel(new BorderLayout());
      badge.setBackground(card.getBackground());
      badge.setPreferredSize(new Dimension(145, 90));
      JLabel badgeNumLbl = new JLabel("+" + m.starReward + " Stars", SwingConstants.CENTER);
      badgeNumLbl.setFont(new Font("SansSerif", Font.BOLD, 21));
      badgeNumLbl.setForeground(Theme.GOLD);
      JLabel badgeStarLbl =
          new JLabel("+" + app.carePackages.xpReward(m) + " XP", SwingConstants.CENTER);
      badgeStarLbl.setFont(new Font("SansSerif", Font.BOLD, 17));
      badgeStarLbl.setName("missionXp-" + m.id);
      badgeNumLbl.setName("missionStars-" + m.id);
      badgeStarLbl.setForeground(Theme.GOLD);
      badge.setLayout(new java.awt.GridLayout(2, 1, 0, 0));
      badge.add(badgeNumLbl);
      badge.add(badgeStarLbl);

      JPanel info = new JPanel(new BorderLayout(0, 8));
      info.setOpaque(false);
      JTextArea nameLbl =
          wrapped(
              m.completed ? "✓ " + m.name + " (COMPLETED)" : m.name,
              Font.BOLD,
              16,
              m.completed ? new Color(80, 220, 80) : new Color(220, 220, 240));
      nameLbl.setName("missionName-" + m.id);
      JTextArea descLbl = wrapped(m.description, Font.PLAIN, 14, new Color(168, 179, 201));
      descLbl.setName("missionDescription-" + m.id);
      nameLbl.setRows(2);
      descLbl.setRows(2);
      info.add(nameLbl, BorderLayout.NORTH);
      info.add(descLbl, BorderLayout.CENTER);

      JPanel progressPanel = new JPanel(new BorderLayout(4, 4));
      progressPanel.setBackground(card.getBackground());
      progressPanel.setPreferredSize(new Dimension(155, 85));
      JProgressBar bar = new JProgressBar(0, m.goal);
      bar.setValue(Math.min(m.current, m.goal));
      bar.setUI(
          new javax.swing.plaf.basic.BasicProgressBarUI() {
            protected Color getSelectionBackground() {
              return Color.WHITE;
            }

            protected Color getSelectionForeground() {
              return Color.WHITE;
            }
          });
      bar.setStringPainted(true);
      bar.setString(m.completed ? "DONE!" : m.current + " / " + m.goal);
      bar.setForeground(m.completed ? new Color(80, 200, 80) : new Color(100, 160, 255));
      bar.setBackground(new Color(30, 30, 45));
      bar.setBorderPainted(false);
      JLabel progLbl =
          new JLabel(String.format("%.0f%%", m.progressPct() * 100), SwingConstants.CENTER);
      progLbl.setFont(new Font("Consolas", Font.BOLD, 11));
      progLbl.setForeground(new Color(160, 160, 190));
      progressPanel.add(bar, BorderLayout.CENTER);
      progressPanel.add(progLbl, BorderLayout.SOUTH);

      card.add(badge, BorderLayout.WEST);
      card.add(info, BorderLayout.CENTER);
      card.add(progressPanel, BorderLayout.EAST);
      missionPanel.add(card);
      missionPanel.add(Box.createRigidArea(new Dimension(0, 10)));
    }

    JScrollPane scroll = new JScrollPane(missionPanel);
    scroll.setBorder(null);
    scroll.setHorizontalScrollBarPolicy(ScrollPaneConstants.HORIZONTAL_SCROLLBAR_NEVER);
    scroll.getVerticalScrollBar().setUnitIncrement(16);
    frame.add(scroll, BorderLayout.CENTER);

    JPanel footer = new JPanel(new FlowLayout(FlowLayout.CENTER, 12, 10));
    footer.setBackground(new Color(18, 18, 30));
    footer.setBorder(BorderFactory.createMatteBorder(2, 0, 0, 0, new Color(40, 45, 70)));

    boolean allDone = app.activeMissions.stream().allMatch(m2 -> m2.completed);
    JButton refreshBtn = new JButton(allDone ? "GET NEW MISSIONS" : "REFRESH MISSIONS");
    app.uiWidgets.styleButton(
        refreshBtn,
        allDone ? new Color(30, 80, 30) : new Color(30, 30, 50),
        allDone ? new Color(80, 220, 80) : new Color(130, 140, 170),
        allDone ? new Color(80, 200, 80) : new Color(50, 55, 80));
    refreshBtn.setFont(new Font("Consolas", Font.BOLD, 13));
    refreshBtn.addActionListener(
        ev -> {
          app.missionService.generateNewMissions();
          frame.dispose();
          app.missionScreen.showMissionsWindow();
        });
    JLabel footerNote = new JLabel("New missions reset your progress counters.");
    footerNote.setFont(new Font("SansSerif", Font.PLAIN, 12));
    footerNote.setForeground(new Color(100, 100, 130));
    footer.add(refreshBtn);
    footer.add(footerNote);
    frame.add(footer, BorderLayout.SOUTH);

    frame.setVisible(true);
  }

  private JTextArea wrapped(String text, int style, int size, Color color) {
    JTextArea area = new JTextArea(text);
    area.setLineWrap(true);
    area.setWrapStyleWord(true);
    area.setEditable(false);
    area.setFocusable(false);
    area.setOpaque(false);
    area.setFont(new Font("SansSerif", style, size));
    area.setForeground(color);
    area.setBorder(null);
    return area;
  }
}
