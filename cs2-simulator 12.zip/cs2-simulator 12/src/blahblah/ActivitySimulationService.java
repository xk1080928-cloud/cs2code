package blahblah;

import blahblah.hGui.*;
import java.awt.*;
import java.awt.event.*;
import java.math.BigDecimal;
import java.math.RoundingMode;
import java.util.ArrayList;
import javax.swing.*;

/** Activity Simulation Service: focused feature implementation. */
final class ActivitySimulationService {
  private final hGui app;

  ActivitySimulationService(hGui app) {
    this.app = app;
  }

  void simulateMarketActivity() {
    if (app.marketProcessQueue.isEmpty()) {
      app.avatarService.initializeMarketQueue();
      return;
    }

    int processed = 0;
    int maxPerCycle = 10;

    while (processed < maxPerCycle && !app.marketProcessQueue.isEmpty()) {
      String skinName = app.marketProcessQueue.poll();
      ArrayList<MarketListing> listings = app.globalMarketListings.get(skinName);

      if (listings == null || listings.isEmpty()) {
        processed++;
        continue;
      }

      ArrayList<MarketListing> toRemove = new ArrayList<>();
      synchronized (listings) {
        double cheapestNpcPrice = Double.MAX_VALUE;
        for (MarketListing candidate : listings) {
          if (candidate != null && !candidate.isPlayerListing && candidate.quantity>0 && Double.isFinite(candidate.getPrice()) && candidate.getPrice() > 0) {
            cheapestNpcPrice = Math.min(cheapestNpcPrice, candidate.getPrice());
          }
        }
        int checkLimit = Math.min(3, listings.size());
        for (int i = 0; i < checkLimit; i++) {
          MarketListing listing = listings.get(i);
          if (listing.isPlayerListing || listing.quantity<=0 || !Double.isFinite(listing.getPrice()) || listing.getPrice()<=0) continue;

          String cleanName = listing.item.name.replace("StatTrak ", "");
          String rarity = app.itemMetadataService.getSkinRarity(cleanName);
          double marketMulti =
              app.marketInitialization.getMarketMultiplier(
                  rarity, app.collectionService.getCollectionName(cleanName));
          double basePrice = app.itemPriceService.getBasePrice(cleanName);
          double expectedPrice = basePrice * marketMulti;
          expectedPrice *=
              app.priceModifiers.getMarketConditionMultiplier(cleanName, listing.item.condition);

          if (listing.item.isStattrak) {
            boolean isCW10 = listing.item.name.contains("Crimson Web");
            boolean isD10 = listing.item.name.contains("Doppler");
            if (isCW10) expectedPrice *= 2.0;
            else if (isD10) expectedPrice *= 0.80;
            else if (rarity.equals("Knife")) expectedPrice *= 0.90;
            else expectedPrice *= 1.85;
          }

          double priceRatio = listing.getPrice() / expectedPrice;
          double sellChance =
              priceRatio < 0.85 ? 0.05 : priceRatio < 0.95 ? 0.03 : priceRatio < 1.05 ? 0.02 : 0.01;
          if (cheapestNpcPrice != Double.MAX_VALUE) {
            sellChance *=
                app.salesSimulationService.getRaritySaleVelocity(rarity)
                    * app.salesSimulationService.getPriceSaleWeight(
                        cheapestNpcPrice, listing.getPrice());
            if (listing.item.isStattrak)
              sellChance *= app.salesSimulationService.getStatTrakSaleVelocityMultiplier(rarity);
            sellChance = Math.min(0.18, sellChance);
          }

          if (hGui.random.nextDouble() < sellChance) {
            toRemove.add(listing);
            app.salesSimulationService.recordMarketListingSale(listing, null, null);
          }
        }
        for (MarketListing sold : toRemove) {
          if (sold.quantity > 1) app.exchangeTransactionService.consumeExchangeLot(sold);
          else listings.remove(sold);
        }
      }
      processed++;
    }
  }

  String cleanStatTrakEncoding(String text) {
    if (text == null) return text;

    boolean hasStatTrak = text.toLowerCase().contains("stattrak");

    text = text.replaceAll("(?i)stattrak\\s*", "").trim();

    if (hasStatTrak) {
      return "StatTrak " + text;
    }

    return text;
  }

  double getRecentSaleFeedChance(String rarity) {
    switch (rarity) {
      case "Industrial":
        return 1.00;
      case "Milspec":
        return 0.95;
      case "Distinguished":
        return 0.85;
      case "Restricted":
        return 0.72;
      case "Exceptional":
        return 0.60;
      case "Classified":
        return 0.42;
      case "Superior":
        return 0.32;
      case "Covert":
        return 0.22;
      case "Master":
        return 0.15;
      case "Knife":
        return 0.10;
      case "Gloves":
        return 0.08;
      default:
        return 0.55;
    }
  }

  void addSaleRecord(SaleRecord sale, boolean forceRecent) {
    if (sale == null || sale.skinName == null) return;
    boolean isSpecial =
        sale.specialVariant != null
            || sale.skinName.toLowerCase().contains("knife")
            || sale.skinName.toLowerCase().contains("doppler");

    if (isSpecial) {
      app.coreUtilities.addSaleHistoryRecord(app.rareSales, sale, hGui.MAX_RARE_SALES);
    }

    String rarity =
        app.itemMetadataService.getSkinRarity(
            app.salesHistoryScreen
                .getSaleHistoryKey(sale.skinName)
                .replace("StatTrak ", "")
                .trim());
    if (forceRecent
        || hGui.random.nextDouble()
            < app.activitySimulationService.getRecentSaleFeedChance(rarity)) {
      app.coreUtilities.addSaleHistoryRecord(app.recentSales, sale, hGui.MAX_SALES_HISTORY);
    }
  }

  void addRecentUnboxedSkin(InventoryItem item) {
    app.activitySimulationService.addRecentUnboxedSkin(item, "YOU", app.playerAvatar);
  }

  void addRecentUnboxedSkin(InventoryItem item, String openerName, Image openerAvatar) {
    app.activitySimulationService.addRecentUnboxedSkin(
        item, openerName, openerAvatar, "Case Unbox");
  }

  void addRecentUnboxedSkin(
      InventoryItem item, String openerName, Image openerAvatar, String source) {
    if (item == null || item.name == null) return;
    String displayName =
        (item.isStattrak && !item.name.startsWith("StatTrak "))
            ? "StatTrak " + item.name
            : item.name;
    double marketPrice = app.listingSalesService.getCurrentMarketPrice(item);
    if (!Double.isFinite(marketPrice) || marketPrice <= 0.0) marketPrice = item.price.doubleValue();
    SaleRecord unbox =
        new SaleRecord(displayName, marketPrice, item.condition, item.itemFloat, item.blueGemTier);
    unbox.timestamp = item.createdAt > 0 ? item.createdAt : System.currentTimeMillis();
    unbox.buyerName = openerName != null && !openerName.trim().isEmpty() ? openerName : "Unknown";
    unbox.buyerAvatar = openerAvatar;
    unbox.marketplaceName = source != null && !source.trim().isEmpty() ? source : "Case Unbox";
    app.coreUtilities.addSaleHistoryRecord(app.recentUnboxedSkins, unbox, hGui.MAX_SALES_HISTORY);
  }

  String rollSimulatedCaseRarity() {
    double roll = hGui.random.nextDouble();
    if (roll < 0.0026) return hGui.random.nextBoolean() ? "Knife" : "Gloves";
    if (roll < 0.0090) return "Covert";
    if (roll < 0.0410) return "Classified";
    if (roll < 0.2008) return "Restricted";
    return hGui.random.nextDouble() < 0.85 ? "Milspec" : "Industrial";
  }

  String chooseSimulatedUnboxSkin(String rarity) {
    ArrayList<String> candidates = new ArrayList<>();
    for (String skin : app.collectionScreen.getSkinsByRarity(rarity)) {
      if (skin == null || skin.trim().isEmpty()) continue;
      if (app.itemMetadataService.isAgentSkin(skin)) continue;
      candidates.add(skin);
    }
    if (candidates.isEmpty() && "Industrial".equals(rarity)) {
      for (String skin : app.collectionScreen.getSkinsByRarity("Milspec")) {
        if (!app.itemMetadataService.isAgentSkin(skin)) candidates.add(skin);
      }
    }
    if (candidates.isEmpty()) candidates.addAll(app.collectionScreen.getSkinsByRarity(rarity));
    if (candidates.isEmpty()) return "MP7 | Skulls";
    return candidates.get(hGui.random.nextInt(candidates.size()));
  }

  String applySimulatedDopplerVariant(String skinName) {
    if (skinName == null || !skinName.contains("Doppler") || skinName.contains("("))
      return skinName;
    return app.goldTradeUpService.sampleTradeUpOdds(
        app.goldTradeUpService.getUnboxingDopplerVariantOdds(skinName));
  }

  InventoryItem createSimulatedUnboxItem(String rarity) {
    String skinName =
        app.activitySimulationService.applySimulatedDopplerVariant(
            app.activitySimulationService.chooseSimulatedUnboxSkin(rarity));
    String actualRarity = app.itemMetadataService.getSkinRarity(skinName);
    if ("Unknown".equals(actualRarity) || actualRarity == null) actualRarity = rarity;

    String[] availableConditions = app.floatRules.getAvailableConditions(skinName);
    String condition = availableConditions[hGui.random.nextInt(availableConditions.length)];
    double itemFloat = app.marketGeneration.generateFloatForCondition(skinName, condition);

    double price;
    if ("Gloves".equals(actualRarity)) {
      price =
          app.priceTables.calculateGlovePrice(
              skinName, condition, app.itemPriceService.getBasePrice(skinName));
    } else {
      price =
          app.itemPriceService.getBasePrice(skinName)
              * app.priceModifiers.getConditionPriceMultiplier(skinName, condition);
    }

    boolean isKnife = "Knife".equals(actualRarity);
    boolean isGloves = "Gloves".equals(actualRarity);
    int patternID = hGui.random.nextInt(1000);
    String blueGemTier = app.itemPriceService.getBlueGemTier(skinName, patternID);
    if (blueGemTier != null) {
      skinName = skinName + " (" + blueGemTier + ")";
      price = app.itemPriceService.applyBlueGemMultiplier(skinName, patternID, blueGemTier, price);
    }

    boolean simulatedStatTrak =
        app.itemMetadataService.supportsStatTrak(skinName) && hGui.random.nextDouble() < 0.10;
    if (simulatedStatTrak) {
      if (isKnife) price *= skinName.contains("Doppler") ? 0.80 : 0.95;
      else price *= 1.70 + hGui.random.nextDouble() * 0.30;
    }

    price *= (app.marketPriceMultipliers.getOrDefault(actualRarity, 1.0));
    price *= 0.90 + hGui.random.nextDouble() * 0.20;
    price =
        app.itemPriceService.capPriceToMarket(
            skinName, condition, simulatedStatTrak, price, blueGemTier);

    Image skinImg = app.artworkService.getSkinImageFromName(skinName, condition);
    InventoryItem item =
        new InventoryItem(
            skinImg != null ? new ImageIcon(skinImg) : null,
            skinName,
            condition,
            simulatedStatTrak ? "StatTrak " + actualRarity : actualRarity,
            BigDecimal.valueOf(price).setScale(2, RoundingMode.HALF_UP),
            itemFloat,
            simulatedStatTrak,
            patternID,
            blueGemTier,
            price);
    item.collection = app.collectionService.getCollectionName(skinName);
    return item;
  }

  InventoryItem createSimulatedArmouryRedeemItem() {
    if (hGui.ARMOURY_COLLECTIONS == null || hGui.ARMOURY_COLLECTIONS.length == 0) {
      return app.activitySimulationService.createSimulatedUnboxItem(
          app.activitySimulationService.rollSimulatedCaseRarity());
    }
    ArmouryCollection col =
        hGui.ARMOURY_COLLECTIONS[hGui.random.nextInt(hGui.ARMOURY_COLLECTIONS.length)];
    double[] rarityWeights;
    String[][] tierNames;
    double[][] tierPrices;
    String[] tierRarities;
    if (col.isAgents) {
      rarityWeights = app.itemMetadataService.getArmouryRarityWeights(col);
      tierNames =
          new String[][] {
            col.covertNames, col.classifiedNames, col.restrictedNames, col.milspecNames
          };
      tierPrices =
          new double[][] {
            col.covertPrices, col.classifiedPrices, col.restrictedPrices, col.milspecPrices
          };
      tierRarities = new String[] {"Master", "Superior", "Exceptional", "Distinguished"};
    } else if (col.consumer == null || col.consumer.length == 0) {
      rarityWeights = app.itemMetadataService.getArmouryRarityWeights(col);
      tierNames =
          new String[][] {
            col.covertNames,
            col.classifiedNames,
            col.restrictedNames,
            col.milspecNames,
            col.industrialNames
          };
      tierPrices =
          new double[][] {
            col.covertPrices,
            col.classifiedPrices,
            col.restrictedPrices,
            col.milspecPrices,
            col.industrialPrices
          };
      tierRarities = new String[] {"Covert", "Classified", "Restricted", "Milspec", "Industrial"};
    } else {
      rarityWeights = app.itemMetadataService.getArmouryRarityWeights(col);
      tierNames =
          new String[][] {
            col.covertNames,
            col.classifiedNames,
            col.restrictedNames,
            col.milspecNames,
            col.industrialNames,
            col.consumerNames
          };
      tierPrices =
          new double[][] {
            col.covertPrices,
            col.classifiedPrices,
            col.restrictedPrices,
            col.milspecPrices,
            col.industrialPrices,
            col.consumerPrices
          };
      tierRarities =
          new String[] {"Covert", "Classified", "Restricted", "Milspec", "Industrial", "Consumer"};
    }
    double roll = hGui.random.nextDouble();
    double cumulative = 0.0;
    int chosenTier = tierNames.length - 1;
    for (int i = 0; i < rarityWeights.length; i++) {
      cumulative += rarityWeights[i];
      if (roll < cumulative && tierNames[i] != null && tierNames[i].length > 0) {
        chosenTier = i;
        break;
      }
    }
    while (chosenTier < tierNames.length - 1
        && (tierNames[chosenTier] == null || tierNames[chosenTier].length == 0)) {
      chosenTier++;
    }
    if (tierNames[chosenTier] == null || tierNames[chosenTier].length == 0) {
      return app.activitySimulationService.createSimulatedUnboxItem(
          app.activitySimulationService.rollSimulatedCaseRarity());
    }

    int skinIdx = hGui.random.nextInt(tierNames[chosenTier].length);
    String skinName = tierNames[chosenTier][skinIdx];
    String rarity = tierRarities[chosenTier];
    double basePrice =
        tierPrices[chosenTier] != null && skinIdx < tierPrices[chosenTier].length
            ? tierPrices[chosenTier][skinIdx]
            : app.itemPriceService.getBasePrice(skinName);
    double itemFloat = 0.0;
    String condition = "Normal";
    double price = basePrice * (app.marketPriceMultipliers.getOrDefault(rarity, 1.0));
    if (!col.isAgents) {
      String[] conditions = app.floatRules.getAvailableConditions(skinName);
      condition = conditions[hGui.random.nextInt(conditions.length)];
      itemFloat = app.marketGeneration.generateFloatForCondition(skinName, condition);
      price =
          basePrice
              * app.marketInitialization.getMarketMultiplier(rarity, col.name)
              * app.priceModifiers.getMarketConditionMultiplier(skinName, condition)
              * (0.90 + hGui.random.nextDouble() * 0.20);
    }
    Image skinImg = app.artworkService.getSkinImageFromName(skinName, condition);
    InventoryItem item =
        new InventoryItem(
            skinImg != null ? new ImageIcon(skinImg) : null,
            skinName,
            condition,
            rarity,
            BigDecimal.valueOf(price).setScale(2, RoundingMode.HALF_UP),
            itemFloat,
            false,
            hGui.random.nextInt(1000),
            null,
            price);
    item.collection = col.name;
    return item;
  }

  void generateSimulatedRecentUnbox() {
    InventoryItem item;
    if (hGui.random.nextDouble() < 0.28) {
      item = app.activitySimulationService.createSimulatedArmouryRedeemItem();
    } else {
      String rarity = app.activitySimulationService.rollSimulatedCaseRarity();
      if (hGui.random.nextDouble() < 0.18) {
        String[] boostedRare = {"Knife", "Gloves", "Covert"};
        rarity = boostedRare[hGui.random.nextInt(boostedRare.length)];
      }
      item = app.activitySimulationService.createSimulatedUnboxItem(rarity);
    }
    app.activitySimulationService.addRecentUnboxedSkin(
        item, MarketListing.generateRandomUsername(), MarketListing.generateRandomAvatar());
  }

  void addUnboxedSkin(String skinName) {
    if (skinName == null) return;
    String cleanName = skinName.replace("StatTrak ", "").trim();

    if (cleanName.contains("(Blue Gem")) {
      if (cleanName.contains("(Blue Gem"))
        cleanName = cleanName.substring(0, cleanName.indexOf("(Blue Gem")).trim();
    }

    if (cleanName.contains("Doppler")) {
      int dopplerIndex = cleanName.indexOf("Doppler");
      if (dopplerIndex != -1) {
        cleanName = cleanName.substring(0, dopplerIndex + 7).trim();
      }
    }

    boolean wasNew = !app.unboxedSkins.contains(cleanName);
    app.unboxedSkins.add(cleanName);

    if (wasNew) {
      int collectionSize = app.unboxedSkins.size();

      app.achievements.get("collect_10").progress = collectionSize;
      app.achievements.get("collect_25").progress = collectionSize;
      app.achievements.get("collect_50").progress = collectionSize;
      app.achievements.get("collect_all").progress = collectionSize;

      if (collectionSize == 10 && !app.achievements.get("collect_10").isUnlocked) {
        app.achievementScreen.unlockAchievement("collect_10");
      }
      if (collectionSize == 25 && !app.achievements.get("collect_25").isUnlocked) {
        app.achievementScreen.unlockAchievement("collect_25");
      }
      if (collectionSize == 50 && !app.achievements.get("collect_50").isUnlocked) {
        app.achievementScreen.unlockAchievement("collect_50");
      }
      if (collectionSize == app.collectionScreen.getAllPossibleSkins().size()
          && !app.achievements.get("collect_all").isUnlocked) {
        app.achievementScreen.unlockAchievement("collect_all");
      }
    }
  }
}
