package blahblah;

import blahblah.hGui.*;
import java.awt.*;
import java.awt.event.*;
import javax.swing.*;

/** Extracted reusable model or widget; behavior retained from the original source. */
final class CrateRollResult {
  final String rarityName;
  final Color rarityColor;
  final boolean isStatTrak;
  final double priceMultiplier;
  final String forcedSkinName;

  CrateRollResult(
      String rarityName, Color rarityColor, boolean isStatTrak, double priceMultiplier) {
    this(rarityName, rarityColor, isStatTrak, priceMultiplier, null);
  }

  CrateRollResult(
      String rarityName,
      Color rarityColor,
      boolean isStatTrak,
      double priceMultiplier,
      String forcedSkinName) {
    this.forcedSkinName = forcedSkinName;
    this.rarityName = rarityName;
    this.rarityColor = rarityColor;
    this.isStatTrak = isStatTrak;
    this.priceMultiplier = priceMultiplier;
  }
}
