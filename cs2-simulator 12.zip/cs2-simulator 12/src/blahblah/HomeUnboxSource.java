package blahblah;

import blahblah.hGui.*;
import java.awt.*;
import java.awt.event.*;
import java.util.List;
import javax.swing.*;

/** Extracted reusable model or widget; behavior retained from the original source. */
final class HomeUnboxSource {
  final String kind, name;
  final List<HomeUnboxTier> tiers;

  HomeUnboxSource(String kind, String name, List<HomeUnboxTier> tiers) {
    this.kind = kind;
    this.name = name;
    this.tiers = List.copyOf(tiers);
  }
}
