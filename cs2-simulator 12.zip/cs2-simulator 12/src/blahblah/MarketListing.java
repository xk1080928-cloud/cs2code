package blahblah;

import blahblah.hGui.*;
import java.awt.*;
import java.awt.event.*;
import java.math.BigDecimal;
import java.math.RoundingMode;
import javax.swing.*;

/** Extracted reusable model or widget; behavior retained from the original source. */
public class MarketListing {
  InventoryItem item;
  double listPrice;
  int timeRemaining;
  boolean isPlayerListing;
  String sellerName;
  Image sellerAvatar;
  String marketplaceName;
  String marketplaceType;
  double marketplaceRating;
  String marketplaceReviews;
  boolean promoted;
  int quantity = 1;
  double saleFee;
  MarketListing stockParent;
  int stockIndex = -1;

  @Override
  public boolean equals(Object other) {
    if (this == other) return true;
    if (stockParent == null || !(other instanceof MarketListing)) return false;
    MarketListing view = (MarketListing) other;
    return view.stockParent == stockParent && view.stockIndex == stockIndex;
  }

  @Override
  public int hashCode() {
    return stockParent == null
        ? System.identityHashCode(this)
        : 31 * System.identityHashCode(stockParent) + stockIndex;
  }

  public MarketListing(
      InventoryItem item, double listPrice, int timeRemaining, boolean isPlayerListing) {
    this.item = item;
    this.listPrice = listPrice;
    this.timeRemaining = timeRemaining;
    this.isPlayerListing = isPlayerListing;
    this.sellerName = isPlayerListing ? "YOU" : generateRandomUsername();
    this.sellerAvatar = isPlayerListing ? null : generateRandomAvatar();
    MarketplaceProfile profile = isPlayerListing ? null : MarketplaceProfile.randomForListing();
    this.marketplaceName = isPlayerListing ? "Your Listing" : profile.name;
    this.marketplaceType = isPlayerListing ? "PLAYER" : profile.type;
    this.marketplaceRating = isPlayerListing ? 5.0 : profile.rating;
    this.marketplaceReviews = isPlayerListing ? "Direct Listing" : profile.reviews;
    this.promoted = !isPlayerListing && profile.promoted;
    if (!isPlayerListing) {
      double marketFactor =
          "P2P".equals(this.marketplaceType)
              ? (0.975 + hGui.random.nextDouble() * 0.020)
              : (1.005 + hGui.random.nextDouble() * 0.045);
      this.listPrice *= marketFactor;
      this.item.price = BigDecimal.valueOf(this.listPrice).setScale(2, RoundingMode.HALF_UP);
    }
  }

  double unitPriceFactor = 1.0;

  double getPrice() {
    if (stockParent != null) return MarketDynamics.cents(stockParent.getPrice() * unitPriceFactor);
    if (!isPlayerListing) {
      Double container = ContainerMarketService.quote(item.name);
      if (container != null && !Double.isFinite(container)) return Double.NaN;
      return MarketDynamics.cents(listPrice);
    }
    return listPrice; // A player's explicit ask never drifts behind their back.
  }

  void setPrice(double price) {
    listPrice = price;
  }

  static String generateRandomUsername() {
    return hGui.NPC_USERNAMES[hGui.random.nextInt(hGui.NPC_USERNAMES.length)];
  }

  static Image generateRandomAvatar() {
    return hGui.NPC_AVATAR_POOL[hGui.random.nextInt(hGui.NPC_AVATAR_POOL.length)];
  }
}
