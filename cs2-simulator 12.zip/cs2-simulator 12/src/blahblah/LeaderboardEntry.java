package blahblah;

import blahblah.hGui.*;
import java.awt.*;
import java.awt.event.*;
import java.util.ArrayList;
import javax.swing.*;

/** Extracted reusable model or widget; behavior retained from the original source. */
public class LeaderboardEntry {
  String username;
  double inventoryValue;
  Image avatar;
  int rank;
  boolean isPlayer;
  ArrayList<InventoryItem> inventoryItems;

  public LeaderboardEntry(String username, double value, Image avatar, boolean isPlayer) {
    this(username, value, avatar, isPlayer, new ArrayList<>());
  }

  public LeaderboardEntry(
      String username,
      double value,
      Image avatar,
      boolean isPlayer,
      ArrayList<InventoryItem> inventoryItems) {
    this.username = username;
    this.inventoryValue = value;
    this.avatar = avatar;
    this.isPlayer = isPlayer;
    this.inventoryItems = inventoryItems != null ? inventoryItems : new ArrayList<>();
  }
}
