package blahblah;

import blahblah.hGui.*;
import java.awt.*;
import java.awt.event.*;
import java.util.ArrayList;
import javax.swing.*;

/** Extracted reusable model or widget; behavior retained from the original source. */
public class TradeOffer {
  String npcName;
  Image npcAvatar;
  ArrayList<InventoryItem> npcOfferedItems;
  double npcOfferedMoney;
  ArrayList<InventoryItem> npcRequestedItems;
  double npcRequestedMoney;
  long timestamp;
  boolean isAccepted;
  boolean isDeclined;
  String tradeId;
  boolean isMarketplacePurchase;
  boolean isInstantDelivery;
  String marketplaceName;
  String marketplaceType;
  double settledPrice;
  long deliveryScheduledTime;

  public TradeOffer(
      String npcName,
      Image npcAvatar,
      ArrayList<InventoryItem> offered,
      double offeredMoney,
      ArrayList<InventoryItem> requested,
      double requestedMoney) {
    this.npcName = npcName;
    this.npcAvatar = npcAvatar;
    this.npcOfferedItems = new ArrayList<>(offered);
    this.npcOfferedMoney = offeredMoney;
    this.npcRequestedItems = new ArrayList<>(requested);
    this.npcRequestedMoney = requestedMoney;
    this.timestamp = System.currentTimeMillis();
    this.isAccepted = false;
    this.isDeclined = false;
    this.tradeId = "TRADE_" + System.currentTimeMillis() + "_" + hGui.random.nextInt(1000);
    this.isMarketplacePurchase = false;
    this.isInstantDelivery = false;
    this.marketplaceName = null;
    this.marketplaceType = null;
    this.settledPrice = 0.0;
    this.deliveryScheduledTime = 0L;
  }
}
