package blahblah;

import blahblah.hGui.*;
import java.awt.*;
import java.awt.event.*;
import java.util.ArrayList;
import java.util.List;
import java.util.Set;
import javax.swing.*;

/** Odds And Checklist Screen: focused feature implementation. */
final class OddsAndChecklistScreen {
  private final hGui app;

  OddsAndChecklistScreen(hGui app) {
    this.app = app;
  }

  void showArmouryOddsWindow() {
    JDialog dlg = new JDialog(app, "Drop Odds Reference", true);
    dlg.setSize(500, 480);
    dlg.setLocationRelativeTo(app);

    Color BG = new Color(15, 15, 20);
    Color TEXT = new Color(230, 230, 235);

    JPanel panel = new JPanel();
    panel.setLayout(new BoxLayout(panel, BoxLayout.Y_AXIS));
    panel.setBackground(BG);
    panel.setBorder(BorderFactory.createEmptyBorder(20, 40, 20, 40));

    JLabel title = new JLabel("Drop Odds Reference", SwingConstants.CENTER);
    title.setFont(new Font("Consolas", Font.BOLD, 20));
    title.setForeground(Theme.ACCENT_T);
    title.setAlignmentX(Component.CENTER_ALIGNMENT);
    panel.add(title);
    panel.add(Box.createRigidArea(new Dimension(0, 20)));

    JLabel armTitle = new JLabel("  Armoury Pass  ", SwingConstants.CENTER);
    armTitle.setFont(new Font("Consolas", Font.BOLD, 15));
    armTitle.setForeground(Theme.GOLD);
    armTitle.setAlignmentX(Component.CENTER_ALIGNMENT);
    panel.add(armTitle);
    panel.add(Box.createRigidArea(new Dimension(0, 8)));

    String[][] armOdds = {
      {"Covert   (Red)", "~0.13%   (1 / 756)"},
      {"Classified  (Pink)", "~0.66%   (1 / 151)"},
      {"Restricted  (Purple)", "~3.33%   (1 / 30)"},
      {"Milspec  (Blue)", "~16.67%  (1 / 6)"},
      {"Industrial  (Light Blue)", "~79.92%  (most drops)"},
    };
    Color[] armColors = {
      Theme.RARITY_COVERT,
      Theme.RARITY_CLASSIFIED,
      Theme.RARITY_RESTRICTED,
      Theme.RARITY_MILSPEC,
      new Color(110, 190, 110)
    };
    for (int i = 0; i < armOdds.length; i++) {
      JLabel lbl = new JLabel(String.format("  %-32s %s", armOdds[i][0], armOdds[i][1]));
      lbl.setFont(new Font("Consolas", Font.PLAIN, 13));
      lbl.setForeground(armColors[i]);
      lbl.setAlignmentX(Component.LEFT_ALIGNMENT);
      panel.add(lbl);
    }

    panel.add(Box.createRigidArea(new Dimension(0, 22)));

    JLabel caseTitle = new JLabel("[*]  Case Unboxing  [*]", SwingConstants.CENTER);
    caseTitle.setFont(new Font("Consolas", Font.BOLD, 15));
    caseTitle.setForeground(Theme.ACCENT_T);
    caseTitle.setAlignmentX(Component.CENTER_ALIGNMENT);
    panel.add(caseTitle);
    panel.add(Box.createRigidArea(new Dimension(0, 8)));

    String[][] caseOdds = {
      {"Mil-Spec / Industrial", "79.92%  (most drops)"},
      {"Restricted  (Purple)", "15.98%"},
      {"Classified  (Pink)", "3.20%"},
      {"Covert  (Red)", "0.64%"},
      {"Knife / Gloves  (Gold)", "0.26%"},
    };
    Color[] caseColors = {
      Theme.RARITY_MILSPEC,
      Theme.RARITY_RESTRICTED,
      Theme.RARITY_CLASSIFIED,
      Theme.RARITY_COVERT,
      Theme.RARITY_GOLD
    };
    for (int i = 0; i < caseOdds.length; i++) {
      JLabel lbl = new JLabel(String.format("  %-32s %s", caseOdds[i][0], caseOdds[i][1]));
      lbl.setFont(new Font("Consolas", Font.PLAIN, 13));
      lbl.setForeground(caseColors[i]);
      lbl.setAlignmentX(Component.LEFT_ALIGNMENT);
      panel.add(lbl);
    }

    panel.add(Box.createRigidArea(new Dimension(0, 10)));
    JLabel stNote = new JLabel("  StatTrak  ->  10% chance on any eligible item");
    stNote.setFont(new Font("Consolas", Font.PLAIN, 13));
    stNote.setForeground(new Color(255, 140, 0));
    stNote.setAlignmentX(Component.LEFT_ALIGNMENT);
    panel.add(stNote);

    panel.add(Box.createRigidArea(new Dimension(0, 22)));

    JButton closeBtn = new JButton("CLOSE");
    app.uiWidgets.styleButton(closeBtn, new Color(40, 40, 55), TEXT, new Color(60, 60, 80));
    closeBtn.setAlignmentX(Component.CENTER_ALIGNMENT);
    closeBtn.addActionListener(ev -> dlg.dispose());
    panel.add(closeBtn);

    JScrollPane scroll = new JScrollPane(panel);
    scroll.setBorder(null);
    scroll.getViewport().setBackground(BG);
    dlg.getContentPane().setBackground(BG);
    dlg.add(scroll);
    dlg.setVisible(true);
  }

  void showCollectionChecklistHelper() {
    JDialog dlg = new JDialog(app, "New Collection Checklist Helper", true);
    dlg.setSize(900, 680);
    dlg.setLocationRelativeTo(app);
    dlg.setLayout(new BorderLayout());
    dlg.getContentPane().setBackground(new Color(15, 15, 20));

    JPanel top = new JPanel(new FlowLayout(FlowLayout.LEFT, 10, 10));
    top.setBackground(new Color(22, 22, 30));
    top.setBorder(BorderFactory.createEmptyBorder(8, 10, 8, 10));

    JLabel label = new JLabel("Collection:");
    label.setForeground(Color.WHITE);
    label.setFont(new Font("Consolas", Font.BOLD, 12));
    top.add(label);

    java.util.List<String> names = new java.util.ArrayList<>();
    for (TradeUpCollection tc : hGui.TRADE_UP_COLLECTIONS) names.add(tc.collectionName);
    JComboBox<String> collectionBox = new JComboBox<>(names.toArray(new String[0]));
    app.uiWidgets.styleComboBox(collectionBox);
    top.add(collectionBox);

    JButton refreshBtn = new JButton("Run Audit");
    app.uiWidgets.styleButton(
        refreshBtn, new Color(40, 90, 120), new Color(230, 230, 235), new Color(70, 150, 190));
    top.add(refreshBtn);
    dlg.add(top, BorderLayout.NORTH);

    JTextArea reportArea = new JTextArea();
    reportArea.setEditable(false);
    reportArea.setFont(new Font("Consolas", Font.PLAIN, 12));
    reportArea.setBackground(new Color(18, 18, 26));
    reportArea.setForeground(new Color(230, 230, 235));
    reportArea.setCaretColor(new Color(230, 230, 235));
    reportArea.setLineWrap(false);
    reportArea.setWrapStyleWord(false);

    JScrollPane scroll = new JScrollPane(reportArea);
    scroll.getViewport().setBackground(new Color(18, 18, 26));
    scroll.setBorder(BorderFactory.createEmptyBorder());
    dlg.add(scroll, BorderLayout.CENTER);

    Runnable refresh =
        () -> {
          String collectionName = (String) collectionBox.getSelectedItem();
          reportArea.setText(
              app.oddsAndChecklistScreen.buildCollectionChecklistReport(collectionName));
          reportArea.setCaretPosition(0);
        };
    refreshBtn.addActionListener(e -> refresh.run());
    collectionBox.addActionListener(e -> refresh.run());
    refresh.run();

    dlg.setVisible(true);
  }

  String buildCollectionChecklistReport(String collectionName) {
    TradeUpCollection col = null;
    for (TradeUpCollection tc : hGui.TRADE_UP_COLLECTIONS) {
      if (tc.collectionName.equals(collectionName)) {
        col = tc;
        break;
      }
    }
    if (col == null) return "Collection not found.";

    java.util.List<String> skins = new java.util.ArrayList<>();
    java.util.Collections.addAll(skins, col.covertSkins);
    java.util.Collections.addAll(skins, col.classifiedSkins);
    java.util.Collections.addAll(skins, col.restrictedSkins);
    java.util.Collections.addAll(skins, col.milspecSkins);
    java.util.List<String> allPossible = app.collectionScreen.getAllPossibleSkins();
    if (app.globalMarketListings.isEmpty()) app.marketGeneration.generateGlobalMarketListings();

    java.util.List<String> missingBasePrice = new java.util.ArrayList<>();
    java.util.List<String> missingFloat = new java.util.ArrayList<>();
    java.util.List<String> missingImage = new java.util.ArrayList<>();
    java.util.List<String> missingInCollectionView = new java.util.ArrayList<>();
    java.util.List<String> missingInMarket = new java.util.ArrayList<>();
    java.util.List<String> wrongCollectionLookup = new java.util.ArrayList<>();

    for (String skin : skins) {
      if (app.itemPriceService.getBasePrice(skin) <= 0.0) missingBasePrice.add(skin);
      if (hGui.FLOAT_LIMITS.get(skin) == null) missingFloat.add(skin);
      if (app.artworkService.getArtworkMetadata(app.artworkService.canonicalArtworkName(skin))
          == null) missingImage.add(skin);
      if (!allPossible.contains(skin)) missingInCollectionView.add(skin);
      if (!app.globalMarketListings.containsKey(app.leaderboardService.normalizeSkinName(skin)))
        missingInMarket.add(skin);
      String resolvedCollection = app.collectionService.getCollectionName(skin);
      if (!collectionName.equals(resolvedCollection)) {
        wrongCollectionLookup.add(skin + " -> " + String.valueOf(resolvedCollection));
      }
    }

    boolean hasCaseType = false;
    for (CaseType ct : CaseType.values()) {
      String mapped = app.oddsAndChecklistScreen.getCollectionNameForCaseType(ct);
      if (collectionName.equals(mapped)) {
        hasCaseType = true;
        break;
      }
    }

    StringBuilder sb = new StringBuilder();
    sb.append("Collection Audit: ").append(collectionName).append("\n\n");
    sb.append(
        hasCaseType
            ? "[OK] Case + ROI wiring present\n"
            : "[MISSING] No CaseType/ROI mapping for this collection\n");
    sb.append("[OK] Trade-up collection registered with ").append(skins.size()).append(" skins\n");
    sb.append(
        missingBasePrice.isEmpty()
            ? "[OK] Base prices present for all skins\n"
            : "[MISSING] Base prices missing:\n  - "
                + String.join("\n  - ", missingBasePrice)
                + "\n");
    sb.append(
        missingFloat.isEmpty()
            ? "[OK] Float limits present for all skins\n"
            : "[MISSING] Float limits missing:\n  - " + String.join("\n  - ", missingFloat) + "\n");
    sb.append(
        missingImage.isEmpty()
            ? "[OK] Image mappings resolve for all skins\n"
            : "[MISSING] Image mappings missing:\n  - "
                + String.join("\n  - ", missingImage)
                + "\n");
    sb.append(
        missingInCollectionView.isEmpty()
            ? "[OK] Collection/regular tab includes all skins\n"
            : "[MISSING] getAllPossibleSkins missing:\n  - "
                + String.join("\n  - ", missingInCollectionView)
                + "\n");
    sb.append(
        missingInMarket.isEmpty()
            ? "[OK] Market listings generated for all skins\n"
            : "[MISSING] Market listing keys missing:\n  - "
                + String.join("\n  - ", missingInMarket)
                + "\n");
    sb.append(
        wrongCollectionLookup.isEmpty()
            ? "[OK] Collection lookup resolves correctly for all skins\n"
            : "[MISSING] Collection lookup issues:\n  - "
                + String.join("\n  - ", wrongCollectionLookup)
                + "\n");
    sb.append("\nChecklist for future collections:\n");
    sb.append(
        "1. Add the CaseType entry and map it in case selection / current collection helpers.\n");
    sb.append("2. Add the TradeUpCollection with mil-spec through covert skin names.\n");
    sb.append("3. Add base prices and float ranges for every skin.\n");
    sb.append("4. Add SKIN_TO_FILE mappings and confirm image files exist.\n");
    sb.append("5. Add skins to getAllPossibleSkins and market generation pools.\n");
    sb.append(
        "6. Verify collection lookup, recent sales, trade offers, and regular market filters.\n");
    sb.append("7. Run the Image Verifier after changes.\n");
    return sb.toString();
  }

  String getCollectionNameForCaseType(CaseType caseType) {
    if (caseType == null) return null;
    if (caseType.isTerminal)
      return caseType
          .crateName
          .replaceFirst("(?i)^Sealed\\s+", "")
          .replaceFirst("(?i)\\s+Terminal$", " Collection");
    if (caseType == CaseType.WEAPON_CASE_ONE) return "Weapon Case One";
    if (caseType == CaseType.BRAVO) return "Bravo Collection";
    if (caseType == CaseType.BREAKOUT) return "Breakout Collection";
    if (caseType == CaseType.SPECTRUM) return "Spectrum Collection";
    if (caseType == CaseType.KILOWATT) return "Kilowatt Collection";
    if (caseType == CaseType.REVOLUTION) return "Revolution Collection";
    if (caseType == CaseType.CHROMA) return "Chroma Collection";
    if (caseType == CaseType.CHROMA_2) return "Chroma 2 Collection";
    if (caseType == CaseType.CHROMA_3) return "Chroma 3 Collection";
    return null;
  }

  void addTradeUpTierSkins(java.util.Set<String> target, String[] skins) {
    if (skins == null) return;
    for (String skin : skins) {
      if (skin != null && !skin.isEmpty()) target.add(skin);
    }
  }

  java.util.List<String> getRegisteredTradeUpSkins() {
    java.util.LinkedHashSet<String> skins = new java.util.LinkedHashSet<>();
    for (TradeUpCollection col : hGui.TRADE_UP_COLLECTIONS) {
      app.oddsAndChecklistScreen.addTradeUpTierSkins(skins, col.covertSkins);
      app.oddsAndChecklistScreen.addTradeUpTierSkins(skins, col.classifiedSkins);
      app.oddsAndChecklistScreen.addTradeUpTierSkins(skins, col.restrictedSkins);
      app.oddsAndChecklistScreen.addTradeUpTierSkins(skins, col.milspecSkins);
    }
    for (CaseType caseType : CaseType.values()) {
      TradeUpCollection col = app.collectionService.buildCatalogCaseCollection(caseType);
      if (col == null) continue;
      app.oddsAndChecklistScreen.addTradeUpTierSkins(skins, col.covertSkins);
      app.oddsAndChecklistScreen.addTradeUpTierSkins(skins, col.classifiedSkins);
      app.oddsAndChecklistScreen.addTradeUpTierSkins(skins, col.restrictedSkins);
      app.oddsAndChecklistScreen.addTradeUpTierSkins(skins, col.milspecSkins);
      app.oddsAndChecklistScreen.addTradeUpTierSkins(skins, col.industrialSkins);
    }
    for (TradeUpCollection col : app.requestedMarketCollections.values()) {
      for (String[] tier :
          new String[][] {
            col.consumerSkins,
            col.industrialSkins,
            col.milspecSkins,
            col.restrictedSkins,
            col.classifiedSkins,
            col.covertSkins
          }) app.oddsAndChecklistScreen.addTradeUpTierSkins(skins, tier);
    }
    return new java.util.ArrayList<>(skins);
  }

  void showSkinImageVerifier() {
    JDialog dlg = new JDialog(app, "Skin Image Verifier", true);
    dlg.setSize(920, 700);
    dlg.setLocationRelativeTo(app);
    dlg.setLayout(new BorderLayout());
    dlg.getContentPane().setBackground(new Color(15, 15, 20));

    JPanel top = new JPanel(new FlowLayout(FlowLayout.LEFT, 10, 10));
    top.setBackground(new Color(22, 22, 30));
    top.setBorder(BorderFactory.createEmptyBorder(8, 10, 8, 10));
    JButton runBtn = new JButton("Run Verification");
    app.uiWidgets.styleButton(
        runBtn, new Color(90, 70, 30), new Color(230, 230, 235), new Color(180, 140, 60));
    top.add(runBtn);
    dlg.add(top, BorderLayout.NORTH);

    JTextArea reportArea = new JTextArea();
    reportArea.setEditable(false);
    reportArea.setFont(new Font("Consolas", Font.PLAIN, 12));
    reportArea.setBackground(new Color(18, 18, 26));
    reportArea.setForeground(new Color(230, 230, 235));

    JScrollPane scroll = new JScrollPane(reportArea);
    scroll.getViewport().setBackground(new Color(18, 18, 26));
    scroll.setBorder(BorderFactory.createEmptyBorder());
    dlg.add(scroll, BorderLayout.CENTER);

    Runnable runVerification =
        () -> {
          reportArea.setText(app.oddsAndChecklistScreen.buildSkinImageVerifierReport());
          reportArea.setCaretPosition(0);
        };
    runBtn.addActionListener(e -> runVerification.run());
    runVerification.run();
    dlg.setVisible(true);
  }

  String buildSkinImageVerifierReport() {
    Set<String> names = new java.util.TreeSet<>(app.collectionScreen.getAllPossibleSkins());
    names.addAll(app.skinCatalog.keySet());
    names.addAll(app.agentCatalog.keySet());
    List<String> missing = new ArrayList<>();
    int configured = 0, wearSources = 0;
    for (String name : names) {
      String canonical = app.artworkService.canonicalArtworkName(name);
      SkinMetadata metadata = app.artworkService.getArtworkMetadata(canonical);
      if (metadata != null && metadata.imageUrl != null && metadata.imageUrl.startsWith("https://"))
        configured++;
      else missing.add(name);
      if (app.wearImageBasePaths.containsKey(canonical)) wearSources++;
    }
    return "REMOTE SKIN ARTWORK VERIFIER\n\n"
        + "Skins checked: "
        + names.size()
        + "\nConfigured online images: "
        + configured
        + "\nConfigured real-wear source paths: "
        + wearSources
        + "\n\n"
        + "No bundled/local PNG files are required. Downloaded images may be cached"
        + " automatically.\n"
        + "Wear images are requested on demand; unavailable renders fall back to the standard"
        + " online image.\n"
        + "This report checks source configuration without downloading every skin or blocking the"
        + " UI.\n\n"
        + "Missing online metadata ("
        + missing.size()
        + "):\n"
        + String.join("\n", missing);
  }

  void verifyTierOrder(
      java.util.List<String> issues, String label, String[] names, String[] expectedFiles) {
    for (int i = 0; i < names.length && i < expectedFiles.length; i++) {
      String actual = hGui.SKIN_TO_FILE.get(names[i]);
      if (!expectedFiles[i].equals(actual)) {
        issues.add(
            label
                + ": "
                + names[i]
                + " expected "
                + expectedFiles[i]
                + " but found "
                + String.valueOf(actual));
      }
    }
  }
}
