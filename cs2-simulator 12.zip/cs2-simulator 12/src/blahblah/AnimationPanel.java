package blahblah;

import blahblah.hGui.*;
import java.awt.*;
import java.awt.event.*;
import java.util.ArrayList;
import java.util.HashSet;
import java.util.Set;
import javax.swing.*;

/** Extracted reusable model or widget; behavior retained from the original source. */
class AnimationPanel extends JPanel {
  private final hGui app;

  private java.awt.image.BufferedImage backdrop;
  private int backdropScenery = -1;
  private final java.util.IdentityHashMap<Image, Image> sprites = new java.util.IdentityHashMap<>();

  private Image sprite(Image source, int width, int height) {
    Image ready = sprites.get(source);
    if (ready != null) return ready;
    ready = HighQualityImages.canvas(source, width, height);
    sprites.put(source, ready);
    return ready;
  }

  int scrollOffset = 0;
  ArrayList<AnimatedSkin> skinStrip = new ArrayList<>();
  int finalIndex = AnimationConfig.FINAL_INDEX;
  boolean isGoldReveal = false;

  Set<Image> gloveSet = null;
  Set<Image> knifeSet = null;
  Set<Image> redSet = null;
  Set<Image> pinkSet = null;
  Set<Image> purpleSet = null;

  void initRaritySetsIfNeeded() {
    if (gloveSet == null) {
      gloveSet = new HashSet<>(java.util.Arrays.asList(app.gloveSkins));
      knifeSet = new HashSet<>(java.util.Arrays.asList(app.knifeSkins));
      redSet = new HashSet<>(java.util.Arrays.asList(app.redSkins));
      pinkSet = new HashSet<>(java.util.Arrays.asList(app.pinkSkins));
      purpleSet = new HashSet<>(java.util.Arrays.asList(app.purpleSkins));
    }
  }

  class AnimatedSkin {
    Image image;
    boolean isStatTrak;
    Color rarityColor;

    AnimatedSkin(Image image, boolean isStatTrak, Color rarityColor) {
      this.image = image;
      this.isStatTrak = isStatTrak;
      this.rarityColor = rarityColor;
    }
  }

  public AnimationPanel(hGui app, CrateRollResult rollResult) {
    this.app = app;
    skinStrip.clear();

    initRaritySetsIfNeeded();
    boolean finalIsGold =
        "Knife".equals(rollResult.rarityName) || "Gloves".equals(rollResult.rarityName);
    isGoldReveal = finalIsGold;

    TradeUpCollection animCol =
        app.currentCase.isSouvenir
            ? app.collectionService.buildCatalogCaseCollection(app.currentCase)
            : app.collectionService.getCurrentCaseCollection();

    java.util.List<Image> animConsumer = new java.util.ArrayList<>();
    java.util.List<Image> animIndustrial = new java.util.ArrayList<>();
    java.util.List<Image> animBlue = new java.util.ArrayList<>();
    java.util.List<Image> animPurple = new java.util.ArrayList<>();
    java.util.List<Image> animPink = new java.util.ArrayList<>();
    java.util.List<Image> animRed = new java.util.ArrayList<>();

    if (app.currentCase.isSouvenir) {
      for (String s :
          app.currentCase.regularDropNames.getOrDefault(
              "Consumer", java.util.Collections.emptyList())) {
        Image img = app.artworkService.getSkinImageFromName(s);
        if (img != null) animConsumer.add(img);
      }
      for (String s :
          app.currentCase.regularDropNames.getOrDefault(
              "Industrial", java.util.Collections.emptyList())) {
        Image img = app.artworkService.getSkinImageFromName(s);
        if (img != null) animIndustrial.add(img);
      }
      for (String s :
          app.currentCase.regularDropNames.getOrDefault(
              "Milspec", java.util.Collections.emptyList())) {
        Image img = app.artworkService.getSkinImageFromName(s);
        if (img != null) animBlue.add(img);
      }
      for (String s :
          app.currentCase.regularDropNames.getOrDefault(
              "Restricted", java.util.Collections.emptyList())) {
        Image img = app.artworkService.getSkinImageFromName(s);
        if (img != null) animPurple.add(img);
      }
      for (String s :
          app.currentCase.regularDropNames.getOrDefault(
              "Classified", java.util.Collections.emptyList())) {
        Image img = app.artworkService.getSkinImageFromName(s);
        if (img != null) animPink.add(img);
      }
      for (String s :
          app.currentCase.regularDropNames.getOrDefault(
              "Covert", java.util.Collections.emptyList())) {
        Image img = app.artworkService.getSkinImageFromName(s);
        if (img != null) animRed.add(img);
      }
    } else if (animCol != null) {
      for (String s : animCol.consumerSkins) {
        Image img = app.artworkService.getSkinImageFromName(s);
        if (img != null) animConsumer.add(img);
      }
      for (String s : animCol.industrialSkins) {
        Image img = app.artworkService.getSkinImageFromName(s);
        if (img != null) animIndustrial.add(img);
      }
      for (String s : animCol.milspecSkins) {
        Image img = app.artworkService.getSkinImageFromName(s);
        if (img != null) animBlue.add(img);
      }
      for (String s : animCol.restrictedSkins) {
        Image img = app.artworkService.getSkinImageFromName(s);
        if (img != null) animPurple.add(img);
      }
      for (String s : animCol.classifiedSkins) {
        Image img = app.artworkService.getSkinImageFromName(s);
        if (img != null) animPink.add(img);
      }
      for (String s : animCol.covertSkins) {
        Image img = app.artworkService.getSkinImageFromName(s);
        if (img != null) animRed.add(img);
      }
    }

    if (!app.currentCase.isSouvenir) {
      if (animConsumer.isEmpty() && app.blueSkins != null)
        animConsumer.addAll(java.util.Arrays.asList(app.blueSkins));
      if (animIndustrial.isEmpty() && app.blueSkins != null)
        animIndustrial.addAll(java.util.Arrays.asList(app.blueSkins));
      if (animBlue.isEmpty() && app.blueSkins != null)
        animBlue.addAll(java.util.Arrays.asList(app.blueSkins));
      if (animPurple.isEmpty() && app.purpleSkins != null)
        animPurple.addAll(java.util.Arrays.asList(app.purpleSkins));
      if (animPink.isEmpty() && app.pinkSkins != null)
        animPink.addAll(java.util.Arrays.asList(app.pinkSkins));
      if (animRed.isEmpty() && app.redSkins != null)
        animRed.addAll(java.util.Arrays.asList(app.redSkins));
    }

    Image[] animConsumerArr = animConsumer.toArray(new Image[0]);
    Image[] animIndustrialArr = animIndustrial.toArray(new Image[0]);
    Image[] animBlueArr = animBlue.toArray(new Image[0]);
    Image[] animPurpleArr = animPurple.toArray(new Image[0]);
    Image[] animPinkArr = animPink.toArray(new Image[0]);
    Image[] animRedArr = animRed.toArray(new Image[0]);
    Image emptyPoolImage =
        app.currentCase.isSouvenir
            ? app.containerBrowserScreen.createItemPlaceholderImage()
            : app.finalSkin != null ? app.finalSkin : app.goldIconImage;
    if (animBlueArr.length == 0) animBlueArr = new Image[] {emptyPoolImage};
    if (animPurpleArr.length == 0)
      animPurpleArr = app.currentCase.isSouvenir ? new Image[] {emptyPoolImage} : animBlueArr;
    if (animPinkArr.length == 0)
      animPinkArr = app.currentCase.isSouvenir ? new Image[] {emptyPoolImage} : animPurpleArr;
    if (animRedArr.length == 0)
      animRedArr = app.currentCase.isSouvenir ? new Image[] {emptyPoolImage} : animPinkArr;
    if (animConsumerArr.length == 0)
      animConsumerArr = app.currentCase.isSouvenir ? new Image[] {emptyPoolImage} : animBlueArr;
    if (animIndustrialArr.length == 0)
      animIndustrialArr = app.currentCase.isSouvenir ? new Image[] {emptyPoolImage} : animBlueArr;
    Color blueColor = app.itemInspectionScreen.getRarityColor("Milspec");
    Color purpleColor = app.itemInspectionScreen.getRarityColor("Restricted");
    Color pinkColor = app.itemInspectionScreen.getRarityColor("Classified");
    Color redColor = app.itemInspectionScreen.getRarityColor("Covert");
    Color goldColor = app.itemInspectionScreen.getRarityColor("Knife");

    for (int i = 0; i < AnimationConfig.STRIP_COUNT; i++) {
      Image skinToAdd;
      boolean stattrakRoll =
          !app.currentCase.isSouvenir
              && app.itemMetadataService.supportsStatTrak(app.finalSkinName)
              && hGui.random.nextDouble() < 0.10;
      Color stripRarityColor;

      if (i == finalIndex) {
        skinToAdd =
            finalIsGold
                ? app.goldIconImage
                : app.finalSkin != null
                    ? app.finalSkin
                    : app.currentCase.isSouvenir
                        ? app.containerBrowserScreen.createItemPlaceholderImage()
                        : animBlueArr[hGui.random.nextInt(animBlueArr.length)];
        stattrakRoll = rollResult != null && rollResult.isStatTrak;
        stripRarityColor =
            finalIsGold
                ? goldColor
                : app.itemInspectionScreen.getRarityColor(
                    app.itemMetadataService.getSkinRarity(app.finalSkinName));
      } else {
        if (app.currentCase.isSouvenir) {
          String tier = CaseRollService.rollSouvenirTier(app.currentCase);
          Image[] pool;
          switch (tier) {
            case "Consumer":
              pool = animConsumerArr;
              break;
            case "Industrial":
              pool = animIndustrialArr;
              break;
            case "Milspec":
              pool = animBlueArr;
              break;
            case "Restricted":
              pool = animPurpleArr;
              break;
            case "Classified":
              pool = animPinkArr;
              break;
            case "Covert":
              pool = animRedArr;
              break;
            default:
              throw new IllegalStateException("Unsupported souvenir rarity: " + tier);
          }
          skinToAdd = pool[hGui.random.nextInt(pool.length)];
          stripRarityColor = app.itemInspectionScreen.getRarityColor(tier);
        } else {
          double roll = hGui.random.nextDouble();
          if (app.currentCase.isTerminal && app.currentCase.rareDropNames.isEmpty()) roll *= 0.9974;
          if (roll < 0.7992) {
            skinToAdd = animBlueArr[hGui.random.nextInt(animBlueArr.length)];
            stripRarityColor = blueColor;
          } else if (roll < 0.9590) {
            skinToAdd = animPurpleArr[hGui.random.nextInt(animPurpleArr.length)];
            stripRarityColor = purpleColor;
          } else if (roll < 0.9910) {
            skinToAdd = animPinkArr[hGui.random.nextInt(animPinkArr.length)];
            stripRarityColor = pinkColor;
          } else {
            skinToAdd = animRedArr[hGui.random.nextInt(animRedArr.length)];
            stripRarityColor = redColor;
          }
        }
      }

      skinStrip.add(new AnimatedSkin(skinToAdd, stattrakRoll, stripRarityColor));
    }
  }

  @Override
  protected void paintComponent(Graphics g) {
    super.paintComponent(g);
    Graphics2D g2d = (Graphics2D) g;

    g2d.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
    g2d.setRenderingHint(RenderingHints.KEY_RENDERING, RenderingHints.VALUE_RENDER_QUALITY);

    java.awt.GradientPaint bgGrad =
        new java.awt.GradientPaint(0, 0, Theme.PLACEHOLDER_BG, 0, getHeight(), Theme.BG_CARD);
    g2d.setPaint(bgGrad);
    g2d.fillRect(0, 0, getWidth(), getHeight());
    if (app.cs2ShellEnabled && getWidth() > 0 && getHeight() > 0) {
      if (backdrop == null
          || backdrop.getWidth() != getWidth()
          || backdrop.getHeight() != getHeight()
          || backdropScenery != app.cs2SceneryIndex) {
        backdrop =
            new java.awt.image.BufferedImage(
                getWidth(), getHeight(), java.awt.image.BufferedImage.TYPE_INT_RGB);
        Graphics2D back = backdrop.createGraphics();
        app.cs2Screens.paintCs2Scene(back, getWidth(), getHeight(), true);
        Image container = app.containerBrowserScreen.getContainerImage(app.currentCase);
        if (container != null) {
          back.setComposite(AlphaComposite.SrcOver.derive(.38f));
          int sw = container.getWidth(null), sh = container.getHeight(null);
          if (sw > 0 && sh > 0) {
            double scale = Math.min(510.0 / sw, 400.0 / sh);
            int w = (int) (sw * scale), h = (int) (sh * scale);
            back.drawImage(container, (getWidth() - w) / 2, (getHeight() - h) / 2, w, h, null);
          }
        }
        back.dispose();
        backdropScenery = app.cs2SceneryIndex;
      }
      g2d.drawImage(backdrop, 0, 0, null);
    }
    int centerX = getWidth() / 2;

    int skinWidth = AnimationConfig.SKIN_WIDTH;
    int skinHeight = AnimationConfig.SKIN_HEIGHT;
    int cardGap = AnimationConfig.CARD_GAP;
    int rarityBarH = 8;
    int startX = -scrollOffset;

    for (int i = 0; i < skinStrip.size(); i++) {
      int x = startX + (i * (skinWidth + cardGap));
      int y = (getHeight() - skinHeight) / 2;

      if (x + skinWidth < 0 || x > getWidth()) continue;

      AnimatedSkin anim = skinStrip.get(i);
      Image skin =
          i == finalIndex && !isGoldReveal && app.finalSkin != null ? app.finalSkin : anim.image;
      if (skin == null) continue;

      Color rarityColor =
          anim.rarityColor != null ? anim.rarityColor : getAnimationRarityColor(skin);

      g2d.setColor(Theme.ANIM_ARMOURY_CARD);
      g2d.fillRoundRect(x, y, skinWidth, skinHeight, 8, 8);

      boolean isGoldIcon = (isGoldReveal && i == finalIndex && skin == app.goldIconImage);
      int imgPad = isGoldIcon ? 16 : 10;
      int imgW = skinWidth - imgPad * 2;
      int imgH = skinHeight - rarityBarH - imgPad * 2;
      int imgX = x + imgPad;
      int imgY = y + imgPad;
      g2d.drawImage(sprite(skin, imgW, imgH), imgX, imgY, null);

      java.awt.GradientPaint barGrad =
          new java.awt.GradientPaint(
              x, 0, rarityColor.darker(), x + skinWidth, 0, rarityColor.brighter());
      g2d.setPaint(barGrad);
      g2d.fillRoundRect(x, y + skinHeight - rarityBarH, skinWidth, rarityBarH, 4, 4);
      g2d.fillRect(x, y + skinHeight - rarityBarH, skinWidth, rarityBarH / 2);
      g2d.setPaint(null);

      if (anim.isStatTrak && !isGoldIcon) {
        g2d.setFont(Theme.ARIAL_BOLD_13);
        String text = "StatTrak";
        FontMetrics fm = g2d.getFontMetrics();
        int tx = x + (skinWidth - fm.stringWidth(text)) / 2;
        int ty = y + skinHeight - rarityBarH - 6;
        g2d.setColor(Theme.ANIM_TEXT_SHADOW);
        g2d.drawString(text, tx + 1, ty + 1);
        g2d.setColor(Theme.STATTRAK_TEXT);
        g2d.drawString(text, tx, ty);
      }
    }

    if (app.cs2ShellEnabled) {
      Graphics2D fade = (Graphics2D) g2d.create();
      int edge = Math.max(getWidth() / 3, (getWidth() - 3 * AnimationConfig.SPACING) / 2);
      edge = Math.max(1, Math.min(edge, getWidth() / 2));
      Color solid = new Color(19, 27, 32, 255), clear = new Color(19, 27, 32, 0);
      fade.setPaint(new GradientPaint(0, 0, solid, edge, 0, clear));
      fade.fillRect(0, 0, edge, getHeight());
      fade.setPaint(new GradientPaint(getWidth() - edge, 0, clear, getWidth(), 0, solid));
      fade.fillRect(getWidth() - edge, 0, edge, getHeight());
      fade.dispose();
    }
    g2d.setColor(Theme.GOLD);
    g2d.setStroke(Theme.STROKE_2);
    g2d.drawLine(
        centerX,
        app.cs2ShellEnabled ? (getHeight() - skinHeight) / 2 : 0,
        centerX,
        app.cs2ShellEnabled ? (getHeight() + skinHeight) / 2 : getHeight());
  }

  Color getAnimationRarityColor(Image skin) {
    initRaritySetsIfNeeded();
    if (skin == app.goldIconImage) return new Color(228, 174, 57);
    if (skin == app.finalSkin && app.finalSkinName != null && app.finalSkinName.contains("Doppler"))
      return new Color(228, 174, 57);
    if (gloveSet.contains(skin) || knifeSet.contains(skin)) return new Color(228, 174, 57);
    if (redSet.contains(skin)) return new Color(235, 75, 75);
    if (pinkSet.contains(skin)) return new Color(211, 44, 230);
    if (purpleSet.contains(skin)) return new Color(136, 71, 255);
    return Theme.RARITY_MILSPEC;
  }

  public void setScrollOffset(int offset) {
    if (offset == scrollOffset) return;
    this.scrollOffset = offset;
    repaint();
  }

  public int getFinalSkinPosition() {
    return finalIndex * AnimationConfig.SPACING;
  }
}
