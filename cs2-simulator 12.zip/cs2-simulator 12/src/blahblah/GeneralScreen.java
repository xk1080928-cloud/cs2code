package blahblah;

import blahblah.hGui.*;
import java.awt.*;
import java.awt.event.*;
import java.io.IOException;
import javax.swing.*;

/** General Screen: focused feature implementation. */
final class GeneralScreen {
  private final hGui app;

  GeneralScreen(hGui app) {
    this.app = app;
  }

  void refreshGeneralTab() {

    JPanel genPanel = app.generalTabPanel;
    genPanel.removeAll();
    genPanel.setLayout(new BorderLayout());

    genPanel.setBackground(Theme.BG_DARK);

    JLabel title = new JLabel("General", SwingConstants.CENTER);
    title.setFont(new Font("Consolas", Font.BOLD, 22));
    title.setForeground(Theme.ACCENT_T);
    title.setBorder(BorderFactory.createEmptyBorder(20, 0, 20, 0));
    genPanel.add(title, BorderLayout.NORTH);

    JPanel btnGrid = new JPanel(new GridLayout(0, 2, 16, 16));
    btnGrid.setBackground(Theme.BG_DARK);
    btnGrid.setBorder(BorderFactory.createEmptyBorder(20, 60, 20, 60));

    String[][] btnDefs = {
      {"TRADES", "View & manage incoming trade offers"},
      {"COLLECTION", "Track all case, Armoury and agent unlocks"},
      {"ACHIEVEMENTS", "Track your achievements"},
      {"STATS", "Opening statistics including Armoury redeems"},
      {"ROI STATS", "Return on investment by case type"},
      {"MISSIONS", "Complete missions to earn Stars"},
    };

    JButton[] btns = {
      app.tradesButton,
      app.collectionButton,
      app.achievementsButton,
      app.statsButton,
      app.roiButton,
      app.missionsButton
    };

    for (int i = 0; i < btnDefs.length; i++) {
      final int idx2 = i;

      JButton card = new JButton();
      card.setLayout(new BorderLayout(4, 6));
      card.setBackground(Theme.BG_CARD);
      card.setFocusPainted(false);
      card.setBorderPainted(true);
      card.setOpaque(true);
      card.setCursor(new Cursor(Cursor.HAND_CURSOR));
      card.setBorder(
          BorderFactory.createCompoundBorder(
              BorderFactory.createLineBorder(Theme.BORDER, 1),
              BorderFactory.createEmptyBorder(18, 20, 18, 20)));
      card.addActionListener(btns[idx2].getActionListeners()[0]);
      card.setActionCommand(
          btns[idx2].getActionCommand() != null ? btns[idx2].getActionCommand() : btnDefs[idx2][0]);
      card.addMouseListener(
          new MouseAdapter() {
            Color orig = Theme.BG_CARD;

            public void mouseEntered(MouseEvent e) {
              card.setBackground(orig.brighter());
            }

            public void mouseExited(MouseEvent e) {
              card.setBackground(orig);
            }
          });

      JLabel title2 = new JLabel(btnDefs[idx2][0], SwingConstants.LEFT);
      title2.setFont(Theme.CONSOLE_BOLD_14);
      title2.setForeground(Theme.ACCENT_CT);
      title2.setOpaque(false);

      JLabel desc = new JLabel(btnDefs[idx2][1], SwingConstants.LEFT);
      desc.setFont(new Font("Consolas", Font.PLAIN, 11));
      desc.setForeground(Theme.TEXT_DIM);
      desc.setOpaque(false);

      card.add(title2, BorderLayout.CENTER);
      card.add(desc, BorderLayout.SOUTH);
      btnGrid.add(card);
    }

    genPanel.add(btnGrid, BorderLayout.CENTER);
    genPanel.revalidate();
    genPanel.repaint();
  }

  public void actionPerformed(ActionEvent e) {
    String cmd = e.getActionCommand();
    if (cmd.equals("OPEN")) {
      if (!app.isAnimating) {
        app.caseOpeningScreen.openCrateWithAnimation();
      }
    } else if (cmd.equals("CLOSE")) {
      app.floatRules.resetCrate();
    } else if (cmd.equals("AUTO")) {
      app.containerBrowserScreen
          .stopAutoOpen(); // Auto-open removed: every opening is an explicit owned-item action.
    } else if (e.getActionCommand().equals("TRADES")) {
      app.tradeHubScreen.showTradesWindow();
    } else if (e.getActionCommand().equals("COLLECTION")) {
      app.collectionScreen.showCollectionWindow();
    } else if (e.getActionCommand().equals("ACHIEVEMENTS")) {
      app.achievementScreen.showAchievementsWindow();
    } else if (e.getActionCommand().equals("STATS")) {
      app.statisticsAndAchievements.showStatsWindow();
    } else if (e.getSource() == app.saveButton) {
      app.saveService.saveProgress();
      JOptionPane.showMessageDialog(
          app, "Game saved successfully!", "Save Complete", JOptionPane.INFORMATION_MESSAGE);
    } else if (e.getSource() == app.loadButton) {
      int confirm =
          JOptionPane.showConfirmDialog(
              app,
              "Load saved game? Current progress will be lost if not saved.",
              "Confirm Load",
              JOptionPane.YES_NO_OPTION);
      if (confirm == JOptionPane.YES_OPTION) {
        try {
          app.saveService.loadProgress();
        } catch (IOException e1) {
          e1.printStackTrace();
        }
        JOptionPane.showMessageDialog(
            app, "Game loaded successfully!", "Load Complete", JOptionPane.INFORMATION_MESSAGE);
      }
    } else if (cmd.equals("SELECT CASE")) {
      app.searchControls.showCaseSelection();
    } else if (e.getActionCommand().equals("LEADERBOARD")) {
      app.leaderboardScreen.showLeaderboard();
    } else if (e.getActionCommand().equals("ROI")) {
      app.roiScreen.showROIWindow();
    } else if (e.getActionCommand().equals("MISSIONS")) {
      app.missionScreen.showMissionsWindow();
    } else if (e.getActionCommand().equals("ARMOURY_TAB")) {
      if (app.cs2ShellEnabled) app.storeScreen.open("ARMOURY");
      else app.mainTabs.setSelectedIndex(1);
    } else if (e.getActionCommand().equals("ARMOURY_ODDS")) {
      app.oddsAndChecklistScreen.showArmouryOddsWindow();
    } else if (e.getActionCommand().equals("COLLECTION_CHECKLIST")) {
      app.oddsAndChecklistScreen.showCollectionChecklistHelper();
    } else if (e.getActionCommand().equals("IMAGE_VERIFIER")) {
      app.oddsAndChecklistScreen.showSkinImageVerifier();
    }
  }
}
