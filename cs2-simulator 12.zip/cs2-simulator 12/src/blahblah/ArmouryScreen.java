package blahblah;

import blahblah.hGui.*;
import java.awt.*;
import java.awt.event.*;
import javax.swing.*;

/** Armoury Screen: focused feature implementation. */
final class ArmouryScreen {
  private final hGui app;

  ArmouryScreen(hGui app) {
    this.app = app;
  }

  void refreshArmouryTab() {
    if (app.cs2ShellEnabled && app.storeScreen.sections != null) {
      app.storeScreen.armouryHome();
      return;
    }
    app.armouryTabPanel.removeAll();

    app.armouryTabPanel.setBackground(Theme.BG_DARK);
    app.armouryTabPanel.setLayout(new BorderLayout());

    JPanel topBar = new JPanel(new BorderLayout());
    topBar.setBackground(Theme.BG_PANEL);
    topBar.setBorder(
        BorderFactory.createCompoundBorder(
            BorderFactory.createMatteBorder(0, 0, 2, 0, Theme.ACCENT_T),
            BorderFactory.createEmptyBorder(10, 16, 10, 16)));

    JLabel titleLbl = new JLabel("ARMOURY", SwingConstants.LEFT);
    titleLbl.setFont(new Font("Consolas", Font.BOLD, 20));
    titleLbl.setForeground(Theme.ACCENT_T);

    JPanel rightBar = new JPanel(new FlowLayout(FlowLayout.RIGHT, 14, 0));
    rightBar.setBackground(Theme.BG_PANEL);
    app.armouryStarsDisp = new JLabel("* " + app.playerStars + " Stars", SwingConstants.RIGHT);
    JLabel starsDisp = app.armouryStarsDisp;
    starsDisp.setFont(new Font("Consolas", Font.BOLD, 16));
    starsDisp.setForeground(Theme.GOLD);
    rightBar.add(starsDisp);

    topBar.add(titleLbl, BorderLayout.WEST);
    topBar.add(rightBar, BorderLayout.EAST);
    app.armouryTabPanel.add(topBar, BorderLayout.NORTH);

    JTabbedPane collectionTabs = new JTabbedPane();
    collectionTabs.setBackground(Theme.BG_DARK);
    collectionTabs.setForeground(Theme.TEXT);
    collectionTabs.setFont(new Font("Consolas", Font.BOLD, 13));
    // Wrapped tabs make every collection directly reachable and avoid the
    // unreliable scroll-arrow controls entirely.
    collectionTabs.setTabLayoutPolicy(JTabbedPane.WRAP_TAB_LAYOUT);

    for (ArmouryCollection col : hGui.ARMOURY_COLLECTIONS) {
      JPanel colPage =
          app.armouryScreen.buildCollectionPage(
              col,
              starsDisp,
              Theme.BG_DARK,
              Theme.BG_CARD,
              Theme.BG_PANEL,
              Theme.ACCENT_T,
              Theme.TEXT,
              Theme.TEXT_DIM,
              Theme.GOLD);
      collectionTabs.addTab(col.name, colPage);
    }

    if (app.lastArmouryTabIndex < collectionTabs.getTabCount())
      collectionTabs.setSelectedIndex(app.lastArmouryTabIndex);
    collectionTabs.addChangeListener(
        e -> app.lastArmouryTabIndex = collectionTabs.getSelectedIndex());

    app.armouryTabPanel.add(collectionTabs, BorderLayout.CENTER);
    app.armouryTabPanel.revalidate();
    app.armouryTabPanel.repaint();
  }

  JPanel buildCollectionPage(
      ArmouryCollection col,
      JLabel starsDisplay,
      Color BG_DARK,
      Color BG_CARD,
      Color BG_PANEL,
      Color ACCENT,
      Color TEXT_MAIN,
      Color TEXT_DIM,
      Color GOLD) {

    JPanel page = new JPanel(new BorderLayout(0, 0));
    page.setBackground(Theme.BG_DARK);

    Object[][] tiers = {
      {"Covert", col.covert, col.covertNames, col.covertPrices, new Color(235, 75, 75)},
      {
        "Classified",
        col.classified,
        col.classifiedNames,
        col.classifiedPrices,
        new Color(211, 44, 230)
      },
      {
        "Restricted",
        col.restricted,
        col.restrictedNames,
        col.restrictedPrices,
        new Color(136, 71, 255)
      },
      {"Milspec", col.milspec, col.milspecNames, col.milspecPrices, new Color(75, 105, 255)},
      {
        "Industrial",
        col.industrial,
        col.industrialNames,
        col.industrialPrices,
        new Color(110, 190, 110)
      },
      {"Consumer", col.consumer, col.consumerNames, col.consumerPrices, new Color(175, 175, 175)},
    };

    if (col.isAgents) {
      tiers[0][0] = "Master";
      tiers[1][0] = "Superior";
      tiers[2][0] = "Exceptional";
      tiers[3][0] = "Distinguished";
    }

    int totalSkins = 0;
    for (Object[] t : tiers) {
      String[] files = (String[]) t[1];
      if (files != null) totalSkins += files.length;
    }

    int cols = 3;
    int rows = (int) Math.ceil((double) totalSkins / cols);
    JPanel grid = new JPanel(new GridLayout(rows, cols, 10, 10));
    grid.setBackground(Theme.BG_DARK);
    grid.setBorder(BorderFactory.createEmptyBorder(14, 14, 14, 14));

    for (Object[] tier : tiers) {
      String tierKey = (String) tier[0];
      String[] files = (String[]) tier[1];
      String[] names = (String[]) tier[2];
      Color tierColor = (Color) tier[4];

      if (files == null || files.length == 0) continue;

      for (int si = 0; si < files.length; si++) {
        final String file = files[si] + ".png";
        final String skinName = names[si];
        final Color tColor = tierColor;

        JPanel card = new JPanel(new BorderLayout(0, 0));
        card.setBackground(Theme.BG_CARD);
        card.setBorder(
            BorderFactory.createCompoundBorder(
                BorderFactory.createLineBorder(tColor, 2),
                BorderFactory.createEmptyBorder(6, 6, 6, 6)));

        JLabel imgLbl = new JLabel("", SwingConstants.CENTER);
        Image skinImg = app.artworkService.getSkinImageFromName(skinName);
        if (skinImg != null) {
          imgLbl.setIcon(new ImageIcon(HighQualityImages.fit(skinImg, 180, 125)));
        } else {
          app.artworkService.getSkinImageFromName(skinName, imgLbl, 180, 125);
        }
        imgLbl.setHorizontalAlignment(SwingConstants.CENTER);
        card.add(imgLbl, BorderLayout.CENTER);

        JPanel infoPanel = new JPanel(new GridLayout(2, 1, 0, 2));
        infoPanel.setBackground(Theme.BG_CARD);
        infoPanel.setBorder(BorderFactory.createEmptyBorder(4, 0, 0, 0));

        JLabel nameLbl =
            new JLabel(
                "<html><div style='text-align:center;width:168px;'>" + skinName + "</div></html>",
                SwingConstants.CENTER);
        nameLbl.setFont(new Font("Consolas", Font.BOLD, skinName.length() > 24 ? 9 : 10));
        nameLbl.setForeground(Theme.TEXT);
        nameLbl.setToolTipText(skinName);

        JLabel rarLbl = new JLabel(tierKey, SwingConstants.CENTER);
        rarLbl.setFont(new Font("Consolas", Font.BOLD, 9));
        rarLbl.setForeground(tColor);

        infoPanel.add(nameLbl);
        infoPanel.add(rarLbl);
        card.add(infoPanel, BorderLayout.SOUTH);

        card.addMouseListener(
            new MouseAdapter() {
              public void mouseEntered(MouseEvent e) {
                card.setBackground(new Color(38, 38, 56));
                infoPanel.setBackground(new Color(38, 38, 56));
              }

              public void mouseExited(MouseEvent e) {
                card.setBackground(Theme.BG_CARD);
                infoPanel.setBackground(Theme.BG_CARD);
              }
            });

        grid.add(card);
      }
    }

    int remainder = totalSkins % cols;
    if (remainder != 0) {
      for (int i = 0; i < (cols - remainder); i++) {
        JPanel blank = new JPanel();
        blank.setBackground(Theme.BG_DARK);
        grid.add(blank);
      }
    }

    JScrollPane gridScroll = new JScrollPane(grid);
    gridScroll.setBorder(null);
    gridScroll.getVerticalScrollBar().setUnitIncrement(20);
    gridScroll.setHorizontalScrollBarPolicy(ScrollPaneConstants.HORIZONTAL_SCROLLBAR_NEVER);
    gridScroll.setBackground(Theme.BG_DARK);
    gridScroll.getViewport().setBackground(Theme.BG_DARK);
    page.add(gridScroll, BorderLayout.CENTER);

    JPanel bottomBar = new JPanel(new FlowLayout(FlowLayout.CENTER, 12, 10));
    bottomBar.setBackground(Theme.BG_PANEL);
    bottomBar.setBorder(BorderFactory.createMatteBorder(2, 0, 0, 0, Theme.ACCENT_T));

    int redeemCost = app.itemMetadataService.getArmouryRedeemCost(col);
    JButton redeemBtn = new JButton("REDEEM - " + redeemCost + " Stars");
    redeemBtn.setFont(new Font("Consolas", Font.BOLD, 14));
    redeemBtn.setBackground(new Color(30, 60, 30));
    redeemBtn.setForeground(Theme.GOLD);
    redeemBtn.setFocusPainted(false);
    redeemBtn.setOpaque(true);
    redeemBtn.setCursor(new Cursor(Cursor.HAND_CURSOR));
    redeemBtn.setBorder(
        BorderFactory.createCompoundBorder(
            BorderFactory.createLineBorder(Theme.GOLD, 2),
            BorderFactory.createEmptyBorder(8, 24, 8, 24)));
    redeemBtn.addActionListener(
        ev -> app.armouryRedeemService.attemptArmouryRedeem(col, starsDisplay, redeemBtn, false));

    JButton autoArmouryBtn = new JButton("AUTO OPEN");
    autoArmouryBtn.setFont(new Font("Consolas", Font.BOLD, 14));
    app.uiWidgets.styleButton(autoArmouryBtn, Theme.BG_CARD, Theme.ACCENT_CT, Theme.BORDER);
    autoArmouryBtn.setCursor(new Cursor(Cursor.HAND_CURSOR));
    if (app.armouryAutoTimer != null && app.armouryAutoTimer.isRunning()) {
      autoArmouryBtn.setText("STOP OPEN");
      if (app.activeArmouryAutoCollection == col) {
        app.armouryAutoButton = autoArmouryBtn;
        app.activeArmouryStarsDisplay = starsDisplay;
      }
    }
    autoArmouryBtn.addActionListener(
        ev -> {
          if (app.cs2ShellEnabled) return;
          if (app.armouryAutoTimer != null && app.armouryAutoTimer.isRunning()) {
            app.containerBrowserScreen.stopArmouryAutoOpen();
            autoArmouryBtn.setText("STOPPED");
            autoArmouryBtn.setEnabled(false);
            javax.swing.Timer resetText =
                new javax.swing.Timer(
                    700,
                    resetEvt -> {
                      autoArmouryBtn.setText("AUTO OPEN");
                      autoArmouryBtn.setEnabled(true);
                    });
            resetText.setRepeats(false);
            resetText.start();
            return;
          }
          app.activeArmouryAutoCollection = col;
          app.activeArmouryStarsDisplay = starsDisplay;
          app.armouryAutoButton = autoArmouryBtn;
          autoArmouryBtn.setText("STOP OPEN");
          app.armouryAutoTimer =
              new javax.swing.Timer(
                  250,
                  tick -> {
                    if (app.armouryAutoTimer == null || !app.armouryAutoTimer.isRunning()) return;
                    if (app.armouryAnimating) return;
                    if (app.playerStars
                        < app.itemMetadataService.getArmouryRedeemCost(
                            app.activeArmouryAutoCollection)) {
                      app.containerBrowserScreen.stopArmouryAutoOpen();
                      return;
                    }
                    app.armouryRedeemService.attemptArmouryRedeem(
                        app.activeArmouryAutoCollection, app.activeArmouryStarsDisplay, null, true);
                  });
          app.armouryAutoTimer.setRepeats(true);
          app.armouryAutoTimer.start();
          app.armouryAutoTimer.getActionListeners()[0].actionPerformed(
              new ActionEvent(
                  app.armouryAutoTimer, ActionEvent.ACTION_PERFORMED, "ARMOURY_AUTO_TICK"));
        });

    bottomBar.add(redeemBtn);
    if (!app.cs2ShellEnabled) bottomBar.add(autoArmouryBtn);
    page.add(bottomBar, BorderLayout.SOUTH);

    return page;
  }
}
