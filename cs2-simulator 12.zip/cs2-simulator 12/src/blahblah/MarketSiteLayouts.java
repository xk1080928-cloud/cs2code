package blahblah;

import java.awt.*;
import javax.swing.*;

/** Real per-brand page compositions. Controls share behavior, not a common recolored page tree. */
final class MarketSiteLayouts {
  private final hGui app;

  MarketSiteLayouts(hGui app) {
    this.app = app;
  }

  private JPanel panel(MarketplaceProfile p, LayoutManager layout) {
    return app.exchangeWidgets.exchangePanel(p, layout);
  }

  private JPanel column(MarketplaceProfile p, Component... children) {
    JPanel box = panel(p, new BorderLayout(0, 12));
    if (children.length > 0) box.add(children[0], BorderLayout.NORTH);
    if (children.length > 1) box.add(children[1], BorderLayout.CENTER);
    if (children.length > 2) box.add(children[2], BorderLayout.SOUTH);
    return box;
  }

  private JLabel title(MarketplaceProfile p, String text, int size) {
    JLabel label =
        app.exchangeWidgets.exchangeLabel(text, size, app.exchangeWidgets.exchangeAccent(p));
    label.setBorder(BorderFactory.createEmptyBorder(8, 10, 8, 10));
    return label;
  }

  private JPanel horizontal(MarketplaceProfile p, JComponent controls, boolean sell) {
    controls.setPreferredSize(null);
    for (Component c : controls.getComponents()) if (c instanceof Box.Filler) controls.remove(c);
    controls.setLayout(new GridLayout(sell ? 1 : 2, sell ? 2 : 0, 12, 8));
    controls.setBorder(BorderFactory.createEmptyBorder(12, 12, 12, 12));
    JPanel wrap = panel(p, new BorderLayout());
    wrap.add(controls);
    wrap.setPreferredSize(new Dimension(0, sell ? 250 : 130));
    return wrap;
  }

  private JComponent split(
      MarketplaceProfile p, JComponent a, JComponent b, double ratio, boolean vertical) {
    JSplitPane pane =
        new JSplitPane(vertical ? JSplitPane.VERTICAL_SPLIT : JSplitPane.HORIZONTAL_SPLIT, a, b);
    pane.setBorder(null);
    pane.setContinuousLayout(true);
    pane.setDividerSize(6);
    pane.setResizeWeight(ratio);
    SwingUtilities.invokeLater(
        () -> {
          if (pane.isDisplayable()) pane.setDividerLocation(ratio);
        });
    return pane;
  }

  void compose(
      MarketplaceProfile p,
      JPanel root,
      JComponent search,
      JComponent body,
      JComponent controls,
      JComponent paging,
      String mode) {
    int style = app.exchangeTransactionService.exchangeStyle(p);
    boolean sell = mode.equals("Sell");
    root.removeAll();
    root.setLayout(new BorderLayout(16, 14));
    root.putClientProperty("siteLayout", p.name + "/" + mode);
    root.setBorder(BorderFactory.createEmptyBorder(16, 20, 16, 20));
    String suffix = sell ? "YOUR SELLING DESK" : "AVAILABLE INVENTORY";
    switch (style) {
      case 0: // CS.MONEY: reference-inspired broad toolbar and uninterrupted offer wall.
        root.add(column(p, search, horizontal(p, controls, sell)), BorderLayout.NORTH);
        root.add(body);
        root.add(paging, BorderLayout.SOUTH);
        break;
      case 1: // SkinSwap: peer desk, slim tool column, prominent trade notice above offers.
        JPanel peer = column(p, title(p, "PEER DESK / " + suffix, 17), search);
        root.add(peer, BorderLayout.NORTH);
        controls.setPreferredSize(new Dimension(sell ? 285 : 180, 0));
        root.add(controls, BorderLayout.WEST);
        root.add(
            column(p, title(p, "Select a stack to compare individual offers", 12), body, paging));
        break;
      case 2: // DMarket: resizable trading floor and a right-hand inspector.
        root.add(column(p, title(p, "DMARKET / TRADING FLOOR", 18), search), BorderLayout.NORTH);
        root.add(split(p, body, controls, .78, false));
        root.add(column(p, title(p, "CATALOG / USD", 12), paging), BorderLayout.SOUTH);
        break;
      case 3: // LIS-SKINS: transaction ticket on the left; no full-width search strip.
        JPanel ticket =
            column(
                p, title(p, "LIS / " + (sell ? "CASH OUT" : "QUICK FIND"), 22), controls, search);
        ticket.setPreferredSize(new Dimension(sell ? 300 : 235, 0));
        root.add(ticket, BorderLayout.WEST);
        root.add(
            column(
                p, title(p, "01 — SELECT   /   02 — REVIEW   /   03 — CONFIRM", 13), body, paging));
        break;
      case 4: // Skins.com: shop ribbon above a gallery, controls docked below it.
        root.add(
            column(p, title(p, "THE ARMORY / FIND YOUR PLAYSTYLE", 22), search),
            BorderLayout.NORTH);
        root.add(body);
        root.add(column(p, horizontal(p, controls, sell), paging), BorderLayout.SOUTH);
        break;
      case 5: // Skin.Land: horizontal route planner with an editorial side flag.
        root.add(column(p, search, horizontal(p, controls, sell)), BorderLayout.NORTH);
        JPanel land =
            column(p, title(p, "SKIN.LAND", 20), title(p, sell ? "SELL ROUTE" : "BUY ROUTE", 13));
        land.setPreferredSize(new Dimension(155, 0));
        root.add(land, BorderLayout.EAST);
        root.add(body);
        root.add(paging, BorderLayout.SOUTH);
        break;
      case 6: // TradeDock: manifest workspace with search in the bottom dock.
        root.add(title(p, "TRADEDOCK / CARGO MANIFEST / " + suffix, 20), BorderLayout.NORTH);
        root.add(split(p, controls, body, .20, false));
        root.add(column(p, search, paging), BorderLayout.SOUTH);
        break;
      case 7: // VaultDrop: collection gate with a collapsible tools drawer.
        root.add(column(p, title(p, "VAULT OPEN / " + suffix, 24), search), BorderLayout.NORTH);
        root.add(body);
        JPanel drawer = horizontal(p, controls, sell);
        drawer.setName("vaultToolsDrawer");
        JToggleButton gate = new JToggleButton("VAULT TOOLS ▾", true);
        gate.setForeground(Color.WHITE);
        gate.setBackground(app.exchangeWidgets.exchangeAccent(p).darker());
        gate.addActionListener(
            e -> {
              drawer.setVisible(gate.isSelected());
              root.revalidate();
            });
        root.add(column(p, gate, drawer, paging), BorderLayout.SOUTH);
        break;
      case 8: // Skinport: its classic left filter column, clean top search and bottom paging.
        root.add(search, BorderLayout.NORTH);
        root.add(controls, BorderLayout.WEST);
        root.add(body);
        root.add(paging, BorderLayout.SOUTH);
        break;
      case 9: // Waxpeer: order-book desk, split tools and results, footer search.
        root.add(column(p, title(p, "WAXPEER / PEER OFFER BOOK", 20), paging), BorderLayout.NORTH);
        JPanel book = column(p, title(p, "FILTER THE BOOK", 12), controls);
        book.setPreferredSize(new Dimension(sell ? 300 : 225, 0));
        root.add(split(p, book, body, .22, false));
        root.add(search, BorderLayout.SOUTH);
        break;
      case 10: // FloatFlip: precision instruments over the board; search at its foot.
        root.add(
            column(
                p,
                title(p, "FLOATFLIP / EVERY DECIMAL MATTERS", 23),
                horizontal(p, controls, sell)),
            BorderLayout.NORTH);
        root.add(body);
        root.add(column(p, search, paging), BorderLayout.SOUTH);
        break;
      case 11: // Halo: concierge column, gallery center and an independent action rail.
        JPanel concierge =
            column(p, title(p, "YOUR CONCIERGE", 19), search, title(p, "COLLECT WITH INTENT", 11));
        concierge.setPreferredSize(new Dimension(225, 0));
        root.add(concierge, BorderLayout.WEST);
        root.add(column(p, title(p, suffix, 19), body, paging));
        root.add(controls, BorderLayout.EAST);
        break;
      case 12: // NeonGrid: console top command line and bottom instrument dock.
        root.add(
            column(p, title(p, "NEONGRID // INPUT > " + suffix, 19), search), BorderLayout.NORTH);
        root.add(body);
        JPanel instruments = horizontal(p, controls, sell);
        instruments.setBorder(
            BorderFactory.createMatteBorder(2, 0, 0, 0, app.exchangeWidgets.exchangeAccent(p)));
        root.add(column(p, paging, instruments), BorderLayout.SOUTH);
        break;
      case 13: // MirageX: wide editorial mast, side-by-side search and tools over the gallery.
        JPanel editorial = panel(p, new BorderLayout(22, 0));
        JPanel query = panel(p, new BorderLayout());
        query.add(search, BorderLayout.NORTH);
        editorial.add(column(p, title(p, "THE MIRAGE EDIT", 25), query));
        controls.setPreferredSize(new Dimension(sell ? 350 : 245, sell ? 330 : 370));
        editorial.add(controls, BorderLayout.EAST);
        root.add(split(p, editorial, body, .37, true));
        root.add(paging, BorderLayout.SOUTH);
        break;
      case 14: // Ember: hot-drop board with an inset search and right transaction tower.
        JPanel hot = column(p, title(p, "EMBER / BRING THE HEAT", 25), search);
        root.add(hot, BorderLayout.NORTH);
        root.add(column(p, title(p, suffix, 13), body, paging));
        root.add(column(p, title(p, "YOUR NEXT MOVE", 16), controls), BorderLayout.EAST);
        break;
      case 15: // FrostBid: a vertically resizable precision workbench, not a sidebar store.
        root.add(search, BorderLayout.NORTH);
        JComponent frostDock =
            column(p, title(p, "FROST / PRECISION CONTROLS", 17), horizontal(p, controls, sell));
        root.add(split(p, body, frostDock, .74, true));
        root.add(paging, BorderLayout.SOUTH);
        break;
      case 16: // Relay: terminal status and page stepper at top, left command rail, query bottom.
        root.add(
            column(p, title(p, "RELAY // INVENTORY CHANNEL / " + suffix, 18), paging),
            BorderLayout.NORTH);
        root.add(column(p, title(p, "CHANNEL CONTROLS", 12), controls), BorderLayout.WEST);
        root.add(body);
        root.add(search, BorderLayout.SOUTH);
        break;
      case 17: // Velvet: framed collection spread and a lower editorial selling/filter desk.
        JPanel velvet = panel(p, new BorderLayout(18, 0));
        velvet.add(title(p, "THE VELVET COLLECTION", 24), BorderLayout.WEST);
        velvet.add(search);
        root.add(velvet, BorderLayout.NORTH);
        body.setBorder(
            BorderFactory.createCompoundBorder(
                BorderFactory.createMatteBorder(1, 0, 1, 0, app.exchangeWidgets.exchangeAccent(p)),
                BorderFactory.createEmptyBorder(12, 0, 12, 0)));
        root.add(body);
        root.add(column(p, horizontal(p, controls, sell), paging), BorderLayout.SOUTH);
        break;
      default:
        throw new IllegalArgumentException("Unknown marketplace");
    }
  }

  void navigation(MarketplaceProfile p, JTabbedPane tabs) {
    switch (app.exchangeTransactionService.exchangeStyle(p)) {
      case 2:
      case 6:
      case 9:
      case 12:
      case 16:
        tabs.setTabPlacement(JTabbedPane.LEFT);
        break;
      case 7:
      case 11:
        tabs.setTabPlacement(JTabbedPane.RIGHT);
        break;
      case 10:
      case 17:
        tabs.setTabPlacement(JTabbedPane.BOTTOM);
        break;
      default:
        tabs.setTabPlacement(JTabbedPane.TOP);
    }
  }

  void swap(MarketplaceProfile p, JPanel root, JPanel left, JPanel right, JPanel summary) {
    root.removeAll();
    root.setLayout(new BorderLayout(18, 14));
    root.putClientProperty("siteLayout", p.name + "/Swap");
    int style = app.exchangeTransactionService.exchangeStyle(p);
    switch (style) {
      case 1:
        root.add(title(p, "SKINSWAP / YOUR OFFER ↔ YOUR NEXT LOADOUT", 19), BorderLayout.NORTH);
        root.add(split(p, left, right, .5, false));
        root.add(summary, BorderLayout.SOUTH);
        break;
      case 5:
        JPanel route = column(p, title(p, "SKIN.LAND / PLAN YOUR UPGRADE", 22), summary);
        root.add(route, BorderLayout.NORTH);
        root.add(split(p, left, right, .43, false));
        break;
      case 12:
        root.add(
            column(p, title(p, "NEONGRID // EXCHANGE CONSOLE", 21), summary), BorderLayout.NORTH);
        JPanel consoles = panel(p, new GridLayout(1, 2, 6, 0));
        consoles.add(left);
        consoles.add(right);
        root.add(consoles);
        root.add(
            title(p, "LEFT: SOURCE INVENTORY  //  RIGHT: DESTINATION INVENTORY", 12),
            BorderLayout.SOUTH);
        break;
      case 16:
        root.add(title(p, "RELAY // INITIATE INVENTORY TRANSFER", 19), BorderLayout.NORTH);
        JPanel relay = panel(p, new GridBagLayout());
        GridBagConstraints c = new GridBagConstraints();
        c.gridy = 0;
        c.weighty = 1;
        c.fill = GridBagConstraints.BOTH;
        c.weightx = 1;
        c.gridx = 0;
        relay.add(left, c);
        c.gridx = 1;
        c.weightx = 0;
        relay.add(title(p, "→", 30), c);
        c.gridx = 2;
        c.weightx = 1;
        relay.add(right, c);
        root.add(relay);
        root.add(summary, BorderLayout.SOUTH);
        break;
      case 17:
        root.add(
            column(p, title(p, "VELVET / THE PRIVATE TRADE ROOM", 25), summary),
            BorderLayout.NORTH);
        root.add(split(p, left, right, .56, false));
        root.add(title(p, "Your collection, thoughtfully exchanged.", 13), BorderLayout.SOUTH);
        break;
      default:
        throw new IllegalArgumentException("This marketplace does not support swaps.");
    }
  }
}
