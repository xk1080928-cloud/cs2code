package blahblah;

import blahblah.hGui.*;
import java.awt.*;
import java.awt.event.*;
import java.util.ArrayList;
import java.util.Comparator;
import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.Map;
import java.util.stream.Collectors;
import javax.swing.*;

/** Market History Screen: focused feature implementation. */
final class MarketHistoryScreen {
  private final hGui app;

  MarketHistoryScreen(hGui app) {
    this.app = app;
  }

  LinkedHashMap<String, ArrayList<MarketListing>> buildConditionTokenMap(
      ArrayList<MarketListing> listings, String skinName) {
    LinkedHashMap<String, ArrayList<MarketListing>> map = new LinkedHashMap<>();
    String[] baseConditions = app.floatRules.getAvailableConditions(skinName);
    for (String condition : baseConditions) {
      ArrayList<MarketListing> base =
          listings.stream()
              .filter(l -> !l.item.isStattrak && condition.equals(l.item.condition))
              .collect(Collectors.toCollection(ArrayList::new));
      if (!base.isEmpty()) map.put(condition, base);
    }
    for (String condition : baseConditions) {
      ArrayList<MarketListing> statTrak =
          listings.stream()
              .filter(l -> l.item.isStattrak && condition.equals(l.item.condition))
              .collect(Collectors.toCollection(ArrayList::new));
      if (!statTrak.isEmpty()) map.put("StatTrak " + condition, statTrak);
    }
    if (map.isEmpty() && !listings.isEmpty()) {
      map.put("Listings", new ArrayList<>(listings));
    }
    return map;
  }

  String getPriceHistoryCondition(String conditionToken) {
    if (conditionToken == null) return "Any";
    return conditionToken.replace("StatTrak ", "").trim();
  }

  boolean saleMatchesSkinView(
      SaleRecord sale, String skinName, String selectedVariant, String selectedCondition) {
    if (sale == null || sale.skinName == null) return false;
    String viewKey = app.marketGroupingService.getMarketplaceBrowseKey(skinName);
    if (!viewKey.equals(app.marketGroupingService.getMarketplaceBrowseKey(sale.skinName)))
      return false;
    if ("StatTrak Only".equals(selectedVariant) && !sale.skinName.startsWith("StatTrak "))
      return false;
    if ("Non-StatTrak Only".equals(selectedVariant) && sale.skinName.startsWith("StatTrak "))
      return false;
    return "All Conditions".equals(selectedCondition) || selectedCondition.equals(sale.condition);
  }

  ArrayList<SaleRecord> getRecordedSalesForSkinView(
      String skinName, String selectedVariant, String selectedCondition) {
    ArrayList<SaleRecord> matchingSales = new ArrayList<>();
    java.util.Set<String> seen = new java.util.HashSet<>();
    for (Map.Entry<String, Map<String, ArrayList<SaleRecord>>> entry :
        new HashMap<>(app.salesHistory).entrySet()) {
      if (!app.marketGroupingService
          .getMarketplaceBrowseKey(skinName)
          .equals(app.marketGroupingService.getMarketplaceBrowseKey(entry.getKey()))) continue;
      Map<String, ArrayList<SaleRecord>> byCondition = entry.getValue();
      if (byCondition == null) continue;
      for (ArrayList<SaleRecord> sales : new ArrayList<>(byCondition.values())) {
        for (SaleRecord sale : new ArrayList<>(sales)) {
          if (!app.marketHistoryScreen.saleMatchesSkinView(
              sale, skinName, selectedVariant, selectedCondition)) continue;
          String key =
              sale.skinName
                  + "|"
                  + sale.condition
                  + "|"
                  + String.format("%.4f", sale.price)
                  + "|"
                  + String.format("%.6f", sale.itemFloat)
                  + "|"
                  + sale.timestamp
                  + "|"
                  + sale.marketplaceName;
          if (seen.add(key)) matchingSales.add(sale);
        }
      }
    }
    matchingSales.addAll(
        app.salesSimulationService.getSimulatedSalesForSkinView(
            skinName, selectedVariant, selectedCondition));
    matchingSales.sort((a, b) -> Long.compare(b.timestamp, a.timestamp));
    return matchingSales;
  }

  ArrayList<SaleRecord> getRecentSalesForGraph(String skinName, String conditionToken) {
    String condition = app.marketHistoryScreen.getPriceHistoryCondition(conditionToken);
    String variant =
        conditionToken != null && conditionToken.startsWith("StatTrak ")
            ? "StatTrak Only"
            : "Non-StatTrak Only";
    ArrayList<SaleRecord> matchingSales =
        app.marketHistoryScreen.getRecordedSalesForSkinView(skinName, variant, condition);
    matchingSales.sort(Comparator.comparingLong(s -> s.timestamp));
    return matchingSales;
  }

  ArrayList<PriceHistoryPoint> getMarketplacePriceHistoryPointData(
      String skinName, String conditionToken, ArrayList<MarketListing> listings) {
    // Aggregate BEFORE retaining the last 60 buckets: every retained sale contributes quantity.
    java.util.SortedMap<Long, double[]> buckets = new java.util.TreeMap<>();
    for (SaleRecord sale : getRecentSalesForGraph(skinName, conditionToken)) {
      if (!Double.isFinite(sale.price) || sale.price <= 0) continue;
      long time = Math.floorDiv(sale.timestamp, 5000) * 5000;
      double[] bucket = buckets.computeIfAbsent(time, k -> new double[2]);
      bucket[0] += sale.price;
      bucket[1]++;
    }
    ArrayList<PriceHistoryPoint> result = new ArrayList<>();
    for (Map.Entry<Long, double[]> entry : buckets.entrySet()) {
      double[] bucket = entry.getValue();
      result.add(new PriceHistoryPoint(bucket[0] / bucket[1], (int) bucket[1], entry.getKey()));
    }
    if (result.size() > 60) result.subList(0, result.size() - 60).clear();
    return result;
  }

  JPanel createMarketplacePriceHistoryPanel(
      String skinName, String conditionToken, ArrayList<MarketListing> listings) {
    ArrayList<PriceHistoryPoint> points =
        app.marketHistoryScreen.getMarketplacePriceHistoryPointData(
            skinName, conditionToken, listings);
    JPanel wrapper = new JPanel(new BorderLayout(0, 8));
    wrapper.setBackground(new Color(24, 30, 42));
    wrapper.setBorder(
        BorderFactory.createCompoundBorder(
            BorderFactory.createLineBorder(new Color(70, 90, 120), 1),
            BorderFactory.createEmptyBorder(12, 14, 12, 14)));
    wrapper.setAlignmentX(Component.LEFT_ALIGNMENT);
    wrapper.setPreferredSize(new Dimension(0, 230));
    wrapper.setMaximumSize(new Dimension(Integer.MAX_VALUE, 230));

    JPanel header = new JPanel(new BorderLayout());
    header.setOpaque(false);
    JLabel title = new JLabel("Price History");
    title.setFont(new Font("Arial", Font.BOLD, 16));
    title.setForeground(Color.WHITE);
    double latest = points.isEmpty() ? 0.0 : points.get(points.size() - 1).price;
    JLabel subtitle =
        new JLabel(
            points.isEmpty()
                ? conditionToken + "  |  no recorded sales yet"
                : conditionToken + "  |  latest 5s mean  $" + String.format("%.2f", latest));
    subtitle.setFont(new Font("Consolas", Font.PLAIN, 11));
    subtitle.setForeground(new Color(150, 170, 200));
    JPanel chartTitle = new JPanel(new FlowLayout(FlowLayout.LEFT, 8, 0));
    chartTitle.setOpaque(false);
    chartTitle.add(title);
    JComponent chartInfo =
        app.uiWidgets.createInfoBadge(
            "<html><b>Skin price history</b><br>Recent market sales, including simulated"
                + " volume.<br>Rarity sets base activity; cheaper same-rarity items sell more"
                + " often.<br>Five-second buckets; hover for mean price and actual sale"
                + " quantity.</html>");
    chartInfo.setName("skinPriceChartInfo");
    chartTitle.add(chartInfo);
    header.add(chartTitle, BorderLayout.WEST);
    header.add(subtitle, BorderLayout.EAST);
    wrapper.add(header, BorderLayout.NORTH);

    JPanel chart =
        new JPanel() {
          int hoverIndex = -1;

          {
            addMouseMotionListener(
                new MouseMotionAdapter() {
                  @Override
                  public void mouseMoved(MouseEvent e) {
                    int left = 54, right = 36;
                    if (points.size() < 2 || e.getX() < left || e.getX() > getWidth() - right) {
                      hoverIndex = -1;
                    } else {
                      double ratio =
                          (double) (e.getX() - left) / Math.max(1, getWidth() - left - right);
                      hoverIndex =
                          Math.max(
                              0,
                              Math.min(
                                  points.size() - 1,
                                  (int) Math.round(ratio * (points.size() - 1))));
                    }
                    repaint();
                  }
                });
            addMouseListener(
                new MouseAdapter() {
                  @Override
                  public void mouseExited(MouseEvent e) {
                    hoverIndex = -1;
                    repaint();
                  }
                });
          }

          @Override
          protected void paintComponent(Graphics g) {
            super.paintComponent(g);
            Graphics2D g2 = (Graphics2D) g.create();
            g2.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
            int w = getWidth();
            int h = getHeight();
            int left = 54, right = 36, top = 12, bottom = 28;
            g2.setColor(new Color(16, 20, 29));
            g2.fillRoundRect(0, 0, w, h, 8, 8);
            if (points.size() < 2) {
              g2.setColor(new Color(150, 160, 185));
              g2.setFont(new Font("Arial", Font.PLAIN, 12));
              g2.drawString("Not enough price history yet", left, h / 2);
              g2.dispose();
              return;
            }
            double min = points.stream().mapToDouble(p -> p.price).min().orElse(0.0);
            double max = points.stream().mapToDouble(p -> p.price).max().orElse(1.0);
            if (Math.abs(max - min) < 0.01) {
              min *= 0.98;
              max *= 1.02;
            }
            g2.setColor(new Color(38, 46, 62));
            for (int i = 0; i < 4; i++) {
              int y = top + i * (h - top - bottom) / 3;
              g2.drawLine(left, y, w - right, y);
            }
            java.awt.geom.Path2D.Double line = new java.awt.geom.Path2D.Double();
            java.awt.geom.Path2D.Double fill = new java.awt.geom.Path2D.Double();
            for (int i = 0; i < points.size(); i++) {
              double x =
                  left
                      + (points.size() == 1 ? 0 : (double) i / (points.size() - 1))
                          * (w - left - right);
              double norm = (points.get(i).price - min) / (max - min);
              double y = top + (1.0 - norm) * (h - top - bottom);
              if (i == 0) {
                line.moveTo(x, y);
                fill.moveTo(x, h - bottom);
                fill.lineTo(x, y);
              } else {
                line.lineTo(x, y);
                fill.lineTo(x, y);
              }
            }
            fill.lineTo(w - right, h - bottom);
            fill.closePath();
            g2.setPaint(
                new GradientPaint(
                    0,
                    top,
                    new Color(80, 160, 255, 90),
                    0,
                    h - bottom,
                    new Color(80, 160, 255, 12)));
            g2.fill(fill);
            g2.setStroke(new BasicStroke(2.5f));
            g2.setColor(new Color(90, 190, 255));
            g2.draw(line);
            g2.setFont(new Font("Consolas", Font.PLAIN, 10));
            g2.setColor(new Color(170, 185, 205));
            g2.drawString("$" + String.format("%.2f", max), 8, top + 4);
            g2.drawString("$" + String.format("%.2f", min), 8, h - bottom);
            g2.drawString("oldest", left, h - 8);
            FontMetrics axisFm = g2.getFontMetrics();
            String nowLabel = "now";
            g2.drawString(
                nowLabel, Math.max(left, w - right - axisFm.stringWidth(nowLabel)), h - 8);
            if (hoverIndex >= 0 && hoverIndex < points.size()) {
              PriceHistoryPoint point = points.get(hoverIndex);
              double x =
                  left + (double) hoverIndex / Math.max(1, points.size() - 1) * (w - left - right);
              double norm = (point.price - min) / (max - min);
              double y = top + (1.0 - norm) * (h - top - bottom);
              g2.setStroke(new BasicStroke(1.2f));
              g2.setColor(new Color(220, 235, 255, 140));
              g2.drawLine((int) x, top, (int) x, h - bottom);
              g2.setColor(new Color(255, 255, 255));
              g2.fillOval((int) x - 4, (int) y - 4, 8, 8);
              String[] tip = {
                "$" + String.format("%.2f", point.price),
                "Sold: (" + point.soldQuantity + ")",
                new java.text.SimpleDateFormat("HH:mm:ss")
                    .format(new java.util.Date(point.timestamp))
              };
              g2.setFont(new Font("Consolas", Font.BOLD, 11));
              FontMetrics fm = g2.getFontMetrics();
              int boxW = 0;
              for (String s : tip) boxW = Math.max(boxW, fm.stringWidth(s));
              boxW += 18;
              int boxH = tip.length * 15 + 12;
              int boxX = (int) Math.max(left, Math.min(x + 10, Math.max(left, w - right - boxW)));
              int boxY = (int) Math.max(top + 4, y - boxH - 10);
              g2.setColor(new Color(12, 16, 24, 235));
              g2.fillRoundRect(boxX, boxY, boxW, boxH, 8, 8);
              g2.setColor(new Color(90, 190, 255));
              g2.drawRoundRect(boxX, boxY, boxW, boxH, 8, 8);
              g2.setColor(Color.WHITE);
              for (int i = 0; i < tip.length; i++) {
                g2.drawString(tip[i], boxX + 9, boxY + 16 + i * 15);
              }
            }
            g2.dispose();
          }
        };
    chart.setOpaque(false);
    chart.setPreferredSize(new Dimension(0, 150));
    wrapper.add(chart, BorderLayout.CENTER);
    return wrapper;
  }
}
