package blahblah;

import blahblah.hGui.*;
import java.awt.*;
import java.awt.event.*;
import java.math.BigDecimal;
import java.math.RoundingMode;
import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import javax.swing.*;

/** Developer Tools: focused feature implementation. */
final class DeveloperTools {
  private final hGui app;

  DeveloperTools(hGui app) {
    this.app = app;
  }

  Map<String, List<String>> getDevCaseOutcomePools(CaseType ct) {
    Map<String, List<String>> pools = new LinkedHashMap<>();
    if (ct == null) return pools;
    for (String tier :
        new String[] {"Consumer", "Industrial", "Milspec", "Restricted", "Classified", "Covert"}) {
      List<String> names =
          ct.regularDropNames.getOrDefault(tier, java.util.Collections.emptyList());
      if (!names.isEmpty()) pools.put(tier, new ArrayList<>(new java.util.LinkedHashSet<>(names)));
    }
    for (String name :
        ct.isSouvenir ? java.util.Collections.<String>emptyList() : ct.rareDropNames) {
      String category = ct.rareDropCategories.getOrDefault(name, ct.rareDropCategory);
      String tier = "Gloves".equals(category) ? "Gloves" : "Knife";
      java.util.LinkedHashSet<String> variants = new java.util.LinkedHashSet<>();
      variants.add(name);
      if ("Knife".equals(tier)) app.collectionService.addDopplerVariants(variants);
      pools.computeIfAbsent(tier, k -> new ArrayList<>()).addAll(variants);
    }
    return pools;
  }

  void configureDevCaseOverride(
      CaseType ct, String mode, String target, int count, String statTrakMode) {
    if (ct == null || count < 1 || count > 100000)
      throw new IllegalArgumentException("Choose 1–100000 openings.");
    Map<String, List<String>> pools = app.developerTools.getDevCaseOutcomePools(ct);
    boolean valid =
        "Rarity".equals(mode)
            ? pools.containsKey(target)
            : "Skin".equals(mode)
                && pools.values().stream().anyMatch(names -> names.contains(target));
    if (!valid)
      throw new IllegalArgumentException("That outcome does not belong to this container.");
    if (!java.util.Arrays.asList("Normal odds", "Always", "Never").contains(statTrakMode))
      throw new IllegalArgumentException("Invalid StatTrak setting.");
    app.devCaseOverrides.put(ct.id, new DevCaseOverride(mode, target, count, statTrakMode));
  }

  CrateRollResult rollCaseForOpening(CaseType ct) {
    DevCaseOverride rule = app.devCaseOverrides.get(ct.id);
    if (rule == null || rule.remaining <= 0) return CaseRollService.crateItem(ct);
    Map<String, List<String>> pools = app.developerTools.getDevCaseOutcomePools(ct);
    String rarity = "Rarity".equals(rule.mode) ? rule.target : null;
    if (rarity == null) {
      for (Map.Entry<String, List<String>> entry : pools.entrySet())
        if (entry.getValue().contains(rule.target)) {
          rarity = entry.getKey();
          break;
        }
    }
    if (rarity == null || !pools.containsKey(rarity) || pools.get(rarity).isEmpty()) {
      app.devCaseOverrides.remove(ct.id);
      return CaseRollService.crateItem(ct);
    }
    String skin =
        "Skin".equals(rule.mode)
            ? rule.target
            : pools.get(rarity).get(hGui.random.nextInt(pools.get(rarity).size()));
    boolean statTrak =
        !ct.isSouvenir
            && !"Gloves".equals(rarity)
            && ("Always".equals(rule.statTrakMode)
                || ("Normal odds".equals(rule.statTrakMode) && hGui.random.nextInt(10) == 0));
    if (--rule.remaining == 0) app.devCaseOverrides.remove(ct.id);
    return new CrateRollResult(rarity, DeveloperTools.devRarityColor(rarity), statTrak, 1.0, skin);
  }

  static Color devRarityColor(String rarity) {
    switch (rarity) {
      case "Consumer":
        return new Color(176, 195, 217);
      case "Industrial":
        return new Color(94, 152, 217);
      case "Milspec":
        return Theme.RARITY_MILSPEC;
      case "Restricted":
        return Theme.RARITY_RESTRICTED;
      case "Classified":
        return Theme.RARITY_CLASSIFIED;
      case "Covert":
        return Theme.RARITY_COVERT;
      default:
        return Theme.RARITY_GOLD;
    }
  }

  double getCaseOpeningCost(CaseType ct) {
    return app.devFreeCaseOpenings ? 0.0 : ct.price;
  }

  void adjustDevMoney(double amount, String operation) {
    if (!Double.isFinite(amount) || amount < 0 || amount > 1.0e12)
      throw new IllegalArgumentException("Money must be between 0 and 1 trillion.");
    BigDecimal value = BigDecimal.valueOf(amount);
    BigDecimal result =
        "Set".equals(operation)
            ? value
            : "Remove".equals(operation)
                ? BigDecimal.valueOf(app.balance).subtract(value)
                : BigDecimal.valueOf(app.balance).add(value);
    app.balance =
        result
            .max(BigDecimal.ZERO)
            .min(BigDecimal.valueOf(1.0e12))
            .setScale(2, RoundingMode.HALF_UP)
            .doubleValue();
    if (app.balanceLabel != null) app.uiWidgets.updateBalanceLabel();
  }

  void adjustDevStars(int amount, String operation) {
    if (amount < 0 || amount > 1000000000)
      throw new IllegalArgumentException("Invalid star amount.");
    long result =
        "Set".equals(operation)
            ? amount
            : (long) app.playerStars + ("Remove".equals(operation) ? -amount : amount);
    app.playerStars = (int) Math.max(0L, Math.min(1000000000L, result));
    app.missionService.updateStarsLabel();
  }

  List<String> getDevGeneratableSkins() {
    java.util.TreeSet<String> names = new java.util.TreeSet<>(String.CASE_INSENSITIVE_ORDER);
    for (String name : app.skinCatalog.keySet()) if (name.contains(" | ")) names.add(name);
    for (String name : app.oddsAndChecklistScreen.getRegisteredTradeUpSkins())
      if (name.contains(" | ")) names.add(name);
    for (ArmouryCollection col : hGui.ARMOURY_COLLECTIONS) {
      if (col.isAgents) continue;
      for (String[] tier :
          new String[][] {
            col.consumerNames,
            col.industrialNames,
            col.milspecNames,
            col.restrictedNames,
            col.classifiedNames,
            col.covertNames
          }) if (tier != null) java.util.Collections.addAll(names, tier);
    }
    // This generator creates normal items; avoid duplicate souvenir/StatTrak aliases
    // contributed by souvenir package trade-up catalogs.
    names.removeIf(
        name ->
            name.startsWith("Souvenir ")
                || name.startsWith("StatTrak ")
                || name.startsWith("StatTrak™ "));
    return new ArrayList<>(names);
  }

  List<String> getDevAvailableWearRanges(String skin) {
    List<String> ranges = new ArrayList<>();
    if (skin == null || app.floatRules.hasNoFloatWear(skin)) return ranges;
    double[] cap = app.marketStockService.getMarketWearBounds(skin);
    for (int i = 0; i < hGui.MARKET_WEAR_NAMES.length; i++) {
      double low = Math.max(cap[0], hGui.MARKET_WEAR_EDGES[i]);
      double high = Math.min(cap[1], hGui.MARKET_WEAR_EDGES[i + 1]);
      if (high > low) ranges.add(hGui.MARKET_WEAR_NAMES[i]);
    }
    return ranges;
  }

  double[] getDevWearFloatBounds(String skin, String wear) {
    if (!app.developerTools.getDevAvailableWearRanges(skin).contains(wear))
      throw new IllegalArgumentException("That wear range is unavailable for the selected skin.");
    double[] cap = app.marketStockService.getMarketWearBounds(skin);
    for (int i = 0; i < hGui.MARKET_WEAR_NAMES.length; i++) {
      if (hGui.MARKET_WEAR_NAMES[i].equals(wear))
        return new double[] {
          Math.max(cap[0], hGui.MARKET_WEAR_EDGES[i]),
          Math.min(cap[1], hGui.MARKET_WEAR_EDGES[i + 1])
        };
    }
    throw new IllegalArgumentException("Select an available wear range.");
  }

  List<InventoryItem> generateDevSkinsWithModes(
      String skin,
      int quantity,
      String floatMode,
      String floatText,
      String wearRange,
      String patternMode,
      String patternText) {
    Double exactFloat = null;
    Integer exactPattern = null;
    String selectedRange = null;
    if (skin != null && !app.floatRules.hasNoFloatWear(skin)) {
      switch (floatMode) {
        case "Random float":
          break;
        case "Specific float":
          if (floatText == null || floatText.trim().isEmpty())
            throw new IllegalArgumentException("Enter a float value for Specific float.");
          try {
            exactFloat = Double.valueOf(floatText.trim());
          } catch (NumberFormatException ex) {
            throw new IllegalArgumentException("Enter a valid decimal float.");
          }
          break;
        case "Float within range":
          selectedRange = wearRange;
          if (selectedRange == null)
            throw new IllegalArgumentException("Choose an available wear range.");
          break;
        default:
          throw new IllegalArgumentException("Choose a float mode.");
      }
    }
    switch (patternMode) {
      case "Random pattern":
        break;
      case "Specific pattern":
        if (patternText == null || patternText.trim().isEmpty())
          throw new IllegalArgumentException("Enter a pattern ID for Specific pattern.");
        try {
          exactPattern = Integer.valueOf(patternText.trim());
        } catch (NumberFormatException ex) {
          throw new IllegalArgumentException("Pattern must be a whole number from 0 to 999.");
        }
        break;
      default:
        throw new IllegalArgumentException("Choose a pattern mode.");
    }
    return app.developerTools.generateDevSkins(
        skin, quantity, exactFloat, exactPattern, selectedRange);
  }

  List<InventoryItem> generateDevSkins(
      String skin, int quantity, Double specifiedFloat, Integer specifiedPattern) {
    return app.developerTools.generateDevSkins(
        skin, quantity, specifiedFloat, specifiedPattern, null);
  }

  List<InventoryItem> generateDevSkins(
      String skin,
      int quantity,
      Double specifiedFloat,
      Integer specifiedPattern,
      String wearRange) {
    if (skin == null || !app.developerTools.getDevGeneratableSkins().contains(skin))
      throw new IllegalArgumentException("Select a skin from the search results.");
    if (quantity < 1 || quantity > 1000)
      throw new IllegalArgumentException("Quantity must be between 1 and 1000.");
    double[] bounds =
        app.floatRules.hasNoFloatWear(skin)
            ? new double[] {0.0, 0.0}
            : app.marketStockService.getMarketWearBounds(skin);
    if (specifiedFloat != null
        && (!Double.isFinite(specifiedFloat)
            || specifiedFloat < bounds[0]
            || specifiedFloat > bounds[1]))
      throw new IllegalArgumentException(
          "Float must be within " + bounds[0] + "–" + bounds[1] + " for this skin.");
    if (wearRange != null) {
      if (specifiedFloat != null)
        throw new IllegalArgumentException(
            "Choose either a specific float or a wear range, not both.");
      bounds = app.developerTools.getDevWearFloatBounds(skin, wearRange);
    }
    if (specifiedPattern != null && (specifiedPattern < 0 || specifiedPattern > 999))
      throw new IllegalArgumentException("Pattern must be a whole number from 0 to 999.");
    double base = app.itemPriceService.getBasePrice(skin);
    if (!Double.isFinite(base) || base <= 0)
      throw new IllegalArgumentException("No valid price is available for this skin.");
    String rarity = app.itemMetadataService.getSkinRarity(skin),
        collection = app.collectionService.getCollectionName(skin);
    Image art = app.artworkService.getSkinImageFromName(skin);
    ImageIcon icon =
        new ImageIcon(art == null ? app.containerBrowserScreen.createItemPlaceholderImage() : art);
    List<InventoryItem> generated = new ArrayList<>();
    double addedValue = 0.0;
    for (int i = 0; i < quantity; i++) {
      double itemFloat =
          specifiedFloat == null
              ? bounds[0] + hGui.random.nextDouble() * (bounds[1] - bounds[0])
              : specifiedFloat;
      if (specifiedFloat == null && bounds[1] > bounds[0])
        itemFloat = Math.max(bounds[0], Math.min(Math.nextDown(bounds[1]), itemFloat));
      int pattern = specifiedPattern == null ? hGui.random.nextInt(1000) : specifiedPattern;
      String wear = app.floatRules.getConditionForFloat(skin, itemFloat);
      Image wearArtwork = app.artworkService.getSkinImageFromName(skin, wear);
      ImageIcon itemIcon = wearArtwork == null ? icon : new ImageIcon(wearArtwork);
      String gem = app.itemPriceService.getBlueGemTier(skin, pattern);
      double price = base * app.marketInitialization.getMarketMultiplier(rarity, collection);
      if (!app.floatRules.hasNoFloatWear(skin))
        price *= app.priceModifiers.getConditionPriceMultiplier(skin, wear);
      if (gem != null)
        price = app.itemPriceService.applyBlueGemMultiplier(skin, pattern, gem, price);
      String name = gem == null ? skin : skin + " (" + gem + ")";
      InventoryItem item =
          new InventoryItem(
              itemIcon,
              name,
              wear,
              rarity,
              app.coreUtilities.money(Math.max(0.01, price)),
              itemFloat,
              false,
              pattern,
              gem,
              base);
      item.collection = collection;
      app.ownershipHistoryService.addItemHistory(
          item,
          System.currentTimeMillis(),
          "Developer generated",
          "Generated using Dev Tools by YOU",
          "YOU");
      generated.add(item);
      addedValue += item.price.doubleValue();
    }
    synchronized (app.inventoryList) {
      for(InventoryItem item:generated)app.globalSupply.created(item);
      app.inventoryList.addAll(generated);
    }
    app.coreUtilities.addInventoryValue(addedValue);
    app.searchControls.updateLeaderboard();
    if (app.inventoryTabPanel != null)
      app.inventoryTabPanel.putClientProperty("inventorySnapshot", null);
    if (app.tradeUpTabPanel != null)
      app.tradeUpTabPanel.putClientProperty("inventorySnapshot", null);
    if (app.mainTabs != null
        && app.mainTabs.getSelectedIndex() == 2
        && app.inventoryTabPanel != null) app.inventoryScreen.refreshInventoryTab();
    return generated;
  }

  JPanel buildDevSkinGeneratorPanel() {
    JPanel panel = new JPanel(new BorderLayout(8, 10));
    panel.setOpaque(false);
    JLabel heading =
        new JLabel(
            "<html>Search for a skin, then generate it directly into your inventory.<br>Choose a"
                + " float mode and a pattern mode; random values are sampled independently per"
                + " item.</html>");
    heading.setForeground(Theme.TEXT_DIM);
    panel.add(heading, BorderLayout.NORTH);
    DevSearchPicker<String> skins =
        new DevSearchPicker<>(app.developerTools.getDevGeneratableSkins(), "devGeneratorSkin", 6);
    skins.enableCollapsedResults();
    JPanel controls = new JPanel();
    controls.setLayout(new BoxLayout(controls, BoxLayout.Y_AXIS));
    controls.setOpaque(false);
    JLabel limits = new JLabel("Select a skin to see its float limits.");
    limits.setName("devGeneratorLimits");
    limits.setForeground(Theme.ACCENT_CT);
    controls.add(limits);
    JPanel quantityRow = new JPanel(new FlowLayout(FlowLayout.LEFT, 8, 5));
    quantityRow.setOpaque(false);
    JSpinner quantity = new JSpinner(new SpinnerNumberModel(10, 1, 1000, 1));
    quantity.setName("devGeneratorQuantity");
    quantityRow.add(new JLabel("Quantity:"));
    quantityRow.add(quantity);
    controls.add(quantityRow);
    JComboBox<String> floatMode =
        new JComboBox<>(new String[] {"Random float", "Specific float", "Float within range"});
    floatMode.setName("devGeneratorFloatMode");
    JTextField itemFloat = new JTextField(10);
    itemFloat.setName("devGeneratorFloat");
    itemFloat.setToolTipText("Exact float, within this skin's valid limits");
    JComboBox<String> wear = new JComboBox<>();
    wear.setName("devGeneratorWearRange");
    wear.setPrototypeDisplayValue("Battle-Scarred");
    JPanel floatRow = new JPanel(new FlowLayout(FlowLayout.LEFT, 8, 5));
    floatRow.setOpaque(false);
    floatRow.add(new JLabel("Float:"));
    floatRow.add(floatMode);
    floatRow.add(itemFloat);
    floatRow.add(wear);
    controls.add(floatRow);
    JLabel floatInfo = new JLabel(" ");
    floatInfo.setName("devGeneratorFloatInfo");
    floatInfo.setForeground(Theme.TEXT_DIM);
    controls.add(floatInfo);
    JComboBox<String> patternMode =
        new JComboBox<>(new String[] {"Random pattern", "Specific pattern"});
    patternMode.setName("devGeneratorPatternMode");
    JTextField pattern = new JTextField(6);
    pattern.setName("devGeneratorPattern");
    pattern.setToolTipText("Exact whole-number pattern, 0–999");
    JPanel patternRow = new JPanel(new FlowLayout(FlowLayout.LEFT, 8, 5));
    patternRow.setOpaque(false);
    patternRow.add(new JLabel("Pattern:"));
    patternRow.add(patternMode);
    patternRow.add(pattern);
    controls.add(patternRow);
    JPanel actions = new JPanel(new FlowLayout(FlowLayout.LEFT, 8, 5));
    actions.setOpaque(false);
    JButton generate = new JButton("Generate skins");
    generate.setName("devGenerateSkins");
    JButton randomize = new JButton("Reset to random");
    randomize.addActionListener(
        e -> {
          floatMode.setSelectedIndex(0);
          patternMode.setSelectedIndex(0);
          itemFloat.setText("");
          pattern.setText("");
        });
    actions.add(generate);
    actions.add(randomize);
    controls.add(actions);
    JLabel result = new JLabel("Normal (non-StatTrak) items. Opening statistics are unchanged.");
    result.setName("devGeneratorStatus");
    result.setForeground(Theme.TEXT_DIM);
    controls.add(result);
    Runnable updateInputs =
        () -> {
          String selected = skins.selected();
          boolean noFloat = selected != null && app.floatRules.hasNoFloatWear(selected);
          boolean exact = "Specific float".equals(floatMode.getSelectedItem());
          boolean range = "Float within range".equals(floatMode.getSelectedItem());
          floatMode.setEnabled(selected != null && !noFloat);
          itemFloat.setVisible(exact && !noFloat);
          itemFloat.setEnabled(selected != null && exact && !noFloat);
          wear.setVisible(range && !noFloat);
          wear.setEnabled(selected != null && range && !noFloat && wear.getItemCount() > 0);
          boolean exactPattern = "Specific pattern".equals(patternMode.getSelectedItem());
          pattern.setVisible(exactPattern);
          pattern.setEnabled(selected != null && exactPattern);
          generate.setEnabled(selected != null);
          if (selected == null) floatInfo.setText("No matching skin. Try a different search.");
          else if (noFloat)
            floatInfo.setText("This item has no float/wear: generated float is 0 (Normal).");
          else if (range && wear.getSelectedItem() != null) {
            double[] interval =
                app.developerTools.getDevWearFloatBounds(selected, (String) wear.getSelectedItem());
            floatInfo.setText(
                wear.getSelectedItem()
                    + ": "
                    + interval[0]
                    + " <= float < "
                    + interval[1]
                    + " (random per item)");
          } else
            floatInfo.setText(
                exact
                    ? "Every item uses the exact float you enter."
                    : "Random float across the skin's full valid range, independently per item.");
          controls.revalidate();
          controls.repaint();
        };
    Runnable selection =
        () -> {
          String selected = skins.selected();
          Object previous = wear.getSelectedItem();
          wear.setModel(
              new DefaultComboBoxModel<>(
                  app.developerTools.getDevAvailableWearRanges(selected).toArray(new String[0])));
          if (previous != null
              && app.developerTools.getDevAvailableWearRanges(selected).contains(previous))
            wear.setSelectedItem(previous);
          if (selected == null) limits.setText("Select a skin from the search results.");
          else if (app.floatRules.hasNoFloatWear(selected))
            limits.setText("No float/wear for this item. Pattern IDs: 0–999.");
          else {
            double[] cap = app.marketStockService.getMarketWearBounds(selected);
            limits.setText(
                "Skin float limits: " + cap[0] + "–" + cap[1] + "  |  Pattern IDs: 0–999");
          }
          updateInputs.run();
        };
    skins.onSelection(selection);
    floatMode.addActionListener(e -> updateInputs.run());
    patternMode.addActionListener(e -> updateInputs.run());
    wear.addActionListener(e -> updateInputs.run());
    selection.run();
    generate.addActionListener(
        e -> {
          try {
            quantity.commitEdit();
            String selected = skins.selected();
            List<InventoryItem> items =
                app.developerTools.generateDevSkinsWithModes(
                    selected,
                    ((Number) quantity.getValue()).intValue(),
                    (String) floatMode.getSelectedItem(),
                    itemFloat.getText(),
                    (String) wear.getSelectedItem(),
                    (String) patternMode.getSelectedItem(),
                    pattern.getText());
            result.setForeground(Theme.PROFIT);
            result.setText("Added " + items.size() + " × " + selected + " to your inventory.");
          } catch (Exception ex) {
            result.setForeground(new Color(245, 100, 100));
            result.setText(ex.getMessage());
          }
        });
    JPanel content = new JPanel(new BorderLayout(8, 10));
    content.setOpaque(false);
    content.add(skins, BorderLayout.NORTH);
    JPanel controlsHolder = new JPanel(new BorderLayout());
    controlsHolder.setOpaque(false);
    controlsHolder.add(controls, BorderLayout.NORTH);
    content.add(controlsHolder, BorderLayout.CENTER);
    panel.add(content, BorderLayout.CENTER);
    return panel;
  }

  JPanel buildDevToolsPanel() {
    JPanel root = new JPanel(new BorderLayout(10, 10));
    root.setBorder(BorderFactory.createEmptyBorder(14, 14, 14, 14));
    root.setBackground(Theme.BG_DARK);
    JPanel form = new JPanel();
    form.setLayout(new BoxLayout(form, BoxLayout.Y_AXIS));
    form.setOpaque(false);
    JLabel explanation =
        new JLabel(
            "<html>Session-only overrides. Normal odds resume after the requested number of"
                + " openings.<br>Only outcomes verified for the chosen container are"
                + " available.</html>");
    explanation.setForeground(Theme.TEXT_DIM);
    form.add(explanation);
    JButton imageReport = new JButton("Image loading report");
    imageReport.setName("devArtworkReport");
    imageReport.addActionListener(e -> app.openingArtworkService.showArtworkLoadReport());
    form.add(imageReport);
    List<CaseType> cases = new ArrayList<>(java.util.Arrays.asList(CaseType.values()));
    cases.sort(app.containerBrowserScreen.defaultContainerOrder());
    DevSearchPicker<CaseType> containers = new DevSearchPicker<>(cases, "devContainer", 4);
    containers.select(app.currentCase);
    form.add(new JLabel("Container to open / configure:"));
    form.add(containers);
    JComboBox<String> mode = new JComboBox<>(new String[] {"Rarity", "Skin"});
    mode.setName("devMode");
    JComboBox<String> outcomes = new JComboBox<>();
    outcomes.setName("devOutcome");
    outcomes.setMaximumRowCount(12);
    form.add(mode);
    form.add(outcomes);
    JPanel options = new JPanel(new FlowLayout(FlowLayout.LEFT));
    options.setOpaque(false);
    JSpinner count = new JSpinner(new SpinnerNumberModel(1, 1, 100000, 1));
    count.setName("devCount");
    JComboBox<String> statTrak = new JComboBox<>(new String[] {"Normal odds", "Always", "Never"});
    statTrak.setName("devStatTrak");
    options.add(new JLabel("Next openings:"));
    options.add(count);
    options.add(new JLabel("StatTrak:"));
    options.add(statTrak);
    form.add(options);
    JLabel status = new JLabel(" ");
    status.setForeground(Theme.ACCENT_CT);
    status.setName("devStatus");
    Runnable populate =
        () -> {
          CaseType ct = containers.selected();
          Map<String, List<String>> pools = app.developerTools.getDevCaseOutcomePools(ct);
          outcomes.removeAllItems();
          if ("Rarity".equals(mode.getSelectedItem()))
            for (String tier : pools.keySet()) outcomes.addItem(tier);
          else {
            java.util.TreeSet<String> names = new java.util.TreeSet<>();
            for (List<String> tier : pools.values()) names.addAll(tier);
            for (String name : names) outcomes.addItem(name);
          }
          DevCaseOverride rule = ct == null ? null : app.devCaseOverrides.get(ct.id);
          status.setText(
              rule == null
                  ? "Normal odds. No override for this container."
                  : rule.mode + ": " + rule.target + " — " + rule.remaining + " remaining");
        };
    containers.onSelection(populate);
    mode.addActionListener(e -> populate.run());
    JPanel actions = new JPanel(new FlowLayout(FlowLayout.LEFT));
    actions.setOpaque(false);
    JButton apply = new JButton("Apply + select container");
    apply.setName("devApply");
    apply.addActionListener(
        e -> {
          try {
            count.commitEdit();
            CaseType ct = containers.selected();
            app.developerTools.configureDevCaseOverride(
                ct,
                (String) mode.getSelectedItem(),
                (String) outcomes.getSelectedItem(),
                ((Number) count.getValue()).intValue(),
                (String) statTrak.getSelectedItem());
            app.containerBrowserScreen.selectCase(ct);
            populate.run();
          } catch (Exception ex) {
            JOptionPane.showMessageDialog(
                root, ex.getMessage(), "Invalid override", JOptionPane.WARNING_MESSAGE);
          }
        });
    JButton clear = new JButton("Clear this override");
    clear.addActionListener(
        e -> {
          CaseType ct = containers.selected();
          if (ct != null) app.devCaseOverrides.remove(ct.id);
          populate.run();
        });
    actions.add(apply);
    actions.add(clear);
    form.add(actions);
    form.add(status);
    JPanel wallet = new JPanel();
    wallet.setOpaque(false);
    wallet.setLayout(new BoxLayout(wallet, BoxLayout.Y_AXIS));
    JCheckBox free = new JCheckBox("Free case openings (no case cost)", app.devFreeCaseOpenings);
    free.setOpaque(false);
    free.addActionListener(
        e -> {
          app.devFreeCaseOpenings = free.isSelected();
          app.uiWidgets.updateBalanceLabel();
        });
    wallet.add(free);
    JPanel money = new JPanel(new FlowLayout(FlowLayout.LEFT));
    money.setOpaque(false);
    JSpinner cash = new JSpinner(new SpinnerNumberModel(1000.0, 0.0, 1.0e12, 100.0));
    money.add(new JLabel("Money $"));
    money.add(cash);
    for (String operation : new String[] {"Add", "Remove", "Set"}) {
      JButton button = new JButton(operation);
      money.add(button);
      button.addActionListener(
          e -> {
            try {
              cash.commitEdit();
              app.developerTools.adjustDevMoney(
                  ((Number) cash.getValue()).doubleValue(), operation);
            } catch (Exception ex) {
              JOptionPane.showMessageDialog(root, "Enter a valid money amount.");
            }
          });
    }
    wallet.add(money);
    JPanel stars = new JPanel(new FlowLayout(FlowLayout.LEFT));
    stars.setOpaque(false);
    JSpinner starAmount = new JSpinner(new SpinnerNumberModel(100, 0, 1000000000, 10));
    stars.add(new JLabel("Stars"));
    stars.add(starAmount);
    for (String operation : new String[] {"Add", "Remove", "Set"}) {
      JButton button = new JButton(operation);
      stars.add(button);
      button.addActionListener(
          e -> {
            try {
              starAmount.commitEdit();
              app.developerTools.adjustDevStars(
                  ((Number) starAmount.getValue()).intValue(), operation);
            } catch (Exception ex) {
              JOptionPane.showMessageDialog(root, "Enter a valid star amount.");
            }
          });
    }
    wallet.add(stars);
    JPanel resets = new JPanel(new FlowLayout(FlowLayout.LEFT));
    resets.setOpaque(false);
    JButton profit = new JButton("Reset opening profit");
    profit.addActionListener(
        e -> {
          app.openingProfit = 0.0;
          app.profitLabel.setText("Opening Profit: $0.00");
          app.profitLabel.setForeground(Theme.TEXT_DIM);
        });
    JButton normal = new JButton("Reset all developer overrides");
    normal.addActionListener(
        e -> {
          app.devCaseOverrides.clear();
          app.devFreeCaseOpenings = false;
          free.setSelected(false);
          app.uiWidgets.updateBalanceLabel();
          populate.run();
        });
    resets.add(profit);
    resets.add(normal);
    wallet.add(resets);
    app.developerTools.layoutDeveloperRows(form);
    app.developerTools.layoutDeveloperRows(wallet);
    JTabbedPane sections = new JTabbedPane();
    sections.setUI(
        new javax.swing.plaf.basic.BasicTabbedPaneUI() {
          @Override
          protected void paintTabBackground(
              Graphics graphics,
              int placement,
              int index,
              int x,
              int y,
              int width,
              int height,
              boolean selected) {
            graphics.setColor(selected ? Theme.BG_PANEL : Theme.BG_CARD);
            graphics.fillRect(x, y, width, height);
          }
        });
    sections.setBackground(Theme.BG_PANEL);
    sections.setForeground(Theme.TEXT);
    sections.addTab("Case overrides", form);
    sections.addTab("Skin generator", app.developerTools.buildDevSkinGeneratorPanel());
    sections.addTab("Wallet & settings", wallet);
    root.add(sections, BorderLayout.CENTER);
    app.developerTools.styleDeveloperPanel(root);
    populate.run();
    return root;
  }

  void layoutDeveloperRows(JPanel panel) {
    panel.setBorder(BorderFactory.createEmptyBorder(8, 8, 8, 8));
    for (Component component : panel.getComponents()) {
      if (component instanceof JComponent)
        ((JComponent) component).setAlignmentX(Component.LEFT_ALIGNMENT);
      Dimension preferred = component.getPreferredSize();
      component.setMaximumSize(new Dimension(Integer.MAX_VALUE, preferred.height + 8));
    }
  }

  @SuppressWarnings("unchecked")
  void styleDeveloperPanel(Component component) {
    if (component instanceof JPanel) {
      component.setBackground(Theme.BG_DARK);
      ((JPanel) component).setOpaque(true);
    }
    if (component instanceof JLabel
        && component.getForeground() instanceof javax.swing.plaf.UIResource)
      component.setForeground(Theme.TEXT);
    if (component instanceof JCheckBox) component.setForeground(Theme.TEXT);
    if (component instanceof JComboBox) {
      // Never combine Aqua's native white bezel with a custom light renderer.
      // Use the same explicit Basic UI for both the closed value and popup.
      JComboBox<String> box = (JComboBox<String>) component;
      app.uiWidgets.styleComboBox(box);
      box.setOpaque(true);
      box.setRenderer(
          new DefaultListCellRenderer() {
            @Override
            public boolean isOpaque() {
              return true;
            }

            @Override
            public Component getListCellRendererComponent(
                JList<?> list, Object value, int index, boolean selected, boolean focus) {
              super.getListCellRendererComponent(list, value, index, selected, focus);
              setVerticalAlignment(SwingConstants.CENTER);
              setHorizontalAlignment(SwingConstants.LEFT);
              setBorder(BorderFactory.createEmptyBorder(4, 8, 4, 8));
              setBackground(selected ? Theme.CARD_HOVER : Theme.BG_PANEL);
              setForeground(selected ? Theme.ACCENT_CT : Theme.TEXT);
              return this;
            }
          });
      Dimension preferred = box.getPreferredSize();
      int textWidth = 0;
      for (int i = 0; i < box.getItemCount(); i++)
        textWidth =
            Math.max(
                textWidth,
                box.getFontMetrics(box.getFont()).stringWidth(String.valueOf(box.getItemAt(i))));
      if (box.getPrototypeDisplayValue() != null)
        textWidth =
            Math.max(
                textWidth,
                box.getFontMetrics(box.getFont())
                    .stringWidth(String.valueOf(box.getPrototypeDisplayValue())));
      box.setPreferredSize(
          new Dimension(Math.max(Math.max(150, preferred.width), textWidth + 56), 34));
      box.setMinimumSize(new Dimension(80, 32));
      return; // Do not restyle the UI delegate's internal arrow/renderer.
    }
    if (component instanceof JSpinner) {
      JSpinner spinner = (JSpinner) component;
      spinner.setUI(new javax.swing.plaf.basic.BasicSpinnerUI());
      spinner.setBorder(BorderFactory.createLineBorder(Theme.BORDER));
      if (spinner.getEditor() instanceof JSpinner.DefaultEditor) {
        JTextField field = ((JSpinner.DefaultEditor) spinner.getEditor()).getTextField();
        field.setBackground(Theme.BG_CARD);
        field.setForeground(Theme.TEXT);
        field.setCaretColor(Theme.TEXT);
        field.setBorder(BorderFactory.createEmptyBorder(5, 7, 5, 7));
      }
      return;
    }
    if (component instanceof JTextField) {
      JTextField field = (JTextField) component;
      field.setBackground(Theme.BG_CARD);
      field.setForeground(Theme.TEXT);
      field.setCaretColor(Theme.TEXT);
      field.setDisabledTextColor(Theme.TEXT_DIM);
      field.setBorder(
          BorderFactory.createCompoundBorder(
              BorderFactory.createLineBorder(Theme.BORDER),
              BorderFactory.createEmptyBorder(6, 8, 6, 8)));
    }
    if (component instanceof JButton
        && !(component instanceof javax.swing.plaf.basic.BasicArrowButton))
      app.uiWidgets.styleButton((JButton) component, Theme.BG_CARD, Theme.TEXT, Theme.BORDER);
    if (component instanceof Container)
      for (Component child : ((Container) component).getComponents())
        app.developerTools.styleDeveloperPanel(child);
  }

  void showDevToolsWindow() {
    if (app.isAnimating) {
      JOptionPane.showMessageDialog(
          app, "Finish the current opening before changing developer settings.");
      return;
    }
    app.containerBrowserScreen.stopAutoOpen();
    JDialog dialog = new JDialog(app, "Dev Tools", true);
    dialog.setDefaultCloseOperation(JDialog.DISPOSE_ON_CLOSE);
    JScrollPane scroll = new JScrollPane(app.developerTools.buildDevToolsPanel());
    scroll.getVerticalScrollBar().setUnitIncrement(20);
    dialog.add(scroll);
    Dimension screen = Toolkit.getDefaultToolkit().getScreenSize();
    dialog.setSize(Math.min(780, screen.width - 60), Math.min(740, screen.height - 80));
    dialog.setLocationRelativeTo(app);
    dialog.setVisible(true);
  }

  void layoutCaseOpeningControls() {
    if (app.casesTabPanel == null
        || app.openCrateButton == null
        || app.autoOpenButton == null
        || app.profitLabel == null) return;
    int width = app.casesTabPanel.getWidth() > 0 ? app.casesTabPanel.getWidth() : 760;
    int height = app.casesTabPanel.getHeight() > 0 ? app.casesTabPanel.getHeight() : 750;
    int x = (width - 220) / 2;
    app.openCrateButton.setBounds(x, 112, 220, 36);
    app.closeCrateButton.setBounds(x, 112, 220, 36);
    app.profitLabel.setBounds(10, 152, Math.max(100, width - 20), 24);
    app.profitLabel.setHorizontalAlignment(SwingConstants.CENTER);
    app.autoOpenButton.setBounds(x, 182, 220, 36);
    app.devToolsButton.setBounds(Math.max(10, width - 136), Math.max(235, height - 48), 120, 30);
    if (app.crateImageLabel != null)
      app.crateImageLabel.setBounds((width - 280) / 2, 370, 280, 200);
  }
}
