package blahblah;

import blahblah.hGui.*;
import java.awt.*;
import java.awt.event.*;
import javax.swing.*;

/** Embedded data kept in Java so no extra resource folder is required. */
final class ArmouryCollectionsData {
  static final ArmouryCollection[] DATA = {
    new ArmouryCollection(
        "Sport & Field Collection",
        new String[] {
          "mp5sdsavannahhalftone",
          "ppbizoncoldcell",
          "tec9tigerstencil",
          "mag7wildwood",
          "famashalfsleeve",
          "ak47olivepolycam"
        },
        new String[] {
          "MP5-SD | Savannah Halftone",
          "PP-Bizon | Cold Cell",
          "Tec-9 | Tiger Stencil",
          "MAG-7 | Wildwood",
          "FAMAS | Half Sleeve",
          "AK-47 | Olive Polycam"
        },
        new double[] {0.20, 0.15, 0.40, 0.25, 0.50, 0.80},
        new String[] {"uspsalpinecamo", "ssg08zeno", "p250smallgame", "novayorkshire"},
        new String[] {
          "USP-S | Alpine Camo", "SSG 08 | Zeno", "P250 | Small Game", "Nova | Yorkshire"
        },
        new double[] {1.5, 1.8, 2.0, 2.0},
        new String[] {"ump45crimsonfoil", "mp9arctictritone", "fivesevenheattreated"},
        new String[] {
          "UMP-45 | Crimson Foil", "MP9 | Arctic Tri-Tone", "Five-SeveN | Heat Treated"
        },
        new double[] {5.0, 5.0, 10.0},
        new String[] {"glock18axia", "galilarrainbowspoon"},
        new String[] {"Glock-18 | AXIA", "Galil AR | Rainbow Spoon"},
        new double[] {50.0, 50.0},
        new String[] {"m4a1sfade"},
        new String[] {"M4A1-S | Fade"},
        new double[] {400.0}),
    new ArmouryCollection(
        "Overpass 2024 Collection",
        new String[] {
          "mp5sdneonsqueezer",
          "p90washme",
          "negevwallbang",
          "m4a1swashmeplz",
          "fivesevenmidnightpaintover",
          "deserteagletilted"
        },
        new String[] {
          "MP5-SD | Neon Squeezer",
          "P90 | Wash me",
          "Negev | Wall Bang",
          "M4A1-S | Wash me plz",
          "Five-SeveN | Midnight Paintover",
          "Desert Eagle | Tilted"
        },
        new double[] {0.18, 0.20, 0.10, 0.12, 0.08, 0.15},
        new String[] {
          "novawurstholle", "mac10pipsqueak", "glock18tealgraf", "galilarmetallicsqueezer"
        },
        new String[] {
          "Nova | Wurst Holle",
          "MAC-10 | Pipsqueak",
          "Glock-18 | Teal Graf",
          "Galil AR | Metallic Squeezer"
        },
        new double[] {1.0, 2.0, 1.5, 1.2},
        new String[] {"xm1014monstermelt", "dualberettassweetlittleangels", "augeyeofzapems"},
        new String[] {
          "XM1014 | Monster Melt", "Dual Berettas | Sweet Little Angels", "AUG | Eye of Zapems"
        },
        new double[] {8.0, 8.0, 8.0},
        new String[] {"zeusx27dragonsnore", "awpcrakow"},
        new String[] {"Zeus x27 | Dragon Snore", "AWP | Crakow!"},
        new double[] {40.0, 55.0},
        new String[] {"ak47bthemonster"},
        new String[] {"AK-47 | B the Monster"},
        new double[] {300.0}),
    new ArmouryCollection(
        "Graphic Design Collection",
        new String[] {
          "ssg08halftonewhorl",
          "p2000coralhalftone",
          "mp7astrolabe",
          "m249spectrogram",
          "galilarnv",
          "famashalftonewash"
        },
        new String[] {
          "SSG 08 | Halftone Whorl",
          "P2000 | Coral Halftone",
          "MP7 | Astrolabe",
          "M249 | Spectrogram",
          "Galil AR | NV",
          "FAMAS | Halftone Wash"
        },
        new double[] {0.40, 0.60, 0.90, 0.8, 3.5, 0.45},
        new String[] {
          "xm1014halftoneshift", "sg553berrygelcoat", "scar20wildberry", "ak47crossfade"
        },
        new String[] {
          "XM1014 | Halftone Shift",
          "SG 553 | Berry Gel Coat",
          "SCAR-20 | Wild Berry",
          "AK-47 | Crossfade"
        },
        new double[] {3.0, 3.5, 2.0, 3.5},
        new String[] {"p90attackvector", "m4a4polysoup", "cz75autoslalom"},
        new String[] {"P90 | Attack Vector", "M4A4 | Polysoup", "CZ75-Auto | Slalom"},
        new double[] {10.0, 15.0, 10.0},
        new String[] {"deserteaglestarcade", "auglilpig"},
        new String[] {"Desert Eagle | Starcade", "AUG | Lil' Pig"},
        new double[] {90.0, 60.0},
        new String[] {"awpcmyk"},
        new String[] {"AWP | CMYK"},
        new double[] {500.0}),
    new ArmouryCollection(
        "The Canals Collection",
        new String[] {
          "ak47baroquepurple", "p250darkfiligree", "sg553candyapple", "tec9orangemurano"
        },
        new String[] {
          "AK-47 | Baroque Purple",
          "P250 | Dark Filigree",
          "SG 553 | Candy Apple",
          "Tec-9 | Orange Murano"
        },
        new double[] {4.00, 4.50, 4.25, 3.75},
        new String[] {
          "dualberettasemerald", "g3sg1violetmurano", "p90baroquered", "ssg08orangefiligree"
        },
        new String[] {
          "Dual Berettas | Emerald",
          "G3SG1 | Violet Murano",
          "P90 | Baroque Red",
          "SSG 08 | Orange Filigree"
        },
        new double[] {30.00, 24.00, 26.00, 35.00},
        new String[] {"mac10redfiligree", "mp9stainedglass", "novabaroqueorange"},
        new String[] {"MAC-10 | Red Filigree", "MP9 | Stained Glass", "Nova | Baroque Orange"},
        new double[] {100.00, 115.00, 95.00},
        new String[] {"mag7cinquedea"},
        new String[] {"MAG-7 | Cinquedea"},
        new double[] {650.00},
        new String[] {"awptheprince"},
        new String[] {"AWP | The Prince"},
        new double[] {2000.00},
        new String[] {
          "augnavymurano",
          "cz75autoindigo",
          "negevboroquesand",
          "r8revolvercanalspray",
          "scar20stonemosaico"
        },
        new String[] {
          "AUG | Navy Murano",
          "CZ75-Auto | Indigo",
          "Negev | Boroque Sand",
          "R8 Revolver | Canal Spray",
          "SCAR-20 | Stone Mosaico"
        },
        new double[] {1.50, 1.75, 1.50, 1.25, 1.25}),
    new ArmouryCollection(
        "The Norse Collection",
        new String[] {"dualberettaspyre", "m4a1smossquartz", "mag7chainmail", "uspspathfinder"},
        new String[] {
          "Dual Berettas | Pyre", "M4A1-S | Moss Quartz", "MAG-7 | Chainmail", "USP-S | Pathfinder"
        },
        new double[] {22.00, 45.00, 18.00, 28.00},
        new String[] {
          "cz75autoemeraldquartz", "mac10copperborre", "scar20brass", "xm1014frostborre"
        },
        new String[] {
          "CZ75-Auto | Emerald Quartz",
          "MAC-10 | Copper Borre",
          "SCAR-20 | Brass",
          "XM1014 | Frost Borre"
        },
        new double[] {170.00, 140.00, 130.00, 110.00},
        new String[] {
          "augflamejormungandr", "deserteagleemeraldjormungandr", "p90astraljormungandr"
        },
        new String[] {
          "AUG | Flame Jörmungandr",
          "Desert Eagle | Emerald Jörmungandr",
          "P90 | Astral Jörmungandr"
        },
        new double[] {500.00, 650.00, 800.00},
        new String[] {"negevmjolnir"},
        new String[] {"Negev | Mjölnir"},
        new double[] {2200.00},
        new String[] {"awpgungnir"},
        new String[] {"AWP | Gungnir"},
        new double[] {8500.00},
        new String[] {
          "famasnightborre", "galilartornado", "mp7scorched", "sg553barricade", "ssg08redstone"
        },
        new String[] {
          "FAMAS | Night Borre",
          "Galil AR | Tornado",
          "MP7 | Scorched",
          "SG 553 | Barricade",
          "SSG 08 | Red Stone"
        },
        new double[] {8.00, 7.00, 6.00, 7.00, 8.00}),
    new ArmouryCollection(
        "The St. Marc Collection",
        new String[] {"m4a4darkblossom", "p90sunsetlily", "tec9rustleaf", "xm1014bananaleaf"},
        new String[] {
          "M4A4 | Dark Blossom", "P90 | Sunset Lily", "Tec-9 | Rust Leaf", "XM1014 | Banana Leaf"
        },
        new double[] {5.00, 5.00, 4.00, 4.00},
        new String[] {"fivesevencrimsonblossom", "famassundown", "mp7tealblossom", "ump45daylily"},
        new String[] {
          "Five-SeveN | Crimson Blossom",
          "FAMAS | Sundown",
          "MP7 | Teal Blossom",
          "UMP-45 | Day Lily"
        },
        new double[] {14.00, 16.00, 14.00, 12.00},
        new String[] {"augmidnightlily", "glock18synthleaf", "ssg08seacalico"},
        new String[] {"AUG | Midnight Lily", "Glock-18 | Synth Leaf", "SSG 08 | Sea Calico"},
        new double[] {80.00, 110.00, 85.00},
        new String[] {"mp9wildlily"},
        new String[] {"MP9 | Wild Lily"},
        new double[] {1200.00},
        new String[] {"ak47wildlotus"},
        new String[] {"AK-47 | Wild Lotus"},
        new double[] {8500.00},
        new String[] {
          "m249jungle",
          "mp5sdbamboogarden",
          "mac10surfwood",
          "ppbizonseabird",
          "sawedoffjunglethicket"
        },
        new String[] {
          "M249 | Jungle",
          "MP5-SD | Bamboo Garden",
          "MAC-10 | Surfwood",
          "PP-Bizon | Seabird",
          "Sawed-Off | Jungle Thicket"
        },
        new double[] {1.50, 1.50, 1.25, 1.25, 1.50}),
    new ArmouryCollection(
        "The Control Collection",
        new String[] {
          "deserteaglethebronze", "dualberettasswitchboard", "mag7carbonfiber", "mp5sdnitro"
        },
        new String[] {
          "Desert Eagle | The Bronze",
          "Dual Berettas | Switch Board",
          "MAG-7 | Carbon Fiber",
          "MP5-SD | Nitro"
        },
        new double[] {6.00, 5.00, 6.00, 6.00},
        new String[] {
          "m4a4globaloffensive", "p2000dispatch", "scar20magnacarta", "ssg08threatdetected"
        },
        new String[] {
          "M4A4 | Global Offensive",
          "P2000 | Dispatch",
          "SCAR-20 | Magna Carta",
          "SSG 08 | Threat Detected"
        },
        new double[] {35.00, 28.00, 25.00, 30.00},
        new String[] {"famasprimeconspiracy", "ump45crimescene", "fivesevenberriesandcherries"},
        new String[] {
          "FAMAS | Prime Conspiracy", "UMP-45 | Crime Scene", "Five-SeveN | Berries And Cherries"
        },
        new double[] {140.00, 120.00, 190.00},
        new String[] {"m4a1sbluephosphor", "uspstargetacquired"},
        new String[] {"M4A1-S | Blue Phosphor", "USP-S | Target Acquired"},
        new double[] {900.00, 500.00},
        new String[] {"awpfade"},
        new String[] {"AWP | Fade"},
        new double[] {1200.00},
        new String[] {
          "augsurveillance",
          "cz75autojungledashed",
          "mp9armysheen",
          "p250forestnight",
          "xm1014charter"
        },
        new String[] {
          "AUG | Surveillance",
          "CZ75-Auto | Jungle Dashed",
          "MP9 | Army Sheen",
          "P250 | Forest Night",
          "XM1014 | Charter"
        },
        new double[] {1.25, 1.25, 1.25, 1.25, 1.25}),
    new ArmouryCollection(
        "The Havoc Collection",
        new String[] {
          "mp7vaultheist", "novarustcoat", "r8revolverphoenixmarker", "ump45houndstooth"
        },
        new String[] {
          "MP7 | Vault Heist",
          "Nova | Rust Coat",
          "R8 Revolver | Phoenix Marker",
          "UMP-45 | Houndstooth"
        },
        new double[] {5.00, 4.00, 5.00, 4.00},
        new String[] {
          "deserteaglenightheist", "negevphoenixstencil", "p250bengaltiger", "p90tigerpit"
        },
        new String[] {
          "Desert Eagle | Night Heist",
          "Negev | Phoenix Stencil",
          "P250 | Bengal Tiger",
          "P90 | Tiger Pit"
        },
        new double[] {20.00, 18.00, 20.00, 20.00},
        new String[] {"galilarphoenixblacklight", "glock18franklin", "sg553hypnotic"},
        new String[] {"Galil AR | Phoenix Blacklight", "Glock-18 | Franklin", "SG 553 | Hypnotic"},
        new double[] {90.00, 100.00, 75.00},
        new String[] {"awpsilktiger", "mac10hotsnakes"},
        new String[] {"AWP | Silk Tiger", "MAC-10 | Hot Snakes"},
        new double[] {250.00, 275.00},
        new String[] {"ak47xray"},
        new String[] {"AK-47 | X-Ray"},
        new double[] {700.00},
        new String[] {
          "dualberettasheist",
          "m249predator",
          "ppbizondeathrattle",
          "sawedoffclayambush",
          "tec9phoenixchalk"
        },
        new String[] {
          "Dual Berettas | Heist",
          "M249 | Predator",
          "PP-Bizon | Death Rattle",
          "Sawed-Off | Clay Ambush",
          "Tec-9 | Phoenix Chalk"
        },
        new double[] {1.00, 1.00, 1.00, 1.00, 1.00}),
    new ArmouryCollection(
        "The Rising Sun Collection",
        new String[] {"p250crimsonkimono", "deserteaglemidnightstorm"},
        new String[] {"P250 | Crimson Kimono", "Desert Eagle | Midnight Storm"},
        new double[] {16.00, 18.00},
        new String[] {"galilaraquaterrace", "mag7counterterrace", "tec9terrace"},
        new String[] {"Galil AR | Aqua Terrace", "MAG-7 | Counter Terrace", "Tec-9 | Terrace"},
        new double[] {130.00, 105.00, 100.00},
        new String[] {
          "m4a4daybreak",
          "fivesevenneonkimono",
          "deserteaglesunsetstormichi",
          "deserteaglesunsetstormni"
        },
        new String[] {
          "M4A4 | Daybreak",
          "Five-SeveN | Neon Kimono",
          "Desert Eagle | Sunset Storm 壱",
          "Desert Eagle | Sunset Storm 弐"
        },
        new double[] {600.00, 480.00, 500.00, 550.00},
        new String[] {"ak47hydroponic"},
        new String[] {"AK-47 | Hydroponic"},
        new double[] {1500.00},
        new String[] {"augakihabaraaccept"},
        new String[] {"AUG | Akihabara Accept"},
        new double[] {2400.00},
        new String[] {
          "sawedoffbambooshadow",
          "ppbizonbambooprint",
          "p250mintkimono",
          "tec9bambooforest",
          "g3sg1orangekimono"
        },
        new String[] {
          "Sawed-Off | Bamboo Shadow",
          "PP-Bizon | Bamboo Print",
          "P250 | Mint Kimono",
          "Tec-9 | Bamboo Forest",
          "G3SG1 | Orange Kimono"
        },
        new double[] {5.00, 5.00, 5.00, 5.00, 5.00}),
    new ArmouryCollection(
        "The Baggage Collection",
        new String[] {"sg553traveler", "p90leather", "mac10commuter", "p2000coachclass"},
        new String[] {
          "SG 553 | Traveler", "P90 | Leather", "MAC-10 | Commuter", "P2000 | Coach Class"
        },
        new double[] {1.00, 1.00, 1.25, 1.50},
        new String[] {"sawedofffirstclass", "uspsbusinessclass", "xm1014redleather"},
        new String[] {"Sawed-Off | First Class", "USP-S | Business Class", "XM1014 | Red Leather"},
        new double[] {4.00, 5.00, 6.00},
        new String[] {"ak47firstclass", "deserteaglepilot"},
        new String[] {"AK-47 | First Class", "Desert Eagle | Pilot"},
        new double[] {20.00, 25.00},
        new String[] {"ak47jetset"},
        new String[] {"AK-47 | Jet Set"},
        new double[] {450.00},
        new String[0],
        new String[0],
        new double[0],
        new String[] {
          "g3sg1contractor", "mp7oliveplaid", "cz75autogreenplaid", "mp9greenplaid", "ssg08sanddune"
        },
        new String[] {
          "G3SG1 | Contractor",
          "MP7 | Olive Plaid",
          "CZ75-Auto | Green Plaid",
          "MP9 | Green Plaid",
          "SSG 08 | Sand Dune"
        },
        new double[] {0.40, 0.50, 0.50, 0.50, 0.60}),
    new ArmouryCollection(
        "The Gods and Monsters Collection",
        new String[] {"awpsuninleo", "m249shippingforecast", "p2000pathfinder", "tec9hades"},
        new String[] {
          "AWP | Sun in Leo", "M249 | Shipping Forecast", "P2000 | Pathfinder", "Tec-9 | Hades"
        },
        new double[] {25.00, 20.00, 18.00, 20.00},
        new String[] {"mp9pandorasbox", "ump45minotaurslabyrinth"},
        new String[] {"MP9 | Pandora's Box", "UMP-45 | Minotaur's Labyrinth"},
        new double[] {140.00, 120.00},
        new String[] {"m4a1sicarusfell", "g3sg1chronos"},
        new String[] {"M4A1-S | Icarus Fell", "G3SG1 | Chronos"},
        new double[] {500.00, 320.00},
        new String[] {"m4a4poseidon"},
        new String[] {"M4A4 | Poseidon"},
        new double[] {1250.00},
        new String[] {"awpmedusa"},
        new String[] {"AWP | Medusa"},
        new double[] {2600.00},
        new String[] {"mp7asterion", "dualberettasmooninlibra", "augdaedalus", "novamooninlibra"},
        new String[] {
          "MP7 | Asterion",
          "Dual Berettas | Moon in Libra",
          "AUG | Daedalus",
          "Nova | Moon in Libra"
        },
        new double[] {5.00, 5.00, 4.50, 4.50}),
    new ArmouryCollection(
        "The Chop Shop Collection",
        new String[] {"deserteaglenight", "uspsparagreen", "galilarurbanrubble"},
        new String[] {"Desert Eagle | Night", "USP-S | Para Green", "Galil AR | Urban Rubble"},
        new double[] {12.00, 8.00, 9.00},
        new String[] {
          "p250whiteout", "mac10fade", "cz75autoemerald", "fivesevennitro", "mp7fullstop"
        },
        new String[] {
          "P250 | Whiteout",
          "MAC-10 | Fade",
          "CZ75-Auto | Emerald",
          "Five-SeveN | Nitro",
          "MP7 | Full Stop"
        },
        new double[] {45.00, 60.00, 45.00, 35.00, 35.00},
        new String[] {"sg553bulldozer", "dualberettasduelist"},
        new String[] {"SG 553 | Bulldozer", "Dual Berettas | Duelist"},
        new double[] {250.00, 225.00},
        new String[] {"m4a1shotrod", "glock18twilightgalaxy"},
        new String[] {"M4A1-S | Hot Rod", "Glock-18 | Twilight Galaxy"},
        new double[] {1650.00, 250.00},
        new String[0],
        new String[0],
        new double[0],
        new String[] {"m249impactdrill", "mag7seabird", "scar20armysheen", "cz75autoarmysheen"},
        new String[] {
          "M249 | Impact Drill", "MAG-7 | Seabird", "SCAR-20 | Army Sheen", "CZ75-Auto | Army Sheen"
        },
        new double[] {3.00, 3.00, 3.00, 3.00}),
    new ArmouryCollection(
        "Agents Collection",
        true,
        new String[] {
          "dprimeirotente", "dtrapperaggressor", "dstreetsoldier", "djunglerebel", "daspirant",
          "dchemhazspecialist", "dbiohazspecialist", "doperator", "dgroundrebel", "ddragomir"
        },
        new String[] {
          "Primeiro Tenente", "Trapper Aggressor", "Street Soldier", "Jungle Rebel", "Aspirant",
          "Chem-Haz Specialist", "Bio-Haz Specialist", "Operator", "Ground Rebel", "Dragomir"
        },
        new double[] {10.0, 9.0, 8.0, 7.0, 6.0, 5.0, 4.0, 3.0, 2.0, 1.0},
        new String[] {
          "egetawaysally",
          "elittlekev",
          "etrapper",
          "ecolmangosdabisi",
          "eofficerjacquesbeltram",
          "eltreehuggerfarlow",
          "eslingshot",
          "eosiris"
        },
        new String[] {
          "Getaway Sally",
          "Little Kev",
          "Trapper",
          "Col. Mangos Dabisi",
          "Officer Jacques Beltram",
          "Lieutenant 'Tree Hugger' Farlow",
          "Slingshot",
          "Osiris"
        },
        new double[] {25.0, 24.0, 23.0, 22.0, 20.0, 18.0, 16.0, 15.0},
        new String[] {
          "snumberk", "selitetrappersolman", "srezantheready", "sprofshahmat", "schemhazcapitaine"
        },
        new String[] {
          "Number K",
          "Elite Trapper Solman",
          "Rezan The Ready",
          "Prof. Shahmat",
          "Chem-Haz Capitaine"
        },
        new double[] {60.0, 55.0, 50.0, 45.0, 40.0},
        new String[] {
          "msirbloodymiamidarryl", "mcmdrdavidagoggalesfernandez", "mvypasistatherevolution"
        },
        new String[] {
          "Sir Bloody Miami Darryl",
          "Cmdr. Davida 'Goggles' Fernandez",
          "Vypa Sista of the Revolution"
        },
        new double[] {150.0, 130.0, 100.0}),

    // Achroma: 20 skins, Consumer through Classified; no Covert tier.
    new ArmouryCollection(
        "The Achroma Collection",
        new String[] {
          "achroma_mac_10_snow_splash",
          "achroma_mp5_sd_snow_splash",
          "achroma_famas_vendetta",
          "achroma_m4a4_aeolian_dark",
          "achroma_r8_revolver_dark_chamber"
        },
        new String[] {
          "MAC-10 | Snow Splash",
          "MP5-SD | Snow Splash",
          "FAMAS | Vendetta",
          "M4A4 | Aeolian Dark",
          "R8 Revolver | Dark Chamber"
        },
        new double[] {0.03, 0.03, 0.03, 0.03, 0.03},
        new String[] {
          "achroma_aug_creep",
          "achroma_p90_aeolian_light",
          "achroma_desert_eagle_the_daily_deagle",
          "achroma_p2000_grip_tape"
        },
        new String[] {
          "AUG | Creep",
          "P90 | Aeolian Light",
          "Desert Eagle | The Daily Deagle",
          "P2000 | Grip Tape"
        },
        new double[] {0.14, 0.13, 0.20, 0.15},
        new String[] {"achroma_ak_47_breakthrough", "achroma_glock_18_trace_lock"},
        new String[] {"AK-47 | Breakthrough", "Glock-18 | Trace Lock"},
        new double[] {1.83, 0.80},
        new String[] {"achroma_awp_the_end"},
        new String[] {"AWP | The End"},
        new double[] {9.11},
        new String[0],
        new String[0],
        new double[0],
        new String[] {
          "achroma_mp9_dizzy",
          "achroma_pp_bizon_bizoom",
          "achroma_dual_berettas_silver_pour",
          "achroma_ssg_08_sans_comic",
          "achroma_scar_20_zinc",
          "achroma_m249_sleet",
          "achroma_p250_sleet",
          "achroma_nova_currents"
        },
        new String[] {
          "MP9 | Dizzy",
          "PP-Bizon | Bizoom",
          "Dual Berettas | Silver Pour",
          "SSG 08 | Sans Comic",
          "SCAR-20 | Zinc",
          "M249 | Sleet",
          "P250 | Sleet",
          "Nova | Currents"
        },
        new double[] {0.03, 0.03, 0.03, 0.03, 0.03, 0.03, 0.03, 0.03}),
    new ArmouryCollection(
        "The Arabesque Collection",
        new String[] {
          "arabesque-1-0",
          "arabesque-1-1",
          "arabesque-1-2",
          "arabesque-1-3",
          "arabesque-1-4",
          "arabesque-1-5"
        },
        new String[] {
          "PP-Bizon | Traitor",
          "MP9 | Dune Asp",
          "Nova | Morning Sun",
          "SCAR-20 | Sirocco Script",
          "Five-SeveN | Desert Seal",
          "Dual Berettas | Mystic Conjunction"
        },
        new double[] {0.03, 0.04, 0.03, 0.03, 0.03, 0.03},
        new String[] {"arabesque-2-0", "arabesque-2-1", "arabesque-2-2", "arabesque-2-3"},
        new String[] {
          "Sawed-Off | Lunar Wyrm",
          "FAMAS | Snake Song",
          "Tec-9 | Sultan",
          "MAC-10 | Arabesque Mosaic"
        },
        new double[] {0.29, 0.29, 0.49, 0.3},
        new String[] {"arabesque-3-0", "arabesque-3-1", "arabesque-3-2"},
        new String[] {"AUG | Lapis Lazuli", "Glock-18 | Ifrit Lattice", "P250 | Lotus Imprint"},
        new double[] {2.54, 2.49, 2.63},
        new String[] {"arabesque-4-0", "arabesque-4-1"},
        new String[] {"Desert Eagle | Eastern Enigma", "M4A4 | Falak"},
        new double[] {14.19, 21.92},
        new String[] {"arabesque-5-0", "arabesque-5-1"},
        new String[] {"AWP | Sovereign Flame", "AK-47 | Consequence of the Jinn"},
        new double[] {98.0, 115.74},
        new String[] {},
        new String[] {},
        new double[] {}),
    new ArmouryCollection(
        "The Spy Tech Collection",
        new String[] {
          "spy-tech-1-0",
          "spy-tech-1-1",
          "spy-tech-1-2",
          "spy-tech-1-3",
          "spy-tech-1-4",
          "spy-tech-1-5"
        },
        new String[] {
          "MP7 | Base-2",
          "Tec-9 | Perimeter",
          "MAC-10 | Video Cam",
          "SCAR-20 | Arctic Camo Panels",
          "XM1014 | Black Site",
          "FAMAS | Corp Defense"
        },
        new double[] {0.04, 0.03, 0.03, 0.03, 0.03, 0.04},
        new String[] {"spy-tech-2-0", "spy-tech-2-1", "spy-tech-2-2", "spy-tech-2-3"},
        new String[] {
          "R8 Revolver | Monarch",
          "AUG | Signal Scanner",
          "MP9 | Spy Prototype",
          "M4A4 | Dark Operative"
        },
        new double[] {0.3, 0.29, 0.31, 0.36},
        new String[] {"spy-tech-3-0", "spy-tech-3-1", "spy-tech-3-2"},
        new String[] {"CZ75-Auto | Hydraulics", "Nova | Smart Gun", "AWP | Black Box"},
        new double[] {2.24, 2.28, 3.73},
        new String[] {"spy-tech-4-0", "spy-tech-4-1"},
        new String[] {"USP-S | Spiral Glitch", "M4A1-S | Fatal Glitch"},
        new double[] {20.6, 20.32},
        new String[] {"spy-tech-5-0", "spy-tech-5-1"},
        new String[] {"AK-47 | AUTOEXEC", "Glock-18 | Ghost Protocol"},
        new double[] {156.0, 154.0},
        new String[] {},
        new String[] {},
        new double[] {})
  };
}
