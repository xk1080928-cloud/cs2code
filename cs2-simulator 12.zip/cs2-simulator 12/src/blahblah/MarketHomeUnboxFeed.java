package blahblah;

import blahblah.hGui.*;
import java.awt.*;
import java.awt.event.*;
import java.util.ArrayList;
import java.util.List;
import javax.swing.*;

/** Extracted reusable model or widget; behavior retained from the original source. */
final class MarketHomeUnboxFeed extends JPanel {
  private final hGui app;

  final List<HomeUnboxEntry> entries = new ArrayList<>();
  final javax.swing.Timer feedTimer, animationTimer;
  java.util.concurrent.ExecutorService worker;
  java.util.concurrent.Future<?> pending;
  volatile List<List<HomeUnboxSource>> sources;
  volatile long epoch;
  long insertedAt, lastSoldInsertedAt, soldMarketKeysRefreshedAt;
  List<String> soldMarketKeys = new ArrayList<>();
  boolean busy;
  final boolean soldFeed;
  static final int ROW_HEIGHT = 84;

  MarketHomeUnboxFeed(hGui app) {
    this(app, false);
  }

  MarketHomeUnboxFeed(hGui app, boolean soldFeed) {
    this.app = app;
    this.soldFeed = soldFeed;
    setName(soldFeed ? "marketHomeSoldFeed" : "marketHomeUnboxFeed");
    setOpaque(false);
    setPreferredSize(new Dimension(600, hGui.MARKET_HOME_UNBOX_ROWS * ROW_HEIGHT));
    setMaximumSize(new Dimension(Integer.MAX_VALUE, hGui.MARKET_HOME_UNBOX_ROWS * ROW_HEIGHT));
    setAlignmentX(Component.CENTER_ALIGNMENT);
    setToolTipText(
        soldFeed
            ? "Simulated sold feed: liquidity-weighted skins/cases/packages, spaced 0.03–0.15"
                  + " seconds apart while Home is open. Does not execute or record real sales."
            : "Live simulated openings at independently randomized 0.03–0.15 second delays while"
                + " Market Home is visible. Pauses elsewhere; each consumes a case/package.");
    feedTimer =
        new javax.swing.Timer(
            soldFeed
                ? app.marketHomeFeeds.nextHomeSoldDelay()
                : app.marketHomeFeeds.nextHomeUnboxDelay(),
            e -> requestNext());
    feedTimer.setCoalesce(true);
    feedTimer.setRepeats(false);
    animationTimer =
        new javax.swing.Timer(
            16,
            e -> {
              if (!isShowing() || System.nanoTime() - insertedAt >= 135000000L)
                animationTimerStop();
              repaint();
            });
    animationTimer.setCoalesce(true);
    addHierarchyListener(
        e -> {
          if ((e.getChangeFlags() & HierarchyEvent.SHOWING_CHANGED) != 0) updateActivity();
        });
  }

  void animationTimerStop() {
    animationTimer.stop();
  }

  void scheduleNext() {
    if (!isShowing() || busy) return;
    int delay =
        soldFeed
            ? app.marketHomeFeeds.nextHomeSoldDelay()
            : app.marketHomeFeeds.nextHomeUnboxDelay();
    feedTimer.setDelay(delay);
    feedTimer.setInitialDelay(delay);
    feedTimer.restart();
  }

  void updateActivity() {
    if (!soldFeed) {
      feedTimer.stop();
      if (isShowing()) {
        app.activeHomeArtworkFeeds.add(this);
        app.backgroundUnboxing.attach(this);
      } else {
        app.activeHomeArtworkFeeds.remove(this);
        app.backgroundUnboxing.detach(this);
        animationTimer.stop();
      }
      return;
    }
    if (isShowing()) app.activeHomeArtworkFeeds.add(this);
    else app.activeHomeArtworkFeeds.remove(this);
    if (isShowing()) {
      if (!soldFeed && (worker == null || worker.isShutdown()))
        worker =
            java.util.concurrent.Executors.newSingleThreadExecutor(
                r -> {
                  Thread thread = new Thread(r, "Market Home unbox feed");
                  thread.setDaemon(true);
                  return thread;
                });
      if (!feedTimer.isRunning() && !busy) scheduleNext();
    } else {
      feedTimer.stop();
      animationTimer.stop();
      epoch++;
      busy = false;
      if (pending != null) pending.cancel(true);
      pending = null;
      if (worker != null) worker.shutdownNow();
      worker = null;
    }
  }

  void requestNext() {
    if (!isShowing()) {
      updateActivity();
      return;
    }
    if (soldFeed) {
      requestNextSimulatedSale();
      return;
    }
    if (busy || worker == null || worker.isShutdown()) return;
    busy = true;
    final long ticket = epoch;
    pending =
        worker.submit(
            () -> {
              HomeUnboxEntry next = null;
              try {
                if (sources == null) sources = app.marketHomeFeeds.buildHomeUnboxSources();
                if (!Thread.currentThread().isInterrupted())
                  next = app.marketHomeFeeds.rollHomeUnbox(sources, true);
              } catch (RuntimeException ex) {
                System.err.println("Live unbox feed skipped an opening: " + ex.getMessage());
              }
              final HomeUnboxEntry result = next;
              SwingUtilities.invokeLater(
                  () -> {
                    if (ticket != epoch) return;
                    busy = false;
                    pending = null;
                    if (!isShowing()) return;
                    if (result != null) acceptEntry(result);
                    scheduleNext();
                  });
            });
  }

  void requestNextSimulatedSale() {
    // No backlog: one sampling attempt, one row maximum, then a new one-shot delay.
    long now = System.nanoTime();
    long remaining = hGui.MARKET_HOME_SOLD_MIN_INTERVAL * 1000000L - (now - lastSoldInsertedAt);
    if (lastSoldInsertedAt != 0 && remaining > 0) {
      int delay = Math.max(1, (int) ((remaining + 999999L) / 1000000L));
      feedTimer.setDelay(delay);
      feedTimer.setInitialDelay(delay);
      feedTimer.restart();
      return;
    }
    if (soldMarketKeys.isEmpty() || now - soldMarketKeysRefreshedAt >= 30000000000L) {
      soldMarketKeys = app.marketHomeFeeds.snapshotHomeMarketSkinKeys();
      soldMarketKeysRefreshedAt = now;
    }
    HomeUnboxEntry next = app.marketHomeFeeds.rollHomeMarketSale(soldMarketKeys, true);
    if (next != null) acceptEntry(next);
    else {
      soldMarketKeys.clear();
    } // Rebuild a stale/empty pool on the next delayed attempt.
    scheduleNext();
  }

  void acceptEntry(HomeUnboxEntry entry) {
    if (soldFeed) {
      long now = System.nanoTime();
      if (!isShowing()
          || (lastSoldInsertedAt != 0
              && now - lastSoldInsertedAt < hGui.MARKET_HOME_SOLD_MIN_INTERVAL * 1000000L)) return;
      lastSoldInsertedAt = now;
    }
    app.marketHomeFeeds.getHomeUnboxArtwork(entry.record.skinName, entry.record.condition);
    entry.record.timestamp = System.currentTimeMillis();
    entries.add(0, entry);
    while (entries.size() > hGui.MARKET_HOME_UNBOX_ROWS + 1) entries.remove(entries.size() - 1);
    insertedAt = System.nanoTime();
    animationTimer.restart();
    repaint();
  }

  String fitFeedText(Graphics2D g, String text, int width) {
    if (text == null) text = "";
    if (width <= 0) return "";
    if (g.getFontMetrics().stringWidth(text) <= width) return text;
    int end = text.length();
    while (end > 0 && g.getFontMetrics().stringWidth(text.substring(0, end) + "…") > width) end--;
    return end == 0 ? "" : text.substring(0, end) + "…";
  }

  @Override
  protected void paintComponent(Graphics graphics) {
    super.paintComponent(graphics);
    Graphics2D g = (Graphics2D) graphics.create();
    g.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
    g.setRenderingHint(
        RenderingHints.KEY_TEXT_ANTIALIASING, RenderingHints.VALUE_TEXT_ANTIALIAS_ON);
    if (entries.isEmpty()) {
      g.setColor(Theme.TEXT_DIM);
      g.setFont(Theme.CONSOLE_PLAIN_12);
      g.drawString(
          soldFeed ? "Waiting for the next sale…" : "Waiting for the next opening…", 18, 34);
      g.dispose();
      return;
    }
    double progress = Math.min(1, Math.max(0, (System.nanoTime() - insertedAt) / 135000000.0));
    int shift = (int) Math.round(ROW_HEIGHT * (1 - Math.pow(1 - progress, 3)));
    for (int i = 0; i < entries.size(); i++) {
      HomeUnboxEntry entry = entries.get(i);
      SaleRecord sale = entry.record;
      int y = (i - 1) * ROW_HEIGHT + shift, width = getWidth() - 2;
      if (y + ROW_HEIGHT < 0 || y >= getHeight()) continue;
      g.setColor(new Color(26, 33, 46));
      g.fillRoundRect(1, y + 1, width, ROW_HEIGHT - 7, 8, 8);
      g.setColor(
          sale.specialVariant == null
              ? app.itemInspectionScreen.getRarityColor(entry.rarity)
              : Color.CYAN);
      g.fillRoundRect(1, y + 1, 4, ROW_HEIGHT - 7, 4, 4);
      Image image = app.imageRepository.get(entry.imageKey);
      if (image == null) image = entry.image;
      if (image == null)
        image =
            app.imageRepository.get(
                app.artworkService.canonicalArtworkName(
                    app.artworkService.artworkSkin(entry.imageKey)));
      if (image != null && image.getWidth(null) > 0 && image.getHeight(null) > 0) {
        double scale = Math.min(76.0 / image.getWidth(null), 55.0 / image.getHeight(null));
        int w = Math.max(1, (int) (image.getWidth(null) * scale)),
            h = Math.max(1, (int) (image.getHeight(null) * scale));
        g.drawImage(image, 12 + (76 - w) / 2, y + 10 + (55 - h) / 2, w, h, null);
      }
      int textX = 100, textWidth = Math.max(0, width - textX - 142);
      Shape oldClip = g.getClip();
      g.clipRect(textX, y + 3, textWidth, ROW_HEIGHT - 9);
      g.setFont(Theme.CONSOLE_BOLD_12);
      g.setColor(sale.skinName.startsWith("StatTrak ") ? new Color(255, 153, 51) : Theme.TEXT);
      g.drawString(fitFeedText(g, sale.skinName, textWidth), textX, y + 19);
      g.setFont(Theme.CONSOLE_PLAIN_9);
      g.setColor(Theme.TEXT_DIM);
      g.drawString(
          sale.condition
              + ("Normal".equals(sale.condition)
                  ? ""
                  : String.format("  Float: %.6f", sale.itemFloat)),
          textX,
          y + 35);
      g.drawString(
          fitFeedText(g, (soldFeed ? "BOUGHT BY: " : "UNBOXED BY: ") + sale.buyerName, textWidth),
          textX,
          y + 50);
      g.setColor(Theme.ACCENT_CT);
      g.drawString(fitFeedText(g, sale.marketplaceName, textWidth), textX, y + 65);
      g.setClip(oldClip);
      g.setFont(Theme.CONSOLE_BOLD_14);
      g.setColor(new Color(255, 216, 90));
      String price = String.format("$%,.2f", sale.price);
      g.drawString(
          price, Math.max(textX, width - g.getFontMetrics().stringWidth(price) - 14), y + 31);
      g.setFont(Theme.CONSOLE_PLAIN_9);
      g.setColor(Theme.TEXT_DIM);
      long age = Math.max(0, (System.currentTimeMillis() - sale.timestamp) / 1000);
      String time = age == 0 ? (soldFeed ? "JUST SOLD" : "JUST UNBOXED") : age + "s ago";
      g.drawString(
          time, Math.max(textX, width - g.getFontMetrics().stringWidth(time) - 14), y + 52);
    }
    g.dispose();
  }
}
