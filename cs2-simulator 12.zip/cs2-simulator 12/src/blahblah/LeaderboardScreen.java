package blahblah;

import blahblah.hGui.*;
import java.awt.*;
import java.awt.event.*;
import java.util.ArrayList;
import java.util.Comparator;
import java.util.List;
import javax.swing.*;

/** Leaderboard Screen: focused feature implementation. */
final class LeaderboardScreen {
  private final hGui app;

  LeaderboardScreen(hGui app) {
    this.app = app;
  }

  void showLeaderboard() {
    app.leaderboardService.refreshAllLeaderboardMarketValues();
    app.leaderboardService.normalizeNpcLeaderboardBands();

    boolean playerInLeaderboard = false;
    for (LeaderboardEntry entry : app.globalLeaderboard) {
      if (entry.isPlayer) {
        entry.inventoryValue = app.inventoryValue;
        playerInLeaderboard = true;
        break;
      }
    }

    if (!playerInLeaderboard && app.inventoryValue > 0) {
      app.globalLeaderboard.add(
          new LeaderboardEntry("YOU", app.inventoryValue, app.playerAvatar, true));
    }

    app.globalLeaderboard.sort((a, b) -> Double.compare(b.inventoryValue, a.inventoryValue));
    for (int i = 0; i < app.globalLeaderboard.size(); i++) {
      app.globalLeaderboard.get(i).rank = i + 1;
    }

    int playerRank = -1;
    boolean hasInventoryValue = app.inventoryValue > 0;

    for (LeaderboardEntry entry : app.globalLeaderboard) {
      if (entry.isPlayer) {
        playerRank = entry.rank;
        break;
      }
    }

    final int finalPlayerRank = playerRank;
    final boolean finalHasInventoryValue = hasInventoryValue;

    JFrame leaderboardFrame = new JFrame("Global Leaderboard");
    leaderboardFrame.setSize(860, 800);
    leaderboardFrame.setLocationRelativeTo(app);
    leaderboardFrame.setLayout(new BorderLayout());

    JPanel headerPanel = new JPanel(new GridLayout(2, 1));
    headerPanel.setBackground(new Color(30, 30, 35));
    headerPanel.setBorder(BorderFactory.createEmptyBorder(10, 10, 10, 10));

    JLabel titleLabel = new JLabel("GLOBAL LEADERBOARD", SwingConstants.CENTER);
    titleLabel.setFont(new Font("Arial", Font.BOLD, 24));
    titleLabel.setForeground(Theme.GOLD);

    String rankText =
        finalHasInventoryValue && finalPlayerRank != -1
            ? String.format("Your Rank: #%d / %d", finalPlayerRank, app.globalLeaderboard.size())
            : "Your Rank: N/A (Build inventory to rank)";

    JLabel yourRankLabel = new JLabel(rankText, SwingConstants.CENTER);
    yourRankLabel.setFont(new Font("Arial", Font.BOLD, 18));
    yourRankLabel.setForeground(
        finalHasInventoryValue && finalPlayerRank != -1
            ? (finalPlayerRank <= 100
                ? Color.GREEN
                : finalPlayerRank <= 1000 ? Color.CYAN : Color.WHITE)
            : Color.GRAY);

    headerPanel.add(titleLabel);
    headerPanel.add(yourRankLabel);
    leaderboardFrame.add(headerPanel, BorderLayout.NORTH);

    JPanel listPanel = new JPanel();
    listPanel.setLayout(new BoxLayout(listPanel, BoxLayout.Y_AXIS));
    listPanel.setBackground(new Color(35, 35, 40));

    int startIdx = 0;
    int endIdx = 0;
    boolean showTopSeparately = false;

    if (finalHasInventoryValue && finalPlayerRank != -1) {

      startIdx = Math.max(0, finalPlayerRank - 26);
      endIdx = Math.min(app.globalLeaderboard.size(), finalPlayerRank + 24);

      showTopSeparately = finalPlayerRank > 35;
    } else {

      startIdx = 0;
      endIdx = Math.min(50, app.globalLeaderboard.size());
    }

    final int finalStartIdx = startIdx;

    if (showTopSeparately) {
      for (int i = 0; i < Math.min(10, app.globalLeaderboard.size()); i++) {
        LeaderboardEntry entry = app.globalLeaderboard.get(i);
        JPanel entryPanel = app.leaderboardScreen.createLeaderboardEntryPanel(entry);
        listPanel.add(entryPanel);
        listPanel.add(Box.createRigidArea(new Dimension(0, 2)));
      }

      JPanel separator = new JPanel();
      separator.setMaximumSize(new Dimension(Integer.MAX_VALUE, 30));
      separator.setBackground(new Color(35, 35, 40));
      JLabel sepLabel = new JLabel("...", SwingConstants.CENTER);
      sepLabel.setForeground(Color.GRAY);
      sepLabel.setFont(new Font("Arial", Font.BOLD, 20));
      separator.add(sepLabel);
      listPanel.add(separator);
    }

    for (int i = startIdx; i < endIdx; i++) {
      LeaderboardEntry entry = app.globalLeaderboard.get(i);
      JPanel entryPanel = app.leaderboardScreen.createLeaderboardEntryPanel(entry);
      listPanel.add(entryPanel);
      listPanel.add(Box.createRigidArea(new Dimension(0, 2)));
    }

    JScrollPane scrollPane = new JScrollPane(listPanel);
    scrollPane.getVerticalScrollBar().setUnitIncrement(16);
    scrollPane.setBorder(null);
    leaderboardFrame.add(scrollPane, BorderLayout.CENTER);

    if (finalHasInventoryValue && finalPlayerRank != -1) {
      SwingUtilities.invokeLater(
          () -> {
            int scrollPosition = Math.max(0, (finalPlayerRank - finalStartIdx - 10) * 62);
            scrollPane.getVerticalScrollBar().setValue(scrollPosition);
          });
    }
    leaderboardFrame.setVisible(true);
  }

  void showLeaderboardInventory(LeaderboardEntry entry) {
    if (!entry.isPlayer) {
      app.leaderboardService.refreshLeaderboardEntryMarketValues(entry);
    }
    List<InventoryItem> sourceItems =
        entry.isPlayer ? new ArrayList<>(app.inventoryList) : new ArrayList<>(entry.inventoryItems);
    String inventoryOwner = entry.isPlayer ? "YOU" : entry.username;
    for (InventoryItem item : sourceItems) {
      app.ownershipHistoryService.ensureTrackedHistoryForDisplay(item, inventoryOwner);
    }
    if (sourceItems.isEmpty()) {
      JOptionPane.showMessageDialog(app, entry.username + " has no visible inventory.");
      return;
    }

    JFrame invFrame = new JFrame(entry.username + " Inventory");
    invFrame.setSize(900, 620);
    invFrame.setLocationRelativeTo(app);
    invFrame.setLayout(new BorderLayout());
    invFrame.setAlwaysOnTop(true);
    invFrame.getContentPane().setBackground(Theme.BG_DARK);

    JPanel controlPanel = new JPanel(new GridLayout(3, 1));
    controlPanel.setBackground(Theme.BG_PANEL);
    controlPanel.setBorder(BorderFactory.createMatteBorder(0, 0, 1, 0, Theme.BORDER));

    JPanel searchPanel = app.uiWidgets.createControlRow();
    JLabel searchLabel = app.uiWidgets.createControlLabel("Search:", true);
    JComboBox<String> searchField = app.searchControls.createSearchFieldWithHistory(20);
    searchPanel.add(searchLabel);
    searchPanel.add(searchField);

    JPanel sortPanel = app.uiWidgets.createControlRow();
    JLabel sortPriceLabel = app.uiWidgets.createControlLabel("Price:", false);
    JComboBox<String> priceSortBox =
        app.uiWidgets.createComboBox(new String[] {"Default", "Highest Price", "Lowest Price"});

    JLabel sortRarityLabel = app.uiWidgets.createControlLabel("Rarity:", false);
    JComboBox<String> raritySortBox =
        app.uiWidgets.createComboBox(
            new String[] {
              "Default",
              "Agents",
              "Knife",
              "Gloves",
              "Covert",
              "Classified",
              "Restricted",
              "Milspec"
            });

    JLabel sortFloatLabel = app.uiWidgets.createControlLabel("Float:", false);
    JComboBox<String> floatSortBox =
        app.uiWidgets.createComboBox(new String[] {"Default", "Lowest Float", "Highest Float"});

    java.util.Set<String> colSetInv = new java.util.LinkedHashSet<>();
    colSetInv.add("All");
    for (InventoryItem it : sourceItems) {
      app.inventoryScreen.resolveInventoryItemCollection(it);
      if (it.collection != null && !it.collection.isEmpty()) colSetInv.add(it.collection);
    }
    JLabel sortColLabel = app.uiWidgets.createControlLabel("Collection:", false);
    JComboBox<String> collectionSortBox =
        app.uiWidgets.createComboBox(colSetInv.toArray(new String[0]));

    JLabel invValueLabel =
        new JLabel(
            String.format(
                "  Total: $%,.2f (%d items)",
                app.leaderboardService.calculateInventoryTotal(sourceItems), sourceItems.size()));
    invValueLabel.setForeground(Theme.ACCENT_CT);
    invValueLabel.setFont(Theme.CONSOLE_BOLD_12);

    sortPanel.add(sortPriceLabel);
    sortPanel.add(priceSortBox);
    sortPanel.add(sortRarityLabel);
    sortPanel.add(raritySortBox);
    sortPanel.add(sortFloatLabel);
    sortPanel.add(floatSortBox);
    sortPanel.add(sortColLabel);
    sortPanel.add(collectionSortBox);

    JPanel infoPanel = app.uiWidgets.createControlRow();
    infoPanel.add(invValueLabel);

    controlPanel.add(searchPanel);
    controlPanel.add(sortPanel);
    controlPanel.add(infoPanel);
    invFrame.add(controlPanel, BorderLayout.NORTH);

    JPanel grid = new JPanel(new GridLayout(0, 1, 8, 8));
    grid.setBackground(Theme.BG_DARK);
    grid.setBorder(BorderFactory.createEmptyBorder(8, 8, 8, 8));

    JScrollPane scroll = new JScrollPane(grid);
    scroll.setHorizontalScrollBarPolicy(ScrollPaneConstants.HORIZONTAL_SCROLLBAR_NEVER);
    scroll.setBackground(Theme.BG_DARK);
    scroll.getViewport().setBackground(Theme.BG_DARK);
    app.tradeCards.optimizeScrollPane(scroll);
    scroll.setBorder(BorderFactory.createLineBorder(Theme.BORDER, 1));
    scroll
        .getViewport()
        .addComponentListener(
            new java.awt.event.ComponentAdapter() {
              @Override
              public void componentResized(java.awt.event.ComponentEvent e) {
                app.inventoryCards.updateInventoryGridCardWidths(grid, scroll);
              }
            });
    invFrame.add(scroll, BorderLayout.CENTER);

    Runnable rebuildGrid =
        () -> {
          grid.removeAll();
          scroll.setColumnHeaderView(null);

          String searchText = app.searchControls.getSearchText(searchField);
          String priceOrder = (String) priceSortBox.getSelectedItem();
          String raritySelection = (String) raritySortBox.getSelectedItem();
          String floatOrder = (String) floatSortBox.getSelectedItem();
          String collectionOrder = (String) collectionSortBox.getSelectedItem();

          List<InventoryItem> filtered = new ArrayList<>(sourceItems);
          if (!searchText.isEmpty()) {
            filtered.removeIf(
                item ->
                    !item.name.toLowerCase().contains(searchText)
                        && !item.condition.toLowerCase().contains(searchText)
                        && !item.rarity.toLowerCase().contains(searchText));
          }
          if ("Agents".equals(raritySelection)) {
            filtered.removeIf(it -> !app.itemMetadataService.isAgentSkin(it.name));
          } else if (!"Default".equals(raritySelection)) {
            filtered.removeIf(it -> !it.rarity.contains(raritySelection));
          }
          if (!"All".equals(collectionOrder)) {
            filtered.removeIf(it -> !collectionOrder.equals(it.collection));
          }

          filtered.sort(
              (a, b) ->
                  Integer.compare(
                      CoreUtilities.rarityRank(a.rarity), CoreUtilities.rarityRank(b.rarity)));

          if ("Highest Price".equals(priceOrder)) {
            filtered.sort((a, b) -> b.price.compareTo(a.price));
          } else if ("Lowest Price".equals(priceOrder)) {
            filtered.sort(Comparator.comparing(a -> a.price));
          }
          if ("Lowest Float".equals(floatOrder)) {
            filtered.sort((a, b) -> Double.compare(a.itemFloat, b.itemFloat));
          } else if ("Highest Float".equals(floatOrder)) {
            filtered.sort((a, b) -> Double.compare(b.itemFloat, a.itemFloat));
          }

          app.inventoryScreen.setPagedInventoryItems(
              grid,
              scroll,
              filtered,
              item ->
                  app.inventoryCards.createInventoryCardFast(
                      item, item.getThumb110(), entry.isPlayer),
              0);
        };

    javax.swing.Timer searchTimer =
        app.searchControls.createSearchHistoryTimer(searchField, rebuildGrid);
    app.searchControls.installSearchHistoryHandlers(searchField, searchTimer, rebuildGrid);
    priceSortBox.addActionListener(e -> rebuildGrid.run());
    raritySortBox.addActionListener(e -> rebuildGrid.run());
    floatSortBox.addActionListener(e -> rebuildGrid.run());
    collectionSortBox.addActionListener(e -> rebuildGrid.run());

    SwingUtilities.invokeLater(rebuildGrid);
    invFrame.setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
    invFrame.addWindowListener(
        new java.awt.event.WindowAdapter() {
          @Override
          public void windowClosed(java.awt.event.WindowEvent e) {
            app.inventoryScreen.releaseInventoryGridCaches(grid);
          }
        });

    invFrame.setVisible(true);

    javax.swing.Timer timer =
        new javax.swing.Timer(
            100,
            e -> {
              invFrame.setAlwaysOnTop(false);
              invFrame.toFront();
              invFrame.requestFocus();
            });
    timer.setRepeats(false);
    timer.start();
  }

  JPanel createLeaderboardEntryPanel(LeaderboardEntry entry) {
    JPanel entryPanel = new JPanel(new BorderLayout(10, 0));
    entryPanel.setMaximumSize(new Dimension(Integer.MAX_VALUE, 74));
    entryPanel.setBackground(entry.isPlayer ? new Color(50, 100, 50) : new Color(45, 45, 50));
    entryPanel.setBorder(
        BorderFactory.createLineBorder(
            entry.isPlayer ? Color.GREEN : Color.GRAY, entry.isPlayer ? 3 : 1));

    JLabel rankLabel = new JLabel("#" + entry.rank);
    rankLabel.setFont(new Font("Arial", Font.BOLD, 20));
    rankLabel.setForeground(
        entry.rank <= 3
            ? Theme.GOLD
            : entry.rank <= 10
                ? new Color(192, 192, 192)
                : entry.rank <= 100 ? new Color(205, 127, 50) : Color.WHITE);
    rankLabel.setBorder(BorderFactory.createEmptyBorder(0, 15, 0, 15));

    JPanel infoPanel = new JPanel(new FlowLayout(FlowLayout.LEFT, 10, 12));
    infoPanel.setBackground(entryPanel.getBackground());
    if (entry.avatar != null) {
      infoPanel.add(new JLabel(new ImageIcon(HighQualityImages.fit(entry.avatar, 40, 40))));
    } else {
      JLabel avatarFallback = new JLabel("?");
      avatarFallback.setPreferredSize(new Dimension(40, 40));
      avatarFallback.setHorizontalAlignment(SwingConstants.CENTER);
      avatarFallback.setForeground(Color.WHITE);
      avatarFallback.setFont(new Font("Arial", Font.BOLD, 20));
      avatarFallback.setBorder(BorderFactory.createLineBorder(Color.GRAY, 1));
      infoPanel.add(avatarFallback);
    }
    JLabel nameLabel = new JLabel(entry.username);
    nameLabel.setFont(new Font("Arial", Font.BOLD, 16));
    nameLabel.setForeground(entry.isPlayer ? Color.GREEN : Color.WHITE);
    infoPanel.add(nameLabel);

    JPanel rightPanel = new JPanel();
    rightPanel.setLayout(new BoxLayout(rightPanel, BoxLayout.X_AXIS));
    rightPanel.setBackground(entryPanel.getBackground());
    rightPanel.setBorder(BorderFactory.createEmptyBorder(8, 8, 8, 12));

    JLabel valueLabel = new JLabel("$" + String.format("%,.2f", entry.inventoryValue));
    valueLabel.setFont(new Font("Arial", Font.BOLD, 16));
    valueLabel.setForeground(Color.YELLOW);
    valueLabel.setBorder(BorderFactory.createEmptyBorder(0, 0, 0, 12));
    rightPanel.add(valueLabel);

    JButton inventoryButton = new JButton("INVENTORY");
    app.uiWidgets.styleButton(
        inventoryButton, new Color(30, 90, 120), Theme.TEXT, new Color(70, 150, 190));
    inventoryButton.setPreferredSize(new Dimension(120, 32));
    inventoryButton.setMinimumSize(new Dimension(120, 32));
    inventoryButton.setMaximumSize(new Dimension(120, 32));
    inventoryButton.addActionListener(e -> app.leaderboardScreen.showLeaderboardInventory(entry));
    rightPanel.add(inventoryButton);

    entryPanel.add(rankLabel, BorderLayout.WEST);
    entryPanel.add(infoPanel, BorderLayout.CENTER);
    entryPanel.add(rightPanel, BorderLayout.EAST);

    return entryPanel;
  }
}
