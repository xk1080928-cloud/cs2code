package blahblah;

import blahblah.hGui.*;
import java.awt.*;
import java.awt.event.*;
import java.util.ArrayList;
import java.util.HashSet;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.stream.Collectors;
import javax.swing.*;

/** Market Home Screen: focused feature implementation. */
final class MarketHomeScreen {
  private final hGui app;
  private final java.util.concurrent.atomic.AtomicBoolean summaryRefreshQueued =
      new java.util.concurrent.atomic.AtomicBoolean();

  MarketHomeScreen(hGui app) {
    this.app = app;
  }

  void createMarketplaceHomeContent(JPanel homeContent, JFrame parent) {
    JPanel hero = new JPanel(new BorderLayout(18, 0));
    hero.setBackground(new Color(24, 31, 44));
    hero.setBorder(
        BorderFactory.createCompoundBorder(
            BorderFactory.createLineBorder(new Color(54, 66, 92), 1),
            BorderFactory.createEmptyBorder(20, 22, 20, 22)));

    JPanel heroText = new JPanel();
    heroText.setOpaque(false);
    heroText.setLayout(new BoxLayout(heroText, BoxLayout.Y_AXIS));
    JLabel heroTitle = new JLabel("Market Overview");
    heroTitle.setFont(new Font("Arial", Font.BOLD, 30));
    heroTitle.setForeground(Color.WHITE);
    JLabel heroSubtitle =
        new JLabel(
            "Browse featured skins, watch fresh unboxes, and jump into the busiest markets.");
    heroSubtitle.setFont(new Font("Arial", Font.PLAIN, 14));
    heroSubtitle.setForeground(new Color(180, 194, 220));
    heroText.add(heroTitle);
    heroText.add(Box.createRigidArea(new Dimension(0, 8)));
    heroText.add(heroSubtitle);

    JPanel heroStats = new JPanel(new GridLayout(1, 3, 12, 0));
    heroStats.setOpaque(false);
    int totalListings = app.marketStockService.getTotalMarketListingCount();
    double bestRecentUnbox =
        app.recentUnboxedSkins.stream().mapToDouble(s -> s.price).max().orElse(0.0);
    heroStats.add(
        app.marketHomeScreen.createMarketplaceHomeStatCard(
            "Tracked Skins",
            String.valueOf(app.marketHomeScreen.getTrackedMarketSkinCount()),
            Theme.ACCENT_CT));
    heroStats.add(
        app.marketHomeScreen.createMarketplaceHomeStatCard(
            "Open Listings", String.valueOf(totalListings), new Color(120, 223, 79)));
    heroStats.add(
        app.marketHomeScreen.createMarketplaceHomeStatCard(
            "Top Recent Unbox",
            "$" + String.format("%.2f", bestRecentUnbox),
            new Color(255, 186, 92)));

    hero.add(heroText, BorderLayout.CENTER);
    hero.add(heroStats, BorderLayout.SOUTH);
    hero.setMaximumSize(new Dimension(Integer.MAX_VALUE, 190));
    homeContent.add(hero);
    homeContent.add(Box.createRigidArea(new Dimension(0, 18)));

    homeContent.add(
        app.marketHomeScreen.createMarketplaceHomeSectionLabel("Recently Unboxed Skins"));
    homeContent.add(new MarketHomeUnboxFeed(app));
    homeContent.add(Box.createRigidArea(new Dimension(0, 18)));
    homeContent.add(app.marketHomeScreen.createMarketplaceHomeSectionLabel("Recently Sold Skins"));
    homeContent.add(new MarketHomeUnboxFeed(app, true));
    homeContent.add(Box.createRigidArea(new Dimension(0, 18)));

    homeContent.add(
        app.marketHomeScreen.createMarketplaceHomeSectionLabel(
            app.exchangePendingSale == null
                ? "Marketplaces"
                : "Choose a marketplace to sell " + app.exchangePendingSale.name));
    JPanel marketsGrid = new JPanel(new GridLayout(0, 5, 12, 12));
    marketsGrid.setOpaque(false);
    marketsGrid.setAlignmentX(Component.CENTER_ALIGNMENT);
    for (MarketplaceOfferAggregate aggregate :
        app.marketHomeScreen.getTopMarketplaceSummaries(Integer.MAX_VALUE)) {
      marketsGrid.add(app.marketHomeScreen.createMarketplaceHomeMarketCard(aggregate));
    }
    marketsGrid.setMaximumSize(new Dimension(Integer.MAX_VALUE, 900));
    homeContent.add(marketsGrid);
    homeContent.putClientProperty(
        "refreshHomeStats",
        (Runnable)
            () -> {
              String[] values = {
                String.valueOf(app.marketHomeScreen.getTrackedMarketSkinCount()),
                String.valueOf(app.marketStockService.getTotalMarketListingCount()),
                "$"
                    + String.format(
                        "%.2f",
                        app.recentUnboxedSkins.stream()
                            .mapToDouble(record -> record.price)
                            .max()
                            .orElse(0))
              };
              for (int i = 0; i < heroStats.getComponentCount(); i++) {
                Object label =
                    ((JPanel) heroStats.getComponent(i)).getClientProperty("homeStatValue");
                if (label instanceof JLabel) ((JLabel) label).setText(values[i]);
              }
              marketsGrid.removeAll();
              for (MarketplaceOfferAggregate aggregate :
                  app.marketHomeScreen.getTopMarketplaceSummaries(Integer.MAX_VALUE))
                marketsGrid.add(app.marketHomeScreen.createMarketplaceHomeMarketCard(aggregate));
              marketsGrid.revalidate();
              marketsGrid.repaint();
            });
  }

  JLabel createMarketplaceHomeSectionLabel(String text) {
    JLabel label = new JLabel(text, SwingConstants.CENTER);
    label.setFont(new Font("Arial", Font.BOLD, 20));
    label.setForeground(Color.WHITE);
    label.setBorder(BorderFactory.createEmptyBorder(0, 2, 10, 2));
    label.setAlignmentX(Component.CENTER_ALIGNMENT);
    label.setHorizontalAlignment(SwingConstants.CENTER);
    return label;
  }

  JPanel createMarketplaceHomeStatCard(String label, String value, Color accent) {
    JPanel card = new JPanel();
    card.setLayout(new BoxLayout(card, BoxLayout.Y_AXIS));
    card.setBackground(new Color(17, 22, 32));
    card.setBorder(
        BorderFactory.createCompoundBorder(
            BorderFactory.createMatteBorder(3, 0, 0, 0, accent),
            BorderFactory.createEmptyBorder(12, 12, 12, 12)));
    JLabel top = new JLabel(label);
    top.setForeground(new Color(166, 178, 204));
    top.setFont(new Font("Arial", Font.PLAIN, 12));
    JLabel bottom = new JLabel(value);
    bottom.setForeground(Color.WHITE);
    bottom.setFont(new Font("Arial", Font.BOLD, 20));
    card.add(top);
    card.add(Box.createRigidArea(new Dimension(0, 8)));
    card.add(bottom);
    card.putClientProperty("homeStatValue", bottom);
    return card;
  }

  JPanel createMarketplaceHomeEmptyState(String text) {
    JPanel panel = new JPanel(new BorderLayout());
    panel.setBackground(new Color(26, 31, 41));
    panel.setBorder(
        BorderFactory.createCompoundBorder(
            BorderFactory.createLineBorder(new Color(50, 56, 72), 1),
            BorderFactory.createEmptyBorder(18, 18, 18, 18)));
    JLabel label = new JLabel("<html><div style='width:760px;'>" + text + "</div></html>");
    label.setForeground(new Color(190, 198, 214));
    label.setFont(new Font("Arial", Font.PLAIN, 13));
    panel.add(label, BorderLayout.CENTER);
    panel.setMaximumSize(new Dimension(Integer.MAX_VALUE, 86));
    return panel;
  }

  java.util.List<SaleRecord> getRandomRecentUnboxSlots(int limit) {
    ArrayList<SaleRecord> shuffled = new ArrayList<>(app.recentUnboxedSkins);
    java.util.Collections.shuffle(shuffled, hGui.random);
    ArrayList<SaleRecord> picked = new ArrayList<>();
    Set<String> seenSkins = new HashSet<>();
    app.marketHomeScreen.addRandomUnboxSlotFromCategory(
        picked, shuffled, seenSkins, limit, true, false);
    app.marketHomeScreen.addRandomUnboxSlotFromCategory(
        picked, shuffled, seenSkins, limit, true, false);
    app.marketHomeScreen.addRandomUnboxSlotFromCategory(
        picked, shuffled, seenSkins, limit, false, true);
    app.marketHomeScreen.addRandomUnboxSlotFromCategory(
        picked, shuffled, seenSkins, limit, false, true);
    for (SaleRecord unbox : shuffled) {
      if (unbox == null || unbox.skinName == null) continue;
      String key =
          app.leaderboardService.normalizeSkinName(unbox.skinName.replace("StatTrak ", ""));
      if (seenSkins.add(key)) {
        picked.add(unbox);
        if (picked.size() >= limit) break;
      }
    }
    if (picked.size() < limit) {
      for (SaleRecord unbox : shuffled) {
        if (unbox == null || picked.contains(unbox)) continue;
        picked.add(unbox);
        if (picked.size() >= limit) break;
      }
    }
    return picked;
  }

  void addRandomUnboxSlotFromCategory(
      ArrayList<SaleRecord> picked,
      ArrayList<SaleRecord> source,
      Set<String> seenSkins,
      int limit,
      boolean rareOnly,
      boolean armouryOnly) {
    if (picked.size() >= limit) return;
    for (SaleRecord unbox : source) {
      if (unbox == null || unbox.skinName == null || picked.contains(unbox)) continue;
      if (rareOnly && !app.marketHomeScreen.isRareRecentUnbox(unbox)) continue;
      if (armouryOnly && !app.marketHomeScreen.isArmouryRecentUnbox(unbox)) continue;
      String key =
          app.leaderboardService.normalizeSkinName(unbox.skinName.replace("StatTrak ", ""));
      if (seenSkins.add(key)) {
        picked.add(unbox);
        return;
      }
    }
  }

  boolean isRareRecentUnbox(SaleRecord unbox) {
    if (unbox == null || unbox.skinName == null) return false;
    String cleanName = unbox.skinName.replace("StatTrak ", "").trim();
    String rarity = app.itemMetadataService.getSkinRarity(cleanName);
    return "Knife".equals(rarity)
        || "Gloves".equals(rarity)
        || "Covert".equals(rarity)
        || (unbox.specialVariant != null && !unbox.specialVariant.trim().isEmpty());
  }

  boolean isArmouryRecentUnbox(SaleRecord unbox) {
    if (unbox == null || unbox.skinName == null) return false;
    String cleanName = unbox.skinName.replace("StatTrak ", "").trim();
    int suffixIdx = cleanName.indexOf(" (");
    if (suffixIdx > 0) cleanName = cleanName.substring(0, suffixIdx).trim();
    return app.itemMetadataService.isArmourySkin(cleanName);
  }

  int getTrackedMarketSkinCount() {
    return app.trackedMarketSkinCount;
  }

  void refreshMarketplaceSummarySnapshot() {
    if (SwingUtilities.isEventDispatchThread() && app.marketInitialized && app.isDisplayable()) {
      if (summaryRefreshQueued.compareAndSet(false, true))
        new SwingWorker<Void, Void>() {
          protected Void doInBackground() {
            try {
              refreshMarketplaceSummarySnapshot();
            } finally {
              summaryRefreshQueued.set(false);
            }
            return null;
          }
        }.execute();
      return;
    }
    app.marketGroupingService.prepareBrowseIndex();
    if (app.cs2ShellEnabled && app.marketInitialized && !SwingUtilities.isEventDispatchThread())
      app.exchangeStockService.rebuildExchangeIndex();
    app.marketplaceSummarySnapshot =
        app.marketHomeScreen.computeTopMarketplaceSummaries(Integer.MAX_VALUE);
    Set<String> names = new HashSet<>();
    for (String key : app.globalMarketListings.keySet())
      names.add(app.marketGroupingService.getMarketplaceBrowseKey(key));
    app.trackedMarketSkinCount = names.size();
  }

  java.util.List<MarketplaceOfferAggregate> getTopMarketplaceSummaries(int limit) {
    List<MarketplaceOfferAggregate> values = app.marketplaceSummarySnapshot;
    if (values == null) return java.util.Collections.emptyList();
    return new ArrayList<>(values.subList(0, Math.min(Math.max(0, limit), values.size())));
  }

  java.util.List<MarketplaceOfferAggregate> computeTopMarketplaceSummaries(int limit) {
    Map<String, MarketplaceOfferAggregate> grouped = new LinkedHashMap<>();
    int summarized = 0, bucketTotal = app.globalMarketListings.size();
    for (ArrayList<MarketListing> listings : new ArrayList<>(app.globalMarketListings.values())) {
      if (listings == null) continue;
      if (app.startupWorkStarted && !app.marketInitialized && (++summarized % 64 == 0))
        app.startupScreen.setStartupProgress(
            97,
            "Summarizing market statistics ("
                + summarized
                + " / "
                + bucketTotal
                + " skin variants)...");
      synchronized (listings) {
        for (MarketListing listing : listings.toArray(new MarketListing[0])) {
          if (listing == null || listing.isPlayerListing || listing.quantity < 1) continue;
          String key = listing.marketplaceName != null ? listing.marketplaceName : "Marketplace";
          MarketplaceOfferAggregate aggregate = grouped.get(key);
          if (aggregate == null) {
            MarketplaceOfferAggregate offer = new MarketplaceOfferAggregate();
            MarketplaceProfile profile = MarketplaceProfile.byName(key);
            offer.marketplaceName = key;
            offer.marketplaceType =
                listing.marketplaceType != null ? listing.marketplaceType : profile.type;
            offer.lowestPrice = listing.getPrice();
            offer.rating =
                listing.marketplaceRating > 0 ? listing.marketplaceRating : profile.rating;
            offer.reviews =
                listing.marketplaceReviews != null ? listing.marketplaceReviews : profile.reviews;
            offer.promoted = listing.promoted || profile.promoted;
            offer.accent = profile.accent;
            offer.accentAlt = profile.accentAlt;
            grouped.put(key, offer);
            aggregate = offer;
          }
          aggregate.listingCount += app.exchangeStockService.stockUnits(listing);
          double ask = listing.getPrice();
          if (Double.isFinite(ask) && ask > 0) {
            if (!Double.isFinite(aggregate.lowestPrice)) aggregate.lowestPrice = ask;
            aggregate.lowestPrice = Math.min(aggregate.lowestPrice, ask);
            aggregate.totalValue += ask * app.exchangeStockService.stockUnits(listing);
          }
        }
      }
    }
    return grouped.values().stream()
        .sorted(
            (a, b) -> {
              int countCompare = Integer.compare(b.listingCount, a.listingCount);
              if (countCompare != 0) return countCompare;
              return Double.compare(a.lowestPrice, b.lowestPrice);
            })
        .limit(limit)
        .collect(Collectors.toList());
  }

  JPanel createMarketplaceHomeMarketCard(MarketplaceOfferAggregate aggregate) {
    JPanel card = new JPanel(new BorderLayout(0, 10));
    card.setBackground(new Color(23, 29, 40));
    card.setBorder(
        BorderFactory.createCompoundBorder(
            BorderFactory.createLineBorder(aggregate.accent, 1),
            BorderFactory.createEmptyBorder(14, 14, 14, 14)));
    JLabel title = new JLabel(aggregate.marketplaceName, SwingConstants.CENTER);
    title.setForeground(Color.WHITE);
    title.setFont(new Font("Arial", Font.BOLD, 18));
    title.setAlignmentX(Component.CENTER_ALIGNMENT);
    JLabel meta =
        new JLabel(
            String.format("%.1f  •  %s", aggregate.rating, aggregate.marketplaceType),
            SwingConstants.CENTER);
    meta.setForeground(new Color(180, 194, 220));
    meta.setFont(new Font("Arial", Font.PLAIN, 12));
    meta.setAlignmentX(Component.CENTER_ALIGNMENT);
    JLabel offers =
        new JLabel(String.format("%d listings", aggregate.listingCount), SwingConstants.CENTER);
    offers.setForeground(Theme.ACCENT_CT);
    offers.setFont(new Font("Arial", Font.BOLD, 13));
    offers.setAlignmentX(Component.CENTER_ALIGNMENT);
    JLabel floorCaption = new JLabel("Total value", SwingConstants.CENTER);
    floorCaption.setForeground(new Color(200, 190, 140));
    floorCaption.setFont(new Font("Arial", Font.PLAIN, 11));
    floorCaption.setAlignmentX(Component.CENTER_ALIGNMENT);
    JLabel floor = new JLabel(String.format("$%,.2f", aggregate.totalValue), SwingConstants.CENTER);
    floor.setForeground(new Color(255, 222, 104));
    floor.setFont(new Font("Arial", Font.BOLD, 16));
    floor.setAlignmentX(Component.CENTER_ALIGNMENT);
    JPanel text = new JPanel();
    text.setOpaque(false);
    text.setLayout(new BoxLayout(text, BoxLayout.Y_AXIS));
    text.add(title);
    text.add(Box.createRigidArea(new Dimension(0, 4)));
    text.add(meta);
    text.add(Box.createRigidArea(new Dimension(0, 10)));
    text.add(offers);
    text.add(Box.createRigidArea(new Dimension(0, 6)));
    text.add(floorCaption);
    text.add(Box.createRigidArea(new Dimension(0, 2)));
    text.add(floor);
    card.add(text, BorderLayout.CENTER);
    JButton browse =
        app.exchangeWidgets.exchangeButton(
            MarketplaceProfile.byName(aggregate.marketplaceName),
            app.exchangePendingSale == null ? "Browse marketplace →" : "Sell here →",
            () ->
                app.exchangeScreens.openExchangeMarketplace(
                    MarketplaceProfile.byName(aggregate.marketplaceName),
                    null,
                    app.exchangePendingSale));
    card.add(browse, BorderLayout.SOUTH);
    return card;
  }
}
