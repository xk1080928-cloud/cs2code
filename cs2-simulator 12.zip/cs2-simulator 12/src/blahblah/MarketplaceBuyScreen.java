package blahblah;

import java.awt.*;
import java.util.*;
import java.util.List;
import javax.swing.*;

/** Stack-first catalog. Expanded offers remain real, individually validated stock lots. */
final class MarketplaceBuyScreen {
  private final hGui app;

  MarketplaceBuyScreen(hGui app) {
    this.app = app;
  }

  JPanel create(MarketplaceProfile p, String initialSearch) {
    JPanel root = app.exchangeWidgets.exchangePanel(p, new BorderLayout());
    root.setName("exchangeBuy");
    JTextField search = app.exchangeWidgets.exchangeSearch(initialSearch);
    search.setName("exchangeBuySearch");
    JComboBox<String> category =
        app.uiWidgets.createComboBox(
            new String[] {"All", "Knives", "Gloves", "Rifles", "Pistols", "Cases", "Agents"});
    JComboBox<String> wear =
        app.uiWidgets.createComboBox(
            new String[] {
              "All",
              "Factory New",
              "Minimal Wear",
              "Field-Tested",
              "Well-Worn",
              "Battle-Scarred",
              "Normal"
            });
    JComboBox<String> order =
        app.uiWidgets.createComboBox(
            new String[] {"Price: low to high", "Price: high to low", "Name"});
    order.setName("exchangeBuyPriceSort");
    JTextField min = app.exchangeWidgets.exchangeSearch(""),
        max = app.exchangeWidgets.exchangeSearch("");
    min.putClientProperty("placeholder", "Min price");
    max.putClientProperty("placeholder", "Max price");
    JCheckBox st = new JCheckBox("StatTrak only"), affordable = new JCheckBox("Affordable items");
    JPanel filters = app.exchangeWidgets.exchangePanel(p, new GridLayout(0, 1, 0, 10));
    filters.setPreferredSize(new Dimension(205, 0));
    filters.setBorder(BorderFactory.createEmptyBorder(14, 8, 14, 12));
    filters.add(
        app.exchangeWidgets.exchangeLabel(
            "FILTER INVENTORY", 13, app.exchangeWidgets.exchangeAccent(p)));
    filters.add(category);
    filters.add(app.exchangeWidgets.exchangeLabel("Exterior", 12, Theme.TEXT_DIM));
    filters.add(wear);
    filters.add(min);
    filters.add(max);
    filters.add(order);
    for (JCheckBox box : new JCheckBox[] {st, affordable}) {
      box.setOpaque(false);
      box.setForeground(Color.WHITE);
      filters.add(box);
    }
    // Sidebar inputs keep natural heights; horizontal brand layouts may reflow this panel.
    Component[] filterControls = filters.getComponents();
    filters.removeAll();
    filters.setLayout(new BoxLayout(filters, BoxLayout.Y_AXIS));
    for (Component control : filterControls) {
      if (control instanceof JComponent) {
        ((JComponent) control).setAlignmentX(Component.LEFT_ALIGNMENT);
        ((JComponent) control)
            .setMaximumSize(
                new Dimension(Integer.MAX_VALUE, control instanceof JTextField ? 35 : 30));
      }
      filters.add(control);
      filters.add(Box.createVerticalStrut(8));
    }
    JPanel top = app.cs2Screens.cs2Glass(new BorderLayout(14, 0));
    top.add(search);
    JLabel count = app.exchangeWidgets.exchangeLabel("", 12, app.exchangeWidgets.exchangeAccent(p));
    top.add(count, BorderLayout.EAST);
    JPanel grid = app.cs2Screens.cs2Grid(5, 8, 10);
    grid.setName("exchangeBuyGrid");
    JPanel body = app.exchangeWidgets.exchangePanel(p, new BorderLayout(0, 12));
    body.add(app.exchangeWidgets.exchangeScroll(grid));
    JPanel paging = app.cs2Screens.cs2Glass(new FlowLayout(FlowLayout.CENTER, 12, 0));
    JLabel pageLabel = app.exchangeWidgets.exchangeLabel("", 12, Theme.TEXT_DIM);
    JButton previous = app.exchangeWidgets.exchangeButton(p, "‹ Previous", () -> {}),
        next = app.exchangeWidgets.exchangeButton(p, "Next ›", () -> {});
    paging.add(previous);
    paging.add(pageLabel);
    paging.add(next);
    List<MarketplaceGroups.Group> groups = new ArrayList<>();
    int[] page = {0};
    boolean[] priceRefresh = {false};
    Runnable[] render = {null}, filter = {null};
    java.util.function.Consumer<MarketListing> purchase =
        lot -> {
          if (!Double.isFinite(lot.getPrice()) || lot.getPrice() <= 0) return;
          if (lot.isPlayerListing) {
            JOptionPane.showMessageDialog(
                app, "This is your own listing. Manage it in Portfolio → My Listings.");
            return;
          }
          double quote = app.coreUtilities.money(lot.getPrice()).doubleValue();
          if (JOptionPane.showConfirmDialog(
                  app,
                  String.format(
                      "Buy %s (%s) for $%,.2f on %s?",
                      lot.item.name, lot.item.condition, quote, p.name),
                  "Confirm purchase",
                  JOptionPane.YES_NO_OPTION)
              == JOptionPane.YES_OPTION) {
            try {
              app.exchangeTransactionService.commitExchangePurchase(lot, quote);
              filter[0].run();
            } catch (Exception ex) {
              JOptionPane.showMessageDialog(app, ex.getMessage());
              filter[0].run();
            }
          }
        };
    render[0] =
        () -> {
          grid.removeAll();
          int pages = Math.max(1, (groups.size() + 29) / 30);
          page[0] = Math.max(0, Math.min(page[0], pages - 1));
          for (int n = page[0] * 30; n < Math.min(groups.size(), (page[0] + 1) * 30); n++) {
            MarketplaceGroups.Group group = groups.get(n);
            MarketListing parent = group.head();
            MarketListing head =
                parent.isPlayerListing
                        || app.exchangeStockService.exchangeContainer(parent.item.name) != null
                    ? parent
                    : app.marketplaceUnitStock.cheapest(parent);
            boolean container = app.exchangeStockService.exchangeContainer(head.item.name) != null;
            JPanel card =
                app.exchangeCatalogScreens.createExchangeListingCard(
                    p,
                    head,
                    () -> {
                      if (!Double.isFinite(head.getPrice()) || head.getPrice() <= 0) return;
                      if (!container) {
                        new MarketplaceStackPicker(app).buy(p, root, group, purchase);
                      } else purchase.accept(head);
                    },
                    false);
            setQuantity(
                card,
                head.item.condition
                    + "  •  "
                    + String.format("%,d", group.units())
                    + " available"
                    + (container ? "" : "  ▤"));
            card.putClientProperty("marketGroup", group);
            boolean unavailable = !Double.isFinite(head.getPrice()) || head.getPrice() <= 0;
            card.putClientProperty("quoteUnavailable", unavailable);
            card.setEnabled(!unavailable);
            grid.add(card);
          }
          previous.setEnabled(page[0] > 0);
          next.setEnabled(page[0] + 1 < pages);
          pageLabel.setText("Page " + (page[0] + 1) + " / " + pages);
          grid.revalidate();
          grid.repaint();
          body.revalidate();
        };
    filter[0] =
        () -> {
          double low = 0, high = Double.POSITIVE_INFINITY;
          try {
            if (!min.getText().isBlank()) low = Double.parseDouble(min.getText());
            if (!max.getText().isBlank()) high = Double.parseDouble(max.getText());
            if (!Double.isFinite(low) || Double.isNaN(high) || low < 0 || high < low)
              throw new IllegalArgumentException();
          } catch (Exception e) {
            count.setText("Enter a valid price range");
            return;
          }
          List<MarketListing> lots = new ArrayList<>();
          String query = search.getText().trim().toLowerCase(Locale.ROOT);
          for (MarketListing lot :
              new ArrayList<>(app.exchangeSiteStock.getOrDefault(p.name, Collections.emptyList())))
            if (lot.quantity > 0
                && lot.item.name.toLowerCase(Locale.ROOT).contains(query)
                && app.exchangeCatalogScreens.exchangeMatchesCategory(
                    lot, (String) category.getSelectedItem())
                && ("All".equals(wear.getSelectedItem())
                    || lot.item.condition.equals(wear.getSelectedItem()))
                && (!st.isSelected() || lot.item.isStattrak)
                && ((Double.isFinite(app.marketplaceUnitStock.floorAsk(lot))
                        && app.marketplaceUnitStock.floorAsk(lot) >= low
                        && app.marketplaceUnitStock.floorAsk(lot) <= high
                        && (!affordable.isSelected()
                            || app.marketplaceUnitStock.floorAsk(lot) <= app.balance))
                    || (!Double.isFinite(app.marketplaceUnitStock.floorAsk(lot))
                        && app.exchangeStockService.exchangeContainer(lot.item.name) != null
                        && min.getText().trim().isEmpty()
                        && max.getText().trim().isEmpty()
                        && !affordable.isSelected()))) lots.add(lot);
          groups.clear();
          groups.addAll(app.marketplaceGroups.group(lots));
          Comparator<MarketplaceGroups.Group> sort =
              Comparator.comparingDouble(g -> app.marketplaceUnitStock.floorAsk(g.head()));
          if (order.getSelectedIndex() == 1) sort = sort.reversed();
          if (order.getSelectedIndex() == 2) sort = Comparator.comparing(g -> g.head().item.name);
          groups.sort(sort);
          root.putClientProperty("catalogGroups", groups);
          count.setText(
              String.format(
                  "%,d listings / %,d stacks",
                  app.exchangeStockService.countStock(lots), groups.size()));
          if (!priceRefresh[0]) page[0] = 0;
          render[0].run();
        };
    previous.addActionListener(
        e -> {
          page[0]--;
          render[0].run();
        });
    next.addActionListener(
        e -> {
          page[0]++;
          render[0].run();
        });
    for (JComboBox<?> box : new JComboBox[] {category, wear, order})
      box.addActionListener(e -> filter[0].run());
    st.addActionListener(e -> filter[0].run());
    affordable.addActionListener(e -> filter[0].run());
    for (JTextField text : new JTextField[] {search, min, max})
      app.exchangeWidgets.exchangeDebounce(text, filter[0]);
    root.putClientProperty("refreshExchange", filter[0]);
    root.putClientProperty(
        "refreshPrices",
        (Runnable)
            () -> {
              priceRefresh[0] = true;
              try {
                filter[0].run();
              } finally {
                priceRefresh[0] = false;
              }
            });
    root.putClientProperty(
        "pickCategory", (java.util.function.Consumer<String>) category::setSelectedItem);
    app.exchangeSiteRefresh.put(p.name, filter[0]);
    app.marketSiteLayouts.compose(p, root, top, body, filters, paging, "Buy");
    filter[0].run();
    return root;
  }

  void setQuantity(Component c, String value) {
    if (c instanceof JLabel && "exchangeLotQuantity".equals(c.getName()))
      ((JLabel) c).setText(value);
    if (c instanceof Container)
      for (Component child : ((Container) c).getComponents()) setQuantity(child, value);
  }
}
