package blahblah;

import blahblah.hGui.*;
import java.awt.*;
import java.awt.event.*;
import java.math.BigDecimal;
import java.math.RoundingMode;
import java.util.ArrayList;
import java.util.Comparator;
import java.util.List;
import java.util.Map;
import javax.swing.*;

/** Market Purchase Service: focused feature implementation. */
final class MarketPurchaseService {
  private final hGui app;

  MarketPurchaseService(hGui app) {
    this.app = app;
  }

  void startMarketplacePurchase(MarketListing listing, JFrame parent, Runnable postSuccessRefresh) {
    final double purchasePrice = listing.getPrice();
    if (!Double.isFinite(purchasePrice) || purchasePrice <= 0) {
      JOptionPane.showMessageDialog(parent, "A verified purchase quote is unavailable.");
      return;
    }
    if (app.balance < purchasePrice) {
      JOptionPane.showMessageDialog(
          parent, "Insufficient funds! Need $" + String.format("%.2f", purchasePrice));
      return;
    }
    int confirm =
        JOptionPane.showConfirmDialog(
            parent,
            String.format(
                "Start P2P purchase on %s?\n"
                    + "%s\n"
                    + "Condition: %s\n"
                    + "Price: $%.2f\n\n"
                    + "You will pay now and receive a trade delivery later.",
                listing.marketplaceName, listing.item.name, listing.item.condition, purchasePrice),
            "Confirm P2P Purchase",
            JOptionPane.YES_NO_OPTION);
    if (confirm != JOptionPane.YES_OPTION) return;

    if (app.balance < purchasePrice) {
      JOptionPane.showMessageDialog(
          parent, "Your balance changed before confirmation. Please retry.");
      return;
    }
    listing.setPrice(purchasePrice);
    listing.item.price = app.coreUtilities.money(purchasePrice);
    app.balance -= purchasePrice;
    TradeOffer purchaseTrade =
        new TradeOffer(
            listing.sellerName != null ? listing.sellerName : listing.marketplaceName,
            listing.sellerAvatar != null ? listing.sellerAvatar : app.playerAvatar,
            new ArrayList<>(java.util.Collections.singletonList(listing.item)),
            0.0,
            new ArrayList<>(),
            0.0);
    purchaseTrade.isMarketplacePurchase = true;
    purchaseTrade.isInstantDelivery = false;
    purchaseTrade.marketplaceName = listing.marketplaceName;
    purchaseTrade.marketplaceType = listing.marketplaceType;
    purchaseTrade.settledPrice = purchasePrice;
    // Schedule delivery after a random delay between 30 and 120 seconds
    int deliveryDelayMs = 30000 + hGui.random.nextInt(91000);
    purchaseTrade.deliveryScheduledTime = System.currentTimeMillis() + deliveryDelayMs;
    // Fire a notification when the delivery arrives
    javax.swing.Timer deliveryNotifTimer =
        new javax.swing.Timer(
            deliveryDelayMs,
            evt -> {
              SwingUtilities.invokeLater(
                  () -> app.priceModifiers.showDeliveryReadyNotification(purchaseTrade));
            });
    deliveryNotifTimer.setRepeats(false);
    deliveryNotifTimer.start();
    app.pendingPurchaseTrades.add(purchaseTrade);
    app.unreadTradesCount++;
    app.tradeHubScreen.updateTradeNotification();
    app.marketPurchaseService.removeListingAfterPurchase(listing);
    app.uiWidgets.updateBalanceLabel();
    app.caseRollService.writeStats();
    app.bundledArtwork.refreshMainUI();
    JOptionPane.showMessageDialog(
        parent,
        "Purchase created. Check the Purchases tab in Trades when the seller sends the trade.");
    if (postSuccessRefresh != null) {
      SwingUtilities.invokeLater(postSuccessRefresh);
    }
  }

  void removeListingAfterPurchase(MarketListing listing) {
    String skinName = listing.item.isStattrak ? "StatTrak " + listing.item.name : listing.item.name;
    app.marketStockService.invalidateGroupedMarketListingsCache();
    app.salesSimulationService.recordMarketListingSale(listing, "YOU", app.playerAvatar);
    app.marketPurchaseService.removeBlueGemListing(listing);
    if (app.globalMarketListings.containsKey(skinName)) {
      app.globalMarketListings.get(skinName).remove(listing);
    }
    app.marketStockService.invalidateGroupedMarketListingsCache();
  }

  Map<String, List<Integer>> getBlueGemPatterns(String cleanSkinName) {
    if (cleanSkinName == null || !cleanSkinName.contains("Case Hardened")) return null;
    if (cleanSkinName.contains("Flip Knife")) return hGui.FLIP_KNIFE_BG;
    else if (cleanSkinName.contains("M9 Bayonet")) return hGui.M9_BG;
    else if (cleanSkinName.contains("AK-47")) return hGui.AK_BG;
    else if (cleanSkinName.contains("Butterfly Knife")) return hGui.BUTTERFLY_BG;
    else if (cleanSkinName.contains("Kukri Knife")) return hGui.KUKRI_BG;
    return null;
  }

  ArrayList<MarketListing> getOrCreateBlueGemListings(String skinName) {
    String marketKey = app.leaderboardService.normalizeSkinName(skinName);
    ArrayList<MarketListing> cached = app.persistentBlueGemListings.get(marketKey);
    if (cached != null) {
      return cached;
    }

    boolean isStatTrak = marketKey.startsWith("StatTrak ");
    String cleanSkinName = marketKey.replace("StatTrak ", "").trim();
    String rarity = app.itemMetadataService.getSkinRarity(cleanSkinName);
    boolean isKnife = rarity.equals("Knife");
    Map<String, List<Integer>> patterns =
        app.marketPurchaseService.getBlueGemPatterns(cleanSkinName);
    ArrayList<MarketListing> generated = new ArrayList<>();

    if (patterns == null) {
      app.persistentBlueGemListings.put(marketKey, generated);
      return generated;
    }

    for (Map.Entry<String, List<Integer>> entry : patterns.entrySet()) {
      String tier = entry.getKey();
      List<Integer> pIds = entry.getValue();
      int numToShow = Math.min(5, pIds.size());
      for (int i = 0; i < numToShow; i++) {
        int patternId = pIds.get(hGui.random.nextInt(pIds.size()));
        double itemFloat =
            (i == 0)
                ? 0.01 + (hGui.random.nextDouble() * 0.05)
                : 0.01 + (hGui.random.nextDouble() * 0.30);
        String condition = app.floatRules.getConditionForFloat(cleanSkinName, itemFloat);

        double basePrice = app.itemPriceService.getBasePrice(cleanSkinName);
        basePrice *= app.priceModifiers.getConditionPriceMultiplier(cleanSkinName, condition);

        String blueGemTier = "Blue Gem " + tier;
        double price =
            app.itemPriceService.applyBlueGemMultiplier(
                cleanSkinName, patternId, blueGemTier, basePrice);
        double bgVariance = 0.80 + (hGui.random.nextDouble() * 0.40);
        price *= bgVariance * (app.marketPriceMultipliers.getOrDefault(rarity, 1.0));
        if (isStatTrak) price *= isKnife ? 1.15 : 3.0;

        String fullName = cleanSkinName + " (" + blueGemTier + ")";
        Image skinImg = app.artworkService.getSkinImageFromName(cleanSkinName, condition);

        InventoryItem dummyItem =
            new InventoryItem(
                skinImg != null ? new ImageIcon(skinImg) : null,
                fullName,
                condition,
                isStatTrak ? "StatTrak " + rarity : rarity,
                BigDecimal.valueOf(price).setScale(2, RoundingMode.HALF_UP),
                itemFloat,
                isStatTrak,
                patternId,
                blueGemTier,
                basePrice);
        dummyItem.collection = app.collectionService.getCollectionName(cleanSkinName);
        generated.add(new MarketListing(dummyItem, price, 0, false));
      }
    }

    app.persistentBlueGemListings.put(marketKey, generated);
    return generated;
  }

  boolean removeBlueGemListing(MarketListing listing) {
    for (ArrayList<MarketListing> listings : app.persistentBlueGemListings.values()) {
      if (listings.remove(listing)) {
        return true;
      }
    }
    return false;
  }

  @SuppressWarnings("unused")
  JPanel createBlueGemCard(
      String skinName,
      int patternId,
      String tier,
      String condition,
      double itemFloat,
      double price,
      JFrame parent) {
    boolean isStatTrak = skinName.contains("StatTrak");
    String cleanSkinName = skinName.replace("StatTrak ", "").trim();
    String rarity = app.itemMetadataService.getSkinRarity(cleanSkinName);
    String blueGemTier = "Blue Gem " + tier;
    String fullName = cleanSkinName + " (" + blueGemTier + ")";
    Image skinImg = app.artworkService.getSkinImageFromName(cleanSkinName, condition);
    double basePrice = app.itemPriceService.getBasePrice(cleanSkinName);

    InventoryItem dummyItem =
        new InventoryItem(
            skinImg != null ? new ImageIcon(skinImg) : null,
            fullName,
            condition,
            isStatTrak ? "StatTrak " + rarity : rarity,
            BigDecimal.valueOf(price).setScale(2, RoundingMode.HALF_UP),
            itemFloat,
            isStatTrak,
            patternId,
            blueGemTier,
            basePrice);
    dummyItem.collection = app.collectionService.getCollectionName(cleanSkinName);
    MarketListing listing = new MarketListing(dummyItem, price, 0, false);
    return app.marketPurchaseService.createOptimizedListingCard(listing, parent);
  }

  JPanel createOptimizedListingCard(MarketListing listing, JFrame parent) {
    JPanel listingCard = new JPanel(new BorderLayout());
    listingCard.setBackground(new Color(50, 50, 55));
    listingCard.setBorder(BorderFactory.createLineBorder(Color.GRAY, 2));
    listingCard.setMaximumSize(new Dimension(Integer.MAX_VALUE, 120));
    String rarity = listing.item.rarity.replace("StatTrak ", "");
    boolean showFloat = app.itemMetadataService.shouldShowFloatForItem(listing.item.name, rarity);
    boolean showPattern =
        app.itemMetadataService.shouldShowPatternForItem(listing.item.name, rarity);

    JPanel imagePanel = new JPanel(new BorderLayout());
    imagePanel.setPreferredSize(new Dimension(120, 80));
    imagePanel.setBackground(new Color(50, 50, 55));

    JLabel listingArtwork = new JLabel("", SwingConstants.CENTER);
    app.artworkService.refreshInventoryItemArtwork(listing.item);
    app.artworkService.getSkinImageFromName(
        listing.item.name, listing.item.condition, listingArtwork, 120, 80);
    imagePanel.add(listingArtwork, BorderLayout.CENTER);

    listingCard.add(imagePanel, BorderLayout.WEST);

    JPanel infoPanel = new JPanel(new GridLayout(showFloat ? 5 : 4, 1));
    infoPanel.setBackground(new Color(50, 50, 55));
    infoPanel.setBorder(BorderFactory.createEmptyBorder(5, 10, 5, 10));

    JLabel nameLabel;
    if (listing.item.isStattrak) {

      nameLabel = new JLabel("StatTrak " + listing.item.name);
      nameLabel.setForeground(new Color(255, 153, 51));
      nameLabel.setFont(new Font("Arial", Font.BOLD, 13));
    } else {
      nameLabel = new JLabel(listing.item.name);
      nameLabel.setForeground(Color.WHITE);
      nameLabel.setFont(new Font("Arial", Font.BOLD, 13));
    }

    JLabel patternLabel =
        new JLabel(
            showPattern
                ? "Pattern: " + app.marketOfferService.formatMarketPatternText(listing)
                : "Type: Agent");
    patternLabel.setFont(new Font("Arial", Font.BOLD, 12));
    patternLabel.setForeground(
        showPattern
            ? app.marketOfferService.getMarketPatternColor(listing, Color.WHITE)
            : Color.WHITE);

    JLabel floatLabel = null;
    if (showFloat) {
      floatLabel = new JLabel(String.format("Float: %.8f", listing.item.itemFloat));
      floatLabel.setFont(new Font("Arial", Font.PLAIN, 12));

      if (listing.item.itemFloat < 0.07) {
        floatLabel.setForeground(new Color(100, 255, 100));
      } else if (listing.item.itemFloat < 0.15) {
        floatLabel.setForeground(new Color(150, 255, 150));
      } else if (listing.item.itemFloat < 0.38) {
        floatLabel.setForeground(new Color(255, 255, 100));
      } else if (listing.item.itemFloat < 0.45) {
        floatLabel.setForeground(new Color(255, 200, 100));
      } else {
        floatLabel.setForeground(new Color(255, 150, 150));
      }
    }

    JLabel priceLabel = new JLabel("$" + String.format("%.2f", listing.getPrice()));
    priceLabel.setFont(new Font("Arial", Font.BOLD, 16));
    priceLabel.setForeground(Color.YELLOW);

    JPanel sellerPanel = new JPanel(new FlowLayout(FlowLayout.LEFT, 5, 2));
    sellerPanel.setBackground(new Color(50, 50, 55));

    JLabel sellerPrefix = new JLabel("SELLER: ");
    sellerPrefix.setFont(new Font("Arial", Font.BOLD, 11));
    sellerPrefix.setForeground(Color.LIGHT_GRAY);
    sellerPanel.add(sellerPrefix);

    if (listing.isPlayerListing) {
      JLabel playerAvatarLabel =
          new JLabel(new ImageIcon(HighQualityImages.fit(app.playerAvatar, 16, 16)));
      sellerPanel.add(playerAvatarLabel);

      JLabel youLabel = new JLabel("YOU");
      youLabel.setFont(new Font("Arial", Font.BOLD, 11));
      youLabel.setForeground(new Color(100, 200, 100));
      sellerPanel.add(youLabel);
    } else {
      if (listing.sellerAvatar != null) {
        JLabel avatarLabel =
            new JLabel(new ImageIcon(HighQualityImages.fit(listing.sellerAvatar, 16, 16)));
        sellerPanel.add(avatarLabel);
      }

      JLabel usernameLabel = new JLabel(listing.sellerName);
      usernameLabel.setFont(new Font("Arial", Font.PLAIN, 11));
      usernameLabel.setForeground(Color.WHITE);
      sellerPanel.add(usernameLabel);
    }

    infoPanel.add(nameLabel);
    infoPanel.add(patternLabel);
    if (showFloat) infoPanel.add(floatLabel);
    infoPanel.add(priceLabel);
    infoPanel.add(sellerPanel);

    listingCard.add(infoPanel, BorderLayout.CENTER);

    if (listing.isPlayerListing) {
      JLabel yourListingLabel = new JLabel("YOUR LISTING");
      yourListingLabel.setForeground(Color.ORANGE);
      yourListingLabel.setFont(new Font("Arial", Font.BOLD, 14));
      yourListingLabel.setHorizontalAlignment(SwingConstants.CENTER);
      yourListingLabel.setPreferredSize(new Dimension(150, 80));
      listingCard.add(yourListingLabel, BorderLayout.EAST);
    } else {
      JButton buyBtn =
          new JButton(
              "<html><center>PURCHASE<br>$"
                  + String.format("%.2f", listing.getPrice())
                  + "</center></html>");
      buyBtn.setFont(new Font("Arial", Font.BOLD, 14));
      buyBtn.setBackground(new Color(50, 150, 50));
      buyBtn.setForeground(Color.WHITE);
      buyBtn.setPreferredSize(new Dimension(150, 80));
      buyBtn.setFocusPainted(false);

      buyBtn.addMouseListener(
          new MouseAdapter() {
            @Override
            public void mousePressed(MouseEvent e) {}
          });

      buyBtn.addActionListener(
          e -> {
            app.marketPurchaseService.buyItemNow(listing, parent);
          });

      listingCard.add(buyBtn, BorderLayout.EAST);
    }

    return listingCard;
  }

  void buyItemNow(MarketListing listing, JFrame parent) {
    app.marketPurchaseService.buyItemNow(listing, parent, null);
  }

  void buyItemNow(MarketListing listing, JFrame parent, Runnable postSuccessRefresh) {
    final double purchasePrice = listing.getPrice();
    if (!Double.isFinite(purchasePrice) || purchasePrice <= 0) {
      JOptionPane.showMessageDialog(parent, "A verified purchase quote is unavailable.");
      return;
    }
    if (app.balance < purchasePrice) {
      JOptionPane.showMessageDialog(
          parent, "Insufficient funds! Need $" + String.format("%.2f", purchasePrice));
      return;
    }

    String rarity = listing.item.rarity.replace("StatTrak ", "");
    boolean showFloat = app.itemMetadataService.shouldShowFloatForItem(listing.item.name, rarity);
    int confirm =
        JOptionPane.showConfirmDialog(
            parent,
            showFloat
                ? String.format(
                    "Buy %s%s\nCondition: %s\nFloat: %.10f\nPrice: $%.2f?",
                    listing.item.isStattrak ? "StatTrak " : "",
                    listing.item.name,
                    listing.item.condition,
                    listing.item.itemFloat,
                    purchasePrice)
                : String.format(
                    "Buy %s%s\nType: Agent\nPrice: $%.2f?",
                    listing.item.isStattrak ? "StatTrak " : "", listing.item.name, purchasePrice),
            "Confirm Purchase",
            JOptionPane.YES_NO_OPTION);

    if (confirm == JOptionPane.YES_OPTION) {
      if (app.balance < purchasePrice) {
        JOptionPane.showMessageDialog(
            parent, "Your balance changed before confirmation. Please retry.");
        return;
      }
      listing.setPrice(purchasePrice);
      listing.item.price = app.coreUtilities.money(purchasePrice);
      app.balance -= purchasePrice;

      if (listing.item.image == null) {
        String cleanName = listing.item.name.replace("StatTrak ", "");
        Image img = app.artworkService.getSkinImageFromName(cleanName, listing.item.condition);
        if (img != null) {
          listing.item.image = new ImageIcon(img);
        }
      }

      String marketKey =
          listing.item.isStattrak ? "StatTrak " + listing.item.name : listing.item.name;
      ArrayList<MarketListing> allListings = app.globalMarketListings.get(marketKey);

      double lowestMarketPrice = purchasePrice;

      if (allListings != null && !allListings.isEmpty()) {
        ArrayList<MarketListing> sameCondition = new ArrayList<>();
        for (MarketListing ml : allListings) {
          if (ml.item.condition.equals(listing.item.condition)) {
            sameCondition.add(ml);
          }
        }

        if (!sameCondition.isEmpty()) {
          sameCondition.sort(Comparator.comparingDouble(l -> l.getPrice()));
          lowestMarketPrice = sameCondition.get(0).getPrice();
        }
      }

      String rarityKey = listing.item.rarity.replace("StatTrak ", "");
      double currentMarketMulti = (app.marketPriceMultipliers.getOrDefault(rarityKey, 1.0));
      double trueBasePrice = lowestMarketPrice / currentMarketMulti;

      listing.item.price = BigDecimal.valueOf(lowestMarketPrice).setScale(2, RoundingMode.HALF_UP);
      listing.item.basePrice = trueBasePrice;

      app.marketPurchaseService.updateIdenticalItemPrices(
          listing.item.name, listing.item.condition, listing.item.isStattrak, trueBasePrice);

      if (listing.item.blueGemTier != null
          && listing.item.collection != null
          && listing.item.collection.length() <= 2) {
        listing.item.collection = null;
      }
      String sellerName =
          (listing.sellerName != null
                  && !listing.sellerName.trim().isEmpty()
                  && !"YOU".equalsIgnoreCase(listing.sellerName))
              ? listing.sellerName
              : (listing.marketplaceName != null
                  ? listing.marketplaceName + " Seller"
                  : "Marketplace Seller");
      String purchaseMarket =
          listing.marketplaceName != null && !listing.marketplaceName.trim().isEmpty()
              ? listing.marketplaceName
              : "Marketplace";
      app.ownershipHistoryService.ensureTrackedHistoryForDisplay(listing.item, sellerName);
      app.ownershipHistoryService.addItemHistory(
          listing.item,
          System.currentTimeMillis() - 1000L,
          "Listed On Market",
          String.format("Listed on market for $%.2f by %s", purchasePrice, sellerName),
          sellerName);
      app.ownershipHistoryService.addItemHistory(
          listing.item,
          System.currentTimeMillis(),
          "Bought From " + purchaseMarket,
          String.format("Bought from %s by YOU for $%.2f", purchaseMarket, purchasePrice),
          "YOU");
      app.inventoryList.add(listing.item);
      app.coreUtilities.addInventoryValue(lowestMarketPrice);

      app.searchControls.updateLeaderboard();

      app.salesSimulationService.recordMarketListingSale(listing, "YOU", app.playerAvatar);
      app.playerPurchases.add(
          app.salesSimulationService.createSaleRecordFromListing(listing, "YOU", app.playerAvatar));
      app.missionProgress.marketSpent += purchasePrice;
      app.missionService.checkMissionProgress();
      if (app.playerPurchases.size() > hGui.MAX_SALES_HISTORY) {
        app.playerPurchases.removeFirst();
      }

      String skinName =
          listing.item.isStattrak ? "StatTrak " + listing.item.name : listing.item.name;
      app.marketPurchaseService.removeBlueGemListing(listing);
      if (app.globalMarketListings.containsKey(skinName)) {
        app.globalMarketListings.get(skinName).remove(listing);
      }

      app.uiWidgets.updateBalanceLabel();
      app.caseRollService.writeStats();
      app.coreUtilities.refreshInventoryValueLabel();
      app.bundledArtwork.refreshMainUI();

      JOptionPane.showMessageDialog(parent, "Purchase successful!");
      if (postSuccessRefresh != null) {
        SwingUtilities.invokeLater(postSuccessRefresh);
      }
    }
  }

  void updateIdenticalItemPrices(
      String skinName, String condition, boolean isStattrak, double newBasePrice) {
    synchronized (app.inventoryList) {
      for (InventoryItem item : app.inventoryList) {
        if (item.name.equals(skinName)
            && item.condition.equals(condition)
            && item.isStattrak == isStattrak
            && item.blueGemTier == null) {

          item.basePrice = newBasePrice;

          String rarityKey = item.rarity.replace("StatTrak ", "");
          double currentMarketMulti = (app.marketPriceMultipliers.getOrDefault(rarityKey, 1.0));
          double newPrice = newBasePrice * currentMarketMulti;

          item.price = BigDecimal.valueOf(newPrice).setScale(2, RoundingMode.HALF_UP);
        }
      }

      app.inventoryValue = 0.0;
      for (InventoryItem item : app.inventoryList) {
        app.inventoryValue += item.price.doubleValue();
      }

      SwingUtilities.invokeLater(
          () -> {
            BigDecimal newInventoryValue =
                BigDecimal.valueOf(app.inventoryValue).setScale(2, RoundingMode.HALF_UP);
            app.totalInventoryValueLabel.setText("Inventory Value: $" + newInventoryValue);
          });
    }
  }

  boolean isConditionValidForSkin(String skinName, String condition) {
    if (skinName == null || condition == null) return false;
    String cleanSkinName = skinName.replace("StatTrak ", "").trim();
    for (String valid : app.floatRules.getAvailableConditions(cleanSkinName)) {
      if (condition.equals(valid)) return true;
    }
    return false;
  }
}
