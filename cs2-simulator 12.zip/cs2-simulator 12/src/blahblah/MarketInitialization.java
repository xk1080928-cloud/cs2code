package blahblah;

import blahblah.hGui.*;
import java.awt.*;
import java.awt.event.*;
import java.util.ArrayList;
import java.util.Map;
import javax.swing.*;

/** Market Initialization: focused feature implementation. */
final class MarketInitialization {
  private final hGui app;

  MarketInitialization(hGui app) {
    this.app = app;
  }

  void initializeMarketPrices() {
    app.marketPriceMultipliers.put("Knife", 1.0);
    app.marketPriceMultipliers.put("Gloves", 1.0);
    app.marketPriceMultipliers.put("Covert", 1.0);
    app.marketPriceMultipliers.put("Master", 1.0);
    app.marketPriceMultipliers.put("Classified", 1.0);
    app.marketPriceMultipliers.put("Superior", 1.0);
    app.marketPriceMultipliers.put("Restricted", 1.0);
    app.marketPriceMultipliers.put("Exceptional", 1.0);
    app.marketPriceMultipliers.put("Milspec", 1.0);
    app.marketPriceMultipliers.put("Distinguished", 1.0);
    app.marketPriceMultipliers.put("Industrial", 1.0);
    for (String rarity : app.marketPriceMultipliers.keySet()) {
      app.priceHistory.computeIfAbsent(rarity, k -> new ArrayList<>()).add(1.0);
    }
  }

  double getMarketMultiplier(String rarity, String collection) {
    return (app.marketPriceMultipliers.getOrDefault(rarity, 1.0));
  }

  void startMarketFluctuationTimer() {
    app.mainTabs.setEnabledAt(4, false);
    app.openCrateButton.setEnabled(false);
    app.autoOpenButton.setEnabled(false);
    app.tradeNotificationLabel.setText("Loading case data and preparing the marketplace...");
    app.caseRoiLabel.setText("Loading skin and case data; case opening will unlock automatically.");
    JLabel marketLoadingLabel =
        new JLabel(
            "Preparing the marketplace listings. This section will unlock automatically.",
            SwingConstants.CENTER);
    marketLoadingLabel.setForeground(Theme.TEXT_DIM);
    app.marketTabPanel.removeAll();
    app.marketTabPanel.add(marketLoadingLabel, BorderLayout.CENTER);
    SwingWorker<Void, Void> marketInitializer =
        new SwingWorker<Void, Void>() {
          @Override
          protected Void doInBackground() throws Exception {
            app.startupScreen.setStartupProgress(0, "Preparing catalogs and interface data...");
            app.avatarService.loadAvatars();
            if(!app.carePackages.restoreMissions())app.missionService.generateNewMissions();
            app.bundledArtwork.loadSkinImages();
            app.marketInitialization.initializeMarketPrices();
            app.marketCatalogService.registerBundledTerminals();
            app.marketCatalogService.registerBundledArmouryCollections();
            CareCollectionsData.register(app);
            app.marketCatalogService.registerRequestedMarketCollections();
            app.catalogLoadingService.loadExternalSkinCatalog();
            app.catalogLoadingService.loadExternalAgentCatalog();
            app.catalogLoadingService.loadExternalCrateCatalog();
            app.startupCatalogsLoaded.await();
            app.startupPriceService.prepareStartupPriceTracking(
                app.startupPriceService.getStartupArtworkNames());
            app.startupPriceService.preloadStartupSkinPrices();
            app.startupScreen.setStartupProgress(40, "Loading case prices...");
            Map<CaseType, Double> casePrices =
                app.startupArtworkService.fetchRoundedMarketCasePrices();
            SwingUtilities.invokeAndWait(
                () -> app.startupArtworkService.applyMarketCasePrices(casePrices));
            app.startupScreen.setStartupProgress(40, "Preparing marketplace listings...");
            app.marketGeneration.generateGlobalMarketListings();
            app.startupPriceService.awaitStartupPriceLookups();
            app.startupArtworkStage = true;
            app.startupArtworkService.preloadStartupArtwork();
            app.startupScreen.setStartupProgress(
                94, "Building NPC inventories and leaderboards...");
            app.leaderboardService.generateLeaderboard();
            app.startupScreen.setStartupProgress(
                95, "Creating rarity- and price-based simulated sales histories...");
            app.salesSimulationService.initializeSimulatedSalesHistory();
            app.avatarService.initializeMarketQueue();
            app.startupScreen.setStartupProgress(
                97, "Summarizing market listings and marketplaces...");
            app.marketHomeScreen.refreshMarketplaceSummarySnapshot();
            app.startupScreen.setStartupProgress(
                98, "Preparing buffered marketplace supply...");
            app.globalSupply.initialize();
            app.globalSupply.reconcileListings();
            app.marketBuffer.initialize(app.marketStockService.getTotalMarketListingCount());
            app.startupScreen.setStartupProgress(
                99, "Preparing the case selector and opening interface...");
            return null;
          }

          @Override
          protected void done() {
            try {
              get();
              app.marketInitialized = true;
              if (app.cs2ShellEnabled) {
                app.cs2Screens.refreshCs2Home();
                app.cs2Screens.refreshCs2Inventory();
              }
              app.salesSimulationService.refillFairSalesQueue();
              app.crateImage = app.containerBrowserScreen.getContainerImage(app.currentCase);
              app.containerBrowserScreen.updateCrateImageDisplay();
              app.mainTabs.setEnabledAt(4, true);
              app.openCrateButton.setEnabled(
                  !app.isAnimating
                      && app.balance >= app.developerTools.getCaseOpeningCost(app.currentCase));
              app.autoOpenButton.setEnabled(true);
              app.tradeNotificationLabel.setText("");
              app.containerBrowserScreen.rebuildCaseBoxes();
              if (app.mainTabs.getSelectedIndex() == 4) app.loadoutScreen.refreshMarketTab();
              app.marketRuntime.startMarketFluctuationTimerAfterInitialization();
              app.tradeGenerationService.startTradeGenerationTimer();
              app.salesSimulationService.startFakeSalesTimer();
              app.salesSimulationService.startSimulatedSalesTimer();
              if (app.startupArtworkFailed > 0 || app.startupArtworkFallbacks > 0)
                app.caseRoiLabel.setToolTipText(
                    "Startup PNGs: "
                        + app.startupArtworkLoaded
                        + " / "
                        + app.startupArtworkTotal
                        + " loaded; "
                        + app.startupArtworkFallbacks
                        + " fallback; "
                        + app.startupArtworkFailed
                        + " unavailable. See Dev Tools > Image loading report for exact skins and"
                        + " wear.");
              app.startupScreen.finishStartupLoading();
              app.backgroundUnboxing.start();
              if(!app.carePackages.state().pending.isEmpty())app.carePackages.queuePresentation();
              app.itemRevealService.resumeTradeUp();
            } catch (InterruptedException e) {
              Thread.currentThread().interrupt();
              app.startupArtworkService.showStartupError("Marketplace startup was interrupted.");
            } catch (java.util.concurrent.ExecutionException e) {
              e.getCause().printStackTrace();
              app.startupArtworkService.showStartupError(
                  "Marketplace initialization failed: "
                      + e.getCause().getClass().getSimpleName()
                      + ": "
                      + String.valueOf(e.getCause().getMessage()));
            }
          }
        };
    marketInitializer.execute();
  }
}
