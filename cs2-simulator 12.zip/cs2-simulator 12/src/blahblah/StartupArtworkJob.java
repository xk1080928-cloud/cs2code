package blahblah;

import blahblah.hGui.*;
import java.awt.*;
import java.awt.event.*;
import javax.swing.*;

/** Extracted reusable model or widget; behavior retained from the original source. */
final class StartupArtworkJob {
  final String key, primary, fallback;

  StartupArtworkJob(String key, String primary, String fallback) {
    this.key = key;
    this.primary = primary;
    this.fallback = fallback;
  }
}
