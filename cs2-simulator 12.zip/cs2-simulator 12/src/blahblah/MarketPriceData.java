package blahblah;

import blahblah.hGui.*;
import java.awt.*;
import java.awt.event.*;
import java.util.Map;
import javax.swing.*;

/** Extracted reusable model or widget; behavior retained from the original source. */
final class MarketPriceData {
  final double basePrice;
  final Map<String, Double> conditionMultipliers;
  final Double vanillaStatTrakPrice;

  MarketPriceData(double basePrice, Map<String, Double> conditionMultipliers) {
    this(basePrice, conditionMultipliers, null);
  }

  MarketPriceData(
      double basePrice, Map<String, Double> conditionMultipliers, Double vanillaStatTrakPrice) {
    this.basePrice = basePrice;
    this.conditionMultipliers = Map.copyOf(conditionMultipliers);
    this.vanillaStatTrakPrice = vanillaStatTrakPrice;
  }
}
