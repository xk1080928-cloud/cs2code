package blahblah;

import blahblah.hGui.*;
import java.awt.*;
import java.awt.event.*;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.stream.Collectors;
import javax.swing.*;

/** Extracted reusable model or widget; behavior retained from the original source. */
public final class CaseType {
  static final Map<String, CaseType> CASES_BY_ID = new LinkedHashMap<>();
  static final Map<String, CaseType> CASES_BY_CRATE = new LinkedHashMap<>();
  static final List<CaseType> CASES = new ArrayList<>();
  static final CaseType WEAPON_CASE_ONE =
      new CaseType("WEAPON_CASE_ONE", "Weapon Case One", "CS:GO Weapon Case", 50.0);
  static final CaseType BRAVO = new CaseType("BRAVO", "Bravo Case", "Operation Bravo Case", 35.0);
  static final CaseType BREAKOUT =
      new CaseType("BREAKOUT", "Breakout Case", "Operation Breakout Weapon Case", 10.0);
  static final CaseType SPECTRUM = new CaseType("SPECTRUM", "Spectrum Case", "Spectrum Case", 5.0);
  static final CaseType KILOWATT = new CaseType("KILOWATT", "Kilowatt Case", "Kilowatt Case", 2.5);
  static final CaseType REVOLUTION =
      new CaseType("REVOLUTION", "Revolution Case", "Revolution Case", 1.0);
  static final CaseType CHROMA = new CaseType("CHROMA", "Chroma Case", "Chroma Case", 2.5);
  static final CaseType CHROMA_2 = new CaseType("CHROMA_2", "Chroma 2 Case", "Chroma 2 Case", 2.5);
  static final CaseType CHROMA_3 = new CaseType("CHROMA_3", "Chroma 3 Case", "Chroma 3 Case", 2.5);

  String name;
  final String id;
  String crateName;
  String imageUrl;
  boolean isTerminal;
  String mapName = "";
  int releaseOrder = Integer.MAX_VALUE;
  int catalogOrder = Integer.MAX_VALUE;
  volatile double price;
  final double rarityBonus;
  final boolean isSouvenir;
  final List<String> rareDropNames = new ArrayList<>();
  final Map<String, String> rareDropCategories = new HashMap<>();
  final Map<String, List<String>> regularDropNames = new HashMap<>();
  String rareDropCategory = "Knives";
  int timesOpened;
  double totalSpent;
  double totalReceived;

  CaseType(String id, String name, String crateName, double price) {
    this(id, name, crateName, price, false);
  }

  CaseType(String id, String name, String crateName, double price, boolean isSouvenir) {
    this.id = id;
    this.name = name;
    this.crateName = crateName;
    this.price = price;
    this.isSouvenir = isSouvenir;
    this.rarityBonus = 1.0;
    this.timesOpened = 0;
    this.totalSpent = 0.0;
    this.totalReceived = 0.0;
    synchronized (CASES) {
      CASES_BY_ID.put(id, this);
      CASES_BY_CRATE.put(crateName.toLowerCase(java.util.Locale.ROOT), this);
      CASES.add(this);
    }
  }

  boolean goldDropsKnives() {
    return !"Gloves".equals(rareDropCategory);
  }

  String goldDropLabel() {
    return "Mixed".equals(rareDropCategory) ? "Knives / Gloves" : rareDropCategory;
  }

  String randomRareDropCategory() {
    if (rareDropNames.isEmpty()) return rareDropCategory;
    String selected = rareDropNames.get(hGui.random.nextInt(rareDropNames.size()));
    return rareDropCategories.getOrDefault(selected, rareDropCategory);
  }

  String catalogCrateName() {
    return crateName;
  }

  String name() {
    return id;
  }

  @Override
  public String toString() {
    return name;
  }

  static CaseType[] values() {
    synchronized (CASES) {
      return CASES.toArray(new CaseType[0]);
    }
  }

  static CaseType valueOf(String id) {
    synchronized (CASES) {
      CaseType result = CASES_BY_ID.get(id);
      if (result == null) throw new IllegalArgumentException("Unknown case type: " + id);
      return result;
    }
  }

  static synchronized void registerCatalogCase(
      String crateName,
      Map<String, List<String>> regularDrops,
      List<String> rareDrops,
      Map<String, String> rareCategories,
      String imageUrl) {
    String key = crateName.toLowerCase(java.util.Locale.ROOT);
    CaseType caseType = CASES_BY_CRATE.get(key);
    if (caseType == null) {
      String id =
          "CATALOG_"
              + crateName
                  .toUpperCase(java.util.Locale.ROOT)
                  .replaceAll("[^A-Z0-9]+", "_")
                  .replaceAll("^_|_$", "");
      caseType = new CaseType(id, crateName, crateName, 2.50);
    }
    final CaseType registeredCase = caseType;
    registeredCase.imageUrl = imageUrl;
    registeredCase.rareDropNames.clear();
    registeredCase.rareDropNames.addAll(rareDrops);
    registeredCase.rareDropCategories.clear();
    registeredCase.rareDropCategories.putAll(rareCategories);
    registeredCase.regularDropNames.clear();
    for (Map.Entry<String, List<String>> entry : regularDrops.entrySet()) {
      registeredCase.regularDropNames.put(entry.getKey(), new ArrayList<>(entry.getValue()));
    }
    Set<String> categories = new HashSet<>(rareCategories.values());
    registeredCase.rareDropCategory =
        categories.size() == 1
            ? categories.iterator().next()
            : categories.isEmpty() ? "Knives" : "Mixed";
  }

  static synchronized void registerSouvenirPackage(
      String crateName, String mapName, Map<String, List<String>> regularDrops, String imageUrl) {
    // Generate a truly unique ID based on the full crate name to prevent cross-event overwrites
    String id =
        "SOUVENIR_"
            + crateName
                .toUpperCase(java.util.Locale.ROOT)
                .replaceAll("[^A-Z0-9]+", "_")
                .replaceAll("^_|_$", "");

    CaseType packageCase = CASES_BY_ID.get(id);
    if (packageCase == null) {
      // Use the actual crateName or a clean combination as the display name
      packageCase = new CaseType(id, crateName, crateName, 0.50, true);
      CASES_BY_ID.put(id, packageCase);
    }

    // Clean up old crate mapping if crateName changed
    CASES_BY_CRATE.remove(packageCase.crateName.toLowerCase(java.util.Locale.ROOT));

    // Set properties correctly using the full crateName as the display name to avoid "Train"
    // fallback issues
    packageCase.name = crateName;
    packageCase.crateName = crateName;
    packageCase.imageUrl = imageUrl;
    packageCase.mapName = mapName == null ? "" : mapName;

    CASES_BY_CRATE.put(crateName.toLowerCase(java.util.Locale.ROOT), packageCase);

    packageCase.rareDropNames.clear();
    packageCase.rareDropCategories.clear();
    packageCase.regularDropNames.clear();

    for (Map.Entry<String, List<String>> entry : regularDrops.entrySet()) {
      List<String> souvenirNames =
          entry.getValue().stream()
              .map(name -> name.startsWith("Souvenir ") ? name : "Souvenir " + name)
              .collect(Collectors.toList());
      packageCase.regularDropNames.put(entry.getKey(), souvenirNames);
    }
  }

  public double getROI() {
    if (totalSpent == 0) return 0.0;
    return ((totalReceived - totalSpent) / totalSpent) * 100.0;
  }

  public double getAverageProfit() {
    if (timesOpened == 0) return 0.0;
    return (totalReceived - totalSpent) / timesOpened;
  }
}
