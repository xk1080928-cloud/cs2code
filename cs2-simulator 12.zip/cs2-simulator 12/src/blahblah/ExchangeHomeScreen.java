package blahblah;

import blahblah.hGui.*;
import java.awt.*;
import java.awt.event.*;
import java.util.ArrayList;
import java.util.Comparator;
import java.util.HashSet;
import java.util.List;
import java.util.Set;
import javax.swing.*;

/** Exchange Home Screen: focused feature implementation. */
final class ExchangeHomeScreen {
  private final hGui app;

  ExchangeHomeScreen(hGui app) {
    this.app = app;
  }

  JPanel exchangeSignatureTile(
      MarketplaceProfile p,
      String eyebrow,
      String title,
      String body,
      String action,
      Runnable click) {
    JPanel tile = app.exchangeWidgets.exchangePanel(p, new BorderLayout(0, 12));
    tile.setBorder(
        BorderFactory.createCompoundBorder(
            BorderFactory.createMatteBorder(0, 3, 0, 0, app.exchangeWidgets.exchangeAccent(p)),
            BorderFactory.createEmptyBorder(18, 18, 18, 18)));
    JPanel text = app.cs2Screens.cs2Glass(new GridLayout(0, 1, 0, 10));
    text.add(app.exchangeWidgets.exchangeLabel(eyebrow, 11, app.exchangeWidgets.exchangeAccent(p)));
    text.add(
        app.exchangeWidgets.exchangeLabel(
            "<html>" + app.marketItemCards.escapeHtml(title) + "</html>", 25, Color.WHITE));
    text.add(
        app.exchangeWidgets.exchangeLabel(
            "<html>" + app.marketItemCards.escapeHtml(body) + "</html>", 13, Theme.TEXT_DIM));
    tile.add(text);
    if (action != null)
      tile.add(app.exchangeWidgets.exchangeButton(p, action, click), BorderLayout.SOUTH);
    return tile;
  }

  JPanel exchangeSignatureArt(MarketplaceProfile p, MarketListing lot, boolean large) {
    JPanel panel = app.exchangeWidgets.exchangePanel(p, new BorderLayout(0, 10));
    panel.setBorder(BorderFactory.createEmptyBorder(12, 16, 12, 16));
    if (lot == null) return panel;
    JLabel art = new JLabel("", SwingConstants.CENTER);
    CaseType ct = app.exchangeStockService.exchangeContainer(lot.item.name);
    if (ct != null)
      app.cs2Screens.bindCs2SupplyArtwork(ct, false, art, large ? 360 : 190, large ? 170 : 100);
    else
      app.artworkService.getSkinImageFromName(
          lot.item.name, lot.item.condition, art, large ? 360 : 190, large ? 170 : 100);
    panel.add(art);
    panel.add(
        app.exchangeWidgets.exchangeLabel(
            "<html>"
                + app.marketItemCards.escapeHtml(lot.item.name)
                + String.format("<br>$%,.2f</html>", lot.getPrice()),
            14,
            Color.WHITE),
        BorderLayout.SOUTH);
    return panel;
  }

  JPanel exchangeSignatureRows(
      MarketplaceProfile p, List<MarketListing> lots, int limit, boolean floats) {
    JPanel table = app.exchangeWidgets.exchangePanel(p, new GridLayout(0, 1, 0, 1));
    int n = 0;
    for (MarketListing lot : lots) {
      if (n++ >= limit) break;
      JPanel row = app.exchangeWidgets.exchangePanel(p, new BorderLayout(14, 0));
      row.setBorder(
          BorderFactory.createCompoundBorder(
              BorderFactory.createMatteBorder(0, 0, 1, 0, new Color(63, 73, 78)),
              BorderFactory.createEmptyBorder(12, 12, 12, 12)));
      row.add(
          app.exchangeWidgets.exchangeLabel(
              String.format("%02d  ", n) + lot.item.name, 12, Color.WHITE));
      row.add(
          app.exchangeWidgets.exchangeLabel(
              floats
                  ? String.format("%.8f", lot.item.itemFloat)
                  : String.format("%,d  ×  $%,.2f", lot.quantity, lot.getPrice()),
              13,
              app.exchangeWidgets.exchangeAccent(p)),
          BorderLayout.EAST);
      table.add(row);
    }
    return table;
  }

  JPanel createExchangeSignature(MarketplaceProfile p, JTabbedPane tabs, JPanel standardHero) {
    int style = app.exchangeTransactionService.exchangeStyle(p);
    List<MarketListing> stock = new ArrayList<>();
    for (MarketListing l :
        app.exchangeSiteStock.getOrDefault(p.name, java.util.Collections.emptyList()))
      if (l.quantity > 0 && !l.isPlayerListing) stock.add(l);
    stock.sort(Comparator.comparingDouble(MarketListing::getPrice).reversed());
    List<MarketListing> skins = new ArrayList<>();
    Set<String> distinct = new HashSet<>();
    for (MarketListing l : stock)
      if (app.exchangeStockService.exchangeContainer(l.item.name) == null
          && distinct.add(l.item.name)) skins.add(l);
    MarketListing first = skins.isEmpty() ? null : skins.get(0),
        second = skins.size() > 1 ? skins.get(1) : first;
    int units = app.exchangeStockService.countStock(stock);
    String available = String.format("%,d available listings", units);
    Runnable buy = () -> tabs.setSelectedIndex(1),
        sell = () -> tabs.setSelectedIndex(2),
        swap = () -> tabs.setSelectedIndex(3);
    JPanel signature = app.exchangeWidgets.exchangePanel(p, new BorderLayout(18, 12));
    signature.setName("exchangeSignature-" + p.name);
    signature.setBorder(BorderFactory.createEmptyBorder(8, 4, 12, 4));
    switch (style) {
      case 0: // CS.MONEY: an oversized upgrade hero with an opposing product stage.
        signature.add(
            app.exchangeHomeScreen.exchangeSignatureTile(
                p,
                "THE LOADOUT UPGRADE",
                "A new finish. A new perspective.",
                available,
                "Explore the catalog →",
                buy));
        signature.add(
            app.exchangeHomeScreen.exchangeSignatureArt(p, first, true), BorderLayout.EAST);
        break;
      case 1: // SkinSwap: inventory-to-inventory trading is the visual entry point.
        signature.setLayout(new GridLayout(1, 3, 18, 0));
        signature.add(
            app.exchangeHomeScreen.exchangeSignatureTile(
                p,
                "YOU OFFER",
                "Your inventory",
                String.format(
                    "%d owned skins • +5%% swap credit",
                    app.inventoryList.stream()
                        .filter(i -> !app.cs2EquipmentScreens.isDefaultWeaponItem(i))
                        .count()),
                "Select your skins",
                swap));
        signature.add(
            app.exchangeHomeScreen.exchangeSignatureTile(
                p,
                "SKINSWAP",
                "↔",
                "Two sides. One transparent difference.",
                "Start a trade",
                swap));
        signature.add(
            app.exchangeHomeScreen.exchangeSignatureTile(
                p, "YOU RECEIVE", "Your next loadout", available, "Find your next skin", buy));
        break;
      case 2: // DMarket: a dashboard arranged around actual catalog price distribution.
        signature.setLayout(new GridLayout(1, 2, 22, 0));
        signature.add(
            app.exchangeHomeScreen.exchangeSignatureTile(
                p,
                "THE GLOBAL TRADING FLOOR",
                "Market pulse",
                available,
                "Open the trading floor",
                buy));
        JPanel dm = app.cs2Screens.cs2Glass(new GridLayout(2, 2, 12, 12));
        dm.add(
            app.marketHomeScreen.createMarketplaceHomeStatCard(
                "LIVE STOCK", String.format("%,d", units), app.exchangeWidgets.exchangeAccent(p)));
        dm.add(
            app.marketHomeScreen.createMarketplaceHomeStatCard(
                "OFFER LOTS",
                String.format("%,d", stock.size()),
                app.exchangeWidgets.exchangeAccent(p)));
        dm.add(
            app.marketHomeScreen.createMarketplaceHomeStatCard(
                "QUICK PAYOUT", "90%", app.exchangeWidgets.exchangeAccent(p)));
        dm.add(
            app.marketHomeScreen.createMarketplaceHomeStatCard(
                "SELLER FEE", "4%", app.exchangeWidgets.exchangeAccent(p)));
        signature.add(dm);
        break;
      case 3: // LIS-SKINS: three ticket-like transaction entrances.
        signature.setLayout(new GridLayout(1, 3, 16, 0));
        signature.add(
            app.exchangeHomeScreen.exchangeSignatureTile(
                p, "01 / DISCOVER", "Rare finds.", available, "Buy skins", buy));
        signature.add(
            app.exchangeHomeScreen.exchangeSignatureTile(
                p,
                "02 / INSTANT CASH",
                "No waiting.",
                "Receive 91% of reference value with a quick sale.",
                "Quick sell",
                sell));
        signature.add(
            app.exchangeHomeScreen.exchangeSignatureTile(
                p,
                "03 / YOUR PRICE",
                "Your terms.",
                "List your skin. A 3% fee applies only when sold.",
                "List a skin",
                sell));
        break;
      case 4: // Skins.com: a visual loadout shop rather than a finance dashboard.
        signature.add(
            app.exchangeHomeScreen.exchangeSignatureTile(
                p,
                "BUILD YOUR NEXT LOADOUT",
                "Pick your playstyle.",
                available,
                "Browse the armory",
                buy),
            BorderLayout.WEST);
        JPanel armory = app.cs2Screens.cs2Glass(new GridLayout(1, 2, 12, 0));
        armory.add(app.exchangeHomeScreen.exchangeSignatureArt(p, first, true));
        armory.add(app.exchangeHomeScreen.exchangeSignatureArt(p, second, true));
        signature.add(armory);
        break;
      case 5: // Skin.Land: a three-way route, with the swap entrance as the primary action.
        signature.add(
            app.exchangeHomeScreen.exchangeSignatureTile(
                p,
                "WELCOME TO SKIN.LAND",
                "A better home for your skins.",
                available,
                "Swap your skins →",
                swap));
        JPanel paths = app.cs2Screens.cs2Glass(new GridLayout(3, 1, 0, 10));
        paths.add(app.exchangeWidgets.exchangeButton(p, "BUY / Explore new arrivals", buy));
        paths.add(app.exchangeWidgets.exchangeButton(p, "SELL / Instant payout", sell));
        paths.add(app.exchangeWidgets.exchangeButton(p, "SWAP / Upgrade your inventory", swap));
        paths.setPreferredSize(new Dimension(340, 220));
        signature.add(paths, BorderLayout.EAST);
        break;
      case 6: // TradeDock: manifest desk.
        signature.add(
            app.exchangeHomeScreen.exchangeSignatureTile(
                p,
                "PORT AUTHORITY / TRADEDOCK",
                "Ready to ship.",
                available,
                "Open the manifest",
                buy),
            BorderLayout.WEST);
        signature.add(app.exchangeHomeScreen.exchangeSignatureRows(p, skins, 4, false));
        break;
      case 7: // VaultDrop: a vault centerpiece and catalog gates underneath.
        JLabel vaultTitle =
            app.exchangeWidgets.exchangeLabel(
                "V A U L T D R O P   /   THE VAULT IS OPEN",
                25,
                app.exchangeWidgets.exchangeAccent(p));
        vaultTitle.setHorizontalAlignment(SwingConstants.CENTER);
        signature.add(vaultTitle, BorderLayout.NORTH);
        signature.add(app.exchangeHomeScreen.exchangeSignatureArt(p, first, true));
        JPanel gates = app.cs2Screens.cs2Glass(new GridLayout(1, 3, 16, 0));
        gates.add(
            app.exchangeWidgets.exchangeButton(
                p, "DISCOVER  /  " + String.format("%,d", units), buy));
        gates.add(app.exchangeWidgets.exchangeButton(p, "RELEASE A SKIN", sell));
        gates.add(app.exchangeWidgets.exchangeButton(p, "VIEW ALL ARRIVALS", buy));
        signature.add(gates, BorderLayout.SOUTH);
        break;
      case 8: // Skinport: reputation rail beside a restrained catalog introduction.
        JPanel reputation = app.exchangeWidgets.exchangePanel(p, new GridLayout(0, 1, 0, 8));
        reputation.setPreferredSize(new Dimension(245, 240));
        reputation.setBorder(BorderFactory.createEmptyBorder(20, 18, 20, 18));
        reputation.add(
            app.exchangeWidgets.exchangeLabel("MARKETPLACE PROFILE", 12, Theme.TEXT_DIM));
        reputation.add(app.exchangeWidgets.exchangeLabel("★ ★ ★ ★ ★", 26, new Color(61, 190, 148)));
        reputation.add(
            app.exchangeWidgets.exchangeLabel(
                String.format("%.1f / 5.0", p.rating), 32, Color.WHITE));
        reputation.add(
            app.exchangeWidgets.exchangeLabel(
                p.reviews + " • simulator profile", 11, Theme.TEXT_DIM));
        signature.add(reputation, BorderLayout.WEST);
        signature.add(
            app.exchangeHomeScreen.exchangeSignatureTile(
                p,
                "COUNTER-STRIKE 2 MARKET",
                "Find your next favourite.",
                available,
                "See all available items →",
                buy));
        break;
      case 9: // Waxpeer: a visible peer offer book, not generic merchandising.
        signature.add(
            app.exchangeHomeScreen.exchangeSignatureTile(
                p, "THE PEER OFFER BOOK", "See the ask.", available, "Browse peer offers", buy),
            BorderLayout.WEST);
        List<MarketListing> low = new ArrayList<>(skins);
        low.sort(Comparator.comparingDouble(MarketListing::getPrice));
        signature.add(app.exchangeHomeScreen.exchangeSignatureRows(p, low, 4, false));
        break;
      case 10: // FloatFlip: the lowest real stock floats lead the page.
        signature.add(
            app.exchangeHomeScreen.exchangeSignatureTile(
                p,
                "FLOAT-FIRST COLLECTING",
                "Every decimal tells a story.",
                available,
                "Find your float",
                buy),
            BorderLayout.WEST);
        List<MarketListing> precision = new ArrayList<>(skins);
        precision.removeIf(l -> app.floatRules.hasNoFloatWear(l.item.name));
        precision.sort(Comparator.comparingDouble(l -> l.item.itemFloat));
        signature.add(app.exchangeHomeScreen.exchangeSignatureRows(p, precision, 4, true));
        break;
      case 11: // HaloSkins: a personal concierge split with one gallery piece.
        signature.add(
            app.exchangeHomeScreen.exchangeSignatureArt(p, first, true), BorderLayout.WEST);
        signature.add(
            app.exchangeHomeScreen.exchangeSignatureTile(
                p,
                "THE COLLECTION CONCIERGE",
                "Exceptional skins. Personal choice.",
                available,
                "Explore the selection",
                buy));
        JPanel concierge = app.cs2Screens.cs2Glass(new GridLayout(2, 1, 0, 12));
        concierge.add(app.exchangeWidgets.exchangeButton(p, "Build your collection", buy));
        concierge.add(app.exchangeWidgets.exchangeButton(p, "Release a collectible", sell));
        signature.add(concierge, BorderLayout.EAST);
        break;
      case 12: // NeonGrid: geometric stock distribution, calculated from this site's actual stock.
        signature.add(
            app.exchangeHomeScreen.exchangeSignatureTile(
                p,
                "NETWORK // ONLINE",
                "UPGRADE YOUR SIGNAL.",
                available,
                "CONNECT TO EXCHANGE",
                swap),
            BorderLayout.WEST);
        JPanel distribution = app.exchangeWidgets.exchangePanel(p, new GridLayout(0, 1, 0, 12));
        for (String c : new String[] {"Knives", "Gloves", "Rifles", "Cases"}) {
          int quantity = 0;
          for (MarketListing l : stock)
            if (app.exchangeCatalogScreens.exchangeMatchesCategory(l, c)) quantity += l.quantity;
          JPanel row = app.cs2Screens.cs2Glass(new BorderLayout(15, 0));
          row.add(
              app.exchangeWidgets.exchangeLabel(
                  c.toUpperCase(java.util.Locale.ROOT), 13, app.exchangeWidgets.exchangeAccent(p)),
              BorderLayout.WEST);
          JProgressBar bar = new JProgressBar(0, Math.max(1, units));
          bar.setValue(quantity);
          bar.setStringPainted(true);
          bar.setString(String.format("%,d units", quantity));
          bar.setForeground(app.exchangeWidgets.exchangeAccent(p).darker());
          bar.setBackground(new Color(20, 45, 49));
          row.add(bar);
          distribution.add(row);
        }
        signature.add(distribution);
        break;
      case 13: // MirageX: asymmetric discovery spread.
        signature.add(
            app.exchangeHomeScreen.exchangeSignatureTile(
                p,
                "THE MIRAGE EDIT",
                "Find the unexpected.",
                available,
                "Explore the collection",
                buy),
            BorderLayout.NORTH);
        JPanel mirage = app.cs2Screens.cs2Glass(new GridLayout(1, 3, 26, 0));
        mirage.add(app.exchangeHomeScreen.exchangeSignatureArt(p, first, false));
        mirage.add(app.exchangeHomeScreen.exchangeSignatureArt(p, second, false));
        mirage.add(
            app.exchangeHomeScreen.exchangeSignatureTile(
                p,
                "DISCOVER",
                "Something different.",
                "A new finish for your next match.",
                "Browse all",
                buy));
        signature.add(mirage);
        break;
      case 14: // EmberSkins: an orange hot-drop wall of distinct premium stock.
        signature.add(
            app.exchangeWidgets.exchangeLabel(
                "HOT DROPS  /  BRING THE HEAT", 25, app.exchangeWidgets.exchangeAccent(p)),
            BorderLayout.NORTH);
        JPanel heat = app.cs2Screens.cs2Glass(new GridLayout(1, 3, 14, 0));
        heat.add(app.exchangeHomeScreen.exchangeSignatureArt(p, first, true));
        heat.add(app.exchangeHomeScreen.exchangeSignatureArt(p, second, true));
        heat.add(
            app.exchangeHomeScreen.exchangeSignatureTile(
                p, "EMBER SKINS", "Ignite your loadout.", available, "Shop the heat", buy));
        signature.add(heat);
        break;
      case 15: // FrostBid: minimal decimal display with a cool editorial panel.
        signature.add(
            app.exchangeHomeScreen.exchangeSignatureTile(
                p,
                "THE FROST COLLECTION",
                "A cooler way to shop.",
                available,
                "Explore precision picks",
                buy),
            BorderLayout.EAST);
        JPanel frost = app.cs2Screens.cs2Glass(new GridLayout(1, 2, 20, 0));
        frost.add(app.exchangeHomeScreen.exchangeSignatureArt(p, first, true));
        frost.add(app.exchangeHomeScreen.exchangeSignatureArt(p, second, true));
        signature.add(frost);
        break;
      case 16: // RelayMarket: a terminal-like inventory relay.
        JLabel terminal =
            app.exchangeWidgets.exchangeLabel(
                "RELAY MARKET  //  AVAILABLE NOW  //  " + String.format("%,d UNITS", units),
                22,
                app.exchangeWidgets.exchangeAccent(p));
        terminal.setFont(new Font("Monospaced", Font.BOLD, 22));
        signature.add(terminal, BorderLayout.NORTH);
        signature.add(app.exchangeHomeScreen.exchangeSignatureRows(p, skins, 4, false));
        signature.add(
            app.exchangeWidgets.exchangeButton(p, "INITIATE INVENTORY RELAY  →", swap),
            BorderLayout.SOUTH);
        break;
      case 17: // VelvetTrade: a premium gallery plate, with the trade room off the editorial rail.
        signature.add(app.exchangeHomeScreen.exchangeSignatureArt(p, first, true));
        JPanel edit =
            app.exchangeHomeScreen.exchangeSignatureTile(
                p,
                "THE VELVET EDIT",
                "Collect something extraordinary.",
                available,
                "Enter the trade room",
                swap);
        edit.setPreferredSize(new Dimension(430, 220));
        signature.add(edit, BorderLayout.EAST);
        break;
      default:
        return standardHero;
    }
    signature.setMaximumSize(new Dimension(Integer.MAX_VALUE, style == 13 ? 350 : 310));
    return signature;
  }
}
