package blahblah;

import java.awt.*;
import java.math.BigDecimal;
import javax.swing.*;

/** Collection-icon selector and four-column collection view; never reparents the legacy Armoury. */
final class ArmouryBrowserScreen {
  private final hGui app;
  private final JPanel host;
  private int agentPage;

  ArmouryBrowserScreen(hGui app, JPanel host) {
    this.app = app;
    this.host = host;
  }

  static JPanel scene() {
    return new JPanel(new BorderLayout()) {
      protected void paintComponent(Graphics graphics) {
        Graphics2D g = (Graphics2D) graphics.create();
        g.setPaint(
            new GradientPaint(
                0, 0, new Color(19, 59, 48), getWidth(), getHeight(), new Color(23, 39, 58)));
        g.fillRect(0, 0, getWidth(), getHeight());
        g.setColor(new Color(177, 227, 198, 10));
        for (int x = 12; x < getWidth(); x += 22)
          for (int y = 12; y < getHeight(); y += 22) g.fillOval(x, y, 2, 2);
        g.dispose();
      }
    };
  }

  private static void styleScroll(JScrollPane pane) {
    pane.setOpaque(false);
    pane.getViewport().setOpaque(false);
    pane.setBorder(null);
    for (JScrollBar bar :
        new JScrollBar[] {pane.getHorizontalScrollBar(), pane.getVerticalScrollBar()}) {
      bar.setPreferredSize(new Dimension(8, 8));
      bar.setUI(
          new javax.swing.plaf.basic.BasicScrollBarUI() {
            protected void configureScrollBarColors() {
              thumbColor = new Color(69, 107, 100);
              trackColor = new Color(20, 46, 44);
            }

            protected JButton createDecreaseButton(int orientation) {
              JButton b = new JButton();
              b.setPreferredSize(new Dimension(0, 0));
              return b;
            }

            protected JButton createIncreaseButton(int orientation) {
              return createDecreaseButton(orientation);
            }
          });
    }
  }

  static String[][] tiers(ArmouryCollection c) {
    return new String[][] {
      c.covertNames,
      c.classifiedNames,
      c.restrictedNames,
      c.milspecNames,
      c.industrialNames,
      c.consumerNames
    };
  }

  static String preview(ArmouryCollection c) {
    for (String[] tier : tiers(c)) if (tier != null && tier.length > 0) return tier[0];
    return null;
  }

  void render(int index) {
    index = Math.max(0, Math.min(index, hGui.ARMOURY_COLLECTIONS.length - 1));
    if (hGui.ARMOURY_COLLECTIONS[index].name.contains("Achroma")) index = 0;
    if (index != app.lastArmouryTabIndex) agentPage = 0;
    app.lastArmouryTabIndex = index;
    ArmouryCollection selected = hGui.ARMOURY_COLLECTIONS[index];
    host.removeAll();
    host.setLayout(new BorderLayout(0, 7));
    host.setBorder(BorderFactory.createEmptyBorder(8, 22, 10, 22));
    host.setName("modernArmouryBrowser");
    JPanel top = app.cs2Screens.cs2Glass(new BorderLayout(0, 6));
    JPanel title = app.cs2Screens.cs2Glass(new BorderLayout());
    title.add(app.cs2Screens.cs2Text("THE ARMOURY", 25, Color.WHITE), BorderLayout.WEST);
    JLabel stars =
        app.cs2Screens.cs2Text("★ " + app.playerStars + " Stars", 19, new Color(157, 235, 201));
    stars.setName("armouryStars");
    title.add(stars, BorderLayout.EAST);
    top.add(title, BorderLayout.NORTH);
    JPanel icons = app.cs2Screens.cs2Glass(null);
    icons.setLayout(new GridLayout(1, 0, 5, 0));
    icons.setPreferredSize(
        new Dimension(
            Math.min(1260, Math.max(900, host.getWidth() > 0 ? host.getWidth() - 60 : 1120)), 100));
    icons.setName("armouryCollectionIcons");
    JButton chosen = null;
    for (int n = 0; n < hGui.ARMOURY_COLLECTIONS.length; n++) {
      if (hGui.ARMOURY_COLLECTIONS[n].name.contains("Achroma")) continue;
      final int pick = n;
      ArmouryCollection c = hGui.ARMOURY_COLLECTIONS[n];
      JButton icon = app.cs2Screens.cs2Button("", false, e -> render(pick));
      icon.setLayout(new BorderLayout(0, 5));
      icon.setPreferredSize(new Dimension(90, 100));
      icon.setMinimumSize(new Dimension(90, 100));
      icon.setMaximumSize(new Dimension(90, 100));
      icon.setName("storeArmouryCollection-" + n);
      icon.setToolTipText(c.name);
      icon.setBorder(
          BorderFactory.createCompoundBorder(
              BorderFactory.createMatteBorder(
                  0, 0, 3, 0, n == index ? new Color(156, 232, 202) : new Color(56, 74, 75)),
              BorderFactory.createEmptyBorder(7, 5, 5, 5)));
      icon.setBackground(n == index ? new Color(48, 88, 83) : new Color(30, 52, 55));
      JLabel art = new JLabel("", SwingConstants.CENTER);
      ImageIcon logo = ArmouryCollectionIcons.icon(c.name);
      Image agentPreview = c.isAgents ? BundledAgentPreviews.image(preview(c)) : null;
      if (agentPreview != null)
        art.setIcon(new ImageIcon(app.cs2Screens.scaleCs2Image(agentPreview, 58, 48)));
      else if (logo != null)
        art.setIcon(new ImageIcon(app.cs2Screens.scaleCs2Image(logo.getImage(), 58, 48)));
      else if (preview(c) != null)
        app.artworkService.getSkinImageFromName(preview(c), "Factory New", art, 58, 48);
      art.setPreferredSize(new Dimension(76, 64));
      icon.add(art, BorderLayout.CENTER);
      JLabel text =
          new JLabel(
              "<html><center>"
                  + c.name
                      .replace(" Collection", "")
                      .replaceFirst("^The ", "")
                      .replace(" & ", " &amp; ")
                  + "</center></html>",
              SwingConstants.CENTER);
      text.setForeground(Color.WHITE);
      text.setFont(app.cs2Screens.cs2Font(Font.PLAIN, 10));
      text.setPreferredSize(new Dimension(82, 30));
      icon.add(text, BorderLayout.SOUTH);
      // Labels must forward clicks too: the whole icon card is the selector.
      java.awt.event.MouseAdapter click =
          new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent e) {
              icon.doClick();
            }
          };
      art.addMouseListener(click);
      text.addMouseListener(click);
      icons.add(icon);

      if (n == index) chosen = icon;
    }
    JPanel selector = app.cs2Screens.cs2Glass(new GridBagLayout());
    selector.add(icons);
    selector.setPreferredSize(new Dimension(1100, 108));
    top.add(selector, BorderLayout.CENTER);
    JPanel collectionTitle = app.cs2Screens.cs2Glass(new BorderLayout(12, 8));
    JLabel collectionLabel =
        app.cs2Screens.cs2Text(selected.name.toUpperCase(java.util.Locale.ROOT), 20, Color.WHITE);
    collectionLabel.setHorizontalAlignment(SwingConstants.CENTER);
    collectionTitle.add(collectionLabel);
    JButton redeem =
        app.cs2Screens.cs2Button(
            "REDEEM " + app.itemMetadataService.getArmouryRedeemCost(selected) + "★", true, null);
    redeem.setName("armouryRedeem");
    redeem.setUI(new javax.swing.plaf.basic.BasicButtonUI());
    redeem.setContentAreaFilled(true);
    redeem.setOpaque(true);
    redeem.setBackground(new Color(44, 139, 77));
    redeem.setForeground(Color.WHITE);
    redeem.setBorder(BorderFactory.createEmptyBorder(13, 26, 13, 26));
    redeem.addActionListener(
        e -> app.armouryRedeemService.attemptArmouryRedeem(selected, stars, redeem, false));
    JPanel redeemBar = app.cs2Screens.cs2Glass(new BorderLayout());
    redeemBar.add(redeem, BorderLayout.EAST);
    int totalAgents = 0;
    for (String[] tier : tiers(selected)) if (tier != null) totalAgents += tier.length;
    if (selected.isAgents) {
      int pages = Math.max(1, (totalAgents + 15) / 16);
      agentPage = Math.max(0, Math.min(agentPage, pages - 1));
      JPanel paging = app.cs2Screens.cs2Glass(new FlowLayout(FlowLayout.LEFT, 8, 0));
      JButton previous =
          app.cs2Screens.cs2Button(
              "‹",
              false,
              e -> {
                agentPage--;
                render(app.lastArmouryTabIndex);
              });
      previous.setName("armouryAgentsPrevious");
      previous.setEnabled(agentPage > 0);
      JButton next =
          app.cs2Screens.cs2Button(
              "›",
              false,
              e -> {
                agentPage++;
                render(app.lastArmouryTabIndex);
              });
      next.setName("armouryAgentsNext");
      next.setEnabled(agentPage < pages - 1);
      paging.add(previous);
      paging.add(
          app.cs2Screens.cs2Text(
              "AGENTS  /  " + (agentPage + 1) + " OF " + pages + "  •  " + totalAgents + " AGENTS",
              12,
              new Color(186, 216, 210)));
      paging.add(next);
      redeemBar.add(paging, BorderLayout.WEST);
    }
    host.add(redeemBar, BorderLayout.SOUTH);
    top.add(collectionTitle, BorderLayout.SOUTH);
    host.add(top, BorderLayout.NORTH);
    JPanel grid = app.cs2Screens.cs2Grid(4, 8, 4);
    grid.setName("armourySkinGrid");
    String[] rarities =
        selected.isAgents
            ? new String[] {
              "Master",
              "Superior",
              "Exceptional",
              "Distinguished",
              "Industrial Grade",
              "Consumer Grade"
            }
            : new String[] {
              "Covert", "Classified", "Restricted", "Mil-Spec", "Industrial Grade", "Consumer Grade"
            };
    String[][] tiers = tiers(selected);
    int itemIndex = 0;
    for (int tier = tiers.length - 1; tier >= 0; tier--) {
      if (tiers[tier] == null) continue;
      for (String name : tiers[tier]) {
        int position = itemIndex++;
        if (selected.isAgents && (position < agentPage * 16 || position >= (agentPage + 1) * 16))
          continue;
        String rarity = rarities[tier];
        Color color = app.itemInspectionScreen.getRarityColor(rarity);
        JLabel art = app.armouryArtworkCache.label(name);
        art.setPreferredSize(new Dimension(250, 100));
        JPanel card = app.cs2Screens.cs2Glass(new BorderLayout(0, 3));
        card.setBorder(BorderFactory.createEmptyBorder(1, 3, 1, 3));
        card.add(art);
        JPanel caption = app.cs2Screens.cs2Glass(new BorderLayout(0, 1));
        JLabel dot = app.cs2Screens.cs2Text("●", 10, color);
        dot.setName("armouryRarityDot");
        dot.setHorizontalAlignment(SwingConstants.CENTER);
        caption.add(dot, BorderLayout.SOUTH);
        JLabel nameLabel =
            new JLabel(
                "<html><div style='width:190px;text-align:center;'>"
                    + name.replace("&", "&amp;").replace("<", "&lt;")
                    + "</div></html>",
                SwingConstants.CENTER);
        nameLabel.setFont(app.cs2Screens.cs2Font(Font.PLAIN, 11));
        nameLabel.setForeground(Color.WHITE);
        nameLabel.setName("armourySkinName");
        caption.add(nameLabel, BorderLayout.CENTER);
        caption.setPreferredSize(new Dimension(220, selected.isAgents ? 40 : 28));
        card.add(caption, BorderLayout.SOUTH);
        card.setToolTipText(name + " / " + rarity);
        app.cs2Screens.installCs2CardClick(
            card,
            new java.awt.event.MouseAdapter() {
              public void mouseClicked(java.awt.event.MouseEvent e) {
                double f = app.floatRules.applyFloatLimits(name, 0);
                String wear =
                    selected.isAgents ? "Normal" : app.floatRules.getConditionForFloat(name, f);
                InventoryItem sample =
                    new InventoryItem(
                        null, name, wear, rarity, BigDecimal.ZERO, f, false, 0, null, 0, true);
                app.cs2Screens.showCs2Inspect(sample);
              }
            });
        card.setCursor(Cursor.getPredefinedCursor(Cursor.HAND_CURSOR));
        card.setPreferredSize(new Dimension(300, 146));
        card.setName("armourySkinCard");
        card.putClientProperty("rarity", rarity);
        card.putClientProperty("catalogName", name);
        grid.add(card);
      }
    }
    JPanel fitted = app.cs2Screens.cs2Glass(null);
    fitted.setLayout(
        new LayoutManager() {
          public void addLayoutComponent(String name, Component c) {}

          public void removeLayoutComponent(Component c) {}

          public Dimension preferredLayoutSize(Container c) {
            return new Dimension(1050, 460);
          }

          public Dimension minimumLayoutSize(Container c) {
            return new Dimension(400, 100);
          }

          public void layoutContainer(Container c) {
            int width = Math.min(1120, c.getWidth());
            grid.setBounds((c.getWidth() - width) / 2, 0, width, c.getHeight());
          }
        });
    fitted.add(grid);
    host.add(fitted, BorderLayout.CENTER);
    host.revalidate();
    host.repaint();
    JButton selectedIcon = chosen;
    SwingUtilities.invokeLater(
        () -> {
          if (selectedIcon != null && selectedIcon.isShowing())
            icons.scrollRectToVisible(selectedIcon.getBounds());
        });
  }
}
