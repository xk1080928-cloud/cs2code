package blahblah;

import blahblah.hGui.*;
import java.awt.*;
import java.awt.event.*;
import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.StandardCopyOption;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.regex.Matcher;
import java.util.regex.Pattern;
import javax.swing.*;

/** Catalog Loading Service: focused feature implementation. */
final class CatalogLoadingService {
  private final hGui app;

  CatalogLoadingService(hGui app) {
    this.app = app;
  }

  void loadExternalSkinCatalog() {
    app.skinCatalogExecutor.execute(
        () -> {
          String json = null;
          try {
            if (Files.isRegularFile(app.skinCatalogFile)) {
              json = new String(Files.readAllBytes(app.skinCatalogFile), StandardCharsets.UTF_8);
              int loaded = app.catalogParsingService.applyExternalSkinCatalog(json);
              long age =
                  System.currentTimeMillis()
                      - Files.getLastModifiedTime(app.skinCatalogFile).toMillis();
              if (loaded > 0 && age < hGui.SKIN_CATALOG_REFRESH_MS) {
                System.out.println("Loaded " + loaded + " entries from cached CS2 skin catalog.");
                SwingUtilities.invokeLater(app.artworkService::refreshAfterCatalogLoad);
                return;
              }
            }

            HttpURLConnection connection =
                (HttpURLConnection)
                    java.net.URI.create(hGui.SKIN_CATALOG_URL).toURL().openConnection();
            connection.setRequestMethod("GET");
            connection.setRequestProperty("Accept", "application/json");
            connection.setRequestProperty("User-Agent", "CSGO-Skin-Simulator/1.0");
            connection.setConnectTimeout(10000);
            connection.setReadTimeout(30000);
            try {
              int status = connection.getResponseCode();
              if (status < 200 || status >= 300) {
                throw new IOException("CS2 skin catalog returned HTTP " + status + ".");
              }
              StringBuilder downloaded = new StringBuilder();
              try (BufferedReader reader =
                  new BufferedReader(
                      new InputStreamReader(connection.getInputStream(), StandardCharsets.UTF_8))) {
                String line;
                while ((line = reader.readLine()) != null) downloaded.append(line).append('\n');
              }
              String downloadedJson = downloaded.toString();
              int loaded = app.catalogParsingService.applyExternalSkinCatalog(downloadedJson);
              if (loaded == 0)
                throw new IOException("Downloaded CS2 skin catalog contained no usable entries.");
              Files.createDirectories(app.skinCatalogFile.getParent());
              Path temporaryFile =
                  app.skinCatalogFile.resolveSibling(app.skinCatalogFile.getFileName() + ".tmp");
              Files.write(temporaryFile, downloadedJson.getBytes(StandardCharsets.UTF_8));
              try {
                Files.move(
                    temporaryFile,
                    app.skinCatalogFile,
                    StandardCopyOption.REPLACE_EXISTING,
                    StandardCopyOption.ATOMIC_MOVE);
              } catch (java.nio.file.AtomicMoveNotSupportedException e) {
                Files.move(temporaryFile, app.skinCatalogFile, StandardCopyOption.REPLACE_EXISTING);
              }
              System.out.println("Downloaded " + loaded + " entries from the CS2 skin catalog.");
              SwingUtilities.invokeLater(app.artworkService::refreshAfterCatalogLoad);
            } finally {
              connection.disconnect();
            }
          } catch (IOException | SecurityException e) {
            if (json != null && !app.skinCatalog.isEmpty()) {
              System.err.println(
                  "Could not refresh CS2 skin catalog; using cached data: " + e.getMessage());
            } else {
              System.err.println("Could not load CS2 skin catalog: " + e.getMessage());
            }
          } finally {
            app.skinCatalogLoaded.countDown();
            app.startupScreen.recordStartupCatalogLoaded();
          }
        });
  }

  void loadExternalAgentCatalog() {
    app.skinCatalogExecutor.execute(
        () -> {
          String json = null;
          try {
            if (Files.isRegularFile(app.agentCatalogFile)) {
              json = new String(Files.readAllBytes(app.agentCatalogFile), StandardCharsets.UTF_8);
              int loaded = app.catalogParsingService.applyExternalAgentCatalog(json);
              long age =
                  System.currentTimeMillis()
                      - Files.getLastModifiedTime(app.agentCatalogFile).toMillis();
              if (loaded > 0 && age < hGui.SKIN_CATALOG_REFRESH_MS) {
                System.out.println("Loaded " + loaded + " entries from cached CS2 agent catalog.");
                SwingUtilities.invokeLater(app.artworkService::refreshAfterCatalogLoad);
                return;
              }
            }

            HttpURLConnection connection =
                (HttpURLConnection)
                    java.net.URI.create(hGui.AGENT_CATALOG_URL).toURL().openConnection();
            connection.setRequestMethod("GET");
            connection.setRequestProperty("Accept", "application/json");
            connection.setRequestProperty("User-Agent", "CSGO-Skin-Simulator/1.0");
            connection.setConnectTimeout(10000);
            connection.setReadTimeout(30000);
            try {
              int status = connection.getResponseCode();
              if (status < 200 || status >= 300) {
                throw new IOException("CS2 agent catalog returned HTTP " + status + ".");
              }
              StringBuilder downloaded = new StringBuilder();
              try (BufferedReader reader =
                  new BufferedReader(
                      new InputStreamReader(connection.getInputStream(), StandardCharsets.UTF_8))) {
                String line;
                while ((line = reader.readLine()) != null) downloaded.append(line).append('\n');
              }
              String downloadedJson = downloaded.toString();
              int loaded = app.catalogParsingService.applyExternalAgentCatalog(downloadedJson);
              if (loaded == 0)
                throw new IOException("Downloaded CS2 agent catalog contained no usable entries.");
              Files.createDirectories(app.agentCatalogFile.getParent());
              Path temporaryFile =
                  app.agentCatalogFile.resolveSibling(app.agentCatalogFile.getFileName() + ".tmp");
              Files.write(temporaryFile, downloadedJson.getBytes(StandardCharsets.UTF_8));
              try {
                Files.move(
                    temporaryFile,
                    app.agentCatalogFile,
                    StandardCopyOption.REPLACE_EXISTING,
                    StandardCopyOption.ATOMIC_MOVE);
              } catch (java.nio.file.AtomicMoveNotSupportedException e) {
                Files.move(
                    temporaryFile, app.agentCatalogFile, StandardCopyOption.REPLACE_EXISTING);
              }
              System.out.println("Downloaded " + loaded + " entries from the CS2 agent catalog.");
              SwingUtilities.invokeLater(app.artworkService::refreshAfterCatalogLoad);
            } finally {
              connection.disconnect();
            }
          } catch (IOException | SecurityException e) {
            if (json != null && !app.agentCatalog.isEmpty()) {
              System.err.println(
                  "Could not refresh CS2 agent catalog; using cached data: " + e.getMessage());
            } else {
              System.err.println("Could not load CS2 agent catalog: " + e.getMessage());
            }
          } finally {
            app.startupScreen.recordStartupCatalogLoaded();
          }
        });
  }

  void loadExternalCrateCatalog() {
    app.skinCatalogExecutor.execute(
        () -> {
          String json = null;
          try {
            app.skinCatalogLoaded.await();
            if (Files.isRegularFile(app.crateCatalogFile)) {
              json = new String(Files.readAllBytes(app.crateCatalogFile), StandardCharsets.UTF_8);
              int loaded = app.catalogLoadingService.applyExternalCrateCatalog(json);
              long age =
                  System.currentTimeMillis()
                      - Files.getLastModifiedTime(app.crateCatalogFile).toMillis();
              if (loaded > 0 && age < hGui.SKIN_CATALOG_REFRESH_MS) {
                System.out.println("Loaded " + loaded + " cases from cached CS2 crate catalog.");
                SwingUtilities.invokeLater(app.artworkService::refreshAfterCatalogLoad);
                return;
              }
            }

            HttpURLConnection connection =
                (HttpURLConnection)
                    java.net.URI.create(hGui.CRATE_CATALOG_URL).toURL().openConnection();
            connection.setRequestMethod("GET");
            connection.setRequestProperty("Accept", "application/json");
            connection.setRequestProperty("User-Agent", "CSGO-Skin-Simulator/1.0");
            connection.setConnectTimeout(10000);
            connection.setReadTimeout(30000);
            try {
              int status = connection.getResponseCode();
              if (status < 200 || status >= 300) {
                throw new IOException("CS2 crate catalog returned HTTP " + status + ".");
              }
              StringBuilder downloaded = new StringBuilder();
              try (BufferedReader reader =
                  new BufferedReader(
                      new InputStreamReader(connection.getInputStream(), StandardCharsets.UTF_8))) {
                String line;
                while ((line = reader.readLine()) != null) downloaded.append(line).append('\n');
              }
              String downloadedJson = downloaded.toString();
              int loaded = app.catalogLoadingService.applyExternalCrateCatalog(downloadedJson);
              if (loaded == 0)
                throw new IOException("Downloaded CS2 crate catalog contained no usable cases.");
              Files.createDirectories(app.crateCatalogFile.getParent());
              Path temporaryFile =
                  app.crateCatalogFile.resolveSibling(app.crateCatalogFile.getFileName() + ".tmp");
              Files.write(temporaryFile, downloadedJson.getBytes(StandardCharsets.UTF_8));
              try {
                Files.move(
                    temporaryFile,
                    app.crateCatalogFile,
                    StandardCopyOption.REPLACE_EXISTING,
                    StandardCopyOption.ATOMIC_MOVE);
              } catch (java.nio.file.AtomicMoveNotSupportedException e) {
                Files.move(
                    temporaryFile, app.crateCatalogFile, StandardCopyOption.REPLACE_EXISTING);
              }
              System.out.println("Downloaded " + loaded + " cases from the CS2 crate catalog.");
              SwingUtilities.invokeLater(app.artworkService::refreshAfterCatalogLoad);
            } finally {
              connection.disconnect();
            }
          } catch (InterruptedException e) {
            Thread.currentThread().interrupt();
            System.err.println("Could not wait for the skin catalog before loading case data.");
          } catch (IOException | SecurityException e) {
            if (json != null && CaseType.values().length > 9) {
              System.err.println(
                  "Could not refresh CS2 crate catalog; using cached data: " + e.getMessage());
            } else {
              System.err.println("Could not load CS2 crate catalog: " + e.getMessage());
            }
          } finally {
            app.startupScreen.recordStartupCatalogLoaded();
          }
        });
  }

  int applyExternalCrateCatalog(String json) {
    if (json == null || json.trim().isEmpty()) return 0;
    int arrayStart = json.indexOf('[');
    if (arrayStart < 0) return 0;
    int loaded = 0;
    List<SouvenirPackageData> souvenirPackages = new ArrayList<>();
    int cursor = arrayStart + 1;
    while (cursor < json.length()) {
      int objectStart = json.indexOf('{', cursor);
      if (objectStart < 0) break;
      int objectEnd = app.publicPriceFeeds.findJsonObjectEnd(json, objectStart);
      if (objectEnd < 0) break;
      String object = json.substring(objectStart, objectEnd + 1);
      cursor = objectEnd + 1;
      String crateName = app.catalogParsingService.extractCatalogString(object, "name", false);
      if (crateName == null || crateName.trim().isEmpty()) continue;
      String crateType = app.catalogParsingService.extractCatalogString(object, "type", false);
      if ("Souvenir".equalsIgnoreCase(crateType)) {
        String imageUrl = app.catalogParsingService.extractCatalogRootString(object, "image");
        String mapName = app.catalogLoadingService.resolveSouvenirMapName(crateName);
        if (mapName == null)
          mapName = crateName.replaceFirst("(?i)\\s+Souvenir Package$", "").trim();
        Matcher yearMatcher = Pattern.compile("(20\\d{2})").matcher(crateName);
        int releaseYear = yearMatcher.find() ? Integer.parseInt(yearMatcher.group(1)) : 0;
        Map<String, List<String>> souvenirDrops =
            app.catalogLoadingService.extractCrateRegularDrops(object);
        souvenirPackages.add(
            new SouvenirPackageData(crateName, imageUrl, mapName, releaseYear, souvenirDrops));
        continue;
      }
      boolean terminal =
          crateName.equalsIgnoreCase("Sealed Genesis Terminal")
              || crateName.equalsIgnoreCase("Sealed Dead Hand Terminal")
              || "Terminal".equalsIgnoreCase(crateType);
      if (!"Case".equalsIgnoreCase(crateType) && !terminal) continue;

      String imageUrl = app.catalogParsingService.extractCatalogRootString(object, "image");
      Map<String, List<String>> regularDrops = new HashMap<>();
      for (String tier :
          new String[] {
            "Consumer", "Industrial", "Milspec", "Restricted", "Classified", "Covert"
          }) {
        regularDrops.put(tier, new ArrayList<>());
      }
      Map<String, List<String>> parsedRegularDrops =
          app.catalogLoadingService.extractCrateRegularDrops(object);
      for (Map.Entry<String, List<String>> tier : parsedRegularDrops.entrySet()) {
        regularDrops.get(tier.getKey()).addAll(tier.getValue());
      }

      List<String> rareDrops = app.catalogLoadingService.extractCrateItems(object, "contains_rare");
      if (rareDrops.isEmpty() && !terminal) continue;
      Map<String, String> rareCategories = new LinkedHashMap<>();
      for (String rareDrop : rareDrops) {
        SkinMetadata metadata = app.skinCatalog.get(rareDrop);
        if (metadata != null
            && ("Knives".equals(metadata.category) || "Gloves".equals(metadata.category))) {
          rareCategories.put(rareDrop, metadata.category);
        } else if (rareDrop.contains("Gloves")) {
          rareCategories.put(rareDrop, "Gloves");
        } else {
          rareCategories.put(rareDrop, "Knives");
        }
      }
      CaseType.registerCatalogCase(crateName, regularDrops, rareDrops, rareCategories, imageUrl);
      CaseType registered =
          CaseType.CASES_BY_CRATE.get(crateName.toLowerCase(java.util.Locale.ROOT));
      registered.isTerminal = terminal;
      registered.releaseOrder = app.containerBrowserScreen.containerReleaseOrder(object, crateName);
      Double index = app.catalogParsingService.extractCatalogNumber(object, "def_index");
      // def_index is a string in the public API, and preserves chronology
      // when two events have the same/missing release date.
      String indexText = app.catalogParsingService.extractCatalogRootString(object, "def_index");
      try {
        registered.catalogOrder =
            indexText == null
                ? (index == null ? Integer.MAX_VALUE : index.intValue())
                : Integer.parseInt(indexText);
      } catch (NumberFormatException ignored) {
      }
      loaded++;
    }
    for (SouvenirPackageData packageData : souvenirPackages) {
      if (packageData.drops.values().stream().allMatch(List::isEmpty)) continue;
      CaseType.registerSouvenirPackage(
          packageData.crateName, packageData.mapName, packageData.drops, packageData.imageUrl);
      loaded++;
    }
    int metadataCursor = arrayStart + 1;
    while (metadataCursor < json.length()) {
      int start = json.indexOf('{', metadataCursor);
      if (start < 0) break;
      int end = app.publicPriceFeeds.findJsonObjectEnd(json, start);
      if (end < 0) break;
      String object = json.substring(start, end + 1);
      metadataCursor = end + 1;
      String name = app.catalogParsingService.extractCatalogRootString(object, "name");
      if (name == null) continue;
      CaseType ct = CaseType.CASES_BY_CRATE.get(name.toLowerCase(java.util.Locale.ROOT));
      if (ct == null) continue;
      ct.releaseOrder = app.containerBrowserScreen.containerReleaseOrder(object, name);
      String index = app.catalogParsingService.extractCatalogRootString(object, "def_index");
      try {
        if (index != null) ct.catalogOrder = Integer.parseInt(index);
      } catch (NumberFormatException ignored) {
      }
    }
    app.souvenirPackageSkinNameCache.clear();
    app.souvenirPackageSkinCacheBuilt = false;
    app.catalogCaseCollectionCache.clear();
    return loaded;
  }

  String resolveSouvenirMapName(String crateName) {
    String normalizedName = crateName.replaceFirst("(?i)\\s+Souvenir Package$", "").trim();
    String[] mapNames = {
      "Dust II", "Dust 2", "Dust", "Cobblestone", "Overpass", "Shortdust", "Vertigo",
      "Mirage", "Inferno", "Nuke", "Cache", "Train", "Ancient", "Anubis",
      "Italy", "Lake", "Office", "Agency", "Canals", "Baggage", "Shoots",
      "Safehouse", "St. Marc", "Blacksite"
    };
    for (String mapName : mapNames) {
      if (normalizedName.regionMatches(
          true, normalizedName.length() - mapName.length(), mapName, 0, mapName.length())) {
        return mapName;
      }
    }
    return null;
  }

  Map<String, List<String>> extractCrateRegularDrops(String crateObject) {
    Map<String, List<String>> dropsByTier = new HashMap<>();
    for (String tier :
        new String[] {"Consumer", "Industrial", "Milspec", "Restricted", "Classified", "Covert"}) {
      dropsByTier.put(tier, new ArrayList<>());
    }
    int arrayStart = app.catalogLoadingService.findJsonArrayFieldStart(crateObject, "contains");
    if (arrayStart < 0) return dropsByTier;
    int arrayEnd = app.catalogLoadingService.findJsonArrayEnd(crateObject, arrayStart);
    if (arrayEnd < 0) return dropsByTier;
    int cursor = arrayStart + 1;
    while (cursor < arrayEnd) {
      int itemStart = crateObject.indexOf('{', cursor);
      if (itemStart < 0 || itemStart >= arrayEnd) break;
      int itemEnd = app.publicPriceFeeds.findJsonObjectEnd(crateObject, itemStart);
      if (itemEnd < 0 || itemEnd > arrayEnd) break;
      String itemObject = crateObject.substring(itemStart, itemEnd + 1);
      String itemName = app.catalogParsingService.extractCatalogString(itemObject, "name", false);
      String rarityObject = app.publicPriceFeeds.findJsonObjectField(itemObject, "rarity");
      String rarity =
          rarityObject == null
              ? null
              : app.catalogParsingService.extractCatalogString(rarityObject, "name", false);
      String tier = app.collectionService.catalogRarityTier(rarity);
      if (itemName != null && tier != null) {
        dropsByTier.get(tier).add(app.catalogParsingService.normalizeCatalogSkinName(itemName));
      }
      cursor = itemEnd + 1;
    }
    return dropsByTier;
  }

  List<String> extractCrateItems(String crateObject, String fieldName) {
    int arrayStart = app.catalogLoadingService.findJsonArrayFieldStart(crateObject, fieldName);
    if (arrayStart < 0) return java.util.Collections.emptyList();
    int arrayEnd = app.catalogLoadingService.findJsonArrayEnd(crateObject, arrayStart);
    if (arrayEnd < 0) return java.util.Collections.emptyList();
    List<String> items = new ArrayList<>();
    int cursor = arrayStart + 1;
    while (cursor < arrayEnd) {
      int itemStart = crateObject.indexOf('{', cursor);
      if (itemStart < 0 || itemStart >= arrayEnd) break;
      int itemEnd = app.publicPriceFeeds.findJsonObjectEnd(crateObject, itemStart);
      if (itemEnd < 0 || itemEnd > arrayEnd) break;
      String itemObject = crateObject.substring(itemStart, itemEnd + 1);
      String itemName = app.catalogParsingService.extractCatalogString(itemObject, "name", false);
      if (itemName != null && !itemName.trim().isEmpty()) {
        String normalized = app.catalogParsingService.normalizeCatalogSkinName(itemName);
        if ("contains_rare".equals(fieldName) && !normalized.contains("|")) {
          normalized += " | Vanilla";
        }
        SkinMetadata metadata = app.skinCatalog.get(normalized);
        if (metadata != null && "Knives".equals(metadata.category) && !normalized.contains("|")) {
          normalized += " | Vanilla";
        }
        if (!items.contains(normalized)) items.add(normalized);
      }
      cursor = itemEnd + 1;
    }
    return items;
  }

  int findJsonArrayFieldStart(String jsonObject, String fieldName) {
    Matcher matcher =
        Pattern.compile("\"" + Pattern.quote(fieldName) + "\"\\s*:\\s*\\[").matcher(jsonObject);
    return matcher.find() ? jsonObject.indexOf('[', matcher.start()) : -1;
  }

  int findJsonArrayEnd(String json, int start) {
    int depth = 0;
    boolean inString = false;
    boolean escaped = false;
    for (int i = start; i < json.length(); i++) {
      char ch = json.charAt(i);
      if (inString) {
        if (escaped) escaped = false;
        else if (ch == '\\') escaped = true;
        else if (ch == '"') inString = false;
      } else if (ch == '"') {
        inString = true;
      } else if (ch == '[') {
        depth++;
      } else if (ch == ']' && --depth == 0) {
        return i;
      }
    }
    return -1;
  }
}
