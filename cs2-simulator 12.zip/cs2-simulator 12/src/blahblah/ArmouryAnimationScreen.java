package blahblah;

import blahblah.hGui.*;
import java.awt.*;
import java.awt.event.*;
import java.awt.image.BufferedImage;
import java.math.BigDecimal;
import java.math.RoundingMode;
import java.util.Map;
import javax.swing.*;

/** Armoury Animation Screen: focused feature implementation. */
final class ArmouryAnimationScreen {
  private final hGui app;

  ArmouryAnimationScreen(hGui app) {
    this.app = app;
  }

  void performArmouryRedeem(
      ArmouryCollection col,
      String skinName,
      String skinRarity,
      double basePrice,
      String imageFile,
      JButton redeemBtn,
      double speedMultiplier,
      boolean autoMode) {

    if (app.cs2ShellEnabled) {
      new ArmouryOrbit(app).start(col, skinName, skinRarity, basePrice, redeemBtn);
      return;
    }
    app.armouryAnimating = true;
    final Image finalSkinImg;

    final double itemFloat2;
    final String finalCondStr;
    final double finalPrice2;
    if (col.isAgents) {
      itemFloat2 = 0.0;
      finalCondStr = "Agent";
      finalPrice2 = basePrice * (app.marketPriceMultipliers.getOrDefault(skinRarity, 1.0));
    } else {
      FloatRange fr2 = hGui.FLOAT_LIMITS.get(skinName);
      if (fr2 == null)
        for (Map.Entry<String, FloatRange> e2 : hGui.FLOAT_LIMITS.entrySet())
          if (skinName.startsWith(e2.getKey())) {
            fr2 = e2.getValue();
            break;
          }
      double floatMin2 = (fr2 != null && fr2.min != null) ? fr2.min : 0.0;
      double floatMax2 = (fr2 != null && fr2.max != null) ? fr2.max : 0.80;
      double rawFloat = floatMin2 + hGui.random.nextDouble() * (floatMax2 - floatMin2);
      itemFloat2 = rawFloat;
      String condition2 = app.floatRules.getConditionForFloat(skinName, rawFloat);
      finalCondStr = condition2;
      double condMult = app.priceModifiers.getMarketConditionMultiplier(skinName, condition2);
      finalPrice2 =
          basePrice
              * app.marketInitialization.getMarketMultiplier(skinRarity, col.name)
              * condMult
              * (0.88 + hGui.random.nextDouble() * 0.24);
    }

    Image wearArtwork = app.artworkService.getSkinImageFromName(skinName, finalCondStr);
    finalSkinImg =
        wearArtwork == null ? app.containerBrowserScreen.createItemPlaceholderImage() : wearArtwork;
    final int FINAL_IDX = AnimationConfig.FINAL_INDEX;
    final int SKIN_W = AnimationConfig.SKIN_WIDTH, SKIN_H = AnimationConfig.SKIN_HEIGHT;
    final int SPACING = AnimationConfig.SPACING;

    Color rarCol =
        skinRarity.equals("Covert")
            ? Theme.RARITY_COVERT
            : skinRarity.equals("Master")
                ? Theme.RARITY_COVERT
                : skinRarity.equals("Classified")
                    ? Theme.RARITY_CLASSIFIED
                    : skinRarity.equals("Superior")
                        ? Theme.RARITY_CLASSIFIED
                        : skinRarity.equals("Restricted")
                            ? Theme.RARITY_RESTRICTED
                            : skinRarity.equals("Exceptional")
                                ? Theme.RARITY_RESTRICTED
                                : skinRarity.equals("Industrial")
                                    ? new Color(110, 190, 110)
                                    : skinRarity.equals("Distinguished")
                                        ? Theme.RARITY_MILSPEC
                                        : Theme.RARITY_MILSPEC;

    java.util.List<StripItem> strip = new java.util.ArrayList<>();
    for (int i = 0; i < AnimationConfig.STRIP_COUNT + 5; i++) {
      if (i == FINAL_IDX) strip.add(new StripItem(finalSkinImg, rarCol));
      else strip.add(app.armouryRedeemService.rollArmouryAnimationItem(col));
    }

    JDialog animDialog = new JDialog(app, "Opening - " + col.name, false);
    app.uiWidgets.configureOpeningDialog(animDialog);

    JPanel armouryHeader = new JPanel(new BorderLayout(8, 0));
    armouryHeader.setBackground(Theme.BG_DARK);
    armouryHeader.setOpaque(true);
    armouryHeader.setBorder(BorderFactory.createEmptyBorder(8, 8, 8, 8));
    JLabel topLbl = new JLabel("Opening " + col.name + "...", SwingConstants.CENTER);
    topLbl.setFont(new Font("Consolas", Font.BOLD, 15));
    topLbl.setForeground(Theme.ACCENT_CT);
    topLbl.setOpaque(false);
    armouryHeader.add(topLbl, BorderLayout.CENTER);
    if (autoMode) {
      JButton dialogStopButton = new JButton("STOP AUTO");
      app.uiWidgets.styleButton(
          dialogStopButton, new Color(80, 30, 30), new Color(220, 90, 90), new Color(220, 90, 90));
      dialogStopButton.setFont(Theme.CONSOLE_BOLD_12);
      dialogStopButton.setFocusable(false);
      dialogStopButton.addActionListener(
          evt -> {
            app.containerBrowserScreen.stopArmouryAutoOpen();
            dialogStopButton.setText("STOPPED");
            dialogStopButton.setEnabled(false);
          });
      Dimension stopSize = dialogStopButton.getPreferredSize();
      armouryHeader.add(Box.createRigidArea(stopSize), BorderLayout.WEST);
      armouryHeader.add(dialogStopButton, BorderLayout.EAST);
    }
    animDialog.add(armouryHeader, BorderLayout.NORTH);

    final int[] scrollPos = {0};
    final double randomBias = (hGui.random.nextDouble() - 0.5) * 100.0;
    final int targetPos =
        (int)
            (FINAL_IDX * SPACING - (AnimationConfig.DIALOG_WIDTH / 2) + (SKIN_W / 2) + randomBias);

    JPanel animPanel =
        new JPanel() {
          @Override
          protected void paintComponent(Graphics g) {
            super.paintComponent(g);
            Graphics2D g2 = (Graphics2D) g;
            g2.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
            g2.setRenderingHint(RenderingHints.KEY_RENDERING, RenderingHints.VALUE_RENDER_QUALITY);
            java.awt.GradientPaint bgGrad =
                new java.awt.GradientPaint(
                    0, 0, Theme.PLACEHOLDER_BG, 0, getHeight(), Theme.BG_CARD);
            g2.setPaint(bgGrad);
            g2.fillRect(0, 0, getWidth(), getHeight());
            int cx = getWidth() / 2;
            int cy = getHeight() / 2;
            int startX = -scrollPos[0];
            for (int si = 0; si < strip.size(); si++) {
              int x = startX + si * SPACING;
              int y = cy - SKIN_H / 2;
              if (x + SKIN_W < 0 || x > getWidth()) continue;
              StripItem stripItem = strip.get(si);
              Image img = stripItem.image;
              g2.setColor(Theme.ANIM_ARMOURY_CARD);
              g2.fillRoundRect(x, y, SKIN_W, SKIN_H, 8, 8);
              int ip = 10;
              g2.drawImage(img, x + ip, y + ip, SKIN_W - ip * 2, SKIN_H - ip * 2 - 8, null);
              int barH = 8;
              Color rc =
                  stripItem.rarityColor != null ? stripItem.rarityColor : Theme.RARITY_MILSPEC;
              java.awt.GradientPaint barGrad =
                  new java.awt.GradientPaint(x, 0, rc.darker(), x + SKIN_W, 0, rc.brighter());
              g2.setPaint(barGrad);
              g2.fillRoundRect(x, y + SKIN_H - barH, SKIN_W, barH, 4, 4);
              g2.fillRect(x, y + SKIN_H - barH, SKIN_W, barH / 2);
              g2.setPaint(null);
            }
            g2.setColor(Theme.GOLD);
            g2.setStroke(Theme.STROKE_2_5);
            g2.drawLine(cx, 0, cx, getHeight());
          }
        };
    animPanel.setOpaque(true);
    animPanel.setBackground(Theme.PLACEHOLDER_BG);
    animPanel.setPreferredSize(
        new Dimension(AnimationConfig.DIALOG_WIDTH, AnimationConfig.PANEL_HEIGHT));
    animDialog.add(animPanel, BorderLayout.CENTER);

    final int armouryPatternId = hGui.random.nextInt(1000);
    final boolean[] resultClaimed = {false};
    Runnable commitReward =
        () -> {
          if (resultClaimed[0]) return;
          resultClaimed[0] = true;
          int finalSkinWidth = finalSkinImg != null ? finalSkinImg.getWidth(null) : -1;
          int finalSkinHeight = finalSkinImg != null ? finalSkinImg.getHeight(null) : -1;
          Image scaledSkinImg =
              finalSkinImg != null
                  ? finalSkinImg
                  : new BufferedImage(1, 1, BufferedImage.TYPE_INT_ARGB);
          if (finalSkinWidth > 0 && finalSkinHeight > 0) {
            double scl2 = Math.min(130.0 / finalSkinWidth, 88.0 / finalSkinHeight);
            scaledSkinImg =
                HighQualityImages.fit(
                    finalSkinImg, (int) (finalSkinWidth * scl2), (int) (finalSkinHeight * scl2));
          }
          InventoryItem item2 =
              new InventoryItem(
                  new ImageIcon(scaledSkinImg),
                  skinName,
                  finalCondStr,
                  skinRarity,
                  BigDecimal.valueOf(finalPrice2).setScale(2, RoundingMode.HALF_UP),
                  itemFloat2,
                  false,
                  armouryPatternId,
                  null,
                  basePrice);
          item2.collection = col.name;
          app.ownershipHistoryService.addItemHistory(
              item2,
              System.currentTimeMillis(),
              "Armoury Redeem",
              String.format("armoury redeem by YOU from %s", col.name),
              "YOU");
          app.activitySimulationService.addRecentUnboxedSkin(item2);
          app.globalSupply.created(item2);
          app.inventoryList.add(item2);
          app.coreUtilities.addInventoryValue(finalPrice2);
          app.statisticsAndAchievements.recordArmouryOpening(skinRarity, skinName, itemFloat2);
          app.caseRollService.writeStats();
          if (app.cs2ShellEnabled) {
            app.cs2UnlockSelection = null;
            app.cs2InventorySection = "EVERYTHING";
            app.cs2EquipFilter = null;
            app.cs2InventorySearch = "";
            app.cs2InventoryPage = 0;
            app.containerSelectionScreen.invalidateCs2Inventory();
            app.cs2Screens.refreshCs2Inventory();
            app.saveService.saveProgressAsync();
          }
        };
    ActionListener closeResult =
        evv -> {
          commitReward.run();
          app.armouryAnimating = false;
          animDialog.dispose();
          app.armouryScreen.refreshArmouryTab();
        };
    String infoHtml =
        app.uiWidgets.buildItemInfoHtml(
            skinRarity, finalCondStr, itemFloat2, armouryPatternId, col.name, col.isAgents);
    FadePanel resultPanel =
        app.uiWidgets.createRewardResultPanel(
            finalSkinImg,
            col.isAgents ? skinName : skinName + "  (" + finalCondStr + ")",
            "",
            rarCol,
            infoHtml,
            "CLOSE",
            closeResult);
    app.artworkService.getSkinImageFromName(
        skinName, finalCondStr, app.activeResultImageLabel, 430, 285);

    animDialog.setVisible(true);

    javax.swing.Timer scrollTimer = new javax.swing.Timer(AnimationConfig.TIMER_DELAY_MS, null);
    animDialog.addWindowListener(
        new java.awt.event.WindowAdapter() {
          @Override
          public void windowClosed(java.awt.event.WindowEvent e) {
            boolean quickOpen = !resultClaimed[0];
            int beforeReward = app.inventoryList.size();
            scrollTimer.stop();
            commitReward.run();
            if (quickOpen && app.cs2ShellEnabled && app.inventoryList.size() > beforeReward) {
              app.itemRevealService.received(app.inventoryList.get(app.inventoryList.size() - 1));
              app.navigationService.mainInventory();
              SwingUtilities.invokeLater(app.itemRevealService::showPending);
            }
            app.armouryAnimating = false;
            if (redeemBtn != null) redeemBtn.setEnabled(true);
          }
        });
    scrollTimer.addActionListener(
        new ActionListener() {
          double currentOffset = 0.0;
          double velocity = 0.0;
          int prevCenterIdx = -1;
          int previousScrollPos = -1;

          @Override
          public void actionPerformed(ActionEvent e) {
            double distance = targetPos - currentOffset;
            double maxSpeed = AnimationConfig.MAX_SPEED * speedMultiplier;
            if (distance > AnimationConfig.DECEL_ZONE) {
              velocity =
                  Math.min(velocity + (AnimationConfig.ACCELERATION * speedMultiplier), maxSpeed);
            } else {
              double factor = distance / AnimationConfig.DECEL_ZONE;
              velocity = maxSpeed * factor;
            }
            if (distance < 260) velocity *= 0.96;
            velocity = Math.min(velocity, distance);
            currentOffset += velocity;
            int nextScrollPos = (int) currentOffset;
            if (nextScrollPos == previousScrollPos && velocity >= AnimationConfig.STOP_VELOCITY) {
              return;
            }
            scrollPos[0] = nextScrollPos;
            previousScrollPos = nextScrollPos;
            int centerIdx = (scrollPos[0] + 400) / SPACING;
            if (centerIdx != prevCenterIdx && centerIdx >= 0 && centerIdx < strip.size()) {
              prevCenterIdx = centerIdx;
            }
            animPanel.repaint();

            if (velocity < AnimationConfig.STOP_VELOCITY) {
              scrollTimer.stop();
              commitReward.run();
              javax.swing.Timer delayTimer =
                  new javax.swing.Timer(
                      Math.max(250, (int) (AnimationConfig.RESULT_DELAY_MS / speedMultiplier)),
                      evt -> {
                        if (!animDialog.isDisplayable()) return;
                        BufferedImage backdrop =
                            new BufferedImage(
                                Math.max(1, animDialog.getContentPane().getWidth()),
                                Math.max(1, animDialog.getContentPane().getHeight()),
                                BufferedImage.TYPE_INT_RGB);
                        Graphics2D oldFrame = backdrop.createGraphics();
                        animDialog.getContentPane().paint(oldFrame);
                        oldFrame.dispose();
                        resultPanel.setBackdrop(backdrop);
                        topLbl.setText("Redeemed " + skinName);
                        animDialog.remove(animPanel);
                        animDialog.add(resultPanel, BorderLayout.CENTER);
                        animDialog.revalidate();
                        app.uiWidgets.fadeInPanel(resultPanel, animDialog);
                        if (app.armouryAutoTimer != null && app.armouryAutoTimer.isRunning()) {
                          javax.swing.Timer nextTimer =
                              new javax.swing.Timer(
                                  850,
                                  nextEvt ->
                                      closeResult.actionPerformed(
                                          new ActionEvent(
                                              animDialog,
                                              ActionEvent.ACTION_PERFORMED,
                                              "ARMOURY_AUTO_NEXT")));
                          nextTimer.setRepeats(false);
                          nextTimer.start();
                        }
                      });
              delayTimer.setRepeats(false);
              delayTimer.start();
            }
          }
        });
    scrollTimer.start();
  }
}
