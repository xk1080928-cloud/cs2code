package blahblah;

import blahblah.hGui.*;
import java.awt.*;
import java.awt.event.*;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import javax.swing.*;

/** Sales Simulation Service: focused feature implementation. */
final class SalesSimulationService {
  private final hGui app;

  SalesSimulationService(hGui app) {
    this.app = app;
  }

  double getSimulatedSalesPerMinute(String rarity, double price, boolean statTrak) {
    if (!Double.isFinite(price) || price <= 0) return 0;
    double base;
    switch (rarity == null ? "" : rarity.replace("StatTrak ", "")) {
      case "Consumer":
        base = 210;
        break;
      case "Industrial":
        base = 150;
        break;
      case "Milspec":
      case "Mil-Spec":
      case "Distinguished":
        base = 100;
        break;
      case "Restricted":
      case "Exceptional":
        base = 60;
        break;
      case "Classified":
      case "Superior":
        base = 30;
        break;
      case "Covert":
      case "Master":
        base = 12;
        break;
      case "Contraband":
        base = 5;
        break;
      case "Knife":
        base = 2.4;
        break;
      case "Gloves":
        base = 1.8;
        break;
      default:
        base = 60;
    }
    // Absolute cash-price elasticity: doubling price reduces activity by about 38%.
    double priceWeight = Math.pow(Math.max(.01, price) / 5.0, -.70);
    return Math.max(.0005, Math.min(240, base * priceWeight * (statTrak ? .45 : 1.0)));
  }

  static long simulatedSaleHash(long value) {
    value = (value ^ (value >>> 30)) * 0xbf58476d1ce4e5b9L;
    value = (value ^ (value >>> 27)) * 0x94d049bb133111ebL;
    return value ^ (value >>> 31);
  }

  void initializeSimulatedSalesHistory() {
    app.simulatedSalesReady = false;
    app.simulatedSalesStates.clear();
    app.simulatedSalesBySkin.clear();
    List<String> keys = new ArrayList<>(app.globalMarketListings.keySet());
    int checked = 0;
    long now = System.currentTimeMillis();
    for (String key : keys) {
      Map<String, MarketListing> cheapest = new LinkedHashMap<>();
      ArrayList<MarketListing> bucket = app.globalMarketListings.get(key);
      if (bucket != null)
        for (MarketListing listing : bucket) {
          if (listing == null
              || listing.item == null
              || listing.isPlayerListing
              || !Double.isFinite(listing.getPrice())
              || listing.getPrice() <= 0) continue;
          MarketListing before = cheapest.get(listing.item.condition);
          if (before == null || listing.getPrice() < before.getPrice())
            cheapest.put(listing.item.condition, listing);
        }
      for (MarketListing listing : cheapest.values()) {
        String modelKey = key + "\u001f" + listing.item.condition;
        SimulatedSalesState state =
            new SimulatedSalesState(app, modelKey, listing, listing.getPrice(), now);
        app.simulatedSalesStates.put(modelKey, state);
        app.simulatedSalesBySkin
            .computeIfAbsent(state.browseKey, k -> new ArrayList<>())
            .add(state);
      }
      if (++checked % 32 == 0 || checked == keys.size())
        app.startupScreen.setStartupProgress(
            95 + (int) Math.round(2.0 * checked / Math.max(1, keys.size())),
            "Creating simulated sales histories ("
                + checked
                + " / "
                + keys.size()
                + " market variants)...");
    }
    app.simulatedSalesReady = true;
  }

  void advanceSimulatedSales(long now) {
    if (!app.simulatedSalesReady) return;
    for (SimulatedSalesState state : app.simulatedSalesStates.values()) state.advance(now);
  }

  void startSimulatedSalesTimer() {
    if (app.simulatedSalesExecutor != null) app.simulatedSalesExecutor.shutdownNow();
    app.simulatedSalesExecutor =
        java.util.concurrent.Executors.newSingleThreadScheduledExecutor(
            task -> {
              Thread thread = new Thread(task, "market-sale-history");
              thread.setDaemon(true);
              return thread;
            });
    app.simulatedSalesExecutor.scheduleWithFixedDelay(
        () -> {
          try {
            app.salesSimulationService.advanceSimulatedSales(System.currentTimeMillis());
          } catch (RuntimeException ex) {
            System.err.println("Simulated sales history update failed: " + ex.getMessage());
          }
        },
        1,
        1,
        java.util.concurrent.TimeUnit.SECONDS);
  }

  List<SaleRecord> getSimulatedSalesForSkinView(String skin, String variant, String condition) {
    if (!app.simulatedSalesReady) return java.util.Collections.emptyList();
    List<SimulatedSalesState> states =
        app.simulatedSalesBySkin.get(app.marketGroupingService.getMarketplaceBrowseKey(skin));
    if (states == null) return java.util.Collections.emptyList();
    List<SaleRecord> sales = new ArrayList<>();
    long now = System.currentTimeMillis();
    for (SimulatedSalesState state : states) {
      if ("StatTrak Only".equals(variant) && !state.statTrak
          || "Non-StatTrak Only".equals(variant) && state.statTrak) continue;
      if (!"All Conditions".equals(condition) && !condition.equals(state.condition)) continue;
      sales.addAll(state.snapshot(now));
    }
    return sales;
  }

  double getSimulatedSalesRateForView(String skin, String variant, String condition) {
    if (!app.simulatedSalesReady) return 0;
    List<SimulatedSalesState> states =
        app.simulatedSalesBySkin.get(app.marketGroupingService.getMarketplaceBrowseKey(skin));
    if (states == null) return 0;
    double rate = 0;
    for (SimulatedSalesState state : states) {
      if ("StatTrak Only".equals(variant) && !state.statTrak
          || "Non-StatTrak Only".equals(variant) && state.statTrak) continue;
      if (!"All Conditions".equals(condition) && !condition.equals(state.condition)) continue;
      synchronized (state) {
        rate += state.rate;
      }
    }
    return rate;
  }

  void refillFairSalesQueue() {
    List<String> keys = new ArrayList<>(app.globalMarketListings.keySet());
    keys.sort(String.CASE_INSENSITIVE_ORDER);
    app.fairSalesQueue.addAll(keys);
  }

  void generateFairCoverageSales(int buckets, boolean onlyMissingHistory) {
    if (app.fairSalesQueue.isEmpty()) app.salesSimulationService.refillFairSalesQueue();
    for (int i = 0; i < buckets && !app.fairSalesQueue.isEmpty(); i++) {
      String key = app.fairSalesQueue.poll();
      ArrayList<MarketListing> listings = app.globalMarketListings.get(key);
      if (listings == null) continue;
      Map<String, MarketListing> byCondition = new LinkedHashMap<>();
      synchronized (listings) {
        for (MarketListing listing : listings) {
          if (listing == null
              || listing.item == null
              || listing.isPlayerListing
              || !Double.isFinite(listing.getPrice())
              || listing.getPrice() <= 0.0) continue;
          MarketListing cheapest = byCondition.get(listing.item.condition);
          if (cheapest == null || listing.getPrice() < cheapest.getPrice())
            byCondition.put(listing.item.condition, listing);
        }
        List<MarketListing> candidates = new ArrayList<>(byCondition.values());
        int cursor = app.fairSaleConditionCursor.getOrDefault(key, 0);
        for (int n = 0; n < candidates.size(); n++) {
          MarketListing listing = candidates.get((cursor + n) % candidates.size());
          String historyKey =
              app.salesHistoryScreen.getSaleHistoryKey(
                  listing.item.isStattrak ? "StatTrak " + listing.item.name : listing.item.name);
          Map<String, ArrayList<SaleRecord>> history = app.salesHistory.get(historyKey);
          if (onlyMissingHistory
              && history != null
              && history.containsKey(listing.item.condition)
              && !history.get(listing.item.condition).isEmpty()) continue;
          if (app.cs2ShellEnabled && listing.quantity > 1) {
            app.salesSimulationService.recordMarketListingSale(listing, null, null);
            app.exchangeTransactionService.consumeExchangeLot(listing);
          } else if (listings.remove(listing)) {
            app.marketPurchaseService.removeBlueGemListing(listing);
            app.salesSimulationService.recordMarketListingSale(listing, null, null);
          }
          // Initial coverage includes each available wear. Later sweeps
          // rotate wear and keep sales coming without dumping supply.
          if (!onlyMissingHistory) break;
        }
        app.fairSaleConditionCursor.put(key, cursor == Integer.MAX_VALUE ? 0 : cursor + 1);
      }
    }
    app.marketStockService.invalidateGroupedMarketListingsCache();
  }

  void startFakeSalesTimer() {
    app.fakeSalesTimer =
        new javax.swing.Timer(
            hGui.FAKE_SALES_MIN_DELAY,
            e -> {
              SwingUtilities.invokeLater(
                  () -> {
                    if (!app.marketInitialized) return;
                    double rarityRoll = hGui.random.nextDouble();
                    String targetRarity;
                    int nextDelay;

                    if (rarityRoll < 0.20) {
                      targetRarity = "Industrial";
                      nextDelay = 150 + hGui.random.nextInt(400);
                    } else if (rarityRoll < 0.38) {
                      targetRarity = "Milspec";
                      nextDelay = 200 + hGui.random.nextInt(500);
                    } else if (rarityRoll < 0.50) {
                      targetRarity = "Restricted";
                      nextDelay = 600 + hGui.random.nextInt(900);
                    } else if (rarityRoll < 0.59) {
                      targetRarity = "Distinguished";
                      nextDelay = 900 + hGui.random.nextInt(1200);
                    } else if (rarityRoll < 0.67) {
                      targetRarity = "Classified";
                      nextDelay = 1500 + hGui.random.nextInt(2000);
                    } else if (rarityRoll < 0.74) {
                      targetRarity = "Exceptional";
                      nextDelay = 1800 + hGui.random.nextInt(2000);
                    } else if (rarityRoll < 0.81) {
                      targetRarity = "Covert";
                      nextDelay = 2500 + hGui.random.nextInt(2500);
                    } else if (rarityRoll < 0.86) {
                      targetRarity = "Superior";
                      nextDelay = 2500 + hGui.random.nextInt(2500);
                    } else if (rarityRoll < 0.89) {
                      targetRarity = "Master";
                      nextDelay = 3200 + hGui.random.nextInt(2600);
                    } else if (rarityRoll < 0.94) {
                      targetRarity = "Knife";
                      nextDelay = 3000 + hGui.random.nextInt(3000);
                    } else {
                      targetRarity = "Gloves";
                      nextDelay = 3000 + hGui.random.nextInt(3000);
                    }

                    app.fakeSalesTimer.setDelay(nextDelay);

                    app.salesSimulationService.generateSaleFromActualListingByRarity(targetRarity);
                  });
            });
    app.fakeSalesTimer.start();
  }

  Map.Entry<String, MarketListing> chooseWeightedMarketSaleCandidateEntry(String targetRarity) {
    ArrayList<Map.Entry<String, MarketListing>> candidates = new ArrayList<>();
    Map<String, Double> cheapestByRarity = new HashMap<>();
    List<String> keys = new ArrayList<>(app.globalMarketListings.keySet());
    int start = keys.isEmpty() ? 0 : hGui.random.nextInt(keys.size());
    for (int offset = 0; offset < keys.size() && candidates.size() < 256; offset++) {
      String key = keys.get((start + offset) % keys.size());
      ArrayList<MarketListing> listings = app.globalMarketListings.get(key);
      if (listings == null || listings.isEmpty()) continue;
      MarketListing first = listings.get(0);
      if (first == null
          || (targetRarity != null
              && !targetRarity.equals(app.salesSimulationService.getListingRarity(first, key))))
        continue;
      synchronized (listings) {
        int picks = Math.min(16, listings.size());
        int begin = hGui.random.nextInt(listings.size());
        for (int i = 0; i < picks; i++) {
          MarketListing listing = listings.get((begin + i) % listings.size());
          if (listing == null || listing.item == null || listing.isPlayerListing) continue;
          String rarity = app.salesSimulationService.getListingRarity(listing, key);
          if (targetRarity != null && !targetRarity.equals(rarity)) continue;
          candidates.add(new java.util.AbstractMap.SimpleEntry<>(key, listing));
          double ask = listing.getPrice();
          if (ask > 0 && ask < cheapestByRarity.getOrDefault(rarity, Double.MAX_VALUE))
            cheapestByRarity.put(rarity, ask);
        }
      }
    }
    if (candidates.isEmpty()) return null;

    double totalWeight = 0.0;
    ArrayList<Double> weights = new ArrayList<>();
    for (Map.Entry<String, MarketListing> candidate : candidates) {
      MarketListing listing = candidate.getValue();
      String rarity = app.salesSimulationService.getListingRarity(listing, candidate.getKey());
      double cheapest = cheapestByRarity.getOrDefault(rarity, listing.getPrice());
      double weight =
          app.salesSimulationService.getRaritySaleVelocity(rarity)
              * app.salesSimulationService.getPriceSaleWeight(cheapest, listing.getPrice());
      if (listing.item != null && listing.item.isStattrak)
        weight *= app.salesSimulationService.getStatTrakSaleVelocityMultiplier(rarity);
      weights.add(weight);
      totalWeight += weight;
    }
    if (totalWeight <= 0.0) return candidates.get(hGui.random.nextInt(candidates.size()));

    double roll = hGui.random.nextDouble() * totalWeight;
    for (int i = 0; i < candidates.size(); i++) {
      roll -= weights.get(i);
      if (roll <= 0.0) return candidates.get(i);
    }
    return candidates.get(candidates.size() - 1);
  }

  String getListingRarity(MarketListing listing, String fallbackKey) {
    if (listing != null
        && listing.item != null
        && listing.item.rarity != null
        && !listing.item.rarity.trim().isEmpty()) {
      String rarity = listing.item.rarity.replace("StatTrak ", "").trim();
      return "Mil-Spec".equals(rarity) ? "Milspec" : rarity;
    }
    String cleanName =
        fallbackKey != null
            ? fallbackKey
            : (listing != null && listing.item != null ? listing.item.name : "");
    cleanName =
        app.activitySimulationService
            .cleanStatTrakEncoding(cleanName)
            .replace("StatTrak ", "")
            .trim();
    return app.itemMetadataService.getSkinRarity(cleanName);
  }

  double getPriceSaleWeight(double cheapestPrice, double listingPrice) {
    if (cheapestPrice <= 0.0 || listingPrice <= 0.0) return 1.0;
    double relative = cheapestPrice / listingPrice;
    return Math.max(0.04, Math.min(4.0, Math.pow(relative, 1.35)));
  }

  double getRaritySaleVelocity(String rarity) {
    if (rarity == null) return 0.55;
    switch (rarity) {
      case "Industrial":
        return 1.50;
      case "Milspec":
        return 1.35;
      case "Distinguished":
        return 1.20;
      case "Restricted":
        return 1.00;
      case "Exceptional":
        return 0.82;
      case "Classified":
        return 0.65;
      case "Superior":
        return 0.50;
      case "Covert":
        return 0.38;
      case "Master":
        return 0.28;
      case "Knife":
        return 0.16;
      case "Gloves":
        return 0.13;
      default:
        return 0.55;
    }
  }

  double getStatTrakSaleVelocityMultiplier(String rarity) {
    if ("Knife".equals(rarity)) return 0.60;
    if ("Gloves".equals(rarity)) return 1.0;
    return 0.45;
  }

  SaleRecord createSaleRecordFromListing(
      MarketListing listing, String buyerName, Image buyerAvatar) {
    if (listing == null
        || listing.item == null
        || listing.item.name == null
        || listing.item.name.isBlank()
        || !Double.isFinite(listing.getPrice())
        || listing.getPrice() <= 0) return null;

    String displayName =
        listing.item.isStattrak ? "StatTrak " + listing.item.name : listing.item.name;
    displayName = app.activitySimulationService.cleanStatTrakEncoding(displayName);

    String specialVariant = null;
    if (listing.item.blueGemTier != null) {
      specialVariant = listing.item.blueGemTier;
    } else if (listing.item.name.contains("Doppler")) {
      if (listing.item.name.contains("Sapphire")) specialVariant = "Sapphire";
      else if (listing.item.name.contains("Ruby")) specialVariant = "Ruby";
      else if (listing.item.name.contains("Black Pearl")) specialVariant = "Black Pearl";
      else specialVariant = "Doppler";
    }

    SaleRecord sale =
        new SaleRecord(
            displayName,
            listing.getPrice(),
            listing.item.condition,
            listing.item.itemFloat,
            specialVariant);
    if (buyerName != null && !buyerName.trim().isEmpty()) sale.buyerName = buyerName;
    if (buyerAvatar != null) sale.buyerAvatar = buyerAvatar;
    sale.marketplaceName =
        listing.marketplaceName != null && !listing.marketplaceName.trim().isEmpty()
            ? listing.marketplaceName
            : "Marketplace";
    return sale;
  }

  void recordMarketListingSale(MarketListing listing, String buyerName, Image buyerAvatar) {
    if (!SwingUtilities.isEventDispatchThread()) {
      SwingUtilities.invokeLater(
          () ->
              app.salesSimulationService.recordMarketListingSale(listing, buyerName, buyerAvatar));
      return;
    }
    SaleRecord sale =
        app.salesSimulationService.createSaleRecordFromListing(listing, buyerName, buyerAvatar);
    if (sale == null) return;
    app.salesHistoryScreen.recordSaleRecord(sale);
    app.activitySimulationService.addSaleRecord(sale, true);
  }

  void generateSaleFromActualListingByRarity(String targetRarity) {
    Map.Entry<String, MarketListing> chosenEntry =
        app.salesSimulationService.chooseWeightedMarketSaleCandidateEntry(targetRarity);
    if (chosenEntry == null) {
      app.salesSimulationService.generateSaleFromActualListing();
      return;
    }

    ArrayList<MarketListing> listings = app.globalMarketListings.get(chosenEntry.getKey());
    MarketListing chosenListing = chosenEntry.getValue();
    if (listings == null || chosenListing == null) return;
    if (app.cs2ShellEnabled && chosenListing.quantity > 1) {
      app.salesSimulationService.recordMarketListingSale(chosenListing, null, null);
      app.exchangeTransactionService.consumeExchangeLot(chosenListing);
    } else {
      listings.removeIf(l -> l == chosenListing);
      app.marketPurchaseService.removeBlueGemListing(chosenListing);
      app.salesSimulationService.recordMarketListingSale(chosenListing, null, null);
    }
    app.marketStockService.invalidateGroupedMarketListingsCache();
  }

  void generateSaleFromActualListing() {
    Map.Entry<String, MarketListing> chosenEntry =
        app.salesSimulationService.chooseWeightedMarketSaleCandidateEntry(null);
    if (chosenEntry == null) return;
    ArrayList<MarketListing> listings = app.globalMarketListings.get(chosenEntry.getKey());
    MarketListing chosenListing = chosenEntry.getValue();
    if (listings == null || chosenListing == null) return;
    if (app.cs2ShellEnabled && chosenListing.quantity > 1) {
      app.salesSimulationService.recordMarketListingSale(chosenListing, null, null);
      app.exchangeTransactionService.consumeExchangeLot(chosenListing);
    } else {
      listings.removeIf(l -> l == chosenListing);
      app.marketPurchaseService.removeBlueGemListing(chosenListing);
      app.salesSimulationService.recordMarketListingSale(chosenListing, null, null);
    }
    app.marketStockService.invalidateGroupedMarketListingsCache();
  }
}
