package blahblah;

import blahblah.hGui.*;
import java.awt.*;
import java.awt.event.*;
import java.util.ArrayList;
import java.util.List;
import javax.swing.*;

/** Case Opening Screen: focused feature implementation. */
final class CaseOpeningScreen {
  private final hGui app;

  CaseOpeningScreen(hGui app) {
    this.app = app;
  }

  void openCrateWithAnimation(double speedMultiplier, boolean autoMode) {
    if (app.isAnimating || app.openingArtworkPreparing || autoMode) return;
    if (app.cs2ShellEnabled
        && !app.containerInventoryService.canUnlockOwnedContainer(app.currentCase)) {
      JOptionPane.showMessageDialog(
          app,
          "Buy this container in Market → Containers and its matching key through the owned case.");
      return;
    }
    if (app.currentCase.id.equals(app.openingArtworkCaseId)) {
      app.caseOpeningScreen.openCrateWithPreparedArtwork(speedMultiplier, autoMode);
      return;
    }
    final CaseType source = app.currentCase;
    final JDialog requestedOwner =
        app.cs2ContainerDialog != null && app.cs2ContainerDialog.isShowing()
            ? app.cs2ContainerDialog
            : null;
    app.openingArtworkPreparing = true;
    app.openCrateButton.setEnabled(false);
    app.openCrateButton.setText("PREPARING ARTWORK...");
    new SwingWorker<Void, Void>() {
      protected Void doInBackground() {
        app.openingArtworkService.prepareOpeningArtwork(source);
        return null;
      }

      protected void done() {
        app.openingArtworkPreparing = false;
        app.openCrateButton.setText("OPEN CASE");
        app.openCrateButton.setEnabled(
            app.marketInitialized
                && !app.isAnimating
                && app.balance >= app.developerTools.getCaseOpeningCost(app.currentCase));
        try {
          get();
          if ((requestedOwner != null && !requestedOwner.isShowing())
              || app.currentCase != source
              || (autoMode && (app.autoTimer == null || !app.autoTimer.isRunning()))) return;
          app.crateImage = app.containerBrowserScreen.getContainerImage(app.currentCase);
          app.containerBrowserScreen.updateCrateImageDisplay();
          app.caseOpeningScreen.openCrateWithPreparedArtwork(speedMultiplier, autoMode);
        } catch (InterruptedException ex) {
          Thread.currentThread().interrupt();
        } catch (java.util.concurrent.ExecutionException ex) {
          app.containerBrowserScreen.stopAutoOpen();
          JOptionPane.showMessageDialog(app, "Could not prepare case artwork. Please retry.");
          if (app.cs2ContainerDialog != null) {
            Object control =
                app.cs2ContainerDialog.getRootPane().getClientProperty("unlockControl");
            if (control instanceof JButton) ((JButton) control).setEnabled(true);
          }
        }
      }
    }.execute();
  }

  void openCrateWithAnimation() {
    app.caseOpeningScreen.openCrateWithAnimation(1.0, false);
  }

  void openCrateWithPreparedArtwork(double speedMultiplier, boolean autoMode) {
    if (!app.collectionService.hasVerifiedCasePools(app.currentCase)) {
      JOptionPane.showMessageDialog(
          app,
          "This case's verified drop data is unavailable. Check the catalog connection and try"
              + " again.",
          "Case Data Unavailable",
          JOptionPane.ERROR_MESSAGE);
      app.containerBrowserScreen.stopAutoOpen();
      return;
    }
    double casePrice =
        app.cs2ShellEnabled ? 0 : app.developerTools.getCaseOpeningCost(app.currentCase);

    if (app.balance < casePrice) {
      JOptionPane.showMessageDialog(app, "Out of money!");
      return;
    }

    if (app.animationFrame != null && app.animationFrame.isDisplayable()) {
      app.animationFrame.dispose();
    }

    if (app.cs2ShellEnabled) {
      try {
        casePrice = app.containerInventoryService.consumeOwnedOpening(app.currentCase);
      } catch (IllegalStateException ex) {
        JOptionPane.showMessageDialog(app, ex.getMessage());
        return;
      }
    }
    app.currentOpeningCost = casePrice;
    if (!app.cs2ShellEnabled) app.balance -= casePrice;
    app.uiWidgets.updateBalanceLabel();
    app.totalCrates++;
    app.missionProgress.casesOpened++;
    app.missionService.checkMissionProgress();

    app.currentCase.timesOpened++;
    app.currentCase.totalSpent += casePrice;

    app.isAnimating = true;

    app.skinImage = null;
    app.crateImage = app.containerBrowserScreen.getContainerImage(app.currentCase);
    app.rarityLabel.setText("");
    app.nameLabel.setText("");
    app.priceLabel.setText("");
    app.floatLabel.setText("");
    app.conditionLabel.setText("");
    app.patternId.setText("");
    app.collectionLabel.setText("");
    app.containerBrowserScreen.updateCrateImageDisplay();

    app.openCrateButton.setVisible(false);
    app.openCrateButton.setEnabled(false);
    app.closeCrateButton.setVisible(false);
    app.autoOpenButton.setVisible(autoMode);
    app.autoOpenButton.setEnabled(true);
    if (autoMode) app.autoOpenButton.setText("STOP OPEN");

    CrateRollResult rollResult = app.developerTools.rollCaseForOpening(app.currentCase);
    app.openingRewardService.generateFinalSkinDetails(rollResult);

    boolean reuse =
        app.cs2ShellEnabled && app.cs2ContainerDialog != null && app.cs2ContainerDialog.isShowing();
    JDialog animDialog =
        reuse ? app.cs2ContainerDialog : new JDialog(app, "Opening Case...", false);
    if (!reuse) app.uiWidgets.configureOpeningDialog(animDialog);
    animDialog.setTitle("Opening Case...");
    animDialog.getContentPane().removeAll();
    animDialog.getContentPane().setLayout(new BorderLayout());
    animDialog.setDefaultCloseOperation(JDialog.DISPOSE_ON_CLOSE);
    animDialog
        .getRootPane()
        .getInputMap(JComponent.WHEN_IN_FOCUSED_WINDOW)
        .put(KeyStroke.getKeyStroke(KeyEvent.VK_ESCAPE, 0), "closeOpeningDialog");
    animDialog
        .getRootPane()
        .getActionMap()
        .put(
            "closeOpeningDialog",
            new AbstractAction() {
              @Override
              public void actionPerformed(ActionEvent e) {
                animDialog.dispose();
              }
            });

    app.animationFrame = animDialog; // Reuse the existing unlock window; no invisible proxy JFrame.

    app.animationPanel = new AnimationPanel(app, rollResult);
    app.animationPanel.setOpaque(true);
    app.animationPanel.setBackground(Theme.PLACEHOLDER_BG);
    if (app.cs2ShellEnabled) {
      // One continuous scene: the fades cover the full area right up to the heading.
      animDialog.add(app.animationPanel, BorderLayout.CENTER);
      JPanel footer = app.cs2Screens.cs2Glass(new BorderLayout());
      footer.setBorder(BorderFactory.createEmptyBorder(15, 60, 25, 60));
      footer.add(
          app.cs2Screens.cs2Text(
              app.containerInventoryService.requiresOwnedKey(app.currentCase)
                  ? "Use " + app.cs2EquipmentScreens.keyName(app.currentCase)
                  : "No key required",
              16,
              Color.WHITE),
          BorderLayout.WEST);
      footer.add(
          app.cs2Screens.cs2Button("CLOSE", false, e -> animDialog.dispose()), BorderLayout.EAST);
      animDialog.add(footer, BorderLayout.SOUTH);
    } else animDialog.add(app.animationPanel, BorderLayout.CENTER);

    JPanel openingHeader = new JPanel(new BorderLayout(8, 0));
    openingHeader.setBackground(new Color(15, 15, 20));
    openingHeader.setOpaque(true);
    openingHeader.setBorder(BorderFactory.createEmptyBorder(6, 8, 6, 8));
    JLabel openingLabel =
        new JLabel(
            app.cs2ShellEnabled
                ? "Unlock Container  •  " + app.currentCase.name
                : "Opening " + app.currentCase.name + "...",
            SwingConstants.CENTER);
    openingLabel.setFont(new Font("SansSerif", Font.PLAIN, app.cs2ShellEnabled ? 28 : 16));
    openingLabel.setForeground(Theme.ACCENT_CT);
    openingLabel.setOpaque(false);
    openingHeader.add(openingLabel, BorderLayout.CENTER);
    if (autoMode) {
      JButton dialogStopButton = new JButton("STOP AUTO");
      app.uiWidgets.styleButton(
          dialogStopButton, new Color(80, 30, 30), new Color(220, 90, 90), new Color(220, 90, 90));
      dialogStopButton.setFont(Theme.CONSOLE_BOLD_12);
      dialogStopButton.setFocusable(false);
      dialogStopButton.addActionListener(
          evt -> {
            app.containerBrowserScreen.stopAutoOpen();
            dialogStopButton.setText("STOPPED");
            dialogStopButton.setEnabled(false);
          });
      Dimension stopSize = dialogStopButton.getPreferredSize();
      openingHeader.add(Box.createRigidArea(stopSize), BorderLayout.WEST);
      openingHeader.add(dialogStopButton, BorderLayout.EAST);
    }
    animDialog.add(openingHeader, BorderLayout.NORTH);

    animDialog.getContentPane().revalidate();
    animDialog.getContentPane().repaint();
    if (!animDialog.isShowing()) animDialog.setVisible(true);

    double randomBias = (hGui.random.nextDouble() - 0.5) * 120.0;
    final double targetPosition =
        app.animationPanel.getFinalSkinPosition()
            + (AnimationConfig.SKIN_WIDTH / 2.0)
            - (animDialog.getWidth() / 2.0)
            + randomBias;

    final boolean[] rewardCommitted = {false};
    final boolean[] openingClosed = {false};
    final List<javax.swing.Timer> openingTimers = new ArrayList<>();
    Runnable commitReward =
        () -> {
          if (!rewardCommitted[0]) {
            rewardCommitted[0] = true;
            app.openingRewardService.displayFinalResult(rollResult, false);
            if (app.cs2ShellEnabled) {
              app.cs2UnlockSelection = null;
              app.cs2EquipFilter = null;
              app.cs2InventorySection = "EVERYTHING";
              app.cs2InventorySearch = "";
              app.cs2InventoryPage = 0;
              app.containerSelectionScreen.invalidateCs2Inventory();
              app.cs2Screens.refreshCs2Inventory();
              app.saveService.saveProgressAsync();
            }
          }
        };
    if (app.cs2ShellEnabled) app.cs2PendingOpeningReward = commitReward;
    javax.swing.Timer scrollTimer = new javax.swing.Timer(AnimationConfig.TIMER_DELAY_MS, null);
    openingTimers.add(scrollTimer);
    animDialog.addWindowListener(
        new java.awt.event.WindowAdapter() {
          @Override
          public void windowClosed(java.awt.event.WindowEvent e) {
            boolean quickOpen = !rewardCommitted[0];
            int beforeReward = app.inventoryList.size();
            openingClosed[0] = true;
            for (javax.swing.Timer timer : openingTimers) timer.stop();
            commitReward.run();
            if (app.cs2ShellEnabled) app.cs2PendingOpeningReward = null;
            app.isAnimating = false;
            app.floatRules.resetCrate();
            if (app.cs2ShellEnabled) {
              if (quickOpen && app.inventoryList.size() > beforeReward) {
                app.itemRevealService.received(app.inventoryList.get(app.inventoryList.size() - 1));
                app.navigationService.mainInventory();
                SwingUtilities.invokeLater(app.itemRevealService::showPending);
              }
              app.saveService.saveProgressAsync();
            }
          }
        });
    scrollTimer.addActionListener(
        new ActionListener() {
          double currentOffset = 0.0;
          double velocity = 0.0;
          long lastFrame = System.nanoTime();

          @Override
          public void actionPerformed(ActionEvent e) {
            long now = System.nanoTime();
            double frameScale = Math.min(4, Math.max(.25, (now - lastFrame) / 16_000_000.0));
            lastFrame = now;
            double distance = targetPosition - currentOffset;
            if (distance <= 0.0) {
              currentOffset = targetPosition;
              velocity = 0.0;
            } else {
              double maxSpeed = AnimationConfig.MAX_SPEED * speedMultiplier;
              if (distance > AnimationConfig.DECEL_ZONE) {
                velocity =
                    Math.min(
                        velocity + (AnimationConfig.ACCELERATION * speedMultiplier * frameScale),
                        maxSpeed);
              } else {
                double factor = distance / AnimationConfig.DECEL_ZONE;
                velocity = maxSpeed * factor;
              }

              if (distance < 260) velocity *= 0.96;
              velocity = Math.min(velocity, distance);
              currentOffset += Math.min(distance, velocity * frameScale);
            }
            app.animationPanel.setScrollOffset((int) currentOffset);

            if (distance <= 0.0 || velocity < AnimationConfig.STOP_VELOCITY) {
              scrollTimer.stop();
              commitReward.run();
              javax.swing.Timer delayTimer =
                  new javax.swing.Timer(
                      Math.max(250, (int) (1000 / speedMultiplier)),
                      evt -> {
                        if (openingClosed[0]) return;
                        commitReward.run();
                        String resultDisplayName =
                            (rollResult.isStatTrak && !rollResult.rarityName.contains("Gloves")
                                    ? "StatTrak "
                                    : "")
                                + app.finalSkinName;
                        openingLabel.setText("Unboxed " + resultDisplayName);
                        java.awt.image.BufferedImage backdrop =
                            new java.awt.image.BufferedImage(
                                Math.max(1, animDialog.getContentPane().getWidth()),
                                Math.max(1, animDialog.getContentPane().getHeight()),
                                java.awt.image.BufferedImage.TYPE_INT_RGB);
                        Graphics2D backdropGraphics = backdrop.createGraphics();
                        animDialog.getContentPane().paint(backdropGraphics);
                        backdropGraphics.dispose();
                        if (app.cs2ShellEnabled) animDialog.getContentPane().removeAll();
                        else animDialog.remove(app.animationPanel);
                        String rarityText =
                            rollResult.isStatTrak && !rollResult.rarityName.contains("Gloves")
                                ? "StatTrak " + rollResult.rarityName
                                : rollResult.rarityName;
                        String collection =
                            app.collectionService.getCollectionName(app.finalSkinName);
                        String info =
                            app.uiWidgets.buildItemInfoHtml(
                                rarityText,
                                app.finalCondition,
                                app.finalFloat,
                                app.finalPatternID,
                                collection,
                                false);
                        FadePanel resultPanel =
                            app.uiWidgets.createRewardResultPanel(
                                app.finalSkin,
                                resultDisplayName,
                                "",
                                rollResult.rarityColor,
                                info,
                                app.autoTimer != null && app.autoTimer.isRunning()
                                    ? "NEXT"
                                    : "CLOSE",
                                closeEvt -> animDialog.dispose());
                        if (app.cs2ShellEnabled) {
                          InventoryItem shown = null;
                          for (int i = app.inventoryList.size() - 1; i >= 0; i--) {
                            InventoryItem candidate = app.inventoryList.get(i);
                            if (candidate.name.equals(app.finalSkinName)
                                && candidate.patternID == app.finalPatternID
                                && Double.compare(candidate.itemFloat, app.finalFloat) == 0) {
                              shown = candidate;
                              break;
                            }
                          }
                          if (shown != null)
                            ((JPanel) resultPanel.getComponent(0))
                                .add(
                                    ItemPresentation.identity(app, shown, 27, "unboxItem", true),
                                    BorderLayout.NORTH);
                        }
                        resultPanel.setBackdrop(backdrop);
                        app.artworkService.getSkinImageFromName(
                            app.finalSkinName,
                            app.finalCondition,
                            app.activeResultImageLabel,
                            app.cs2ShellEnabled ? 820 : 430,
                            app.cs2ShellEnabled ? 490 : 285);
                        animDialog.add(resultPanel, BorderLayout.CENTER);
                        animDialog.revalidate();
                        app.uiWidgets.fadeInPanel(resultPanel, animDialog);
                        if (app.autoTimer != null && app.autoTimer.isRunning()) {
                          javax.swing.Timer nextTimer =
                              new javax.swing.Timer(850, nextEvt -> animDialog.dispose());
                          openingTimers.add(nextTimer);
                          nextTimer.setRepeats(false);
                          nextTimer.start();
                        }
                      });
              openingTimers.add(delayTimer);
              delayTimer.setRepeats(false);
              delayTimer.start();
            }
          }
        });

    scrollTimer.start();
  }
}
