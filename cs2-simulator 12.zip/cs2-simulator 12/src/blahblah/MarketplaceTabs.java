package blahblah;

import java.awt.*;
import javax.swing.*;

/** Closeable temporary offer views live inside Market, not independent windows. */
final class MarketplaceTabs {
  private final hGui app;

  MarketplaceTabs(hGui app) {
    this.app = app;
  }

  void configure(JTabbedPane tabs) {
    tabs.setFont(new Font("SansSerif", Font.PLAIN, 14));
    tabs.setTabLayoutPolicy(JTabbedPane.SCROLL_TAB_LAYOUT);
    tabs.setUI(
        new javax.swing.plaf.basic.BasicTabbedPaneUI() {
          protected void installDefaults() {
            super.installDefaults();
            tabInsets = new Insets(6, 14, 6, 14);
            selectedTabPadInsets = new Insets(0, 0, 0, 0);
            tabAreaInsets = new Insets(3, 5, 3, 5);
          }

          protected void paintTabBackground(
              Graphics g, int placement, int index, int x, int y, int w, int h, boolean selected) {
            g.setColor(selected ? new Color(49, 67, 84) : new Color(20, 25, 34));
            g.fillRoundRect(x, y, w, h, 8, 8);
          }

          protected void paintTabBorder(
              Graphics g, int placement, int index, int x, int y, int w, int h, boolean selected) {}

          protected void paintFocusIndicator(
              Graphics g,
              int placement,
              Rectangle[] rects,
              int index,
              Rectangle icon,
              Rectangle text,
              boolean selected) {}

          protected void paintContentBorder(Graphics g, int placement, int index) {}
        });
  }

  Runnable open(String title, JPanel page) {
    if (app.exchangeHostSections == null) app.loadoutScreen.refreshMarketTab();
    app.storeScreen.open("MARKET");
    JTabbedPane tabs = app.exchangeHostSections;
    Component previous = tabs.getSelectedComponent();
    tabs.addTab(title, page);
    page.putClientProperty("temporaryMarketView", true);
    Runnable close =
        () -> {
          Object cleanup = page.getClientProperty("disposeTemporaryView");
          if (cleanup instanceof Runnable) ((Runnable) cleanup).run();
          tabs.remove(page);
          if (previous != null && tabs.indexOfComponent(previous) >= 0)
            tabs.setSelectedComponent(previous);
        };
    JPanel header = new JPanel();
    header.setLayout(new BoxLayout(header, BoxLayout.X_AXIS));
    header.setOpaque(false);
    JLabel label = new JLabel(title);
    label.setForeground(Color.WHITE);
    label.setFont(tabs.getFont());
    label.setAlignmentY(.5f);
    label.setToolTipText(title);
    header.add(label);
    header.add(Box.createHorizontalStrut(10));
    JButton exit = new JButton("×");
    exit.setUI(new javax.swing.plaf.basic.BasicButtonUI());
    exit.setFont(new Font("SansSerif", Font.PLAIN, 20));
    exit.setForeground(Color.WHITE);
    exit.setFocusable(false);
    exit.setBorder(BorderFactory.createEmptyBorder());
    exit.setOpaque(false);
    exit.setContentAreaFilled(false);
    exit.setAlignmentY(.5f);
    Dimension closeSize = new Dimension(24, 24);
    exit.setPreferredSize(closeSize);
    exit.setMinimumSize(closeSize);
    exit.setMaximumSize(closeSize);
    exit.setToolTipText("Close tab");
    exit.addActionListener(e -> close.run());
    header.add(exit);
    header.setPreferredSize(new Dimension(label.getPreferredSize().width + 34, 28));
    tabs.setTabComponentAt(tabs.indexOfComponent(page), header);
    tabs.setSelectedComponent(page);
    return close;
  }
}
