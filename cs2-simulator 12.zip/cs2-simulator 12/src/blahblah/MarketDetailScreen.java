package blahblah;

import blahblah.hGui.*;
import java.awt.*;
import java.awt.event.*;
import java.util.ArrayList;
import java.util.LinkedHashMap;
import javax.swing.*;

/** Market Detail Screen: focused feature implementation. */
final class MarketDetailScreen {
  private final hGui app;

  MarketDetailScreen(hGui app) {
    this.app = app;
  }

  void showDetailedListings(String skinName, ArrayList<MarketListing> listings, JFrame parent) {
    String normalizedName = app.marketGroupingService.getMarketplaceBrowseKey(skinName);
    String baseName = normalizedName.trim();
    ArrayList<MarketListing> combinedListings =
        app.marketGroupingService.getCombinedBrowseListings(normalizedName);

    JPanel detailFrame = new JPanel(new BorderLayout());
    detailFrame.setBackground(new Color(16, 20, 29));
    Runnable[] closeTab = {null};
    JPanel topPanel = new JPanel(new BorderLayout());
    topPanel.setBackground(new Color(16, 20, 29));
    topPanel.setBorder(BorderFactory.createEmptyBorder(18, 22, 18, 22));
    JLabel titleLabel = new JLabel(baseName);
    titleLabel.setFont(new Font("Arial", Font.BOLD, 28));
    titleLabel.setForeground(Color.WHITE);
    JLabel subtitle =
        new JLabel(
            String.format(
                "%d listings across %d markets",
                app.exchangeStockService.countStock(combinedListings),
                app.marketFilterControls.countDistinctMarketplaces(combinedListings)));
    subtitle.setFont(new Font("Arial", Font.PLAIN, 13));
    subtitle.setForeground(new Color(150, 160, 185));
    JPanel titleWrap = new JPanel();
    titleWrap.setOpaque(false);
    titleWrap.setLayout(new BoxLayout(titleWrap, BoxLayout.Y_AXIS));
    titleWrap.add(titleLabel);
    titleWrap.add(subtitle);
    topPanel.add(titleWrap, BorderLayout.WEST);
    detailFrame.add(topPanel, BorderLayout.NORTH);

    JTabbedPane tabbedPane = new JTabbedPane();
    String[] selectedConditionToken = {null};
    tabbedPane.addTab(
        "Offers",
        app.marketGroupingService.createMarketplaceOfferHubPanel(
            normalizedName, combinedListings, app, selectedConditionToken));
    JPanel recentSalesPanel =
        app.salesHistoryScreen.createSkinRecentSalesPanel(normalizedName, selectedConditionToken);
    tabbedPane.addTab("Recent Sales", recentSalesPanel);
    tabbedPane.addChangeListener(
        e -> {
          if (tabbedPane.getSelectedComponent() == recentSalesPanel) {
            recentSalesPanel.dispatchEvent(
                new ComponentEvent(recentSalesPanel, ComponentEvent.COMPONENT_SHOWN));
          }
        });
    detailFrame.add(tabbedPane, BorderLayout.CENTER);

    JPanel bottomPanel = new JPanel(new FlowLayout(FlowLayout.RIGHT, 10, 10));
    bottomPanel.setBackground(new Color(16, 20, 29));
    JButton refreshBtn = new JButton("Refresh");
    app.uiWidgets.styleButton(
        refreshBtn, new Color(36, 82, 64), new Color(220, 240, 225), new Color(80, 150, 120));
    refreshBtn.addActionListener(
        e -> {
          closeTab[0].run();
          app.marketDetailScreen.showDetailedListings(
              normalizedName,
              app.marketGroupingService.getCombinedBrowseListings(normalizedName),
              parent);
        });
    bottomPanel.add(refreshBtn);
    detailFrame.add(bottomPanel, BorderLayout.SOUTH);
    closeTab[0] = app.marketplaceTabs.open(baseName + " / offers", detailFrame);
  }

  JPanel createWearRangePanel(String skinName) {
    boolean noWear = app.floatRules.hasNoFloatWear(skinName);
    double[] bounds = app.marketStockService.getMarketWearBounds(skinName);
    JPanel panel =
        new JPanel() {
          double displayFraction(double value) {
            for (int i = 0; i < 5; i++) {
              if (value <= hGui.MARKET_WEAR_EDGES[i + 1])
                return (i
                        + (value - hGui.MARKET_WEAR_EDGES[i])
                            / (hGui.MARKET_WEAR_EDGES[i + 1] - hGui.MARKET_WEAR_EDGES[i]))
                    / 5.0;
            }
            return 1.0;
          }

          void marker(Graphics2D g, String text, int anchor, int width) {
            FontMetrics fm = g.getFontMetrics();
            int bubbleWidth = fm.stringWidth(text) + 14;
            int x = anchor - bubbleWidth / 2;
            x = Math.max(0, Math.min(width - bubbleWidth, x));
            g.setColor(new Color(65, 76, 94));
            g.fillRoundRect(x, 42, bubbleWidth, 25, 9, 9);
            g.fillPolygon(new int[] {anchor - 5, anchor + 5, anchor}, new int[] {66, 66, 72}, 3);
            g.setColor(Color.WHITE);
            g.drawString(text, x + 7, 59);
          }

          @Override
          protected void paintComponent(Graphics graphics) {
            super.paintComponent(graphics);
            Graphics2D g = (Graphics2D) graphics.create();
            g.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
            int w = getWidth();
            g.setFont(new Font("Arial", Font.BOLD, 19));
            g.setColor(Color.WHITE);
            g.drawString("Wear Range", 0, 24);

            if (noWear) {
              g.setFont(new Font("Arial", Font.PLAIN, 13));
              g.drawString("No float / wear — Normal", 0, 52);
              g.dispose();
              return;
            }
            int margin = 22, barWidth = Math.max(5, w - margin * 2), y = 80, height = 46;
            Color[] colors = {
              new Color(32, 197, 94),
              new Color(132, 204, 22),
              new Color(234, 179, 8),
              new Color(249, 115, 22),
              new Color(239, 68, 68)
            };
            String[] labels = {"FN", "MW", "FT", "WW", "BS"};
            Shape originalClip = g.getClip();
            g.clip(new java.awt.geom.RoundRectangle2D.Double(margin, y, barWidth, height, 12, 12));
            for (int i = 0; i < 5; i++) {
              int x1 = margin + (int) Math.round(barWidth * i / 5.0);
              int x2 = margin + (int) Math.round(barWidth * (i + 1) / 5.0);
              g.setColor(new Color(29, 39, 54));
              g.fillRect(x1, y, x2 - x1, height);
              g.setColor(colors[i]);
              g.fillRect(x1, y, x2 - x1, 7);
              g.setFont(new Font("Arial", Font.PLAIN, 15));
              g.setColor(Color.WHITE);
              FontMetrics fm = g.getFontMetrics();
              g.drawString(labels[i], x1 + (x2 - x1 - fm.stringWidth(labels[i])) / 2, y + 33);
              g.setColor(new Color(13, 23, 38));
              if (i > 0) g.drawLine(x1, y, x1, y + height);
            }
            int minX = margin + (int) Math.round(barWidth * displayFraction(bounds[0]));
            int maxX = margin + (int) Math.round(barWidth * displayFraction(bounds[1]));
            g.setColor(new Color(12, 17, 26, 190));
            g.fillRect(margin, y, Math.max(0, minX - margin), height);
            g.fillRect(maxX, y, Math.max(0, margin + barWidth - maxX), height);
            g.setClip(originalClip);
            g.setColor(new Color(180, 193, 212));
            g.drawLine(minX, y, minX, y + height);
            g.drawLine(maxX, y, maxX, y + height);
            g.setFont(new Font("Arial", Font.PLAIN, 13));
            // If both caps fall in one narrow region, put values at the
            // edges and connect them to the exact marker positions.
            int labelMin = minX, labelMax = maxX;
            if (maxX - minX < 75) {
              labelMin = margin;
              labelMax = margin + barWidth;
            }
            marker(g, String.format(java.util.Locale.ROOT, "%.2f", bounds[0]), labelMin, w);
            marker(g, String.format(java.util.Locale.ROOT, "%.2f", bounds[1]), labelMax, w);
            if (labelMin != minX || labelMax != maxX) {
              g.setColor(new Color(160, 173, 190));
              g.drawLine(labelMin, 73, minX, y);
              g.drawLine(labelMax, 73, maxX, y);
            }
            g.dispose();
          }
        };
    panel.setOpaque(false);
    panel.setPreferredSize(new Dimension(340, noWear ? 68 : 142));
    panel.setToolTipText(
        noWear
            ? "This item has no float or wear conditions."
            : String.format(
                java.util.Locale.ROOT,
                "<html>Float range: %.4f–%.4f<br>FN: 0–0.07 · MW: 0.07–0.15<br>FT: 0.15–0.38 · WW:"
                    + " 0.38–0.45 · BS: 0.45–1.00<br>Darkened areas cannot exist for this"
                    + " skin.</html>",
                bounds[0],
                bounds[1]));
    panel.setLayout(null);
    JComponent rangeInfo = app.uiWidgets.createInfoBadge(panel.getToolTipText());
    rangeInfo.setName("wearRangeInfo");
    int infoX =
        panel.getFontMetrics(new Font("Arial", Font.BOLD, 19)).stringWidth("Wear Range") + 12;
    rangeInfo.setBounds(infoX, 1, 28, 28);
    panel.add(rangeInfo);
    panel
        .getAccessibleContext()
        .setAccessibleName(
            noWear
                ? "Wear Range: no float, Normal"
                : String.format(
                    java.util.Locale.ROOT, "Wear Range: %.4f to %.4f", bounds[0], bounds[1]));
    panel.putClientProperty("wearRangeBounds", noWear ? null : bounds.clone());
    return panel;
  }

  JPanel createMarketplaceOffersPanel(
      String skinName,
      ArrayList<MarketListing> listings,
      JFrame parent,
      String[] selectedConditionToken) {
    JPanel panel = new JPanel(new BorderLayout(18, 0));
    panel.setBackground(new Color(16, 20, 29));
    panel.setBorder(BorderFactory.createEmptyBorder(0, 18, 18, 18));

    LinkedHashMap<String, ArrayList<MarketListing>> conditionMap =
        app.marketHistoryScreen.buildConditionTokenMap(listings, skinName);
    java.util.List<String> conditionKeys = new ArrayList<>(conditionMap.keySet());
    final String[] selectedToken = {conditionKeys.isEmpty() ? null : conditionKeys.get(0)};
    if (selectedConditionToken != null && selectedConditionToken[0] == null) {
      selectedConditionToken[0] = selectedToken[0];
    }

    JPanel leftPanel = new JPanel(new BorderLayout());
    leftPanel.setBackground(new Color(39, 45, 57));
    leftPanel.setBorder(BorderFactory.createEmptyBorder(12, 12, 12, 12));
    leftPanel.setPreferredSize(new Dimension(390, 0));

    JPanel leftCenter = new JPanel(new BorderLayout(0, 12));
    leftCenter.setOpaque(false);
    JPanel imagePanel = new JPanel(new BorderLayout());
    imagePanel.setOpaque(false);
    imagePanel.setPreferredSize(new Dimension(0, 230));
    JLabel offerArtwork = new JLabel("", SwingConstants.CENTER);
    offerArtwork.setName("marketOfferWearArtwork");
    imagePanel.add(offerArtwork, BorderLayout.CENTER);

    leftCenter.add(imagePanel, BorderLayout.NORTH);

    JPanel conditionList = new JPanel();
    conditionList.setLayout(new BoxLayout(conditionList, BoxLayout.Y_AXIS));
    conditionList.setOpaque(false);
    JScrollPane conditionScroll = new JScrollPane(conditionList);
    conditionScroll.setBorder(null);
    conditionScroll.setOpaque(false);
    conditionScroll.getViewport().setOpaque(false);
    conditionScroll.getViewport().setBackground(new Color(39, 45, 57));
    conditionScroll.setHorizontalScrollBarPolicy(ScrollPaneConstants.HORIZONTAL_SCROLLBAR_NEVER);
    conditionScroll.getVerticalScrollBar().setUnitIncrement(16);
    leftCenter.add(conditionScroll, BorderLayout.CENTER);
    leftCenter.add(app.marketDetailScreen.createWearRangePanel(skinName), BorderLayout.SOUTH);
    leftPanel.add(leftCenter, BorderLayout.CENTER);

    JPanel rightPanel = new JPanel(new BorderLayout());
    rightPanel.setBackground(new Color(16, 20, 29));
    JPanel rightHeader = new JPanel(new BorderLayout(0, 12));
    rightHeader.setOpaque(false);
    JLabel activeOffers = new JLabel("Marketplace Offers");
    activeOffers.setFont(new Font("Arial", Font.BOLD, 20));
    activeOffers.setForeground(Color.WHITE);
    activeOffers.setBorder(BorderFactory.createEmptyBorder(8, 0, 0, 0));
    rightHeader.add(activeOffers, BorderLayout.NORTH);
    JLabel offerStatsLabel = new JLabel();
    offerStatsLabel.setFont(new Font("Consolas", Font.BOLD, 11));
    offerStatsLabel.setForeground(new Color(120, 215, 255));
    JLabel offerHintLabel = new JLabel("Open a marketplace to browse its custom view");
    offerHintLabel.setFont(new Font("Arial", Font.PLAIN, 12));
    offerHintLabel.setForeground(new Color(150, 160, 185));
    JPanel offerMeta = new JPanel(new FlowLayout(FlowLayout.LEFT, 10, 0));
    offerMeta.setOpaque(false);
    offerMeta.add(offerStatsLabel);
    offerMeta.add(offerHintLabel);
    rightHeader.add(offerMeta, BorderLayout.CENTER);
    rightPanel.add(rightHeader, BorderLayout.NORTH);

    ScrollablePanel offersContainer = new ScrollablePanel();
    offersContainer.setLayout(new BoxLayout(offersContainer, BoxLayout.Y_AXIS));
    offersContainer.setOpaque(false);
    JScrollPane offersScroll = new JScrollPane(offersContainer);
    offersScroll.setBorder(null);
    offersScroll.getViewport().setBackground(new Color(16, 20, 29));
    offersScroll.setHorizontalScrollBarPolicy(ScrollPaneConstants.HORIZONTAL_SCROLLBAR_NEVER);
    offersScroll.getVerticalScrollBar().setUnitIncrement(18);
    rightPanel.add(offersScroll, BorderLayout.CENTER);

    boolean isAgentItem = app.itemMetadataService.isAgentSkin(skinName);
    String[] availableBaseConditions = app.floatRules.getAvailableConditions(skinName);
    boolean supportsStatTrak = app.itemMetadataService.supportsStatTrak(skinName);
    java.util.List<String> allDisplayTokens = new java.util.ArrayList<>();
    // Display only variants that can actually exist.  In particular, a
    // vanilla knife has Normal and StatTrak Normal, while an agent has only
    // Normal; neither has a disabled list of imaginary wear states.
    for (String condition : availableBaseConditions) {
      allDisplayTokens.add(condition);
    }
    if (!isAgentItem && supportsStatTrak) {
      for (String condition : availableBaseConditions) {
        allDisplayTokens.add("StatTrak " + condition);
      }
    }

    final Runnable[] rebuildOffers = new Runnable[1];
    rebuildOffers[0] =
        () -> {
          app.artworkService.getSkinImageFromName(
              skinName,
              app.marketHistoryScreen.getPriceHistoryCondition(selectedToken[0]),
              offerArtwork,
              320,
              220);

          if (selectedConditionToken != null) selectedConditionToken[0] = selectedToken[0];
          conditionList.removeAll();
          offersContainer.removeAll();
          for (String token : allDisplayTokens) {
            ArrayList<MarketListing> tokenListings = conditionMap.get(token);
            boolean available = tokenListings != null && !tokenListings.isEmpty();
            double low =
                available
                    ? tokenListings.stream().mapToDouble(l -> l.getPrice()).min().orElse(0)
                    : 0;
            boolean selected = token.equals(selectedToken[0]);
            boolean isStattrakToken = token.startsWith("StatTrak");
            String baseToken =
                isStattrakToken ? token.replaceFirst("^StatTrak\\s+", "").trim() : token;
            boolean possible =
                java.util.Arrays.asList(availableBaseConditions).contains(baseToken)
                    && (!isStattrakToken || supportsStatTrak);

            JPanel row = new JPanel(new BorderLayout(0, 0));
            row.setMaximumSize(new Dimension(Integer.MAX_VALUE, 42));
            row.setOpaque(true);
            Color rowBg = selected ? new Color(55, 65, 85) : new Color(39, 45, 57);
            row.setBackground(rowBg);
            row.setBorder(
                BorderFactory.createCompoundBorder(
                    BorderFactory.createMatteBorder(0, 0, 1, 0, new Color(50, 58, 74)),
                    BorderFactory.createEmptyBorder(8, 14, 8, 14)));

            // Left: condition name label
            String displayToken = "StatTrak Normal".equals(token) ? "StatTrak" : token;
            JLabel nameLbl = new JLabel(displayToken);
            nameLbl.setFont(new Font("Arial", Font.PLAIN, 13));
            if (isStattrakToken) {
              nameLbl.setForeground(new Color(255, 176, 72));
            } else {
              nameLbl.setForeground(Color.WHITE);
            }

            // Right: live price, or an empty market for a valid variant.
            JLabel priceLbl;
            if (available) {
              priceLbl =
                  new JLabel(
                      Double.isFinite(low) ? String.format("$%.2f", low) : "Quote unavailable");
              priceLbl.setFont(new Font("Arial", Font.BOLD, 13));
              priceLbl.setForeground(isStattrakToken ? new Color(255, 176, 72) : Color.WHITE);
            } else {
              priceLbl = new JLabel("No listings");
              priceLbl.setFont(new Font("Arial", Font.PLAIN, 13));
              priceLbl.setForeground(new Color(170, 175, 190));
            }

            row.add(nameLbl, BorderLayout.WEST);
            row.add(priceLbl, BorderLayout.EAST);

            if (possible) {
              row.setCursor(java.awt.Cursor.getPredefinedCursor(java.awt.Cursor.HAND_CURSOR));
              row.addMouseListener(
                  new MouseAdapter() {
                    @Override
                    public void mouseEntered(MouseEvent e) {
                      if (!token.equals(selectedToken[0])) row.setBackground(new Color(48, 56, 72));
                    }

                    @Override
                    public void mouseExited(MouseEvent e) {
                      row.setBackground(
                          token.equals(selectedToken[0])
                              ? new Color(55, 65, 85)
                              : new Color(39, 45, 57));
                    }

                    @Override
                    public void mouseClicked(MouseEvent e) {
                      selectedToken[0] = token;
                      if (selectedConditionToken != null) selectedConditionToken[0] = token;
                      rebuildOffers[0].run();
                    }
                  });
            }

            conditionList.add(row);
          }

          ArrayList<MarketListing> currentListings =
              selectedToken[0] == null ? new ArrayList<>() : conditionMap.get(selectedToken[0]);
          if (currentListings == null) currentListings = new ArrayList<>();
          java.util.List<MarketplaceOfferAggregate> offers =
              app.marketOfferService.buildMarketplaceAggregates(currentListings);
          offerStatsLabel.setText(
              String.format(
                  "%d markets  |  %d listings",
                  offers.size(), app.exchangeStockService.countStock(currentListings)));
          if (offers.isEmpty()) {
            JLabel empty =
                new JLabel("No marketplace offers for this condition", SwingConstants.CENTER);
            empty.setForeground(new Color(170, 175, 190));
            empty.setAlignmentX(Component.LEFT_ALIGNMENT);
            offersContainer.add(empty);
          } else {
            for (MarketplaceOfferAggregate offer : offers) {
              offersContainer.add(
                  app.marketOfferService.createMarketplaceOfferRow(
                      skinName, selectedToken[0], offer, parent));
              offersContainer.add(Box.createRigidArea(new Dimension(0, 10)));
            }
            offersContainer.add(
                app.marketHistoryScreen.createMarketplacePriceHistoryPanel(
                    skinName, selectedToken[0], currentListings));
          }
          conditionList.revalidate();
          conditionList.repaint();
          offersContainer.revalidate();
          offersContainer.repaint();
        };

    panel.add(leftPanel, BorderLayout.WEST);
    panel.add(rightPanel, BorderLayout.CENTER);
    rebuildOffers[0].run();
    return panel;
  }
}
