package blahblah;

import blahblah.hGui.*;
import java.awt.*;
import java.awt.event.*;
import javax.swing.*;

/** Ui Widgets: focused feature implementation. */
final class UiWidgets {
  private final hGui app;

  UiWidgets(hGui app) {
    this.app = app;
  }

  void updateBalanceLabel() {
    app.balanceLabel.setText(String.format("Balance: $%.2f", app.balance));
    if (app.cs2BalanceLabel != null)
      app.cs2BalanceLabel.setText(String.format("$%,.2f", app.balance));
    if (app.openCrateButton != null) {
      app.openCrateButton.setEnabled(
          !app.isAnimating
              && app.balance >= app.developerTools.getCaseOpeningCost(app.currentCase));
      app.openCrateButton.setText(
          String.format(
              "OPEN CASE  $%.2f", app.developerTools.getCaseOpeningCost(app.currentCase)));
    }
  }

  JButton makeHeaderButton(String text, Color bg, Color fg) {
    JButton btn = new JButton(text);
    btn.setToolTipText(text);
    btn.setFont(Theme.CONSOLE_BOLD_12);
    btn.setBackground(bg);
    btn.setForeground(fg);
    btn.setFocusPainted(false);
    btn.setOpaque(true);
    btn.setBorder(
        BorderFactory.createCompoundBorder(
            BorderFactory.createLineBorder(Theme.BORDER.brighter(), 1),
            BorderFactory.createEmptyBorder(5, 12, 5, 12)));
    btn.setCursor(new Cursor(Cursor.HAND_CURSOR));
    Color hover = bg.brighter();
    btn.addMouseListener(
        new MouseAdapter() {
          public void mouseEntered(MouseEvent e) {
            btn.setBackground(hover);
          }

          public void mouseExited(MouseEvent e) {
            btn.setBackground(bg);
          }

          public void mousePressed(MouseEvent e) {
            btn.setBackground(hover.darker());
          }

          public void mouseReleased(MouseEvent e) {
            btn.setBackground(hover);
          }
        });
    return btn;
  }

  void styleButton(JButton btn, Color bg, Color fg, Color border) {
    if (btn.getToolTipText() == null || btn.getToolTipText().trim().isEmpty()) {
      btn.setToolTipText(btn.getText());
    }
    btn.setFont(Theme.CONSOLE_BOLD_13);
    btn.setBackground(bg);
    btn.setForeground(fg);
    btn.setFocusPainted(false);
    btn.setOpaque(true);
    btn.setBorderPainted(true);
    btn.setBorder(
        BorderFactory.createCompoundBorder(
            BorderFactory.createLineBorder(border, 1),
            BorderFactory.createEmptyBorder(6, 14, 6, 14)));
    btn.setCursor(new Cursor(Cursor.HAND_CURSOR));
    Color hover = bg.brighter();
    btn.addMouseListener(
        new MouseAdapter() {
          public void mouseEntered(MouseEvent e) {
            btn.setBackground(hover);
          }

          public void mouseExited(MouseEvent e) {
            btn.setBackground(bg);
          }

          public void mousePressed(MouseEvent e) {
            btn.setBackground(hover.darker());
          }

          public void mouseReleased(MouseEvent e) {
            btn.setBackground(hover);
          }
        });
  }

  void installDialogDragHandler(JDialog dialog) {
    final Point[] dragStart = {null};
    MouseAdapter dragger =
        new MouseAdapter() {
          @Override
          public void mousePressed(MouseEvent e) {
            dragStart[0] = e.getPoint();
          }

          @Override
          public void mouseDragged(MouseEvent e) {
            if (dragStart[0] == null) return;
            Point screen = e.getLocationOnScreen();
            dialog.setLocation(screen.x - dragStart[0].x, screen.y - dragStart[0].y);
          }
        };
    dialog.addMouseListener(dragger);
    dialog.addMouseMotionListener(dragger);
    if (dialog.getContentPane() != null) {
      dialog.getContentPane().addMouseListener(dragger);
      dialog.getContentPane().addMouseMotionListener(dragger);
    }
  }

  void fadeInPanel(FadePanel panel, JDialog owner) {
    panel.setAlpha(0.0f);
    panel.setVisible(true);
    if (owner != null) owner.revalidate();
    long started = System.nanoTime();
    javax.swing.Timer timer = new javax.swing.Timer(16, null);
    timer.setCoalesce(true);
    timer.addActionListener(
        e -> {
          if (owner != null && !owner.isDisplayable()) {
            timer.stop();
            return;
          }
          float t = Math.min(1f, (System.nanoTime() - started) / 280_000_000f);
          panel.setAlpha(t * t * (3f - 2f * t));
          if (t >= 1f) {
            panel.clearBackdrop();
            timer.stop();
          }
        });
    timer.start();
  }

  String buildItemInfoHtml(
      String rarity,
      String wear,
      double itemFloat,
      int pattern,
      String collection,
      boolean isAgent) {
    StringBuilder html =
        new StringBuilder(
            "<html><div style='color:#d8d8e0; font-family:Consolas; font-size:12px;'>");
    html.append("<b>Rarity:</b> ").append(app.saveService.jsonEscape(rarity)).append("<br>");
    if (!isAgent) {
      html.append("<b>Wear:</b> ").append(app.saveService.jsonEscape(wear)).append("<br>");
      if (!"Normal".equals(wear)) {
        html.append("<b>Float:</b> ").append(String.format("%.8f", itemFloat)).append("<br>");
      }
      html.append("<b>Pattern ID:</b> ").append(pattern).append("<br>");
    }
    if (!app.inventoryScreen.hasNoItemCollection(rarity))
      html.append("<b>Collection:</b> ")
          .append(app.saveService.jsonEscape(collection != null ? collection : "Unknown"));
    html.append("</div></html>");
    return html.toString();
  }

  private boolean fullCardTooltipsConfigured;

  void installItemHover(JComponent component, String html) {
    if (!fullCardTooltipsConfigured) {
      fullCardTooltipsConfigured = true;
      UIManager.put("ToolTip.background", new Color(16, 18, 26));
      UIManager.put("ToolTip.foreground", new Color(220, 225, 235));
      UIManager.put(
          "ToolTip.border",
          BorderFactory.createCompoundBorder(
              BorderFactory.createLineBorder(new Color(89, 119, 143)),
              BorderFactory.createEmptyBorder(9, 11, 9, 11)));
      ToolTipManager.sharedInstance().setInitialDelay(180);
      ToolTipManager.sharedInstance().setDismissDelay(15000);
    }
    component.setToolTipText(html);
    if (component instanceof java.awt.Container)
      for (Component child : ((java.awt.Container) component).getComponents())
        if (child instanceof JComponent) installItemHover((JComponent) child, html);
  }

  JComponent createInfoBadge(String infoHtml) {
    JLabel badge =
        new JLabel("i", SwingConstants.CENTER) {
          @Override
          protected void paintComponent(Graphics g) {
            Graphics2D g2 = (Graphics2D) g.create();
            g2.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
            g2.setColor(new Color(38, 44, 58));
            g2.fillOval(0, 0, getWidth() - 1, getHeight() - 1);
            g2.setColor(Theme.ACCENT_CT);
            g2.setStroke(Theme.STROKE_2);
            g2.drawOval(1, 1, getWidth() - 3, getHeight() - 3);
            g2.dispose();
            super.paintComponent(g);
          }
        };
    badge.setOpaque(false);
    badge.setForeground(Theme.ACCENT_CT);
    badge.setFont(Theme.CONSOLE_BOLD_14);
    badge.setPreferredSize(new Dimension(28, 28));
    badge.setToolTipText(null);
    final JPopupMenu infoPopup = new JPopupMenu();
    infoPopup.setBorder(BorderFactory.createLineBorder(Theme.ACCENT_CT, 1));
    JLabel infoLabel = new JLabel(infoHtml);
    infoLabel.setOpaque(true);
    infoLabel.setBackground(Theme.BG_PANEL);
    infoLabel.setForeground(Theme.TEXT);
    infoLabel.setFont(Theme.CONSOLE_PLAIN_12);
    infoLabel.setBorder(BorderFactory.createEmptyBorder(8, 10, 8, 10));
    infoPopup.add(infoLabel);
    badge.addMouseListener(
        new MouseAdapter() {
          @Override
          public void mouseEntered(MouseEvent e) {
            infoPopup.show(badge, 0, -infoPopup.getPreferredSize().height - 6);
          }

          @Override
          public void mouseExited(MouseEvent e) {
            infoPopup.setVisible(false);
          }
        });
    return badge;
  }

  FadePanel createRewardResultPanel(
      Image image,
      String name,
      String subtitle,
      Color accent,
      String infoHtml,
      String closeText,
      ActionListener closeAction) {
    if (app.cs2ShellEnabled)
      return app.cs2Screens.createCs2RewardPanel(image, name, accent, infoHtml, closeAction);
    FadePanel result = new FadePanel(new BorderLayout(12, 8));
    result.setBackground(Theme.BG_DARK);
    result.setBorder(BorderFactory.createEmptyBorder(12, 14, 12, 14));
    result.setAlpha(0.0f);
    result.setVisible(false);

    JLabel imageLabel = new JLabel("", SwingConstants.CENTER);
    app.activeResultImageLabel = imageLabel;
    if (image != null) {
      int iw = image.getWidth(null);
      int ih = image.getHeight(null);
      Image display = image;
      if (iw > 0 && ih > 0) {
        double scale = Math.min(430.0 / iw, 285.0 / ih);
        display =
            HighQualityImages.fit(
                image, Math.max(1, (int) (iw * scale)), Math.max(1, (int) (ih * scale)));
      }
      imageLabel.setIcon(new ImageIcon(display));
    }
    result.add(imageLabel, BorderLayout.NORTH);

    if (subtitle != null && !subtitle.trim().isEmpty()) {
      JPanel text = new JPanel(new GridLayout(1, 1));
      text.setOpaque(false);
      JLabel subLabel = new JLabel(subtitle, SwingConstants.CENTER);
      subLabel.setFont(Theme.CONSOLE_PLAIN_12);
      subLabel.setForeground(Theme.TEXT_DIM);
      text.add(subLabel);
      result.add(text, BorderLayout.CENTER);
    }

    JPanel bottom = new JPanel(new BorderLayout());
    bottom.setOpaque(false);
    bottom.add(app.uiWidgets.createInfoBadge(infoHtml), BorderLayout.WEST);
    JButton closeBtn = new JButton(closeText);
    app.uiWidgets.styleButton(
        closeBtn, new Color(30, 80, 30), new Color(80, 220, 80), new Color(80, 200, 80));
    closeBtn.setFont(Theme.CONSOLE_BOLD_13);
    closeBtn.addActionListener(closeAction);
    bottom.add(closeBtn, BorderLayout.EAST);
    result.add(bottom, BorderLayout.SOUTH);

    return result;
  }

  void configureOpeningDialog(JDialog dialog) {
    if (app.cs2ShellEnabled) {
      app.cs2Screens.configureCs2Dialog(dialog);
      return;
    }
    dialog.setUndecorated(true);
    app.uiWidgets.installDialogDragHandler(dialog);
    dialog.getRootPane().setBorder(BorderFactory.createLineBorder(Theme.ACCENT_T, 2));
    dialog.getRootPane().setOpaque(true);
    dialog.getRootPane().setBackground(Theme.BG_DARK);
    dialog.setSize(AnimationConfig.DIALOG_WIDTH, AnimationConfig.DIALOG_HEIGHT + 90);
    dialog.setLocationRelativeTo(app);
    dialog.setLayout(new BorderLayout());
    dialog.getContentPane().setBackground(Theme.BG_DARK);
    if (dialog.getContentPane() instanceof JComponent) {
      ((JComponent) dialog.getContentPane()).setOpaque(true);
    }
  }

  JButton makeIconButton(String text, Color bg, Color fg, Color border) {
    JButton btn = new JButton(text);
    app.uiWidgets.styleButton(btn, bg, fg, border);
    btn.setFont(Theme.CONSOLE_BOLD_12);
    return btn;
  }

  JPanel createControlRow() {
    JPanel panel = new JPanel(new FlowLayout(FlowLayout.LEFT, 8, 6));
    panel.setBackground(Theme.BG_PANEL);
    return panel;
  }

  JLabel createControlLabel(String text, boolean emphasized) {
    JLabel label = new JLabel(text);
    label.setForeground(emphasized ? Theme.TEXT : Theme.TEXT_DIM);
    label.setFont(emphasized ? Theme.CONSOLE_BOLD_12 : Theme.CONSOLE_PLAIN_12);
    return label;
  }

  JTextField createDarkTextField(int columns) {
    JTextField field = new JTextField(columns);
    field.setBackground(Theme.BG_CARD);
    field.setForeground(Theme.TEXT);
    field.setCaretColor(Theme.TEXT);
    field.setBorder(
        BorderFactory.createCompoundBorder(
            BorderFactory.createLineBorder(Theme.BORDER, 1),
            BorderFactory.createEmptyBorder(4, 8, 4, 8)));
    field.setFont(Theme.CONSOLE_PLAIN_12);
    return field;
  }

  JComboBox<String> createComboBox(String[] options) {
    JComboBox<String> box = new JComboBox<>(options);
    app.uiWidgets.styleComboBox(box);
    return box;
  }

  void styleComboBox(JComboBox<String> box) {
    box.setFont(Theme.CONSOLE_PLAIN_12);
    box.setBackground(Theme.BG_PANEL);
    box.setForeground(Theme.TEXT);
    box.setUI(
        new javax.swing.plaf.basic.BasicComboBoxUI() {
          @Override
          public void paintCurrentValueBackground(Graphics g, Rectangle bounds, boolean hasFocus) {
            g.setColor(Theme.BG_PANEL);
            g.fillRect(bounds.x, bounds.y, bounds.width, bounds.height);
          }

          @Override
          public void paintCurrentValue(Graphics g, Rectangle bounds, boolean hasFocus) {
            // BasicComboBoxUI otherwise overwrites the renderer with native disabled
            // colors (light text on a white field on some macOS/Linux themes).
            Component value =
                comboBox
                    .getRenderer()
                    .getListCellRendererComponent(
                        listBox, comboBox.getSelectedItem(), -1, false, false);
            value.setFont(comboBox.getFont());
            value.setBackground(Theme.BG_PANEL);
            value.setForeground(comboBox.isEnabled() ? Theme.TEXT : new Color(160, 170, 190));
            currentValuePane.paintComponent(
                g,
                value,
                comboBox,
                bounds.x,
                bounds.y,
                bounds.width,
                bounds.height,
                value instanceof JPanel);
          }

          @Override
          protected JButton createArrowButton() {
            JButton btn =
                new JButton() {
                  @Override
                  protected void paintComponent(Graphics g) {
                    super.paintComponent(g);
                    Graphics2D g2 = (Graphics2D) g.create();
                    g2.setRenderingHint(
                        RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
                    g2.setColor(Theme.ACCENT_CT);
                    int[] xs = {getWidth() / 2 - 4, getWidth() / 2 + 4, getWidth() / 2};
                    int[] ys = {getHeight() / 2 - 2, getHeight() / 2 - 2, getHeight() / 2 + 3};
                    g2.fillPolygon(xs, ys, 3);
                    g2.dispose();
                  }
                };
            btn.setBackground(Theme.BG_PANEL);
            btn.setFocusPainted(false);
            btn.setBorder(BorderFactory.createEmptyBorder());
            btn.setContentAreaFilled(true);
            btn.setPreferredSize(new Dimension(18, 18));
            btn.setMinimumSize(new Dimension(18, 18));
            btn.setMaximumSize(new Dimension(18, Integer.MAX_VALUE));
            return btn;
          }

          @Override
          public void installUI(javax.swing.JComponent c) {
            super.installUI(c);
            comboBox.setBorder(
                BorderFactory.createCompoundBorder(
                    BorderFactory.createLineBorder(Theme.BORDER, 1),
                    BorderFactory.createEmptyBorder(2, 6, 2, 4)));
          }
        });
    box.setBackground(Theme.BG_PANEL);
    box.setForeground(Theme.TEXT);
    box.setRenderer(
        new DefaultListCellRenderer() {
          @Override
          public Component getListCellRendererComponent(
              JList<?> list, Object value, int index, boolean isSelected, boolean cellHasFocus) {
            super.getListCellRendererComponent(list, value, index, isSelected, cellHasFocus);
            setBackground(isSelected ? Theme.CARD_HOVER : Theme.BG_PANEL);
            setForeground(isSelected ? Theme.ACCENT_CT : Theme.TEXT);
            setBorder(BorderFactory.createEmptyBorder(2, 6, 2, 6));
            return this;
          }
        });
    if (box.isEditable()) {
      ComboBoxEditor editor = box.getEditor();
      if (editor != null) {
        Component editorComponent = editor.getEditorComponent();
        if (editorComponent instanceof JTextField) {
          JTextField field = (JTextField) editorComponent;
          field.setBackground(Theme.BG_PANEL);
          field.setForeground(Theme.TEXT);
          field.setCaretColor(Theme.TEXT);
          field.setBorder(BorderFactory.createEmptyBorder(2, 6, 2, 6));
          field.setFont(Theme.CONSOLE_PLAIN_12);
          field.setSelectionColor(Theme.CARD_HOVER);
          field.setSelectedTextColor(Theme.TEXT);
          field.setOpaque(true);
          field.setFocusable(true);
          field.setEditable(true);
        }
      }
    } else {
      box.setFocusable(false);
    }
  }

  JLabel makeModernLabel(int x, int y, int w, int h, int size, Color color) {
    JLabel lbl = new JLabel("", SwingConstants.LEFT);
    lbl.setBounds(x, y, w, h);
    lbl.setFont(new Font("Consolas", Font.BOLD, size));
    lbl.setForeground(color);
    return lbl;
  }
}
