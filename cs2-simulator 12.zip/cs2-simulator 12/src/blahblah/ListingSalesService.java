package blahblah;

import blahblah.hGui.*;
import java.awt.*;
import java.awt.event.*;
import java.util.ArrayList;
import javax.swing.*;

/** Listing Sales Service: focused feature implementation. */
final class ListingSalesService {
  private final hGui app;

  ListingSalesService(hGui app) {
    this.app = app;
  }

  void updateActiveListings() {
    ArrayList<MarketListing> sold = new ArrayList<>();
    for (MarketListing listing : app.activeListings) {
      listing.timeRemaining -= 5;
      if (listing.timeRemaining <= 0) {
        app.balance +=
            app.coreUtilities.money(listing.getPrice() * (1 - listing.saleFee)).doubleValue();
        app.missionProgress.marketSellCount++;
        double profit = listing.getPrice() * (1 - listing.saleFee) - listing.item.basePrice;
        if (profit > 0) {
          app.totalMarketProfit += profit;
        }
        String displayName =
            listing.item.isStattrak ? "StatTrak " + listing.item.name : listing.item.name;
        String specialVariant =
            listing.item.blueGemTier != null
                ? listing.item.blueGemTier
                : (listing.item.name.contains("Doppler") ? "Doppler" : null);
        SaleRecord sale =
            app.salesSimulationService.createSaleRecordFromListing(listing, null, null);
        if (sale == null) {
          sale =
              new SaleRecord(
                  displayName,
                  listing.getPrice(),
                  listing.item.condition,
                  listing.item.itemFloat,
                  specialVariant);
        }
        app.salesHistoryScreen.recordSaleRecord(sale);
        app.activitySimulationService.addSaleRecord(sale, true);
        app.missionService.checkMissionProgress();

        sold.add(listing);
      }
    }
    for (MarketListing done : sold) {
      done.quantity = 0;
      String key = done.item.isStattrak ? "StatTrak " + done.item.name : done.item.name;
      ArrayList<MarketListing> bucket = app.globalMarketListings.get(key);
      if (bucket != null) bucket.remove(done);
    }
    app.activeListings.removeAll(sold);

    if (!sold.isEmpty()) {
      if (sold.size() == 1) {
        MarketListing s = sold.get(0);
        app.tradeNotificationLabel.setText(
            "SOLD: " + s.item.name + " - $" + String.format("%.2f", s.getPrice()));
      } else {
        double totalSold = sold.stream().mapToDouble(l -> l.getPrice()).sum();
        app.tradeNotificationLabel.setText(
            "SOLD " + sold.size() + " items - $" + String.format("%.2f", totalSold));
      }

      javax.swing.Timer clearNotif =
          new javax.swing.Timer(5000, e -> app.tradeNotificationLabel.setText(""));
      clearNotif.setRepeats(false);
      clearNotif.start();
    }

    if (!sold.isEmpty() && !app.achievements.get("first_sale").isUnlocked) {
      app.achievementScreen.unlockAchievement("first_sale");
    }

    if (app.totalMarketProfit >= 10000 && !app.achievements.get("market_profit_10k").isUnlocked) {
      app.achievementScreen.unlockAchievement("market_profit_10k");
    }
    app.missionService.checkMarketAchievements();

    if (!sold.isEmpty()) {
      app.uiWidgets.updateBalanceLabel();
      app.marketStockService.invalidateGroupedMarketListingsCache();
      if (app.cs2ShellEnabled) app.saveService.saveProgress();
    }
  }

  double getCurrentMarketPrice(InventoryItem item) {
    if (app.cs2EquipmentScreens.isDefaultWeaponItem(item)) return 0;
    if (app.itemPriceService.isBlueGem(item)) {

      return item.price.doubleValue();
    }

    if (app.floatRules.isVanillaKnife(item.name)) {
      return app.marketStockService.getVanillaVariantBasePrice(
              item.name, item.isStattrak, app.itemPriceService.getBasePrice(item.name))
          * app.marketInitialization.getMarketMultiplier(
              "Knife", app.collectionService.getCollectionName(item.name)) * MarketDynamics.factor(item.name);
    }
    String rarityKey = item.rarity.replace("StatTrak ", "").replace("StatTrak ", "");
    boolean isGloveRarity = rarityKey.equals("Gloves");

    double rawBase;
    if (isGloveRarity) {

      double gloveBase = app.itemPriceService.getBasePrice(item.name);
      rawBase = app.priceTables.calculateGlovePrice(item.name, item.condition, gloveBase);
    } else {
      rawBase = app.itemPriceService.getBasePrice(item.name);
      boolean hasNoFloatWear =
          app.itemMetadataService.isAgentSkin(item.name)
              || app.floatRules.isVanillaKnife(item.name);
      if (!hasNoFloatWear) {
        rawBase *= app.priceModifiers.getMarketConditionMultiplier(item.name, item.condition);
      }

      if (item.isStattrak && app.itemMetadataService.supportsStatTrak(item.name)) {
        rawBase *= rarityKey.equals("Knife") ? 1.15 : 2.0;
      }
    }

    String collectionName =
        item.collection != null
            ? item.collection
            : app.collectionService.getCollectionName(item.name);
    double currentMarketMulti =
        app.marketInitialization.getMarketMultiplier(rarityKey, collectionName);
    return rawBase * currentMarketMulti * MarketDynamics.factor(item.name)
        * MarketDynamics.floatPremium(item.condition, item.itemFloat,
            app.marketStockService.getMarketWearBounds(item.name)[0], app.marketStockService.getMarketWearBounds(item.name)[1]);
  }

  int calculateSellTime(double listPrice, double marketPrice) {
    double ratio = listPrice / marketPrice;
    if (ratio <= 0.8) return 15 + hGui.random.nextInt(30);
    else if (ratio <= 0.9) return 30 + hGui.random.nextInt(30);
    else if (ratio <= 1.0) return 60 + hGui.random.nextInt(30);
    else if (ratio <= 1.1) return 90 + hGui.random.nextInt(30);
    else if (ratio <= 1.3) return 120 + hGui.random.nextInt(30);
    else return 180 + hGui.random.nextInt(100);
  }

  boolean isPhaseDopplerVariant(String skinName) {
    return skinName != null && skinName.contains("Doppler") && skinName.contains("(Phase ");
  }
}
