package blahblah;

import blahblah.hGui.*;
import java.awt.*;
import java.awt.event.*;
import java.util.ArrayList;
import java.util.Comparator;
import java.util.HashSet;
import java.util.Set;
import javax.swing.*;

/** Ownership History Service: focused feature implementation. */
final class OwnershipHistoryService {
  private final hGui app;

  OwnershipHistoryService(hGui app) {
    this.app = app;
  }

  String nextInventoryItemId() {
    synchronized (app) {
      return app.inventoryIdGenerator.nextId();
    }
  }

  void syncInventoryItemIdCounter(String itemId) {
    synchronized (app) {
      app.inventoryIdGenerator.observeExistingId(itemId);
    }
  }

  void ensureInventoryItemTracking(InventoryItem item) {
    if (item == null) return;
    if (item.itemId == null || item.itemId.trim().isEmpty()) {
      item.itemId = app.ownershipHistoryService.nextInventoryItemId();
    } else {
      app.ownershipHistoryService.syncInventoryItemIdCounter(item.itemId);
    }
    if (item.createdAt <= 0L) {
      item.createdAt = System.currentTimeMillis();
    }
    if (item.history == null) {
      item.history = new ArrayList<>();
    }
    if (item.currentOwner == null || item.currentOwner.trim().isEmpty()) {
      item.currentOwner = "UNASSIGNED";
    }
  }

  void addItemHistory(
      InventoryItem item, long timestamp, String title, String detail, String owner) {
    if (item == null || title == null || detail == null) return;
    app.ownershipHistoryService.ensureInventoryItemTracking(item);
    item.history.add(new ItemHistoryEntry(timestamp, title, detail, owner));
    item.history.sort(Comparator.comparingLong(h -> h.timestamp));
    if (owner != null && !owner.trim().isEmpty()) {
      item.currentOwner = owner;
    }
  }

  double extractHistoryPrice(ItemHistoryEntry entry, double fallbackPrice) {
    if (entry == null || entry.detail == null) return fallbackPrice;
    int dollarIndex = entry.detail.lastIndexOf('$');
    if (dollarIndex < 0 || dollarIndex + 1 >= entry.detail.length()) return fallbackPrice;
    StringBuilder amount = new StringBuilder();
    for (int i = dollarIndex + 1; i < entry.detail.length(); i++) {
      char ch = entry.detail.charAt(i);
      if ((ch >= '0' && ch <= '9') || ch == '.') amount.append(ch);
      else break;
    }
    try {
      return Math.max(1.0, Double.parseDouble(amount.toString()));
    } catch (NumberFormatException ex) {
      return fallbackPrice;
    }
  }

  void normalizeLegacyOwnershipHistory(InventoryItem item) {
    if (item == null || item.history == null || item.history.size() < 2) return;
    ArrayList<ItemHistoryEntry> cleaned = new ArrayList<>();
    double fallbackPrice = app.ownershipHistoryService.getHistoryReferencePrice(item);
    for (int i = 0; i < item.history.size(); i++) {
      ItemHistoryEntry current = item.history.get(i);
      String currentTitle = current.title != null ? current.title.toLowerCase() : "";
      boolean oldImmediateSale = currentTitle.contains("quick") && currentTitle.contains("sold");
      if (oldImmediateSale && i + 1 < item.history.size()) {
        ItemHistoryEntry next = item.history.get(i + 1);
        String nextTitle = next.title != null ? next.title.toLowerCase() : "";
        if (nextTitle.contains("buy") && nextTitle.contains("order")) {
          String from = current.owner != null ? current.owner : "Unknown";
          String to =
              next.owner != null
                  ? next.owner
                  : app.ownershipHistoryService.getRandomHistoryNameExcluding(from);
          double price =
              app.ownershipHistoryService.extractHistoryPrice(
                  next, app.ownershipHistoryService.extractHistoryPrice(current, fallbackPrice));
          cleaned.add(
              new ItemHistoryEntry(
                  next.timestamp,
                  "Traded",
                  String.format("%s traded to %s for $%.2f", from, to, price),
                  to));
          i++;
          continue;
        }
      }
      if ("Bought Off Market".equals(current.title)) {
        String marketName = app.ownershipHistoryService.getHistoryMarketplaceFromPrevious(cleaned);
        current.title = "Bought From " + marketName;
        if (current.detail != null) {
          current.detail =
              current.detail.replace(
                  "Bought off the market by", "Bought from " + marketName + " by");
        }
      }
      cleaned.add(current);
    }
    item.history = cleaned;
    item.history.sort(Comparator.comparingLong(h -> h.timestamp));
  }

  String getHistoryMarketplaceFromPrevious(ArrayList<ItemHistoryEntry> history) {
    if (history == null || history.isEmpty()) return MarketplaceProfile.randomForListing().name;
    ItemHistoryEntry previous = history.get(history.size() - 1);
    if (previous == null || previous.detail == null)
      return MarketplaceProfile.randomForListing().name;
    String marker = "Listed on ";
    int start = previous.detail.indexOf(marker);
    int end = previous.detail.indexOf(" for $", start >= 0 ? start : 0);
    if (start >= 0 && end > start + marker.length()) {
      String market = previous.detail.substring(start + marker.length(), end).trim();
      if (!market.equalsIgnoreCase("market") && !market.isEmpty()) return market;
    }
    return MarketplaceProfile.randomForListing().name;
  }

  String getRandomHistoryNameExcluding(String... excluded) {
    Set<String> blocked = new HashSet<>();
    if (excluded != null) {
      for (String name : excluded) {
        if (name != null && !name.trim().isEmpty()) blocked.add(name.trim());
      }
    }
    String candidate = hGui.NPC_USERNAMES[hGui.random.nextInt(hGui.NPC_USERNAMES.length)];
    int safety = 0;
    while (blocked.contains(candidate) && safety++ < 20) {
      candidate = hGui.NPC_USERNAMES[hGui.random.nextInt(hGui.NPC_USERNAMES.length)];
    }
    return candidate;
  }

  long randomBetween(long minInclusive, long maxInclusive) {
    long min = Math.min(minInclusive, maxInclusive);
    long max = Math.max(minInclusive, maxInclusive);
    long spread = Math.max(1L, max - min + 1L);
    return min + ((hGui.random.nextLong() & Long.MAX_VALUE) % spread);
  }

  boolean isSameCalendarDay(long a, long b) {
    java.util.Calendar ca = java.util.Calendar.getInstance();
    java.util.Calendar cb = java.util.Calendar.getInstance();
    ca.setTimeInMillis(a);
    cb.setTimeInMillis(b);
    return ca.get(java.util.Calendar.YEAR) == cb.get(java.util.Calendar.YEAR)
        && ca.get(java.util.Calendar.DAY_OF_YEAR) == cb.get(java.util.Calendar.DAY_OF_YEAR);
  }

  boolean isSyntheticHistoryInvalid(InventoryItem item) {
    if (item == null || item.history == null || item.history.isEmpty()) return true;
    long now = System.currentTimeMillis();
    long tenYearsAgo = now - (3650L * 24L * 60L * 60L * 1000L);
    ArrayList<ItemHistoryEntry> history = new ArrayList<>(item.history);
    history.sort(Comparator.comparingLong(h -> h.timestamp));

    if (!"Unboxed".equals(history.get(0).title)) return true;

    boolean allSameDay = true;
    for (int i = 0; i < history.size(); i++) {
      ItemHistoryEntry entry = history.get(i);
      if (entry.timestamp < tenYearsAgo || entry.timestamp > now) return true;
      if (i > 0) {
        if (entry.timestamp < history.get(i - 1).timestamp) return true;
        if (!app.ownershipHistoryService.isSameCalendarDay(
            entry.timestamp, history.get(0).timestamp)) {
          allSameDay = false;
        }
        String prevTitle = history.get(i - 1).title != null ? history.get(i - 1).title : "";
        String title = entry.title != null ? entry.title : "";
        String lowerTitle = title.toLowerCase();
        if ((lowerTitle.contains("buy") && lowerTitle.contains("order"))
            || (lowerTitle.contains("quick") && lowerTitle.contains("sold"))) return true;
        boolean titleIsMarketPurchase =
            "Bought Off Market".equals(title) || title.startsWith("Bought From ");
        if ("Listed On Market".equals(prevTitle) && !titleIsMarketPurchase) return true;
        if (titleIsMarketPurchase && !"Listed On Market".equals(prevTitle)) return true;
      }
    }
    return allSameDay && history.size() > 1;
  }

  double getHistoryReferencePrice(InventoryItem item) {
    if (item == null) return 10.0;
    double current = item.price != null ? item.price.doubleValue() : 0.0;
    double base = item.basePrice > 0 ? item.basePrice : 0.0;
    if (current > 0 && base > 0) return (current * 0.65) + (base * 0.35);
    if (current > 0) return current;
    if (base > 0) return base;
    return 10.0;
  }

  double generateHistoryMarketPrice(InventoryItem item) {
    double ref = app.ownershipHistoryService.getHistoryReferencePrice(item);
    return Math.max(1.0, ref * (0.82 + hGui.random.nextDouble() * 0.28));
  }

  double generateHistoryTradePrice(double marketPrice) {
    return Math.max(1.0, marketPrice * (0.62 + hGui.random.nextDouble() * 0.18));
  }

  void seedRandomOwnershipHistory(InventoryItem item, String finalOwner) {
    app.ownershipHistoryService.ensureInventoryItemTracking(item);
    if (!item.history.isEmpty()) return;

    long now = System.currentTimeMillis();
    long tenYearsAgo = now - (3650L * 24L * 60L * 60L * 1000L);
    long idleGap = app.ownershipHistoryService.randomBetween(0L, 900L * 24L * 60L * 60L * 1000L);
    long timelineEnd = Math.max(tenYearsAgo + (60L * 24L * 60L * 60L * 1000L), now - idleGap);
    String currentHolder =
        app.ownershipHistoryService.getRandomHistoryNameExcluding(finalOwner, "YOU");
    int transferCount = 1 + hGui.random.nextInt(4);
    int eventCount = 1 + (transferCount * 2);
    long minSpan = Math.max(45L, eventCount * 20L) * 24L * 60L * 60L * 1000L;
    long maxSpan = Math.max(minSpan, timelineEnd - tenYearsAgo);
    long timelineSpan = app.ownershipHistoryService.randomBetween(minSpan, maxSpan);
    long cursor = Math.max(tenYearsAgo, timelineEnd - timelineSpan);
    item.history.clear();
    app.ownershipHistoryService.addItemHistory(
        item, cursor, "Unboxed", "Unboxed by " + currentHolder, currentHolder);

    for (int i = 0; i < transferCount; i++) {
      boolean finalTransfer = i == transferCount - 1;
      String nextOwner =
          finalTransfer
              ? finalOwner
              : app.ownershipHistoryService.getRandomHistoryNameExcluding(
                  currentHolder, finalOwner, "YOU");
      double marketPrice = app.ownershipHistoryService.generateHistoryMarketPrice(item);
      int remainingTransfers = transferCount - i;
      long remainingWindow = Math.max(14L * 24L * 60L * 60L * 1000L, timelineEnd - cursor);
      long firstMinGap = 20L * 24L * 60L * 60L * 1000L;
      long firstMaxGap =
          Math.max(firstMinGap, remainingWindow / Math.max(remainingTransfers * 2L, 2L));
      long firstEventTime =
          Math.min(
              timelineEnd - (remainingTransfers * 2L * 24L * 60L * 60L * 1000L),
              cursor + app.ownershipHistoryService.randomBetween(firstMinGap, firstMaxGap));
      int transferType = hGui.random.nextInt(4);
      if (transferType == 0) {
        String historyMarket = MarketplaceProfile.randomForListing().name;
        app.ownershipHistoryService.addItemHistory(
            item,
            firstEventTime,
            "Listed On Market",
            String.format(
                "Listed on %s for $%.2f by %s", historyMarket, marketPrice, currentHolder),
            currentHolder);
        long secondMinGap = 3L * 24L * 60L * 60L * 1000L;
        long secondMaxGap =
            Math.max(
                secondMinGap,
                (timelineEnd - firstEventTime) / Math.max(remainingTransfers * 2L - 1L, 1L));
        long secondEventTime =
            Math.min(
                timelineEnd
                    - Math.max(0L, (remainingTransfers - 1L) * 2L * 24L * 60L * 60L * 1000L),
                firstEventTime
                    + app.ownershipHistoryService.randomBetween(secondMinGap, secondMaxGap));
        app.ownershipHistoryService.addItemHistory(
            item,
            secondEventTime,
            "Bought From " + historyMarket,
            String.format("Bought from %s by %s for $%.2f", historyMarket, nextOwner, marketPrice),
            nextOwner);
        cursor = secondEventTime;
      } else if (transferType == 1) {
        double tradePrice = app.ownershipHistoryService.generateHistoryTradePrice(marketPrice);
        app.ownershipHistoryService.addItemHistory(
            item,
            firstEventTime,
            "Traded",
            String.format("%s traded to %s for $%.2f", currentHolder, nextOwner, tradePrice),
            nextOwner);
        cursor = firstEventTime;
      } else if (transferType == 2) {
        app.ownershipHistoryService.addItemHistory(
            item,
            firstEventTime,
            "Private Sale",
            String.format(
                "%s sold privately to %s for $%.2f", currentHolder, nextOwner, marketPrice),
            nextOwner);
        cursor = firstEventTime;
      } else {
        app.ownershipHistoryService.addItemHistory(
            item,
            firstEventTime,
            "Trade Accepted",
            String.format("%s accepted a trade offer from %s", nextOwner, currentHolder),
            nextOwner);
        cursor = firstEventTime;
      }
      currentHolder = nextOwner;
    }
    if (finalOwner != null && !finalOwner.equals(currentHolder)) {
      double marketPrice = app.ownershipHistoryService.generateHistoryMarketPrice(item);
      String historyMarket = MarketplaceProfile.randomForListing().name;
      long nextTime =
          Math.min(
              timelineEnd - (24L * 60L * 60L * 1000L),
              cursor
                  + app.ownershipHistoryService.randomBetween(
                      7L * 24L * 60L * 60L * 1000L, 180L * 24L * 60L * 60L * 1000L));
      app.ownershipHistoryService.addItemHistory(
          item,
          nextTime,
          "Listed On Market",
          String.format("Listed on %s for $%.2f by %s", historyMarket, marketPrice, currentHolder),
          currentHolder);
      long finalTime =
          Math.min(
              timelineEnd,
              nextTime
                  + app.ownershipHistoryService.randomBetween(
                      1L * 24L * 60L * 60L * 1000L, 45L * 24L * 60L * 60L * 1000L));
      app.ownershipHistoryService.addItemHistory(
          item,
          finalTime,
          "Bought From " + historyMarket,
          String.format("Bought from %s by %s for $%.2f", historyMarket, finalOwner, marketPrice),
          finalOwner);
    }
  }

  void ensureTrackedHistoryForDisplay(InventoryItem item, String fallbackOwner) {
    if (item == null) return;
    app.ownershipHistoryService.ensureInventoryItemTracking(item);
    String owner =
        (fallbackOwner != null && !fallbackOwner.trim().isEmpty())
            ? fallbackOwner
            : item.currentOwner;
    if (item.history != null && !item.history.isEmpty()) {
      app.ownershipHistoryService.normalizeLegacyOwnershipHistory(item);
      if (!"YOU".equalsIgnoreCase(owner)
          && app.ownershipHistoryService.isSyntheticHistoryInvalid(item)) {
        item.history.clear();
        app.ownershipHistoryService.seedRandomOwnershipHistory(
            item,
            owner != null
                ? owner
                : app.ownershipHistoryService.getRandomHistoryNameExcluding("YOU"));
      }
      if (owner != null && !owner.trim().isEmpty()) item.currentOwner = owner;
      return;
    }
    if ("YOU".equalsIgnoreCase(owner)) {
      app.ownershipHistoryService.addItemHistory(
          item, item.createdAt, "Legacy Item", "Initial tracked owner recorded as YOU", "YOU");
    } else {
      app.ownershipHistoryService.seedRandomOwnershipHistory(
          item,
          owner != null ? owner : app.ownershipHistoryService.getRandomHistoryNameExcluding("YOU"));
    }
  }

  java.util.List<ItemHistoryEntry> getDisplayHistory(InventoryItem item, String fallbackOwner) {
    app.ownershipHistoryService.ensureTrackedHistoryForDisplay(item, fallbackOwner);
    ArrayList<ItemHistoryEntry> history = new ArrayList<>();
    if (item != null && item.history != null) {
      history.addAll(item.history);
      history.sort(Comparator.comparingLong(a -> a.timestamp));
    }
    return history;
  }

  Image getInspectDisplayImage(InventoryItem item) {
    if (item == null) return null;
    String cleanName = item.name != null ? item.name.replace("StatTrak ", "").trim() : "";
    if (item.blueGemTier != null && cleanName.contains("(Blue Gem")) {
      cleanName = cleanName.substring(0, cleanName.indexOf("(Blue Gem")).trim();
    }
    Image source = app.artworkService.getSkinImageFromName(cleanName, item.condition);
    if (source == null && item.image != null) source = item.image.getImage();
    return source;
  }

  Image scaleImageToFit(Image source, int maxWidth, int maxHeight) {
    if (source == null) return null;
    int iw = source.getWidth(null);
    int ih = source.getHeight(null);
    if (iw <= 0 || ih <= 0) return source;
    double scale = Math.min((double) maxWidth / iw, (double) maxHeight / ih);
    scale = Math.max(scale, 0.01);
    int targetW = Math.max(1, (int) Math.round(iw * scale));
    int targetH = Math.max(1, (int) Math.round(ih * scale));
    java.awt.image.BufferedImage scaled =
        new java.awt.image.BufferedImage(
            targetW, targetH, java.awt.image.BufferedImage.TYPE_INT_ARGB);
    Graphics2D g2 = scaled.createGraphics();
    g2.setRenderingHint(
        RenderingHints.KEY_INTERPOLATION, RenderingHints.VALUE_INTERPOLATION_BICUBIC);
    g2.setRenderingHint(RenderingHints.KEY_RENDERING, RenderingHints.VALUE_RENDER_QUALITY);
    g2.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
    g2.drawImage(source, 0, 0, targetW, targetH, null);
    g2.dispose();
    return scaled;
  }
}
