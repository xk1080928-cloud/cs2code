package blahblah;

import blahblah.hGui.*;
import java.awt.*;
import java.awt.event.*;
import javax.swing.*;

/** Search Controls: focused feature implementation. */
final class SearchControls {
  private final hGui app;

  SearchControls(hGui app) {
    this.app = app;
  }

  void showCaseSelection() {
    JFrame caseFrame = new JFrame("Select Case Type");
    caseFrame.setSize(760, 500);
    caseFrame.setLocationRelativeTo(app);
    caseFrame.setLayout(new GridLayout(0, 3, 20, 20));
    caseFrame.getContentPane().setBackground(new Color(30, 30, 35));
    ((JPanel) caseFrame.getContentPane())
        .setBorder(BorderFactory.createEmptyBorder(20, 20, 20, 20));

    for (CaseType caseType : CaseType.values()) {
      JPanel casePanel = new JPanel(new BorderLayout());
      casePanel.setBackground(new Color(50, 50, 55));
      casePanel.setBorder(
          BorderFactory.createCompoundBorder(
              BorderFactory.createLineBorder(
                  app.currentCase == caseType ? Color.GREEN : Color.GRAY, 3),
              BorderFactory.createEmptyBorder(15, 15, 15, 15)));

      JLabel nameLabel = new JLabel(caseType.name, SwingConstants.CENTER);
      nameLabel.setFont(new Font("Arial", Font.BOLD, 20));
      nameLabel.setForeground(Color.WHITE);

      JLabel priceLabel =
          new JLabel("$" + String.format("%.2f", caseType.price), SwingConstants.CENTER);
      priceLabel.setFont(new Font("Arial", Font.BOLD, 18));
      priceLabel.setForeground(Color.YELLOW);

      String description =
          caseType.goldDropLabel() + " only | $" + String.format("%.2f", caseType.price);

      JLabel descLabel = new JLabel(description, SwingConstants.CENTER);
      descLabel.setFont(new Font("Arial", Font.ITALIC, 14));
      descLabel.setForeground(Color.LIGHT_GRAY);

      JButton selectBtn = new JButton("SELECT");
      selectBtn.setFont(new Font("Arial", Font.BOLD, 14));
      selectBtn.setBackground(new Color(50, 150, 50));
      selectBtn.addActionListener(
          e -> {
            app.currentCase = caseType;
            app.openCrateButton.setText(
                String.format(
                    "OPEN CASE  $%.2f", app.developerTools.getCaseOpeningCost(app.currentCase)));
            caseFrame.dispose();
          });

      JPanel infoPanel = new JPanel(new GridLayout(4, 1));
      infoPanel.setBackground(new Color(50, 50, 55));
      infoPanel.add(nameLabel);
      infoPanel.add(priceLabel);
      infoPanel.add(descLabel);
      infoPanel.add(selectBtn);

      casePanel.add(infoPanel, BorderLayout.CENTER);
      caseFrame.add(casePanel);
    }

    caseFrame.setVisible(true);
  }

  void addToSearchHistory(String query) {
    query = query.trim().toLowerCase();
    if (query.isEmpty()) return;

    app.searchHistory.remove(query);
    app.searchHistory.addFirst(query);

    if (app.searchHistory.size() > hGui.MAX_SEARCH_HISTORY) {
      app.searchHistory.removeLast();
    }
    for (JComboBox<String> searchBox : app.searchBoxes) {
      app.searchControls.refreshSearchFieldItems(
          searchBox, app.searchControls.getSearchText(searchBox));
    }
  }

  JComboBox<String> createSearchFieldWithHistory(int columns) {
    JComboBox<String> searchBox = new JComboBox<>();
    searchBox.setEditable(true);
    app.uiWidgets.styleComboBox(searchBox);
    searchBox.setFont(new Font("Consolas", Font.PLAIN, 13));
    searchBox.putClientProperty("JComboBox.isTableCellEditor", Boolean.FALSE);
    JTextField editor = app.searchControls.getSearchEditor(searchBox);
    if (editor != null) {
      editor.setBackground(Theme.BG_PANEL);
      editor.setForeground(Theme.TEXT);
      editor.setCaretColor(Theme.TEXT);
      editor.setSelectionColor(Theme.ACCENT_CT.darker());
      editor.setSelectedTextColor(Theme.TEXT);
      editor.setBorder(BorderFactory.createEmptyBorder(0, 2, 0, 2));
      editor.setColumns(columns);
      Dimension size = editor.getPreferredSize();
      searchBox.setPreferredSize(new Dimension(size.width + 26, Math.max(28, size.height + 6)));
    }
    app.searchBoxes.add(searchBox);
    app.searchControls.refreshSearchFieldItems(searchBox, "");
    return searchBox;
  }

  JTextField getSearchEditor(JComboBox<String> searchBox) {
    Component editor = searchBox.getEditor().getEditorComponent();
    return editor instanceof JTextField ? (JTextField) editor : null;
  }

  String getSearchText(JComboBox<String> searchBox) {
    JTextField editor = app.searchControls.getSearchEditor(searchBox);
    if (editor != null) {
      return editor.getText().toLowerCase().trim();
    }
    Object selected = searchBox.getSelectedItem();
    return selected == null ? "" : selected.toString().toLowerCase().trim();
  }

  void refreshSearchFieldItems(JComboBox<String> searchBox, String currentText) {
    searchBox.putClientProperty("searchHistorySyncing", Boolean.TRUE);
    searchBox.removeAllItems();
    String normalized = currentText == null ? "" : currentText.toLowerCase().trim();
    for (String query : app.searchHistory) {
      if (normalized.isEmpty() || query.contains(normalized)) {
        searchBox.addItem(query);
      }
    }
    JTextField editor = app.searchControls.getSearchEditor(searchBox);
    if (editor != null) {
      editor.setText(currentText);
    } else {
      searchBox.setSelectedItem(currentText);
    }
    searchBox.putClientProperty("searchHistorySyncing", Boolean.FALSE);
  }

  void commitSearchQuery(JComboBox<String> searchBox) {
    String query = app.searchControls.getSearchText(searchBox);
    if (query.isEmpty()) return;
    app.searchControls.addToSearchHistory(query);
    app.searchControls.refreshSearchFieldItems(searchBox, query);
  }

  javax.swing.Timer createSearchHistoryTimer(JComboBox<String> searchBox, Runnable updateAction) {
    javax.swing.Timer timer =
        new javax.swing.Timer(
            300,
            e -> {
              updateAction.run();
            });
    timer.setRepeats(false);
    return timer;
  }

  void installSearchHistoryHandlers(
      JComboBox<String> searchBox, javax.swing.Timer timer, Runnable updateAction) {
    JTextField editor = app.searchControls.getSearchEditor(searchBox);
    if (editor != null) {
      editor
          .getDocument()
          .addDocumentListener(
              new javax.swing.event.DocumentListener() {
                void changed() {
                  if (Boolean.TRUE.equals(searchBox.getClientProperty("searchHistorySyncing"))) {
                    return;
                  }
                  final String text = app.searchControls.getSearchText(searchBox);
                  SwingUtilities.invokeLater(
                      () -> {
                        app.searchControls.refreshSearchFieldItems(searchBox, text);
                        if (!text.isEmpty() && searchBox.getItemCount() > 0) {
                          searchBox.setPopupVisible(true);
                        }
                      });
                  timer.restart();
                }

                public void insertUpdate(javax.swing.event.DocumentEvent e) {
                  changed();
                }

                public void removeUpdate(javax.swing.event.DocumentEvent e) {
                  changed();
                }

                public void changedUpdate(javax.swing.event.DocumentEvent e) {
                  changed();
                }
              });
    }
    searchBox.addActionListener(
        e -> {
          if (Boolean.TRUE.equals(searchBox.getClientProperty("searchHistorySyncing"))) {
            return;
          }
          app.searchControls.commitSearchQuery(searchBox);
          updateAction.run();
        });
  }

  void updateLeaderboard() {
    app.globalLeaderboard.removeIf(entry -> entry.isPlayer);

    if (app.inventoryValue > 0) {
      app.globalLeaderboard.add(
          new LeaderboardEntry("YOU", app.inventoryValue, app.playerAvatar, true));
    }

    app.globalLeaderboard.sort((a, b) -> Double.compare(b.inventoryValue, a.inventoryValue));
    for (int i = 0; i < app.globalLeaderboard.size(); i++) {
      app.globalLeaderboard.get(i).rank = i + 1;
    }
  }
}
