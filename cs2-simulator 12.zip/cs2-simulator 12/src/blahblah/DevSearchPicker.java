package blahblah;

import blahblah.hGui.*;
import java.awt.*;
import java.awt.event.*;
import java.util.ArrayList;
import java.util.List;
import javax.swing.*;

/** Extracted reusable model or widget; behavior retained from the original source. */
final class DevSearchPicker<T> extends JPanel {
  final JTextField search = new JTextField();
  final DefaultListModel<T> model = new DefaultListModel<>();
  final JList<T> list = new JList<>(model);
  final JLabel summary = new JLabel(" ");
  final List<T> values;
  final List<Runnable> listeners = new ArrayList<>();
  boolean filtering;
  boolean collapseOnSelection;
  JScrollPane results;

  DevSearchPicker(List<T> values, String name, int rows) {
    super(new BorderLayout(0, 5));
    this.values = List.copyOf(values);
    setOpaque(false);
    search.setName(name + "Search");
    list.setName(name);
    search.setToolTipText("Search by name; use Down and arrow keys to browse matches");
    search.getAccessibleContext().setAccessibleName("Search " + name);
    search.setBackground(Theme.BG_CARD);
    search.setForeground(Theme.TEXT);
    search.setCaretColor(Theme.TEXT);
    search.setBorder(
        BorderFactory.createCompoundBorder(
            BorderFactory.createLineBorder(Theme.BORDER),
            BorderFactory.createEmptyBorder(7, 9, 7, 9)));
    search.setPreferredSize(new Dimension(500, 34));
    list.setSelectionMode(ListSelectionModel.SINGLE_SELECTION);
    list.setVisibleRowCount(rows);
    list.setFixedCellHeight(27);
    list.setBackground(Theme.BG_CARD);
    list.setForeground(Theme.TEXT);
    list.setSelectionBackground(Theme.CARD_HOVER);
    list.setSelectionForeground(Theme.ACCENT_CT);
    list.setCellRenderer(
        new DefaultListCellRenderer() {
          public Component getListCellRendererComponent(
              JList<?> view, Object value, int index, boolean selected, boolean focus) {
            super.getListCellRendererComponent(view, value, index, selected, focus);
            setOpaque(true);
            setVerticalAlignment(SwingConstants.CENTER);
            setBorder(BorderFactory.createEmptyBorder(3, 8, 3, 8));
            setBackground(selected ? Theme.CARD_HOVER : Theme.BG_CARD);
            setForeground(selected ? Theme.ACCENT_CT : Theme.TEXT);
            setToolTipText(value == null ? null : value.toString());
            return this;
          }
        });
    JScrollPane scroll =
        new JScrollPane(
            list, JScrollPane.VERTICAL_SCROLLBAR_AS_NEEDED, JScrollPane.HORIZONTAL_SCROLLBAR_NEVER);
    results = scroll;
    results.setName(name + "Results");
    scroll.setBorder(BorderFactory.createLineBorder(Theme.BORDER));
    scroll.setPreferredSize(new Dimension(500, rows * 27 + 2));
    scroll.getVerticalScrollBar().setUnitIncrement(27);
    summary.setForeground(Theme.TEXT_DIM);
    add(search, BorderLayout.NORTH);
    add(scroll, BorderLayout.CENTER);
    add(summary, BorderLayout.SOUTH);
    list.addListSelectionListener(
        e -> {
          if (!e.getValueIsAdjusting() && !filtering) selectionChanged();
        });
    search
        .getDocument()
        .addDocumentListener(
            new javax.swing.event.DocumentListener() {
              public void insertUpdate(javax.swing.event.DocumentEvent e) {
                filter();
              }

              public void removeUpdate(javax.swing.event.DocumentEvent e) {
                filter();
              }

              public void changedUpdate(javax.swing.event.DocumentEvent e) {
                filter();
              }
            });
    search.getInputMap().put(KeyStroke.getKeyStroke("DOWN"), "browseResults");
    search
        .getActionMap()
        .put(
            "browseResults",
            new AbstractAction() {
              public void actionPerformed(ActionEvent e) {
                if (!model.isEmpty()) {
                  showResults(true);
                  list.requestFocusInWindow();
                }
              }
            });
    search.addActionListener(
        e -> {
          if (!model.isEmpty()) {
            if (collapseOnSelection) commitSelection();
            else {
              list.requestFocusInWindow();
              selectionChanged();
            }
          }
        });
    list.addMouseListener(
        new MouseAdapter() {
          @Override
          public void mouseReleased(MouseEvent e) {
            int index = list.locationToIndex(e.getPoint());
            if (SwingUtilities.isLeftMouseButton(e)
                && index >= 0
                && list.getCellBounds(index, index).contains(e.getPoint())
                && collapseOnSelection) commitSelection();
          }
        });
    list.getInputMap().put(KeyStroke.getKeyStroke("ENTER"), "commitSkinSelection");
    list.getActionMap()
        .put(
            "commitSkinSelection",
            new AbstractAction() {
              public void actionPerformed(ActionEvent e) {
                if (collapseOnSelection) commitSelection();
              }
            });
    AbstractAction close =
        new AbstractAction() {
          public void actionPerformed(ActionEvent e) {
            if (collapseOnSelection) {
              showResults(false);
              search.requestFocusInWindow();
            }
          }
        };
    for (JComponent component : new JComponent[] {search, list}) {
      component.getInputMap().put(KeyStroke.getKeyStroke("ESCAPE"), "closeSkinResults");
      component.getActionMap().put("closeSkinResults", close);
    }
    search.addMouseListener(
        new MouseAdapter() {
          @Override
          public void mousePressed(MouseEvent e) {
            if (collapseOnSelection) showResults(!model.isEmpty());
          }
        });
    filter();
  }

  void enableCollapsedResults() {
    collapseOnSelection = true;
    showResults(false);
  }

  void showResults(boolean visible) {
    results.setVisible(visible);
    revalidate();
    repaint();
    if (getParent() != null) {
      getParent().revalidate();
      getParent().repaint();
    }
  }

  void commitSelection() {
    T value = selected();
    if (value == null) return;
    if (collapseOnSelection) {
      search.setText(value.toString());
      showResults(false);
      summary.setText("Selected: " + value);
    }
    selectionChanged();
  }

  T selected() {
    return list.getSelectedValue();
  }

  void onSelection(Runnable listener) {
    listeners.add(listener);
  }

  void select(T value) {
    list.setSelectedValue(value, true);
  }

  void selectionChanged() {
    T value = selected();
    summary.setText(
        value == null
            ? "No matching results"
            : collapseOnSelection && !results.isVisible()
                ? "Selected: " + value
                : model.size() + " matches  |  Selected: " + value);
    summary.setToolTipText(value == null ? null : value.toString());
    for (Runnable listener : listeners) listener.run();
  }

  void filter() {
    T old = selected();
    filtering = true;
    String query = search.getText().trim().toLowerCase(java.util.Locale.ROOT);
    String[] words = query.isEmpty() ? new String[0] : query.split("\\s+");
    model.clear();
    for (T value : values) {
      String name = value.toString().toLowerCase(java.util.Locale.ROOT);
      boolean match = true;
      for (String word : words)
        if (!name.contains(word)) {
          match = false;
          break;
        }
      if (match) model.addElement(value);
    }
    if (old != null && model.contains(old)) list.setSelectedValue(old, true);
    else if (!model.isEmpty()) list.setSelectedIndex(0);
    if (!model.isEmpty()) list.ensureIndexIsVisible(list.getSelectedIndex());
    filtering = false;
    selectionChanged();
    if (collapseOnSelection) showResults(!model.isEmpty());
  }
}
