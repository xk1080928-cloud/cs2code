package blahblah;

import blahblah.hGui.*;
import java.awt.*;
import java.awt.event.*;
import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import javax.swing.*;

/** Market Home Feeds: focused feature implementation. */
final class MarketHomeFeeds {
  private final hGui app;

  MarketHomeFeeds(hGui app) {
    this.app = app;
  }

  int nextHomeSoldDelay() {
    return java.util.concurrent.ThreadLocalRandom.current()
        .nextInt(hGui.MARKET_HOME_SOLD_MIN_INTERVAL, hGui.MARKET_HOME_SOLD_MAX_INTERVAL + 1);
  }

  void repaintHomeFeedsForArtwork(String key) {
    for (MarketHomeUnboxFeed feed : app.activeHomeArtworkFeeds) {
      if (feed.isShowing() && feed.entries.stream().anyMatch(entry -> entry.imageKey.equals(key)))
        feed.repaint();
    }
  }

  int nextHomeUnboxDelay() {
    return java.util.concurrent.ThreadLocalRandom.current()
        .nextInt(hGui.MARKET_HOME_UNBOX_MIN_INTERVAL, hGui.MARKET_HOME_UNBOX_MAX_INTERVAL + 1);
  }

  List<String> snapshotHomeMarketSkinKeys() {
    // Only inspect bucket headers, not every listing. Used on the EDT at startup/occasional
    // refresh.
    List<String> keys = new ArrayList<>();
    for (Map.Entry<String, ArrayList<MarketListing>> entry : app.globalMarketListings.entrySet())
      if (entry.getValue() != null && !entry.getValue().isEmpty()) keys.add(entry.getKey());
    return keys;
  }

  HomeUnboxEntry rollHomeMarketSale(List<String> keys, boolean loadArtwork) {
    if (keys.isEmpty()) return null;
    java.util.List<String> containers = new ArrayList<>();
    for (String key : keys)
      if (app.exchangeStockService.exchangeContainer(key) != null) containers.add(key);
    List<String> pool = !containers.isEmpty() && hGui.random.nextDouble() < .20 ? containers : keys;
    MarketListing chosen = null;
    double cumulative = 0;
    for (int attempt = 0; attempt < 32; attempt++) {
      List<MarketListing> listings =
          app.globalMarketListings.get(pool.get(hGui.random.nextInt(pool.size())));
      if (listings == null || listings.isEmpty()) continue;
      MarketListing listing = listings.get(hGui.random.nextInt(listings.size()));
      if (listing == null
          || listing.item == null
          || listing.item.name == null
          || !Double.isFinite(listing.getPrice())
          || listing.getPrice() <= 0) continue;
      double weight =
          app.salesSimulationService.getSimulatedSalesPerMinute(
              listing.item.rarity, listing.getPrice(), listing.item.isStattrak);
      cumulative += weight;
      if (hGui.random.nextDouble() * cumulative < weight) chosen = listing;
    }
    if (chosen == null) return null;
    SaleRecord sale = app.salesSimulationService.createSaleRecordFromListing(chosen, null, null);
    if (sale == null) return null;
    String skin = app.artworkService.canonicalArtworkName(sale.skinName);
    CaseType container = app.exchangeStockService.exchangeContainer(chosen.item.name);
    Image image =
        loadArtwork
            ? (container == null
                ? getHomeUnboxArtwork(skin, sale.condition)
                : app.containerArtwork.get("case-selector-" + container.id))
            : null;
    return new HomeUnboxEntry(
        sale,
        app.artworkService.getSkinArtworkKey(skin, sale.condition),
        container == null ? app.itemMetadataService.getSkinRarity(skin) : "Container",
        image);
  }

  Map<String, Double> homeUnboxUniformPool(String[] names) {
    Map<String, Double> pool = new LinkedHashMap<>();
    if (names != null)
      for (String name : names)
        if (name != null && !name.isBlank())
          pool.put(app.catalogParsingService.stripSouvenirPrefix(name), 1.0);
    return pool;
  }

  List<List<HomeUnboxSource>> buildHomeUnboxSources() {
    List<HomeUnboxSource> cases = new ArrayList<>(),
        souvenirs = new ArrayList<>(),
        armoury = new ArrayList<>();
    String[] rarities = {"Consumer", "Industrial", "Milspec", "Restricted", "Classified", "Covert"};
    double[] caseWeights = {0, 0, .7992, .1598, .032, .0064};
    for (CaseType ct : CaseType.values()) {
      if (ct.isTerminal
          || (!ct.isSouvenir && !ct.crateName.toLowerCase(java.util.Locale.ROOT).contains("case")))
        continue;
      boolean[] available = new boolean[rarities.length];
      for (int i = 0; i < rarities.length; i++)
        available[i] = !ct.regularDropNames.getOrDefault(rarities[i], List.of()).isEmpty();
      double[] weights =
          ct.isSouvenir ? CaseRollService.calculateCollectionTierOdds(available) : caseWeights;
      List<HomeUnboxTier> tiers = new ArrayList<>();
      for (int i = 0; i < rarities.length; i++)
        if (available[i] && weights[i] > 0) {
          Map<String, Double> pool =
              app.marketHomeFeeds.homeUnboxUniformPool(
                  ct.regularDropNames.get(rarities[i]).toArray(new String[0]));
          tiers.add(new HomeUnboxTier(rarities[i], weights[i], pool));
        }
      if (!ct.isSouvenir) {
        Map<String, Double> gold = app.goldTradeUpService.getCaseUnboxingGoldOutcomeOdds(ct, null);
        if (!gold.isEmpty()) tiers.add(new HomeUnboxTier("Gold", .0026, gold));
      }
      if (!tiers.isEmpty())
        (ct.isSouvenir ? souvenirs : cases)
            .add(
                new HomeUnboxSource(
                    ct.isSouvenir ? "Souvenir package" : "Case", ct.crateName, tiers));
    }
    if (hGui.ARMOURY_COLLECTIONS != null)
      for (ArmouryCollection col : hGui.ARMOURY_COLLECTIONS) {
        String[][] names =
            col.isAgents
                ? new String[][] {
                  col.milspecNames, col.restrictedNames, col.classifiedNames, col.covertNames
                }
                : new String[][] {
                  col.consumerNames,
                  col.industrialNames,
                  col.milspecNames,
                  col.restrictedNames,
                  col.classifiedNames,
                  col.covertNames
                };
        String[] tiersNames =
            col.isAgents
                ? new String[] {"Distinguished", "Exceptional", "Superior", "Master"}
                : rarities;
        boolean[] available = new boolean[names.length];
        for (int i = 0; i < names.length; i++)
          available[i] = names[i] != null && names[i].length > 0;
        double[] weights = CaseRollService.calculateCollectionTierOdds(available);
        List<HomeUnboxTier> tiers = new ArrayList<>();
        for (int i = 0; i < names.length; i++)
          if (available[i])
            tiers.add(
                new HomeUnboxTier(
                    tiersNames[i], weights[i], app.marketHomeFeeds.homeUnboxUniformPool(names[i])));
        if (!tiers.isEmpty()) armoury.add(new HomeUnboxSource("Armoury", col.name, tiers));
      }
    List<List<HomeUnboxSource>> groups = new ArrayList<>();
    for (List<HomeUnboxSource> group : List.of(cases, souvenirs, armoury))
      if (!group.isEmpty()) groups.add(List.copyOf(group));
    return List.copyOf(groups);
  }

  Image getHomeUnboxArtwork(String skin) {
    return app.artworkService.getRemoteSkinArtwork(skin, null, false);
  }

  Image getHomeUnboxArtwork(String skin, String condition) {
    return app.artworkService.getRemoteSkinArtwork(
        app.artworkService.canonicalArtworkName(skin), condition, false);
  }

  HomeUnboxEntry rollHomeUnboxSource(HomeUnboxSource source, boolean loadArtwork) {
    double total = source.tiers.stream().mapToDouble(t -> t.weight).sum();
    double roll = hGui.random.nextDouble() * total;
    HomeUnboxTier tier = source.tiers.get(source.tiers.size() - 1);
    for (HomeUnboxTier candidate : source.tiers) {
      roll -= candidate.weight;
      if (roll < 0) {
        tier = candidate;
        break;
      }
    }
    String skin = app.goldTradeUpService.sampleTradeUpOdds(tier.skins);
    String rarity =
        "Gold".equals(tier.rarity)
            ? app.goldTradeUpService.getGoldTradeUpOutputRarity(skin)
            : tier.rarity;
    boolean noFloat = app.floatRules.hasNoFloatWear(skin);
    FloatRange bounds = app.catalogParsingService.findFloatRange(skin);
    double min = bounds == null || bounds.min == null ? 0 : bounds.min;
    double max = bounds == null || bounds.max == null ? 1 : bounds.max;
    double itemFloat =
        noFloat ? 0 : Math.max(min, Math.min(max, min + hGui.random.nextDouble() * (max - min)));
    String condition = noFloat ? "Normal" : app.floatRules.getConditionForFloat(skin, itemFloat);
    boolean statTrak =
        "Case".equals(source.kind)
            && app.itemMetadataService.supportsStatTrak(skin)
            && hGui.random.nextInt(10) == 0;
    int pattern = hGui.random.nextInt(1000);
    String blueGem = app.itemPriceService.getBlueGemTier(skin, pattern);
    double price =
        app.itemPriceService.getBasePrice(skin)
            * app.priceModifiers.getConditionPriceMultiplier(skin, condition);
    if (statTrak) price *= "Knife".equals(rarity) ? 1.15 : 2.0;
    if (blueGem != null)
      price = app.itemPriceService.applyBlueGemMultiplier(skin, pattern, blueGem, price);
    if (!Double.isFinite(price) || price <= 0) price = .01;
    String displayName =
        ("Souvenir package".equals(source.kind) ? "Souvenir " : statTrak ? "StatTrak " : "")
            + skin
            + (blueGem == null ? "" : " (" + blueGem + ")");
    SaleRecord record =
        new SaleRecord(
            displayName,
            app.coreUtilities.money(price).doubleValue(),
            condition,
            itemFloat,
            blueGem);
    record.marketplaceName = source.kind + " · " + source.name;
    Image image = loadArtwork ? app.marketHomeFeeds.getHomeUnboxArtwork(skin, condition) : null;
    return new HomeUnboxEntry(
        record, app.artworkService.getSkinArtworkKey(skin, condition), rarity, image);
  }

  HomeUnboxEntry rollHomeUnbox(List<List<HomeUnboxSource>> sources, boolean loadArtwork) {
    if (sources.isEmpty()) return null;
    List<HomeUnboxSource> group = sources.get(hGui.random.nextInt(sources.size()));
    return app.marketHomeFeeds.rollHomeUnboxSource(
        group.get(hGui.random.nextInt(group.size())), loadArtwork);
  }
}
