package blahblah;

import blahblah.hGui.*;
import java.awt.*;
import java.io.Serializable;
import java.util.*;
import java.util.List;
import javax.swing.*;

/** Persistent 100-XP levels, one automatically delivered three-item package per earned level. */
final class CarePackages {
  private final hGui app;
  private javax.swing.Timer presentation;

  CarePackages(hGui app) {
    this.app = app;
  }

  static final class SavedMission implements Serializable {
    private static final long serialVersionUID = 1L;
    String id, name, description, type;
    int goal, current, stars;
    boolean completed;
  }

  static final class State implements Serializable {
    private static final long serialVersionUID = 1L;
    long xp, packages;
    Set<String> awarded = new HashSet<>();
    LinkedHashSet<String> pending = new LinkedHashSet<>();
    List<GameState.SerializableInventoryItem> last = new ArrayList<>();
    List<SavedMission> missions = new ArrayList<>();
    Map<String, Number> progress = new HashMap<>();
  }

  State state() {
    if (app.inventoryToolsService.state.care == null)
      app.inventoryToolsService.state.care = new State();
    return app.inventoryToolsService.state.care;
  }

  int level() {
    return (int) Math.min(Integer.MAX_VALUE, 1 + state().xp / 100);
  }

  int xpReward(Mission m) {
    return Math.max(10, m.starReward * 25);
  }

  void award(Mission m) {
    if (!state().awarded.add(m.id)) return;
    long before = state().xp / 100;
    state().xp += xpReward(m);
    int earned = (int) (state().xp / 100 - before);
    for (int n = 0; n < earned; n++) grant();
    if (earned > 0) queuePresentation();
    if (app.storeScreen.sections != null && app.storeScreen.sections.getSelectedIndex() == 0)
      app.storeScreen.refreshHome();
    app.saveService.saveProgressAsync();
  }

  InventoryItem rollSkin() {
    LinkedHashMap<String, List<String[]>> collections = new LinkedHashMap<>();
    for (String[] r : CareCollectionsData.ROWS)
      collections.computeIfAbsent(r[0], k -> new ArrayList<>()).add(r);
    List<List<String[]>> pools = new ArrayList<>(collections.values());
    List<String[]> pool = pools.get(hGui.random.nextInt(pools.size()));
    String[] rarities = {"Consumer", "Industrial", "Milspec", "Restricted", "Classified"};
    boolean[] present = new boolean[5];
    for (String[] r : pool)
      for (int i = 0; i < 5; i++) if (rarities[i].equals(r[2])) present[i] = true;
    double[] odds = CaseRollService.calculateCollectionTierOdds(present);
    double roll = hGui.random.nextDouble();
    int tier = 4;
    for (int i = 0; i < 5; i++) {
      roll -= odds[i];
      if (roll < 0) {
        tier = i;
        break;
      }
    }
    List<String[]> eligible = new ArrayList<>();
    for (String[] r : pool) if (rarities[tier].equals(r[2])) eligible.add(r);
    String[] r = eligible.get(hGui.random.nextInt(eligible.size()));
    double low = Double.parseDouble(r[4]), high = Double.parseDouble(r[5]);
    double f = low + hGui.random.nextDouble() * (high - low);
    String wear = app.floatRules.getConditionForFloat(r[1], f);
    double price =
        app.itemPriceService.getBasePrice(r[1])
            * app.priceModifiers.getConditionPriceMultiplier(r[1], wear);
    InventoryItem item =
        new InventoryItem(
            null,
            r[1],
            wear,
            r[2],
            app.coreUtilities.money(Math.max(.01, price)),
            f,
            false,
            hGui.random.nextInt(1000),
            null,
            Math.max(.01, price));
    item.collection = r[0];
    return item;
  }

  private void grant() {
    List<CaseType> cases = new ArrayList<>();
    for (CaseType ct : CaseType.values())
      if (!ct.isSouvenir
          && !ct.isTerminal
          && ct.catalogCrateName().toLowerCase(Locale.ROOT).contains("case")) cases.add(ct);
    if (cases.isEmpty())
      throw new IllegalStateException("No case catalog is available for Care Package.");
    CaseType ct = cases.get(hGui.random.nextInt(cases.size()));
    OwnedSupply box = new OwnedSupply(ct, false, 0);
    List<InventoryItem> skins = List.of(rollSkin(), rollSkin());
    app.ownedSupplies.add(box);
    app.globalSupply.created(ct, 1);
    app.itemRevealService.received(box);
    state().pending.add("supply:" + box.id);
    state().last.clear();
    state().last.add(InventoryItemCodec.encode(app.containerMarketService.item(box)));
    for (InventoryItem skin : skins) {
      app.ownershipHistoryService.addItemHistory(
          skin, System.currentTimeMillis(), "Care Package", "Level-up reward", "YOU");
      app.inventoryList.add(skin);
      app.coreUtilities.addInventoryValue(skin.price.doubleValue());
      app.globalSupply.created(skin);
      app.itemRevealService.received(skin);
      state().pending.add(skin.itemId);
      state().last.add(InventoryItemCodec.encode(skin));
    }
    state().packages++;
    app.containerSelectionScreen.invalidateCs2Inventory();
  }

  void queuePresentation() {
    if (presentation != null && presentation.isRunning()) return;
    presentation =
        new javax.swing.Timer(
            220,
            e -> {
              if (!app.isShowing()
                  || app.isAnimating
                  || app.armouryAnimating
                  || app.itemRevealService.showing
                  || app.itemRevealService.tradeUpPending) return;
              List<InventoryItem> items = new ArrayList<>();
              for (String id : state().pending) {
                for (InventoryItem i : app.inventoryList) if (id.equals(i.itemId)) items.add(i);
                for (OwnedSupply s : app.ownedSupplies)
                  if (id.equals("supply:" + s.id)) items.add(app.containerMarketService.item(s));
              }
              presentation.stop();
              if (items.isEmpty()) {
                state().pending.clear();
                return;
              }
              app.storeScreen.open("HOME");
              final long version = app.worldVersion;
              javax.swing.Timer reveal =
                  new javax.swing.Timer(
                      PageTransitions.DURATION_MS + 40,
                      x -> {
                        if (version == app.worldVersion)
                          app.itemRevealService.show(items, true, "Care Package");
                        else queuePresentation();
                      });
              reveal.setRepeats(false);
              reveal.start();
            });
    presentation.setCoalesce(true);
    presentation.start();
  }

  void captureMissions() {
    state().missions.clear();
    for (Mission m : app.activeMissions) {
      SavedMission s = new SavedMission();
      s.id = m.id;
      s.name = m.name;
      s.description = m.description;
      s.type = m.type;
      s.goal = m.goal;
      s.current = m.current;
      s.stars = m.starReward;
      s.completed = m.completed;
      state().missions.add(s);
    }
    for (java.lang.reflect.Field f : MissionProgress.class.getDeclaredFields())
      try {
        if (!java.lang.reflect.Modifier.isStatic(f.getModifiers())) {
          f.setAccessible(true);
          state().progress.put(f.getName(), (Number) f.get(app.missionProgress));
        }
      } catch (IllegalAccessException ex) {
        throw new IllegalStateException(ex);
      }
  }

  boolean restoreMissions() {
    if (state().missions.isEmpty()) return false;
    app.activeMissions.clear();
    for (SavedMission s : state().missions) {
      Mission m = new Mission(s.id, s.name, s.description, s.type, s.goal, s.stars);
      m.current = s.current;
      m.completed = s.completed;
      app.activeMissions.add(m);
    }
    for (java.lang.reflect.Field f : MissionProgress.class.getDeclaredFields())
      try {
        Number n = state().progress.get(f.getName());
        if (n != null) {
          f.setAccessible(true);
          if (f.getType() == int.class) f.setInt(app.missionProgress, n.intValue());
          else if (f.getType() == double.class) f.setDouble(app.missionProgress, n.doubleValue());
        }
      } catch (IllegalAccessException ex) {
        throw new IllegalStateException(ex);
      }
    return true;
  }

  JPanel home() {
    JPanel root =
        new JPanel(new BorderLayout()) {
          protected void paintComponent(Graphics graphics) {
            super.paintComponent(graphics);
            Graphics2D g = (Graphics2D) graphics.create();
            g.setPaint(
                new GradientPaint(
                    0, 0, new Color(55, 61, 63), getWidth(), getHeight(), new Color(19, 25, 30)));
            g.fillRect(0, 0, getWidth(), getHeight());
            g.dispose();
          }
        };
    root.setName("storeHome");
    root.setBorder(BorderFactory.createEmptyBorder(38, 55, 32, 55));
    JPanel banner = new JPanel(new BorderLayout(28, 0));
    banner.setBackground(new Color(29, 35, 40));
    banner.setBorder(
        BorderFactory.createCompoundBorder(
            BorderFactory.createLineBorder(new Color(74, 81, 84), 1),
            BorderFactory.createEmptyBorder(22, 24, 24, 24)));
    JPanel cards = new JPanel(new GridLayout(1, 3, 12, 0));
    cards.setOpaque(false);
    for (int n = 0; n < 3; n++) {
      JPanel card = app.cs2Screens.cs2Glass(new BorderLayout(4, 8));
      card.setOpaque(true);
      card.setBackground(new Color(20, 25, 30));
      card.setBorder(
          BorderFactory.createCompoundBorder(
              BorderFactory.createLineBorder(new Color(76, 80, 83), 1),
              BorderFactory.createEmptyBorder(12, 8, 12, 8)));
      if (state().last.size() == 3) {
        InventoryItem i = InventoryItemCodec.decode(state().last.get(n));
        JPanel tile = app.cs2Screens.createCs2SkinCard(i, () -> app.cs2Screens.showCs2Inspect(i));
        card.add(tile);
      } else {
        JLabel unknown = app.cs2Screens.cs2Text("?", 70, new Color(231, 160, 49));
        unknown.setHorizontalAlignment(SwingConstants.CENTER);
        card.add(unknown);
      }
      JLabel type =
          app.cs2Screens.cs2Text(n == 0 ? "CASE" : "COLLECTION SKIN", 12, new Color(235, 216, 181));
      type.setHorizontalAlignment(SwingConstants.CENTER);
      card.add(type, BorderLayout.SOUTH);
      cards.add(card);
    }
    cards.setPreferredSize(new Dimension(660, 270));
    banner.add(cards);
    JPanel detail = app.cs2Screens.cs2Glass(new BorderLayout(0, 18));
    detail.setOpaque(true);
    detail.setBackground(new Color(114, 67, 15));
    detail.setBorder(BorderFactory.createEmptyBorder(18, 18, 18, 18));
    detail.setPreferredSize(new Dimension(330, 270));
    JLabel title = app.cs2Screens.cs2Text("Care Package", 29, Color.WHITE);
    detail.add(title, BorderLayout.NORTH);
    JPanel info = app.cs2Screens.cs2Glass(new GridLayout(0, 1, 0, 12));
    info.add(app.cs2Screens.cs2Text("EARN AN XP LEVEL", 20, new Color(255, 199, 90)));
    info.add(app.cs2Screens.cs2Text("Level " + level() + "  •  100 XP per level", 16, Color.WHITE));
    info.add(
        app.cs2Screens.cs2Text("1 case + 2 gun skins • every level", 14, new Color(237, 218, 187)));
    info.add(
        app.cs2Screens.cs2Text(
            "Rewards are delivered automatically.", 13, new Color(222, 208, 183)));
    detail.add(info);
    JProgressBar bar = new JProgressBar(0, 100);
    bar.setName("careXpProgress");
    bar.setValue((int) (state().xp % 100));
    bar.setStringPainted(true);
    bar.setString((state().xp % 100) + " / 100 XP");
    bar.setForeground(new Color(246, 173, 52));
    bar.setBackground(new Color(50, 40, 26));
    detail.add(bar, BorderLayout.SOUTH);
    banner.add(detail, BorderLayout.EAST);
    JPanel top = app.cs2Screens.cs2Glass(new BorderLayout(0, 18));
    top.add(banner);
    JLabel subtitle =
        app.cs2Screens.cs2Text(
            "Complete missions for Stars + XP.  Packages earned: " + state().packages,
            16,
            Color.WHITE);
    top.add(subtitle, BorderLayout.SOUTH);
    root.add(top, BorderLayout.NORTH);
    JPanel lower = app.cs2Screens.cs2Glass(new BorderLayout());
    lower.setBorder(BorderFactory.createEmptyBorder(28, 0, 0, 0));
    lower.add(
        app.cs2Screens.cs2Text(
            "ACHROMA  •  HARLEQUIN  •  ASCENT  •  BOREAL  •  RADIANT",
            15,
            new Color(194, 211, 214)),
        BorderLayout.NORTH);
    root.add(lower);
    return root;
  }
}
