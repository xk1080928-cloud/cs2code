package blahblah;

import blahblah.hGui.*;
import java.awt.*;
import java.awt.event.*;
import java.util.Map;
import javax.swing.*;

/** Loadout Screen: focused feature implementation. */
final class LoadoutScreen {
  private final hGui app;

  LoadoutScreen(hGui app) {
    this.app = app;
  }

  void refreshMarketTab() {
    app.marketplacePriceLabels.clear();
    app.marketTabPanel.removeAll();
    app.marketTabPanel.setBackground(Theme.BG_DARK);
    app.itemMetadataService.normalizeUnsupportedStatTrakListings();
    app.itemMetadataService.removeImpossibleWearListings();
    app.marketPriceChanges.ensureMinimumListings();

    if (app.globalMarketListings.isEmpty() && !app.globalSupply.ready()) {
      app.marketGeneration.generateGlobalMarketListings();
    }

    JTabbedPane marketSections = new JTabbedPane();
    app.marketplaceTabs.configure(marketSections);
    marketSections.setBackground(Theme.BG_DARK);
    marketSections.setForeground(Theme.TEXT);

    JTabbedPane portfolioTabs = new JTabbedPane();
    portfolioTabs.setBackground(Theme.BG_DARK);
    portfolioTabs.setForeground(Theme.TEXT);
    portfolioTabs.addTab("My Listings", app.marketGroupingService.createMyListingsPanel());
    portfolioTabs.addTab("Purchases", app.playerPurchasesScreen.createPlayerPurchasesPanel());

    app.exchangeHostSections = marketSections;
    app.exchangeOpenSites.clear();
    app.exchangeSiteRefresh.clear();
    marketSections.addTab("Browse", app.marketBrowserScreen.createMarketplaceBrowserPanel());
    marketSections.addTab("Marketplaces", app.marketplaceDirectory.createDirectory());
    marketSections.addTab("Portfolio", portfolioTabs);
    // Containers are browsed within Browse via the Cases dropdown, not in a separate tab/window.

    app.marketTabPanel.add(marketSections, BorderLayout.CENTER);
    app.marketTabPanel.revalidate();
    app.marketTabPanel.repaint();
  }

  boolean isItemEquipped(InventoryItem item) {
    if (item == null) return false;
    return app.tLoadout.containsValue(item) || app.ctLoadout.containsValue(item);
  }

  boolean arrayContains(String[] values, String target) {
    if (values == null || target == null) return false;
    for (String value : values) {
      if (target.equals(value)) return true;
    }
    return false;
  }

  boolean isUsableOnSide(InventoryItem item, boolean isTSide) {
    if (item == null) return false;
    if (app.cs2EquipmentScreens.isDefaultWeaponItem(item)) {
      if (item.name.startsWith("CT ")) return !isTSide;
      if (item.name.startsWith("T ")) return isTSide;
    }
    String cleanName = item.name.replace("StatTrak ", "").trim();
    String rarity = item.rarity != null ? item.rarity.replace("StatTrak ", "") : "";
    if (app.itemMetadataService.isAgentSkin(cleanName)
        || "Knife".equals(rarity)
        || "Gloves".equals(rarity)) return true;
    String weaponType = app.marketFilterControls.extractWeaponType(cleanName);
    if (isTSide) {
      return app.loadoutScreen.arrayContains(hGui.T_SLOTS_PISTOL, weaponType)
          || app.loadoutScreen.arrayContains(hGui.T_SLOTS_OTHER, weaponType)
          || app.loadoutScreen.arrayContains(hGui.T_SLOTS_SMG, weaponType)
          || app.loadoutScreen.arrayContains(hGui.T_SLOTS_HEAVY, weaponType)
          || app.loadoutScreen.arrayContains(hGui.T_SLOTS_RIFLE, weaponType);
    }
    return app.loadoutScreen.arrayContains(hGui.CT_SLOTS_PISTOL, weaponType)
        || app.loadoutScreen.arrayContains(hGui.CT_SLOTS_OTHER, weaponType)
        || app.loadoutScreen.arrayContains(hGui.CT_SLOTS_SMG, weaponType)
        || app.loadoutScreen.arrayContains(hGui.CT_SLOTS_HEAVY, weaponType)
        || app.loadoutScreen.arrayContains(hGui.CT_SLOTS_RIFLE, weaponType);
  }

  boolean passesSideFilter(InventoryItem item, String sideFilter) {
    if ("Any Side".equals(sideFilter)) return true;
    boolean tUsable = app.loadoutScreen.isUsableOnSide(item, true);
    boolean ctUsable = app.loadoutScreen.isUsableOnSide(item, false);
    if ("T Side".equals(sideFilter)) return tUsable;
    if ("CT Side".equals(sideFilter)) return ctUsable;
    if ("Both Sides".equals(sideFilter)) return tUsable && ctUsable;
    return true;
  }

  boolean isTradeUpEligibleItem(InventoryItem item) {
    if (app.cs2EquipmentScreens.isDefaultWeaponItem(item)) return false;
    if (item == null || app.itemMetadataService.isAgentSkin(item.name)) return false;
    if (item.rarity == null) return false;
    if (item.rarity.contains("Covert"))
      return app.goldTradeUpService.getGoldTradeUpSource(item) != null;
    return !item.rarity.contains("Knife") && !item.rarity.contains("Glove");
  }

  boolean shouldShowLoadoutSlot(InventoryItem equipped) {
    if ("Equipped Only".equals(app.loadoutVisibilityFilter)) return equipped != null;
    if ("Empty Only".equals(app.loadoutVisibilityFilter)) return equipped == null;
    return true;
  }

  void refreshLoadoutTab() {
    if (app.cs2ShellEnabled) {
      app.cs2EquipmentScreens.refreshCs2Loadout();
      return;
    }

    if (app.loadoutScrollPaneT != null)
      app.loadoutScrollYT = app.loadoutScrollPaneT.getVerticalScrollBar().getValue();
    if (app.loadoutScrollPaneCT != null)
      app.loadoutScrollYCT = app.loadoutScrollPaneCT.getVerticalScrollBar().getValue();
    app.loadoutTabPanel.removeAll();
    app.loadoutTabPanel.setLayout(new BorderLayout());
    app.loadoutTabPanel.setBackground(Theme.BG_DARK);

    JPanel headerBar = new JPanel(new BorderLayout());
    headerBar.setBackground(new Color(18, 18, 30));
    headerBar.setBorder(
        BorderFactory.createCompoundBorder(
            BorderFactory.createMatteBorder(0, 0, 2, 0, Theme.ACCENT_T),
            BorderFactory.createEmptyBorder(10, 18, 10, 18)));

    JLabel headerLbl = new JLabel("  LOADOUT", SwingConstants.LEFT);
    headerLbl.setFont(new Font("Consolas", Font.BOLD, 20));
    headerLbl.setForeground(Theme.ACCENT_T);
    headerLbl.setOpaque(false);
    headerBar.add(headerLbl, BorderLayout.WEST);

    JPanel filterPanel = new JPanel(new FlowLayout(FlowLayout.RIGHT, 8, 0));
    filterPanel.setOpaque(false);
    JLabel filterLbl = new JLabel("Show:");
    filterLbl.setFont(new Font("Consolas", Font.PLAIN, 12));
    filterLbl.setForeground(Theme.TEXT_DIM);
    JComboBox<String> loadoutFilterBox =
        new JComboBox<>(new String[] {"All Slots", "Equipped Only", "Empty Only"});
    app.uiWidgets.styleComboBox(loadoutFilterBox);
    loadoutFilterBox.setSelectedItem(app.loadoutVisibilityFilter);
    loadoutFilterBox.addActionListener(
        ev -> {
          app.loadoutVisibilityFilter = (String) loadoutFilterBox.getSelectedItem();
          app.loadoutScreen.refreshLoadoutTab();
        });
    filterPanel.add(filterLbl);
    filterPanel.add(loadoutFilterBox);
    headerBar.add(filterPanel, BorderLayout.EAST);
    app.loadoutTabPanel.add(headerBar, BorderLayout.NORTH);

    JTabbedPane sides = new JTabbedPane(JTabbedPane.TOP);
    sides.setBackground(Theme.BG_DARK);
    sides.setForeground(new Color(230, 230, 235));
    sides.setFont(new Font("Consolas", Font.BOLD, 14));
    sides.addTab("  TERRORIST  ", app.loadoutScreen.buildLoadoutSidePanel(true));
    sides.addTab("  COUNTER-TERRORIST  ", app.loadoutScreen.buildLoadoutSidePanel(false));
    sides.setSelectedIndex(app.loadoutSelectedSide);
    sides.addChangeListener(ev -> app.loadoutSelectedSide = sides.getSelectedIndex());
    app.loadoutTabPanel.add(sides, BorderLayout.CENTER);

    app.loadoutTabPanel.revalidate();
    app.loadoutTabPanel.repaint();
  }

  JPanel buildLoadoutSidePanel(boolean isTSide) {
    Color TEXT = Theme.TEXT;

    JPanel root = new JPanel(new BorderLayout(0, 0));
    root.setBackground(Theme.BG_DARK);

    JPanel agentPanel = new JPanel(new BorderLayout());
    agentPanel.setBackground(Theme.BG_PANEL);
    agentPanel.setPreferredSize(new Dimension(160, 0));
    agentPanel.setBorder(
        BorderFactory.createCompoundBorder(
            BorderFactory.createMatteBorder(0, 0, 0, 2, Theme.BORDER),
            BorderFactory.createEmptyBorder(12, 10, 12, 10)));

    Map<String, InventoryItem> loadout = isTSide ? app.tLoadout : app.ctLoadout;
    String agentSlot = isTSide ? hGui.AGENT_SLOT_T : hGui.AGENT_SLOT_CT;
    InventoryItem equippedAgent = loadout.get(agentSlot);
    JPanel agentCard =
        app.loadoutCards.buildAgentCard(
            agentSlot, equippedAgent, Theme.BG_CARD, Theme.ACCENT_T, TEXT, loadout, isTSide);
    agentPanel.add(agentCard, BorderLayout.NORTH);
    root.add(agentPanel, BorderLayout.WEST);

    String[][] sectionTitles;
    String[][][] sectionSlots;
    if (isTSide) {
      sectionTitles =
          new String[][] {{"STARTING PISTOL"}, {"PISTOLS"}, {"SMGs"}, {"HEAVY"}, {"RIFLES"}};
      sectionSlots =
          new String[][][] {
            {hGui.T_SLOTS_PISTOL},
            {hGui.T_SLOTS_OTHER},
            {hGui.T_SLOTS_SMG},
            {hGui.T_SLOTS_HEAVY},
            {hGui.T_SLOTS_RIFLE}
          };
    } else {
      sectionTitles =
          new String[][] {{"STARTING PISTOL"}, {"PISTOLS"}, {"SMGs"}, {"HEAVY"}, {"RIFLES"}};
      sectionSlots =
          new String[][][] {
            {hGui.CT_SLOTS_PISTOL},
            {hGui.CT_SLOTS_OTHER},
            {hGui.CT_SLOTS_SMG},
            {hGui.CT_SLOTS_HEAVY},
            {hGui.CT_SLOTS_RIFLE}
          };
    }

    ScrollablePanel weaponArea = new ScrollablePanel();
    weaponArea.setLayout(new BoxLayout(weaponArea, BoxLayout.Y_AXIS));
    weaponArea.setBackground(Theme.BG_DARK);

    weaponArea.setBorder(BorderFactory.createEmptyBorder(8, 8, 16, 20));

    int totalSections = sectionTitles.length + 2;
    for (int si = 0; si < totalSections; si++) {
      boolean isKnifeSection = (si == totalSections - 2);
      boolean isGlovesSection = (si == totalSections - 1);
      String sectionTitle =
          isKnifeSection ? "KNIFE" : isGlovesSection ? "GLOVES" : sectionTitles[si][0];

      JPanel secHdr = new JPanel(new FlowLayout(FlowLayout.LEFT, 4, 2));
      secHdr.setBackground(Theme.BG_DARK);
      secHdr.setMaximumSize(new Dimension(Integer.MAX_VALUE, 26));
      JLabel secLbl = new JLabel("\u25BC  " + sectionTitle);
      secLbl.setFont(new Font("Consolas", Font.BOLD, 10));
      secLbl.setForeground(Theme.ACCENT_T);
      secHdr.add(secLbl);

      JPanel cardsRow = new JPanel(new WrapLayout(FlowLayout.LEFT, 6, 4));
      cardsRow.setBackground(Theme.BG_DARK);
      if (isKnifeSection) {

        String knifeKey = isTSide ? "Knife_T" : "Knife_CT";
        InventoryItem equippedKnife = loadout.get(knifeKey);
        if (app.loadoutScreen.shouldShowLoadoutSlot(equippedKnife)) {
          JPanel knifeCard =
              app.loadoutCards.buildWeaponCard(
                  knifeKey, equippedKnife, Theme.BG_CARD, Theme.ACCENT_T, TEXT, loadout, isTSide);
          cardsRow.add(knifeCard);
        }
      } else if (isGlovesSection) {

        String glovesKey = isTSide ? "Gloves_T" : "Gloves_CT";
        InventoryItem equippedGloves = loadout.get(glovesKey);
        if (app.loadoutScreen.shouldShowLoadoutSlot(equippedGloves)) {
          JPanel glovesCard =
              app.loadoutCards.buildWeaponCard(
                  glovesKey, equippedGloves, Theme.BG_CARD, Theme.ACCENT_T, TEXT, loadout, isTSide);
          cardsRow.add(glovesCard);
        }
      } else {
        for (String slot : sectionSlots[si][0]) {
          InventoryItem equipped = loadout.get(slot);
          if (app.loadoutScreen.shouldShowLoadoutSlot(equipped)) {
            JPanel card =
                app.loadoutCards.buildWeaponCard(
                    slot, equipped, Theme.BG_CARD, Theme.ACCENT_T, TEXT, loadout, isTSide);
            cardsRow.add(card);
          }
        }
      }
      if (cardsRow.getComponentCount() > 0) {
        weaponArea.add(secHdr);
        weaponArea.add(cardsRow);
        weaponArea.add(Box.createRigidArea(new Dimension(0, 2)));
      }
    }

    JScrollPane scrollPane =
        new JScrollPane(
            weaponArea,
            JScrollPane.VERTICAL_SCROLLBAR_AS_NEEDED,
            JScrollPane.HORIZONTAL_SCROLLBAR_NEVER);
    if (isTSide) app.loadoutScrollPaneT = scrollPane;
    else app.loadoutScrollPaneCT = scrollPane;
    scrollPane.setBorder(null);
    scrollPane.setBackground(Theme.BG_DARK);
    scrollPane.getVerticalScrollBar().setUnitIncrement(16);

    scrollPane
        .getViewport()
        .addComponentListener(
            new java.awt.event.ComponentAdapter() {
              @Override
              public void componentResized(java.awt.event.ComponentEvent e) {
                weaponArea.revalidate();
              }
            });

    final int savedY = isTSide ? app.loadoutScrollYT : app.loadoutScrollYCT;
    if (savedY > 0) {
      final int[] lastMax = {-1};
      final int[] stable = {0};
      javax.swing.Timer t = new javax.swing.Timer(30, null);
      t.addActionListener(
          ev -> {
            int max = scrollPane.getVerticalScrollBar().getMaximum();
            if (max == lastMax[0]) {
              stable[0]++;
            } else {
              lastMax[0] = max;
              stable[0] = 0;
            }
            if (stable[0] >= 2 && max > savedY) {
              t.stop();
              scrollPane.getVerticalScrollBar().setValue(savedY);
            } else if (stable[0] >= 10) {
              t.stop();
              scrollPane.getVerticalScrollBar().setValue(savedY);
            }
          });
      t.start();
    }
    root.add(scrollPane, BorderLayout.CENTER);

    return root;
  }
}
