package blahblah;

import java.awt.*;
import javax.swing.*;

/** Main-menu mission briefing: every objective, progress and reward is visible, not a preview. */
final class MissionBoard {
  private final hGui app;

  MissionBoard(hGui app) {
    this.app = app;
  }

  private JTextArea text(String value, int size, boolean bold, int rows, Color color) {
    JTextArea t = new JTextArea(value);
    t.setLineWrap(true);
    t.setWrapStyleWord(true);
    t.setRows(rows);
    t.setEditable(false);
    t.setFocusable(false);
    t.setOpaque(false);
    t.setBorder(null);
    t.setForeground(color);
    t.setFont(new Font("SansSerif", bold ? Font.BOLD : Font.PLAIN, size));
    return t;
  }

  JPanel build() {
    JPanel board =
        new JPanel(new BorderLayout(0, 10)) {
          protected void paintComponent(Graphics graphics) {
            Graphics2D g = (Graphics2D) graphics.create();
            g.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
            g.setPaint(
                new GradientPaint(
                    0,
                    0,
                    new Color(19, 49, 56, 248),
                    getWidth(),
                    getHeight(),
                    new Color(13, 24, 36, 248)));
            g.fillRoundRect(0, 0, getWidth(), getHeight(), 22, 22);
            g.setColor(new Color(105, 216, 190, 95));
            g.drawRoundRect(0, 0, getWidth() - 1, getHeight() - 1, 22, 22);
            g.setColor(new Color(146, 225, 220, 8));
            for (int x = getWidth() / 2; x < getWidth() + getHeight(); x += 34)
              g.drawLine(x, 0, x - getHeight(), getHeight());
            g.dispose();
          }
        };
    board.setName("cs2HomeMissions");
    board.setOpaque(false);
    board.setBorder(BorderFactory.createEmptyBorder(15, 16, 14, 16));
    JPanel header = app.cs2Screens.cs2Glass(new BorderLayout(12, 5));
    JLabel title = app.cs2Screens.cs2Text("MISSION BRIEFING", 19, Color.WHITE);
    title.setFont(new Font("SansSerif", Font.BOLD, 19));
    header.add(title, BorderLayout.CENTER);
    long completed = app.activeMissions.stream().filter(m -> m.completed).count();
    JLabel total =
        app.cs2Screens.cs2Text(
            completed + " / " + app.activeMissions.size() + " COMPLETE",
            11,
            new Color(133, 229, 193));
    header.add(total, BorderLayout.EAST);
    header.add(
        app.cs2Screens.cs2Text("YOUR OBJECTIVES  /  STARS + XP", 11, new Color(153, 184, 197)),
        BorderLayout.SOUTH);
    board.add(header, BorderLayout.NORTH);
    JPanel missions = app.cs2Screens.cs2Glass(new GridLayout(0, 1, 0, 8));
    int index = 0;
    for (Mission mission : app.activeMissions) {
      final Color accent = mission.completed ? new Color(112, 221, 157) : new Color(122, 199, 233);
      JPanel card = new JPanel(new BorderLayout(0, 4));
      card.setBackground(new Color(23, 37, 48));
      card.setName("homeMission-" + mission.id);
      card.setBorder(
          BorderFactory.createCompoundBorder(
              BorderFactory.createMatteBorder(0, 3, 0, 0, accent),
              BorderFactory.createEmptyBorder(7, 10, 7, 10)));
      JPanel heading = app.cs2Screens.cs2Glass(new BorderLayout(9, 0));
      JLabel number = app.cs2Screens.cs2Text(String.format("%02d", ++index), 19, accent);
      number.setFont(new Font("SansSerif", Font.BOLD, 19));
      heading.add(number, BorderLayout.WEST);
      JTextArea name = text(mission.name, 12, true, 2, Color.WHITE);
      name.setName("homeMissionName-" + mission.id);
      heading.add(name);
      card.add(heading, BorderLayout.NORTH);
      JTextArea objective = text(mission.description, 11, false, 2, new Color(183, 200, 211));
      objective.setName("homeMissionObjective-" + mission.id);
      card.add(objective);
      JPanel foot = app.cs2Screens.cs2Glass(new BorderLayout(0, 4));
      JLabel reward =
          app.cs2Screens.cs2Text(
              mission.starReward + " Stars   +   " + app.carePackages.xpReward(mission) + " XP",
              12,
              new Color(248, 202, 112));
      reward.setName("homeMissionReward-" + mission.id);
      foot.add(reward, BorderLayout.NORTH);
      JProgressBar progress = new JProgressBar(0, Math.max(1, mission.goal));
      progress.setValue(Math.min(mission.current, mission.goal));
      progress.setBorderPainted(false);
      progress.setForeground(accent);
      progress.setBackground(new Color(48, 66, 77));
      progress.setPreferredSize(new Dimension(100, 4));
      foot.add(progress);
      JLabel count =
          app.cs2Screens.cs2Text(
              mission.completed
                  ? "COMPLETED"
                  : Math.min(mission.current, mission.goal)
                      + " / "
                      + mission.goal
                      + "   •   "
                      + Math.round(mission.progressPct() * 100)
                      + "%",
              11,
              new Color(167, 194, 207));
      foot.add(count, BorderLayout.SOUTH);
      card.add(foot, BorderLayout.SOUTH);
      missions.add(card);
    }
    if (index == 0)
      missions.add(text("Your next objectives will appear here.", 14, false, 2, Color.WHITE));
    board.add(missions);
    if (index > 0 && completed == index) {
      JButton next =
          app.cs2Screens.cs2Button(
              "NEW MISSIONS",
              true,
              e -> {
                app.missionService.generateNewMissions();
                app.cs2Screens.refreshCs2Home();
              });
      board.add(next, BorderLayout.SOUTH);
    }
    board.setPreferredSize(
        new Dimension(
            448, 88 + Math.max(1, index) * 120 + (index > 0 && completed == index ? 40 : 0)));
    return board;
  }
}
