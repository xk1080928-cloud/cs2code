package blahblah;

import blahblah.hGui.*;
import java.awt.*;
import java.awt.event.*;
import java.util.ArrayList;
import java.util.Comparator;
import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.regex.Matcher;
import java.util.regex.Pattern;
import javax.swing.*;

/** Container Browser Screen: focused feature implementation. */
final class ContainerBrowserScreen {
  private final hGui app;

  ContainerBrowserScreen(hGui app) {
    this.app = app;
  }

  void updateCrateImageDisplay() {
    if (app.casesTabPanel == null) return;
    if (app.crateImageLabel == null) {
      app.crateImageLabel = new JLabel();

      app.crateImageLabel.setBounds(240, 370, 280, 200);
      app.crateImageLabel.setHorizontalAlignment(SwingConstants.CENTER);
      app.casesTabPanel.add(app.crateImageLabel);
      app.casesTabPanel.setComponentZOrder(app.crateImageLabel, 0);
    }
    if (app.crateImage != null) {
      app.crateImageLabel.setIcon(new ImageIcon(HighQualityImages.fit(app.crateImage, 280, 200)));
    } else {
      app.crateImageLabel.setIcon(null);
    }
    app.casesTabPanel.repaint();
  }

  void showLoadedCaseResultImage(String skinName, Image image) {
    if (image == null || skinName == null) return;
    if (skinName.startsWith("case-selector-")) {
      for (CaseType caseType : CaseType.values()) {
        if (skinName.equals("case-selector-" + caseType.id) && caseType == app.currentCase) {
          app.crateImage = image;
          app.containerBrowserScreen.updateCrateImageDisplay();
          break;
        }
      }
      return;
    }
    String loadedName =
        app.artworkService.canonicalArtworkName(app.artworkService.artworkSkin(skinName));
    String loadedWear = app.artworkService.artworkWear(skinName);
    Map<String, String> normalizedNames = new HashMap<>();
    Map<Image, ImageIcon> icons = new java.util.IdentityHashMap<>();
    for (InventoryItem item : app.inventoryList) {
      String normalized =
          normalizedNames.computeIfAbsent(item.name, app.artworkService::canonicalArtworkName);
      if (!loadedName.equals(normalized)
          || (loadedWear != null && !loadedWear.equals(item.condition))) continue;
      String exactKey =
          app.artworkService.wearImageAbbreviation(item.condition) == null
              ? loadedName
              : loadedName + hGui.WEAR_IMAGE_SEPARATOR + item.condition;
      Image exact = app.imageRepository.get(exactKey), resolved = exact == null ? image : exact;
      if (item.image == null || item.image.getImage() != resolved) {
        item.image = icons.computeIfAbsent(resolved, ImageIcon::new);
        item.thumb110x75 = null;
        item.thumb130x88 = null;
      }
    }
    if (!loadedName.equals(app.artworkService.canonicalArtworkName(app.finalSkinName))
        && !loadedName.equals(app.artworkService.canonicalArtworkName(app.gunName))) return;
    if (loadedWear != null && !loadedWear.equals(app.finalCondition)) return;
    Image exact =
        app.imageRepository.get(
            app.artworkService.getSkinArtworkKey(app.finalSkinName, app.finalCondition));
    if (exact != null) image = exact;
    app.finalSkin = image;
    if (app.activeResultImageLabel != null) {
      Object requested = app.activeResultImageLabel.getClientProperty("skinArtworkKey");
      if (requested == null
          || requested.equals(
              app.artworkService.getSkinArtworkKey(app.finalSkinName, app.finalCondition))) {
        app.activeResultImageLabel.setIcon(
            app.marketItemCards.createContainedImageLabel(image, 430, 285).getIcon());
        app.activeResultImageLabel.repaint();
      }
    }
    if (app.animationPanel != null) app.animationPanel.repaint();
  }

  void stopAutoOpen() {
    if (app.autoTimer != null) {
      app.autoTimer.stop();
      app.autoTimer = null;
    }
    app.autoOpenButton.setText("AUTO OPEN");
  }

  void stopArmouryAutoOpen() {
    if (app.armouryAutoTimer != null) {
      app.armouryAutoTimer.stop();
      app.armouryAutoTimer = null;
    }
    app.activeArmouryAutoCollection = null;
    app.activeArmouryStarsDisplay = null;
    if (app.armouryAutoButton != null) {
      app.armouryAutoButton.setText("AUTO OPEN");
      app.armouryAutoButton.setEnabled(true);
    }
  }

  void selectCase(CaseType ct) {
    if (app.cs2ShellEnabled && (app.isAnimating || app.openingArtworkPreparing)) return;
    if (ct == null || app.isAnimating) return;
    app.currentCase = ct;
    app.skinImage = null;
    app.crateImage = app.containerBrowserScreen.getContainerImage(ct);
    if (app.openCrateButton != null) {
      app.openCrateButton.setText(String.format("OPEN CASE  $%.2f", ct.price));
    }
    if (app.caseSelectorButton != null) app.caseSelectorButton.setText(ct.name);
    app.containerBrowserScreen.updateCrateImageDisplay();
    app.uiWidgets.updateBalanceLabel();
    app.collectionService.updateSelectedCaseRoi();
  }

  Image getContainerImage(CaseType caseType) {
    if (caseType == null) return app.containerBrowserScreen.createContainerPlaceholderImage(null);
    String imageKey = "case-selector-" + caseType.id;
    Image image = app.imageRepository.get(imageKey);
    if (image == null && caseType.imageUrl != null && !caseType.imageUrl.isBlank()) {
      if (app.crateImageLabel != null)
        app.artworkService.registerPendingRemoteImageLabel(imageKey, app.crateImageLabel);
      app.imageRepository.loadRemote(imageKey, caseType.imageUrl);
    }
    return image == null
        ? app.containerBrowserScreen.createContainerPlaceholderImage(caseType)
        : image;
  }

  Image createContainerPlaceholderImage(CaseType caseType) {
    java.awt.image.BufferedImage image =
        new java.awt.image.BufferedImage(280, 180, java.awt.image.BufferedImage.TYPE_INT_ARGB);
    Graphics2D g = image.createGraphics();
    g.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
    g.setColor(Theme.BG_PANEL);
    g.fillRoundRect(28, 30, 224, 120, 14, 14);
    g.setColor(Theme.BORDER);
    g.setStroke(new BasicStroke(2));
    g.drawRoundRect(28, 30, 224, 120, 14, 14);
    g.setFont(new Font("Consolas", Font.BOLD, 12));
    String label = "LOADING CONTAINER ART";
    FontMetrics metrics = g.getFontMetrics();
    g.drawString(label, (image.getWidth() - metrics.stringWidth(label)) / 2, 96);
    g.dispose();
    return image;
  }

  Image createItemPlaceholderImage() {
    java.awt.image.BufferedImage image =
        new java.awt.image.BufferedImage(160, 100, java.awt.image.BufferedImage.TYPE_INT_ARGB);
    Graphics2D g = image.createGraphics();
    g.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
    g.setColor(Theme.BG_CARD);
    g.fillRoundRect(8, 8, 144, 84, 10, 10);
    g.setColor(Theme.BORDER);
    g.drawRoundRect(8, 8, 144, 84, 10, 10);
    g.setColor(Theme.TEXT_DIM);
    g.setFont(new Font("Consolas", Font.BOLD, 11));
    String label = "IMAGE LOADING";
    FontMetrics metrics = g.getFontMetrics();
    g.drawString(label, (image.getWidth() - metrics.stringWidth(label)) / 2, 54);
    g.dispose();
    return image;
  }

  void rebuildCaseBoxes() {
    if (app.caseSelectorButton != null) {
      app.caseSelectorButton.setText(app.currentCase.name);
      app.caseSelectorButton.setEnabled(true);
    }
    app.collectionService.updateSelectedCaseRoi();
  }

  Comparator<CaseType> defaultContainerOrder() {
    return Comparator.comparing((CaseType ct) -> ct.isSouvenir)
        .thenComparing(ct -> ct.isSouvenir ? ct.mapName : "", String.CASE_INSENSITIVE_ORDER)
        .thenComparingInt(ct -> ct.releaseOrder)
        .thenComparingInt(ct -> ct.catalogOrder)
        .thenComparing(ct -> ct.name, String.CASE_INSENSITIVE_ORDER);
  }

  int containerReleaseOrder(String object, String name) {
    Integer release = hGui.CONTAINER_RELEASE_DATES.get(name);
    if (release != null) return release;
    String date = app.catalogParsingService.extractCatalogRootString(object, "first_sale_date");
    if (date != null) {
      String[] parts = date.split("[-/]");
      try {
        if (parts.length == 3)
          return Integer.parseInt(parts[0]) * 10000
              + Integer.parseInt(parts[1]) * 100
              + Integer.parseInt(parts[2]);
      } catch (NumberFormatException ignored) {
      }
    }
    // Several crate records have no sale date. Tournament order within a
    // year is explicit; alphabetical tournament order is not chronological.
    String lower = name.toLowerCase(java.util.Locale.ROOT);
    if (lower.contains("genesis terminal")) return 20250916;
    if (lower.contains("dead hand terminal")) return 20260311;
    Matcher year = Pattern.compile("20\\d{2}").matcher(name);
    if (!year.find()) return Integer.MAX_VALUE;
    int month = 1;
    if (lower.contains("dreamhack 2014")) month = 11;
    else if (lower.contains("cologne")) month = 8;
    else if (lower.contains("cluj")) month = 10;
    else if (lower.contains("krakow")) month = 7;
    else if (lower.contains("london") || lower.contains("berlin")) month = 9;
    else if (lower.contains("rio")) month = 11;
    else if (lower.contains("shanghai") || lower.contains("budapest")) month = 12;
    else if (lower.contains("austin")) month = 6;
    else if (lower.contains("stockholm")) month = 10;
    else if (lower.contains("antwerp") || lower.contains("paris")) month = 5;
    else if (lower.contains("katowice")
        || lower.contains("columbus")
        || lower.contains("copenhagen")) month = 3;
    return Integer.parseInt(year.group()) * 10000 + month * 100 + 1;
  }

  void showCaseSelectorDialog() {
    JDialog dialog = new JDialog(app, "Choose a Case", true);
    dialog.setDefaultCloseOperation(JDialog.DISPOSE_ON_CLOSE);
    dialog.setLayout(new BorderLayout(0, 8));
    dialog.getContentPane().setBackground(Theme.BG_DARK);

    JPanel header = new JPanel(new BorderLayout(10, 0));
    header.setBackground(Theme.BG_PANEL);
    header.setBorder(BorderFactory.createEmptyBorder(12, 14, 8, 14));
    JLabel title = new JLabel("SELECT A CASE");
    title.setForeground(Theme.ACCENT_T);
    title.setFont(Theme.CONSOLE_BOLD_16);
    header.add(title, BorderLayout.WEST);

    JPanel controls = new JPanel(new FlowLayout(FlowLayout.RIGHT, 8, 0));
    controls.setOpaque(false);
    JComboBox<String> sortBox =
        new JComboBox<>(
            new String[] {"Price: Low to High", "Price: High to Low", "ROI: Low to High"});
    app.uiWidgets.styleComboBox(sortBox);
    sortBox.setPreferredSize(new Dimension(170, 30));
    JTextField searchField = new JTextField(18);
    searchField.setToolTipText("Search cases");
    JLabel sortLabel = new JLabel("Sort:");
    sortLabel.setForeground(Theme.TEXT_DIM);
    JLabel searchLabel = new JLabel("Search:");
    searchLabel.setForeground(Theme.TEXT_DIM);
    controls.add(sortLabel);
    controls.add(sortBox);
    controls.add(searchLabel);
    controls.add(searchField);
    header.add(controls, BorderLayout.EAST);
    dialog.add(header, BorderLayout.NORTH);

    JPanel grid = new JPanel(new GridLayout(0, 3, 12, 12));
    grid.setBackground(Theme.BG_DARK);
    grid.setBorder(BorderFactory.createEmptyBorder(12, 12, 12, 12));
    JScrollPane scrollPane = new JScrollPane(grid);
    scrollPane.setBorder(null);
    scrollPane.getViewport().setBackground(Theme.BG_DARK);
    scrollPane.getVerticalScrollBar().setUnitIncrement(18);
    dialog.add(scrollPane, BorderLayout.CENTER);

    Runnable rebuildGrid =
        () -> {
          String query = searchField.getText().trim().toLowerCase(java.util.Locale.ROOT);
          List<CaseType> cases = new ArrayList<>(java.util.Arrays.asList(CaseType.values()));
          cases.removeIf(
              caseType ->
                  !caseType.name.toLowerCase(java.util.Locale.ROOT).contains(query)
                      && !caseType.crateName.toLowerCase(java.util.Locale.ROOT).contains(query));
          String sort = (String) sortBox.getSelectedItem();
          if ("Price: Low to High".equals(sort)) {
            cases.sort(Comparator.comparingDouble(caseType -> caseType.price));
          } else if ("Price: High to Low".equals(sort)) {
            cases.sort(
                Comparator.comparingDouble((CaseType caseType) -> caseType.price).reversed());
          } else if ("ROI: Low to High".equals(sort)) {
            cases.sort(Comparator.comparingDouble(app.collectionService::getEstimatedCaseRoi));
          } else {
            cases.sort(app.containerBrowserScreen.defaultContainerOrder());
          }

          grid.removeAll();
          for (CaseType caseType : cases) {
            grid.add(app.containerBrowserScreen.createCaseSelectorCard(caseType, dialog));
          }
          grid.revalidate();
          grid.repaint();
        };
    sortBox.addActionListener(e -> rebuildGrid.run());
    searchField
        .getDocument()
        .addDocumentListener(
            new javax.swing.event.DocumentListener() {
              @Override
              public void insertUpdate(javax.swing.event.DocumentEvent e) {
                rebuildGrid.run();
              }

              @Override
              public void removeUpdate(javax.swing.event.DocumentEvent e) {
                rebuildGrid.run();
              }

              @Override
              public void changedUpdate(javax.swing.event.DocumentEvent e) {
                rebuildGrid.run();
              }
            });
    rebuildGrid.run();

    dialog.setSize(1040, 780);
    dialog.setLocationRelativeTo(app);
    dialog.setVisible(true);
  }

  JPanel createCaseSelectorCard(CaseType caseType, JDialog dialog) {
    JPanel card = new JPanel(new BorderLayout(4, 6));
    card.setBackground(Theme.BG_CARD);
    card.setBorder(
        BorderFactory.createCompoundBorder(
            BorderFactory.createLineBorder(
                caseType == app.currentCase ? Theme.ACCENT_T : Theme.BORDER, 2),
            BorderFactory.createEmptyBorder(8, 8, 8, 8)));
    card.setPreferredSize(new Dimension(250, 250));

    JLabel imageLabel = new JLabel("", SwingConstants.CENTER);
    imageLabel.setPreferredSize(new Dimension(220, 150));
    String imageKey = "case-selector-" + caseType.id;
    Image caseImage = app.imageRepository.get(imageKey);
    if (caseImage == null) {
      caseImage = app.containerBrowserScreen.createContainerPlaceholderImage(caseType);
      if (caseType.imageUrl != null && !caseType.imageUrl.isBlank()) {
        app.artworkService.registerPendingRemoteImageLabel(imageKey, imageLabel);
        app.imageRepository.loadRemote(imageKey, caseType.imageUrl);
      }
    }
    if (caseImage != null) {
      int width = caseImage.getWidth(null);
      int height = caseImage.getHeight(null);
      if (width > 0 && height > 0) {
        double scale = Math.min(210.0 / width, 140.0 / height);
        imageLabel.setIcon(
            new ImageIcon(
                HighQualityImages.fit(
                    caseImage,
                    Math.max(1, (int) (width * scale)),
                    Math.max(1, (int) (height * scale)))));
      }
    }
    JPanel artwork = new JPanel(new BorderLayout(0, 4));
    artwork.setOpaque(false);
    artwork.add(imageLabel, BorderLayout.CENTER);
    JButton previewButton = new JButton("PREVIEW CONTENTS");
    app.uiWidgets.styleButton(previewButton, Theme.BG_DARK, Theme.ACCENT_CT, Theme.BORDER);
    previewButton.setFont(Theme.CONSOLE_BOLD_12);
    previewButton.setFocusable(false);
    previewButton.addActionListener(e -> app.containerBrowserScreen.showContainerPreview(caseType));
    artwork.add(previewButton, BorderLayout.SOUTH);
    card.add(artwork, BorderLayout.CENTER);

    JLabel nameLabel =
        new JLabel(
            "<html><div style='text-align:center;'>"
                + app.marketItemCards.escapeHtml(caseType.name)
                + "</div></html>",
            SwingConstants.CENTER);
    nameLabel.setForeground(Theme.TEXT);
    nameLabel.setFont(Theme.CONSOLE_BOLD_12);
    JLabel details =
        new JLabel(
            String.format(
                "<html><div style='text-align:center;'>Price: $%.2f<br>Estimated ROI:"
                    + " %s</div></html>",
                caseType.price,
                app.collectionService.hasVerifiedCasePools(caseType)
                    ? String.format("%.1f%%", app.collectionService.getEstimatedCaseRoi(caseType))
                    : "Unavailable"),
            SwingConstants.CENTER);
    details.setForeground(Theme.ACCENT_CT);
    details.setFont(Theme.CONSOLE_PLAIN_12);
    JPanel text = new JPanel(new GridLayout(2, 1, 0, 3));
    text.setOpaque(false);
    text.add(nameLabel);
    text.add(details);
    card.add(text, BorderLayout.SOUTH);

    MouseAdapter chooseCase =
        new MouseAdapter() {
          @Override
          public void mouseClicked(MouseEvent e) {
            app.containerBrowserScreen.selectCase(caseType);
            dialog.dispose();
          }

          @Override
          public void mouseEntered(MouseEvent e) {
            if (caseType != app.currentCase)
              card.setBorder(
                  BorderFactory.createCompoundBorder(
                      BorderFactory.createLineBorder(Theme.ACCENT_CT, 2),
                      BorderFactory.createEmptyBorder(8, 8, 8, 8)));
          }

          @Override
          public void mouseExited(MouseEvent e) {
            card.setBorder(
                BorderFactory.createCompoundBorder(
                    BorderFactory.createLineBorder(
                        caseType == app.currentCase ? Theme.ACCENT_T : Theme.BORDER, 2),
                    BorderFactory.createEmptyBorder(8, 8, 8, 8)));
          }
        };
    app.containerBrowserScreen.installCaseCardClickListener(card, chooseCase);
    return card;
  }

  void sizeContentsWindow(Window window) {
    Rectangle usable = GraphicsEnvironment.getLocalGraphicsEnvironment().getMaximumWindowBounds();
    window.setSize(Math.min(1140, usable.width), Math.min(760, usable.height));
    window.setLocationRelativeTo(app);
  }

  void showContainerPreview(CaseType caseType) {
    JDialog dialog = new JDialog(app, caseType.name + " Contents", true);
    dialog.setDefaultCloseOperation(JDialog.DISPOSE_ON_CLOSE);
    dialog.setContentPane(app.containerBrowserScreen.createContainerContentsPanel(caseType));
    app.containerBrowserScreen.sizeContentsWindow(dialog);
    dialog.setResizable(true);
    dialog.setVisible(true);
  }

  JPanel createContainerContentsPanel(CaseType caseType) {
    JPanel contentsPanel = new JPanel(new BorderLayout(8, 8));
    contentsPanel.setBackground(Theme.BG_DARK);
    JPanel items = new JPanel(new GridLayout(0, 3, 10, 10));
    items.setBackground(Theme.BG_DARK);
    items.setBorder(BorderFactory.createEmptyBorder(12, 12, 12, 12));
    String[] tiers = {"Consumer", "Industrial", "Milspec", "Restricted", "Classified", "Covert"};
    Map<String, List<String>> contents = caseType.regularDropNames;
    if (contents.values().stream().allMatch(List::isEmpty) && !caseType.isSouvenir) {
      TradeUpCollection collection = app.containerBrowserScreen.getCollectionForCaseType(caseType);
      if (collection != null) {
        contents = new LinkedHashMap<>();
        contents.put("Consumer", java.util.Arrays.asList(collection.consumerSkins));
        contents.put("Industrial", java.util.Arrays.asList(collection.industrialSkins));
        contents.put("Milspec", java.util.Arrays.asList(collection.milspecSkins));
        contents.put("Restricted", java.util.Arrays.asList(collection.restrictedSkins));
        contents.put("Classified", java.util.Arrays.asList(collection.classifiedSkins));
        contents.put("Covert", java.util.Arrays.asList(collection.covertSkins));
      }
    }
    for (String tier : tiers) {
      for (String skinName : contents.getOrDefault(tier, java.util.Collections.emptyList())) {
        JPanel itemCard = new JPanel(new BorderLayout(4, 4));
        // Wider cards reserve space for complete, wrapped names.
        itemCard.setPreferredSize(new Dimension(340, 205));
        itemCard.setMinimumSize(new Dimension(340, 205));
        itemCard.setBackground(Theme.BG_CARD);
        itemCard.setBorder(
            BorderFactory.createLineBorder(app.itemInspectionScreen.getRarityColor(tier), 1));
        JLabel art = new JLabel("", SwingConstants.CENTER);
        app.artworkService.getSkinImageFromName(skinName, art, 150, 95);
        JLabel name =
            new JLabel(
                "<html><div style='width:230px;text-align:center;'>"
                    + app.marketItemCards.escapeHtml(skinName)
                    + "</div></html>",
                SwingConstants.CENTER);
        name.setToolTipText(skinName);
        name.setBorder(BorderFactory.createEmptyBorder(4, 8, 8, 8));
        name.setPreferredSize(new Dimension(320, 64));
        name.setForeground(Theme.TEXT);
        name.setFont(Theme.CONSOLE_PLAIN_12);
        JLabel rarity = new JLabel(tier, SwingConstants.CENTER);
        rarity.setForeground(app.itemInspectionScreen.getRarityColor(tier));
        rarity.setFont(Theme.CONSOLE_BOLD_12);
        itemCard.add(art, BorderLayout.CENTER);
        itemCard.add(name, BorderLayout.SOUTH);
        itemCard.add(rarity, BorderLayout.NORTH);
        items.add(itemCard);
      }
    }
    if (!caseType.isSouvenir) {
      Set<String> rarePreviewItems = new java.util.TreeSet<>(String.CASE_INSENSITIVE_ORDER);
      for (String rareDrop : caseType.rareDropNames) {
        rarePreviewItems.add(rareDrop);
        if (rareDrop.contains("Doppler") || rareDrop.contains("Gamma Doppler")) {
          Set<String> variants = new java.util.LinkedHashSet<>();
          variants.add(rareDrop);
          app.collectionService.addDopplerVariants(variants);
          rarePreviewItems.addAll(variants);
        }
      }
      for (String rareDrop : rarePreviewItems) {
        JPanel rareCard = new JPanel(new BorderLayout(4, 4));
        rareCard.setPreferredSize(new Dimension(340, 205));
        rareCard.setMinimumSize(new Dimension(340, 205));
        rareCard.setBackground(Theme.BG_CARD);
        rareCard.setBorder(BorderFactory.createLineBorder(Theme.RARITY_GOLD, 1));
        JLabel art = new JLabel("", SwingConstants.CENTER);
        app.artworkService.getSkinImageFromName(rareDrop, art, 150, 95);
        JLabel name =
            new JLabel(
                "<html><div style='width:230px;text-align:center;'>"
                    + app.marketItemCards.escapeHtml(rareDrop)
                    + "</div></html>",
                SwingConstants.CENTER);
        name.setToolTipText(rareDrop);
        name.setBorder(BorderFactory.createEmptyBorder(4, 8, 8, 8));
        name.setPreferredSize(new Dimension(320, 64));
        name.setForeground(Theme.TEXT);
        name.setFont(Theme.CONSOLE_PLAIN_12);
        JLabel rarity = new JLabel("Rare Special Item", SwingConstants.CENTER);
        rarity.setForeground(Theme.RARITY_GOLD);
        rarity.setFont(Theme.CONSOLE_BOLD_12);
        rareCard.add(art, BorderLayout.CENTER);
        rareCard.add(name, BorderLayout.SOUTH);
        rareCard.add(rarity, BorderLayout.NORTH);
        items.add(rareCard);
      }
    }
    if (items.getComponentCount() == 0) {
      JLabel unavailable =
          new JLabel("Container contents are not available.", SwingConstants.CENTER);
      unavailable.setForeground(Theme.TEXT_DIM);
      contentsPanel.add(unavailable, BorderLayout.CENTER);
    } else {
      JScrollPane scroll = new JScrollPane(items);
      scroll.setBorder(null);
      scroll.getViewport().setBackground(Theme.BG_DARK);
      scroll.getVerticalScrollBar().setUnitIncrement(18);
      scroll.setHorizontalScrollBarPolicy(ScrollPaneConstants.HORIZONTAL_SCROLLBAR_NEVER);
      contentsPanel.add(scroll, BorderLayout.CENTER);
    }

    contentsPanel.addComponentListener(
        new ComponentAdapter() {
          @Override
          public void componentResized(ComponentEvent e) {
            ((GridLayout) items.getLayout())
                .setColumns(Math.max(1, Math.min(3, (contentsPanel.getWidth() - 40) / 350)));
            items.revalidate();
          }
        });
    return contentsPanel;
  }

  TradeUpCollection getCollectionForCaseType(CaseType caseType) {
    String collectionName = app.oddsAndChecklistScreen.getCollectionNameForCaseType(caseType);
    if (collectionName != null) {
      for (TradeUpCollection collection : hGui.TRADE_UP_COLLECTIONS) {
        if (collection.collectionName.equals(collectionName)) return collection;
      }
    }
    return app.collectionService.buildCatalogCaseCollection(caseType);
  }

  void installCaseCardClickListener(Component component, MouseListener listener) {
    if (component instanceof AbstractButton) return;
    component.addMouseListener(listener);
    if (component instanceof java.awt.Container) {
      for (Component child : ((java.awt.Container) component).getComponents()) {
        app.containerBrowserScreen.installCaseCardClickListener(child, listener);
      }
    }
    app.casesTabPanel.repaint();
  }
}
