package blahblah;

import blahblah.hGui.*;
import java.awt.*;
import java.awt.event.*;
import java.util.Map;
import javax.swing.*;

/** Loadout Cards: focused feature implementation. */
final class LoadoutCards {
  private final hGui app;

  LoadoutCards(hGui app) {
    this.app = app;
  }

  JPanel buildWeaponCard(
      String slot,
      InventoryItem equipped,
      Color BG_CARD,
      Color ACCENT,
      Color TEXT,
      Map<String, InventoryItem> loadout,
      boolean isTSide) {
    boolean hasEquipped = (equipped != null);
    if (hasEquipped) app.artworkService.refreshInventoryItemArtwork(equipped);
    Color borderCol = hasEquipped ? Theme.ACCENT_T : Theme.BORDER;
    String slotDisplay = slot.replaceAll("_(T|CT)$", "");

    JPanel card = new JPanel(new BorderLayout(0, 2));
    card.setBackground(Theme.BG_CARD);
    card.setBorder(
        BorderFactory.createCompoundBorder(
            BorderFactory.createLineBorder(borderCol, 1),
            BorderFactory.createEmptyBorder(4, 4, 4, 4)));
    card.setPreferredSize(new Dimension(116, 110));
    card.setCursor(java.awt.Cursor.getPredefinedCursor(java.awt.Cursor.HAND_CURSOR));

    JLabel imgLbl;
    if (hasEquipped && equipped.image != null) {

      ImageIcon thumb = equipped.getThumb110();
      imgLbl = new JLabel(thumb != null ? thumb : equipped.image, SwingConstants.CENTER);
      imgLbl.setPreferredSize(new Dimension(90, 52));
    } else {

      String abbrev =
          slotDisplay.length() > 10 ? slotDisplay.substring(0, 9) + "\u2026" : slotDisplay;
      imgLbl =
          new JLabel(
              "<html><center><font color='#3a3a55'>" + abbrev + "</font></center></html>",
              SwingConstants.CENTER);
      imgLbl.setFont(new Font("Consolas", Font.PLAIN, 8));
      imgLbl.setOpaque(true);
      imgLbl.setBackground(Theme.PLACEHOLDER_BG);
      imgLbl.setPreferredSize(new Dimension(90, 52));
    }
    imgLbl.setHorizontalAlignment(SwingConstants.CENTER);
    if (hasEquipped)
      app.artworkService.getSkinImageFromName(equipped.name, equipped.condition, imgLbl, 90, 52);
    card.add(imgLbl, BorderLayout.CENTER);

    JPanel bottomPanel = new JPanel(new GridLayout(1, 1, 0, 2));
    bottomPanel.setBackground(Theme.BG_CARD);
    bottomPanel.setBorder(BorderFactory.createEmptyBorder(2, 2, 2, 2));
    JLabel gunLbl = new JLabel(slotDisplay, SwingConstants.CENTER);
    gunLbl.setFont(new Font("Consolas", Font.BOLD, 8));
    gunLbl.setForeground(Theme.SLOT_LABEL);

    bottomPanel.add(gunLbl);
    card.add(bottomPanel, BorderLayout.SOUTH);

    card.addMouseListener(
        new java.awt.event.MouseAdapter() {
          @Override
          public void mouseClicked(java.awt.event.MouseEvent e) {
            app.loadoutCards.showLoadoutPicker(slot, loadout, isTSide);
          }

          @Override
          public void mouseEntered(java.awt.event.MouseEvent e) {
            card.setBackground(Theme.CARD_HOVER);
            card.setBorder(
                BorderFactory.createCompoundBorder(
                    BorderFactory.createLineBorder(Theme.ACCENT_T, 2),
                    BorderFactory.createEmptyBorder(3, 3, 3, 3)));
          }

          @Override
          public void mouseExited(java.awt.event.MouseEvent e) {
            card.setBackground(Theme.BG_CARD);
            card.setBorder(
                BorderFactory.createCompoundBorder(
                    BorderFactory.createLineBorder(borderCol, 1),
                    BorderFactory.createEmptyBorder(4, 4, 4, 4)));
          }
        });
    return card;
  }

  JPanel buildAgentCard(
      String slot,
      InventoryItem equipped,
      Color BG_CARD,
      Color ACCENT,
      Color TEXT,
      Map<String, InventoryItem> loadout,
      boolean isTSide) {
    boolean hasEquipped = (equipped != null);
    if (hasEquipped) app.artworkService.refreshInventoryItemArtwork(equipped);
    Color borderCol = hasEquipped ? Theme.ACCENT_T : Theme.BORDER;
    String sideLabel = isTSide ? "T Agent" : "CT Agent";
    String agentDisplay = hasEquipped ? equipped.name : "None";

    JPanel card = new JPanel(new BorderLayout(0, 4));
    card.setBackground(Theme.BG_CARD);
    card.setBorder(
        BorderFactory.createCompoundBorder(
            BorderFactory.createLineBorder(borderCol, 1),
            BorderFactory.createEmptyBorder(6, 6, 6, 6)));
    card.setPreferredSize(new Dimension(136, 178));
    card.setCursor(java.awt.Cursor.getPredefinedCursor(java.awt.Cursor.HAND_CURSOR));

    JLabel imgLbl;
    if (hasEquipped && equipped.image != null) {
      Image src = equipped.image.getImage();
      int iw = Math.max(1, src.getWidth(null));
      int ih = Math.max(1, src.getHeight(null));
      double scale = Math.min(112.0 / iw, 104.0 / ih);
      Image scaled = HighQualityImages.fit(src, (int) (iw * scale), (int) (ih * scale));
      imgLbl = new JLabel(new ImageIcon(scaled), SwingConstants.CENTER);
    } else {
      imgLbl = new JLabel(isTSide ? "T" : "CT", SwingConstants.CENTER);
      imgLbl.setFont(new Font("Consolas", Font.BOLD, isTSide ? 42 : 34));
      imgLbl.setForeground(
          new Color(
              Theme.ACCENT_T.getRed(), Theme.ACCENT_T.getGreen(), Theme.ACCENT_T.getBlue(), 70));
      imgLbl.setOpaque(true);
      imgLbl.setBackground(Theme.PLACEHOLDER_BG);
    }
    imgLbl.setPreferredSize(new Dimension(112, 104));
    if (hasEquipped)
      app.artworkService.getSkinImageFromName(equipped.name, equipped.condition, imgLbl, 112, 104);
    card.add(imgLbl, BorderLayout.CENTER);

    JPanel bottomPanel = new JPanel(new GridLayout(3, 1, 0, 2));
    bottomPanel.setBackground(Theme.BG_CARD);

    JLabel sideLbl = new JLabel(sideLabel, SwingConstants.CENTER);
    sideLbl.setFont(new Font("Consolas", Font.BOLD, 9));
    sideLbl.setForeground(Theme.SLOT_LABEL);

    JLabel nameLbl =
        new JLabel("<html><center>" + agentDisplay + "</center></html>", SwingConstants.CENTER);
    nameLbl.setFont(new Font("Consolas", Font.PLAIN, 8));
    nameLbl.setForeground(hasEquipped ? TEXT : new Color(80, 80, 110));

    JLabel actionLbl =
        new JLabel(hasEquipped ? "Click to change" : "Click to equip", SwingConstants.CENTER);
    actionLbl.setFont(new Font("Consolas", Font.PLAIN, 8));
    actionLbl.setForeground(Theme.ACCENT_T);

    bottomPanel.add(sideLbl);
    bottomPanel.add(nameLbl);
    bottomPanel.add(actionLbl);
    card.add(bottomPanel, BorderLayout.SOUTH);

    card.addMouseListener(
        new java.awt.event.MouseAdapter() {
          @Override
          public void mouseClicked(java.awt.event.MouseEvent e) {
            app.loadoutCards.showLoadoutPicker(slot, loadout, isTSide);
          }

          @Override
          public void mouseEntered(java.awt.event.MouseEvent e) {
            card.setBackground(Theme.CARD_HOVER);
            bottomPanel.setBackground(Theme.CARD_HOVER);
            card.setBorder(
                BorderFactory.createCompoundBorder(
                    BorderFactory.createLineBorder(Theme.ACCENT_T, 2),
                    BorderFactory.createEmptyBorder(5, 5, 5, 5)));
          }

          @Override
          public void mouseExited(java.awt.event.MouseEvent e) {
            card.setBackground(Theme.BG_CARD);
            bottomPanel.setBackground(Theme.BG_CARD);
            card.setBorder(
                BorderFactory.createCompoundBorder(
                    BorderFactory.createLineBorder(borderCol, 1),
                    BorderFactory.createEmptyBorder(6, 6, 6, 6)));
          }
        });

    return card;
  }

  void showLoadoutPicker(String slot, Map<String, InventoryItem> loadout, boolean isTSide) {
    Color TEXT = Theme.TEXT;

    java.util.List<InventoryItem> matches = new java.util.ArrayList<>();
    for (InventoryItem item : app.inventoryList) {
      String cleanName = item.name.replace("StatTrak ", "").trim();
      boolean isKnifeSlot = slot.equals("Knife_T") || slot.equals("Knife_CT");
      boolean isGlovesSlot = slot.equals("Gloves_T") || slot.equals("Gloves_CT");
      boolean isAgentSlot = slot.equals(hGui.AGENT_SLOT_T) || slot.equals(hGui.AGENT_SLOT_CT);
      if (isKnifeSlot) {
        String r = item.rarity != null ? item.rarity : "";
        if (r.equalsIgnoreCase("Knife")
            || cleanName.contains("Knife")
            || cleanName.contains("Bayonet")
            || cleanName.contains("Karambit")) {
          matches.add(item);
        }
      } else if (isGlovesSlot) {
        String r = item.rarity != null ? item.rarity : "";
        if (r.equalsIgnoreCase("Gloves") || cleanName.contains("Gloves")) {
          matches.add(item);
        }
      } else if (isAgentSlot) {
        if (app.itemMetadataService.isAgentSkin(cleanName)) {
          matches.add(item);
        }
      } else {
        if (cleanName.toLowerCase().startsWith(slot.toLowerCase())) {
          matches.add(item);
        }
      }
    }
    matches.sort(
        (a, b) -> {
          java.util.List<String> order =
              java.util.Arrays.asList(
                  "Factory New", "Minimal Wear", "Field-Tested", "Well-Worn", "Battle-Scarred");
          int ai = order.indexOf(a.condition), bi = order.indexOf(b.condition);
          return Integer.compare(ai < 0 ? 99 : ai, bi < 0 ? 99 : bi);
        });

    String slotLabel =
        (slot.equals(hGui.AGENT_SLOT_T) || slot.equals(hGui.AGENT_SLOT_CT))
            ? "Agent"
            : slot.replaceAll("_(T|CT)$", "");
    JDialog dialog = new JDialog(app, "Select skin for " + slotLabel, true);
    dialog.setSize(640, 440);
    dialog.setLocationRelativeTo(app);
    dialog.getContentPane().setBackground(Theme.BG_DARK);
    dialog.setLayout(new BorderLayout());

    JLabel hdr = new JLabel("  " + slotLabel + "  \u2014  Select a skin", SwingConstants.LEFT);
    hdr.setFont(new Font("Consolas", Font.BOLD, 15));
    hdr.setForeground(Theme.ACCENT_T);
    hdr.setOpaque(true);
    hdr.setBackground(new Color(18, 18, 30));
    hdr.setBorder(
        BorderFactory.createCompoundBorder(
            BorderFactory.createMatteBorder(0, 0, 2, 0, Theme.ACCENT_T),
            BorderFactory.createEmptyBorder(10, 16, 10, 16)));
    dialog.add(hdr, BorderLayout.NORTH);

    JPanel grid = new JPanel(new WrapLayout(FlowLayout.LEFT, 10, 10));
    grid.setBackground(Theme.BG_DARK);
    grid.setBorder(BorderFactory.createEmptyBorder(10, 10, 10, 10));

    JPanel defaultCard =
        app.loadoutCards.buildPickerCard(
            null, slot, Theme.BG_CARD, Theme.ACCENT_T, TEXT, loadout.get(slot) == null);
    defaultCard.addMouseListener(
        new java.awt.event.MouseAdapter() {
          @Override
          public void mouseClicked(java.awt.event.MouseEvent e) {

            int scrollY =
                isTSide
                    ? (app.loadoutScrollPaneT != null
                        ? app.loadoutScrollPaneT.getVerticalScrollBar().getValue()
                        : 0)
                    : (app.loadoutScrollPaneCT != null
                        ? app.loadoutScrollPaneCT.getVerticalScrollBar().getValue()
                        : 0);
            loadout.remove(slot);
            dialog.dispose();
            if (isTSide) app.loadoutScrollYT = scrollY;
            else app.loadoutScrollYCT = scrollY;
            app.missionService.checkLoadoutAchievements();
            app.loadoutScreen.refreshLoadoutTab();
          }
        });
    grid.add(defaultCard);

    for (InventoryItem item : matches) {
      boolean isEquipped = item.equals(loadout.get(slot));
      JPanel skinCard =
          app.loadoutCards.buildPickerCard(
              item, slot, Theme.BG_CARD, Theme.ACCENT_T, TEXT, isEquipped);
      skinCard.addMouseListener(
          new java.awt.event.MouseAdapter() {
            @Override
            public void mouseClicked(java.awt.event.MouseEvent e) {

              int scrollY =
                  isTSide
                      ? (app.loadoutScrollPaneT != null
                          ? app.loadoutScrollPaneT.getVerticalScrollBar().getValue()
                          : 0)
                      : (app.loadoutScrollPaneCT != null
                          ? app.loadoutScrollPaneCT.getVerticalScrollBar().getValue()
                          : 0);
              loadout.put(slot, item);
              dialog.dispose();
              if (isTSide) app.loadoutScrollYT = scrollY;
              else app.loadoutScrollYCT = scrollY;
              app.missionService.checkLoadoutAchievements();
              app.loadoutScreen.refreshLoadoutTab();
            }
          });
      grid.add(skinCard);
    }

    JScrollPane scroll =
        new JScrollPane(
            grid, JScrollPane.VERTICAL_SCROLLBAR_AS_NEEDED, JScrollPane.HORIZONTAL_SCROLLBAR_NEVER);
    scroll.setBorder(null);
    scroll.setBackground(Theme.BG_DARK);
    scroll.getVerticalScrollBar().setUnitIncrement(16);
    dialog.add(scroll, BorderLayout.CENTER);

    if (matches.isEmpty()) {
      JLabel noSkins =
          new JLabel(
              "You have no " + slotLabel + " skins in your inventory.", SwingConstants.CENTER);
      noSkins.setFont(new Font("Consolas", Font.PLAIN, 12));
      noSkins.setForeground(Theme.SLOT_LABEL);
      noSkins.setBorder(BorderFactory.createEmptyBorder(6, 0, 6, 0));
      dialog.add(noSkins, BorderLayout.SOUTH);
    }
    dialog.setVisible(true);
  }

  JPanel buildPickerCard(
      InventoryItem item,
      String slot,
      Color BG_CARD,
      Color ACCENT,
      Color TEXT,
      boolean isSelected) {
    boolean isDefault = (item == null);
    if (!isDefault) app.artworkService.refreshInventoryItemArtwork(item);
    Color border = isSelected ? Theme.ACCENT_T : new Color(45, 45, 65);

    boolean isPickerST = !isDefault && item.isStattrak;
    JPanel card = new JPanel(new BorderLayout(0, 3));
    card.setBackground(isSelected ? new Color(30, 35, 55) : Theme.BG_CARD);
    card.setBorder(
        BorderFactory.createCompoundBorder(
            BorderFactory.createLineBorder(border, isSelected ? 2 : 1),
            BorderFactory.createEmptyBorder(6, 6, 6, 6)));
    card.setPreferredSize(new Dimension(130, 115));
    card.setCursor(java.awt.Cursor.getPredefinedCursor(java.awt.Cursor.HAND_CURSOR));

    JLabel imgLbl;
    if (!isDefault && item.image != null) {
      Image src = item.image.getImage();
      int iw = src.getWidth(null), ih = src.getHeight(null);
      if (iw <= 0 || ih <= 0) {
        iw = 100;
        ih = 65;
      }
      double pscale = Math.min(100.0 / iw, 65.0 / ih);
      int sw = (int) (iw * pscale), sh = (int) (ih * pscale);
      Image scaled = HighQualityImages.fit(src, sw, sh);
      imgLbl = new JLabel(new ImageIcon(scaled), SwingConstants.CENTER);
      imgLbl.setPreferredSize(new Dimension(100, 65));
    } else {
      imgLbl = new JLabel(isDefault ? "NONE" : "?", SwingConstants.CENTER);
      imgLbl.setFont(new Font("Consolas", Font.BOLD, isDefault ? 12 : 18));
      imgLbl.setForeground(isDefault ? new Color(100, 100, 130) : new Color(60, 60, 80));
      imgLbl.setOpaque(true);
      imgLbl.setBackground(Theme.PLACEHOLDER_BG);
      imgLbl.setPreferredSize(new Dimension(100, 65));
    }
    if (!isDefault)
      app.artworkService.getSkinImageFromName(item.name, item.condition, imgLbl, 100, 65);
    card.add(imgLbl, BorderLayout.CENTER);

    String displayName =
        isDefault ? "None" : (isPickerST ? "ST " + item.name.replace("StatTrak ", "") : item.name);
    JPanel textPanel = new JPanel(new GridLayout(2, 1, 0, 1));
    textPanel.setBackground(card.getBackground());
    JLabel nameLbl = new JLabel(displayName, SwingConstants.CENTER);
    nameLbl.setFont(new Font("Consolas", Font.BOLD, 9));
    nameLbl.setForeground(isSelected ? Theme.ACCENT_T : isPickerST ? Theme.STATTRAK : TEXT);
    JLabel condLbl = new JLabel(isDefault ? "" : item.condition, SwingConstants.CENTER);
    condLbl.setFont(new Font("Consolas", Font.PLAIN, 8));
    condLbl.setForeground(new Color(130, 140, 170));
    textPanel.add(nameLbl);
    textPanel.add(condLbl);
    card.add(textPanel, BorderLayout.SOUTH);

    card.addMouseListener(
        new java.awt.event.MouseAdapter() {
          @Override
          public void mouseEntered(java.awt.event.MouseEvent e) {
            if (!isSelected) {
              card.setBackground(new Color(35, 35, 52));
              card.setBorder(
                  BorderFactory.createCompoundBorder(
                      BorderFactory.createLineBorder(Theme.ACCENT_T, 1),
                      BorderFactory.createEmptyBorder(6, 6, 6, 6)));
            }
          }

          @Override
          public void mouseExited(java.awt.event.MouseEvent e) {
            if (!isSelected) {
              card.setBackground(Theme.BG_CARD);
              card.setBorder(
                  BorderFactory.createCompoundBorder(
                      BorderFactory.createLineBorder(border, 1),
                      BorderFactory.createEmptyBorder(6, 6, 6, 6)));
            }
          }
        });
    return card;
  }
}
