package blahblah;

import java.util.*;
import java.util.concurrent.*;
import javax.swing.*;

/**
 * One visibility-gated producer. Leaving Market Home cancels in-flight commits, not just painting.
 */
final class BackgroundUnboxing {
  private final hGui app;
  private volatile ScheduledExecutorService worker;
  private final List<MarketHomeUnboxFeed> listeners = new ArrayList<>();
  private final ArrayDeque<HomeUnboxEntry> recent = new ArrayDeque<>();
  private List<HomeUnboxSource> sources;
  private volatile long epoch;
  private boolean enabled;

  BackgroundUnboxing(hGui app) {
    this.app = app;
  }

  boolean isRunning() {
    return worker != null && !worker.isShutdown();
  }

  boolean isEnabled() {
    return enabled;
  }

  boolean homeVisible() {
    for (MarketHomeUnboxFeed feed : listeners) if (feed.isShowing()) return true;
    return false;
  }

  void start() {
    enabled = true;
    updateClock();
  }

  void stop() {
    enabled = false;
    pause();
  }

  private void pause() {
    epoch++;
    ScheduledExecutorService old = worker;
    worker = null;
    if (old != null) old.shutdownNow();
  }

  private void updateClock() {
    if (!enabled || !homeVisible()) {
      pause();
      return;
    }
    if (isRunning()) return;
    final long ticket = ++epoch;
    worker =
        Executors.newSingleThreadScheduledExecutor(
            r -> {
              Thread t = new Thread(r, "Market Home simulated unboxing");
              t.setDaemon(true);
              return t;
            });
    schedule(ticket);
  }

  private void schedule(long ticket) {
    ScheduledExecutorService current = worker;
    if (ticket != epoch || current == null || current.isShutdown()) return;
    try {
      current.schedule(
          () -> roll(ticket), app.marketHomeFeeds.nextHomeUnboxDelay(), TimeUnit.MILLISECONDS);
    } catch (RejectedExecutionException ignored) {
    }
  }

  private void roll(long ticket) {
    if (ticket != epoch) return;
    try {
      if (sources == null) {
        sources = new ArrayList<>();
        for (List<HomeUnboxSource> group : app.marketHomeFeeds.buildHomeUnboxSources())
          for (HomeUnboxSource s : group)
            if ("Case".equals(s.kind) || "Souvenir package".equals(s.kind)) sources.add(s);
      }
      if (sources.isEmpty()) {
        schedule(ticket);
        return;
      }
      // Choose the physical source family before the source: a larger package catalog must not
      // dominate.
      boolean cases = ThreadLocalRandom.current().nextBoolean();
      List<HomeUnboxSource> family = new ArrayList<>();
      for (HomeUnboxSource s : sources) if (cases == "Case".equals(s.kind)) family.add(s);
      if (family.isEmpty()) family = sources;
      HomeUnboxSource source = family.get(ThreadLocalRandom.current().nextInt(family.size()));
      CaseType ct = null;
      for (CaseType c : CaseType.values())
        if (c.crateName.equals(source.name) || c.catalogCrateName().equals(source.name)) {
          ct = c;
          break;
        }
      final CaseType container = ct;
      HomeUnboxEntry entry = app.marketHomeFeeds.rollHomeUnboxSource(source, false);
      SwingUtilities.invokeLater(
          () -> {
            if (ticket != epoch) return;
            if (!homeVisible()) {
              updateClock();
              return;
            }
            try {
              if (container != null && app.globalSupply.fakeOpening(container, entry))
                publish(entry);
            } finally {
              schedule(ticket);
            }
          });
    } catch (RuntimeException ex) {
      System.err.println("Simulated opening skipped: " + ex.getMessage());
      schedule(ticket);
    }
  }

  void publish(HomeUnboxEntry entry) {
    entry.record.timestamp = System.currentTimeMillis();
    recent.addFirst(entry);
    while (recent.size() > 100) recent.removeLast();
    app.coreUtilities.addSaleHistoryRecord(
        app.recentUnboxedSkins, entry.record, hGui.MAX_SALES_HISTORY);
    for (MarketHomeUnboxFeed feed : new ArrayList<>(listeners))
      if (feed.isShowing()) feed.acceptEntry(entry);
  }

  void attach(MarketHomeUnboxFeed feed) {
    boolean fresh = !listeners.contains(feed);
    if (fresh) listeners.add(feed);
    if (fresh || feed.entries.isEmpty()) {
      feed.entries.clear();
      for (HomeUnboxEntry e : recent) {
        feed.entries.add(e);
        app.marketHomeFeeds.getHomeUnboxArtwork(e.record.skinName, e.record.condition);
        if (feed.entries.size() >= hGui.MARKET_HOME_UNBOX_ROWS + 1) break;
      }
      feed.repaint();
    }
    updateClock();
  }

  void detach(MarketHomeUnboxFeed feed) {
    listeners.remove(feed);
    updateClock();
  }
}
