package blahblah;

import blahblah.hGui.*;
import java.awt.*;
import java.awt.event.*;
import java.util.LinkedHashMap;
import java.util.Map;
import javax.swing.*;

/** Extracted reusable model or widget; behavior retained from the original source. */
final class HomeUnboxTier {
  final String rarity;
  final double weight;
  final Map<String, Double> skins;

  HomeUnboxTier(String rarity, double weight, Map<String, Double> skins) {
    this.rarity = rarity;
    this.weight = weight;
    this.skins = java.util.Collections.unmodifiableMap(new LinkedHashMap<>(skins));
  }
}
