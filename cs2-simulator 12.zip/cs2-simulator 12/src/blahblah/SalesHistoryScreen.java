package blahblah;

import blahblah.hGui.*;
import java.awt.*;
import java.awt.event.*;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;
import javax.swing.*;

/** Sales History Screen: focused feature implementation. */
final class SalesHistoryScreen {
  private final hGui app;

  SalesHistoryScreen(hGui app) {
    this.app = app;
  }

  String getSaleHistoryKey(String skinName) {
    String normalized =
        app.activitySimulationService.cleanStatTrakEncoding(
            app.leaderboardService.normalizeSkinName(skinName));
    return normalized.replaceAll("\\s*\\(Blue Gem [^)]+\\)$", "").trim();
  }

  void recordSaleRecord(SaleRecord sale) {
    if (sale == null || sale.skinName == null) return;

    String skinName = app.salesHistoryScreen.getSaleHistoryKey(sale.skinName);
    sale.skinName = skinName;
    if (sale.condition == null || sale.condition.trim().isEmpty()) sale.condition = "Unknown";
    if (sale.timestamp <= 0L) sale.timestamp = System.currentTimeMillis();
    if (sale.buyerName == null || sale.buyerName.trim().isEmpty())
      sale.buyerName = SaleRecord.generateRandomUsername();
    if (sale.buyerAvatar == null) sale.buyerAvatar = SaleRecord.generateRandomAvatar();
    if (sale.marketplaceName == null || sale.marketplaceName.trim().isEmpty())
      sale.marketplaceName = "Marketplace";

    // Retain every registered skin; each skin/condition is independently bounded.
    if (!app.salesHistory.containsKey(skinName)) {
      app.salesHistory.put(skinName, new HashMap<>());
    }
    Map<String, ArrayList<SaleRecord>> skinSales = app.salesHistory.get(skinName);

    if (!skinSales.containsKey(sale.condition)) {
      skinSales.put(sale.condition, new ArrayList<>());
    }

    ArrayList<SaleRecord> conditionSales = skinSales.get(sale.condition);
    conditionSales.add(sale);

    if (conditionSales.size() > 200) {
      conditionSales.remove(0);
    }
  }

  JPanel createRecentUnboxedPanel() {
    JPanel panel = new JPanel(new BorderLayout());
    panel.setBackground(new Color(35, 35, 40));

    JPanel header = new JPanel(new BorderLayout());
    header.setBackground(new Color(45, 45, 50));
    header.setBorder(BorderFactory.createEmptyBorder(8, 10, 8, 10));
    JLabel titleLabel = new JLabel("Recently Unboxed Skins");
    titleLabel.setForeground(Color.WHITE);
    titleLabel.setFont(new Font("Consolas", Font.BOLD, 12));
    header.add(titleLabel, BorderLayout.WEST);
    panel.add(header, BorderLayout.NORTH);

    JPanel unboxContainer = new JPanel();
    unboxContainer.setLayout(new BoxLayout(unboxContainer, BoxLayout.Y_AXIS));
    unboxContainer.setBackground(new Color(35, 35, 40));
    unboxContainer.setBorder(BorderFactory.createEmptyBorder(10, 10, 10, 10));

    JScrollPane scroll = new JScrollPane(unboxContainer);
    scroll.getVerticalScrollBar().setUnitIncrement(16);
    scroll.setBorder(null);
    scroll.getViewport().setBackground(new Color(35, 35, 40));
    panel.add(scroll, BorderLayout.CENTER);

    JLabel statsLabel = new JLabel("No case unboxes yet", SwingConstants.CENTER);
    statsLabel.setForeground(Color.CYAN);
    statsLabel.setFont(new Font("Arial", Font.BOLD, 12));
    statsLabel.setBorder(BorderFactory.createEmptyBorder(6, 6, 6, 6));
    panel.add(statsLabel, BorderLayout.SOUTH);

    Runnable updateUnboxes =
        () -> {
          unboxContainer.removeAll();
          ArrayList<SaleRecord> filtered = new ArrayList<>(app.recentUnboxedSkins);
          filtered.sort((a, b) -> Long.compare(b.timestamp, a.timestamp));
          int limit = Math.min(100, filtered.size());
          double totalValue = 0.0;
          for (int i = 0; i < limit; i++) {
            SaleRecord unbox = filtered.get(i);
            totalValue += unbox.price;
            unboxContainer.add(app.salesHistoryScreen.createUnboxedSkinCard(unbox));
            unboxContainer.add(Box.createRigidArea(new Dimension(0, 5)));
          }
          statsLabel.setText(
              String.format(
                  "Showing %d / %d recent unboxes  |  Displayed value: $%.2f",
                  limit, app.recentUnboxedSkins.size(), totalValue));
          unboxContainer.revalidate();
          unboxContainer.repaint();
        };

    if (app.salesUpdateTimer != null) {
      app.salesUpdateTimer.stop();
    }
    app.salesUpdateTimer =
        new javax.swing.Timer(
            hGui.SALES_UI_UPDATE_INTERVAL,
            e -> {
              if (panel.isShowing()) updateUnboxes.run();
            });
    app.salesUpdateTimer.start();
    updateUnboxes.run();
    return panel;
  }

  JPanel createSkinRecentSalesPanel(String skinName, String[] selectedConditionToken) {
    JPanel panel = new JPanel(new BorderLayout());
    panel.setBackground(new Color(35, 35, 40));

    JPanel header = new JPanel(new BorderLayout());
    header.setBackground(new Color(45, 45, 50));
    header.setBorder(BorderFactory.createEmptyBorder(8, 10, 8, 10));

    JLabel titleLabel = new JLabel("Sales History · Simulated Market");
    titleLabel.setForeground(Color.WHITE);
    titleLabel.setFont(new Font("Consolas", Font.BOLD, 12));
    header.add(titleLabel, BorderLayout.WEST);

    JPanel filterPanel = new JPanel(new FlowLayout(FlowLayout.RIGHT, 8, 0));
    filterPanel.setOpaque(false);

    JComboBox<String> variantBox =
        new JComboBox<>(new String[] {"All Variants", "StatTrak Only", "Non-StatTrak Only"});
    app.uiWidgets.styleComboBox(variantBox);
    filterPanel.add(variantBox);

    JComboBox<String> conditionBox =
        new JComboBox<>(
            app.floatRules.getAvailableConditions(
                app.marketGroupingService.getBaseMarketKey(skinName)));
    conditionBox.insertItemAt("All Conditions", 0);
    conditionBox.setSelectedIndex(0);
    app.uiWidgets.styleComboBox(conditionBox);
    filterPanel.add(conditionBox);
    header.add(filterPanel, BorderLayout.EAST);

    panel.add(header, BorderLayout.NORTH);

    JPanel salesContainer = new JPanel();
    salesContainer.setLayout(new BoxLayout(salesContainer, BoxLayout.Y_AXIS));
    salesContainer.setBackground(new Color(35, 35, 40));
    salesContainer.setBorder(BorderFactory.createEmptyBorder(10, 10, 10, 10));

    JScrollPane scroll = new JScrollPane(salesContainer);
    scroll.getVerticalScrollBar().setUnitIncrement(16);
    scroll.setBorder(null);
    scroll.getViewport().setBackground(new Color(35, 35, 40));
    panel.add(scroll, BorderLayout.CENTER);

    JLabel statsLabel = new JLabel("No recorded sales yet", SwingConstants.CENTER);
    statsLabel.setForeground(Color.CYAN);
    statsLabel.setFont(new Font("Arial", Font.BOLD, 12));
    statsLabel.setBorder(BorderFactory.createEmptyBorder(6, 6, 6, 6));
    panel.add(statsLabel, BorderLayout.SOUTH);

    if (skinName.startsWith("StatTrak ")) {
      variantBox.setSelectedItem("StatTrak Only");
    }
    final String[] appliedConditionToken = {null};
    final boolean[] applyingFilterToken = {false};

    Runnable refreshSales =
        () -> {
          salesContainer.removeAll();

          if (selectedConditionToken != null
              && selectedConditionToken[0] != null
              && !selectedConditionToken[0].equals(appliedConditionToken[0])) {
            String token = selectedConditionToken[0];
            boolean statTrakToken = token.startsWith("StatTrak ");
            String conditionToken =
                statTrakToken ? token.replaceFirst("^StatTrak\\s+", "").trim() : token;
            appliedConditionToken[0] = token;
            applyingFilterToken[0] = true;
            variantBox.setSelectedItem(statTrakToken ? "StatTrak Only" : "Non-StatTrak Only");
            conditionBox.setSelectedItem(conditionToken);
            applyingFilterToken[0] = false;
          }

          String selectedCondition = (String) conditionBox.getSelectedItem();
          String selectedVariant = (String) variantBox.getSelectedItem();
          ArrayList<SaleRecord> matchingSales =
              app.marketHistoryScreen.getRecordedSalesForSkinView(
                  skinName, selectedVariant, selectedCondition);

          if (matchingSales.isEmpty()) {
            JLabel emptyLabel =
                new JLabel("No recorded sales for this item yet", SwingConstants.CENTER);
            emptyLabel.setForeground(Color.LIGHT_GRAY);
            emptyLabel.setFont(new Font("Arial", Font.BOLD, 16));
            emptyLabel.setBorder(BorderFactory.createEmptyBorder(40, 0, 40, 0));
            salesContainer.add(emptyLabel);
            statsLabel.setText("No recorded sales yet");
          } else {
            double avgPrice =
                matchingSales.stream().mapToDouble(s -> s.price).average().orElse(0.0);
            statsLabel.setText(
                String.format(
                    "Recent sales: %d | Average: $%.2f | Estimated volume: %.1f/min",
                    matchingSales.size(),
                    avgPrice,
                    app.salesSimulationService.getSimulatedSalesRateForView(
                        skinName, selectedVariant, selectedCondition)));
            int visibleSales = 0;
            for (SaleRecord sale : matchingSales) {
              if (visibleSales++ >= 60) break;
              salesContainer.add(app.salesHistoryScreen.createSaleCard(sale));
              salesContainer.add(Box.createRigidArea(new Dimension(0, 5)));
            }
          }

          salesContainer.revalidate();
          salesContainer.repaint();
        };

    variantBox.addActionListener(
        e -> {
          if (!applyingFilterToken[0]) refreshSales.run();
        });
    conditionBox.addActionListener(
        e -> {
          if (!applyingFilterToken[0]) refreshSales.run();
        });

    javax.swing.Timer refreshTimer =
        new javax.swing.Timer(hGui.SALES_UI_UPDATE_INTERVAL, e -> refreshSales.run());
    if (panel.isShowing()) refreshTimer.start();
    panel.addHierarchyListener(
        e -> {
          if ((e.getChangeFlags() & java.awt.event.HierarchyEvent.SHOWING_CHANGED) != 0) {
            if (panel.isShowing()) refreshTimer.start();
            else refreshTimer.stop();
          }
        });
    panel.addComponentListener(
        new ComponentAdapter() {
          @Override
          public void componentShown(ComponentEvent e) {
            refreshSales.run();
          }
        });

    refreshSales.run();
    return panel;
  }

  JPanel createSaleCard(SaleRecord sale) {
    return app.salesHistoryScreen.createSaleCard(
        sale, sale.simulatedMarketSale ? "SIMULATED BUYER: " : "BUYER: ");
  }

  JPanel createUnboxedSkinCard(SaleRecord sale) {
    return app.salesHistoryScreen.createSaleCard(sale, "UNBOXED BY: ");
  }

  JPanel createSaleCard(SaleRecord sale, String actorPrefixText) {
    JPanel card = new JPanel(new BorderLayout());
    card.setBackground(new Color(50, 50, 55));
    card.setMaximumSize(new Dimension(Integer.MAX_VALUE, 88));
    card.setPreferredSize(new Dimension(500, 88));

    String cleanName = sale.skinName.replace("StatTrak ", "").trim();
    String rarity =
        app.itemMetadataService.getSkinRarity(
            cleanName.replaceAll("[^a-zA-Z0-9\\s\\-|]+", "").trim());
    Color borderColor = app.itemInspectionScreen.getRarityColor(rarity);

    if (sale.specialVariant != null && sale.specialVariant.contains("Blue Gem")) {
      borderColor = Color.CYAN;
    }

    card.setBorder(
        BorderFactory.createCompoundBorder(
            BorderFactory.createLineBorder(borderColor, 2),
            BorderFactory.createEmptyBorder(3, 6, 3, 6)));

    String skinNameForImage = cleanName;
    if (skinNameForImage.contains("(Blue Gem")) {
      skinNameForImage =
          skinNameForImage.substring(0, skinNameForImage.indexOf("(Blue Gem")).trim();
    }

    JLabel imageLabel = new JLabel("Loading image...", SwingConstants.CENTER);
    imageLabel.setPreferredSize(new Dimension(72, 50));
    imageLabel.setForeground(Theme.TEXT_DIM);
    imageLabel.setBackground(new Color(30, 30, 35));
    imageLabel.setOpaque(true);
    // Register the card so remote catalog artwork replaces this label as soon as it downloads.
    app.artworkService.getSkinImageFromName(skinNameForImage, sale.condition, imageLabel, 72, 50);
    card.add(imageLabel, BorderLayout.WEST);

    JPanel detailsPanel = new JPanel(new GridLayout(4, 1, 0, 0));
    detailsPanel.setBackground(new Color(50, 50, 55));
    detailsPanel.setBorder(BorderFactory.createEmptyBorder(3, 8, 3, 8));

    JLabel nameLabel = new JLabel(sale.skinName);
    if (sale.skinName.contains("StatTrak")) {
      nameLabel.setForeground(new Color(255, 153, 51));
      nameLabel.setFont(new Font("Consolas", Font.BOLD, 11));
    } else {
      nameLabel.setForeground(Color.WHITE);
      nameLabel.setFont(new Font("Consolas", Font.BOLD, 11));
    }

    boolean showFloat = app.itemMetadataService.shouldShowFloatForItem(cleanName, rarity);
    JLabel condLabel =
        new JLabel(
            showFloat
                ? sale.condition + "  Float: " + String.format("%.4f", sale.itemFloat)
                : "Agent");
    condLabel.setForeground(Color.LIGHT_GRAY);
    condLabel.setFont(new Font("Consolas", Font.PLAIN, 10));

    JPanel buyerPanel = new JPanel(new FlowLayout(FlowLayout.LEFT, 3, 0));
    buyerPanel.setBackground(new Color(50, 50, 55));
    JLabel buyerPrefix = new JLabel(actorPrefixText);
    buyerPrefix.setFont(new Font("Consolas", Font.BOLD, 9));
    buyerPrefix.setForeground(Color.LIGHT_GRAY);
    buyerPanel.add(buyerPrefix);
    if (sale.buyerAvatar != null) {
      JLabel avatarLabel =
          new JLabel(new ImageIcon(HighQualityImages.fit(sale.buyerAvatar, 16, 16)));
      buyerPanel.add(avatarLabel);
    }
    JLabel usernameLabel = new JLabel(sale.buyerName != null ? sale.buyerName : "Unknown");
    usernameLabel.setFont(new Font("Consolas", Font.PLAIN, 9));
    usernameLabel.setForeground(Color.WHITE);
    buyerPanel.add(usernameLabel);

    JPanel marketPanel = new JPanel(new FlowLayout(FlowLayout.LEFT, 3, 0));
    marketPanel.setBackground(new Color(50, 50, 55));
    boolean unboxedCard =
        actorPrefixText != null && actorPrefixText.toUpperCase().contains("UNBOXED");
    JLabel marketPrefix = new JLabel(unboxedCard ? "SOURCE: " : "MARKET: ");
    marketPrefix.setFont(new Font("Consolas", Font.BOLD, 9));
    marketPrefix.setForeground(Color.LIGHT_GRAY);
    marketPanel.add(marketPrefix);
    String marketText =
        unboxedCard
            ? (sale.marketplaceName != null && !sale.marketplaceName.trim().isEmpty()
                ? sale.marketplaceName
                : "Case Unbox")
            : (sale.marketplaceName != null && !sale.marketplaceName.trim().isEmpty()
                ? sale.marketplaceName
                : "Marketplace");
    JLabel marketLabel = new JLabel(marketText);
    marketLabel.setFont(new Font("Consolas", Font.PLAIN, 9));
    marketLabel.setForeground(new Color(130, 210, 255));
    marketPanel.add(marketLabel);

    detailsPanel.add(nameLabel);
    detailsPanel.add(condLabel);
    detailsPanel.add(buyerPanel);
    detailsPanel.add(marketPanel);

    card.add(detailsPanel, BorderLayout.CENTER);

    JPanel rightPanel = new JPanel(new GridLayout(2, 1));
    rightPanel.setBackground(new Color(50, 50, 55));
    rightPanel.setBorder(BorderFactory.createEmptyBorder(10, 10, 10, 10));

    JLabel priceLabel = new JLabel("$" + String.format("%.2f", sale.price));
    priceLabel.setForeground(Color.YELLOW);
    priceLabel.setFont(new Font("Arial", Font.BOLD, 18));
    priceLabel.setHorizontalAlignment(SwingConstants.RIGHT);

    long secondsAgo = (System.currentTimeMillis() - sale.timestamp) / 1000;
    String timeStr;
    if (secondsAgo < 60) {
      timeStr = secondsAgo + "s ago";
    } else if (secondsAgo < 3600) {
      timeStr = (secondsAgo / 60) + "m ago";
    } else {
      timeStr = (secondsAgo / 3600) + "h ago";
    }

    JLabel timeLabel = new JLabel(timeStr);
    timeLabel.setForeground(Color.LIGHT_GRAY);
    timeLabel.setFont(new Font("Arial", Font.PLAIN, 11));
    timeLabel.setHorizontalAlignment(SwingConstants.RIGHT);

    rightPanel.add(priceLabel);
    rightPanel.add(timeLabel);

    card.add(rightPanel, BorderLayout.EAST);

    return card;
  }
}
