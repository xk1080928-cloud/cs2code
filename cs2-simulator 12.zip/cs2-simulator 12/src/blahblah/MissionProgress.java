package blahblah;

import blahblah.hGui.*;
import java.awt.*;
import java.awt.event.*;
import javax.swing.*;

/** Extracted reusable model or widget; behavior retained from the original source. */
final class MissionProgress {
  int casesOpened;
  int tradeUps;
  double marketSpent;
  int knivesUnboxed;
  int glovesUnboxed;
  int armouryRedeems;
  int marketSellCount;
  int covertsUnboxed;
  int classifiedsUnboxed;
}
