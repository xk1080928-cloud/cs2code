package blahblah;

import blahblah.hGui.*;
import java.awt.*;
import java.awt.event.*;
import java.util.ArrayList;
import java.util.Comparator;
import java.util.HashSet;
import java.util.List;
import java.util.Set;
import javax.swing.*;

/** Exchange Screens: focused feature implementation. */
final class ExchangeScreens {
  private final hGui app;

  ExchangeScreens(hGui app) {
    this.app = app;
  }

  void navigateExchangeDirectory(InventoryItem sale) {
    app.exchangePendingSale = sale;
    app.storeScreen.open("MARKET");
    if (app.exchangeHostSections == null) app.loadoutScreen.refreshMarketTab();
    app.loadoutScreen.refreshMarketTab();
    app.exchangeHostSections.setSelectedIndex(1);
  }

  void openExchangeMarketplace(MarketplaceProfile p, String search, InventoryItem sale) {
    app.storeScreen.open("MARKET");
    if (app.exchangeHostSections == null) app.loadoutScreen.refreshMarketTab();
    String key = p.name;
    JPanel old = app.exchangeOpenSites.remove(key);
    if (old != null) app.exchangeHostSections.remove(old);
    JPanel site = app.exchangeScreens.createExchangeMarketplace(p, search, sale);
    app.exchangeOpenSites.put(key, site);
    app.exchangeHostSections.addTab(p.name, site);
    app.exchangeHostSections.setSelectedComponent(site);
  }

  JPanel createExchangeMarketplace(MarketplaceProfile p, String initialSearch, InventoryItem sale) {
    JPanel root = app.exchangeWidgets.exchangePanel(p, new BorderLayout(0, 0));
    root.setName("marketplaceSite-" + p.name);
    Color accent = app.exchangeWidgets.exchangeAccent(p);
    JPanel mast = app.exchangeWidgets.exchangePanel(p, new BorderLayout(20, 0));
    mast.setBorder(
        BorderFactory.createCompoundBorder(
            BorderFactory.createMatteBorder(0, 0, 2, 0, accent),
            BorderFactory.createEmptyBorder(16, 22, 15, 22)));
    JLabel wordmark =
        app.exchangeWidgets.exchangeLabel(p.name.toUpperCase(java.util.Locale.ROOT), 26, accent);
    wordmark.setFont(
        new Font(
            app.exchangeTransactionService.exchangeStyle(p) == 16 ? "Monospaced" : "SansSerif",
            Font.BOLD,
            26));
    mast.add(wordmark, BorderLayout.WEST);
    mast.add(
        app.exchangeWidgets.exchangeLabel("SIMULATED MARKETPLACE   /   USD", 12, Theme.TEXT_DIM),
        BorderLayout.CENTER);
    JPanel mastRight = app.cs2Screens.cs2Glass(new FlowLayout(FlowLayout.RIGHT));
    mastRight.add(
        app.exchangeWidgets.exchangeButton(
            p,
            "← Marketplaces",
            () -> {
              app.exchangeHostSections.remove(root);
              app.exchangeOpenSites.remove(p.name);
              app.exchangeSiteRefresh.remove(p.name);
              app.exchangeHostSections.setSelectedIndex(1);
            }));
    mast.add(mastRight, BorderLayout.EAST);
    root.add(mast, BorderLayout.NORTH);
    JTabbedPane tabs = new JTabbedPane();
    tabs.setName("marketplaceSiteTabs");
    app.exchangeWidgets.styleExchangeTabs(tabs, p);
    app.marketSiteLayouts.navigation(p, tabs);
    tabs.setBackground(app.exchangeWidgets.exchangeBackground(p));
    tabs.setForeground(Color.WHITE);
    tabs.setFont(app.cs2Screens.cs2Font(Font.BOLD, 14));
    JPanel home = app.exchangeScreens.createExchangeHome(p, tabs);
    tabs.addTab("Home", home);
    JPanel buy =
        app.exchangeCatalogScreens.createExchangeBuy(p, initialSearch == null ? "" : initialSearch);
    tabs.addTab("Buy", buy);
    JPanel sell = app.exchangeCatalogScreens.createExchangeSell(p, sale);
    tabs.addTab("Sell", sell);
    if (ExchangeStockService.supportsExchangeSwap(p.name))
      tabs.addTab(
          app.exchangeWidgets.exchangeSwapTab(p), app.exchangeCatalogScreens.createExchangeSwap(p));
    root.add(tabs);
    tabs.addChangeListener(
        e -> {
          Component selected = tabs.getSelectedComponent();
          if (selected instanceof JComponent) {
            Object run = ((JComponent) selected).getClientProperty("refreshExchange");
            if (run instanceof Runnable) ((Runnable) run).run();
          }
        });
    JPanel footer = app.exchangeWidgets.exchangePanel(p, new BorderLayout());
    footer.setBorder(BorderFactory.createEmptyBorder(8, 22, 8, 22));
    footer.add(
        app.exchangeWidgets.exchangeLabel(
            app.marketplacePricing.label(p)
                + "  •  "
                + p.type
                + "  •  "
                + (p.type.equals("P2P")
                    ? "Skin purchases use trade delivery"
                    : "Instant skin delivery")
                + String.format(
                    "  •  Quick-sell deduction %.0f%%  •  Listing fee %.1f%%",
                    app.exchangeTransactionService.exchangeQuickSellLoss(p) * 100,
                    app.exchangeTransactionService.exchangeListingFee(p) * 100),
            11,
            Theme.TEXT_DIM));
    root.add(footer, BorderLayout.SOUTH);
    if (sale != null) tabs.setSelectedIndex(2);
    else if (initialSearch != null && !initialSearch.isEmpty()) tabs.setSelectedIndex(1);
    return root;
  }

  JPanel createExchangeHome(MarketplaceProfile p, JTabbedPane tabs) {
    int style = app.exchangeTransactionService.exchangeStyle(p);
    Color accent = app.exchangeWidgets.exchangeAccent(p);
    JPanel outer = app.exchangeWidgets.exchangePanel(p, new BorderLayout());
    ScrollablePanel content = new ScrollablePanel();
    content.setLayout(new BoxLayout(content, BoxLayout.Y_AXIS));
    content.setBackground(app.exchangeWidgets.exchangeBackground(p));
    content.setBorder(BorderFactory.createEmptyBorder(24, 26, 24, 26));
    JPanel hero = app.exchangeWidgets.exchangePanel(p, new BorderLayout(26, 16));
    hero.setBorder(
        BorderFactory.createCompoundBorder(
            BorderFactory.createMatteBorder(style == 12 ? 2 : 0, 0, 1, 0, accent),
            BorderFactory.createEmptyBorder(24, 22, 24, 22)));
    JPanel words = app.cs2Screens.cs2Glass(new GridLayout(0, 1, 0, 10));
    words.add(
        app.exchangeWidgets.exchangeLabel(
            app.exchangeWidgets.exchangeTagline(p), style == 16 ? 26 : 32, Color.WHITE));
    words.add(
        app.exchangeWidgets.exchangeLabel(
            new String[] {
                  "DISCOVER / COLLECT / PLAY",
                  "Inventory to inventory. Transparent values.",
                  "A global catalog, one trading floor.",
                  "No noise. Just the next skin.",
                  "Fresh arrivals for every playstyle.",
                  "Buy, sell or swap your way.",
                  "The dock is open. Your loadout awaits.",
                  "Curated drops for your collection.",
                  "Premium finds, clear prices.",
                  "Peer offers. Live inventory.",
                  "Float-first collecting.",
                  "The personal collection concierge.",
                  "CONNECT. SELECT. EXCHANGE.",
                  "Explore the hidden side of your inventory.",
                  "Hot arrivals. New possibilities.",
                  "Precision picks, ice-cold finishes.",
                  "STATUS: ONLINE  /  STOCK: LIVE",
                  "Collect something extraordinary."
                }
                [style],
            14,
            accent));
    hero.add(words, style % 3 == 0 ? BorderLayout.CENTER : BorderLayout.NORTH);
    List<MarketListing> stock =
        app.exchangeSiteStock.getOrDefault(p.name, java.util.Collections.emptyList());
    int total = app.exchangeStockService.countStock(stock);
    JPanel stats =
        app.cs2Screens.cs2Glass(
            new GridLayout(style % 3 == 1 ? 3 : 1, style % 3 == 1 ? 1 : 3, 12, 8));
    stats.add(
        app.marketHomeScreen.createMarketplaceHomeStatCard(
            "AVAILABLE", String.format("%,d", total), accent));
    stats.add(
        app.marketHomeScreen.createMarketplaceHomeStatCard(
            "QUICK SELL",
            String.format(
                "%.0f%% payout",
                100 * (1 - app.exchangeTransactionService.exchangeQuickSellLoss(p))),
            accent));
    stats.add(
        app.marketHomeScreen.createMarketplaceHomeStatCard(
            "LISTING FEE",
            String.format("%.1f%%", 100 * app.exchangeTransactionService.exchangeListingFee(p)),
            accent));
    if (style % 3 == 1) stats.setPreferredSize(new Dimension(230, 200));
    hero.add(stats, style % 3 == 1 ? BorderLayout.EAST : BorderLayout.SOUTH);
    hero.setMaximumSize(new Dimension(Integer.MAX_VALUE, 320));
    content.add(app.exchangeHomeScreen.createExchangeSignature(p, tabs, hero));
    content.add(Box.createVerticalStrut(18));
    JPanel shortcuts =
        app.cs2Screens.cs2Glass(
            new FlowLayout(style % 2 == 0 ? FlowLayout.LEFT : FlowLayout.CENTER, 10, 4));
    for (String category :
        new String[] {"Knives", "Gloves", "Rifles", "Pistols", "Cases", "Agents"})
      shortcuts.add(
          app.exchangeWidgets.exchangeButton(
              p,
              category,
              () -> {
                tabs.setSelectedIndex(1);
                JPanel buy = (JPanel) tabs.getComponentAt(1);
                Object picker = buy.getClientProperty("pickCategory");
                if (picker instanceof java.util.function.Consumer) {
                  @SuppressWarnings("unchecked")
                  java.util.function.Consumer<String> categoryPicker =
                      (java.util.function.Consumer<String>) picker;
                  categoryPicker.accept(category);
                }
              }));
    shortcuts.setMaximumSize(new Dimension(Integer.MAX_VALUE, 64));
    content.add(shortcuts);
    JPanel heading = app.cs2Screens.cs2Glass(new BorderLayout());
    heading.setBorder(BorderFactory.createEmptyBorder(12, 0, 12, 0));
    heading.add(
        app.exchangeWidgets.exchangeLabel(
            new String[] {
                  "Featured upgrades",
                  "The trading desk",
                  "Market movers",
                  "Fresh listings",
                  "Loadout essentials",
                  "Explore Skin.Land",
                  "Ready to ship",
                  "The vault selection",
                  "Counter-Strike 2 market",
                  "Peer picks",
                  "Collector’s decimals",
                  "Concierge picks",
                  "THE LIVE GRID",
                  "Mirage discoveries",
                  "Trending heat",
                  "Frost selections",
                  "LATEST RELAYS",
                  "The velvet edit"
                }
                [style],
            22,
            Color.WHITE));
    heading.add(
        app.exchangeWidgets.exchangeButton(p, "Browse all  →", () -> tabs.setSelectedIndex(1)),
        BorderLayout.EAST);
    heading.setMaximumSize(new Dimension(Integer.MAX_VALUE, 60));
    content.add(heading);
    JPanel featured = app.cs2Screens.cs2Grid(5, style == 8 ? 1 : 12, 12);
    List<MarketListing> picks = new ArrayList<>();
    Set<String> names = new HashSet<>();
    List<MarketListing> sorted = new ArrayList<>(stock);
    sorted.sort(Comparator.comparingDouble(MarketListing::getPrice).reversed());
    for (MarketListing l : sorted)
      if (l.quantity > 0 && names.add(l.item.name)) {
        picks.add(l);
        if (picks.size() == 5) break;
      }
    for (MarketListing l : picks)
      featured.add(
          app.exchangeCatalogScreens.createExchangeListingCard(
              p, l, () -> tabs.setSelectedIndex(1), false));
    featured.setMaximumSize(new Dimension(Integer.MAX_VALUE, 270));
    content.add(featured);
    content.add(Box.createVerticalStrut(20));
    JPanel editorial = app.cs2Screens.cs2Glass(new GridLayout(1, style % 2 == 0 ? 3 : 2, 14, 0));
    String[][] stories = {
      {"Discover your finish", "Compare offers across the whole catalog."},
      {"Your inventory, your choice", "List at your price or take a quick-sell quote."},
      {"Transparent by design", "No real-money trades. All balances are simulated."}
    };
    for (int n = 0; n < (style % 2 == 0 ? 3 : 2); n++) {
      JPanel story = app.exchangeWidgets.exchangePanel(p, new BorderLayout(0, 12));
      story.setBorder(
          BorderFactory.createCompoundBorder(
              BorderFactory.createMatteBorder(
                  0, style % 2 == 0 ? 3 : 0, style % 2 == 1 ? 2 : 0, 0, accent),
              BorderFactory.createEmptyBorder(18, 16, 18, 16)));
      story.add(
          app.exchangeWidgets.exchangeLabel(stories[(n + style) % 3][0], 17, accent),
          BorderLayout.NORTH);
      story.add(app.exchangeWidgets.exchangeLabel(stories[(n + style) % 3][1], 12, Theme.TEXT_DIM));
      editorial.add(story);
    }
    editorial.setMaximumSize(new Dimension(Integer.MAX_VALUE, 120));
    content.add(editorial);
    outer.add(app.exchangeWidgets.exchangeScroll(content));
    outer.putClientProperty("homeStyle", style);
    return outer;
  }
}
