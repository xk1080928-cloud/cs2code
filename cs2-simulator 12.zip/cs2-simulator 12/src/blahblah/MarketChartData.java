package blahblah;

import blahblah.hGui.*;
import java.awt.*;
import java.awt.event.*;
import java.math.BigDecimal;
import java.math.RoundingMode;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import javax.swing.*;

/** Market Chart Data: focused feature implementation. */
final class MarketChartData {
  private final hGui app;

  MarketChartData(hGui app) {
    this.app = app;
  }

  JPanel createMyListingCard(MarketListing listing) {
    Color BG_INFO = new Color(22, 22, 30);

    JPanel card = new JPanel(new BorderLayout());
    card.setBackground(Theme.BG_CARD);
    card.setBorder(
        BorderFactory.createCompoundBorder(
            BorderFactory.createLineBorder(
                app.itemInspectionScreen.getRarityColor(listing.item.rarity), 2),
            BorderFactory.createEmptyBorder(4, 4, 4, 4)));

    JLabel ownListingArtwork = new JLabel("", SwingConstants.CENTER);
    app.artworkService.getSkinImageFromName(
        listing.item.name, listing.item.condition, ownListingArtwork, 130, 88);
    card.add(ownListingArtwork, BorderLayout.CENTER);

    String rarity = listing.item.rarity.replace("StatTrak ", "");
    boolean showFloat = app.itemMetadataService.shouldShowFloatForItem(listing.item.name, rarity);
    JPanel info = new JPanel(new GridLayout(showFloat ? 6 : 5, 1));
    info.setBackground(BG_INFO);

    JLabel name = new JLabel(listing.item.name, SwingConstants.CENTER);
    name.setForeground(Color.WHITE);

    JLabel price =
        new JLabel("$" + String.format("%.2f", listing.getPrice()), SwingConstants.CENTER);
    price.setForeground(Color.YELLOW);

    JLabel floatLabel = null;
    if (showFloat) {
      floatLabel =
          new JLabel(String.format("Float: %.10f", listing.item.itemFloat), SwingConstants.CENTER);
      floatLabel.setForeground(Color.CYAN);
    }

    JLabel time = new JLabel("Sells in: " + listing.timeRemaining + "s", SwingConstants.CENTER);
    time.setForeground(Color.CYAN);

    JLabel cond = new JLabel(listing.item.condition, SwingConstants.CENTER);
    cond.setForeground(Color.LIGHT_GRAY);

    JButton cancelBtn = new JButton("Cancel Listing");
    cancelBtn.addMouseListener(
        new MouseAdapter() {
          @Override
          public void mousePressed(MouseEvent e) {}
        });
    cancelBtn.addActionListener(
        e -> {
          app.activeListings.remove(listing);
          listing.quantity = 0;
          String cancelledKey =
              listing.item.isStattrak ? "StatTrak " + listing.item.name : listing.item.name;
          ArrayList<MarketListing> cancelledBucket = app.globalMarketListings.get(cancelledKey);
          if (cancelledBucket != null) cancelledBucket.remove(listing);
          app.marketStockService.invalidateGroupedMarketListingsCache();
          app.ownershipHistoryService.addItemHistory(
              listing.item,
              System.currentTimeMillis(),
              "Listing Cancelled",
              "market listing cancelled by YOU",
              "YOU");
          app.containerMarketService.restore(listing.item);
          app.caseRollService.writeStats();
          BigDecimal newInventoryValue =
              BigDecimal.valueOf(app.inventoryValue).setScale(2, RoundingMode.HALF_UP);
          app.totalInventoryValueLabel.setText("Inventory Value: $" + newInventoryValue);
          app.bundledArtwork.refreshMainUI();
          app.loadoutScreen.refreshMarketTab();
        });

    info.add(name);
    info.add(cond);
    if (showFloat) info.add(floatLabel);
    info.add(price);
    info.add(time);
    info.add(cancelBtn);

    card.add(info, BorderLayout.SOUTH);
    return card;
  }

  Map<String, ArrayList<Double>> buildMarketTrendHistory(boolean collectionMode) {
    Map<String, ArrayList<Double>> source =
        collectionMode ? app.collectionPriceHistory : app.priceHistory;
    Map<String, ArrayList<Double>> result = new HashMap<>();
    for (Map.Entry<String, ArrayList<Double>> entry : new HashMap<>(source).entrySet()) {
      ArrayList<Double> history = entry.getValue();
      if (history == null || history.isEmpty()) continue;
      ArrayList<Double> copy = new ArrayList<>(history);
      while (copy.size() > 60) copy.remove(0);
      if (copy.size() == 1) copy.add(copy.get(0));
      result.put(entry.getKey(), copy);
    }
    if (!collectionMode) {
      for (Map.Entry<String, Double> entry : new HashMap<>(app.marketPriceMultipliers).entrySet()) {
        result.computeIfAbsent(
            entry.getKey(),
            k -> {
              ArrayList<Double> fallback = new ArrayList<>();
              fallback.add(1.0);
              fallback.add(entry.getValue());
              return fallback;
            });
      }
    }
    return result;
  }

  double toDisplayTrendPercent(double ratio) {
    if (Double.isNaN(ratio) || Double.isInfinite(ratio)) return 0.0;
    double pct = (ratio - 1.0) * 100.0;
    return Math.max(-75.0, Math.min(125.0, pct));
  }

}
