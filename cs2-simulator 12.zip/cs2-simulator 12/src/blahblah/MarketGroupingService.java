package blahblah;

import blahblah.hGui.*;
import java.awt.*;
import java.awt.event.*;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;
import javax.swing.*;

/** Market Grouping Service: focused feature implementation. */
final class MarketGroupingService {
  private final hGui app;
  private volatile Map<String, java.util.List<String>> browseIndex =
      java.util.Collections.emptyMap();
  private volatile int browseIndexSize = -1;

  synchronized void prepareBrowseIndex() {
    if (browseIndexSize == app.globalMarketListings.size()) return;
    Map<String, java.util.List<String>> next = new HashMap<>();
    for (String key : app.globalMarketListings.keySet())
      next.computeIfAbsent(getMarketplaceBrowseKey(key), k -> new ArrayList<>()).add(key);
    browseIndex = next;
    browseIndexSize = app.globalMarketListings.size();
  }

  MarketGroupingService(hGui app) {
    this.app = app;
  }

  JPanel createMyListingsPanel() {
    JPanel panel = new JPanel(new BorderLayout());

    JPanel grid = new JPanel(new GridLayout(0, 3, 10, 10));
    grid.setBackground(Color.DARK_GRAY);
    grid.setBorder(BorderFactory.createEmptyBorder(10, 10, 10, 10));

    JScrollPane scroll = new JScrollPane(grid);

    for (MarketListing listing : app.activeListings) {
      JPanel card = app.marketChartData.createMyListingCard(listing);
      grid.add(card);
    }

    if (app.activeListings.isEmpty()) {
      JLabel emptyLabel = new JLabel("No active listings", SwingConstants.CENTER);
      emptyLabel.setFont(new Font("Arial", Font.BOLD, 24));
      panel.add(emptyLabel, BorderLayout.CENTER);
    } else {
      panel.add(scroll, BorderLayout.CENTER);
    }

    return panel;
  }

  String stripDopplerVariantSuffix(String skinName) {
    if (skinName == null || !skinName.contains("Doppler")) return skinName;
    return skinName
        .replaceAll(
            "\\s*\\((Phase 1|Phase 2|Phase 3|Phase 4|Sapphire|Ruby|Black Pearl|Emerald)\\)$", "")
        .trim();
  }

  String getBaseMarketKey(String skinName) {
    String normalized =
        app.leaderboardService.normalizeSkinName(skinName.replace("StatTrak ", "").trim());
    return app.marketGroupingService.stripDopplerVariantSuffix(normalized);
  }

  ArrayList<MarketListing> getCombinedMarketListings(String skinName) {
    String baseKey = app.marketGroupingService.getBaseMarketKey(skinName);
    ArrayList<MarketListing> combined = new ArrayList<>();
    for (Map.Entry<String, ArrayList<MarketListing>> entry : app.globalMarketListings.entrySet()) {
      if (app.marketGroupingService.getBaseMarketKey(entry.getKey()).equals(baseKey)) {
        combined.addAll(entry.getValue());
      }
    }
    return combined;
  }

  String getMarketplaceBrowseKey(String skinName) {
    String normalized =
        app.leaderboardService.normalizeSkinName(skinName.replace("StatTrak ", "").trim());
    return normalized.contains("Doppler")
        ? normalized
        : app.marketGroupingService.getBaseMarketKey(skinName);
  }

  ArrayList<MarketListing> getCombinedBrowseListings(String skinName) {
    String browseKey = app.marketGroupingService.getMarketplaceBrowseKey(skinName);
    ArrayList<MarketListing> combined = new ArrayList<>();
    prepareBrowseIndex();
    for (String key : browseIndex.getOrDefault(browseKey, java.util.Collections.emptyList())) {
      ArrayList<MarketListing> bucket = app.globalMarketListings.get(key);
      if (bucket != null)
        synchronized (bucket) {
          combined.addAll(bucket);
        }
    }
    if (app.marketPurchaseService.getBlueGemPatterns(browseKey) != null) {
      combined.addAll(app.marketPurchaseService.getOrCreateBlueGemListings(browseKey));
      combined.addAll(
          app.marketPurchaseService.getOrCreateBlueGemListings("StatTrak " + browseKey));
    }
    return combined;
  }

  Map<String, ArrayList<MarketListing>> buildGroupedMarketListings() {
    int totalListings = app.marketStockService.getTotalMarketListingCount();
    if (app.groupedMarketListingsCache != null
        && app.groupedMarketListingsCacheSize == totalListings) {
      return app.groupedMarketListingsCache;
    }
    Map<String, ArrayList<MarketListing>> grouped = new HashMap<>();
    for (Map.Entry<String, ArrayList<MarketListing>> entry : app.globalMarketListings.entrySet()) {
      String baseKey = app.marketGroupingService.getMarketplaceBrowseKey(entry.getKey());
      grouped.computeIfAbsent(baseKey, k -> new ArrayList<>()).addAll(entry.getValue());
    }
    app.groupedMarketListingsCache = grouped;
    app.groupedMarketListingsCacheSize = totalListings;
    return grouped;
  }

  JPanel createMarketplaceOfferHubPanel(
      String skinName,
      ArrayList<MarketListing> listings,
      JFrame parent,
      String[] selectedConditionToken) {
    return app.marketDetailScreen.createMarketplaceOffersPanel(
        skinName, listings, parent, selectedConditionToken);
  }

  JPanel createDopplerVariantCardSection(ArrayList<MarketListing> listings) {
    return null;
  }
}
