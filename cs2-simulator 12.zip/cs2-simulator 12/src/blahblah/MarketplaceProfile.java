package blahblah;

import blahblah.hGui.*;
import java.awt.*;
import java.awt.event.*;
import javax.swing.*;

/** Extracted reusable model or widget; behavior retained from the original source. */
public class MarketplaceProfile {
  String name;
  String type;
  double rating;
  String reviews;
  Color accent;
  Color accentAlt;
  boolean promoted;

  MarketplaceProfile(
      String name,
      String type,
      double rating,
      String reviews,
      Color accent,
      Color accentAlt,
      boolean promoted) {
    this.name = name;
    this.type = type;
    this.rating = rating;
    this.reviews = reviews;
    this.accent = accent;
    this.accentAlt = accentAlt;
    this.promoted = promoted;
  }

  static final MarketplaceProfile[] CATALOG = {
    new MarketplaceProfile(
        "CS.MONEY",
        "INSTANT",
        4.7,
        "8.1K reviews",
        new Color(84, 121, 255),
        new Color(46, 67, 150),
        true),
    new MarketplaceProfile(
        "SkinSwap",
        "P2P",
        4.2,
        "1.7K reviews",
        new Color(120, 223, 79),
        new Color(61, 122, 45),
        false),
    new MarketplaceProfile(
        "DMarket",
        "INSTANT",
        4.4,
        "21.4K reviews",
        new Color(93, 232, 148),
        new Color(38, 122, 78),
        false),
    new MarketplaceProfile(
        "LIS-SKINS",
        "P2P",
        4.9,
        "6.5K reviews",
        new Color(255, 149, 84),
        new Color(142, 74, 44),
        false),
    new MarketplaceProfile(
        "Skins.com",
        "INSTANT",
        4.1,
        "120 reviews",
        new Color(97, 230, 118),
        new Color(46, 120, 58),
        false),
    new MarketplaceProfile(
        "Skin.Land",
        "P2P",
        4.6,
        "3.4K reviews",
        new Color(167, 104, 255),
        new Color(78, 47, 120),
        false),
    new MarketplaceProfile(
        "TradeDock",
        "P2P",
        4.3,
        "940 reviews",
        new Color(255, 196, 74),
        new Color(145, 100, 40),
        false),
    new MarketplaceProfile(
        "VaultDrop",
        "INSTANT",
        4.8,
        "12.2K reviews",
        new Color(64, 198, 255),
        new Color(37, 88, 122),
        true),
    new MarketplaceProfile(
        "Skinport",
        "INSTANT",
        4.8,
        "52.1K reviews",
        new Color(255, 113, 113),
        new Color(120, 48, 48),
        false),
    new MarketplaceProfile(
        "Waxpeer",
        "P2P",
        4.5,
        "4.9K reviews",
        new Color(255, 214, 102),
        new Color(120, 92, 42),
        false),
    new MarketplaceProfile(
        "FloatFlip",
        "INSTANT",
        4.0,
        "680 reviews",
        new Color(112, 255, 229),
        new Color(39, 120, 112),
        false),
    new MarketplaceProfile(
        "HaloSkins",
        "P2P",
        4.7,
        "2.1K reviews",
        new Color(231, 132, 255),
        new Color(97, 50, 120),
        true),
    new MarketplaceProfile(
        "NeonGrid",
        "INSTANT",
        4.6,
        "11.8K reviews",
        new Color(74, 255, 223),
        new Color(20, 88, 86),
        true),
    new MarketplaceProfile(
        "MirageX",
        "P2P",
        4.4,
        "3.8K reviews",
        new Color(255, 186, 92),
        new Color(120, 72, 25),
        false),
    new MarketplaceProfile(
        "EmberSkins",
        "INSTANT",
        4.9,
        "19.6K reviews",
        new Color(255, 104, 67),
        new Color(124, 39, 21),
        true),
    new MarketplaceProfile(
        "FrostBid",
        "P2P",
        4.3,
        "2.6K reviews",
        new Color(146, 214, 255),
        new Color(57, 95, 128),
        false),
    new MarketplaceProfile(
        "RelayMarket",
        "INSTANT",
        4.5,
        "7.3K reviews",
        new Color(190, 255, 112),
        new Color(72, 112, 28),
        false),
    new MarketplaceProfile(
        "VelvetTrade",
        "P2P",
        4.8,
        "5.2K reviews",
        new Color(255, 132, 212),
        new Color(112, 44, 92),
        true)
  };

  static MarketplaceProfile randomForListing() {
    return CATALOG[hGui.random.nextInt(CATALOG.length)];
  }

  static MarketplaceProfile byName(String name) {
    for (MarketplaceProfile profile : CATALOG) {
      if (profile.name.equals(name)) return profile;
    }
    return CATALOG[0];
  }
}
