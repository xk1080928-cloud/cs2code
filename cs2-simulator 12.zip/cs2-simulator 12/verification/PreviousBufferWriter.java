package blahblah;
import java.io.*;import java.math.BigDecimal;
/** Compile against the previous complete release, not current model classes. */
public class PreviousBufferWriter {
  static void write(String path)throws Exception{
    InventoryToolsState s=new InventoryToolsState();s.supply=new GlobalSupply.State();s.supply.seeded=true;
    GlobalSupply.Entry e=new GlobalSupply.Entry();e.quantity=201;e.average=123.45;s.supply.variants.put("fixture",e);
    s.care=new CarePackages.State();s.care.xp=235;s.care.awarded.add("stable-mission");
    s.marketBuffer=new BufferedMarketSupply.State();s.marketBuffer.baseline=10_580_634;s.marketBuffer.aim=10_580_634;s.marketBuffer.relisted=12345;s.marketBuffer.issued=17;s.marketBuffer.nextReview=Long.MAX_VALUE;
    InventoryItem i=new InventoryItem(null,"AK-47 | Redline","Field-Tested","Classified",BigDecimal.valueOf(22),.23456789,false,321,null,22,true);i.itemId="stable-old-item";s.pendingTradeRewards=new java.util.ArrayList<>(java.util.List.of(InventoryItemCodec.encode(i)));
    try(ObjectOutputStream out=new ObjectOutputStream(new FileOutputStream(path))){out.writeObject(s);}
  }
 public static void main(String[] args)throws Exception{write(args[0]);}
}
