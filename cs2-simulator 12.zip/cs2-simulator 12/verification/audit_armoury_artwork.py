from pathlib import Path
import urllib.request,json,concurrent.futures,hashlib,io,datetime
from PIL import Image
R=Path('/home/user');hits=json.loads((R/'.cache/wraps-wear-metadata.json').read_text())
wear={'Factory New':'fn','Minimal Wear':'mw','Field-Tested':'ft','Well-Worn':'ww','Battle-Scarred':'bs'}
entries=[x for x in hits if x['paint_index']!='10036' or x['wear']['name'] in ('Factory New','Minimal Wear')]
def fetch(url):
 try:
  response=urllib.request.urlopen(urllib.request.Request(url,headers={'User-Agent':'CS2-Simulator-Artwork-Audit/1.0'}),timeout=25);b=response.read()
  im=Image.open(io.BytesIO(b));im.load()
  (R/'.cache'/('audited-'+hashlib.sha256(url.encode()).hexdigest()+'.png')).write_bytes(b)
  return dict(status=response.status,bytes=len(b),sha256=hashlib.sha256(b).hexdigest(),format=im.format,width=im.width,height=im.height)
 except urllib.error.HTTPError as e:return dict(status=e.code)
 except Exception as e:return dict(error=str(e))
def job(x):
 old='https://raw.githubusercontent.com/seyfooksck/cs2-skins-list/main/skins/leather_handwraps/'+x['paint_index']+'/'+wear[x['wear']['name']]+'.png'
 return dict(name=x['name'],wear=x['wear']['name'],missing_repository_url=old,missing_repository_result=fetch(old),replacement_url=x['image'],replacement_result=fetch(x['image']),valve_inventory_asset=x['original']['image_inventory'])
rows=list(concurrent.futures.ThreadPoolExecutor(max_workers=8).map(job,entries))
result=dict(audited_at_utc=datetime.datetime.now(datetime.timezone.utc).isoformat(),metadata_source='https://raw.githubusercontent.com/ByMykel/CSGO-API/main/public/api/en/skins_not_grouped.json',note='Official condition-binned Valve inventory imagery: FN/MW share the light icon, FT/WW share medium, BS uses heavy. These are not synthesized or five independently rendered floats.',entries=rows)
(R/'verification/armoury-wear-image-audit.json').write_text(json.dumps(result,indent=2)+'\n')
print(json.dumps(dict(entries=len(rows),old_404=sum(x['missing_repository_result'].get('status')==404 for x in rows),replacement_valid=sum(x['replacement_result'].get('status')==200 for x in rows)),indent=2))
assert len(rows)==12 and all(x['replacement_result'].get('status')==200 for x in rows)
# Capture the actual feed diagnosis, never call the modeled replacement a live MW quotation.
prices=json.loads((R/'.cache/live-price-snapshot.json').read_text());fn=prices['★ Karambit | Doppler (Factory New)']['doppler']['Ruby'];mw=prices['★ Karambit | Doppler (Minimal Wear)']
(R/'verification/armoury-ruby-quote-audit.json').write_text(json.dumps(dict(audited_at_utc=result['audited_at_utc'],source='https://prices.csgotrader.app/latest/csfloat.json',variant='Ruby',factory_new_ask=fn,minimal_wear_ask=mw['doppler']['Ruby'],minimal_wear_highest_order=mw['highest_order']['doppler']['Ruby'],diagnosis='Correct variant, illiquid/outlier MW asking price; not an extra Ruby multiplier.',outlier_rule='Only Karambit Ruby MW asks above 2x the same-variant FN cash reference',modeled_mw_reference=round(fn*.85,2),modeled_reference_is_live_mw_quote=False,policy='Explicit 15% wear discount to same-variant FN reference, not a hard dollar cap. Live MW asks within 2x FN are retained.'),indent=2)+'\n')
