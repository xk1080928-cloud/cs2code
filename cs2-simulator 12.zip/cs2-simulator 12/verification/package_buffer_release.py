"""Compatibility entry point: packages the current complete release, not the historical buffer build."""
from pathlib import Path
import runpy
runpy.run_path(str(Path(__file__).with_name("package_release.py")),run_name="__main__")
