package blahblah;

import java.awt.*;
import java.awt.image.BufferedImage;
import java.math.BigDecimal;
import java.nio.file.*;
import java.util.*;
import java.util.List;
import javax.swing.*;
import blahblah.InventoryToolsState.Tool;
import blahblah.hGui.*;

/** Directed acceptance checks for the supplied October 19 references. HTTPS is fixture-controlled;
 * genuine live wear-artwork URLs are independently checked by audit_armoury_artwork.py. */
public class ArmouryMarketAcceptanceChecks {
  static hGui app; static int checks;
  static void check(boolean ok,String text){if(!ok)throw new AssertionError(text);checks++;System.out.println("PASS: "+text);}
  static void edt(MarketHomeFeedTests.Throwing r)throws Exception{Cs2RedesignTests.edt(r);}
  static <T>T find(Component c,Class<T> t,String n){return Cs2RedesignTests.find(c,t,n);}
  static InventoryItem item(String name,String wear,String rarity,double f){InventoryItem i=new InventoryItem(null,name,wear,rarity,BigDecimal.valueOf(100),f,false,31,null,100);app.ownershipHistoryService.ensureInventoryItemTracking(i);return i;}
  static JPanel grid(String name){return find(app,JPanel.class,name);}
  static void screenshot(String name)throws Exception{Cs2RedesignTests.capture(name);}

  static void miscAndArmoury()throws Exception{
    edt(()->app.storeScreen.open("MISC"));
    String labels=GoldTradeUpTests.labels(app.generalTabPanel);
    for(String n:List.of("TRADES","COLLECTION","ACHIEVEMENTS","STATS","ROI STATS","MISSIONS"))check(labels.contains(n),"Misc contains the old General action: "+n);
    edt(()->{app.mainTabs.setSelectedIndex(0);MarketplaceOpeningChecks.button(app,"⚙").doClick();});
    check(app.mainTabs.getSelectedIndex()==6&&app.generalTabPanel.isShowing(),"The top-left gear opens the former Misc controls independently of Store Home");
    screenshot("armoury-misc-acceptance.png");
    for(int n=0;n<hGui.ARMOURY_COLLECTIONS.length;n++){
      if(hGui.ARMOURY_COLLECTIONS[n].name.contains("Achroma"))continue;
      final int index=n;edt(()->{app.storeScreen.open("ARMOURY");find(app,JButton.class,"storeArmouryCollection-"+index).doClick();});
      ArmouryCollection c=hGui.ARMOURY_COLLECTIONS[n];JPanel skins=grid("armourySkinGrid");
      int total=0;for(String[] tier:ArmouryBrowserScreen.tiers(c))if(tier!=null)total+=tier.length;
      check(skins!=null&&((GridLayout)skins.getLayout()).getColumns()==4&&skins.getComponentCount()==(c.isAgents?Math.min(total,16):total),"New four-column Armoury contains every weapon skin / a complete readable agent page in "+c.name);
      check(!app.armouryTabPanel.isShowing()&&find(app,JButton.class,"armouryRedeem")!=null,"Collection selection retains redemption and never opens legacy Armoury: "+c.name);
      if(c.name.contains("Achroma")||c.name.contains("Chop Shop")||c.name.contains("Baggage"))check(ArmouryBrowserScreen.preview(c)!=null&&ArmouryCollectionIcons.icon(c.name)!=null,"No-Covert collection has a genuine icon and highest-available-tier preview: "+c.name);
    }
    edt(()->find(app,JButton.class,"storeArmouryCollection-0").doClick());
    screenshot("armoury-four-column-acceptance.png");
    check(grid("armouryCollectionIcons").getComponentCount()==15,"All fifteen remaining collection selectors stay in the top row; Achroma is no longer redeemable");
    int before=app.inventoryList.size();edt(()->{app.activeMissions.clear();app.playerStars=8;find(app,JButton.class,"armouryRedeem").doClick();});
    check(app.playerStars==4&&app.armouryAnimating,"The new Redeem button charges the existing four-star cost and starts the in-place orbit");
    MarketplaceOpeningChecks.waitFor(()->app.inventoryList.size()==before+1,25000);
    MarketplaceOpeningChecks.waitFor(()->MarketplaceOpeningChecks.dialog("New Item")!=null,6000);
    JDialog d=MarketplaceOpeningChecks.dialog("New Item");
    check(d!=null&&d.isShowing(),"Armoury reward is committed exactly once before its New Item result is acknowledged");
    check(find(d,JComponent.class,"tradeUpResultInfo")==null,"Armoury New Item omits the info hover button");
    edt(()->d.dispose());MarketplaceOpeningChecks.waitFor(()->!app.armouryAnimating,3000);
    check(app.inventoryList.size()==before+1&&!app.armouryAnimating,"Closing Armoury cannot grant a second reward");
    edt(()->app.armouryScreen.refreshArmouryTab());
    check(grid("armourySkinGrid")!=null&&!app.armouryTabPanel.isShowing(),"Legacy refresh callers are redirected to the modern Armoury browser too");
  }

  static void sortsAndStorage()throws Exception{
    check("Quality".equals(app.cs2InventorySort),"Quality is the default Inventory sort, including after an opening");
    edt(()->app.cs2Screens.selectCs2InventorySection("EVERYTHING"));
    JComboBox<?> sort=find(app,JComboBox.class,"cs2InventorySort");List<String> choices=new ArrayList<>();for(int n=0;n<sort.getItemCount();n++)choices.add((String)sort.getItemAt(n));
    check(choices.equals(List.of("Quality","Newest","Alphabetical","Equip Slot","Collection","Equipped")),"Inventory exposes exactly the six requested sort orders");
    check(((GridLayout)grid("cs2InventoryGrid").getLayout()).getColumns()==8,"Regular Inventory has exactly eight columns");
    InventoryItem a=item("AK-47 | Slate","Field-Tested","Restricted",.2),b=item("AWP | Dragon Lore","Field-Tested","Covert",.2),c=item("P90 | Sand Spray","Field-Tested","Milspec",.2);
    a.createdAt=100;b.createdAt=200;c.createdAt=300;
    List<Object> rows=new ArrayList<>(List.of(c,a,b));rows.sort(app.cs2Screens.cs2InventoryComparator());check(rows.get(0)==b&&rows.get(2)==c,"Quality orders Covert above Restricted above Milspec");
    for(String s:choices){edt(()->sort.setSelectedItem(s));rows=new ArrayList<>(List.of(c,a,b));rows.sort(app.cs2Screens.cs2InventoryComparator());check(rows.size()==3,"Requested sort runs without dropping or duplicating items: "+s);}
    edt(()->sort.setSelectedItem("Newest"));rows=new ArrayList<>(List.of(a,b,c));rows.sort(app.cs2Screens.cs2InventoryComparator());check(rows.get(0)==c,"Newest uses acquisition time descending");
    app.tLoadout.put("AK-47",a);edt(()->sort.setSelectedItem("Equipped"));rows=new ArrayList<>(List.of(c,b,a));rows.sort(app.cs2Screens.cs2InventoryComparator());check(rows.get(0)==a,"Equipped places the currently equipped item first");app.tLoadout.remove("AK-47");
    edt(()->{app.cs2InventorySort="Quality";app.inventoryList.add(a);app.inventoryList.add(b);app.inventoryList.add(c);});
    Tool[] unit={null};CaseType ct=Cs2RedesignTests.source("Revolution Case");OwnedSupply key=new OwnedSupply(ct,true,2.49),box=new OwnedSupply(ct,false,1.23);
    edt(()->{unit[0]=app.inventoryToolsService.buy(true,1).get(0);app.inventoryToolsService.setLabel(unit[0],"Acceptance batch");app.ownedSupplies.add(key);app.ownedSupplies.add(box);});
    check(!app.inventoryToolsService.storable(key),"Case keys are excluded from storage eligibility");
    try{app.inventoryToolsService.deposit(unit[0],List.of(a,key));throw new AssertionError("Stored a key");}catch(IllegalArgumentException expected){check(unit[0].size()==0&&app.inventoryList.contains(a)&&app.ownedSupplies.contains(key),"A mixed batch containing a key is rejected atomically");}
    edt(()->app.inventoryToolsService.transfer(unit[0],true));JPanel deposit=grid("storageInventoryGrid");check(((GridLayout)deposit.getLayout()).getColumns()==8,"Deposit uses the regular eight-column Inventory card grid");
    boolean keyVisible=false;for(Component card:deposit.getComponents())if(((JComponent)card).getClientProperty("storedObject")==key)keyVisible=true;check(!keyVisible,"Deposit view omits owned keys, not just a disabled key action");
    edt(()->{app.inventoryToolsService.closeBrowser();app.inventoryToolsService.deposit(unit[0],List.of(a,b,box));app.inventoryToolsService.transfer(unit[0],false);});
    JPanel contents=grid("storageInventoryGrid");check(((GridLayout)contents.getLayout()).getColumns()==8&&contents.getComponentCount()==3,"Storage contents uses the same eight-column cards for the exact stored batch");
    screenshot("armoury-storage-acceptance.png");
    edt(()->{for(Component card:contents.getComponents())ToolsRevealChecks.click(card);find(app,JButton.class,"storageInventoryCommit").doClick();});
    MarketplaceOpeningChecks.waitFor(()->MarketplaceOpeningChecks.dialog("New Items")!=null,4000);JDialog reveal=MarketplaceOpeningChecks.dialog("New Items");
    check(GoldTradeUpTests.labels(reveal).contains("1 / 3")&&app.inventoryToolsService.state.newItems.contains(a.itemId)&&app.inventoryToolsService.state.newItems.contains(b.itemId),"Retrieving a batch opens one New Items popup containing both retrieved skins and the case");
    edt(()->find(reveal,JButton.class,"newItemsNext").doClick());check(GoldTradeUpTests.labels(reveal).contains("2 / 3"),"Retrieval carousel advances through the whole batch in the same dialog");
    edt(()->MarketplaceOpeningChecks.button(reveal,"CONTINUE").doClick());MarketplaceOpeningChecks.waitFor(()->!app.itemRevealService.showing,3000);check(unit[0].size()==0&&app.inventoryToolsService.state.newItems.isEmpty(),"Acknowledging retrieved items clears arrivals without duplicating their ownership");
    edt(()->{app.inventoryToolsService.closeBrowser();app.cs2UnlockSelection=box;app.containerSelectionScreen.renderCs2UnlockSelection();});
    JPanel match=grid("cs2MatchingSupplyGrid");String matchLabels=GoldTradeUpTests.labels(app.inventoryTabPanel);
    check(((GridLayout)match.getLayout()).getColumns()==8&&!matchLabels.contains("SELECT A MATCHING")&&!matchLabels.contains("Click Inventory to return"),"Matching key/container selection uses eight regular columns with no heading/subtitle");
    JScrollPane scroll=(JScrollPane)SwingUtilities.getAncestorOfClass(JScrollPane.class,match);check(!scroll.isOpaque()&&!scroll.getViewport().isOpaque(),"Matching selection has no opaque dark-gray scroll background");
    screenshot("armoury-matching-acceptance.png");
    edt(()->{app.cs2UnlockSelection=null;app.cs2Screens.selectCs2InventorySection("EVERYTHING");});
  }

  static void pricesAndArtwork()throws Exception{
    check(VerifiedWearArtwork.URLS.size()==12,"All twelve reported glove wear URLs have explicit genuine replacements");
    for(Map.Entry<String,String> row:VerifiedWearArtwork.URLS.entrySet()){String[] key=row.getKey().split("\\|",3);String skin=key[0]+"|"+key[1];String wear=key[2];check(row.getValue().equals(app.artworkService.getWearImageUrl(skin,wear)),"Wear routing selects the audited Valve asset: "+row.getKey());}
    Map<String,Double> ruby=new LinkedHashMap<>();ruby.put("Factory New",6798.22);ruby.put("Minimal Wear",27272.72);app.itemPriceService.rejectIlliquidGemWearQuote("Karambit | Doppler (Ruby)",ruby);
    check(ruby.get("Minimal Wear")==5778.49,"Ruby MW's actual $27,272.72 outlier is replaced by a documented $5,778.49 modeled same-Ruby wear reference");
    Map<String,Double> plausible=new LinkedHashMap<>(Map.of("Factory New",6798.22,"Minimal Wear",5900.0));app.itemPriceService.rejectIlliquidGemWearQuote("Karambit | Doppler (Ruby)",plausible);check(plausible.get("Minimal Wear")==5900,"A plausible real MW quote is retained rather than blanket-capped");
    Map<String,Double> other=new LinkedHashMap<>(Map.of("Factory New",6798.22,"Minimal Wear",27272.72));app.itemPriceService.rejectIlliquidGemWearQuote("M9 Bayonet | Doppler (Ruby)",other);check(other.get("Minimal Wear")==27272.72,"The Ruby correction does not cap other knife variants");
    check(MarketDynamics.floatPremium("Factory New",.06)>1&&Math.abs(MarketDynamics.floatPremium("Factory New",.0005)-2.5)<.00000001,"Float premium values a .0005 FN with a 2.5× base premium and monotonic ordinary FN prices");
    Random random=new Random(12345);boolean up=false,down=false;for(int n=0;n<1000;n++){double next=MarketDynamics.step(1,random),delta=Math.abs(next-1);if(delta<.002499999||delta>.005000001)throw new AssertionError("Movement outside requested range");up|=next>1;down|=next<1;}
    check(up&&down&&MarketDynamics.INTERVAL_MS==5000,"Every simulated skin tick chooses an up/down movement within 0.25–0.50%, at a five-second interval");
    app.globalMarketListings.clear();app.exchangeSiteStock.clear();String name="M4A4 | Howl";InventoryItem source=item(name,"Factory New","Contraband",.06);MarketListing parent=new MarketListing(source,100,120,false);parent.marketplaceName="CS.MONEY";parent.quantity=100;
    app.globalMarketListings.put(name,new ArrayList<>(List.of(parent)));app.exchangeSiteStock.put("CS.MONEY",new ArrayList<>(List.of(parent)));
    MarketplaceGroups.Group group=app.marketplaceGroups.group(List.of(parent)).get(0);Set<Double> prices=new HashSet<>();for(int n=0;n<100;n++)prices.add(app.marketplaceUnitStock.at(group,n).getPrice());check(prices.size()>80,"A multi-quantity Howl lot produces varied individual asks instead of repeated identical prices");
    MarketListing chosen=app.marketplaceUnitStock.at(group,17),same=app.marketplaceUnitStock.at(group,17);check(chosen.equals(same)&&chosen.getPrice()==same.getPrice()&&chosen.item.itemFloat==same.item.itemFloat,"Individual offer identity, float and seller premium remain stable across page reconstruction");
    CaseType ct=Cs2RedesignTests.source("Revolution Case");ContainerMarketService.publish(ct,1.23);MarketListing container=new MarketListing(app.containerMarketService.item(new OwnedSupply(ct,false,1.23)),1.23,120,false);container.marketplaceName="CS.MONEY";container.setPrice(1.23);app.globalMarketListings.put(ct.name,new ArrayList<>(List.of(container)));
    double before=parent.getPrice();MarketListing player=new MarketListing(source,155,120,true);
    edt(()->app.marketDynamics.tick());
    check(parent.getPrice()==before&&MarketDynamics.factor(name)==1,"A real supply tick never rewrites an existing skin ask or applies a hidden factor");
    check(container.getPrice()==1.23&&player.getPrice()==155,"Container and player asks remain fixed across order-flow ticks");
    int oldLots=app.globalMarketListings.get(name).size();int oldUnits=app.globalMarketListings.get(name).stream().mapToInt(l->l.quantity).sum();
    edt(()->app.marketRuntime.startMarketFluctuationTimerAfterInitialization());Thread.sleep(5500);
    MarketplaceOpeningChecks.waitFor(()->!app.marketUpdateInProgress,10000);edt(()->app.marketTimer.stop());
    check(app.marketTimer.getDelay()==5000&&parent.getPrice()==before,"The existing five-second market refresher runs fixed-ask supply movement, not a separate factor timer");
    check(!Double.isFinite(MarketDynamics.cents(Double.NaN))&&!Double.isFinite(MarketDynamics.cents(Double.POSITIVE_INFINITY)),"Invalid prices stay unavailable and cannot become penny asks");
    boolean absent=false;try{Class.forName("blahblah.PriceChartScreen");}catch(ClassNotFoundException expected){absent=true;}
    check(absent,"Only the total-cap graph implementation is removed");
  }

  static void fadeAndOpening()throws Exception{
    FadePanel fade=new FadePanel(new BorderLayout());fade.setSize(160,100);fade.setBackground(new Color(20,30,40));JPanel child=new JPanel();child.setBackground(new Color(220,130,40));fade.add(child);DevGeneratorTests.layout(fade);
    BufferedImage out=new BufferedImage(160,100,BufferedImage.TYPE_INT_RGB);fade.setAlpha(0);Graphics2D g=out.createGraphics();fade.paint(g);g.dispose();Color pixel=new Color(out.getRGB(80,50));check(pixel.equals(new Color(20,30,40)),"Alpha-zero result painting has a dark backing, never a white flash");
    fade.setAlpha(.5f);g=out.createGraphics();fade.paint(g);g.dispose();pixel=new Color(out.getRGB(80,50));check(Math.abs(pixel.getRed()-120)<3&&Math.abs(pixel.getGreen()-80)<3,"Overlapping result children receive one flattened scene alpha, not double opacity");
    edt(()->app.uiWidgets.fadeInPanel(fade,null));Thread.sleep(420);check(fade.alpha==1f,"Elapsed-time result fade reaches full visibility smoothly without per-frame window relayout");
    CaseType ct=Cs2RedesignTests.source("Revolution Case");ct.price=1.23;app.verifiedCaseQuotes.add(ct.id);ContainerMarketService.publish(ct,1.23);
    edt(()->{app.inventoryToolsService.state.newItems.clear();app.inventoryToolsService.closeBrowser();app.containerInventoryService.buyOwnedSupplies(ct,false,1);app.containerInventoryService.buyOwnedSupplies(ct,true,1);app.currentCase=ct;app.cs2Screens.selectCs2InventorySection("EVERYTHING");app.openingArtworkService.prepareOpeningArtwork(ct);});
    int before=app.inventoryList.size();edt(()->app.caseOpeningScreen.openCrateWithAnimation());MarketplaceOpeningChecks.waitFor(()->app.inventoryList.size()==before+1,25000);JDialog d=MarketplaceOpeningChecks.dialog("Opening Case...");
    check(d!=null&&d.isShowing()&&app.isAnimating,"Case reward is committed at landing while the result window is still open");
    InventoryItem reward=app.inventoryList.get(app.inventoryList.size()-1);final boolean[] visible={false};edt(()->{for(Component card:grid("cs2InventoryGrid").getComponents())if(((JComponent)card).getClientProperty("inventoryItem")==reward)visible[0]=true;});
    check(visible[0],"The actual Inventory component tree already contains the reward behind the still-open reel/result");
    check(find(d,JComponent.class,"tradeUpResultInfo")==null,"Armoury New Item omits the info hover button");Thread.sleep(400);screenshot("armoury-opening-result-acceptance.png");
    edt(()->d.dispose());MarketplaceOpeningChecks.waitFor(()->!app.armouryAnimating,3000);check(app.inventoryList.size()==before+1&&!app.isAnimating,"Closing the case result only releases the opening lock, without a second grant");
    check("Quality".equals(app.cs2InventorySort),"Opening preserves the requested Quality sort instead of forcing Newest");
    edt(()->{app.balance=4321.23;app.saveService.saveProgressAsync();app.balance=4567.89;app.saveService.saveProgress();});Thread.sleep(250);
    check(Files.readString(Path.of("csgo_simulator_save.json")).contains("4567.89"),"An older queued animation save cannot overwrite a newer synchronous save");
  }
  public static void main(String[] args)throws Exception{
    Thread.setDefaultUncaughtExceptionHandler((t,e)->{e.printStackTrace();System.exit(1);});Cs2RedesignTests.setup();app=Cs2RedesignTests.gui;
    miscAndArmoury();sortsAndStorage();pricesAndArtwork();fadeAndOpening();edt(()->{app.marketDynamics.stop();for(Window w:Window.getWindows())w.dispose();});System.out.println("All "+checks+" Armoury/market acceptance checks passed.");System.exit(0);
  }
}
