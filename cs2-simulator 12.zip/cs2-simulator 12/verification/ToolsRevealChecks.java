package blahblah;

import blahblah.hGui.*;
import blahblah.InventoryToolsState.Tool;
import java.awt.*;
import java.awt.event.*;
import java.awt.image.BufferedImage;
import java.math.BigDecimal;
import java.util.*;
import java.util.List;
import javax.swing.*;

public class ToolsRevealChecks {
 static hGui app;static int count;
 static void check(boolean ok,String text){if(!ok)throw new AssertionError(text);count++;System.out.println("PASS: "+text);}
 static void edt(MarketHomeFeedTests.Throwing action)throws Exception{Cs2RedesignTests.edt(action);}
 static <T>T find(Component root,Class<T> t,String name){return Cs2RedesignTests.find(root,t,name);}
 static JButton button(Component c,String text){return MarketplaceOpeningChecks.button(c,text);}
 static void click(Component c){for(MouseListener l:c.getMouseListeners())l.mouseClicked(new MouseEvent(c,MouseEvent.MOUSE_CLICKED,System.currentTimeMillis(),0,8,8,1,false,MouseEvent.BUTTON1));}
 static InventoryItem skin(String name,String rarity,double f){InventoryItem i=new InventoryItem(null,name,"Field-Tested",rarity,BigDecimal.valueOf(20),f,false,42,null,20);app.ownershipHistoryService.ensureInventoryItemTracking(i);return i;}
 static void tools()throws Exception{
  double cash=app.balance;final List<Tool>[] purchased=new List[]{null};edt(()->purchased[0]=app.inventoryToolsService.buy(true,1));Tool unit=purchased[0].get(0);
  check(!unit.activated&&unit.size()==0&&Math.abs(app.balance-cash+1.99)<.00001,"A $1.99 store purchase creates an inactive, empty Storage Unit, not a marketplace listing");
  app.inventoryToolsService.setLabel(unit,"Investment skins");check(unit.activated&&unit.label.equals("Investment skins"),"Start Using This Unit activates a named unit");
  cash=app.balance;app.inventoryToolsService.setLabel(unit,"Keepers");check(app.balance==cash&&unit.label.equals("Keepers"),"Change Label is free and does not consume a Name Tag");
  InventoryItem owned=skin("AK-47 | Slate","Restricted",.23);app.inventoryList.add(owned);app.inventoryValue+=20;app.tLoadout.put("AK-47",owned);
  CaseType ct=Cs2RedesignTests.source("Revolution Case");OwnedSupply supply=new OwnedSupply(ct,false,.15);app.ownedSupplies.add(supply);
  List<Tool> tags=app.inventoryToolsService.buy(false,2);String id=owned.itemId;long created=owned.createdAt;
  app.inventoryToolsService.deposit(unit,List.of(owned,supply,tags.get(0)));
  check(unit.size()==3&&!app.inventoryList.contains(owned)&&!app.ownedSupplies.contains(supply),"Mixed batch deposit removes skins, cases and Name Tags from active inventory");
  check(!app.tLoadout.containsValue(owned)&&!app.containerMarketService.owns(owned),"Stored items cannot remain equipped or be sold through a stale item reference");
  try{app.inventoryToolsService.rename(tags.get(1),owned,"Unavailable");throw new AssertionError();}catch(IllegalArgumentException expected){check(true,"Stored weapons cannot be renamed or consume a tag");}
  try{app.inventoryToolsService.deposit(unit,List.of(unit));throw new AssertionError();}catch(IllegalArgumentException expected){check(unit.size()==3,"Nested storage units are rejected without changing contents");}
  InventoryItem glove=skin("Driver Gloves | Black Tie","Gloves",.2);app.inventoryList.add(glove);
  check(!app.inventoryToolsService.storable(glove),"Gloves, like default equipment and agents, are excluded from storage");app.inventoryList.remove(glove);
  edt(()->app.saveService.saveProgress());edt(()->app.saveService.loadProgress());
  unit=app.inventoryToolsService.state.tools.stream().filter(t->t.id.equals(purchased[0].get(0).id)).findFirst().get();
  check(unit.size()==3&&unit.label.equals("Keepers")&&unit.activated,"Storage labels, activation and mixed contents survive normal save/load");
  app.inventoryToolsService.retrieve(unit,app.inventoryToolsService.contents(unit));
  InventoryItem restored=app.inventoryList.stream().filter(i->id.equals(i.itemId)).findFirst().get();
  check(restored.itemFloat==.23&&restored.patternID==42&&restored.createdAt==created&&unit.size()==0,"Retrieval restores the exact original item ID, float, pattern and timestamp");
  check(app.ownedSupplies.stream().anyMatch(s->s.id.equals(supply.id)),"Stored cases retain their original supply identity on retrieval");
  Tool tag=app.inventoryToolsService.state.tools.stream().filter(t->!t.storage).findFirst().get();String canonical=restored.name;
  app.inventoryToolsService.rename(tag,restored,"My keeper");
  check(!app.inventoryToolsService.state.tools.contains(tag)&&restored.name.equals(canonical)&&app.inventoryToolsService.displayName(restored).contains("My keeper"),"Applying a Name Tag consumes it once and keeps the canonical pricing/catalog name intact");
  try{app.inventoryToolsService.rename(tag,restored,"Replay");throw new AssertionError();}catch(IllegalArgumentException expected){check(true,"An already consumed Name Tag cannot be replayed");}
  check(find(app.cs2Screens.createCs2SkinCard(restored,()->{}),JLabel.class,"never") == null&&GoldTradeUpTests.labels(app.cs2Screens.createCs2SkinCard(restored,()->{})).contains("My keeper"),"The custom name is visibly displayed on the item card");
  List<Object> only=app.cs2Screens.filteredCs2Inventory("STORAGE UNITS","");check(only.size()==1&&only.get(0) instanceof Tool&&((Tool)only.get(0)).storage,"Storage Units inventory category contains only storage units");
  check(app.cs2Screens.filteredCs2Inventory("EVERYTHING","").stream().anyMatch(o->o instanceof Tool&&!((Tool)o).storage),"Unused Name Tags appear in Everything inventory");
  List<Object> filler=new ArrayList<>();for(int n=0;n<1000;n++){OwnedSupply s=new OwnedSupply(ct,false,.15);app.ownedSupplies.add(s);filler.add(s);}app.inventoryToolsService.deposit(unit,filler);
  OwnedSupply extra=new OwnedSupply(ct,false,.15);app.ownedSupplies.add(extra);
  try{app.inventoryToolsService.deposit(unit,List.of(extra));throw new AssertionError();}catch(IllegalArgumentException expected){check(unit.size()==1000&&app.ownedSupplies.contains(extra),"The 1,000-item capacity is enforced atomically, without losing the extra item");}
  app.inventoryToolsService.retrieve(unit,app.inventoryToolsService.contents(unit));app.ownedSupplies.removeAll(filler);app.ownedSupplies.remove(extra);
  for(String bad:List.of("","abcdefghijklmnopqrstu","line\ncontrol"))try{InventoryToolsService.validName(bad);throw new AssertionError();}catch(IllegalArgumentException expected){check(true,"Invalid label is rejected: "+bad.replace('\n',' '));}
  app.inventoryToolsService.state.newItems.clear(); // Backend retrieval verified above; popup batches have a dedicated native acceptance suite.
  edt(()->app.inventoryToolsService.changed());
  edt(()->app.inventoryToolsService.showStore());Component store=app.storeScreen.sections.getSelectedComponent();
  check(find(store,JButton.class,"buyStorageUnit")!=null&&find(store,JButton.class,"buyNameTag")!=null,"Store → Tools presents both genuine tool products");
  SwingUtilities.invokeLater(()->find(store,JButton.class,"buyNameTag").doClick());MarketplaceOpeningChecks.waitFor(()->MarketplaceOpeningChecks.dialog("Authorize purchase")!=null,3000);
  JDialog checkout=MarketplaceOpeningChecks.dialog("Authorize purchase");cash=app.balance;int before=app.inventoryToolsService.state.tools.size();edt(()->button(checkout,"CANCEL").doClick());
  check(app.balance==cash&&app.inventoryToolsService.state.tools.size()==before,"Cancelling the CS2-style purchase authorization charges nothing");
  SwingUtilities.invokeLater(()->find(store,JButton.class,"buyNameTag").doClick());MarketplaceOpeningChecks.waitFor(()->MarketplaceOpeningChecks.dialog("Authorize purchase")!=null,3000);
  JDialog confirmation=MarketplaceOpeningChecks.dialog("Authorize purchase");JButton submit=find(confirmation,JButton.class,"authorizeToolPurchase");double wallet=app.balance;int toolsBefore=app.inventoryToolsService.state.tools.size();
  edt(()->{submit.doClick();for(ActionListener listener:submit.getActionListeners())listener.actionPerformed(new ActionEvent(submit,ActionEvent.ACTION_PERFORMED,"replay"));});
  check(Math.abs(app.balance-wallet+1.99)<.00001&&app.inventoryToolsService.state.tools.size()==toolsBefore+1,"Authorizing through the Tools Store buys one tag and is idempotent against a repeated authorize event");
  check(app.mainTabs.getSelectedIndex()==2&&MarketplaceOpeningChecks.dialog("Authorize purchase")==null,"Completed authorization returns to Inventory instead of leaving a stale checkout dialog");
 }
 static void market()throws Exception{
  MarketplaceProfile site=MarketplaceProfile.byName("SkinSwap");String name="M9 Bayonet | Gamma Doppler (Emerald)";
  MarketListing one=IndividualMarketChecks.lot(name,"Factory New",23,site.name),two=IndividualMarketChecks.lot(name,"Factory New",17,site.name);
  app.exchangeSiteStock.put(site.name,new ArrayList<>(List.of(one,two)));edt(()->{app.loadoutScreen.refreshMarketTab();app.mainTabs.setSelectedIndex(4);});
  MarketplaceGroups.Group group=app.marketplaceGroups.group(List.of(one,two)).get(0);edt(()->new MarketplaceStackPicker(app).buy(site,app,group,l->{}));JPanel page=(JPanel)app.exchangeHostSections.getSelectedComponent();
  JPanel header=(JPanel)app.exchangeHostSections.getTabComponentAt(app.exchangeHostSections.getSelectedIndex());JButton close=DevGeneratorTests.first(header,JButton.class);
  check(close.getPreferredSize().equals(new Dimension(24,24))&&header.getPreferredSize().height==28,"Temporary tab header uses centered, fixed-size close geometry instead of an oversized native Aqua button");
  JComboBox sort=find(page,JComboBox.class,"individualOfferFloatSort");edt(()->sort.setSelectedItem("Float: low to high"));JPanel rows=find(page,JPanel.class,"exchangeStackIndividuals");double previous=-1;
  for(Component ticket:rows.getComponents()){MarketListing l=(MarketListing)find(ticket,JPanel.class,"exchangeListingCard").getClientProperty("marketListing");check(l.item.itemFloat>=previous,"Ascending float order is monotonic on the first page");previous=l.item.itemFloat;}
  double maxFirst=previous;edt(()->button(page,"›").doClick());MarketListing next=(MarketListing)find(find(page,JPanel.class,"exchangeStackIndividuals").getComponent(0),JPanel.class,"exchangeListingCard").getClientProperty("marketListing");check(next.item.itemFloat>=maxFirst,"Float sorting is global across lots and page boundaries, not just inside the visible page");
  edt(()->sort.setSelectedItem("Float: high to low"));rows=find(page,JPanel.class,"exchangeStackIndividuals");previous=2;for(Component ticket:rows.getComponents()){MarketListing l=(MarketListing)find(ticket,JPanel.class,"exchangeListingCard").getClientProperty("marketListing");check(l.item.itemFloat<=previous,"Descending float order is monotonic");previous=l.item.itemFloat;}
  check(group.units()==40,"Sorting and paging do not alter stock quantity or unit identity");edt(()->button(page,"Close tab").doClick());
 }
 static void tradeups()throws Exception{
  app.tradeUpSelection.clear();app.cs2TradeUpQuality="All";CaseType source=Cs2RedesignTests.source("Chroma Case");
  InventoryItem gold=skin(source.regularDropNames.get("Covert").get(0),"Covert",.2);
  InventoryItem standard=skin("M4A4 | Dragon King","Classified",.2);app.inventoryList.add(gold);app.inventoryList.add(standard);
  check(app.goldTradeUpService.isTradeUpEligibleForMode(gold)&&app.goldTradeUpService.isTradeUpEligibleForMode(standard),"An empty contract offers eligible Covert and standard-rarity skins together");
  edt(()->app.cs2EquipmentScreens.refreshCs2TradeUp());check(find(app.tradeUpTabPanel,JComboBox.class,"tradeUpContractMode")==null,"No Standard/Gold mode selector remains in the trade-up UI");
  app.tradeUpSelection.add(gold);edt(()->app.cs2EquipmentScreens.refreshCs2TradeUp());check(app.goldTradeUpMode&&app.goldTradeUpService.getTradeUpRequiredCount(app.tradeUpSelection)==5&&!app.goldTradeUpService.isTradeUpEligibleForMode(standard),"Selecting a Covert infers a five-input gold contract and locks compatible input quality");
  app.tradeUpSelection.clear();app.tradeUpSelection.add(standard);edt(()->app.cs2EquipmentScreens.refreshCs2TradeUp());check(!app.goldTradeUpMode&&app.goldTradeUpService.getTradeUpRequiredCount(app.tradeUpSelection)==10&&!app.goldTradeUpService.isTradeUpEligibleForMode(gold),"Selecting Classified infers a ten-input standard contract");
  app.tradeUpSelection.clear();edt(()->app.cs2EquipmentScreens.refreshCs2TradeUp());check(app.goldTradeUpService.isTradeUpEligibleForMode(gold)&&app.goldTradeUpService.isTradeUpEligibleForMode(standard),"Clearing the contract restores unrestricted eligible rarities");
  InventoryItem result=skin("Desert Eagle | Ocean Drive","Covert",.12);app.inventoryList.add(result);long began=System.nanoTime();int owned=app.inventoryList.size();edt(()->{app.itemRevealService.tradeUp(result);app.itemRevealService.tradeUp(result);});Thread.sleep(220);
  check(MarketplaceOpeningChecks.dialog("Trade-Up Complete")==null&&app.itemRevealService.tradeUpPending&&!app.inventoryList.contains(result)&&app.mainTabs.getSelectedIndex()==2&&"EVERYTHING".equals(app.cs2InventorySection),"Trade-up switches to main Inventory before revealing, with the result staged rather than owned");
  MarketplaceOpeningChecks.waitFor(()->MarketplaceOpeningChecks.dialog("Trade-Up Complete")!=null,2500);check((System.nanoTime()-began)/1e6>=PageTransitions.DURATION_MS,"The quick shared Inventory transition finishes before the result popup opens");
  JDialog d=MarketplaceOpeningChecks.dialog("Trade-Up Complete");check(GoldTradeUpTests.labels(d).contains("NEW ITEM")&&button(d,"CONTINUE")!=null,"Contract result uses the rarity-lit NEW ITEM design and Continue action");
  Thread.sleep(420);Cs2RedesignTests.capture("tools-tradeup-result.png");edt(()->button(d,"CONTINUE").doClick());Cs2RedesignTests.flush();check(app.inventoryList.size()==owned&&!app.itemRevealService.tradeUpPending,"Fade/Continue do not regrant an already committed reward, even after a duplicate presentation request");
 }
 static void newItems()throws Exception{
  app.inventoryToolsService.state.newItems.clear();InventoryItem a=skin("Desert Eagle | Ocean Drive","Covert",.15),b=skin("AK-47 | Slate","Restricted",.18);app.inventoryList.add(a);app.inventoryList.add(b);app.itemRevealService.received(a);app.itemRevealService.received(b);
  edt(()->{app.mainTabs.setSelectedIndex(4);app.saveService.saveProgress();});edt(()->app.saveService.loadProgress());check(app.inventoryToolsService.state.newItems.size()==2,"Unacknowledged new-market-item IDs persist across save/load");
  SwingUtilities.invokeLater(()->app.mainTabs.setSelectedIndex(2));MarketplaceOpeningChecks.waitFor(()->MarketplaceOpeningChecks.dialog("New Items")!=null,3500);JDialog d=MarketplaceOpeningChecks.dialog("New Items");
  check(GoldTradeUpTests.labels(d).contains("NEW ITEM")&&GoldTradeUpTests.labels(d).contains("1 / 2"),"Entering Inventory shows the newly received batch with a per-item counter");
  edt(()->find(d,JButton.class,"newItemsNext").doClick());check(GoldTradeUpTests.labels(d).contains("2 / 2")&&GoldTradeUpTests.labels(d).contains("AK-47 | Slate"),"Next/previous browse the exact received item identities");
  Thread.sleep(420);Cs2RedesignTests.capture("tools-new-items-result.png");int owned=app.inventoryList.size();edt(()->button(d,"CONTINUE").doClick());Cs2RedesignTests.flush();check(app.inventoryToolsService.state.newItems.isEmpty()&&app.inventoryList.size()==owned,"Continue acknowledges the batch without granting or deleting items");
 }
 static void animation()throws Exception{
  app.currentCase=Cs2RedesignTests.source("Revolution Case");AnimationPanel reel=new AnimationPanel(app,new CrateRollResult("Restricted",Theme.RARITY_RESTRICTED,false,1));reel.skinStrip.clear();
  BufferedImage[] images=new BufferedImage[8];for(int n=0;n<8;n++){images[n]=new BufferedImage(1600,1000,BufferedImage.TYPE_INT_ARGB);Graphics2D g=images[n].createGraphics();g.setColor(new Color(30+n*20,60,140));g.fillOval(0,0,1600,1000);g.dispose();}
  for(int n=0;n<60;n++)reel.skinStrip.add(reel.new AnimatedSkin(images[n%8],false,Theme.RARITY_RESTRICTED));reel.setSize(1500,500);BufferedImage output=new BufferedImage(1500,500,BufferedImage.TYPE_INT_RGB);long[] timings=new long[200];
  edt(()->{for(int n=0;n<220;n++){reel.scrollOffset=n*36;Graphics2D g=output.createGraphics();long start=System.nanoTime();reel.paint(g);long ns=System.nanoTime()-start;g.dispose();if(n>=20)timings[n-20]=ns;}});Arrays.sort(timings);double p95=timings[189]/1e6;System.out.printf("REEL PAINT: p95 %.3f ms, 8 high-resolution source images, 60 strip cards, 1500×500 viewport%n",p95);
  check(p95<30,"Cached scenery and pre-scaled reel sprites keep warmed paint under a 30-ms frame budget");
  java.lang.reflect.Field field=AnimationPanel.class.getDeclaredField("backdrop");field.setAccessible(true);Object back=field.get(reel);edt(()->{Graphics2D g=output.createGraphics();reel.paint(g);g.dispose();});check(field.get(reel)==back,"The scenery/container backdrop is reused between animation frames, not resized every repaint");
 }
 public static void main(String[] args)throws Exception{
  Thread.setDefaultUncaughtExceptionHandler((t,e)->{e.printStackTrace();System.exit(1);});Cs2RedesignTests.setup();app=Cs2RedesignTests.gui;IndividualMarketChecks.app=app;
  tools();market();tradeups();newItems();animation();edt(()->{for(Window w:Window.getWindows())w.dispose();});System.out.println("All "+count+" tools/reveal/update checks passed.");System.exit(0);
 }
}
