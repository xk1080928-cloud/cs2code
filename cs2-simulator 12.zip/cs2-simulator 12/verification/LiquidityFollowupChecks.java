package blahblah;

import java.awt.*;
import java.awt.event.*;
import java.awt.image.BufferedImage;
import java.math.BigDecimal;
import java.util.*;
import java.util.List;
import javax.swing.*;

/** Directed current-source native checks for the fixed-ask follow-up. HTTPS is controlled. */
public class LiquidityFollowupChecks {
  static hGui app; static int checks;
  static void check(boolean ok,String text){if(!ok)throw new AssertionError(text);checks++;System.out.println("PASS: "+text);}
  static void edt(MarketHomeFeedTests.Throwing r)throws Exception{Cs2RedesignTests.edt(r);}
  static <T>T find(Component c,Class<T> t,String n){return Cs2RedesignTests.find(c,t,n);}
  static InventoryItem item(String n,String wear,String rarity,double f){InventoryItem i=new InventoryItem(null,n,wear,rarity,BigDecimal.valueOf(100),f,false,321,null,100);app.ownershipHistoryService.ensureInventoryItemTracking(i);return i;}
  static MarketListing lot(InventoryItem i,double price,int quantity){MarketListing l=new MarketListing(i,price,120,true);l.isPlayerListing=false;l.quantity=quantity;l.marketplaceName="CS.MONEY";return l;}
  static void all(Component c,List<Component> out){out.add(c);if(c instanceof Container)for(Component child:((Container)c).getComponents())all(child,out);}
  static void armoury()throws Exception{
    Set<String> names=new HashSet<>();for(ArmouryCollection c:hGui.ARMOURY_COLLECTIONS)for(String[] tier:ArmouryBrowserScreen.tiers(c))if(tier!=null)Collections.addAll(names,tier);
    BufferedImage fixture=new BufferedImage(900,600,BufferedImage.TYPE_INT_ARGB);
    for(String n:names)app.imageRepository.put(n,fixture);
    for(int n=0;n<500;n++)app.imageRepository.put("eviction-"+n,fixture);
    check(names.stream().allMatch(app.armouryArtworkCache::contains),"Every Armoury thumbnail survives ordinary image-cache eviction ("+names.size()+" unique names)");
    edt(()->app.setSize(1366,768));
    for(int n=0;n<hGui.ARMOURY_COLLECTIONS.length;n++){
      if(hGui.ARMOURY_COLLECTIONS[n].name.contains("Achroma"))continue;
      final int index=n;edt(()->{app.storeScreen.open("ARMOURY");find(app,JButton.class,"storeArmouryCollection-"+index).doClick();DevGeneratorTests.layout(app);});
      JPanel grid=find(app,JPanel.class,"armourySkinGrid");JButton redeem=find(app,JButton.class,"armouryRedeem");
      boolean fits=grid.getWidth()>0&&grid.getHeight()>0;for(Component card:grid.getComponents())fits&=card.getY()>=0&&card.getY()+card.getHeight()<=grid.getHeight()&&card.getHeight()>=(hGui.ARMOURY_COLLECTIONS[index].isAgents?18:35);
      check(fits&&((GridLayout)grid.getLayout()).getColumns()==4&&SwingUtilities.getAncestorOfClass(JScrollPane.class,grid)==null,"All four-column skins fit without vertical scrolling at 1366×768: "+hGui.ARMOURY_COLLECTIONS[n].name);
      Point p=SwingUtilities.convertPoint(redeem,0,0,app);check(p.x>app.getWidth()/2&&p.y>app.getHeight()/2&&redeem.getText().equals("REDEEM "+app.itemMetadataService.getArmouryRedeemCost(hGui.ARMOURY_COLLECTIONS[index])+"★"),"Green redemption with the correct displayed cost stays bottom-right: "+hGui.ARMOURY_COLLECTIONS[n].name);
      List<Component> tree=new ArrayList<>();all(find(app,JPanel.class,"armouryCollectionIcons"),tree);boolean unclipped=true;for(Component c:tree)if(c instanceof JLabel&&((JLabel)c).getIcon()!=null){Icon icon=((JLabel)c).getIcon();boolean fit=icon.getIconHeight()<=c.getHeight()&&icon.getIconWidth()<=c.getWidth();if(!fit)System.out.println("CLIPPED LOGO: "+c.getWidth()+"x"+c.getHeight()+" icon="+icon.getIconWidth()+"x"+icon.getIconHeight());unclipped&=fit;}
      check(unclipped,"Collection logo image fits inside its actual label bounds: "+hGui.ARMOURY_COLLECTIONS[n].name);
    }
    Cs2RedesignTests.capture("liquidity-armoury-1366.png");edt(()->app.setSize(1600,1000));
  }
  static void navigationAndHover()throws Exception{
    InventoryItem a=item("AK-47 | Slate","Field-Tested","Restricted",.20012345),b=item("AK-47 | Slate","Field-Tested","Restricted",.22234567);app.inventoryList.add(a);app.inventoryList.add(b);app.tradeUpSelection.add(a);
    edt(()->app.cs2Screens.selectCs2InventorySection("TRADE UP"));
    JPanel selected=find(app,JPanel.class,"cs2TradeUpSelected"),eligible=find(app,JPanel.class,"cs2TradeUpEligible");
    check(find(selected,JComponent.class,"tradeUpInputInfo")==null&&find(eligible,JComponent.class,"tradeUpInputInfo")==null,"Both selected and eligible trade-up cards omit the obsolete info button");
    String text=((JPanel)selected.getComponent(0)).getToolTipText();check(text!=null&&text.contains("Rarity:")&&text.contains("Restricted")&&text.contains("Wear:")&&text.contains("Field-Tested")&&text.contains("0.20012345")&&text.contains("Pattern ID:")&&text.contains("321")&&text.contains("Collection:"),"Whole-card hover exposes rarity, wear, float, pattern and collection details");
    for(String sort:List.of("Quality","Newest","Alphabetical","Equip Slot","Collection","Equipped")){
      app.cs2InventorySort=sort;List<Object> rows=new ArrayList<>(app.inventoryList);rows.sort(app.cs2Screens.cs2InventoryComparator());boolean seenDefault=false,valid=true;for(Object row:rows){boolean d=row instanceof InventoryItem&&app.cs2EquipmentScreens.isDefaultWeaponItem((InventoryItem)row);if(d)seenDefault=true;else if(seenDefault)valid=false;}check(valid&&seenDefault,"Every default gun/knife/glove follows every collectible in "+sort+" sort");
    }
    edt(()->{app.mainTabs.setSelectedIndex(4);app.cs2InventorySearch="slate";app.cs2EquipFilter="AK-47";app.navigationService.navigateCs2Top(2);});
    check(app.mainTabs.getSelectedIndex()==2&&"EVERYTHING".equals(app.cs2InventorySection)&&app.cs2InventorySearch.isEmpty()&&app.cs2EquipFilter==null&&app.inventoryToolsService.browsingUnit==null,"Returning from Store/Market resets to unfiltered main Inventory");
    check(app.tradeUpSelection.equals(List.of(a)),"Returning to main Inventory preserves contract selections separately");
    app.tradeUpSelection.clear();app.inventoryList.remove(a);app.inventoryList.remove(b);app.cs2InventorySort="Quality";
  }
  static void booksAndHistory()throws Exception{
    app.inventoryToolsService.state.supply=null;app.globalMarketListings.clear();app.exchangeSiteStock.clear();
    InventoryItem agent=item("Special Agent Ava | FBI","Normal","Consumer",0);MarketListing a=lot(agent,20000,20),b=lot(agent,40000,30);ArrayList<MarketListing> bucket=new ArrayList<>(List.of(a,b));app.globalMarketListings.put(agent.name,bucket);
    check(app.marketRuntime.calculateTotalMarketCap()==1_600_000,"Exact-variant cap uses the weighted average $32,000 price × all 50 surviving units");
    app.globalMarketListings.put("duplicate-reference",new ArrayList<>(List.of(a)));check(app.marketRuntime.calculateTotalMarketCap()==1_600_000,"Cap cannot double-count the same backing lot through duplicate references");app.globalMarketListings.remove("duplicate-reference");
    InventoryItem howl=item("M4A4 | Howl","Factory New","Contraband",.02);MarketListing skin=lot(howl,100,100);MarketplaceGroups.Group group=app.marketplaceGroups.group(List.of(skin)).get(0);
    double floor=Double.POSITIVE_INFINITY;for(int n=0;n<100;n++)floor=Math.min(floor,app.marketplaceUnitStock.at(group,n).getPrice());check(floor==app.marketplaceUnitStock.floorAsk(skin),"Cached minimum is the lowest real available individually priced offer");
    MarketListing cheapest=app.marketplaceUnitStock.cheapest(skin),held=app.marketplaceUnitStock.unit(skin,17);double heldPrice=held.getPrice();app.marketplaceUnitStock.consume(cheapest);check(!app.marketplaceUnitStock.available(cheapest)&&held.getPrice()==heldPrice,"Consuming cheapest stock retains every surviving identity and fixed ask");
    for(boolean ascending:new boolean[]{true,false}){int[] order=app.marketplaceUnitStock.sortedPriceRanks(group,ascending);boolean ok=order.length==99;Set<Integer> ids=new HashSet<>();double previous=ascending?Double.NEGATIVE_INFINITY:Double.POSITIVE_INFINITY;for(int rank:order){MarketListing offer=app.marketplaceUnitStock.at(group,rank);double value=offer.getPrice();ok&=ascending?value>=previous:value<=previous;previous=value;ids.add(offer.stockIndex);}check(ok&&ids.size()==99,"Price sort is globally ordered and visits every surviving unit exactly once: "+(ascending?"lowest":"highest"));}
    edt(()->{app.storeScreen.open("MARKET");new MarketplaceStackPicker(app).buy(MarketplaceProfile.byName("CS.MONEY"),app,group,l->{});});JComboBox<?> sort=find(app,JComboBox.class,"individualOfferFloatSort");check(sort!=null&&sort.getItemCount()==4&&sort.getItemAt(0).toString().contains("Price: lowest")&&sort.getItemAt(1).toString().contains("Price: highest"),"Individual market picker exposes lowest/highest price as well as both float orders");
    app.exchangeSiteStock.put("CS.MONEY",new ArrayList<>(List.of(skin)));
    JPanel[] catalog={null};edt(()->catalog[0]=new MarketplaceBuyScreen(app).create(MarketplaceProfile.byName("CS.MONEY"),"Howl"));
    MarketListing added=lot(howl,50,3);app.exchangeSiteStock.get("CS.MONEY").add(added);
    edt(()->((Runnable)catalog[0].getClientProperty("refreshPrices")).run());
    List<MarketplaceGroups.Group> refreshed=(List<MarketplaceGroups.Group>)catalog[0].getClientProperty("catalogGroups");
    check(refreshed.size()==1&&refreshed.get(0).units()==102&&refreshed.get(0).head()==added,"Visible price refresh re-reads newly supplied stock and uses the actual cheapest offer, not a stale cached stack");
    check(MarketDynamics.floatPremium("Factory New",.062,.06,.8)>MarketDynamics.floatPremium("Factory New",.069,.06,.8),"Capped FN glove pricing correctly values .062 above .069");
    check(MarketDynamics.floatPremium("Factory New",.060,0,1)>MarketDynamics.floatPremium("Factory New",.069,0,1),"Ordinary FN pricing stays monotonic at the high end of the FN interval");
    MarketListing cheap=lot(agent,10,1),next=lot(agent,10.04,50);bucket.clear();bucket.add(cheap);bucket.add(next);app.inventoryToolsService.state.supply=null;app.globalSupply.initialize();hGui.random.setSeed(1234);edt(()->app.marketDynamics.move(bucket,new ArrayList<>(bucket),true,.0035));check(cheap.quantity==0&&next.quantity==50&&next.getPrice()==10.04,"Rising reference consumes only real cheapest offers; the next fixed ask becomes the reference");
    double before=next.getPrice();int parents=bucket.size();edt(()->app.marketDynamics.move(bucket,new ArrayList<>(bucket),false,.0035));double newFloor=bucket.stream().filter(l->l.quantity>0).mapToDouble(app.marketplaceUnitStock::floorAsk).min().getAsDouble();check(bucket.size()==parents+1&&next.getPrice()==before&&newFloor<before&&Math.abs(newFloor/before-1)>=.0025&&Math.abs(newFloor/before-1)<=.005,"Falling reference introduces cheaper real stock, without rewriting any old ask");
    Random random=new Random(81);boolean up=false,down=false;for(int n=0;n<1000;n++){double step=MarketDynamics.step(1,random),d=Math.abs(step-1);if(d<.0025-1e-10||d>.005+1e-10)throw new AssertionError("Wrong target magnitude");up|=step>1;down|=step<1;}check(up&&down&&MarketDynamics.INTERVAL_MS==hGui.MARKET_UPDATE_INTERVAL,"Supply targets are ±0.25–0.50% on the existing five-second market clock");
    app.salesHistory.clear();app.simulatedSalesReady=false;ArrayList<SaleRecord> sales=new ArrayList<>();long t=1700000000000L;for(int n=0;n<350;n++){SaleRecord r=new SaleRecord("AK-47 | Slate",10,"Field-Tested",.20+n*.0000001,null);r.timestamp=t+n;sales.add(r);}for(int n=0;n<7;n++){SaleRecord r=new SaleRecord("AK-47 | Slate",20,"Field-Tested",.21+n*.0000001,null);r.timestamp=t+5000+n;sales.add(r);}app.salesHistory.put("AK-47 | Slate",new HashMap<>(Map.of("Field-Tested",sales)));
    ArrayList<PriceHistoryPoint> points=app.marketHistoryScreen.getMarketplacePriceHistoryPointData("AK-47 | Slate","Field-Tested",new ArrayList<>());check(points.size()==2&&points.get(0).soldQuantity==350&&points.get(0).price==10&&points.get(1).soldQuantity==7&&points.get(1).price==20&&points.get(1).timestamp-points.get(0).timestamp==5000,"History aggregates all 357 sales before truncation into two five-second points with exact quantities and means");
    double low=app.salesSimulationService.getSimulatedSalesPerMinute("Gloves",100,false),high=app.salesSimulationService.getSimulatedSalesPerMinute("Gloves",20000,false);check(high<low/20&&high<.02,"Very expensive gloves generate economically sparse histories rather than repeated high-value sales");
    check(app.salesSimulationService.getSimulatedSalesPerMinute("Container",100,false)<app.salesSimulationService.getSimulatedSalesPerMinute("Container",1,false)/20,"Container demand decreases strongly with absolute price");
  }
  static void feeds()throws Exception{
    app.globalMarketListings.clear();List<CaseType> cases=new ArrayList<>();CaseType souvenir=null;for(CaseType ct:CaseType.values()){if(ct.isSouvenir&&souvenir==null)souvenir=ct;else if(!ct.isSouvenir&&!ct.isTerminal&&cases.size()<2)cases.add(ct);}check(cases.size()==2&&souvenir!=null,"Catalog provides distinct cheap/expensive cases and a souvenir package");
    List<String> keys=new ArrayList<>();CaseType[] containers={cases.get(0),cases.get(1),souvenir};double[] prices={1,1000,3};for(int n=0;n<3;n++){CaseType ct=containers[n];ContainerMarketService.publish(ct,prices[n]);app.exchangeContainers.put(ct.catalogCrateName(),ct);InventoryItem i=item(ct.catalogCrateName(),"Normal","Container",0);app.globalMarketListings.put(i.name,new ArrayList<>(List.of(lot(i,prices[n],500))));keys.add(i.name);}
    InventoryItem skin=item("AK-47 | Slate","Field-Tested","Restricted",.2);app.globalMarketListings.put(skin.name,new ArrayList<>(List.of(lot(skin,10,500))));keys.add(skin.name);int cheap=0,expensive=0,packages=0,skins=0;
    for(int n=0;n<1500;n++){HomeUnboxEntry e=app.marketHomeFeeds.rollHomeMarketSale(keys,false);if(e==null)continue;if(e.record.skinName.equals(containers[0].catalogCrateName()))cheap++;if(e.record.skinName.equals(containers[1].catalogCrateName()))expensive++;if(e.record.skinName.equals(souvenir.catalogCrateName()))packages++;if(e.record.skinName.equals(skin.name))skins++;}
    check(cheap>0&&packages>0&&skins>0&&cheap>expensive*5,"Recently Sold includes skins, cases and souvenir packages, with cheap cases outselling expensive cases ("+cheap+" / "+expensive+" / "+packages+" / "+skins+")");
    for(int n=0;n<1000;n++){int a=app.marketHomeFeeds.nextHomeSoldDelay(),b=app.marketHomeFeeds.nextHomeUnboxDelay();if(a<30||a>150||b<30||b>150)throw new AssertionError("Wrong feed delay");}check(true,"Both Home feed delays always fall within 30–150ms");app.globalMarketListings.clear();
  }
  static void acknowledge()throws Exception{MarketplaceOpeningChecks.waitFor(()->MarketplaceOpeningChecks.dialog("New Items")!=null,4000);JDialog d=MarketplaceOpeningChecks.dialog("New Items");check(d!=null&&app.mainTabs.getSelectedIndex()==2&&"EVERYTHING".equals(app.cs2InventorySection),"Quick-open reward appears in New Items over main Inventory");edt(()->MarketplaceOpeningChecks.button(d,"CONTINUE").doClick());MarketplaceOpeningChecks.waitFor(()->!app.itemRevealService.showing,3000);}
  static void quickOpen()throws Exception{
    CaseType ct=Cs2RedesignTests.source("Revolution Case");ct.price=1.23;app.verifiedCaseQuotes.add(ct.id);ContainerMarketService.publish(ct,1.23);
    edt(()->{app.inventoryToolsService.closeBrowser();app.containerInventoryService.buyOwnedSupplies(ct,false,1);app.containerInventoryService.buyOwnedSupplies(ct,true,1);app.inventoryToolsService.state.newItems.clear();app.currentCase=ct;app.navigationService.mainInventory();app.openingArtworkService.prepareOpeningArtwork(ct);});
    int before=app.inventoryList.size(),cases=app.containerInventoryService.ownedSupplyCount(ct,false),keys=app.containerInventoryService.ownedSupplyCount(ct,true);
    edt(()->app.caseOpeningScreen.openCrateWithAnimation());JDialog opening=MarketplaceOpeningChecks.dialog("Opening Case...");check(opening!=null&&app.inventoryList.size()==before,"Case reel is still playing before its early close");edt(opening::dispose);acknowledge();
    check(app.inventoryList.size()==before+1&&app.containerInventoryService.ownedSupplyCount(ct,false)==cases-1&&app.containerInventoryService.ownedSupplyCount(ct,true)==keys-1&&!app.isAnimating,"Early case close consumes exactly one matching case/key and grants exactly one reward");edt(opening::dispose);check(app.inventoryList.size()==before+1,"Repeated case disposal cannot duplicate the quick-open reward");
    int start=app.inventoryList.size();
    edt(()->{app.activeMissions.clear();app.playerStars=8;app.storeScreen.open("ARMOURY");find(app,JButton.class,"storeArmouryCollection-0").doClick();find(app,JButton.class,"armouryRedeem").doClick();});
    check(app.armouryAnimating&&app.playerStars==4&&app.inventoryList.size()==start+1,"Armoury orbit charges four stars once and immediately commits one durable reward");
    MarketplaceOpeningChecks.waitFor(()->MarketplaceOpeningChecks.dialog("New Item")!=null,6000);JDialog armoury=MarketplaceOpeningChecks.dialog("New Item");
    check(armoury!=null&&find(armoury,JComponent.class,"tradeUpResultInfo")==null,"Armoury reveals New Item in place of the removed reel, without info hover");
    edt(armoury::dispose);MarketplaceOpeningChecks.waitFor(()->!app.armouryAnimating,3000);
    check(app.inventoryList.size()==start+1&&app.playerStars==4,"Closing Armoury restores the catalog without another reward or charge");edt(armoury::dispose);check(app.inventoryList.size()==start+1,"Repeated Armoury disposal cannot duplicate its reward");
  }
  public static void main(String[] args)throws Exception{
    Thread.setDefaultUncaughtExceptionHandler((t,e)->{e.printStackTrace();System.exit(1);});Cs2RedesignTests.setup();app=Cs2RedesignTests.gui;
    armoury();navigationAndHover();booksAndHistory();feeds();quickOpen();edt(()->{for(Window w:Window.getWindows())w.dispose();});System.out.println("All "+checks+" liquidity follow-up checks passed.");System.exit(0);
  }
}
