from pathlib import Path
import subprocess,time,json,sys
R=Path('/home/user');rows=[]
for suite in sys.argv[1:]:
 cwd=R/'.cache'/('liquidity-'+suite);cwd.mkdir(exist_ok=True)
 for p in cwd.glob('csgo_simulator_save.*'):p.unlink()
 log=R/'verification'/('liquidity-'+suite+'.txt');t=time.monotonic()
 with log.open('w') as f:
  try:code=subprocess.run(['xvfb-run','-a','-s','-screen 0 1600x1000x24','java','-Xmx900m','-cp',str(R/'.cache/modular-classes'),'blahblah.'+suite],cwd=cwd,stdout=f,stderr=subprocess.STDOUT,timeout=150).returncode
  except subprocess.TimeoutExpired:code=124
 text=log.read_text();row=dict(suite=suite,exit_code=code,passing_checks=sum(x.startswith('PASS:') for x in text.splitlines()),seconds=round(time.monotonic()-t,2),log=log.name);rows.append(row);print(json.dumps(row),flush=True)
 if code:print(text[-3000:],flush=True)
(R/'verification'/('liquidity-native-'+sys.argv[1]+'.json')).write_text(json.dumps(rows,indent=2)+'\n')
raise SystemExit(any(r['exit_code'] for r in rows))
