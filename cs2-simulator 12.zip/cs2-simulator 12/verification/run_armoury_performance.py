from pathlib import Path
import subprocess,json,time
R=Path('/home/user');results=[]
for suite in ['IndividualMarketChecks','ArtworkMirrorChecks','IndividualResponsivenessChecks']:
 cwd=R/'.cache'/('armoury-final-'+suite);cwd.mkdir(exist_ok=True)
 for p in cwd.glob('csgo_simulator_save.*'):p.unlink()
 start=time.monotonic();log=R/'verification'/('armoury-'+suite+'.txt')
 with log.open('w') as stream:
  try:code=subprocess.run(['xvfb-run','-a','-s','-screen 0 1600x1000x24','java','-Xmx900m','-cp',str(R/'.cache/modular-classes'),'blahblah.'+suite],cwd=cwd,stdout=stream,stderr=subprocess.STDOUT,timeout=180).returncode
  except subprocess.TimeoutExpired:code=124
 text=log.read_text();row=dict(suite=suite,exit_code=code,passing_checks=sum(line.startswith('PASS:') for line in text.splitlines()),seconds=round(time.monotonic()-start,2),log=log.name);results.append(row);print(json.dumps(row),flush=True)
 if code:print(text[-4000:],flush=True)
(R/'verification/armoury-performance-summary.json').write_text(json.dumps(results,indent=2)+'\n');raise SystemExit(any(r['exit_code'] for r in results))
