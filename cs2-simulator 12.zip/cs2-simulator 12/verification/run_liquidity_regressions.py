"""Run retained runtime suites against modular bytecode. Reflection adapters do not change expected math.
Legacy textual source-pattern guards still inspect the archived single-file baseline; those are not
claimed as fresh modular-source inspections. Native runtime checks are logged separately.
"""
from pathlib import Path
import json,subprocess,time
ROOT=Path('/home/user');results=[]
for path in sorted((ROOT/'verification').glob('*Tests.java')):
    if path.stem in ('Cs2RedesignTests','MarketEventsAndOpeningTests'):continue
    start=time.time();log=ROOT/'verification'/('modular-'+path.stem+'.txt')
    with log.open('w') as stream:
        try:
            proc=subprocess.run(['java','-Xmx1g','-Djava.awt.headless=true','-cp',str(ROOT/'.cache/modular-classes'),'blahblah.HarnessRunner',path.stem],cwd=ROOT,stdout=stream,stderr=subprocess.STDOUT,timeout=160)
            status=proc.returncode
        except subprocess.TimeoutExpired:status=124
    text=log.read_text();row=dict(suite=path.stem,exit_code=status,passing_checks=sum(line.startswith('PASS:') for line in text.splitlines()),seconds=round(time.time()-start,2),log=log.name)
    results.append(row);print(json.dumps(row),flush=True)
    if status:print(text[-2500:],flush=True)
summary=dict(suites=len(results),passed_suites=sum(r['exit_code']==0 for r in results),passing_checks=sum(r['passing_checks'] for r in results),source_pattern_note='Legacy textual guards inspect unchanged single-file baseline; runtime assertions execute newly compiled modular classes.',results=results)
(ROOT/'verification/modular-regression-summary.json').write_text(json.dumps(summary,indent=2)+'\n')
print(json.dumps({k:v for k,v in summary.items() if k!='results'}),flush=True)
raise SystemExit(0 if summary['passed_suites']==summary['suites'] else 1)
