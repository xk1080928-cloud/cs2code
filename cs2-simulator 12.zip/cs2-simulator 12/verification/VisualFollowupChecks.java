package blahblah;
import java.awt.*;import java.awt.image.BufferedImage;import java.nio.file.*;import java.math.BigDecimal;import java.util.*;import java.util.List;import java.util.concurrent.*;import javax.swing.*;

/** Actual rendered pixels, modal lifecycle, identity layout and blocked-EDT startup-price checks. */
public class VisualFollowupChecks {
 static hGui app;static int checks;
 static void check(boolean b,String s){if(!b)throw new AssertionError(s);checks++;System.out.println("PASS: "+s);}
 static void edt(MarketHomeFeedTests.Throwing r)throws Exception{Cs2RedesignTests.edt(r);}
 static <T>T find(Component c,Class<T> t,String n){return Cs2RedesignTests.find(c,t,n);}
 static void waitFor(java.util.function.BooleanSupplier s,long n)throws Exception{MarketplaceOpeningChecks.waitFor(s,n);}
 static BufferedImage render(JComponent c)throws Exception{BufferedImage[] out={null};edt(()->{out[0]=new BufferedImage(c.getWidth(),c.getHeight(),2);Graphics2D g=out[0].createGraphics();c.printAll(g);g.dispose();});return out[0];}
 static void shot(JComponent c,String name)throws Exception{javax.imageio.ImageIO.write(render(c),"png",Path.of("/home/user/.cache/visual-"+name+".png").toFile());}
 static int brightness(int rgb){Color c=new Color(rgb);return c.getRed()+c.getGreen()+c.getBlue();}
 static InventoryItem item(String n,String r,boolean st){return new InventoryItem(null,n,"Field-Tested",r,BigDecimal.TEN,.2,st,281,null,10);}
 static void startup()throws Exception{
  waitFor(()->app.pendingMarketPriceLookups.isEmpty(),30000);
  edt(()->{app.backgroundUnboxing.stop();if(app.marketTimer!=null)app.marketTimer.stop();if(app.fakeSalesTimer!=null)app.fakeSalesTimer.stop();app.cs2EquipmentScreens.ensureDefaultWeaponInventory();});
  check(app.inventoryList.stream().anyMatch(app.cs2EquipmentScreens::isDefaultWeaponItem),"Price probe includes the real stock defaults that previously defeated the empty-inventory startup guard");
  app.startupWorkStarted=true;app.marketInitialized=false;
  synchronized(app.publicPriceFeeds.publicPriceProviderLock("csfloat")){
   app.publicPriceSnapshots.put("csfloat","{\"AK-47 | Slate (Field-Tested)\":{\"price\":172.30}}");app.publicPriceSnapshotTimes.put("csfloat",System.currentTimeMillis());app.publicPriceSnapshotIndexes.remove("csfloat");app.publicPriceIndexSources.remove("csfloat");
  }
  CountDownLatch held=new CountDownLatch(1),release=new CountDownLatch(1);
  SwingUtilities.invokeLater(()->{held.countDown();try{release.await(2,TimeUnit.SECONDS);}catch(InterruptedException e){Thread.currentThread().interrupt();}});
  if(!held.await(2,TimeUnit.SECONDS))throw new AssertionError("EDT did not enter probe hold");
  long began=System.nanoTime();boolean committed;
  try{app.marketPriceLookups.remove("AK-47 | Slate");app.itemPriceService.scheduleMarketPriceLookup("AK-47 | Slate",5);long end=System.nanoTime()+900_000_000L;while(app.pendingMarketPriceLookups.contains("AK-47 | Slate")&&System.nanoTime()<end)Thread.sleep(5);committed=!app.pendingMarketPriceLookups.contains("AK-47 | Slate")&&app.liveConditionPriceMultipliers.containsKey("AK-47 | Slate");}
  finally{release.countDown();}
  check(committed,"Resolved startup quotes commit/cache fully even while EDT is intentionally unavailable; no per-price UI queue debt ("+(System.nanoTime()-began)/1_000_000+" ms)");
  check(Math.abs(app.liveBasePrices.get("AK-47 | Slate")*app.liveConditionPriceMultipliers.get("AK-47 | Slate").get("Field-Tested")-172.30)<1e-7,"Worker-side startup commit preserves the exact real quote and exterior multiplier");
  app.marketInitialized=true;edt(()->{});
 }
 static void missions()throws Exception{
  edt(()->{app.setSize(1366,768);app.missionService.generateNewMissions();app.cs2Screens.refreshCs2Home();app.mainTabs.setSelectedIndex(0);app.pageTransitions.stop();app.validate();});
  JPanel board=find(app,JPanel.class,"cs2HomeMissions");check(board.getWidth()>=420&&board.getWidth()<=480&&board.getHeight()<610,"Mission briefing is narrow and fits the desktop");
  int last=-1;
  for(Mission m:app.activeMissions){JPanel card=find(board,JPanel.class,"homeMission-"+m.id);check(card.getY()>last&&card.getHeight()<130,"Missions occupy a single compact vertical column: "+m.name);last=card.getY();JTextArea objective=find(board,JTextArea.class,"homeMissionObjective-"+m.id);check(objective.getText().equals(m.description)&&objective.getHeight()>=objective.getFontMetrics(objective.getFont()).getHeight(),"Objective remains visible: "+m.name);}
  shot(board,"missions");
 }
 static void transitions()throws Exception{
  edt(()->app.mainTabs.setSelectedIndex(2));
  waitFor(()->{JComponent o=find(app,JComponent.class,"pageTransitionOverlay");return o!=null&&o.getWidth()>0;},3000);
  JComponent overlay=find(app,JComponent.class,"pageTransitionOverlay");BufferedImage first=render(overlay);Thread.sleep(70);BufferedImage second=render(overlay);
  int changed=0;for(int y=0;y<first.getHeight();y+=12)for(int x=0;x<first.getWidth();x+=12)if(first.getRGB(x,y)!=second.getRGB(x,y))changed++;
  check(changed>100,"Actual rendered tab transition visibly moves/fades the incoming scene, not an imperceptible timer-only wash ("+changed+" changed sampled pixels)");
  waitFor(()->find(app,JComponent.class,"pageTransitionOverlay")==null,1500);
  edt(()->{app.cs2Screens.refreshCs2Inventory();app.pageTransitions.begin();app.pageTransitions.finish();});check(find(app,JComponent.class,"pageTransitionOverlay")==null,"Content/purchase-like refreshes on the same tab do not animate");
  edt(()->app.cs2Screens.selectCs2InventorySection("EQUIPMENT"));check(find(app,JComponent.class,"pageTransitionOverlay")!=null,"Actual Inventory section-tab navigation also animates, without enabling ordinary refresh transitions");
  waitFor(()->find(app,JComponent.class,"pageTransitionOverlay")==null,1500);

 }
 static void inventory()throws Exception{
  JPanel grid=find(app,JPanel.class,"cs2InventoryGrid");JScrollPane scroll=(JScrollPane)SwingUtilities.getAncestorOfClass(JScrollPane.class,grid);
  check(!grid.isOpaque()&&!scroll.getViewport().isOpaque(),"No solid dark-gray slab remains behind Inventory cards");
  JPanel[] tile={null};edt(()->{tile[0]=app.cs2Screens.createCs2Tile("Test","Skin",Color.RED,new JLabel(),null);tile[0].setSize(160,155);DevGeneratorTests.layout(tile[0]);});
  JPanel well=find(tile[0],JPanel.class,"cs2CardWell");BufferedImage art=render(well);
  int top=brightness(art.getRGB(10,3)),middle=brightness(art.getRGB(10,well.getHeight()/2)),bottom=brightness(art.getRGB(10,well.getHeight()-9));
  check(!tile[0].isOpaque()&&middle==bottom&&top<middle-25,"Skin cards have solid gray bodies and a short BLACK gradient only at the TOP");shot(app.inventoryTabPanel,"inventory");
 }
 static void armoury()throws Exception{
  edt(()->{app.storeScreen.open("ARMOURY");find(app,JButton.class,"storeArmouryCollection-0").doClick();app.pageTransitions.stop();app.validate();});
  JPanel grid=find(app,JPanel.class,"armourySkinGrid");
  for(Component c:grid.getComponents()){
   JLabel name=find(c,JLabel.class,"armourySkinName"),dot=find(c,JLabel.class,"armouryRarityDot");Point a=SwingUtilities.convertPoint(name,0,0,c),b=SwingUtilities.convertPoint(dot,0,0,c);
   check(b.y>=a.y+name.getHeight()&&Math.abs(b.x+dot.getWidth()/2-c.getWidth()/2)<=2,"Rarity dot is centered directly beneath the skin name");
  }
  shot(app.storeScreen.armouryHost(),"armoury");
 }
 static void identities()throws Exception{
  InventoryItem gun=item("AK-47 | Redline","Classified",true);InventoryItem knife=item("Karambit | Doppler (Ruby)","Knife",true),gloves=item("Sport Gloves | Vice","Gloves",false);
  check(ItemPresentation.name(app,gun).equals("StatTrak™ AK-47 | Redline"),"StatTrak is explicit in the inspection/reward name");
  check(ItemPresentation.name(app,knife).equals("★ StatTrak™ Karambit | Doppler (Ruby)")&&ItemPresentation.name(app,gloves).equals("★ Sport Gloves | Vice"),"Knives/gloves receive exactly one leading star with correctly ordered StatTrak labeling");
  JPanel normal=ItemPresentation.identity(app,gun,19,"probe",false);check(find(normal,JLabel.class,"probeCollectionIcon")!=null&&find(normal,JLabel.class,"probeCollectionName").getText().equals("The Phoenix Collection"),"Gun identity includes the genuine collection emblem and collection subtitle");
  check(CollectionEmblems.icon("The Phoenix Collection")!=null&&CollectionEmblems.icon("The Sport & Field Collection")!=null,"Embedded genuine collection emblems cover ordinary cases as well as Armoury collections");
  SwingUtilities.invokeLater(()->app.cs2Screens.showCs2Inspect(gun));waitFor(()->MarketplaceOpeningChecks.dialog("Inspect")!=null,4000);JDialog inspect=MarketplaceOpeningChecks.dialog("Inspect");
  JLabel name=find(inspect,JLabel.class,"inspectItemName"),collection=find(inspect,JLabel.class,"inspectItemCollectionName"),icon=find(inspect,JLabel.class,"inspectItemCollectionIcon");
  Point n=SwingUtilities.convertPoint(name,0,0,inspect),c=SwingUtilities.convertPoint(collection,0,0,inspect),i=SwingUtilities.convertPoint(icon,0,0,inspect);
  check(name.getText().equals("StatTrak™ AK-47 | Redline")&&c.y>n.y&&i.x<n.x,"Actual inspection lays out collection below name with its icon to the left of both");waitFor(()->app.activeResultImageLabel!=null&&app.activeResultImageLabel.getText().isEmpty(),10000);shot((JComponent)inspect.getContentPane(),"inspect");edt(inspect::dispose);
  edt(()->{app.inventoryList.add(gun);app.inventoryToolsService.state.newItems.clear();app.itemRevealService.received(gun);app.pageTransitions.stop();});
  Point sample=new Point(20,200);Point at=SwingUtilities.convertPoint(app.getContentPane(),sample,app);Point onScreen=new Point(app.getLocationOnScreen().x+at.x,app.getLocationOnScreen().y+at.y);Robot robot=new Robot();int before=brightness(robot.getPixelColor(onScreen.x,onScreen.y).getRGB());
  SwingUtilities.invokeLater(()->app.itemRevealService.show(List.of(gun),true,"Armoury Redeem"));waitFor(()->MarketplaceOpeningChecks.dialog("New Item")!=null,4000);JDialog popup=MarketplaceOpeningChecks.dialog("New Item");
  check("itemRevealDim".equals(app.getGlassPane().getName())&&app.getGlassPane().isVisible(),"Full dim layer is installed and laid out before New Item becomes visible");
  int early=brightness(robot.getPixelColor(onScreen.x,onScreen.y).getRGB());Thread.sleep(120);int late=brightness(robot.getPixelColor(onScreen.x,onScreen.y).getRGB());
  check(early<=before*.65+5&&Math.abs(early-late)<10,"Native owner pixels are already dimmed on the first popup frame, not a delayed second later");
  JPanel panel=find(popup,JPanel.class,"tradeUpResultPanel");render(panel);double angle=((Number)panel.getClientProperty("backgroundRotation")).doubleValue();Thread.sleep(150);render(panel);double next=((Number)panel.getClientProperty("backgroundRotation")).doubleValue();
  check(next>angle&&next-angle<.1,"New Item's line background rotates slowly, independently of the fixed title/artwork");
  check(find(popup,JLabel.class,"tradeUpResultCollectionIcon")!=null&&find(popup,JLabel.class,"tradeUpResultCollectionName").getText().equals("The Phoenix Collection"),"New Item also places the genuine collection emblem beside name and collection");
  shot((JComponent)popup.getContentPane(),"new-item");edt(()->MarketplaceOpeningChecks.button(popup,"CONTINUE").doClick());waitFor(()->!app.itemRevealService.showing,1000);edt(()->{});
  check(!"itemRevealDim".equals(app.getGlassPane().getName())&&!app.inventoryToolsService.state.newItems.contains(gun.itemId),"Continue synchronously clears dim/pending acknowledgement before the modal call returns");
 }
 static void redemption()throws Exception{
  edt(()->{app.playerStars=8;app.activeMissions.clear();app.storeScreen.open("ARMOURY");find(app,JButton.class,"storeArmouryCollection-0").doClick();app.pageTransitions.stop();});
  int before=app.cs2EquipmentScreens.collectibleInventory().size();edt(()->find(app,JButton.class,"armouryRedeem").doClick());waitFor(()->MarketplaceOpeningChecks.dialog("New Item")!=null,6000);JDialog popup=MarketplaceOpeningChecks.dialog("New Item");edt(()->MarketplaceOpeningChecks.button(popup,"CONTINUE").doClick());waitFor(()->!app.armouryAnimating,2000);
  check(!"itemRevealDim".equals(app.getGlassPane().getName())&&!"armouryOrbitEffect".equals(app.getGlassPane().getName())&&app.playerStars==4&&app.cs2EquipmentScreens.collectibleInventory().size()==before+1,"Armoury Continue restores the catalog without stale dim, extra charge or duplicate reward");
 }
 public static void main(String[]args)throws Exception{
  Thread.setDefaultUncaughtExceptionHandler((t,e)->{e.printStackTrace();System.exit(1);});Cs2RedesignTests.setup();app=Cs2RedesignTests.gui;startup();missions();transitions();inventory();armoury();identities();redemption();edt(()->{for(Window w:Window.getWindows())w.dispose();});System.out.println("All "+checks+" visual/startup follow-up checks passed.");System.exit(0);
 }
}
