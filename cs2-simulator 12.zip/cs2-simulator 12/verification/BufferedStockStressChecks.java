package blahblah;
import javax.swing.*;import java.awt.*;import java.awt.image.*;import java.io.*;import java.util.*;

/** Full ten-million-unit book, real order flow and repeated buffer reviews; no stock downscaling. */
public class BufferedStockStressChecks {
 public static void main(String[] args)throws Exception{
  Thread.setDefaultUncaughtExceptionHandler((t,e)->{e.printStackTrace();System.exit(1);});Cs2RedesignTests.network();ByteArrayOutputStream tiny=new ByteArrayOutputStream();javax.imageio.ImageIO.write(new BufferedImage(8,8,2),"png",tiny);Cs2RedesignTests.fallback=tiny.toByteArray();
  java.util.concurrent.CountDownLatch ready=new java.util.concurrent.CountDownLatch(1);hGui[] host={null};
  Cs2RedesignTests.edt(()->{host[0]=new hGui();Cs2RedesignTests.gui=host[0];host[0].setVisible(true);javax.swing.Timer watch=new javax.swing.Timer(100,null);watch.addActionListener(e->{if(!host[0].startupLoadingOverlay.isVisible()){watch.stop();host[0].backgroundUnboxing.stop();host[0].marketTimer.stop();if(host[0].fakeSalesTimer!=null)host[0].fakeSalesTimer.stop();ready.countDown();}});watch.start();});
  if(!ready.await(110,java.util.concurrent.TimeUnit.SECONDS))throw new AssertionError("Startup timeout");hGui app=host[0];if(!app.marketInitialized)throw new AssertionError("Startup failed");
  long initial=app.marketStockService.getTotalMarketListingCount(),world=app.globalSupply.total();
  long baseline=app.marketBuffer.state().baseline;Cs2RedesignTests.check(baseline==10_000_000&&initial>=9_000_000&&initial<=11_000_000,"Startup retains the complete roughly-ten-million-unit market and uses the clarified ten-million-unit center");
  final long[] last={System.nanoTime()},max={0};java.util.List<Long> gaps=new ArrayList<>();javax.swing.Timer[] heartbeat={null};
  Cs2RedesignTests.edt(()->{heartbeat[0]=new javax.swing.Timer(25,e->{long now=System.nanoTime();long gap=(now-last[0])/1_000_000;last[0]=now;gaps.add(gap);max[0]=Math.max(max[0],gap);});heartbeat[0].start();});
  long now=System.currentTimeMillis(),min=initial,high=initial;long start=System.nanoTime();
  for(int n=1;n<=120;n++){
    app.marketDynamics.tick();app.marketBuffer.tick(now+n*5000L);
    int count=app.marketStockService.getTotalMarketListingCount();min=Math.min(min,count);high=Math.max(high,count);
    System.out.println("BUFFER TICK "+n+": units="+count+", relisted="+app.marketBuffer.state().relisted+", issued="+app.marketBuffer.state().issued);
  }
  Cs2RedesignTests.edt(()->heartbeat[0].stop());Collections.sort(gaps);long p95=gaps.get(Math.min(gaps.size()-1,(int)(gaps.size()*.95)));
  System.out.println("FULL BUFFER: baseline="+baseline+", minimum="+min+", maximum="+high+", p95="+p95+" ms, max="+max[0]+" ms, elapsed="+((System.nanoTime()-start)/1e9)+" s");
  java.util.Map<String,long[]> rows=new java.util.HashMap<>();for(java.util.ArrayList<MarketListing> bucket:app.globalMarketListings.values())for(MarketListing l:bucket)if(l.quantity>0){long[] r=rows.computeIfAbsent(MarketplacePricing.variant(l.item),k->new long[2]);r[0]+=l.quantity;r[1]++;}
  long blocked=0,available=0;int blockedGroups=0;for(java.util.Map.Entry<String,Long> e:app.globalSupply.quantities().entrySet()){long[] r=rows.getOrDefault(e.getKey(),new long[2]);long reserve=e.getValue()-r[0];if(r[1]>=BufferedMarketSupply.MAX_LOTS){blocked+=reserve;blockedGroups++;}else available+=reserve;}System.out.println("RESERVE DEPTH: blocked="+blocked+", available="+available+", blockedGroups="+blockedGroups);
  Cs2RedesignTests.check(min>=9_000_000&&high<=11_000_000,"Ten simulated minutes of real full-book order flow remain within a explicit 9–11 million listing band");
  Cs2RedesignTests.check(app.marketBuffer.state().relisted>0&&app.marketBuffer.state().issued==0&&app.globalSupply.total()==world,"Sustained full-stock replenishment recycles NPC reserves without runaway global issuance");
  Cs2RedesignTests.check(p95<150&&max[0]<1500,"Bounded restock batches yield to the EDT and retain full-stock UI responsiveness");
  Cs2RedesignTests.edt(()->{for(Window w:Window.getWindows())w.dispose();});System.out.println("Full buffered stock stress checks passed.");System.exit(0);
 }
}
