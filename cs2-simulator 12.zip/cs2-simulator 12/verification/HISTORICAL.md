# Historical evidence

Current: `card-release-proof.json`, `card-headless-summary.json`, `card-*.txt`, current visual screenshots and VALIDATION.md. Earlier visual/polish/buffer logs and their release counts/policies are historical; decompress `.txt.gz` before following historical paths. The current source manifest and eight-file preserved-math audit override previous source hashes. Original save-schema baselines remain uncompressed.
