# Validation — startup processing and visible interface follow-up

**Release:** 2026-10-20 · complete project · **185 production Java files** · Java 11+.

## Results

| Verification | Result |
|---|---:|
| Production compile, UTF-8 / `--release 11` | PASS |
| Native Swing/artwork suites | **19 / 19; 935 passing assertions** |
| Retained headless suites | **19 / 19; 578 passing assertions** |
| Directed visible-interface suite | **44 assertions** (included above) |
| Exact-price/blocked-EDT startup probe | **1 assertion** (included above) |
| Original save record descriptors / serial UIDs | Unchanged; also checked from the extracted ZIP |
| Collection emblems | **110 embedded genuine images**, provenance/hash audit |
| StatTrak catalog audit | **5,280 entries; 5,280 identical normal/wear PNG URLs; 0 distinct** |

`verification/visual-release-proof.json` records the native results and exact source-manifest hash. `visual-headless-summary.json` records the headless run. Corresponding `visual-*.txt` files contain actual logs. The complete 19-suite native run passed. After a retained headless test exposed overly broad suppression of real pre-initialized-book repricing, the startup-only gate was narrowed; all 19 headless suites and the four affected native startup/visual suites were rerun and passed. This sequence is recorded rather than claiming every test executed in a single final invocation.

Runtime tests execute current modular bytecode. Some retained headless textual guards inspect the archived single-file baseline: they are **not** evidence of fresh modular-source inspection. Verification fixtures and harnesses are development-only and not runtime application dependencies.

## What the new directed checks actually exercise

- A real visible one-column mission briefing with all four objectives; card/board geometry is compact. No View Missions shortcuts.
- Transparent Inventory grid/viewport and the card's solid-gray body/top-only shade. Existing scrolling/caching is retained; transparent viewport scrolling does not use incompatible opaque blitting.
- Actual rendered frame pixels differ during the tab transition. Its 280ms clock begins at first paint, avoiding a timer silently expiring while capture/layout is queued. Both top-level navigation and actual Inventory section-tab changes animate. Same-tab/data/purchase-style refreshes do not create an overlay; transition overlays clean up.
- Genuine visible Armoury thumbnails, with a rarity dot horizontally centered below each name; retained four-column selectors/paging and filled green Redeem.
- Actual inspection and New Item collection identity layout, left emblem/beneath-name subtitle, clean stock-knife title, StatTrak name and single leading knife/glove star.
- New Item owner pixels are already dimmed on the first popup frame. Rotation changes the existing background-ray rendering. Continue removes/restores the glass layer synchronously and idempotently. Armoury return charges once and grants exactly one determined reward; no second dim effect is queued.
- Five native screenshots are included as `verification/visual-{missions,inventory,armoury,inspect,new-item}.png`. These are supporting stills, not substitutes for the timed/pixel assertions. Controlled genuine catalog images are used, not generated artwork.

## Startup diagnosis and limits

Previously a feed price could be printed immediately, but resolving/caching it remained pending behind UI-thread work. Each initial quote also requested UI/ROI work even though the world was not initialized; ordinary stock equipment prevented an older empty-inventory optimization from applying.

The previous complete release was extracted and run with a deliberately occupied EDT. The downloaded **$172.30** quote was still pending after approximately **655ms**. The current release commits/caches that same exact quote while the EDT remains occupied (approximately **11ms** in the final probe). See `visual-previous-startup-commit.txt` and `visual-StartupCommitProbe.txt`.

This is a controlled reproduction of the post-download commit/queue mechanism, **not** a claim that a particular user's native save/startup was replayed or that all future network preloads finish in that time. Quote workers now commit directly only during the empty-book/default-equipment initial phase. Real existing books, player items/listings, normal runtime repricing formulas and fixed asks retain their established behavior. Agent startup prices avoid redundant UI refresh work too. Case-price progress has its own correctly positioned 40% stage. Genuine missing-source/fallback reporting remains.

## Retained full-stock behavior

The real full-book test ran **120 bounded cycles / ten simulated minutes**:

- Initial: **10,000,000** listed units.
- Minimum: **9,851,434**; maximum: **10,604,056**; final: **9,904,038**.
- Reserve units relisted: **9,226,005**; new units issued: **0**.
- EDT heartbeat: **29ms p95**, **808ms observed maximum** in this controlled run. This does not claim no isolated long frames on every platform.

The 9–11M reserve-first policy, compact identities and surviving asks remain. Main-menu/Home-only simulated openings pause outside the correct page with no catch-up. Recent-sales and individual history remain; only the total-cap graph is removed. Ten math/model/supply files compare byte-for-byte with the previous complete release (`visual-preserved-models.json`), including float rules, roll/trade-up math, inventory model and both supply policies.

## Save/reward coverage and test corrections

Retained suites cover actual save/load, legacy extension migration, XP/Stars/missions, pending/owned/stored IDs, floats/patterns/loadouts, early-close/opening reward delivery, whole-batch retrieval and exactly-once Armoury delivery. New display metadata is runtime-only: internal canonical item names and the original save record descriptors were not changed.

Development testing caught and corrected the clean default-knife inspection title. An old fixed 300ms transition timeout was replaced with a bounded wait because the now-visible 280ms animation starts at first paint. The isolated Armoury cost test now clears unrelated randomly generated missions: completing Armoury Debut legitimately awards Stars and must not be mistaken for a duplicate charge/reward. No economic formula or fixed-ask assertion was relaxed. The retained pre-initialized-book repricing test remains unchanged and passes after the startup gate correction.

## Genuine artwork and platform qualifications

Collection sources/original and embedded-preview hashes are in `collection-emblem-sources.json`; fourteen source SVGs were rasterized for embedded header-size PNG previews. All 63 prior genuine Agent previews remain. The StatTrak audit (`stattrak-artwork-audit.json`) records catalog source/date/SHA. No distinct PNG was available among those verified entries: the code retains the genuine matching exterior/standard image and explicitly labels StatTrak rather than fabricating a counter.

Build and controlled desktop tests ran on **Linux/OpenJDK 11 under Xvfb**, with documented catalog/network/artwork fixtures. Source and artwork URL audits were separate. This is **not native macOS or Windows visual verification**, not a fresh live-price audit, and not a benchmark of arbitrary user hardware/network conditions.

## Packaging verification

Run `python3 verification/package_release.py [output.zip]` from the project tree. It validates the 185-source manifest and release proof; decodes and checks all 63 Agent and 110 collection preview hashes; verifies preserved-model hashes and StatTrak audit counts; writes a complete-file manifest; creates a complete ZIP; checks every archived hash and CRC; extracts it; builds with JDK 11; and compares the five original save descriptors. Only then is the destination ZIP replaced. It also writes the ZIP's SHA-256 sidecar and an external package-verification JSON. It does not pretend to rerun the lab-only desktop/network fixtures.

The current release's main README/CHANGELOG/source manifest and `visual-*` evidence take precedence over compressed historical polish/buffer logs and historical release counts.
