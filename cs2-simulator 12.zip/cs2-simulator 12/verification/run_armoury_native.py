from pathlib import Path
import subprocess,json,time
R=Path('/home/user');rows=[]
for suite in ['StoreInventoryChecks','ToolsRevealChecks','IndividualMarketChecks','RetainedUiChecks','MarketplaceExpansionChecks','MarketplaceOpeningChecks','MarketplaceStartupSmoke']:
 cwd=R/'.cache'/('armoury-'+suite);cwd.mkdir(exist_ok=True)
 for p in cwd.glob('csgo_simulator_save.*'):p.unlink()
 log=R/'verification'/('armoury-'+suite+'.txt');start=time.monotonic()
 with log.open('w') as stream:
  try:code=subprocess.run(['xvfb-run','-a','-s','-screen 0 1600x1000x24','java','-Xmx900m','-cp',str(R/'.cache/modular-classes'),'blahblah.'+suite],cwd=cwd,stdout=stream,stderr=subprocess.STDOUT,timeout=160).returncode
  except subprocess.TimeoutExpired:code=124
 text=log.read_text();row=dict(suite=suite,exit_code=code,passing_checks=sum(x.startswith('PASS:') for x in text.splitlines()),seconds=round(time.monotonic()-start,2),log=log.name);rows.append(row);print(json.dumps(row),flush=True)
 if code:print(text[-3500:],flush=True)
(R/'verification/armoury-native-summary.json').write_text(json.dumps(rows,indent=2)+'\n');raise SystemExit(any(r['exit_code'] for r in rows))
