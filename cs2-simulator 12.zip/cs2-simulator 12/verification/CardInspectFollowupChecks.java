package blahblah;

import java.awt.*;
import java.awt.event.*;
import java.awt.image.*;
import java.math.BigDecimal;
import java.nio.file.*;
import java.util.*;
import javax.swing.*;

/** Real Swing event, pixel, source-resolution, market ordering and normal-unboxing assertions. */
public class CardInspectFollowupChecks {
 static hGui app;static int count;
 static void check(boolean b,String m){if(!b)throw new AssertionError(m);count++;System.out.println("PASS: "+m);}
 static void edt(MarketHomeFeedTests.Throwing r)throws Exception{Cs2RedesignTests.edt(r);}
 static <T>T find(Component c,Class<T> t,String n){return Cs2RedesignTests.find(c,t,n);}
 static void waitFor(java.util.function.BooleanSupplier p,int n)throws Exception{MarketplaceOpeningChecks.waitFor(p,n);}
 static InventoryItem gun(){return new InventoryItem(null,"AK-47 | Redline","Field-Tested","Classified",BigDecimal.TEN,.2,true,178,null,10);}
 static void shot(JComponent c,String n)throws Exception{javax.imageio.ImageIO.write(VisualFollowupChecks.render(c),"png",Path.of("/home/user/.cache/card-"+n+".png").toFile());}
 static void cards()throws Exception{
  JPanel[] tile={null};edt(()->{tile[0]=app.cs2Screens.createCs2Tile("Name","Finish",Color.MAGENTA,new JLabel(),null);tile[0].setSize(180,175);DevGeneratorTests.layout(tile[0]);});
  JPanel well=find(tile[0],JPanel.class,"cs2CardWell");BufferedImage i=VisualFollowupChecks.render(well);Color middle=new Color(i.getRGB(8,well.getHeight()/2));
  check(!tile[0].isOpaque(),"Inventory card root is transparent behind skin names");
  Component text=((BorderLayout)tile[0].getLayout()).getLayoutComponent(BorderLayout.SOUTH);check(text instanceof JPanel&&!((JPanel)text).isOpaque(),"Both name/finish rows have no gray backing");
  check(middle.equals(new Color(105,109,113)),"Lighter gray is confined to the artwork well");
  check(VisualFollowupChecks.brightness(i.getRGB(8,3))<VisualFollowupChecks.brightness(i.getRGB(8,well.getHeight()/2))-30,"Short black shade stays at the top of artwork");
  check(well.getY()+well.getHeight()<=text.getY()&&well.getBorder().getBorderInsets(well).bottom==4,"Artwork background ends at its rarity strip above the name");
 }
 static void equipment()throws Exception{
  edt(()->{app.balance=1000;app.inventoryToolsService.buy(true,1);app.inventoryToolsService.buy(false,1);app.inventoryList.add(gun());app.cs2Screens.selectCs2InventorySection("EQUIPMENT");app.pageTransitions.stop();app.validate();});
  check(find(app.inventoryTabPanel,JButton.class,"cs2InventorySTORAGE UNITS")==null,"Storage Units tab is removed from actual Inventory navigation");
  java.util.List<Object> tools=app.cs2Screens.filteredCs2Inventory("EQUIPMENT","");
  check(tools.size()==2&&tools.stream().allMatch(o->o instanceof InventoryToolsState.Tool),"Equipment contains only the storage unit and unused Name Tag, no skins/defaults/cases/keys");
  check(app.cs2Screens.filteredCs2Inventory("EQUIPMENT","name").size()==1,"Equipment search retains tool matching");
  edt(()->app.cs2EquipmentScreens.openLoadoutInventory("USP-S",false));
  check(app.cs2InventorySection.equals("EVERYTHING")&&app.cs2EquipFilter.equals("USP-S")&&app.cs2Screens.filteredCs2Inventory("EVERYTHING","").stream().allMatch(o->o instanceof InventoryItem&&((InventoryItem)o).name.startsWith("USP-S")),"Loadout slot filtering still opens matching skins/defaults in main Inventory, not the tools-only Equipment tab");
  edt(()->{app.cs2EquipFilter=null;app.cs2Screens.selectCs2InventorySection("EVERYTHING");app.pageTransitions.stop();app.validate();});shot(app.inventoryTabPanel,"inventory");
 }
 static void identityAndMouse()throws Exception{
  InventoryItem item=gun();SwingUtilities.invokeLater(()->app.cs2Screens.showCs2Inspect(item));waitFor(()->MarketplaceOpeningChecks.dialog("Inspect")!=null,4000);JDialog dialog=MarketplaceOpeningChecks.dialog("Inspect");
  InspectImageView view=find(dialog,InspectImageView.class,"inspectImageView");waitFor(()->view!=null&&view.getText().isEmpty()&&view.sourceImage()!=null,10000);
  JLabel name=find(dialog,JLabel.class,"inspectItemName"),collection=find(dialog,JLabel.class,"inspectItemCollectionName"),icon=find(dialog,JLabel.class,"inspectItemCollectionIcon");
  check(name.getBorder()!=null&&name.getBorder().getBorderInsets(name).bottom==4&&name.getClientProperty("rarityLine").equals(app.cs2EquipmentScreens.itemColor(item)),"Actual inspection restores a rarity-colored line directly on/below the name");
  check(icon.getIcon().getIconWidth()==64&&icon.getPreferredSize().width==68,"Inspection emblem is increased from 54 to 64 logical pixels");
  check(collection.getText().equals("The Phoenix Collection"),"Inspection retains the genuine collection label below the skin name");
  Image original=app.artworkService.getSkinImageFromName(item.name,item.condition);check(view.sourceImage()==original&&original.getWidth(null)>130,"Inspection paints the original native-resolution PNG, not a 130px ownership thumbnail");
  BufferedImage before=VisualFollowupChecks.render(view);
  edt(()->{long t=System.currentTimeMillis();view.dispatchEvent(new MouseEvent(view,MouseEvent.MOUSE_PRESSED,t,InputEvent.BUTTON1_DOWN_MASK,120,120,1,false,MouseEvent.BUTTON1));view.dispatchEvent(new MouseEvent(view,MouseEvent.MOUSE_DRAGGED,t+1,InputEvent.BUTTON1_DOWN_MASK,185,155,0,false,MouseEvent.NOBUTTON));view.dispatchEvent(new MouseEvent(view,MouseEvent.MOUSE_RELEASED,t+2,0,185,155,1,false,MouseEvent.BUTTON1));});
  check(((Double)view.getClientProperty("inspectPanX"))==65&&((Double)view.getClientProperty("inspectPanY"))==35,"Real dispatched mouse dragging moves the PNG by the pointer delta");
  BufferedImage after=VisualFollowupChecks.render(view);int changed=0;for(int y=0;y<before.getHeight();y+=6)for(int x=0;x<before.getWidth();x+=6)if(before.getRGB(x,y)!=after.getRGB(x,y))changed++;
  check(changed>100,"Rendered inspection pixels actually move after dragging");
  edt(()->view.dispatchEvent(new MouseWheelEvent(view,MouseEvent.MOUSE_WHEEL,System.currentTimeMillis(),0,view.getWidth()/2,view.getHeight()/2,0,false,MouseWheelEvent.WHEEL_UNIT_SCROLL,1,-3)));
  check((Double)view.getClientProperty("inspectZoom")>1,"Mouse wheel zooms the image");
  edt(()->find(dialog,JButton.class,"inspectResetView").doClick());check((Double)view.getClientProperty("inspectZoom")==1&&(Double)view.getClientProperty("inspectPanX")==0,"Reset View restores initial zoom and centering");
  edt(()->{view.dispatchEvent(new MouseWheelEvent(view,MouseEvent.MOUSE_WHEEL,System.currentTimeMillis(),0,30,30,0,false,MouseWheelEvent.WHEEL_UNIT_SCROLL,1,-200));});check((Double)view.getClientProperty("inspectZoom")==4,"Zoom is safely bounded");
  edt(()->view.dispatchEvent(new MouseEvent(view,MouseEvent.MOUSE_CLICKED,System.currentTimeMillis(),0,40,40,2,false,MouseEvent.BUTTON1)));check((Double)view.getClientProperty("inspectZoom")==1,"Double-click resets inspection too");
  check(GoldTradeUpTests.labels(dialog).contains("2D image"),"Inspection is honestly labeled 2D, not represented as 3D");shot((JComponent)dialog.getContentPane(),"inspect");edt(dialog::dispose);
  Image small=HighQualityImages.fit(new BufferedImage(1024,768,2),150,105);check(small instanceof MultiResolutionImage,"Skin thumbnail scaling retains a native-detail high-DPI image variant");
  Image retina=((MultiResolutionImage)small).getResolutionVariant(small.getWidth(null)*2,small.getHeight(null)*2);check(retina.getWidth(null)==small.getWidth(null)*2,"2x screens receive twice the raster detail at the same logical card size");
 }
 static void cases()throws Exception{
  for(String crate:new String[]{"Revolution Case","Operation Phoenix Weapon Case","Chroma Case"}){
   CaseType ct=Cs2RedesignTests.source(crate);InventoryItem item=new InventoryItem(null,ct.name,"Normal","Case",BigDecimal.ONE,0,false,0,null,1);
   JPanel panel=app.itemRevealService.panel(item,()->{});JLabel label=find(panel,JLabel.class,"tradeUpResultCollectionName"),icon=find(panel,JLabel.class,"tradeUpResultCollectionIcon");
   String expected=crate.contains("Revolution")?"The Revolution Collection":crate.contains("Phoenix")?"The Phoenix Collection":"The Chroma Collection";
   check(label.getText().equals(expected)&&icon!=null,"Case New Item identity shows its actual matching collection/emblem: "+crate);
   check(icon.getIcon().getIconWidth()==64,"Case popup shares the larger genuine collection emblem");
  }
 }
 static void market()throws Exception{
  MarketplaceProfile site=MarketplaceProfile.byName("Skinport");InventoryItem a=gun();a.name="AK-47 | Redline";InventoryItem b=gun();b.name="AWP | Asiimov";
  IndividualMarketChecks.app=app;MarketListing expensive=IndividualMarketChecks.lot(a.name,"Field-Tested",2,site.name),cheap=IndividualMarketChecks.lot(b.name,"Field-Tested",2,site.name);expensive.setPrice(90);cheap.setPrice(10);
  app.exchangeSiteStock.put(site.name,new ArrayList<>(java.util.List.of(expensive,cheap)));
  JPanel[] catalog={null};edt(()->catalog[0]=new MarketplaceBuyScreen(app).create(site,""));JComboBox<?> order=find(catalog[0],JComboBox.class,"exchangeBuyPriceSort");
  check(order.getSelectedItem().equals("Price: low to high")&&order.getItemCount()==3,"Marketplace catalog defaults to low-to-high price with no Default entry");
  java.util.List<MarketplaceGroups.Group> groups=(java.util.List<MarketplaceGroups.Group>)catalog[0].getClientProperty("catalogGroups");check(groups.size()==2&&groups.get(0).head().item.name.equals(b.name),"Default catalog order is actually ascending asks, not just a relabeled selector");
  MarketplaceGroups.Group group=app.marketplaceGroups.group(java.util.List.of(expensive)).get(0);edt(()->{app.storeScreen.open("MARKET");new MarketplaceStackPicker(app).buy(site,app,group,l->{});});JComboBox<?> sort=find(app,JComboBox.class,"individualOfferFloatSort");
  check(sort!=null&&sort.getItemCount()==4&&sort.getSelectedItem().equals("Price: lowest first"),"Individual offers also default to ascending price and have no Default-order choice");
 }
 static void unboxing()throws Exception{
  CaseType ct=Cs2RedesignTests.source("Revolution Case");edt(()->{app.activeMissions.clear();app.currentCase=ct;app.containerInventoryService.buyOwnedSupplies(ct,false,1);app.containerInventoryService.buyOwnedSupplies(ct,true,1);app.caseOpeningScreen.openCrateWithAnimation(30,false);});
  waitFor(()->MarketplaceOpeningChecks.dialog("Opening Case...")!=null,10000);JDialog dialog=MarketplaceOpeningChecks.dialog("Opening Case...");waitFor(()->find(dialog,JLabel.class,"unboxItemCollectionName")!=null,30000);
  JLabel label=find(dialog,JLabel.class,"unboxItemCollectionName"),icon=find(dialog,JLabel.class,"unboxItemCollectionIcon");check(icon!=null&&label.getText().equals("The Revolution Collection"),"The actual normally landed unboxing result includes its genuine collection name/emblem");
  check(icon.getIcon().getIconWidth()==64&&find(dialog,JLabel.class,"unboxItemName").getClientProperty("rarityLine")!=null,"Unboxing header uses the larger emblem and name rarity line");
  InventoryItem reward=app.inventoryList.get(app.inventoryList.size()-1);check(reward.image.getImage().getWidth(null)>130,"A newly unboxed owned item retains the original PNG rather than a permanent 130px thumbnail");
  FadePanel completed=DevGeneratorTests.first(dialog,FadePanel.class);waitFor(()->completed.alpha>=1,3000);check(completed.alpha==1,"Normal unboxing collection header is visible after the real result fade completes");int before=app.inventoryList.size();shot((JComponent)dialog.getContentPane(),"unboxing");edt(dialog::dispose);edt(()->{});check(app.inventoryList.size()==before,"Closing the upgraded normal result still cannot duplicate its reward");
 }
 public static void main(String[] args)throws Exception{
  Thread.setDefaultUncaughtExceptionHandler((t,e)->{e.printStackTrace();System.exit(1);});Cs2RedesignTests.setup();app=(hGui)Cs2RedesignTests.gui;
  edt(()->{if(app.marketTimer!=null)app.marketTimer.stop();if(app.fakeSalesTimer!=null)app.fakeSalesTimer.stop();app.backgroundUnboxing.stop();app.setSize(1366,768);});
  cards();equipment();identityAndMouse();cases();market();unboxing();edt(()->{for(Window w:Window.getWindows())w.dispose();});System.out.println("All "+count+" card/inspect follow-up checks passed.");System.exit(0);
 }
}
