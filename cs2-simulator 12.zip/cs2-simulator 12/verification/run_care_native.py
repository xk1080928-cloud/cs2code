"""Serial native checks: isolates each desktop and kills the entire JVM/Xvfb group on timeout.
Controlled HTTPS/artwork fixtures are under the verification workspace, not a live-source audit.
"""
from pathlib import Path
import subprocess,time,json,sys,os,signal
R=Path(__file__).resolve().parents[2]
rows=[]
for suite in sys.argv[1:]:
    cwd=R/'.cache'/('care-'+suite);cwd.mkdir(parents=True,exist_ok=True)
    for p in cwd.glob('csgo_simulator_save.*'):p.unlink()
    log=R/'verification'/('care-'+suite+'.txt');start=time.monotonic()
    with log.open('w') as f:
        proc=subprocess.Popen(['xvfb-run','-a','-s','-screen 0 1600x1000x24','java','-Xmx900m','-cp',str(R/'.cache/modular-classes'),'blahblah.'+suite],cwd=cwd,stdout=f,stderr=subprocess.STDOUT,start_new_session=True)
        try:code=proc.wait(timeout=360 if suite=="BufferedStockStressChecks" else 180)
        except subprocess.TimeoutExpired:
            os.killpg(proc.pid,signal.SIGKILL);proc.wait();code=124
    text=log.read_text();row=dict(suite=suite,exit_code=code,passing_checks=sum(x.startswith('PASS:') for x in text.splitlines()),seconds=round(time.monotonic()-start,2),log=log.name);rows.append(row);print(json.dumps(row),flush=True)
    if code:print(text[-3000:],flush=True)
(R/'verification'/('care-native-'+sys.argv[1]+'.json')).write_text(json.dumps(rows,indent=2)+'\n')
raise SystemExit(any(r['exit_code'] for r in rows))
