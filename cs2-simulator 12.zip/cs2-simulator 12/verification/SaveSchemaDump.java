import java.io.*;
public class SaveSchemaDump {
 public static void main(String[]args)throws Exception {
  for(String name:new String[]{"blahblah.hGui$GameState","blahblah.hGui$GameState$CaseTypeStats","blahblah.hGui$GameState$SerializableInventoryItem","blahblah.hGui$OwnedSupply","blahblah.hGui$ItemHistoryEntry"}) {
    ObjectStreamClass c=ObjectStreamClass.lookup(Class.forName(name));System.out.println(name+" UID="+c.getSerialVersionUID());for(ObjectStreamField f:c.getFields())System.out.println("  "+f.getName()+":"+f.getTypeString()+":"+f.getTypeCode());
  }
 }
}
