package blahblah;
import java.net.*;
import java.io.*;
import java.awt.image.BufferedImage;
import java.nio.file.*;
import java.util.*;
import javax.imageio.ImageIO;

/** Exact-asset mirror recovery, not substitution of a different skin or exterior. */
public class ArtworkMirrorChecks {
 public static void main(String[] args)throws Exception{
  ByteArrayOutputStream out=new ByteArrayOutputStream();BufferedImage expected=new BufferedImage(5,3,BufferedImage.TYPE_INT_ARGB);expected.setRGB(2,1,0xff13af62);ImageIO.write(expected,"png",out);byte[] png=out.toByteArray();List<String> hits=new ArrayList<>();
  URL.setURLStreamHandlerFactory(protocol->!protocol.equals("https")?null:new URLStreamHandler(){protected URLConnection openConnection(URL url){return new URLConnection(url){public void connect(){}public InputStream getInputStream()throws IOException{hits.add(url.toString());if(url.getHost().contains("akamai"))throw new FileNotFoundException("One official edge returns 404");return new ByteArrayInputStream(png);}};}});
  MarketRegressionTests.setup();ImageRepository repo=new ImageRepository(MarketRegressionTests.gui);java.lang.reflect.Field field=ImageRepository.class.getDeclaredField("diskCacheDirectory");field.setAccessible(true);Path dir=Files.createTempDirectory(Path.of("/home/user/.cache"),"exact-mirror-");field.set(repo,dir);
  String original="https://community.akamai.steamstatic.com/economy/image/same-exact-asset";BufferedImage actual=repo.readRemoteCachedImage(original);
  MarketRegressionTests.check(actual.getRGB(2,1)==expected.getRGB(2,1),"An edge-local 404 recovers the exact image bytes from an official HTTPS mirror");
  MarketRegressionTests.check(hits.size()==2&&hits.get(1).equals("https://community.fastly.steamstatic.com/economy/image/same-exact-asset"),"Recovery changes only the official CDN host, never the asset path, skin or exterior");
  repo.readRemoteCachedImage(original);MarketRegressionTests.check(hits.size()==2&&repo.isCachedOnDisk(original),"Recovered exact artwork is cached under the original requested URL with no repeat HTTP call");
  MarketRegressionTests.check(repo.steamArtworkMirrors("https://raw.githubusercontent.com/example/skin/fn.png").size()==1,"Non-Steam wear artwork is not silently redirected to invented mirrors or exteriors");System.out.println("All 4 exact-artwork mirror checks passed.");System.exit(0);
 }
}
