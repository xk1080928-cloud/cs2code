package blahblah;

import java.awt.*;
import java.awt.event.*;
import java.awt.image.BufferedImage;
import java.nio.file.*;
import java.util.*;
import java.util.List;
import javax.swing.*;

/** Directed current-policy native checks. Uses the controlled HTTPS fixture workspace. */
public class PolishChecks {
 static hGui app;static int checks;
 static void check(boolean b,String s){if(!b)throw new AssertionError(s);checks++;System.out.println("PASS: "+s);}
 static void edt(MarketHomeFeedTests.Throwing r)throws Exception{Cs2RedesignTests.edt(r);}
 static <T>T find(Component c,Class<T> t,String n){return Cs2RedesignTests.find(c,t,n);}
 static void waitFor(java.util.function.BooleanSupplier s,long timeout)throws Exception{MarketplaceOpeningChecks.waitFor(s,timeout);}
 static void image(JComponent c,String name)throws Exception{BufferedImage image=new BufferedImage(Math.max(1,c.getWidth()),Math.max(1,c.getHeight()),2);Graphics2D g=image.createGraphics();c.printAll(g);g.dispose();javax.imageio.ImageIO.write(image,"png",Path.of("/home/user/.cache/"+name+".png").toFile());}
 static boolean buttonText(Component c,String text){if(c instanceof JButton&&((JButton)c).getText().toUpperCase().contains(text))return true;if(c instanceof Container)for(Component child:((Container)c).getComponents())if(buttonText(child,text))return true;return false;}
 static void missions()throws Exception{
  edt(()->{app.setSize(1366,768);app.missionService.generateNewMissions();app.cs2Screens.refreshCs2Home();app.mainTabs.setSelectedIndex(0);});Thread.sleep(220);
  edt(()->{JPanel board=find(app,JPanel.class,"cs2HomeMissions");check(board!=null&&!buttonText(board,"VIEW MISSIONS"),"Main-menu briefing has no View Missions button");check(app.activeMissions.size()==4,"Real mission generation supplies four objectives");for(Mission m:app.activeMissions){JTextArea title=find(board,JTextArea.class,"homeMissionName-"+m.id),objective=find(board,JTextArea.class,"homeMissionObjective-"+m.id);check(title!=null&&objective!=null&&objective.getText().equals(m.description)&&objective.isShowing(),"Main menu shows the complete mission and its objective: "+m.name);}check(board.getHeight()>400&&board.getWidth()>=420&&board.getWidth()<=480,"Full mission briefing has a compact single-column layout");image(board,"polish-mission-board");app.storeScreen.open("HOME");check(!buttonText(app.storeScreen.sections.getComponentAt(0),"VIEW MISSIONS"),"Care Package Store Home also removes View Missions");});
 }
 static void transitions()throws Exception{
  edt(()->app.pageTransitions.stop());edt(()->{app.pageTransitions.begin();app.pageTransitions.finish();});check(find(app,JComponent.class,"pageTransitionOverlay")==null,"Generic content/purchase refresh hooks cannot start a tab animation");
  edt(()->app.mainTabs.setSelectedIndex(2));check(find(app,JComponent.class,"pageTransitionOverlay")!=null,"An actual top-level tab switch gets a lightweight transition");waitFor(()->find(app,JComponent.class,"pageTransitionOverlay")==null,1500);edt(()->{});check(find(app,JComponent.class,"pageTransitionOverlay")==null,"Tab transition ends promptly without a queued catch-up effect");
  edt(()->{app.cs2Screens.refreshCs2Inventory();app.cs2Screens.refreshCs2Home();app.storeScreen.refreshHome();});check(find(app,JComponent.class,"pageTransitionOverlay")==null,"Inventory, mission and purchase-like refreshes do not animate when the selected tab is unchanged");
 }
 static void stock()throws Exception{
  edt(()->{app.backgroundUnboxing.stop();if(app.marketTimer!=null)app.marketTimer.stop();app.globalMarketListings.clear();app.inventoryList.clear();app.ownedSupplies.clear();app.activeListings.clear();app.inventoryToolsService.state=new InventoryToolsState();});
  String name="AK-47 | Slate";ArrayList<MarketListing> lots=new ArrayList<>();for(int n=0;n<200;n++){InventoryItem i=new InventoryItem(null,name,"Field-Tested","Restricted",java.math.BigDecimal.valueOf(10+n),.2,false,0,null,10,true);MarketListing l=new MarketListing(i,10+n,120,true);l.isPlayerListing=false;l.quantity=50_000;lots.add(l);}app.globalMarketListings.put(name,lots);app.globalSupply.initialize();app.marketBuffer.initialize(10_000_000);
  long world=app.globalSupply.total();MarketListing parent=lots.get(170);double ask=parent.getPrice();MarketListing identity=app.marketplaceUnitStock.unit(parent,17);
  for(int n=0;n<4;n++)edt(()->{app.marketPriceChanges.ensureMinimumListings();app.marketStockService.trimMarketListingsForResponsiveUi();app.marketPriceChanges.enforceStatTrakListingScarcity();});
  check(app.marketStockService.getTotalMarketListingCount()==10_000_000&&lots.size()==200,"Legacy navigation/repair paths cannot truncate initialized compact lots or collapse ten-million-unit stock");
  check(app.globalSupply.total()==world&&parent.quantity==50_000&&parent.getPrice()==ask&&app.marketplaceUnitStock.unit(parent,17).equals(identity),"Repair preserves global quantity, every surviving parent, fixed asks and selected unit identity");
  check(app.marketBuffer.lower()==9_000_000&&app.marketBuffer.upper()==11_000_000,"Confirmed ongoing listing band is 9–11 million, not 900k–1.1m");
  edt(()->{app.globalMarketListings.clear();app.inventoryToolsService.state=new InventoryToolsState();});
 }
 static void armoury()throws Exception{
  int index=0;for(int n=0;n<hGui.ARMOURY_COLLECTIONS.length;n++)if(hGui.ARMOURY_COLLECTIONS[n].isAgents)index=n;final int agents=index;
  java.lang.reflect.Field previews=ArmouryArtworkCache.class.getDeclaredField("previews");previews.setAccessible(true);((Map<?,?>)previews.get(app.armouryArtworkCache)).clear();
  edt(()->{app.storeScreen.open("ARMOURY");find(app,JButton.class,"storeArmouryCollection-"+agents).doClick();});
  JPanel grid=find(app,JPanel.class,"armourySkinGrid");check(grid!=null&&grid.getComponentCount()==16&&((GridLayout)grid.getLayout()).getColumns()==4,"Agents use readable four-column pages, not dozens of nearly zero-height portraits");
  waitFor(()->{for(Component c:grid.getComponents()){String name=(String)((JComponent)c).getClientProperty("catalogName");if(!app.armouryArtworkCache.contains(name))return false;}return true;},10000);
  check(true,"Every visible agent requests and retains decoded PNG artwork, including after an empty preview cache");
  edt(()->{JButton redeem=find(app,JButton.class,"armouryRedeem");check(redeem.isOpaque()&&redeem.isContentAreaFilled()&&redeem.getBackground().getGreen()>redeem.getBackground().getRed()*2,"Redeem is a filled, platform-independent green box");JPanel icons=find(app,JPanel.class,"armouryCollectionIcons");Point left=SwingUtilities.convertPoint(icons,0,0,app.storeScreen.armouryHost());check(Math.abs(left.x+icons.getWidth()/2-app.storeScreen.armouryHost().getWidth()/2)<12,"Collection selectors are centered uniformly");image(app.storeScreen.armouryHost(),"polish-agents");});
  Set<String> seen=new HashSet<>();while(true){edt(()->{for(Component c:find(app,JPanel.class,"armourySkinGrid").getComponents())seen.add((String)((JComponent)c).getClientProperty("catalogName"));});JButton next=find(app,JButton.class,"armouryAgentsNext");if(!next.isEnabled())break;edt(next::doClick);}int total=0;for(String[] tier:ArmouryBrowserScreen.tiers(hGui.ARMOURY_COLLECTIONS[agents]))if(tier!=null)total+=tier.length;check(seen.size()==total,"Agent paging exposes every genuine catalog entry without omissions or duplicates");
  edt(()->{find(app,JButton.class,"storeArmouryCollection-0").doClick();app.activeMissions.clear();app.playerStars=8;});int before=app.inventoryList.size();int windows=Window.getWindows().length;long start=System.nanoTime();
  edt(()->find(app,JButton.class,"armouryRedeem").doClick());
  check(app.armouryAnimating&&app.playerStars==4&&app.inventoryList.size()==before+1,"Armoury charges once and durably commits precisely one reward before visual work");
  check(Window.getWindows().length==windows&&"armouryOrbitEffect".equals(app.getGlassPane().getName()),"Redemption fades the existing Armoury in place, with no new opening window or reel");
  Thread.sleep(650);edt(()->image((JComponent)app.getGlassPane(),"polish-orbit"));check(MarketplaceOpeningChecks.dialog("New Item")==null,"Geometric orbit does not reveal the item before its two-second animation");
  waitFor(()->MarketplaceOpeningChecks.dialog("New Item")!=null,6000);check((System.nanoTime()-start)/1e9>=1.9,"New Item appears after the requested two-second orbit");JDialog popup=MarketplaceOpeningChecks.dialog("New Item");check(find(popup,JComponent.class,"tradeUpResultInfo")==null,"Armoury New Item has no info hover badge");
  edt(popup::dispose);waitFor(()->!app.armouryAnimating,3000);check(app.cs2EquipmentScreens.collectibleInventory().size()==before+1&&app.playerStars==4&&!"armouryOrbitEffect".equals(app.getGlassPane().getName()),"Closing the reward fades the catalog back, resets the scene and never grants twice");
 }
 static void opening()throws Exception{
  CaseType ct=Cs2RedesignTests.source("Revolution Case");ct.price=1.23;ContainerMarketService.publish(ct,1.23);app.verifiedCaseQuotes.add(ct.id);
  edt(()->{app.containerInventoryService.buyOwnedSupplies(ct,false,1);app.containerInventoryService.buyOwnedSupplies(ct,true,1);app.inventoryToolsService.state.newItems.clear();app.openingArtworkCaseId=null;app.navigationService.mainInventory();});
  SwingUtilities.invokeLater(()->app.cs2Screens.showCs2Container(ct));waitFor(()->MarketplaceOpeningChecks.dialog("Unlock "+ct.name)!=null,15000);
  JDialog unlock=MarketplaceOpeningChecks.dialog("Unlock "+ct.name);for(List<String> names:ct.regularDropNames.values())for(String name:names)check(app.imageRepository.get(app.artworkService.canonicalArtworkName(name))!=null,"First unlock has pinned outcome PNG before it is shown: "+name);
  int windows=Window.getWindows().length;edt(()->MarketplaceOpeningChecks.button(unlock,"UNLOCK CONTAINER").doClick());
  check(app.cs2ContainerDialog==unlock&&app.animationFrame==unlock&&Window.getWindows().length==windows,"Case opening reuses the exact unlock window, without a proxy frame or extra opening panel/window");
  edt(unlock::dispose);waitFor(()->MarketplaceOpeningChecks.dialog("New Items")!=null,5000);edt(()->MarketplaceOpeningChecks.dialog("New Items").dispose());
 }
 static void scrolling()throws Exception{
  edt(()->{app.navigationService.mainInventory();app.inventoryList.clear();for(int n=0;n<60;n++){InventoryItem i=new InventoryItem(null,"AK-47 | Slate","Field-Tested","Restricted",java.math.BigDecimal.valueOf(10),.2,false,n,null,10,true);app.inventoryList.add(i);}app.containerSelectionScreen.invalidateCs2Inventory();app.cs2Screens.refreshCs2Inventory();});Thread.sleep(200);
  edt(()->{JPanel grid=find(app,JPanel.class,"cs2InventoryGrid");JScrollPane pane=(JScrollPane)SwingUtilities.getAncestorOfClass(JScrollPane.class,grid);check(!grid.isOpaque()&&!pane.getViewport().isOpaque()&&pane.getViewport().getScrollMode()==JViewport.SIMPLE_SCROLL_MODE&&!pane.isWheelScrollingEnabled(),"Inventory uses an transparent cached-scene viewport and pixel-eased wheel handling");});
  final long[] last={System.nanoTime()},max={0};javax.swing.Timer[] beat={null};edt(()->{beat[0]=new javax.swing.Timer(16,e->{long now=System.nanoTime();max[0]=Math.max(max[0],(now-last[0])/1_000_000);last[0]=now;});beat[0].start();});
  for(int n=0;n<45;n++){final int direction=n<23?1:-1;edt(()->{JPanel grid=find(app,JPanel.class,"cs2InventoryGrid");JScrollPane pane=(JScrollPane)SwingUtilities.getAncestorOfClass(JScrollPane.class,grid);pane.dispatchEvent(new MouseWheelEvent(pane,MouseEvent.MOUSE_WHEEL,System.currentTimeMillis(),0,100,100,0,false,MouseWheelEvent.WHEEL_UNIT_SCROLL,3,direction));});Thread.sleep(20);}Thread.sleep(200);edt(()->beat[0].stop());check(max[0]<250,"Actual wheel scrolling retains a responsive EDT (maximum heartbeat gap "+max[0]+" ms)");
 }
 public static void main(String[] args)throws Exception{
  Thread.setDefaultUncaughtExceptionHandler((t,e)->{e.printStackTrace();System.exit(1);});Cs2RedesignTests.setup();app=Cs2RedesignTests.gui;missions();transitions();stock();armoury();opening();scrolling();edt(()->{app.backgroundUnboxing.stop();for(Window w:Window.getWindows())w.dispose();});System.out.println("All "+checks+" current polish checks passed.");System.exit(0);
 }
}
