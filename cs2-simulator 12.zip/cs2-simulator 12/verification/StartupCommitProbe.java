package blahblah;
import java.awt.Window;import java.util.concurrent.*;import javax.swing.*;
/** Same downloaded quote while the UI thread is occupied: run against old and current releases. */
public class StartupCommitProbe{
 public static void main(String[] args)throws Exception{
  Thread.setDefaultUncaughtExceptionHandler((t,e)->{e.printStackTrace();System.exit(1);});String mode=args.length==0?"current":args[0];Cs2RedesignTests.setup();hGui app=Cs2RedesignTests.gui;
  MarketplaceOpeningChecks.waitFor(()->app.pendingMarketPriceLookups.isEmpty(),30000);
  Cs2RedesignTests.edt(()->{app.cs2EquipmentScreens.ensureDefaultWeaponInventory();app.backgroundUnboxing.stop();if(app.marketTimer!=null)app.marketTimer.stop();});
  app.startupWorkStarted=true;app.marketInitialized=false;
  synchronized(app.publicPriceFeeds.publicPriceProviderLock("csfloat")){app.publicPriceSnapshots.put("csfloat","{\"AK-47 | Slate (Field-Tested)\":{\"price\":172.30}}");app.publicPriceSnapshotTimes.put("csfloat",System.currentTimeMillis());app.publicPriceSnapshotIndexes.remove("csfloat");app.publicPriceIndexSources.remove("csfloat");}
  CountDownLatch held=new CountDownLatch(1),release=new CountDownLatch(1);SwingUtilities.invokeLater(()->{held.countDown();try{release.await(2,TimeUnit.SECONDS);}catch(InterruptedException e){Thread.currentThread().interrupt();}});held.await();
  app.marketPriceLookups.remove("AK-47 | Slate");long start=System.nanoTime();app.itemPriceService.scheduleMarketPriceLookup("AK-47 | Slate",5);
  while(app.pendingMarketPriceLookups.contains("AK-47 | Slate")&&System.nanoTime()-start<650_000_000L)Thread.sleep(5);
  boolean waiting=app.pendingMarketPriceLookups.contains("AK-47 | Slate");System.out.println("STARTUP COMMIT PROBE: mode="+mode+", quotedPrice=172.30, pendingWhileEDTOccupied="+waiting+", elapsedMs="+(System.nanoTime()-start)/1_000_000);
  release.countDown();if(mode.equals("old")?!waiting:waiting)throw new AssertionError("Unexpected quote commit state");
  System.out.println("PASS: "+(waiting?"Previous release logs the downloaded quote but cannot finish skin-price resolution until the UI queue runs.":"Current startup resolves/caches the exact quote without waiting for UI refresh/ROI work."));
  Cs2RedesignTests.edt(()->{for(Window w:Window.getWindows())w.dispose();});System.exit(0);
 }
}
