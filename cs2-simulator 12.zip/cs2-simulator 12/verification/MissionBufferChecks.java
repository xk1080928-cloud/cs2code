package blahblah;

import java.awt.*;
import java.awt.image.BufferedImage;
import java.io.*;
import java.nio.file.*;
import java.util.*;
import java.util.List;
import javax.swing.*;

/** Current-policy directed checks; controlled HTTPS fixtures, not a native macOS claim. */
public class MissionBufferChecks {
 static hGui app;static int checks;
 static void check(boolean b,String s){if(!b)throw new AssertionError(s);checks++;System.out.println("PASS: "+s);}
 static void edt(MarketHomeFeedTests.Throwing r)throws Exception{Cs2RedesignTests.edt(r);}
 static InventoryItem item(String name,String rarity,double price){return new InventoryItem(null,name,"Normal",rarity,java.math.BigDecimal.valueOf(price),0,false,0,null,price,true);}
 static MarketListing lot(InventoryItem item,int quantity){MarketListing l=new MarketListing(item,item.price.doubleValue(),120,true);l.isPlayerListing=false;l.quantity=quantity;l.marketplaceName="Skinport";return l;}
 static void clear()throws Exception{edt(()->{app.backgroundUnboxing.stop();if(app.marketTimer!=null)app.marketTimer.stop();app.globalMarketListings.clear();app.inventoryList.clear();app.ownedSupplies.clear();app.activeListings.clear();app.inventoryToolsService.state=new InventoryToolsState();app.exchangePlannedStock=0;});}
 static void labels(Component c){if(c instanceof JLabel){JLabel l=(JLabel)c;if(l.getName()!=null&&(l.getName().startsWith("missionXp-")||l.getName().startsWith("missionStars-")||l.getName().startsWith("homeMissionReward-")))check(l.getWidth()>=l.getFontMetrics(l.getFont()).stringWidth(l.getText())&&l.getHeight()>=l.getFontMetrics(l.getFont()).getHeight(),"Full reward/XP text fits: "+l.getName());}if(c instanceof Container)for(Component child:((Container)c).getComponents())labels(child);}
 static void missions()throws Exception{
  edt(()->{app.setSize(1366,768);app.activeMissions.clear();app.activeMissions.add(new Mission("layout-long","Open Cases and Complete High-Quality Trade-Up Contracts","Open matching cases and finish your contract to earn Stars and progression XP.","CASES",100,18));app.activeMissions.add(new Mission("layout-second","Collect a Variety of Different Weapon Finishes","Obtain weapon finishes from different eligible collections.","CASES",200,12));app.mainTabs.setSelectedIndex(0);app.cs2Screens.refreshCs2Home();app.missionScreen.showMissionsWindow();});
  edt(()->{JFrame window=null;for(Window w:Window.getWindows())if(w instanceof JFrame&&"Missions".equals(((JFrame)w).getTitle()))window=(JFrame)w;check(window!=null&&window.getWidth()>=880&&window.getHeight()>=620,"Missions window is enlarged and desktop-bounded");DevGeneratorTests.layout(window);labels(window);JTextArea title=Cs2RedesignTests.find(window,JTextArea.class,"missionName-layout-long");check(title!=null&&title.getLineWrap()&&title.getWrapStyleWord()&&title.getWidth()>350&&title.getHeight()>=2*title.getFontMetrics(title.getFont()).getHeight(),"Long mission names use a readable, genuinely wrapping title area");BufferedImage shot=new BufferedImage(window.getWidth(),window.getHeight(),2);Graphics2D g=shot.createGraphics();window.getContentPane().printAll(g);g.dispose();javax.imageio.ImageIO.write(shot,"png",Path.of("/home/user/verification/buffer-missions-layout.png").toFile());window.dispose();JPanel home=Cs2RedesignTests.find(app,JPanel.class,"cs2HomeMissions");check(home!=null&&home.getWidth()>=420&&home.getWidth()<=480&&home.getHeight()>=278,"Main-menu mission box is compact and single-column");labels(home);BufferedImage shotHome=new BufferedImage(home.getWidth(),home.getHeight(),2);Graphics2D hg=shotHome.createGraphics();home.printAll(hg);hg.dispose();javax.imageio.ImageIO.write(shotHome,"png",Path.of("/home/user/verification/buffer-main-menu-missions-layout.png").toFile());});
 }
 static void buffering()throws Exception{
  clear();InventoryItem src=item("Special Agent Ava | FBI","Master",20);MarketListing original=lot(src,10000);app.globalMarketListings.put(src.name,new ArrayList<>(List.of(original)));app.globalSupply.initialize();app.marketBuffer.initialize(10000);
  MarketListing identity=app.marketplaceUnitStock.unit(original,5000);double f=identity.item.itemFloat;double ask=identity.getPrice();
  edt(()->app.marketplaceUnitStock.trimTo(original,9500));long now=System.currentTimeMillis();app.marketBuffer.state().nextReview=0;app.marketBuffer.tick(now);
  int count=app.marketStockService.getTotalMarketListingCount();check(count>9500&&count<=9700,"Buffered shortage receives only a bounded emergency batch (at most 2%), not an exact full refill");
  check(app.globalSupply.total()==10000&&app.marketBuffer.state().issued==0&&app.marketBuffer.state().relisted==count-9500,"First-pass replenishment relists existing NPC reserves without creating world supply");
  check(original.quantity==9500&&app.marketplaceUnitStock.unit(original,5000).equals(identity)&&app.marketplaceUnitStock.unit(original,5000).item.itemFloat==f&&app.marketplaceUnitStock.unit(original,5000).getPrice()==ask,"New lots leave surviving parent quantities, indexed identities, floats and fixed asks untouched");
  for(int n=1;n<=15;n++)app.marketBuffer.tick(now+n*30_001L);
  int restored=app.marketStockService.getTotalMarketListingCount();check(restored>=app.marketBuffer.lower()&&restored<=app.marketBuffer.upper()&&app.marketBuffer.state().issued==0,"Repeated buffered cycles recover into the modest band without manufacturing exact counts");
  long global=app.globalSupply.total();long relisted=app.marketBuffer.state().relisted;app.marketBuffer.tick(now+15*30_001L+1);check(app.globalSupply.total()==global&&app.marketBuffer.state().relisted==relisted,"Cooldown and deadband prevent constant one-for-one replacement");
  // Fully bought-out variant still has reserves and must not be permanently missing.
  edt(()->app.globalMarketListings.clear());app.marketBuffer.state().nextReview=0;app.marketBuffer.tick(now+1_000_000);check(app.marketStockService.getTotalMarketListingCount()>0&&app.globalSupply.total()==10000,"An empty variant can be relisted directly from its surviving global reserve");
  clear();CaseType ct=Cs2RedesignTests.source("Revolution Case");ContainerMarketService.publish(ct,1.23);InventoryItem container=item(ct.catalogCrateName(),"Container",1.23);app.globalMarketListings.put(container.name,new ArrayList<>(List.of(lot(container,100))));app.globalSupply.initialize();app.marketBuffer.initialize(10000);app.marketBuffer.state().nextReview=0;app.marketBuffer.tick(now+1_000_000);
  check(app.marketBuffer.state().relisted==0&&app.marketBuffer.state().issued>0&&app.marketBuffer.state().issued<=1&&app.globalSupply.total()<=101,"Only exhausted reserves permit tightly limited common/container issuance");
  long baseline=app.marketBuffer.state().baseline;ByteArrayOutputStream bytes=new ByteArrayOutputStream();try(ObjectOutputStream out=new ObjectOutputStream(bytes)){out.writeObject(app.inventoryToolsService.state);}try(ObjectInputStream in=new ObjectInputStream(new ByteArrayInputStream(bytes.toByteArray()))){app.inventoryToolsService.state=(InventoryToolsState)in.readObject();}check(app.marketBuffer.state().baseline==baseline&&app.marketBuffer.state().issued==1,"Optional buffered target and issuance counters survive save-extension round trips");
 }
 static void artwork()throws Exception{
  clear();edt(()->app.storeScreen.open("MARKET"));edt(()->{});
  String skin="AWP | Dragon Lore",wear="Field-Tested";String key=app.artworkService.getSkinArtworkKey(skin,wear);
  check(app.artworkService.getSkinArtworkKey("Souvenir "+skin,wear).equals(key),"Souvenir display prefix resolves to the genuine canonical finish/wear image key");
  java.lang.reflect.Field cache=ImageRepository.class.getDeclaredField("cache");cache.setAccessible(true);((Map<?,?>)cache.get(app.imageRepository)).remove(key);
  HomeUnboxEntry entry=new HomeUnboxEntry(new SaleRecord("Souvenir "+skin,100,wear,.2,null),key,"Covert",null);
  edt(()->{for(MarketHomeUnboxFeed feed:new ArrayList<>(app.activeHomeArtworkFeeds))if(!feed.soldFeed&&feed.isShowing())feed.acceptEntry(entry);});
  MarketplaceOpeningChecks.waitFor(()->app.imageRepository.get(key)!=null,7000);
  Image image=app.imageRepository.get(key);check(image!=null&&image.getWidth(null)>0&&image.getHeight(null)>0,"Visible image-less souvenir entries asynchronously request and receive their PNG without relying on paint to download");
  check(Class.forName("blahblah.MarketHistoryScreen")!=null&&Class.forName("blahblah.SalesHistoryScreen")!=null,"Recent-sales and individual-skin history graph implementations are preserved");
 }
 public static void main(String[] args)throws Exception{
  Thread.setDefaultUncaughtExceptionHandler((t,e)->{e.printStackTrace();System.exit(1);});Cs2RedesignTests.setup();app=Cs2RedesignTests.gui;missions();buffering();artwork();edt(()->{app.backgroundUnboxing.stop();for(Window w:Window.getWindows())w.dispose();});System.out.println("All "+checks+" mission/buffer/artwork checks passed.");System.exit(0);
 }
}
