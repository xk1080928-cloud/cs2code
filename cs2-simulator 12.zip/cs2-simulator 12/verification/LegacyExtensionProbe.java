package blahblah;
import java.io.*;
public class LegacyExtensionProbe {
 public static void main(String[] args)throws Exception{
  if(args[0].equals("write")){
   InventoryToolsState s=new InventoryToolsState();s.supply=new GlobalSupply.State();s.supply.seeded=true;GlobalSupply.Entry e=new GlobalSupply.Entry();e.quantity=201;e.average=123.45;s.supply.variants.put("fixture",e);s.supply.capHistory.add(123.45);s.care=new CarePackages.State();s.care.xp=235;s.care.awarded.add("stable-mission");
   InventoryItem i=new InventoryItem(null,"AK-47 | Redline","Field-Tested","Classified",java.math.BigDecimal.valueOf(22),.23456789,false,321,null,22,true);i.itemId="stable-old-item";s.pendingTradeRewards=new java.util.ArrayList<>(java.util.List.of(InventoryItemCodec.encode(i)));
   try(ObjectOutputStream out=new ObjectOutputStream(new FileOutputStream(args[1]))){out.writeObject(s);}
  }else{
   InventoryToolsState s;try(ObjectInputStream in=new ObjectInputStream(new FileInputStream(args[1]))){s=(InventoryToolsState)in.readObject();}
   if(s.supply.variants.get("fixture").quantity!=201||s.care.xp!=235||!s.care.awarded.contains("stable-mission")||!s.pendingTradeRewards.get(0).itemId.equals("stable-old-item")||s.pendingTradeRewards.get(0).itemFloat!=.23456789||InventoryToolsState.class.getDeclaredField("marketBuffer").get(s)!=null)throw new AssertionError("Old extension changed");
   System.out.println("PASS: Previous complete release's actual serialized extension imports with exact supply, XP, award IDs and pending item identity/float; new buffer defaults safely to null.");
  }
 }
}
