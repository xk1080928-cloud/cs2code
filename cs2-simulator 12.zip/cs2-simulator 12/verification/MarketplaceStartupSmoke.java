package blahblah;
import javax.swing.*;import java.awt.*;import java.awt.image.*;import java.io.*;import java.nio.file.*;import java.util.*;
public class MarketplaceStartupSmoke {
 public static void main(String[]args)throws Exception{
  Thread.setDefaultUncaughtExceptionHandler((thread,error)->{error.printStackTrace();System.exit(1);});
  Cs2RedesignTests.network();ByteArrayOutputStream small=new ByteArrayOutputStream();javax.imageio.ImageIO.write(new BufferedImage(8,8,BufferedImage.TYPE_INT_ARGB),"png",small);Cs2RedesignTests.fallback=small.toByteArray();
  java.util.concurrent.CountDownLatch ready=new java.util.concurrent.CountDownLatch(1);final hGui[] frame={null};final javax.swing.Timer[] watch={null};long start=System.nanoTime();final boolean[] captured={false};
  Cs2RedesignTests.edt(()->{frame[0]=new hGui();Cs2RedesignTests.gui=frame[0];frame[0].setVisible(true);watch[0]=new javax.swing.Timer(100,e->{try{String status=(String)Cs2RedesignTests.get("startupProgressStatus");if(!captured[0]&&status.contains("Generating listings:")){captured[0]=true;System.out.println("VISIBLE GENERATION COUNTER: "+status);javax.imageio.ImageIO.write(new Robot().createScreenCapture(new Rectangle(Toolkit.getDefaultToolkit().getScreenSize())),"png",Path.of("/home/user/verification/marketplace-visible-listing-counter.png").toFile());}if(!( (JPanel)Cs2RedesignTests.get("startupLoadingOverlay")).isVisible()){watch[0].stop();frame[0].backgroundUnboxing.stop();if(frame[0].marketTimer!=null)frame[0].marketTimer.stop();if(frame[0].fakeSalesTimer!=null)frame[0].fakeSalesTimer.stop();ready.countDown();}}catch(Exception ex){throw new RuntimeException(ex);}});watch[0].start();});
  Thread.sleep(600);Cs2RedesignTests.capture("marketplace-startup-overlay.png");
  if(!ready.await(110,java.util.concurrent.TimeUnit.SECONDS))throw new AssertionError("Full startup did not finish: "+Cs2RedesignTests.get("startupProgressStatus"));
  if(!(Boolean)Cs2RedesignTests.get("marketInitialized"))throw new AssertionError("Startup reported failure; inspect its stack trace.");
  System.out.printf("Full mocked-HTTPS desktop startup seconds: %.3f%n",(System.nanoTime()-start)/1e9);
  Cs2RedesignTests.check(captured[0],"The real loading overlay visibly reports generated / planned listing counts during generation");
  Cs2RedesignTests.check((Integer)Cs2RedesignTests.get("startupProgressPercent")==100,"The real fullscreen constructor completes its normal staged startup at 100%");
  Map<?,?> artwork=(Map<?,?>)Cs2RedesignTests.get("cs2KeyArtwork");Cs2RedesignTests.check(artwork.size()>30,"Case-specific key PNGs are warmed before the loading overlay closes ("+artwork.size()+" case mappings)");
  Cs2RedesignTests.check(((java.util.List<?>)Cs2RedesignTests.get("ownedSupplies")).isEmpty(),"A fresh startup does not grant free cases or keys");
  Map<?,?> models=(Map<?,?>)Cs2RedesignTests.get("simulatedSalesStates");Cs2RedesignTests.check(models.size()>10000,"The redesigned application still seeds full-market simulated sales histories ("+models.size()+" variants)");
  int units=(Integer)Cs2RedesignTests.call("getTotalMarketListingCount",new Class[0]);Cs2RedesignTests.check(units>9500000&&units<11500000,"Startup builds roughly ten million real purchasable stock units ("+units+")");
  Map<String,java.util.List<MarketListing>> sites=(Map)Cs2RedesignTests.get("exchangeSiteStock");java.util.Set<Integer> sizes=new java.util.HashSet<>();int sum=0;for(java.util.List<MarketListing> stock:sites.values()){int count=stock.stream().mapToInt(l->l.quantity).sum();sizes.add(count);sum+=count;}Cs2RedesignTests.check(sites.size()>=18&&sizes.size()>=16&&sum==units,"Marketplace inventories have unequal sizes and together conserve every generated stock unit");
  Cs2RedesignTests.check((Long)Cs2RedesignTests.get("exchangePlannedStock")==frame[0].globalSupply.total(),"The initial generated/total counter equals full circulating supply; background openings subsequently consume case listings");
  long listings=0;for(Object bucket:((Map<?,?>)Cs2RedesignTests.get("globalMarketListings")).values())listings+=((java.util.List<?>)bucket).size();System.out.println("Materialized stock lots: "+listings);Cs2RedesignTests.check(listings<400000,"Ten-million stock units use bounded compact lots, not millions of heavyweight InventoryItem objects");
  Cs2RedesignTests.capture("marketplace-complete-startup.png");
  Cs2RedesignTests.edt(()->{for(Window w:Window.getWindows())w.dispose();});System.out.println("Full startup smoke test passed.");System.exit(0);
 }
}
