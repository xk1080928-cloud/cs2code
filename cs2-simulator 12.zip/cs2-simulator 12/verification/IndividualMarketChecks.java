package blahblah;

import blahblah.hGui.*;
import java.awt.*;
import java.awt.event.*;
import java.math.*;
import java.nio.file.*;
import java.util.*;
import java.util.List;
import javax.swing.*;

public class IndividualMarketChecks {
  static hGui app;static int checks;
  static void check(boolean value,String message){if(!value)throw new AssertionError(message);checks++;System.out.println("PASS: "+message);}
  static void edt(MarketHomeFeedTests.Throwing action)throws Exception{Cs2RedesignTests.edt(action);}
  static <T>T find(Component c,Class<T> type,String name){return Cs2RedesignTests.find(c,type,name);}
  static void click(Component c){for(MouseListener l:c.getMouseListeners())l.mouseClicked(new MouseEvent(c,MouseEvent.MOUSE_CLICKED,System.currentTimeMillis(),0,8,8,1,false,MouseEvent.BUTTON1));}
  static MarketListing lot(String name,String wear,int quantity,String site){
    InventoryItem i=new InventoryItem(null,name,wear,"Knife",BigDecimal.valueOf(1000),.02,false,42,null,1000,true);
    MarketListing l=new MarketListing(i,1000,120,false);l.marketplaceName=site;l.marketplaceType="INSTANT";l.setPrice(1000);l.quantity=quantity;
    app.globalMarketListings.computeIfAbsent(name,k->new ArrayList<>()).add(l);return l;
  }
  static void floats()throws Exception {
    MarketplaceProfile site=MarketplaceProfile.byName("SkinSwap");
    String name="M9 Bayonet | Gamma Doppler (Emerald)";
    MarketListing one=lot(name,"Factory New",20,site.name),two=lot(name,"Factory New",20,site.name);
    List<MarketListing> parents=new ArrayList<>(List.of(one,two));app.exchangeSiteStock.put(site.name,parents);
    MarketplaceGroups.Group group=app.marketplaceGroups.group(parents).get(0);
    Set<String> floats=new HashSet<>();List<MarketListing> units=new ArrayList<>();
    for(int n=0;n<40;n++){
      MarketListing unit=app.marketplaceUnitStock.at(group,n);units.add(unit);
      check(unit.quantity==1&&unit.stockParent!=null,"Expanded offer "+n+" is one individually addressable unit");
      check(floats.add(String.format(java.util.Locale.US,"%.8f",unit.item.itemFloat)),"Displayed float "+n+" is unique across both lots");
      check("Factory New".equals(app.floatRules.getConditionForFloat(unit.item.name,unit.item.itemFloat)),"Unit "+n+" stays within the genuine skin/wear interval");
    }
    check(group.units()==40&&parents.size()==2,"Expanding forty distinct floats keeps forty stock units and only two compact parent lots");
    MarketListing chosen=units.get(27),same=app.marketplaceUnitStock.at(group,27);
    check(chosen.equals(same)&&chosen.hashCode()==same.hashCode()&&chosen.item.itemFloat==same.item.itemFloat,"Paging and rebuilding preserve individual identity and its exact float");
    app.balance=100000;double before=app.balance,charged=chosen.getPrice();final InventoryItem[] received={null};
    edt(()->received[0]=app.exchangeTransactionService.commitExchangePurchase(chosen,chosen.getPrice()));
    check(received[0].itemFloat==chosen.item.itemFloat&&received[0].patternID==chosen.item.patternID,"Purchasing a non-head offer delivers that exact displayed float and pattern");
    check(group.units()==39&&chosen.stockParent.quantity==19&&(chosen.stockParent==one?two:one).quantity==20&&Math.abs(app.balance-(before-charged))<.000001,"Non-head purchase consumes exactly one unit from the correct parent lot");
    try{app.exchangeTransactionService.commitExchangePurchase(same,same.getPrice());throw new AssertionError("Replay accepted");}catch(IllegalArgumentException expected){check(group.units()==39,"A second wrapper cannot replay an already purchased individual unit");}
    for(int n=0;n<39;n++)check(app.marketplaceUnitStock.at(group,n).item.itemFloat!=chosen.item.itemFloat,"Sold unit never reappears on page rank "+n);
    int tabs=app.exchangeHostSections.getTabCount();int dialogs=Window.getWindows().length;
    edt(()->new MarketplaceStackPicker(app).lots(site,app,group,l->false,l->{}));
    JPanel page=(JPanel)app.exchangeHostSections.getSelectedComponent();JPanel grid=find(page,JPanel.class,"exchangeStackIndividuals");
    check(Boolean.TRUE.equals(page.getClientProperty("temporaryMarketView"))&&app.exchangeHostSections.getTabCount()==tabs+1,"Expanding stock opens a temporary Market tab");
    check(grid.getComponentCount()==15&&Window.getWindows().length==dialogs,"Individual offers are paged, with no new native popup window");
    check(GoldTradeUpTests.labels(page).contains("39 individual offers"),"The tab reports individual stock, not two repeated lot-head offers");
    JButton next=MarketplaceOpeningChecks.button(page,"›");edt(next::doClick);
    check(grid.getComponentCount()==15,"The second page exposes another fifteen independent units");
    edt(()->MarketplaceOpeningChecks.button(page,"Close tab").doClick());check(app.exchangeHostSections.getTabCount()==tabs,"Closing an offer tab removes it and restores the previous view");
    JPanel[] buy={null};edt(()->buy[0]=app.exchangeCatalogScreens.createExchangeBuy(site,"Emerald"));
    JPanel catalog=find(buy[0],JPanel.class,"exchangeBuyGrid");edt(()->click(catalog.getComponent(0)));
    check(Boolean.TRUE.equals(((JPanel)app.exchangeHostSections.getSelectedComponent()).getClientProperty("temporaryMarketView")),"Clicking a multi-quantity Buy card also routes to a temporary per-unit tab");
    MarketListing a=app.marketplaceUnitStock.at(group,0),b=app.marketplaceUnitStock.at(group,1);
    double debit=app.exchangeTransactionService.swapSiteValue(a)+app.exchangeTransactionService.swapSiteValue(b)-app.exchangeTransactionService.swapUserValue(received[0]);
    edt(()->app.exchangeTransactionService.commitExchangeSwap(site,List.of(received[0]),List.of(a,b),debit));
    check(group.units()==37&&app.inventoryList.stream().anyMatch(i->i.itemFloat==a.item.itemFloat)&&app.inventoryList.stream().anyMatch(i->i.itemFloat==b.item.itemFloat),"A swap can select two distinct units from one parent and delivers both displayed floats exactly");
    MarketListing single=lot(name,"Factory New",1,site.name);app.globalMarketListings.put(name,new ArrayList<>(List.of(single)));app.exchangeSiteStock.put(site.name,new ArrayList<>(List.of(single)));
    MarketListing only=app.marketplaceUnitStock.at(app.marketplaceGroups.group(List.of(single)).get(0),0);
    check(only.stockParent==single&&!floats.contains(String.format(java.util.Locale.US,"%.8f",only.item.itemFloat)),"A one-unit backing lot also has its own globally disjoint float identity");
    int tabCount=app.exchangeHostSections.getTabCount();JPanel[] sole={null};edt(()->sole[0]=app.exchangeCatalogScreens.createExchangeBuy(site,"Emerald"));
    edt(()->{JPanel soleGrid=find(sole[0],JPanel.class,"exchangeBuyGrid");Component match=null;for(Component c:soleGrid.getComponents()){MarketplaceGroups.Group g=(MarketplaceGroups.Group)((JComponent)c).getClientProperty("marketGroup");if(g.lots.contains(single)){match=c;break;}}if(match==null)throw new AssertionError("Single offer missing from catalog");click(match);});
    check(app.exchangeHostSections.getTabCount()==tabCount+1&&find(app.exchangeHostSections.getSelectedComponent(),JPanel.class,"exchangeStackIndividuals").getComponentCount()==1,"Even a single-unit skin card opens a temporary individual-offer tab, not a purchase popup");
  }
  static void containers()throws Exception {
    CaseType ct=Cs2RedesignTests.source("Revolution Case");
    Map<CaseType,Double> quotes=new HashMap<>();quotes.put(ct,1.23);edt(()->app.startupArtworkService.applyMarketCasePrices(quotes));
    String name=ct.catalogCrateName();MarketListing lot=lot(name,"Normal",17,"CS.MONEY");
    lot.item.rarity="Container";lot.listPrice=1.23;
    check(lot.getPrice()==1.23,"A container listing starts with its verified real-source cash quote");
    check(lot.getPrice()==1.23,"Simulated order flow does not rewrite an existing container ask");
    ContainerMarketService.publish(ct,2.37);check(lot.getPrice()==1.23,"A replacement public reference does not silently reprice already listed containers");
    ContainerMarketService.publish(ct,null);int units=lot.quantity;
    check(!Double.isFinite(lot.getPrice())&&lot.quantity==units,"Unavailable real quotes are unavailable, not zero/penny prices; stock is not deleted");
    app.exchangeSiteStock.put("CS.MONEY",new ArrayList<>(List.of(lot)));
    JPanel[] unavailable={null};edt(()->unavailable[0]=app.exchangeCatalogScreens.createExchangeBuy(MarketplaceProfile.byName("CS.MONEY"),name));
    JPanel unavailableGrid=find(unavailable[0],JPanel.class,"exchangeBuyGrid");
    check(unavailableGrid.getComponentCount()==1&&GoldTradeUpTests.labels(unavailableGrid).contains("Quote unavailable"),"An unavailable-price container remains visible in the catalog with an honest unavailable label");
    check(!unavailableGrid.getComponent(0).isEnabled()&&Boolean.TRUE.equals(((JPanel)unavailableGrid.getComponent(0)).getClientProperty("quoteUnavailable")),"Unavailable-quote container purchases are disabled, not sold for zero cents");
    ContainerMarketService.publish(ct,1.23);ct.price=1.23;app.verifiedCaseQuotes.add(ct.id);app.caseQuotesResolved=true;
    OwnedSupply owned=new OwnedSupply(ct,false,1.1);app.ownedSupplies.add(owned);
    InventoryItem sale=app.containerMarketService.item(owned);check(app.containerMarketService.owns(sale)&&sale.price.doubleValue()==1.23,"An owned case adapts to the Sell desk at its verified reference price");
    edt(()->app.exchangeScreens.navigateExchangeDirectory(sale));
    JPanel directory=find(app.marketTabPanel,JPanel.class,"marketplaceDirectory");edt(()->find(directory,JButton.class,"marketplaceDirectoryOpen-Skinport").doClick());
    JTabbedPane site=find(app.exchangeHostSections.getSelectedComponent(),JTabbedPane.class,"marketplaceSiteTabs");
    check(site.getSelectedIndex()==2&&find(site,JButton.class,"exchangeSellList")==null,"Owned case selection opens the chosen marketplace Sell desk");
    final MarketListing[] listing={null};edt(()->listing[0]=app.exchangeTransactionService.commitExchangeListing(MarketplaceProfile.byName("Skinport"),sale,1.4));
    check(!app.ownedSupplies.contains(owned)&&app.activeListings.contains(listing[0]),"Listing a case removes exactly its OwnedSupply and creates a normal site listing");
    edt(()->app.saveService.saveProgress());app.activeListings.clear();edt(()->app.saveService.loadProgress());
    MarketListing restored=app.activeListings.stream().filter(l->sale.itemId.equals(l.item.itemId)).findFirst().get();
    check(restored.getPrice()==1.4&&restored.marketplaceName.equals("Skinport"),"Container listing price, site and original supply identity survive save/load");
    app.activeListings.remove(restored);app.containerMarketService.restore(restored.item);
    OwnedSupply returned=app.ownedSupplies.stream().filter(s->s.id.equals(owned.id)).findFirst().get();
    check(returned.createdAt==owned.createdAt&&returned.purchasePrice==owned.purchasePrice,"Cancelling a listed container restores the same identity, creation time and cost");
    app.achievements.get("first_sale").isUnlocked=true;app.activeMissions.clear();
    InventoryItem quick=app.containerMarketService.item(returned);double quote=app.marketplacePricing.quickSellQuote(MarketplaceProfile.byName("Skinport"),quick),cash=app.balance;
    edt(()->app.exchangeTransactionService.commitExchangeQuickSell(MarketplaceProfile.byName("Skinport"),quick,quote));
    check(app.ownedSupplies.stream().noneMatch(s->s.id.equals(owned.id))&&Math.abs(app.balance-cash-quote)<.000001,"Owned container quick-sell consumes one supply and credits its disclosed quote once");
    CaseType souvenir=Arrays.stream(CaseType.values()).filter(c->c.isSouvenir).findFirst().get();souvenir.price=9.87;app.verifiedCaseQuotes.add(souvenir.id);ContainerMarketService.publish(souvenir,9.87);
    OwnedSupply pack=new OwnedSupply(souvenir,false,8);app.ownedSupplies.add(pack);InventoryItem packageSale=app.containerMarketService.item(pack);
    edt(()->app.exchangeTransactionService.commitExchangeListing(MarketplaceProfile.byName("Skinport"),packageSale,10));
    check(!app.ownedSupplies.contains(pack),"Souvenir packages can be listed just like owned cases");
    try{app.containerMarketService.item(new OwnedSupply(ct,true,2.49));throw new AssertionError("Key sellable");}catch(IllegalArgumentException expected){check(true,"Nontradable keys remain excluded from container sales");}
  }
  static boolean hasIcon(Component c){if(c instanceof JLabel&&((JLabel)c).getIcon()!=null)return true;if(c instanceof Container)for(Component child:((Container)c).getComponents())if(hasIcon(child))return true;return false;}
  static void visualsAndPerformance()throws Exception {
    JLabel label=new JLabel();edt(()->app.artworkService.getSkinImageFromName("AK-47 | Slate","Field-Tested",label,180,134));
    check(label.getToolTipText()==null,"Skin image genuine-wear/fallback hover text is removed");
    CaseType caseType=Cs2RedesignTests.source("Revolution Case");InventoryItem caseItem=app.containerMarketService.item(new OwnedSupply(caseType,false,1));
    JPanel caseCard=app.cs2Screens.createCs2SkinCard(caseItem,()->{});
    check(hasIcon(caseCard),"Owned-container sale cards bind genuine case artwork instead of querying nonexistent skin artwork");
    ArrayList<MarketListing> data=new ArrayList<>();data.add(lot("Bowie Knife | Rust Coat","Battle-Scarred",2,"Skinport"));
    JPanel card=app.marketItemCards.createMarketplaceSkinCard("Bowie Knife | Rust Coat",data,app);
    check(card.getComponent(0).getPreferredSize().height>=305||card.getPreferredSize().height>=305,"Market skin cards reserve a taller card/artwork region for Bowie knives");
    int windows=Window.getWindows().length;edt(()->app.marketDetailScreen.showDetailedListings("Bowie Knife | Rust Coat",data,app));
    check(Window.getWindows().length==windows&&Boolean.TRUE.equals(((JPanel)app.exchangeHostSections.getSelectedComponent()).getClientProperty("temporaryMarketView")),"The all-market skin detail view opens in a temporary tab, not a separate JFrame");
    String animation=Files.readString(Path.of("/home/user/cs2-simulator/src/blahblah/AnimationPanel.java"));check(!animation.contains("Math.abs(i - focus) > 2"),"The five-visible-opening-skins cap is removed");
    String scene=Files.readString(Path.of("/home/user/cs2-simulator/src/blahblah/Cs2Screens.java"));check(!scene.contains("new BufferedImage(100, 56"),"Inventory scenery no longer upsamples a pixelated 100×56 image");
    app.marketGroupingService.prepareBrowseIndex();long start=System.nanoTime();for(int n=0;n<1000;n++)app.marketGroupingService.getCombinedBrowseListings("Bowie Knife | Rust Coat");double ms=(System.nanoTime()-start)/1e6;
    System.out.printf("TIMING: 1000 indexed browse lookups %.2f ms%n",ms);check(ms<2000,"Repeated browse lookup uses a prepared key index, not a full-market scan per card");
    MarketListing custom=lot("Glock-18 | Candy Apple","Factory New",2,"SkinSwap");custom.item.price=BigDecimal.valueOf(100);custom.setPrice(110);
    MarketListing customUnit=app.marketplaceUnitStock.at(app.marketplaceGroups.group(List.of(custom)).get(0),1);
    check(app.exchangeTransactionService.swapSiteValue(customUnit)==app.coreUtilities.money(customUnit.getPrice()*(1+app.exchangeTransactionService.exchangeSwapMarkup(customUnit.item))).doubleValue(),"An individually premium-priced unit receives exactly one disclosed Swap markup");
    MarketListing fixed=lot("AK-47 | Slate","Factory New",2,"CS.MONEY");double price=fixed.getPrice();start=System.nanoTime();double sum=0;for(int n=0;n<1_000_000;n++)sum+=fixed.getPrice();ms=(System.nanoTime()-start)/1e6;
    System.out.printf("TIMING: one million cached site quotes %.2f ms%n",ms);check(sum>0&&ms<2000&&fixed.getPrice()==price,"Hot automatic quote reads reuse the listing cache instead of allocating composite keys");
  }
  public static void main(String[] args)throws Exception {
    Thread.setDefaultUncaughtExceptionHandler((t,e)->{e.printStackTrace();System.exit(1);});Cs2RedesignTests.setup();app=Cs2RedesignTests.gui;
    for(javax.swing.Timer timer:new javax.swing.Timer[]{app.marketTimer,app.fakeSalesTimer,app.tradeGenerationTimer,app.salesUpdateTimer})if(timer!=null)timer.stop();
    edt(()->{app.loadoutScreen.refreshMarketTab();app.mainTabs.setSelectedIndex(4);});floats();containers();visualsAndPerformance();
    edt(()->{for(Window w:Window.getWindows())w.dispose();});System.out.println("All "+checks+" individual-market checks passed.");System.exit(0);
  }
}
