package blahblah;

import java.awt.*;
import java.io.*;
import java.math.BigDecimal;
import java.util.*;
import javax.swing.*;

/** Previous-release serialized buffer migration plus exact retained Armoury float/price formulas. */
public class UpgradePolicyChecks {
  static int checks;static hGui app;
  static void check(boolean b,String text){if(!b)throw new AssertionError(text);checks++;System.out.println("PASS: "+text);}
  static void edt(MarketHomeFeedTests.Throwing r)throws Exception{Cs2RedesignTests.edt(r);}
  static void write(String path)throws Exception{
    InventoryToolsState s=new InventoryToolsState();s.supply=new GlobalSupply.State();s.supply.seeded=true;
    GlobalSupply.Entry e=new GlobalSupply.Entry();e.quantity=201;e.average=123.45;s.supply.variants.put("fixture",e);
    s.care=new CarePackages.State();s.care.xp=235;s.care.awarded.add("stable-mission");
    s.marketBuffer=new BufferedMarketSupply.State();s.marketBuffer.baseline=10_580_634;s.marketBuffer.aim=10_580_634;s.marketBuffer.relisted=12345;s.marketBuffer.issued=17;s.marketBuffer.nextReview=Long.MAX_VALUE;
    InventoryItem i=new InventoryItem(null,"AK-47 | Redline","Field-Tested","Classified",BigDecimal.valueOf(22),.23456789,false,321,null,22,true);i.itemId="stable-old-item";s.pendingTradeRewards=new java.util.ArrayList<>(java.util.List.of(InventoryItemCodec.encode(i)));
    try(ObjectOutputStream out=new ObjectOutputStream(new FileOutputStream(path))){out.writeObject(s);}
  }
  static void migration(String path)throws Exception{
    InventoryToolsState s;try(ObjectInputStream in=new ObjectInputStream(new FileInputStream(path))){s=(InventoryToolsState)in.readObject();}
    check(s.marketBuffer.baseline==10_580_634&&s.marketBuffer.policyVersion==0,"The actual previous-release buffer deserializes with its old center and a defaulted policy version");
    app.inventoryToolsService.state=s;app.globalMarketListings.clear();app.marketBuffer.tick(System.currentTimeMillis());
    check(s.marketBuffer.baseline==10_000_000&&s.marketBuffer.aim>=9_950_000&&s.marketBuffer.aim<=10_050_000&&s.marketBuffer.policyVersion==2&&app.marketBuffer.lower()==9_000_000&&app.marketBuffer.upper()==11_000_000,"First market review migrates the old center to the clarified 9–11 million policy");
    check(s.marketBuffer.relisted==12345&&s.marketBuffer.issued==17&&app.globalSupply.total()==201&&s.care.xp==235&&s.care.awarded.contains("stable-mission"),"Migration preserves supply, progression, awarded mission IDs and all existing buffer counters");
    var r=s.pendingTradeRewards.get(0);check(r.itemId.equals("stable-old-item")&&r.itemFloat==.23456789,"Migration preserves the exact pending reward identity and eight-decimal float");
    ByteArrayOutputStream bytes=new ByteArrayOutputStream();try(ObjectOutputStream out=new ObjectOutputStream(bytes)){out.writeObject(s);}try(ObjectInputStream in=new ObjectInputStream(new ByteArrayInputStream(bytes.toByteArray()))){s=(InventoryToolsState)in.readObject();}
    check(s.marketBuffer.policyVersion==2&&s.marketBuffer.baseline==10_000_000,"The migrated policy itself survives another binary round trip");
    app.inventoryToolsService.state=new InventoryToolsState();app.inventoryList.clear();app.activeMissions.clear();app.storeScreen.open("ARMOURY");
  }
  static void economics(boolean agent)throws Exception{
    ArmouryCollection col=hGui.ARMOURY_COLLECTIONS[0];if(agent)for(ArmouryCollection c:hGui.ARMOURY_COLLECTIONS)if(c.isAgents)col=c;
    final ArmouryCollection selected=col;
    String name=agent?col.milspecNames[0]:col.classifiedNames[0],rarity=agent?"Distinguished":"Classified";
    double base=27.25;long seed=agent?8012:21093;Random expected=new Random(seed);
    FloatRange range=hGui.FLOAT_LIMITS.get(name);if(range==null)for(Map.Entry<String,FloatRange> e:hGui.FLOAT_LIMITS.entrySet())if(name.startsWith(e.getKey())){range=e.getValue();break;}
    double min=range!=null&&range.min!=null?range.min:0,max=range!=null&&range.max!=null?range.max:.80;
    double f=agent?0:min+expected.nextDouble()*(max-min);
    String wear=agent?"Agent":app.floatRules.getConditionForFloat(name,f);
    double price=agent?base*app.marketPriceMultipliers.getOrDefault(rarity,1.0):base*app.marketInitialization.getMarketMultiplier(rarity,col.name)*app.priceModifiers.getMarketConditionMultiplier(name,wear)*(.88+expected.nextDouble()*.24);
    int pattern=expected.nextInt(1000);int before=app.cs2EquipmentScreens.collectibleInventory().size();
    edt(()->{app.inventoryToolsService.state.newItems.clear();hGui.random.setSeed(seed);app.armouryAnimationScreen.performArmouryRedeem(selected,name,rarity,base,"unused.png",null,1,false);});
    InventoryItem result=app.cs2EquipmentScreens.collectibleInventory().get(before);
    check(result.name.equals(name)&&result.condition.equals(wear)&&result.itemFloat==f&&result.price.equals(app.coreUtilities.money(price))&&result.patternID==pattern,"In-place "+(agent?"Agent":"weapon")+" redemption retains the exact former condition, float bounds, price formula and random pattern distribution");
    check(app.inventoryToolsService.state.newItems.contains(result.itemId)&&result.collection.equals(col.name),"The charged reward is immediately durable, marked pending and retains its source collection");
    MarketplaceOpeningChecks.waitFor(()->MarketplaceOpeningChecks.dialog("New Item")!=null,6000);JDialog popup=MarketplaceOpeningChecks.dialog("New Item");edt(popup::dispose);MarketplaceOpeningChecks.waitFor(()->!app.armouryAnimating,3000);
    check(app.cs2EquipmentScreens.collectibleInventory().size()==before+1&&!app.inventoryToolsService.state.newItems.contains(result.itemId),"Acknowledgement settles the pending "+(agent?"Agent":"weapon")+" arrival without another grant");
  }
  public static void main(String[] args)throws Exception{
    if(args.length>0&&args[0].equals("write")){write(args[1]);return;}
    Thread.setDefaultUncaughtExceptionHandler((t,e)->{e.printStackTrace();System.exit(1);});Cs2RedesignTests.setup();app=Cs2RedesignTests.gui;
    edt(()->{app.backgroundUnboxing.stop();if(app.marketTimer!=null)app.marketTimer.stop();});migration("/home/user/cs2-simulator/verification/previous-buffer-extension.dat");economics(false);economics(true);
    edt(()->{for(Window w:Window.getWindows())w.dispose();});System.out.println("All "+checks+" upgrade/economics checks passed.");System.exit(0);
  }
}
