package blahblah;
import java.lang.reflect.*;
import java.util.*;
import java.util.List;
import java.nio.file.*;
import java.math.BigDecimal;
import java.awt.*;
import java.awt.event.*;
import java.awt.image.BufferedImage;
import javax.swing.*;
import javax.swing.border.LineBorder;
import javax.imageio.ImageIO;
@SuppressWarnings({"unchecked","rawtypes"})
public class InventoryPerformanceTests {
 static hGui gui; static JPanel trade,inventory; static ImageIcon icon;
 static Object call(String n,Class<?>[] t,Object... a)throws Exception{return MarketRegressionTests.call(n,t,a);}
 static Object get(String n)throws Exception{return MarketRegressionTests.field(n).get(gui);}
 static void set(String n,Object v)throws Exception{MarketRegressionTests.field(n).set(gui,v);}
 static void check(boolean b,String m){MarketRegressionTests.check(b,m);}
 static void edt(Runnable r)throws Exception{SwingUtilities.invokeAndWait(r);}
 static void flush()throws Exception{edt(()->{});edt(()->{});}
 static JPanel grid(JPanel panel){return (JPanel)DevGeneratorTests.first(panel,JScrollPane.class).getViewport().getView();}
 static InventoryItem item(String name,String rarity,double f,boolean st){return new InventoryItem(icon,name,"Field-Tested",st?"StatTrak "+rarity:rarity,BigDecimal.valueOf(20),f,st,42,null,20);}
 static void click(JPanel c){for(MouseListener m:c.getMouseListeners())m.mouseClicked(new MouseEvent(c,MouseEvent.MOUSE_CLICKED,System.currentTimeMillis(),0,10,10,1,false));}
 static void page(JPanel g,int index)throws Exception{g.putClientProperty("pageIndex",index);call("renderInventoryPage",new Class[]{JPanel.class},g);}
 static void stop()throws Exception{Object t=trade.getClientProperty("selTimer");if(t instanceof javax.swing.Timer)((javax.swing.Timer)t).stop();}
 static void initialize()throws Exception{
  MarketRegressionTests.setup();gui=MarketRegressionTests.gui;DevGeneratorTests.gui=gui;GoldTradeUpTests.gui=gui;TradeUpPresentationTests.gui=gui;
  call("registerBundledTerminals",new Class[0]);call("registerRequestedMarketCollections",new Class[0]);
  call("applyExternalSkinCatalog",new Class[]{String.class},Files.readString(Path.of("verification/current-skins.json")));
  call("applyExternalCrateCatalog",new Class[]{String.class},Files.readString(Path.of("crates.json")));
  Class<?> c=Class.forName("blahblah.ImageRepository");Constructor<?> ctor=c.getDeclaredConstructor(hGui.class);ctor.setAccessible(true);set("imageRepository",ctor.newInstance(gui));
  icon=new ImageIcon(ImageIO.read(Path.of("verification/artwork-fixtures/AWP---Dragon-Lore.png").toFile()));
  trade=new JPanel(new BorderLayout());inventory=new JPanel(new BorderLayout());set("tradeUpTabPanel",trade);set("inventoryTabPanel",inventory);
  String mil=CaseType.CHROMA.regularDropNames.get("Milspec").get(0),res=CaseType.CHROMA.regularDropNames.get("Restricted").get(0);
  DevGeneratorTests.cached(mil,100);DevGeneratorTests.cached(res,100);
  List<InventoryItem> items=(List)get("inventoryList");
  for(int i=0;i<10000;i++)items.add(item(i%2==0?mil:res,i%2==0?"Milspec":"Restricted",i/12000.0,false));
 }
 static void testTrade()throws Exception{
  edt(()->{try{call("refreshTradeUpTab",new Class[0]);}catch(Exception e){throw new RuntimeException(e);}});flush();
  edt(()->{try{
   JPanel g=grid(trade);List<InventoryItem> selected=(List)get("tradeUpSelection");
   check(g.getComponentCount()==60&&((List)g.getClientProperty("pageItems")).size()==10000,"A 10,000-skin trade-up inventory constructs only 60 live cards");
   JScrollPane scroll=DevGeneratorTests.first(trade,JScrollPane.class);
   check(scroll.getColumnHeader()!=null&&DevGeneratorTests.find(trade,"inventoryNextPage")!=null,"Page count and previous/next controls stay accessible above the scrolling grid");
   JPanel first=(JPanel)g.getComponent(0);long t=System.nanoTime();click(first);double firstMs=(System.nanoTime()-t)/1e6;
   check(selected.size()==1&&((List)g.getClientProperty("pageItems")).size()==5000,"First selection locks the eligible pool to its rarity without creating 5,000 cards");
   check(g.getComponent(0)==first&&g.getComponentCount()==60,"The selected card is reused while the first bounded page is refiltered");
   Component[] before=g.getComponents();t=System.nanoTime();click((JPanel)g.getComponent(1));double clickMs=(System.nanoTime()-t)/1e6;
   check(Arrays.equals(before,g.getComponents())&&selected.size()==2,"Subsequent selection changes reuse every grid component instead of rebuilding the inventory");
   check(GoldTradeUpTests.labels(trade).contains("2/10 selected")&&GoldTradeUpTests.labels(trade).contains("Total value: $40.00"),"Selection counts and total value update immediately, without waiting for a timer");
   check(((LineBorder)first.getBorder()).getThickness()==3,"Selected cards retain their green selection border");
   page(g,1);click((JPanel)g.getComponent(0));check(selected.size()==3,"Additional input selections work across inventory pages");
   page(g,0);check(((LineBorder)((JPanel)g.getComponent(0)).getBorder()).getThickness()==3,"Returning to a page preserves its selected-card state");
   page(g,1);click((JPanel)g.getComponent(0));page(g,0);
   for(int i=2;i<10;i++)click((JPanel)g.getComponent(i));
   JButton execute=null;for(JButton b:buttons(trade))if(b.getText().equals("TRADE UP (10)"))execute=b;
   check(selected.size()==10&&execute!=null&&execute.isEnabled(),"Ten selected inputs immediately enable the standard contract button");
   for(int i=0;i<10;i++)click((JPanel)g.getComponent(i));
   check(selected.isEmpty()&&((List)g.getClientProperty("pageItems")).size()==10000,"Removing the last selection unlocks all matching inventory items");
   for(int i=1;i<8;i++)page(g,i);
   check(((Map)g.getClientProperty("cardCache")).size()<=180&&g.getComponentCount()==60,"Browsing many pages keeps the card cache bounded at 180 and live cards at 60");
   page(g,166);check(g.getComponentCount()==40&&((Integer)g.getClientProperty("pageIndex"))==166,"The final partial page makes every one of 10,000 inventory items reachable");
   page(g,0);Component[] stable=g.getComponents();t=System.nanoTime();click((JPanel)g.getComponent(0));
   long max=0;for(int i=0;i<100;i++){long a=System.nanoTime();click((JPanel)g.getComponent(1));max=Math.max(max,System.nanoTime()-a);}
   check(selected.size()==1&&g.getComponentCount()==60,"One hundred repeated selection/deselection clicks leave a consistent bounded grid");
   click((JPanel)g.getComponent(0));
   System.out.printf("TIMING: 10,000 items: first rarity lock %.3f ms; next input %.3f ms; max repeated click %.3f ms%n",firstMs,clickMs,max/1e6);
   stop();
  }catch(Exception e){throw new RuntimeException(e);}});flush();
 }
 static List<JButton> buttons(Component c){List<JButton> b=new ArrayList<>();if(c instanceof JButton)b.add((JButton)c);if(c instanceof Container)for(Component ch:((Container)c).getComponents())b.addAll(buttons(ch));return b;}
 static void testInventory()throws Exception{
  edt(()->{try{call("refreshInventoryTab",new Class[0]);}catch(Exception e){throw new RuntimeException(e);}});flush();
  edt(()->{try{
   JPanel g=grid(inventory);check(g.getComponentCount()==60&&((List)g.getClientProperty("pageItems")).size()==10000,"The main inventory also renders a bounded 60-card page for 10,000 items");
   JPanel first=(JPanel)g.getComponent(0);page(g,1);page(g,0);check(g.getComponent(0)==first,"Inventory page navigation reuses cached cards and their thumbnails");
   InventoryItem shown=(InventoryItem)first.getClientProperty("inventoryItem");shown.price=BigDecimal.valueOf(77.77);page(g,0);
   check(((JLabel)first.getClientProperty("inventoryPriceLabel")).getText().equals("$77.77"),"Reused inventory cards refresh current prices rather than showing stale cached values");
   first.setSize(165,205);DevGeneratorTests.layout(first);JLabel art=(JLabel)first.getClientProperty("inventoryArtwork");Insets pad=art.getInsets();
   check(first.getPreferredSize().height==205&&art.getHeight()-pad.top-pad.bottom>=art.getIcon().getIconHeight(),"Taller 205-pixel inventory cards fit the entire skin thumbnail with top/bottom padding");
   InventoryItem big=item("AWP | Dragon Lore","Covert",.03,false);big.collection="The Cobblestone Collection";
   JPanel large=(JPanel)call("createInventoryCardFast",new Class[]{InventoryItem.class,ImageIcon.class},big,big.getThumb130());large.setSize(165,205);DevGeneratorTests.layout(large);JLabel largeArt=(JLabel)large.getClientProperty("inventoryArtwork");Insets p=largeArt.getInsets();
   check(largeArt.getHeight()-p.top-p.bottom>=largeArt.getIcon().getIconHeight(),"Larger 130×88 popup thumbnails also fit without clipping their tops");
   JPanel render=new JPanel(new GridLayout(1,2,10,0));render.setBackground(new Color(20,20,28));render.add(first);render.add(large);TradeUpPresentationTests.render(render,"inventory-taller-cards-render.png",340,205);
   for(int i=1;i<7;i++)page(g,i);check(((Map)g.getClientProperty("cardCache")).size()<=180,"Main inventory navigation cannot grow an unbounded cache of Swing components");
  }catch(Exception e){throw new RuntimeException(e);}});flush();
 }
 static void testGoldAndCollections()throws Exception{
  List<InventoryItem> items=(List)get("inventoryList");items.clear();String name=CaseType.CHROMA.regularDropNames.get("Covert").get(0);DevGeneratorTests.cached(name,1000);
  for(int i=0;i<10000;i++)items.add(item(name,"Covert",i/12000.0,false));
  edt(()->{try{set("goldTradeUpMode",true);trade.putClientProperty("inventorySnapshot",null);call("refreshTradeUpTab",new Class[0]);}catch(Exception e){throw new RuntimeException(e);}});flush();
  edt(()->{try{
   JPanel g=grid(trade);check(g.getComponentCount()==60&&((List)g.getClientProperty("pageItems")).size()==10000,"Gold mode handles 10,000 duplicate Coverts without expanding outcome pools or constructing cards per duplicate");
   for(int i=0;i<5;i++)click((JPanel)g.getComponent(i));
   check(((List)get("tradeUpSelection")).size()==5&&buttons(trade).stream().anyMatch(b->b.getText().equals("GOLD TRADE UP (5)")&&b.isEnabled()),"Five eligible Coverts immediately enable a gold contract after the optimization");stop();((List)get("tradeUpSelection")).clear();
   for(String n:new String[]{"Bayonet | Doppler (Ruby)","Bayonet | Vanilla","StatTrak Talon Knife | Doppler (Phase 2)","Specialist Gloves | Crimson Kimono","Hand Wraps | Leather"})check(call("getCollectionName",new Class[]{String.class},n)==null,"No collection is inferred for "+n);
   InventoryItem knife=item("Bayonet | Doppler (Ruby)","Knife",.03,true);knife.collection="Chroma Collection";
   InventoryItem glove=item("Hand Wraps | Leather","Gloves",.2,false);glove.collection="Glove Collection";
   check(call("resolveInventoryItemCollection",new Class[]{InventoryItem.class},knife)==null&&knife.collection==null&&call("resolveInventoryItemCollection",new Class[]{InventoryItem.class},glove)==null&&glove.collection==null,"Stale knife and glove collection assignments are actually removed, not merely hidden");
   String info=(String)call("buildItemInfoHtml",new Class[]{String.class,String.class,double.class,int.class,String.class,boolean.class},"StatTrak Knife","Factory New",.03,42,"Stale Collection",false);
   check(!info.contains("Collection:")&&!info.contains("Stale Collection")&&info.contains("Pattern ID:")&&info.contains("Float:"),"Shared unboxing/reward hover omits the knife collection row while preserving float and pattern stats");
   check(call("getCollectionName",new Class[]{String.class},"AWP | Dragon Lore")!=null,"Weapon collections remain intact");
   DevGeneratorTests.cached(knife.name,1000);knife.collection="Stale Collection";JPanel reward=(JPanel)call("buildTradeUpResultPanel",new Class[]{InventoryItem.class,Runnable.class},knife,(Runnable)()->{});
   check(knife.collection==null&&!TradeUpPresentationTests.actualPopupHtml((JComponent)DevGeneratorTests.find(reward,"tradeUpResultInfo")).contains("Collection:"),"Reward panels clear stale saved knife metadata and do not expose a collection in their info hover");
   ArrayList<InventoryItem> inputs=new ArrayList<>(items.subList(0,5));items.clear();items.addAll(inputs);Map<String,Double> odds=GoldTradeUpTests.odds(inputs);for(String n:odds.keySet())DevGeneratorTests.cached(n,1000);
   JPanel outcomes=(JPanel)call("buildTradeUpOutcomesPanel",new Class[]{ArrayList.class},inputs);JLabel probability=(JLabel)DevGeneratorTests.find(outcomes,"tradeUpProfitOdds");
   check(probability!=null&&probability.getFont().getSize()>=16&&probability.getText().matches("Odds to profit: [0-9]+\\.[0-9]{2}%"),"Odds to profit has a dedicated prominent line with two decimal places");
   double expected=0;JPanel outcomesGrid=(JPanel)DevGeneratorTests.find(outcomes,"tradeUpOutcomesGrid");for(Component c:outcomesGrid.getComponents())if(GoldTradeUpTests.labels(c).contains("PROFIT"))expected+=odds.get(((JPanel)c).getClientProperty("tradeUpOutcomeSkin"));
   check(Math.abs(expected-((Number)probability.getClientProperty("profitProbability")).doubleValue())<1e-12,"Displayed profit probability equals the sum of odds of strictly profitable output cards");
   check(!GoldTradeUpTests.labels(outcomes).contains("Chroma Collection"),"Gold outcome cards never label internal source cases as knife/glove collections");
   TradeUpPresentationTests.render(outcomes,"tradeup-prominent-profit-odds-render.png",1420,860);
   for(InventoryItem in:inputs)in.price=BigDecimal.valueOf(100000000);JPanel losing=(JPanel)call("buildTradeUpOutcomesPanel",new Class[]{ArrayList.class},inputs);JLabel zero=(JLabel)DevGeneratorTests.find(losing,"tradeUpProfitOdds");
   check(zero.getText().equals("Odds to profit: 0.00%")&&((Number)zero.getClientProperty("profitProbability")).doubleValue()==0,"No profitable outcomes produces an explicit zero-percent profit chance");
   ArrayList<InventoryItem> standard=TradeUpProbabilityTests.batch(1,9);items.clear();items.addAll(standard);
   for(InventoryItem in:standard)in.itemFloat=0;
   DevGeneratorTests.cached("AWP | Dragon Lore",1000);DevGeneratorTests.cached("AK-47 | Head Shot",1);DevGeneratorTests.cached("M4A4 | Temukau",1);
   JPanel partial=(JPanel)call("buildTradeUpOutcomesPanel",new Class[]{ArrayList.class},standard);
   JLabel ten=(JLabel)DevGeneratorTests.find(partial,"tradeUpProfitOdds");
   check(ten.getText().equals("Odds to profit: 10.00%")&&Math.abs(((Number)ten.getClientProperty("profitProbability")).doubleValue()-.1)<1e-12,"Profit odds use input-count collection shares: only a profitable Dragon Lore gives exactly 10%, not 33.3%");
   DevGeneratorTests.cached("AWP | Dragon Lore",80);
   JPanel even=(JPanel)call("buildTradeUpOutcomesPanel",new Class[]{ArrayList.class},standard);
   check(((JLabel)DevGeneratorTests.find(even,"tradeUpProfitOdds")).getText().equals("Odds to profit: 0.00%")&&GoldTradeUpTests.labels(even).contains("~$200.00"),"A $200 outcome on a $200 contract is break-even, not counted as profit");
   testPendingArtworkCleanup();
   String source=Files.readString(Path.of("hGui.java"));check(!source.contains("Load All?")&&!source.contains("showAllItems")&&!source.contains("Load More..."),"No inventory window retains an unbounded load-all card-rendering path");
  }catch(Exception e){throw new RuntimeException(e);}});flush();
 }
 static void testPendingArtworkCleanup()throws Exception{
  JPanel g=new JPanel();String name="Inventory pending artwork fixture";
  java.util.function.Function<InventoryItem,JPanel> renderer=it->{
   JPanel card=new JPanel();JLabel art=new JLabel();card.putClientProperty("inventoryRemoteName",name);card.putClientProperty("inventoryArtwork",art);
   try{call("registerPendingRemoteImageLabel",new Class[]{String.class,JLabel.class,int.class,int.class},name,art,110,75);}catch(Exception e){throw new RuntimeException(e);}return card;
  };
  for(int i=0;i<500;i++){InventoryItem it=item(name,"Milspec",.2,false);it.image=null;call("cachedInventoryGridCard",new Class[]{JPanel.class,InventoryItem.class,java.util.function.Function.class},g,it,renderer);}
  Map<String,Set<JLabel>> pending=(Map)get("pendingRemoteImageLabels");
  check(pending.get(name).size()==180,"Cache eviction also unregisters pending artwork labels, preventing discarded cards from being retained after failed image downloads");
  call("releaseInventoryGridCaches",new Class[]{Container.class},g);
  check(!pending.containsKey(name)&&((Map)g.getClientProperty("cardCache")).isEmpty(),"Refreshing or closing an inventory releases cached cards and pending artwork references");
 }
 public static void main(String[] a)throws Exception{try{initialize();testTrade();testInventory();testGoldAndCollections();System.out.println("All inventory paging, selection performance, collection and profit-display tests passed.");}finally{if(trade!=null)stop();((java.util.prefs.Preferences)get("marketPricePreferences")).removeNode();}System.exit(0);}
}
