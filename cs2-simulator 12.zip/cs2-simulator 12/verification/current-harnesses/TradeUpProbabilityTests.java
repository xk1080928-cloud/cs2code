package blahblah;
import java.lang.reflect.*;
import java.util.*;
import java.nio.file.*;
import java.awt.*;
import java.awt.image.BufferedImage;
import javax.swing.*;

@SuppressWarnings({"unchecked","rawtypes"})
public class TradeUpProbabilityTests {
 static hGui gui;
 static Object call(String n,Class<?>[] t,Object...a)throws Exception{return MarketRegressionTests.call(n,t,a);}
 static Object get(String n)throws Exception{Field f=MarketRegressionTests.field(n);return f.get(Modifier.isStatic(f.getModifiers())?null:gui);}
 static void set(String n,Object v)throws Exception{MarketRegressionTests.field(n).set(gui,v);}
 static void check(boolean b,String m){MarketRegressionTests.check(b,m);}
 static ArrayList<InventoryItem> batch(int knights,int wicked){ArrayList<InventoryItem> a=new ArrayList<>();for(int i=0;i<knights+wicked;i++)a.add(GoldTradeUpTests.item(i<knights?"M4A1-S | Knight":"P2000 | Wicked Sick","Classified",false));return a;}
 static Map<String,Double> odds(java.util.List<InventoryItem> a)throws Exception{return (Map)call("resolveTradeUpOutcomeOdds",new Class[]{java.util.List.class,String.class},a,"Classified");}
 static void expected(Map<String,Double> o,double lore,double head,double tem){if(o.size()!=3||Math.abs(o.get("AWP | Dragon Lore")-lore)>1e-12||Math.abs(o.get("AK-47 | Head Shot")-head)>1e-12||Math.abs(o.get("M4A4 | Temukau")-tem)>1e-12)throw new AssertionError("Incorrect odds: "+o);}
 static String segment(String source,String from,String to){int a=source.indexOf(from);int b=source.indexOf(to,a);if(a<0||b<0)throw new AssertionError("Missing formula");return source.substring(a,b);}
 static void run()throws Exception{
  call("registerBundledTerminals",new Class[0]);call("registerRequestedMarketCollections",new Class[0]);
  call("applyExternalSkinCatalog",new Class[]{String.class},Files.readString(Path.of("verification/current-skins.json")));
  call("applyExternalCrateCatalog",new Class[]{String.class},Files.readString(Path.of("crates.json")));
  ArrayList<InventoryItem> in=batch(1,9);java.util.List<InventoryItem> inventory=(java.util.List)get("inventoryList");inventory.addAll(in);
  Map<String,Double> o=odds(in);expected(o,.1,.45,.45);
  check(true,"One Knight + nine Wicked Sicks gives Dragon Lore 10%, Head Shot 45%, Temukau 45%");
  expected(odds(batch(7,3)),.7,.15,.15);check(true,"Seven single-output collection inputs retain 70%; the other collection's two outcomes receive 15% each");
  expected(odds(batch(5,5)),.5,.25,.25);check(true,"Equal input collection shares remain 50/50 regardless of one versus two possible outputs");
  Map<String,Double> one=odds(batch(10,0)),two=odds(batch(0,10));
  check(one.size()==1&&one.get("AWP | Dragon Lore")==1&&two.size()==2&&two.values().stream().allMatch(p->p==.5),"Single-collection contracts split 100% equally among that collection's next-tier outcomes");
  Map<String,Double> partial=odds(batch(1,1));expected(partial,.5,.25,.25);check(true,"Partial selection previews normalize by actual selected input count");
  ArrayList<InventoryItem> unknown=batch(1,8);unknown.add(GoldTradeUpTests.item("P2000 | Invalid fixture","Classified",false));
  check(odds(unknown).isEmpty()&&odds(new ArrayList<>()).isEmpty(),"Unknown collections and empty contracts do not produce a misleading partial probability pool");
  Class<?> cls=Class.forName("blahblah.ImageRepository");Constructor<?> ctor=cls.getDeclaredConstructor(hGui.class);ctor.setAccessible(true);set("imageRepository",ctor.newInstance(gui));DevGeneratorTests.gui=gui;
  for(String n:o.keySet())DevGeneratorTests.cached(n,1000);
  JPanel preview=(JPanel)call("buildTradeUpOutcomesPanel",new Class[]{ArrayList.class},in);String labels=GoldTradeUpTests.labels(preview);
  check(labels.contains("10.0% chance")&&labels.split("45.0% chance",-1).length==3&&!labels.contains("5.3% chance")&&!labels.contains("47.4% chance"),"The actual outcomes UI displays 10%/45%/45%, not the previous output-count-biased odds");
  preview.setSize(1000,760);DevGeneratorTests.layout(preview);BufferedImage img=new BufferedImage(1000,760,2);Graphics2D g=img.createGraphics();preview.printAll(g);g.dispose();javax.imageio.ImageIO.write(img,"png",Path.of("verification/knight-wicked-tradeup-odds-render.png").toFile());
  Random random=(Random)get("random");random.setSeed(192837);Map<String,Integer> counts=new HashMap<>();int trials=100000;
  for(int i=0;i<trials;i++){String skin=(String)call("sampleTradeUpOdds",new Class[]{Map.class},o);counts.merge(skin,1,Integer::sum);}
  check(o.entrySet().stream().allMatch(e->Math.abs(counts.getOrDefault(e.getKey(),0)/(double)trials-e.getValue())<.006),"The sampler used by contract execution reproduces 10%/45%/45% over 100000 seeded rolls");
  String dop="Bayonet | Doppler",gamma="Bayonet | Gamma Doppler";
  Map<String,Double> d=(Map)call("getDopplerVariantOdds",new Class[]{String.class},dop),gd=(Map)call("getDopplerVariantOdds",new Class[]{String.class},gamma);
  check(Math.abs(d.get(dop+" (Sapphire)")-.01/.4025)<1e-12&&Math.abs(d.get(dop+" (Ruby)")-.01/.4025)<1e-12&&Math.abs(d.get(dop+" (Black Pearl)")-.0025/.4025)<1e-12,"Standalone Chroma Doppler gem selection uses normalized calculator ratios");
  check(java.util.stream.IntStream.rangeClosed(1,4).allMatch(i->Math.abs(d.get(dop+" (Phase "+i+")")-.095/.4025)<1e-12)&&Math.abs(d.values().stream().mapToDouble(Double::doubleValue).sum()-1)<1e-12,"Chroma conditional Doppler phases use 0.095/0.4025 each and sum with gems to 100%");
  check(Math.abs(gd.get(gamma+" (Emerald)")-.0135/.1675)<1e-12&&java.util.stream.IntStream.rangeClosed(1,4).allMatch(i->Math.abs(gd.get(gamma+" (Phase "+i+")")-.0385/.1675)<1e-12)&&Math.abs(gd.values().stream().mapToDouble(Double::doubleValue).sum()-1)<1e-12,"Gamma conditional phases and Emerald use calculator ratios and total 100%");
  Map<String,Double> ud=(Map)call("getUnboxingDopplerVariantOdds",new Class[]{String.class},dop),ugd=(Map)call("getUnboxingDopplerVariantOdds",new Class[]{String.class},gamma);
  Map<String,Integer> regularCounts=new HashMap<>(),gammaCounts=new HashMap<>();random.setSeed(382891);
  for(int i=0;i<trials;i++){
   regularCounts.merge((String)call("applySimulatedDopplerVariant",new Class[]{String.class},dop),1,Integer::sum);
   gammaCounts.merge((String)call("applySimulatedDopplerVariant",new Class[]{String.class},gamma),1,Integer::sum);
  }
  check(ud.entrySet().stream().allMatch(e->Math.abs(regularCounts.getOrDefault(e.getKey(),0)/(double)trials-e.getValue())<.004),"Simulated regular unboxing follows the separate 3.5%/3.5%/1% gem weights");
  check(ugd.entrySet().stream().allMatch(e->Math.abs(gammaCounts.getOrDefault(e.getKey(),0)/(double)trials-e.getValue())<.004),"Simulated Gamma unboxing follows the separate 8% Emerald weight");
  check(call("applySimulatedDopplerVariant",new Class[]{String.class},dop+" (Ruby)").equals(dop+" (Ruby)")&&call("applySimulatedDopplerVariant",new Class[]{String.class},"Bayonet | Fade").equals("Bayonet | Fade"),"Already-resolved Dopplers and non-Doppler finishes are not rerolled");
  if(!Files.exists(Path.of("verification/before-corrected-tradeup-odds.java.txt"))){System.out.println("SKIP: historical monolithic source-only comparison; current runtime math checked above");return;}
  String old=Files.readString(Path.of("verification/before-corrected-tradeup-odds.java.txt")),now=Files.readString(Path.of("hGui.java"));
  check(segment(old,"FloatRange outputFR = findFloatRange(skinName);","double mMult").equals(segment(now,"FloatRange outputFR = findFloatRange(skinName);","double mMult")),"The actual standard trade-up output-float and condition formula is byte-for-byte unchanged");
  check(segment(old,"double totalNormFloat = 0.0;","double inputTotal").equals(segment(now,"double totalNormFloat = 0.0;","double inputTotal"))&&segment(old,"FloatRange fr = findFloatRange(sn);","double cMult").equals(segment(now,"FloatRange fr = findFloatRange(sn);","double cMult")),"The preview's output-float and condition calculations are unchanged");
  check(segment(old,"private double getGoldTradeUpOutputFloat(","private String getGoldTradeUpOutputRarity").equals(segment(now,"private double getGoldTradeUpOutputFloat(","private String getGoldTradeUpOutputRarity")),"The gold trade-up output-float formula is unchanged");
  String execute=segment(now,"private void executeTradeUp(","private void refreshMarketTab(");
  check(execute.contains("resolveTradeUpOutcomeOdds(selectedItems, baseRarity)")&&execute.contains("sampleTradeUpOdds(outcomeOdds)")&&!now.contains("resolveOutcomePool("),"Execution and preview use the same corrected probability map; the biased repeated-output pool is removed");
 }
 public static void main(String[] args)throws Exception{MarketRegressionTests.setup();gui=MarketRegressionTests.gui;SwingUtilities.invokeAndWait(()->{try{run();}catch(Exception ex){throw new RuntimeException(ex);}});((java.util.prefs.Preferences)get("marketPricePreferences")).removeNode();System.out.println("All corrected trade-up probability and Doppler tests passed.");}
}
