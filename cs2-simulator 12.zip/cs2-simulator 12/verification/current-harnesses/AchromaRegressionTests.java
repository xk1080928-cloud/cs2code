package blahblah;
import java.util.*;
import java.lang.reflect.*;
import java.awt.*;
import java.awt.image.BufferedImage;
import javax.swing.*;

@SuppressWarnings({"unchecked","rawtypes"})
class AchromaRegressionTests {
    static hGui gui;
    static Object call(String name,Class<?>[] types,Object...args)throws Exception {
        Method m=ModularAccess.method(name,types);m.setAccessible(true);
        try{return m.invoke(ModularAccess.receiver(gui,m),args);}catch(InvocationTargetException e){throw new RuntimeException(name,e.getCause());}
    }
    static Object get(String name)throws Exception {Field f=SimulatorContext.class.getDeclaredField(name);f.setAccessible(true);return f.get(Modifier.isStatic(f.getModifiers())?null:gui);}
    static void check(boolean ok,String msg){if(!ok)throw new AssertionError(msg);System.out.println("PASS: "+msg);}
    static void run()throws Exception {
        call("registerBundledArmouryCollections",new Class<?>[0]);
        ArmouryCollection achroma=null;
        for(ArmouryCollection c:(ArmouryCollection[])get("ARMOURY_COLLECTIONS"))if(c.name.equals("The Achroma Collection"))achroma=c;
        check(achroma!=null,"Achroma is registered in the Armoury Pass");
        String[][] names={achroma.consumerNames,achroma.industrialNames,achroma.milspecNames,achroma.restrictedNames,achroma.classifiedNames,achroma.covertNames};
        String[][] files={achroma.consumer,achroma.industrial,achroma.milspec,achroma.restricted,achroma.classified,achroma.covert};
        double[][] prices={achroma.consumerPrices,achroma.industrialPrices,achroma.milspecPrices,achroma.restrictedPrices,achroma.classifiedPrices,achroma.covertPrices};
        int[] expected={8,5,4,2,1,0};String[] rarity={"Consumer","Industrial","Milspec","Restricted","Classified","Covert"};
        Set<String> all=new HashSet<>();
        for(int i=0;i<names.length;i++) {
            check(names[i].length==expected[i]&&files[i].length==expected[i]&&prices[i].length==expected[i],"Correct aligned Achroma "+rarity[i]+" tier: "+expected[i]);
            all.addAll(Arrays.asList(names[i]));
        }
        check(all.size()==20&&((Map)get("skinCatalog")).size()==20,"All 20 skins have bundled metadata even with no live catalog");
        check((Integer)call("getArmouryRedeemCost",new Class<?>[]{ArmouryCollection.class},achroma)==4,"Achroma uses the existing four-star redemption cost");
        double[] weights=(double[])call("getArmouryRarityWeights",new Class<?>[]{ArmouryCollection.class},achroma);
        check(weights.length==6&&weights[0]==0&&Math.abs(Arrays.stream(weights).sum()-1)<1e-9,"Drop odds are normalized across the five populated tiers, with no Covert drops");
        TradeUpCollection collection=null;for(TradeUpCollection c:(TradeUpCollection[])get("ARMOURY_TRADE_UP_COLLECTIONS"))if(c.collectionName.equals(achroma.name))collection=c;
        check(collection!=null&&collection.getOutcomePool("Consumer").length==5&&collection.getOutcomePool("Industrial").length==4&&collection.getOutcomePool("Milspec").length==2&&collection.getOutcomePool("Restricted").length==1&&collection.getOutcomePool("Classified").length==0,"Trade-ups advance correctly through Achroma and stop at Classified");
        for(int t=0;t<names.length;t++)for(String name:names[t]) {
            if(!(Boolean)call("isArmourySkin",new Class<?>[]{String.class},name)||(Boolean)call("supportsStatTrak",new Class<?>[]{String.class},name))throw new AssertionError("Armoury/StatTrak: "+name);
            if(!rarity[t].equals(call("getSkinRarity",new Class<?>[]{String.class},name)))throw new AssertionError("Rarity: "+name);
            if(call("findCollection",new Class<?>[]{String.class},name)!=collection)throw new AssertionError("Trade-up mapping: "+name);
            double price=(Double)call("getBasePriceInner",new Class<?>[]{String.class},name);if(price<=0)throw new AssertionError("Price: "+name);
            ((Map)get("liveBasePrices")).put(name,price);
        }
        check(true,"Every Achroma skin has the right rarity, pricing fallback and trade-up mapping, and no StatTrak variant");
        double[] max=(double[])call("getMarketWearBounds",new Class<?>[]{String.class},"R8 Revolver | Dark Chamber");
        check(max[0]==0&&max[1]==0.80339,"Bundled float caps retain catalog precision");
        Class<?> rc=Class.forName("blahblah.ImageRepository");Constructor<?> ctor=rc.getDeclaredConstructor(hGui.class);ctor.setAccessible(true);Object repo=ctor.newInstance(gui);Field rf=SimulatorContext.class.getDeclaredField("imageRepository");rf.setAccessible(true);rf.set(gui,repo);
        Method put=rc.getDeclaredMethod("put",String.class,Image.class);put.setAccessible(true);Image img=new BufferedImage(150,95,2);
        for(String name:all)put.invoke(repo,name,img);
        for(String[] tier:files)for(String file:tier)if(call("resolveArmouryArtwork",new Class<?>[]{ArmouryCollection.class,String.class},achroma,file)!=img)throw new AssertionError("Artwork: "+file);
        check(true,"Redemption and animation resolve artwork from the shared skin cache, without requiring local PNGs");
        Class<?>[] signature={ArmouryCollection.class,JLabel.class,Color.class,Color.class,Color.class,Color.class,Color.class,Color.class,Color.class};
        JPanel page=(JPanel)call("buildCollectionPage",signature,achroma,new JLabel(),Color.BLACK,Color.GRAY,Color.BLACK,Color.ORANGE,Color.WHITE,Color.GRAY,Color.YELLOW);
        check(page.getComponentCount()>0,"Achroma Armoury page builds successfully with all tiers");
        Map<String,ArrayList<MarketListing>> market=(Map)get("globalMarketListings");for(String name:all)market.put(name,new ArrayList<>());
        call("ensureMinimumListings",new Class<?>[0]);
        for(String name:all)if(market.get(name).isEmpty()||MarketRegressionTests.counts(market.get(name)).size()!=5)throw new AssertionError("Market supply: "+name);
        check(true,"All 20 skins receive valid listings across their five available wear conditions");
        call("refillFairSalesQueue",new Class<?>[0]);call("generateFairCoverageSales",new Class<?>[]{int.class,boolean.class},20,true);
        Map sales=(Map)get("salesHistory");check(sales.keySet().containsAll(all),"All Achroma skins participate in simulated sales coverage");
    }
    public static void main(String[] args)throws Exception {
        MarketRegressionTests.setup();gui=MarketRegressionTests.gui;
        SwingUtilities.invokeAndWait(()->{try{run();}catch(Exception e){throw new RuntimeException(e);}});
        ((java.util.prefs.Preferences)get("marketPricePreferences")).removeNode();
        System.out.println("All Achroma regression tests passed.");
    }
}
