package blahblah;
import java.util.*;
import java.nio.file.*;
import java.lang.reflect.*;
import java.awt.*;
import java.awt.image.BufferedImage;
import javax.swing.*;

@SuppressWarnings({"unchecked","rawtypes"})
public class CollectionRegressionTests {
 static hGui gui;
 static Object call(String n,Class<?>[] types,Object...a)throws Exception{return MarketRegressionTests.call(n,types,a);}
 static Object get(String n)throws Exception{Field f=MarketRegressionTests.field(n);return f.get(Modifier.isStatic(f.getModifiers())?null:gui);}
 static void check(boolean b,String m){MarketRegressionTests.check(b,m);}
 static String canon(String n)throws Exception{return (String)call("canonicalMarketCollectionName",new Class<?>[]{String.class},n);}
 static String tier(String s){return s.replace(" Grade","").replace("Mil-Spec","Milspec");}
 static void run()throws Exception {
  call("registerBundledArmouryCollections",new Class<?>[0]);
  call("registerRequestedMarketCollections",new Class<?>[0]);
  Map<String,TradeUpCollection> registry=(Map)get("requestedMarketCollections");
  check(registry.size()==48,"Exactly 48 requested market collections are registered offline");
  java.util.List<String> expectedArmoury=Files.readAllLines(Path.of("verification/expected-armoury.txt"));
  java.util.List<String> actualArmoury=new ArrayList<>();
  for(ArmouryCollection c:(ArmouryCollection[])get("ARMOURY_COLLECTIONS"))actualArmoury.add(c.name);
  check(actualArmoury.equals(expectedArmoury),"Only Arabesque and Spy Tech were appended to Armoury; all 14 prior entries and indices preserved");
  Map<String,Object> metadata=(Map)get("skinCatalog");
  Set<String> names=new HashSet<>(); Map<String,Set<String>> expectedByCollection=new LinkedHashMap<>();
  for(String line:Files.readAllLines(Path.of("verification/expected-market-collections.tsv"))) {
   String[] r=line.split("\t");String col=canon(r[0]),n=r[1];names.add(n);expectedByCollection.computeIfAbsent(col,k->new HashSet<>()).add(n);
   if(!registry.containsKey(col)||!metadata.containsKey(n))throw new AssertionError("Missing "+col+" / "+n);
   double[] bounds=(double[])call("getMarketWearBounds",new Class<?>[]{String.class},n);
   if(Math.abs(bounds[0]-Double.parseDouble(r[2]))>1e-8||Math.abs(bounds[1]-Double.parseDouble(r[3]))>1e-8)throw new AssertionError("Caps "+n+" "+Arrays.toString(bounds));
   if(!tier(r[4]).equals(call("getSkinRarity",new Class<?>[]{String.class},n)))throw new AssertionError("Rarity "+n+" expected "+tier(r[4])+" got "+call("getSkinRarity",new Class<?>[]{String.class},n));
   if(!(Boolean)call("belongsToMarketplaceCollection",new Class<?>[]{String.class,String.class},n,col))throw new AssertionError("Membership "+n);
   if((Boolean)call("supportsStatTrak",new Class<?>[]{String.class},n))throw new AssertionError("Invalid StatTrak "+n);
   if(call("findCollection",new Class<?>[]{String.class},n)==null)throw new AssertionError("No trade-up collection "+n);
   Object m=metadata.get(n);Field image=m.getClass().getDeclaredField("imageUrl");image.setAccessible(true);if(!((String)image.get(m)).startsWith("https://"))throw new AssertionError("No artwork "+n);
   ((Map)get("liveBasePrices")).put(n,call("getBasePriceInner",new Class<?>[]{String.class},n));
  }
  check(names.size()==750,"All 750 unique requested skins have exact rarity, float limits, membership, artwork, trade-up mapping and no synthetic StatTrak variants");
  for(String raw:new String[]{"Dust II Collection","2021 Dust II Collection","2024 Overpass Collection","2025 Train Collection","Sport and Field Collection"}){
   String canonical=canon(raw);if(!registry.containsKey(canonical))throw new AssertionError("Alias "+raw+" -> "+canonical);
  }
  check(true,"User naming aliases resolve to their canonical market collections");
  Class<?> rc=Class.forName("blahblah.ImageRepository");Constructor<?> ctor=rc.getDeclaredConstructor(hGui.class);ctor.setAccessible(true);Object repo=ctor.newInstance(gui);MarketRegressionTests.field("imageRepository").set(gui,repo);
  Method put=rc.getDeclaredMethod("put",String.class,Image.class);put.setAccessible(true);Image img=new BufferedImage(150,95,2);
  java.util.List<Runnable> downloads = new ArrayList<>();
  MarketRegressionTests.field("remoteImageExecutor").set(gui,new java.util.concurrent.AbstractExecutorService(){
   public void execute(Runnable r){downloads.add(r);}public void shutdown(){}public java.util.List<Runnable> shutdownNow(){return java.util.List.of();}public boolean isShutdown(){return false;}public boolean isTerminated(){return false;}public boolean awaitTermination(long t,java.util.concurrent.TimeUnit u){return true;}
  });
  int requested=0;
  for(ArmouryCollection c:(ArmouryCollection[])get("ARMOURY_COLLECTIONS")){
   if(!(Boolean)call("usesCatalogArmouryArtwork",new Class<?>[]{ArmouryCollection.class},c))continue;
   for(String[] tier:new String[][]{c.consumerNames,c.industrialNames,c.milspecNames,c.restrictedNames,c.classifiedNames,c.covertNames})for(String n:tier){call("getSkinImageFromName",new Class<?>[]{String.class},n);requested++;}
  }
  check(downloads.size()==requested&&requested==54,"All 54 Achroma/Arabesque/Spy Tech skins request remote artwork when local PNGs are absent");
  for(String n:names)put.invoke(repo,n,img);
  for(ArmouryCollection c:(ArmouryCollection[])get("ARMOURY_COLLECTIONS")) {
   if(!c.name.equals("The Arabesque Collection")&&!c.name.equals("The Spy Tech Collection"))continue;
   String[][] ns={c.consumerNames,c.industrialNames,c.milspecNames,c.restrictedNames,c.classifiedNames,c.covertNames};
   String[][] fs={c.consumer,c.industrial,c.milspec,c.restricted,c.classified,c.covert};
   double[][] ps={c.consumerPrices,c.industrialPrices,c.milspecPrices,c.restrictedPrices,c.classifiedPrices,c.covertPrices};int[] expected={0,6,4,3,2,2};
   for(int t=0;t<6;t++){
    if(ns[t].length!=expected[t]||fs[t].length!=expected[t]||ps[t].length!=expected[t])throw new AssertionError("Tier alignment "+c.name);
    for(int i=0;i<ns[t].length;i++){put.invoke(repo,ns[t][i],img);if(call("resolveArmouryArtwork",new Class<?>[]{ArmouryCollection.class,String.class},c,fs[t][i])!=img)throw new AssertionError("Art "+ns[t][i]);}
   }
   if((Integer)call("getArmouryRedeemCost",new Class<?>[]{ArmouryCollection.class},c)!=4)throw new AssertionError("Cost "+c.name);
   double[] odds=(double[])call("getArmouryRarityWeights",new Class<?>[]{ArmouryCollection.class},c);
   if(Math.abs(Arrays.stream(odds).sum()-1)>1e-8)throw new AssertionError("Odds "+c.name);
   JPanel page=(JPanel)call("buildCollectionPage",new Class<?>[]{ArmouryCollection.class,JLabel.class,Color.class,Color.class,Color.class,Color.class,Color.class,Color.class,Color.class},c,new JLabel(),Color.BLACK,Color.GRAY,Color.BLACK,Color.ORANGE,Color.WHITE,Color.GRAY,Color.YELLOW);
   if(page.getComponentCount()==0)throw new AssertionError("Empty page "+c.name);
   TradeUpCollection tc=(TradeUpCollection)call("findCollection",new Class<?>[]{String.class},c.industrialNames[0]);
   if(tc.getOutcomePool("Industrial").length!=4||tc.getOutcomePool("Milspec").length!=3||tc.getOutcomePool("Restricted").length!=2||tc.getOutcomePool("Classified").length!=2)throw new AssertionError("Outcomes "+c.name);
   check(true,c.name+": complete 17-skin Armoury page, cached imagery, four-star cost, normalized odds and correct trade-up tiers");
  }
  Map<String,ArrayList<MarketListing>> market=(Map)get("globalMarketListings");
  call("ensureMinimumListings",new Class<?>[0]);
  for(String n:names){
   ArrayList<MarketListing> listings=market.get(n);if(listings==null||listings.isEmpty())throw new AssertionError("Empty market "+n);
   Set<String> valid=new HashSet<>(Arrays.asList((String[])call("getAvailableConditions",new Class<?>[]{String.class},n)));
   if(!MarketRegressionTests.counts(listings).keySet().equals(valid))throw new AssertionError("Missing wear "+n);
   double[] b=(double[])call("getMarketWearBounds",new Class<?>[]{String.class},n);
   for(MarketListing l:listings)MarketRegressionTests.checkFloat(l,b[0],b[1]);
  }
  check(true,"Every requested skin receives market stock in every valid wear, with no out-of-range floats");
  String[] menu=(String[])call("getMarketplaceCollectionMenuItems",new Class<?>[0]);
  Set<String> menuItems=new HashSet<>(Arrays.asList(menu));
  check(menuItems.size()==menu.length&&menuItems.containsAll(registry.keySet()),"Collection menu contains every requested collection without duplicate aliases");
  for(Map.Entry<String,Set<String>> e:expectedByCollection.entrySet()){
   java.util.List<Map.Entry<String,ArrayList<MarketListing>>> filtered=(java.util.List)call("collectMarketplaceEntries",new Class<?>[]{String.class,String.class,String.class,String.class},"Collections",e.getKey(),"","Price: Low to High");
   Set<String> visible=new HashSet<>();for(Map.Entry<String,ArrayList<MarketListing>> row:filtered)visible.add(row.getKey());
   if(!visible.containsAll(e.getValue())){Set<String> missing=new HashSet<>(e.getValue());missing.removeAll(visible);throw new AssertionError("Missing from filter "+e.getKey()+": "+missing);}
  }
  check(true,"All 48 collection filters display their full requested skin sets");
  int totalBefore=market.values().stream().mapToInt(java.util.List::size).sum();
  call("registerRequestedMarketCollections",new Class<?>[0]);call("ensureMinimumListings",new Class<?>[0]);
  check(registry.size()==48&&market.size()==750&&market.values().stream().mapToInt(java.util.List::size).sum()==totalBefore,"Repeated catalog registration and market repair are idempotent without duplicate stock");
  call("refillFairSalesQueue",new Class<?>[0]);call("generateFairCoverageSales",new Class<?>[]{int.class,boolean.class},750,true);
  check(((Map)get("salesHistory")).keySet().containsAll(names),"Simulated sales cover all 750 requested skins, not only Armoury rewards");
 }
 public static void main(String[] args)throws Exception{
  MarketRegressionTests.setup();gui=MarketRegressionTests.gui;
  SwingUtilities.invokeAndWait(()->{try{run();}catch(Exception e){throw new RuntimeException(e);}});
  ((java.util.prefs.Preferences)get("marketPricePreferences")).removeNode();
  System.out.println("All requested collection regression tests passed.");
 }
}
