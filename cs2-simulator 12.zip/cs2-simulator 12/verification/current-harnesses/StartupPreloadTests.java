package blahblah;
import java.awt.*;
import java.awt.image.BufferedImage;
import java.io.*;
import java.net.*;
import java.lang.reflect.*;
import java.nio.file.*;
import java.util.*;
import java.util.List;
import java.util.concurrent.*;
import java.util.concurrent.atomic.*;
import javax.imageio.ImageIO;
import javax.swing.*;
@SuppressWarnings({"unchecked","rawtypes"})
public class StartupPreloadTests {
 static hGui gui;static Object repo;static JPanel overlay;static ExecutorService work,remote;
 static Path cache=Path.of("verification/startup-preload-test-cache");
 static Map<String,Integer> hits=new ConcurrentHashMap<>();static Set<String> failures=ConcurrentHashMap.newKeySet();
 static AtomicInteger requests=new AtomicInteger(),active=new AtomicInteger(),maxActive=new AtomicInteger();static int checks;
 static byte[] png;static List<Object> manifest;static String fn,standard,missingCase;
 static class Progress extends JProgressBar {
  List<Integer> seen=Collections.synchronizedList(new ArrayList<>());
  Progress(){super(0,100);}public void setValue(int n){super.setValue(n);if(seen!=null)seen.add(n);}
 }
 static Progress progress;
 static Object call(String n,Class<?>[]t,Object...a)throws Exception{return MarketRegressionTests.call(n,t,a);}
 static Object get(String n)throws Exception{return MarketRegressionTests.field(n).get(gui);}
 static void set(String n,Object v)throws Exception{MarketRegressionTests.field(n).set(gui,v);}
 static Object member(Object o,String n)throws Exception{Field f=o.getClass().getDeclaredField(n);f.setAccessible(true);return f.get(o);}
 static void edt(MarketHomeFeedTests.Throwing a)throws Exception{MarketHomeFeedTests.edt(a);}
 static void flush()throws Exception{MarketHomeFeedTests.flush();}
 static void check(boolean b,String m){MarketRegressionTests.check(b,m);checks++;}
 static String key(String n,String w)throws Exception{return (String)call("getSkinArtworkKey",new Class[]{String.class,String.class},n,w);}
 static void setup()throws Exception{
  BufferedImage pixel=new BufferedImage(6,4,BufferedImage.TYPE_INT_ARGB);pixel.setRGB(2,2,0xffcc9933);ByteArrayOutputStream out=new ByteArrayOutputStream();ImageIO.write(pixel,"png",out);png=out.toByteArray();
  URL.setURLStreamHandlerFactory(p->!p.equals("https")?null:new URLStreamHandler(){protected URLConnection openConnection(URL u){return new URLConnection(u){public void connect(){}public InputStream getInputStream()throws IOException{
   String url=u.toString();requests.incrementAndGet();hits.merge(url,1,Integer::sum);int running=active.incrementAndGet();maxActive.accumulateAndGet(running,Math::max);
   try{if(getConnectTimeout()!=4000||getReadTimeout()!=6000)throw new AssertionError("Timeouts missing");if(failures.stream().anyMatch(f->java.net.URI.create(f).getRawPath().equals(java.net.URI.create(url).getRawPath())))throw new FileNotFoundException("mock 404");return new ByteArrayInputStream(png);}finally{active.decrementAndGet();}
  }};}});
  MarketRegressionTests.setup();gui=MarketRegressionTests.gui;TradeUpPresentationTests.gui=gui;
  for(String n:new String[]{"pendingRemoteImageLabels","unavailableRemoteImageUrls","startupResolvedArtworkUrls"})set(n,new ConcurrentHashMap<>());
  for(String n:new String[]{"remoteImageLoads","remoteImageGameViewRequests","marketPriceLookups","pendingMarketPriceLookups","startupPriceRequestedNames"})set(n,ConcurrentHashMap.newKeySet());
  for(String n:new String[]{"registerBundledTerminals","registerBundledArmouryCollections","registerRequestedMarketCollections"})call(n,new Class[0]);
  call("applyExternalSkinCatalog",new Class[]{String.class},Files.readString(Path.of("verification/current-skins.json")));
  ((Set)get("marketPriceLookups")).addAll(Files.readAllLines(Path.of("verification/agent-names.txt")));
  call("applyExternalAgentCatalog",new Class[]{String.class},Files.readString(Path.of("verification/current-agents.json")));
  Class<?> c=Class.forName("blahblah.ImageRepository");Constructor<?> ctor=c.getDeclaredConstructor(hGui.class);ctor.setAccessible(true);repo=ctor.newInstance(gui);set("imageRepository",repo);
  if(Files.exists(cache))try(var paths=Files.walk(cache)){for(Path p:paths.sorted(Comparator.reverseOrder()).collect(java.util.stream.Collectors.toList()))Files.delete(p);}
  Field disk=c.getDeclaredField("diskCacheDirectory");disk.setAccessible(true);disk.set(repo,cache);
  work=Executors.newSingleThreadExecutor();remote=Executors.newFixedThreadPool(2);set("remoteImageExecutor",remote);
  set("startupProgressPercent",0);set("startupProgressStatus","Preparing the interface...");set("startupStartedAt",System.currentTimeMillis());
  edt(()->{overlay=(JPanel)call("createStartupLoadingOverlay",new Class[0]);set("startupLoadingOverlay",overlay);overlay.setVisible(true);
   JProgressBar original=(JProgressBar)get("startupLoadingProgressBar");Container card=original.getParent();GridBagConstraints placement=((GridBagLayout)card.getLayout()).getConstraints(original);
   progress=new Progress();progress.setStringPainted(true);progress.setForeground(original.getForeground());progress.setBackground(original.getBackground());progress.setBorderPainted(false);progress.setPreferredSize(original.getPreferredSize());
   card.remove(original);card.add(progress,placement);set("startupLoadingProgressBar",progress);progress.setValue(0);});
 }
 static void initialScreen()throws Exception{
  edt(()->{TradeUpPresentationTests.render(overlay,"startup-screen-zero-render.png",810,860);});flush();
  check((Integer)get("startupProgressPercent")==0&&progress.getValue()==0,"The first loading-screen paint shows 0%, not an already-running 90% PNG phase");
  check(requests.get()==0&&!((Boolean)get("startupWorkStarted")),"Building/painting the loading UI does not fetch PNGs or start work before a displayable first paint");
  check((Boolean)get("startupStartQueued"),"The first actual overlay paint queues the deferred startup hook");
  String s=Files.readString(Path.of("hGui.java"));String ctor=TradeUpProbabilityTests.segment(s,"public hGui()", "private void initializeMarketQueue(");
  check(!ctor.contains("loadExternalSkinCatalog();")&&!ctor.contains("getContainerImage(currentCase)")&&!ctor.contains("generateLeaderboard();"),"The frame constructor no longer starts catalog/PNG downloads or heavy data preparation before the window is visible");
  String begin=TradeUpProbabilityTests.segment(s,"private void beginStartupLoading(","private JPanel createStartupLoadingOverlay(");check(begin.contains("startupProgressPercent = 0"),"Every normal startup explicitly resets the progress bar to zero");
  String flow=TradeUpProbabilityTests.segment(s,"private void startMarketFluctuationTimer(","private Set<String> getStartupArtworkNames(");
  check(flow.indexOf("preloadStartupSkinPrices();")<flow.indexOf("preloadStartupArtwork();")&&flow.indexOf("awaitStartupPriceLookups();")<flow.indexOf("preloadStartupArtwork();"),"The coordinator completes all skin-price work before beginning PNG preload");
  check(flow.indexOf("finishStartupLoading();")>flow.indexOf("startFakeSalesTimer();"),"The overlay stays up until all preload and ready-state preparation has finished");
  set("startupWorkStarted",true);set("startupArtworkStage",false);set("marketInitialized",false);
  call("getSkinImageFromName",new Class[]{String.class,String.class},"AWP | Dragon Lore","Factory New");Thread.sleep(40);
  check(requests.get()==0,"Behind-overlay UI lookups cannot start PNG downloads during the prices stage");
 }
 static void manifest()throws Exception{
  manifest=(List)call("buildStartupArtworkManifest",new Class[0]);Set<String> urls=new HashSet<>(),keys=new HashSet<>();for(Object job:manifest){urls.add((String)member(job,"primary"));keys.add((String)member(job,"key"));}
  check(manifest.size()>10000,"Startup queues the complete standard/wear catalog, not an 80-image sample");
  check(urls.size()==manifest.size(),"Shared image URLs and name aliases are deduplicated before downloading");
  fn=(String)call("getWearImageUrl",new Class[]{String.class,String.class},"AWP | Dragon Lore","Factory New");
  String bs=(String)call("getWearImageUrl",new Class[]{String.class,String.class},"AWP | Dragon Lore","Battle-Scarred");
  check(urls.contains(fn)&&urls.contains(bs),"Both genuine Dragon Lore FN and BS PNGs are included at startup");
  check(keys.contains(key("Sport Gloves | Vice","Battle-Scarred"))&&keys.contains(key("Bayonet | Doppler (Phase 2)","Factory New")),"The preload includes glove wear and phase-specific knife wear");
  int needed=0;boolean complete=true;
  for(String name:(Set<String>)call("getStartupArtworkNames",new Class[0]))for(String wear:(String[])call("getAvailableConditions",new Class[]{String.class},name)){
   String url=(String)call("getWearImageUrl",new Class[]{String.class,String.class},name,wear);if(url!=null){needed++;complete&=urls.contains(url);}
  }
  check(complete&&needed>9000,"Every valid configured skin/exterior URL is represented in the startup manifest");
  check(keys.stream().anyMatch(k->k.startsWith("case-selector-"))&&keys.stream().anyMatch(k->k.contains("Romanov")),"Case/container artwork and agent PNGs are preloaded as well");
  for(Object job:manifest)if(fn.equals(member(job,"primary")))standard=(String)member(job,"fallback");
  missingCase=(String)member(manifest.get(0),"primary");failures.add(missingCase);failures.add(fn);
 }
 static void prices()throws Exception{
  Set<String> names=(Set)call("getStartupArtworkNames",new Class[0]);Map prices=(Map)get("liveBasePrices");for(String name:names)prices.put(name,100.0);
  Set pending=(Set)get("pendingMarketPriceLookups");pending.add("AWP | Dragon Lore");
  Future<?> future=work.submit(()->{try{call("preloadStartupSkinPrices",new Class[0]);}catch(Exception e){throw new RuntimeException(e);}});
  long until=System.nanoTime()+TimeUnit.SECONDS.toNanos(4);while((Integer)get("startupProgressPercent")<10&&System.nanoTime()<until)Thread.sleep(10);flush();
  check(!future.isDone(),"Price-stage completion waits for outstanding quote application instead of jumping ahead");
  check(requests.get()==0,"No PNG download runs while the price-stage wait is pending");
  edt(()->pending.remove("AWP | Dragon Lore"));future.get(10,TimeUnit.SECONDS);flush();
  check((Integer)get("startupProgressPercent")==40&&((String)get("startupProgressStatus")).startsWith("Skin prices loaded:"),"Price progress advances into its actual completed-count range before PNGs begin");
  check(progress.getValue()>=10&&progress.getValue()<=40,"The visible progress bar updates during the skin-price stage");
 }
 static void pngs()throws Exception{
  set("startupArtworkStage",true);
  Future<?> future=work.submit(()->{try{call("preloadStartupArtwork",new Class[0]);}catch(Exception e){throw new RuntimeException(e);}});future.get(100,TimeUnit.SECONDS);flush();
  int total=(Integer)get("startupArtworkTotal"),loaded=(Integer)get("startupArtworkLoaded"),failed=(Integer)get("startupArtworkFailed");
  check(total==manifest.size()&&loaded+failed==total,"Startup waits for a completion result for every queued PNG, including failures");
  check(failed==1&&loaded==total-1,"Successful downloads are counted as loaded while a failed source is counted separately, never falsely loaded");
  check((Integer)get("startupArtworkFallbacks")==1,"An unavailable genuine wear render is successfully preloaded from its standard online fallback");
  check(((Map)get("startupResolvedArtworkUrls")).get(fn).equals(standard),"Resolved wear-to-standard fallback is remembered for later in-program image requests");
  check(((JLabel)get("startupLoadingArtworkDetailsLabel")).getText().contains("Skin PNGs loaded: "+loaded+" / "+total),"The persistent PNG counter explicitly shows loaded skin PNGs out of the complete total during later cache stages");
  check(progress.getValue()==93&&((JLabel)get("startupLoadingArtworkDetailsLabel")).getText().contains("Unavailable: 1"),"PNG downloads, container retention and opening-artwork readiness finish at 93% with honest fallback/unavailable counts visible");
  long files;try(var list=Files.list(cache)){files=list.filter(p->p.toString().endsWith(".png")).count();}
  check(files==total-2,"All successful unique source PNGs persist in the automatic disk cache, including across memory-cache eviction");
  Map memory=(Map)member(repo,"cache");check(memory.size()<=512,"Complete catalog preloading does not retain thousands of full-size decoded PNGs in RAM");
  int before=requests.get();set("marketInitialized",true);JLabel target=new JLabel();
  edt(()->call("getSkinImageFromName",new Class[]{String.class,String.class,JLabel.class,int.class,int.class},"AWP | Dragon Lore","Factory New",target,160,110));
  long until=System.nanoTime()+TimeUnit.SECONDS.toNanos(5);String k=key("AWP | Dragon Lore","Factory New");while(((Set)get("remoteImageLoads")).contains(k)&&System.nanoTime()<until)Thread.sleep(5);flush();
  check(target.getIcon()!=null&&requests.get()==before,"Opening a preloaded missing-wear image uses its cached fallback without a post-startup network retry");
  check(progress.seen.contains(0)&&progress.seen.stream().anyMatch(n->n>0&&n<=40)&&progress.seen.stream().anyMatch(n->n>45&&n<98),"Observed bar values include 0, price-stage progress and incremental PNG progress, not just 90% then 98%");
  int prev=-1;boolean monotonic=true;for(int p:progress.seen){if(p<prev)monotonic=false;prev=p;}check(monotonic,"Startup progress never goes backwards between stages");
  edt(()->TradeUpPresentationTests.render(overlay,"startup-screen-png-counter-render.png",810,860));
  System.out.println("MANIFEST: "+total+" unique requested PNG URLs; "+loaded+" loaded; "+failed+" unavailable; bounded cache "+memory.size());
 }
 static void warmCache()throws Exception{
  int before=requests.get();((Map)get("startupResolvedArtworkUrls")).clear();((Map)get("unavailableRemoteImageUrls")).clear();
  synchronized(repo){((Map)member(repo,"cache")).clear();}
  work.submit(()->{try{call("preloadStartupArtwork",new Class[0]);}catch(Exception e){throw new RuntimeException(e);}}).get(100,TimeUnit.SECONDS);flush();
  check(requests.get()==before+1+((ImageRepository)repo).steamArtworkMirrors(missingCase).size(),"A later cold-memory preload restores all successful PNGs from disk; only the unavailable primary sources and their official mirrors are checked again");
  check((Integer)get("startupArtworkLoaded")==manifest.size()-1&&(Integer)get("startupArtworkFallbacks")==1,"Warm-cache startup preserves complete loaded totals and genuine-wear fallback accounting");
  check(maxActive.get()<=8&&maxActive.get()>0,"Startup network concurrency stays bounded to the configured eight download workers");
 }
 static void guards()throws Exception{
  final boolean[] rejected={false};edt(()->{try{call("preloadStartupArtwork",new Class[0]);}catch(RuntimeException e){rejected[0]=e.getCause() instanceof IllegalStateException;}});
  check(rejected[0],"Full PNG download/decode work is explicitly forbidden on the Swing EDT");
  int old=(Integer)get("startupProgressPercent");call("setStartupProgress",new Class[]{int.class,String.class},10,"stale stage");flush();check((Integer)get("startupProgressPercent")==old,"Late earlier-stage notifications cannot reset loading progress");
  edt(()->call("finishStartupLoading",new Class[0]));check(progress.getValue()==100&&!overlay.isVisible(),"Only final startup completion sets 100% and dismisses the loading screen");
 }
 public static void main(String[]a)throws Exception{try{setup();initialScreen();manifest();prices();pngs();warmCache();guards();System.out.println("All "+checks+" complete-startup preload checks passed.");}finally{if(work!=null)work.shutdownNow();if(remote!=null)remote.shutdownNow();if(gui!=null)((java.util.prefs.Preferences)get("marketPricePreferences")).removeNode();if(Files.exists(cache))try(var p=Files.walk(cache)){for(Path f:p.sorted(Comparator.reverseOrder()).collect(java.util.stream.Collectors.toList()))Files.delete(f);}}System.exit(0);}
}
