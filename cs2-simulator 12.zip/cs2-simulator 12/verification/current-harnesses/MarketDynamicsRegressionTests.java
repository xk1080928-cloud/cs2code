package blahblah;
import java.util.*;
import java.lang.reflect.*;
import java.nio.file.*;
import java.awt.*;
import java.awt.image.BufferedImage;
import javax.swing.*;

@SuppressWarnings({"unchecked","rawtypes"})
public class MarketDynamicsRegressionTests {
 static hGui gui;
 static Object call(String n,Class<?>[] ts,Object...a)throws Exception{return MarketRegressionTests.call(n,ts,a);}
 static Object get(String n)throws Exception{Field f=MarketRegressionTests.field(n);return f.get(Modifier.isStatic(f.getModifiers())?null:gui);}
 static void set(String n,Object v)throws Exception{MarketRegressionTests.field(n).set(gui,v);}
 static void check(boolean b,String m){MarketRegressionTests.check(b,m);}
 static java.util.List<Runnable> tasks=new ArrayList<>();
 static void setup()throws Exception{
  MarketRegressionTests.setup();gui=MarketRegressionTests.gui;
  set("marketPriceExecutor",new java.util.concurrent.AbstractExecutorService(){
   public void execute(Runnable r){tasks.add(r);}public void shutdown(){}public java.util.List<Runnable> shutdownNow(){return java.util.List.of();}public boolean isShutdown(){return false;}public boolean isTerminated(){return false;}public boolean awaitTermination(long n,java.util.concurrent.TimeUnit u){return true;}
  });
 }
 static void supply()throws Exception{
  String[] rarities={"Consumer","Industrial","Milspec","Restricted","Classified","Covert","Contraband","Knife"};
  double previousSpread=1,previousCv=1,previousMean=Double.MAX_VALUE;
  StringBuilder audit=new StringBuilder("Rarity,Mean,Min,Max,Relative standard deviation,Configured spread\n");
  for(String rarity:rarities){
   double spread=(Double)call("getMarketSupplyVariance",new Class<?>[]{String.class},rarity);
   check(spread<previousSpread,rarity+" quantity variance is lower than the preceding rarity");previousSpread=spread;
   double sum=0,squares=0;int min=Integer.MAX_VALUE,max=0;Set<Integer> unique=new HashSet<>();
   for(int i=0;i<500;i++){
    String n="AK-47 | Supply audit "+rarity+" "+i;MarketRegressionTests.cap(n,0,1);((Map)get("rarityCache")).put(n,rarity);
    Map<String,Integer> normal=(Map)call("getMarketSupplyTargets",new Class<?>[]{String.class,boolean.class},n,false);
    Map<String,Integer> stat=(Map)call("getMarketSupplyTargets",new Class<?>[]{String.class,boolean.class},n,true);
    int total=normal.values().stream().mapToInt(Integer::intValue).sum(),st=stat.values().stream().mapToInt(Integer::intValue).sum();
    if(total!=(Integer)call("getMarketSupplyBudget",new Class<?>[]{String.class,boolean.class},n,false))throw new AssertionError("Rounding "+n);
    if(st>=total||normal.values().stream().anyMatch(c->c<6)||stat.values().stream().anyMatch(c->c<2))throw new AssertionError("Scarcity/floor "+n);
    if(!normal.equals(call("getMarketSupplyTargets",new Class<?>[]{String.class,boolean.class},n,false)))throw new AssertionError("Reroll "+n);
    sum+=total;squares+=total*(double)total;min=Math.min(min,total);max=Math.max(max,total);unique.add(total);
   }
   double mean=sum/500,cv=Math.sqrt(squares/500-mean*mean)/mean;
   check(cv<previousCv&&mean<previousMean&&unique.size()>=7,rarity+" has varied per-skin totals, a smaller measured relative spread and lower average supply");
   previousCv=cv;previousMean=mean;
   audit.append(String.format(java.util.Locale.ROOT,"%s,%.2f,%d,%d,%.5f,%.2f%n",rarity,mean,min,max,cv,spread));
  }
  Files.writeString(Path.of("verification/supply-variance-audit.csv"),audit.toString());
  check(true,"Supply budgets are stable on repeated calls, conserve exact per-skin totals, preserve wear floors and keep StatTrak scarcer");
  String a="AK-47 | Dynamics Full",b="AK-47 | Dynamics Other";
  MarketRegressionTests.cap(a,0,1);MarketRegressionTests.cap(b,.1,.42);
  Map<String,ArrayList<MarketListing>> market=(Map)get("globalMarketListings");
  ArrayList<MarketListing> first=new ArrayList<>(),second=new ArrayList<>();market.put(a,first);market.put(b,second);
  MarketListing player=MarketRegressionTests.listing(a,"Factory New",false,true,9999,.02);first.add(player);
  call("ensureMinimumListings",new Class<?>[0]);
  int before=first.size()+second.size();
  call("ensureMinimumListings",new Class<?>[0]);
  check(before==first.size()+second.size()&&first.contains(player)&&player.listPrice==9999,"Replenishing does not reroll supply or change player asks");
  check(MarketRegressionTests.counts(second).size()==3,"Varied supply still respects capped skins' available wear conditions");
  first.removeIf(l->!l.isPlayerListing&&l.item.condition.equals("Factory New"));
  call("ensureMinimumListings",new Class<?>[0]);
  check(before==first.size()+second.size(),"Depleted wear replenishes to its original varied target, not a universal stock count");
  market.clear();
 }
 static void capitalization()throws Exception{
  Map<String,ArrayList<MarketListing>> market=(Map)get("globalMarketListings");market.clear();
  MarketListing listing=MarketRegressionTests.listing("Special Agent Ava | FBI","Normal",false,true,250,0);
  market.put("fixture",new ArrayList<>(java.util.List.of(listing)));gui.globalSupply.initialize();
  check((Double)call("calculateTotalMarketCap",new Class<?>[0])==250,"Independent surviving-supply valuation remains exact without a graph or sampling clock");
  market.put("duplicate fixture",new ArrayList<>(java.util.List.of(listing)));
  check((Double)call("calculateTotalMarketCap",new Class<?>[0])==250,"Independent valuation deduplicates the same backing lot");
  market.clear();((java.util.List)get("inventoryList")).clear();
 }
 static <T> T find(Component c,Class<T> type){if(type.isInstance(c))return type.cast(c);if(c instanceof Container)for(Component x:((Container)c).getComponents()){T r=find(x,type);if(r!=null)return r;}return null;}
 static void layout(Component c){if(c instanceof Container){((Container)c).doLayout();for(Component x:((Container)c).getComponents())layout(x);}}
 static void menus()throws Exception{
  call("registerRequestedMarketCollections",new Class<?>[0]);
  String[] items=(String[])call("getMarketplaceCollectionMenuItems",new Class<?>[0]);
  String[] group={"Home"},selected={null};int[] rebuild={0};
  JPopupMenu menu=(JPopupMenu)call("buildMarketplaceSelectionMenu",new Class<?>[]{String.class,String[].class,String[].class,String[].class,Runnable.class,int.class},"Collections",items,group,selected,(Runnable)()->rebuild[0]++,360);
  menu.setSize(menu.getPreferredSize());layout(menu);
  JTextField search=find(menu,JTextField.class);JList list=find(menu,JList.class);JScrollPane scroll=find(menu,JScrollPane.class);
  check(menu.getHeight()<=360&&list.getModel().getSize()>=49&&scroll!=null,"All collection choices live inside a bounded scrollable popup, not a cut-off screen-height menu");
  list.setSelectedIndex(list.getModel().getSize()-1);list.ensureIndexIsVisible(list.getSelectedIndex());layout(menu);
  check(scroll.getViewport().getViewPosition().y>0,"Last collection can be reached by scrolling the menu");
  search.setText("sPy TeCh");
  check(list.getModel().getSize()==1&&list.getModel().getElementAt(0).toString().contains("Spy Tech"),"Collection search filters case-insensitively");
  search.postActionEvent();
  check(group[0].equals("Collections")&&selected[0].contains("Spy Tech")&&rebuild[0]==1,"Enter selects the filtered collection and rebuilds the market view");
  search.setText("nonexistent collection 1234");search.postActionEvent();
  check(list.getModel().getSize()==0&&rebuild[0]==1,"No-match searches are safe and do not change the current filter");
  search.setText("");list.setSelectedIndex(list.getModel().getSize()-1);
  list.getActionMap().get("chooseOption").actionPerformed(new java.awt.event.ActionEvent(list,0,"enter"));
  check(selected[0].equals(items[items.length-1])&&rebuild[0]==2,"Keyboard selection works for the last collection as well as the first");
  menu.setSize(menu.getPreferredSize());layout(menu);
  BufferedImage image=new BufferedImage(menu.getWidth(),menu.getHeight(),BufferedImage.TYPE_INT_RGB);Graphics2D g=image.createGraphics();menu.printAll(g);g.dispose();javax.imageio.ImageIO.write(image,"png",Path.of("verification/collection-menu-render.png").toFile());
  JPopupMenu shortMenu=(JPopupMenu)call("buildMarketplaceSelectionMenu",new Class<?>[]{String.class,String[].class,String[].class,String[].class,Runnable.class,int.class},"Collections",items,group,selected,(Runnable)()->{},170);
  check(shortMenu.getPreferredSize().height<=170,"Collection popup also fits a short available screen region");
 }
 static void queuedQuotes()throws Exception{
  ((Map)get("publicPriceSnapshots")).put("csfloat","{\"★ Karambit\":{\"price\":1523.45},\"★ StatTrak™ Karambit\":{\"price\":1400.00}}");
  ((Map)get("publicPriceSnapshotTimes")).put("csfloat",System.currentTimeMillis());
  tasks.clear();call("scheduleMarketPriceLookup",new Class<?>[]{String.class,double.class},"Karambit | Vanilla",100.0);
  check(((Set)get("pendingMarketPriceLookups")).contains("Karambit | Vanilla")&&tasks.size()==1,"Bootstrap tracks quote work while it is queued");
  tasks.remove(0).run();
  check(((Set)get("pendingMarketPriceLookups")).contains("Karambit | Vanilla"),"Quote stays pending until its price correction has actually been applied on the EDT");
 }
 public static void main(String[] args)throws Exception{
  setup();SwingUtilities.invokeAndWait(()->{try{supply();capitalization();menus();queuedQuotes();}catch(Exception e){throw new RuntimeException(e);}});
  SwingUtilities.invokeAndWait(()->{});
  check(!((Set)get("pendingMarketPriceLookups")).contains("Karambit | Vanilla"),"Applied quote clears pending startup work so chart recording can begin");
  call("generateGlobalMarketListings",new Class<?>[0]);
  Map<String,ArrayList<MarketListing>> generated=(Map)get("globalMarketListings");
  int initialTotal=generated.values().stream().mapToInt(java.util.List::size).sum();
  call("ensureMinimumListings",new Class<?>[0]);
  check(initialTotal==generated.values().stream().mapToInt(java.util.List::size).sum(),"Full startup generation already matches final supply: first replenishment cannot inflate the market cap by adding missing stock");
  check(generated.size()>750,"Full generation includes the requested collections, case skins, knives, gloves, StatTrak and Agents");
  ((java.util.prefs.Preferences)get("marketPricePreferences")).removeNode();
  System.out.println("All market dynamics regression tests passed.");
 }
}
