package blahblah;
import java.lang.reflect.*;
import java.nio.file.*;
import java.util.*;
import java.util.List;
import java.awt.*;
import java.awt.event.*;
import java.awt.image.BufferedImage;
import java.util.concurrent.*;
import javax.swing.*;
import javax.imageio.ImageIO;
@SuppressWarnings({"unchecked","rawtypes"})
public class MarketHomeFeedTests {
 static hGui gui; static List<List<Object>> groups; static JPanel root,browser,feed;
 static Class<?> sourceClass,tierClass,entryClass;
 static Object call(String n,Class<?>[] t,Object...a)throws Exception{return MarketRegressionTests.call(n,t,a);}
 static Object get(Object o,String n)throws Exception{Field f=o.getClass().getDeclaredField(n);f.setAccessible(true);return f.get(o);}
 static void set(Object o,String n,Object v)throws Exception{Field f=o.getClass().getDeclaredField(n);f.setAccessible(true);f.set(o,v);}
 static Object innerCall(Object o,String n,Class<?>[] t,Object...a)throws Exception{Method m=o.getClass().getDeclaredMethod(n,t);m.setAccessible(true);return m.invoke(o,a);}
 static void check(boolean b,String m){MarketRegressionTests.check(b,m);}
 static void edt(Throwing r)throws Exception{SwingUtilities.invokeAndWait(()->{try{r.run();}catch(Exception e){throw new RuntimeException(e);}});}
 interface Throwing{void run()throws Exception;}
 static void flush()throws Exception{edt(()->{});edt(()->{});}
 static Object forced(String kind,String skin,String rarity)throws Exception{
  ((Map)MarketRegressionTests.field("liveBasePrices").get(gui)).put(skin,100.0);
  ((Set)MarketRegressionTests.field("remoteImageLoads").get(gui)).add(skin);
  Constructor<?> t=tierClass.getDeclaredConstructor(String.class,double.class,Map.class);t.setAccessible(true);Object tier=t.newInstance(rarity,1,Map.of(skin,1.0));
  Constructor<?> c=sourceClass.getDeclaredConstructor(String.class,String.class,List.class);c.setAccessible(true);return c.newInstance(kind,"Forced float-cap fixture",List.of(tier));
 }
 static Object roll(Object source)throws Exception{return call("rollHomeUnboxSource",new Class[]{sourceClass,boolean.class},source,false);}
 static SaleRecord record(Object entry)throws Exception{return (SaleRecord)get(entry,"record");}
 static List<SaleRecord> history()throws Exception{return (List)MarketRegressionTests.field("recentUnboxedSkins").get(gui);}
 static void setup()throws Exception{
  MarketRegressionTests.setup();gui=MarketRegressionTests.gui;DevGeneratorTests.gui=gui;TradeUpPresentationTests.gui=gui;
  call("registerBundledTerminals",new Class[0]);call("registerRequestedMarketCollections",new Class[0]);
  call("applyExternalSkinCatalog",new Class[]{String.class},Files.readString(Path.of("verification/current-skins.json")));
  call("applyExternalCrateCatalog",new Class[]{String.class},Files.readString(Path.of("crates.json")));
  Class<?> repo=Class.forName("blahblah.ImageRepository");Constructor<?> rc=repo.getDeclaredConstructor(hGui.class);rc.setAccessible(true);MarketRegressionTests.field("imageRepository").set(gui,rc.newInstance(gui));
  sourceClass=Class.forName("blahblah.HomeUnboxSource");tierClass=Class.forName("blahblah.HomeUnboxTier");entryClass=Class.forName("blahblah.HomeUnboxEntry");
  groups=(List)call("buildHomeUnboxSources",new Class[0]);
  Map<String,Double> prices=(Map)MarketRegressionTests.field("liveBasePrices").get(gui);Set<String> loads=(Set)MarketRegressionTests.field("remoteImageLoads").get(gui);
  for(List<Object> group:groups)for(Object source:group)for(Object tier:(List)get(source,"tiers"))for(Object n:((Map)get(tier,"skins")).keySet()){prices.put((String)n,100.0);loads.add((String)n);}
 }
 static void probabilities()throws Exception{
  check(groups.size()==3&&groups.stream().allMatch(g->!g.isEmpty()),"Live source pools contain cases, souvenir packages and Armoury collections");
  Set<String> kinds=new HashSet<>();Object chroma=null;
  for(List<Object> group:groups)for(Object source:group){
   String kind=(String)get(source,"kind"),name=(String)get(source,"name");kinds.add(kind);
   if(kind.equals("Case")&&name.equals("Chroma Case"))chroma=source;
   checkSource(source);
  }
  check(kinds.equals(Set.of("Case","Souvenir package","Armoury")),"Each source is categorized before rarity/skin selection, without mixing unrelated skin pools");
  check(chroma!=null,"A Chroma case is available for exact-odds verification");
  Map<String,Double> weights=new HashMap<>();Object gold=null;for(Object tier:(List)get(chroma,"tiers")){weights.put((String)get(tier,"rarity"),(Double)get(tier,"weight"));if(get(tier,"rarity").equals("Gold"))gold=tier;}
  check(weights.equals(Map.of("Milspec",.7992,"Restricted",.1598,"Classified",.032,"Covert",.0064,"Gold",.0026)),"Normal cases preserve exact 79.92 / 15.98 / 3.20 / 0.64 / 0.26 percent opening odds");
  Map<String,Double> goldOdds=(Map)get(gold,"skins"),expected=(Map)call("getCaseUnboxingGoldOutcomeOdds",new Class[]{CaseType.class,String.class},CaseType.CHROMA,null);
  check(goldOdds.equals(expected),"Gold drops reuse the actual unboxing distribution, not trade-up gem weights");
  String d="Bayonet | Doppler";double sum=goldOdds.entrySet().stream().filter(e->e.getKey().startsWith(d+" (")).mapToDouble(Map.Entry::getValue).sum();
  check(Math.abs(goldOdds.get(d+" (Ruby)")/sum-.035)<1e-12&&Math.abs(goldOdds.get(d+" (Phase 1)")/sum-.23)<1e-12,"Conditional Chroma Doppler weights remain 23% per phase and 3.5% per Ruby/Sapphire");
  Object souvenir=groups.get(1).get(0);double previous=0;boolean valid=true;for(Object tier:(List)get(souvenir,"tiers")){double w=(Double)get(tier,"weight");if(previous>0&&Math.abs(previous/w-5)>1e-10)valid=false;previous=w;}
  check(valid,"Souvenir package rarity odds use the same normalized five-to-one tier curve as actual openings");
  Map<String,Integer> counts=new HashMap<>();long start=System.nanoTime();for(int i=0;i<30000;i++){Object e=roll(chroma);counts.merge((String)get(e,"rarity"),1,Integer::sum);}
  double goldRate=(counts.getOrDefault("Knife",0)+counts.getOrDefault("Gloves",0))/30000.0;
  check(Math.abs(counts.getOrDefault("Milspec",0)/30000.0-.7992)<.012&&Math.abs(goldRate-.0026)<.0015,"Thirty thousand source-first case rolls reproduce ordinary opening rarity odds without boosted rare outcomes");
  Map<String,Integer> typeCounts=new HashMap<>();for(int i=0;i<6000;i++){Object e=call("rollHomeUnbox",new Class[]{List.class,boolean.class},groups,false);String source=record(e).marketplaceName;typeCounts.merge(source.substring(0,source.indexOf(" · ")),1,Integer::sum);}
  check(typeCounts.size()==3&&typeCounts.values().stream().allMatch(v->Math.abs(v/6000.0-1.0/3)<.04),"Source type is chosen uniformly first; the number of skins/sources cannot bias its share");
  check(history().isEmpty()&&((List)MarketRegressionTests.field("inventoryList").get(gui)).isEmpty(),"Preparing a reward draw alone does not commit history, inventory, money or supply; the producer commits separately");
  System.out.printf("TIMING: 36,000 source-aware openings generated in %.3f seconds, without rendering or market scans%n",(System.nanoTime()-start)/1e9);
 }
 static void checkSource(Object source)throws Exception{
  List<Object> tiers=(List)get(source,"tiers");if(tiers.isEmpty())throw new AssertionError("Empty source");
  String name=(String)get(source,"name");if(name.contains("Terminal"))throw new AssertionError("Unrequested terminal source");
  for(Object tier:tiers)if(((Double)get(tier,"weight"))<=0||((Map)get(tier,"skins")).isEmpty())throw new AssertionError("Empty tier");
 }
 static void caps()throws Exception{
  String[][] skins={{"M4A1-S | Hot Rod","Covert"},{"AWP | Dragon Lore","Covert"},{"Bayonet | Doppler (Ruby)","Knife"},{"Butterfly Knife | Gamma Doppler (Emerald)","Knife"},{"Sport Gloves | Vice","Gloves"}};
  for(String[] pair:skins){Object forced=forced("Case",pair[0],pair[1]);Object bounds=call("findFloatRange",new Class[]{String.class},pair[0]);double lo=get(bounds,"min")==null?0:(Double)get(bounds,"min"),hi=get(bounds,"max")==null?1:(Double)get(bounds,"max");Set<Double> floats=new HashSet<>();
   for(int i=0;i<200;i++){SaleRecord r=record(roll(forced));if(r.itemFloat<lo||r.itemFloat>hi||!r.condition.equals(call("getConditionForFloat",new Class[]{String.class,double.class},pair[0],r.itemFloat)))throw new AssertionError("Invalid float/wear: "+pair[0]);floats.add(r.itemFloat);}
   check(floats.size()>190,"Independent floats and matching wear respect the cap for "+pair[0]);
  }
  Object vanilla=forced("Case","Bayonet | Vanilla","Knife");SaleRecord plain=record(roll(vanilla));check(plain.itemFloat==0&&plain.condition.equals("Normal"),"Vanilla knives remain Normal and have no artificial float");
  Object souvenir=forced("Souvenir package","AWP | Dragon Lore","Covert");boolean safe=true;for(int i=0;i<200;i++){SaleRecord r=record(roll(souvenir));safe&=r.skinName.startsWith("Souvenir ")&&!r.skinName.contains("StatTrak")&&r.marketplaceName.contains("Souvenir package");}check(safe,"Souvenir outputs are marked Souvenir, never StatTrak, and identify their actual package source");
  Object armoury=forced("Armoury","M4A1-S | Hot Rod","Covert");safe=true;for(int i=0;i<200;i++)safe&=!record(roll(armoury)).skinName.startsWith("StatTrak");check(safe,"Armoury redemption outputs never acquire case-only StatTrak status");
 }
 static void visibilityAndNavigation()throws Exception{
  edt(()->{browser=(JPanel)call("createMarketplaceBrowserPanel",new Class[0]);root=new JPanel(new BorderLayout());root.add(browser);root.setSize(1100,950);root.addNotify();DevGeneratorTests.layout(root);});flush();
  edt(()->{
   feed=(JPanel)DevGeneratorTests.find(browser,"marketHomeUnboxFeed");DevGeneratorTests.layout(root);
   check(feed!=null&&feed.getComponentCount()==0,"Home uses one bounded painted feed, not accumulating Swing cards");
   check(!((javax.swing.Timer)get(feed,"feedTimer")).isRunning()&&get(feed,"worker")==null,"Unbox Home is now a passive subscriber; its independent producer is validated by native CareSupplyChecks");
   Object sample=roll(forced("Case","AWP | Dragon Lore","Covert"));for(int n=0;n<10;n++)gui.backgroundUnboxing.publish((HomeUnboxEntry)sample);
   check(history().size()==10&&((List)get(feed,"entries")).size()==7,"Global producer publishes history once and the visible subscriber keeps only six rows plus its transition row");
   JButton home=(JButton)DevGeneratorTests.find(browser,"marketplaceHomeButton");Object before=get(feed,"entries");int size=history().size();for(int n=0;n<100;n++)home.doClick(0);
   check(DevGeneratorTests.find(browser,"marketHomeUnboxFeed")==feed&&get(feed,"entries")==before&&history().size()==size,"Spamming Home neither rebuilds the chain nor invents global openings");
   root.setVisible(false);check(!((javax.swing.Timer)get(feed,"animationTimer")).isRunning(),"Hiding Home stops only its visual animation");
   gui.backgroundUnboxing.publish((HomeUnboxEntry)sample);check(history().size()==size+1,"Global history continues while the Home view is hidden");
   root.setVisible(true);check(DevGeneratorTests.find(browser,"marketHomeUnboxFeed")==feed,"Returning Home reuses the existing bounded view");root.setVisible(false);
  });
 }
 static void boundedAndRender()throws Exception{
  edt(()->{
   Object source=forced("Case","AWP | Dragon Lore","Covert");Object e=roll(source);String key=(String)get(e,"imageKey");Image image=ImageIO.read(Path.of("verification/artwork-fixtures/AWP---Dragon-Lore.png").toFile());TradeUpPresentationTests.putArt(key,image);
   for(int i=0;i<2200;i++)gui.backgroundUnboxing.publish((HomeUnboxEntry)e);
   ((javax.swing.Timer)get(feed,"animationTimer")).stop();
   check(((List)get(feed,"entries")).size()==7&&history().size()==2000,"Even 2,200 arrivals keep the animated chain and recent-history storage bounded");
   set(feed,"insertedAt",System.nanoTime()-200000000L);TradeUpPresentationTests.render(feed,"market-home-live-feed-render.png",1000,504);
   check(feed.getComponentCount()==0,"Long-running feed updates never accumulate Swing cards, image labels or listeners");
  });
  String source=Files.readString(Path.of("hGui.java"));String fake=TradeUpProbabilityTests.segment(source,"private void startFakeSalesTimer(","private Map.Entry<String, MarketListing> chooseWeightedMarketSaleCandidateEntry");
  check(!fake.contains("generateSimulatedRecentUnbox")&&!fake.contains("recentUnboxedSkins"),"Market sales/startup timers no longer create fake unboxes or seed boosted history");
  String artwork=TradeUpProbabilityTests.segment(source,"private Image getHomeUnboxArtwork(","private HomeUnboxEntry rollHomeUnboxSource(");
  check(artwork.contains("getRemoteSkinArtwork(skin, condition, false)")&&!artwork.contains("getSkinImageFromName("),"Feed image downloads populate the cache without invoking inventory scans, animation invalidations or unrelated-page refresh callbacks");
  check(source.contains("if (!notifyGameViews && !regularUIRequested)")&&source.contains("remoteImageGameViewRequests.add(skinName)"),"An image already loading for the feed can be promoted if another page requests it, preserving normal inventory/unboxing artwork updates");
  String home=TradeUpProbabilityTests.segment(source,"private void createMarketplaceHomeContent(","private JLabel createMarketplaceHomeSectionLabel");check(!home.contains("getRandomRecentUnboxSlots")&&home.contains("new MarketHomeUnboxFeed()"),"The Home feed no longer samples shuffled/rare-boosted slots from market history");
 }
 public static void main(String[] args)throws Exception{try{setup();probabilities();caps();visibilityAndNavigation();boundedAndRender();System.out.println("All source-first live-feed odds, caps, lifecycle, navigation and bounded-render tests passed.");}finally{if(root!=null)edt(()->{root.setVisible(false);root.removeNotify();});((java.util.prefs.Preferences)MarketRegressionTests.field("marketPricePreferences").get(gui)).removeNode();}System.exit(0);}
}
