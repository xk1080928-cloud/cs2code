package blahblah;
import java.util.*;
import java.lang.reflect.*;
import java.nio.file.*;
import java.awt.*;
import java.awt.event.*;
import java.awt.image.BufferedImage;
import javax.swing.*;

@SuppressWarnings({"unchecked","rawtypes"})
public class DevChartRestockTests {
 static hGui gui;
 static Object call(String n,Class<?>[] ts,Object...a)throws Exception{return MarketRegressionTests.call(n,ts,a);}
 static Object get(String n)throws Exception{Field f=MarketRegressionTests.field(n);return f.get(Modifier.isStatic(f.getModifiers())?null:gui);}
 static void set(String n,Object v)throws Exception{MarketRegressionTests.field(n).set(gui,v);}
 static Object prop(Object o,String n)throws Exception{Field f=o.getClass().getDeclaredField(n);f.setAccessible(true);return f.get(o);}
 static void check(boolean b,String m){MarketRegressionTests.check(b,m);}
 static void configure(CaseType ct,String mode,String target,int count,String st)throws Exception{call("configureDevCaseOverride",new Class<?>[]{CaseType.class,String.class,String.class,int.class,String.class},ct,mode,target,count,st);}
 static Object roll(CaseType ct)throws Exception{return call("rollCaseForOpening",new Class<?>[]{CaseType.class},ct);}
 static Map<String,java.util.List<String>> pools(CaseType ct)throws Exception{return (Map)call("getDevCaseOutcomePools",new Class<?>[]{CaseType.class},ct);}
 static Component find(Component c,String name){if(name.equals(c.getName()))return c;if(c instanceof Container)for(Component ch:((Container)c).getComponents()){Component got=find(ch,name);if(got!=null)return got;}return null;}
 static void layout(Component c){if(c instanceof Container){((Container)c).doLayout();for(Component ch:((Container)c).getComponents())layout(ch);}}
 static void restocking()throws Exception{
  String name="AK-47 | Gradual refill fixture";MarketRegressionTests.cap(name,0,1);
  Map<String,ArrayList<MarketListing>> market=(Map)get("globalMarketListings");ArrayList<MarketListing> bucket=new ArrayList<>();market.put(name,bucket);
  call("ensureMinimumListings",new Class<?>[0]);int initial=bucket.size();
  check(initial>100,"Startup still seeds the complete per-skin market supply");
  MarketListing player=MarketRegressionTests.listing(name,"Factory New",false,true,12345,.03);bucket.clear();bucket.add(player);
  set("marketInitialized",true);Map<String,Long> last=(Map)get("lastNpcRestockAt");last.put(name,0L);
  call("ensureMinimumListings",new Class<?>[0]);int first=bucket.size()-1;int batch=(Integer)call("getNpcRestockBatchSize",new Class<?>[]{String.class},name);
  check(first>0&&first<=batch&&first<initial,"Runtime shortages receive only a small batch, not a full refill");
  call("ensureMinimumListings",new Class<?>[0]);call("replenishThinMarketListings",new Class<?>[0]);
  check(bucket.size()==first+1,"Repeated refresh and repair calls cannot bypass the per-skin restocking cooldown");
  for(int tick=0;tick<100;tick++){last.put(name,0L);call("ensureMinimumListings",new Class<?>[0]);}
  check(bucket.size()==initial+1&&bucket.contains(player)&&player.listPrice==12345,"Gradual batches eventually reach the stable target without touching player listings");
  check(MarketRegressionTests.counts(bucket).size()==5,"Round-robin replenishment covers every valid wear");
  for(MarketListing l:bucket)MarketRegressionTests.checkFloat(l,0,1);
  check(true,"Gradually generated stock keeps valid floats and wear conditions");
  int previous=Integer.MAX_VALUE;
  for(String rarity:new String[]{"Consumer","Industrial","Milspec","Restricted","Classified","Covert","Knife"}){
   ((Map)get("rarityCache")).put(name,rarity);int next=(Integer)call("getNpcRestockBatchSize",new Class<?>[]{String.class},name);
   if(next>=previous)throw new AssertionError("Batch rarity "+rarity);previous=next;
  }
  check(true,"Higher-rarity skins replenish in progressively smaller batches");market.clear();set("marketInitialized",false);
 }
 static void developer()throws Exception{
  call("registerBundledTerminals",new Class<?>[0]);
  call("applyExternalSkinCatalog",new Class<?>[]{String.class},Files.readString(Path.of("verification/current-skins.json")));
  call("applyExternalCrateCatalog",new Class<?>[]{String.class},Files.readString(Path.of("crates.json")));
  CaseType genesis=null,dead=null,souvenir=null;
  for(CaseType c:CaseType.values()){
   if(c.crateName.equals("Sealed Genesis Terminal"))genesis=c;
   if(c.crateName.equals("Sealed Dead Hand Terminal"))dead=c;
   if(c.isSouvenir&&souvenir==null)souvenir=c;
   Map<String,java.util.List<String>> p=pools(c);
   for(Map.Entry<String,java.util.List<String>> e:p.entrySet())for(String n:e.getValue()){
    if(e.getKey().equals("Knife")||e.getKey().equals("Gloves")){
     String base=n.replaceAll("\\s*\\((?:Phase [1-4]|Ruby|Sapphire|Emerald|Black Pearl)\\)$","");
     if(!c.rareDropNames.contains(n)&&!c.rareDropNames.contains(base))throw new AssertionError("Cross-case rare "+n+" "+c.name);
    }else if(!c.regularDropNames.getOrDefault(e.getKey(),java.util.List.of()).contains(n))throw new AssertionError("Cross-case regular "+n);
   }
  }
  check(true,"Every developer option is from that container's verified regular/rare pool, including only valid Doppler expansions");
  check(!pools(genesis).containsKey("Knife")&&!pools(genesis).containsKey("Gloves")&&!pools(dead).containsKey("Knife")&&pools(dead).containsKey("Gloves"),"Genesis offers no gold override; Dead Hand offers gloves, not knives");
  String skin=genesis.regularDropNames.get("Covert").get(0);configure(genesis,"Skin",skin,3,"Always");
  for(int i=0;i<3;i++){Object result=roll(genesis);if(!skin.equals(prop(result,"forcedSkinName"))||!(Boolean)prop(result,"isStatTrak"))throw new AssertionError("Forced skin/count");}
  check(!((Map)get("devCaseOverrides")).containsKey(genesis.id)&&prop(roll(genesis),"forcedSkinName")==null,"Exact skin override fires exactly N times, then automatically returns to normal odds");
  configure(genesis,"Rarity","Covert",2,"Never");roll(dead);
  Object rule=((Map)get("devCaseOverrides")).get(genesis.id);
  check((Integer)prop(rule,"remaining")==2,"Opening a different case does not consume or apply this case's override");
  for(int i=0;i<2;i++){Object result=roll(genesis);if(!"Covert".equals(prop(result,"rarityName"))||!genesis.regularDropNames.get("Covert").contains(prop(result,"forcedSkinName"))||(Boolean)prop(result,"isStatTrak"))throw new AssertionError("Rarity");}
  check(true,"Forced rarity rolls choose only matching skins from the configured case");
  configure(CaseType.BRAVO,"Rarity","Knife",20,"Always");
  for(int i=0;i<20;i++)if(!"Knife".equals(prop(roll(CaseType.BRAVO),"rarityName")))throw new AssertionError("Knife");
  check(true,"Knife-every-time works only for a case with verified knife outcomes");
  boolean rejected=false;try{configure(genesis,"Skin",dead.regularDropNames.get("Covert").get(0),1,"Normal odds");}catch(Exception e){rejected=true;}
  check(rejected,"Cross-case skin overrides are rejected");rejected=false;try{configure(dead,"Rarity","Knife",1,"Normal odds");}catch(Exception e){rejected=true;}
  check(rejected,"Knife overrides are rejected for a gloves-only container");
  configure(dead,"Rarity","Gloves",1,"Always");check(!(Boolean)prop(roll(dead),"isStatTrak"),"Developer settings cannot create nonexistent StatTrak gloves");
  String tier=pools(souvenir).keySet().iterator().next();configure(souvenir,"Rarity",tier,1,"Always");
  check(!(Boolean)prop(roll(souvenir),"isStatTrak"),"Souvenir overrides cannot create StatTrak drops");
  set("currentCase",genesis);JPanel panel=(JPanel)call("buildDevToolsPanel",new Class<?>[0]);
  JList<CaseType> containers=(JList)find(panel,"devContainer");JComboBox<String> modes=(JComboBox)find(panel,"devMode"),outcomes=(JComboBox)find(panel,"devOutcome");
  containers.setSelectedValue(dead,true);modes.setSelectedItem("Rarity");Set<String> menu=new HashSet<>();for(int i=0;i<outcomes.getItemCount();i++)menu.add(outcomes.getItemAt(i));
  check(menu.equals(pools(dead).keySet()),"Changing the Dev Tools container immediately rebuilds the rarity selections");
  modes.setSelectedItem("Skin");Set<String> expected=new HashSet<>();for(java.util.List<String> ns:pools(dead).values())expected.addAll(ns);menu.clear();for(int i=0;i<outcomes.getItemCount();i++)menu.add(outcomes.getItemAt(i));
  check(menu.equals(expected),"Changing to exact-skin mode shows only skins in the newly selected container");
  panel.setSize(760,680);layout(panel);BufferedImage image=new BufferedImage(760,680,2);Graphics2D g=image.createGraphics();panel.printAll(g);g.dispose();javax.imageio.ImageIO.write(image,"png",Path.of("verification/dev-tools-render.png").toFile());
  set("balance",100.0);call("adjustDevMoney",new Class<?>[]{double.class,String.class},50.25,"Add");check((Double)get("balance")==150.25,"Money can be added with exact cents");
  call("adjustDevMoney",new Class<?>[]{double.class,String.class},1000.0,"Remove");check((Double)get("balance")==0,"Money removal clamps to zero, not a negative balance");
  call("adjustDevMoney",new Class<?>[]{double.class,String.class},900.5,"Set");check((Double)get("balance")==900.5,"Money can be set directly");
  set("playerStars",10);call("adjustDevStars",new Class<?>[]{int.class,String.class},20,"Add");check((Integer)get("playerStars")==30,"Stars can be added");
  call("adjustDevStars",new Class<?>[]{int.class,String.class},99,"Remove");check((Integer)get("playerStars")==0,"Star removal clamps safely to zero");
  call("adjustDevStars",new Class<?>[]{int.class,String.class},500,"Set");check((Integer)get("playerStars")==500,"Stars can be set directly");
  set("devFreeCaseOpenings",true);check((Double)call("getCaseOpeningCost",new Class<?>[]{CaseType.class},genesis)==0,"Free-opening developer toggle removes the actual case cost");set("devFreeCaseOpenings",false);
  // Exercise final selection itself, not just the configured roll.
  Class<?> repo=Class.forName("blahblah.ImageRepository");Constructor<?> ctor=repo.getDeclaredConstructor(hGui.class);ctor.setAccessible(true);Object cache=ctor.newInstance(gui);set("imageRepository",cache);
  Method put=repo.getDeclaredMethod("put",String.class,Image.class);put.setAccessible(true);put.invoke(cache,skin,new BufferedImage(150,95,2));
  Constructor<?> mission=Class.forName("blahblah.MissionProgress").getDeclaredConstructor();mission.setAccessible(true);set("missionProgress",mission.newInstance());
  ((Map)get("liveBasePrices")).put(skin,10.0);set("currentCase",genesis);configure(genesis,"Skin",skin,1,"Never");Object forced=roll(genesis);
  call("generateFinalSkinDetails",new Class<?>[]{forced.getClass()},forced);
  check(skin.equals(get("finalSkinName")),"The actual reward-generation path honors the exact forced skin");
 }
 static void charts()throws Exception{
  for(String removed:new String[]{"PriceChartScreen","MarketCapChartPanel","MarketCapSample"}){
    boolean absent=false;try{Class.forName("blahblah."+removed);}catch(ClassNotFoundException expected){absent=true;}
    check(absent,"Removed total-cap graph class is absent: "+removed);
  }
  check(Class.forName("blahblah.MarketHistoryScreen")!=null&&Class.forName("blahblah.SalesHistoryScreen")!=null,"Individual skin and recent-sales history screens remain available");
 }
 static void resetAndLayout()throws Exception{
  set("casesTabPanel",new JPanel(null));((JPanel)get("casesTabPanel")).setSize(1000,760);
  for(String n:new String[]{"openCrateButton","closeCrateButton","autoOpenButton","devToolsButton"})set(n,new JButton());
  for(String n:new String[]{"rarityLabel","nameLabel","priceLabel","floatLabel","conditionLabel","patternId","collectionLabel","lowFloatLabel","profitLabel"})set(n,new JLabel("old result"));
  Object cache=get("imageRepository");Method put=cache.getClass().getDeclaredMethod("put",String.class,Image.class);put.setAccessible(true);put.invoke(cache,"case-selector-"+((CaseType)get("currentCase")).id,new BufferedImage(280,180,2));
  set("skinImage",new BufferedImage(150,95,2));set("isAnimating",false);gui.floatRules.resetCrate();
  JButton open=(JButton)get("openCrateButton"),auto=(JButton)get("autoOpenButton");JLabel profit=(JLabel)get("profitLabel");
  check(get("skinImage")==null&&get("crateImage")!=null&&((JLabel)get("nameLabel")).getText().isEmpty()&&!((JLabel)get("lowFloatLabel")).isVisible(),"Closing/resetting returns to the case image and clears the old skin details");
  check(open.getX()+open.getWidth()/2==500&&profit.getX()+profit.getWidth()/2==500&&profit.getY()>open.getY()+open.getHeight()&&profit.getY()+profit.getHeight()<auto.getY(),"Open button, profit underneath, and auto-open button remain centered without overlap");
  check(open.getY()<150&&auto.getY()<192,"Both opening buttons were moved upward");
  Image container=(Image)get("crateImage");call("showLoadedCaseResultImage",new Class<?>[]{String.class,Image.class},(String)get("finalSkinName"),new BufferedImage(150,95,2));
  check(get("skinImage")==null&&get("crateImage")==container,"Late skin artwork cannot replace the restored case image after closing");
 }
 public static void main(String[] args)throws Exception{
  MarketRegressionTests.setup();gui=MarketRegressionTests.gui;
  SwingUtilities.invokeAndWait(()->{try{restocking();developer();charts();resetAndLayout();}catch(Exception e){throw new RuntimeException(e);}});
  ((java.util.prefs.Preferences)get("marketPricePreferences")).removeNode();System.out.println("All Dev Tools, chart and restocking tests passed.");
 }
}
