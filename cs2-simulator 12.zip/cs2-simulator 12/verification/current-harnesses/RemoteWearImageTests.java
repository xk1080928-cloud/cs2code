package blahblah;
import java.awt.*;
import java.awt.image.BufferedImage;
import java.io.*;
import java.lang.reflect.*;
import java.net.*;
import java.nio.file.*;
import java.util.*;
import java.util.List;
import java.util.concurrent.*;
import java.math.BigDecimal;
import javax.imageio.ImageIO;
import javax.swing.*;
@SuppressWarnings({"unchecked","rawtypes"})
public class RemoteWearImageTests {
 static final String SKIN="AWP | Dragon Lore",FN="Factory New",BS="Battle-Scarred",MW="Minimal Wear",WW="Well-Worn";
 static hGui gui;static Object repo;static ExecutorService executor;
 static Map<String,byte[]> responses=new ConcurrentHashMap<>();static Map<String,Integer> hits=new ConcurrentHashMap<>();
 static volatile String blocked;static CountDownLatch entered,release;
 static Path cache=Path.of("verification/remote-wear-test-cache");static BufferedImage fn,bs,base;static String fnUrl,bsUrl,standard;
 static int checks;
 static Object call(String n,Class<?>[] t,Object...a)throws Exception{return MarketRegressionTests.call(n,t,a);}
 static Object get(String n)throws Exception{return MarketRegressionTests.field(n).get(gui);}
 static void set(String n,Object v)throws Exception{MarketRegressionTests.field(n).set(gui,v);}
 static Object inner(String n,Class<?>[] t,Object...a)throws Exception{Method m=repo.getClass().getDeclaredMethod(n,t);m.setAccessible(true);return m.invoke(repo,a);}
 static void check(boolean b,String m){MarketRegressionTests.check(b,m);checks++;}
 interface Action{void run()throws Exception;}
 static void edt(Action a)throws Exception{SwingUtilities.invokeAndWait(()->{try{a.run();}catch(Exception e){throw new RuntimeException(e);}});}
 static void flush()throws Exception{edt(()->{});edt(()->{});}
 static String key(String n,String w)throws Exception{return (String)call("getSkinArtworkKey",new Class[]{String.class,String.class},n,w);}
 static String url(String n,String w)throws Exception{return (String)call("getWearImageUrl",new Class[]{String.class,String.class},n,w);}
 static Image image(String k)throws Exception{return (Image)inner("get",new Class[]{String.class},k);}
 static void put(String k,Image im)throws Exception{inner("put",new Class[]{String.class,Image.class},k,im);}
 static void remove(String k)throws Exception{Field f=repo.getClass().getDeclaredField("cache");f.setAccessible(true);synchronized(repo){((Map)f.get(repo)).remove(k);}}
 static void home(String n,String w)throws Exception{call("getHomeUnboxArtwork",new Class[]{String.class,String.class},n,w);}
 static void bind(String n,String w,JLabel l)throws Exception{call("getSkinImageFromName",new Class[]{String.class,String.class,JLabel.class,int.class,int.class},n,w,l,160,110);}
 static void await(String k)throws Exception{long end=System.nanoTime()+TimeUnit.SECONDS.toNanos(8);while(((Set)get("remoteImageLoads")).contains(k)&&System.nanoTime()<end)Thread.sleep(5);if(((Set)get("remoteImageLoads")).contains(k))throw new AssertionError("Timeout: "+k);flush();}
 static int count(String u){return hits.getOrDefault(u,0);}
 static Path disk(String u)throws Exception{return (Path)inner("getDiskCacheFile",new Class[]{String.class},u);}
 static boolean same(Image a,BufferedImage b){if(!(a instanceof BufferedImage))return false;BufferedImage x=(BufferedImage)a;return x.getWidth()==b.getWidth()&&x.getHeight()==b.getHeight()&&Arrays.equals(x.getRGB(0,0,x.getWidth(),x.getHeight(),null,0,x.getWidth()),b.getRGB(0,0,b.getWidth(),b.getHeight(),null,0,b.getWidth()));}
 static byte[] bytes(String f)throws Exception{return Files.readAllBytes(Path.of("verification/wear-source-fixtures/"+f+".png"));}
 static void setup()throws Exception{
  URL.setURLStreamHandlerFactory(protocol->!protocol.equals("https")?null:new URLStreamHandler(){protected URLConnection openConnection(URL url){return new URLConnection(url){public void connect(){}public InputStream getInputStream()throws IOException{
   String u=url.toString();hits.merge(u,1,Integer::sum);
   if(getConnectTimeout()!=4000||getReadTimeout()!=6000)throw new AssertionError("Missing network timeouts");
   if(u.equals(blocked)){entered.countDown();try{if(!release.await(8,TimeUnit.SECONDS))throw new IOException("Gate timeout");}catch(InterruptedException e){throw new IOException(e);}}
   byte[] data=responses.get(u);if(data==null)throw new FileNotFoundException("Mock 404: "+u);return new ByteArrayInputStream(data);
  }};}});
  MarketRegressionTests.setup();gui=MarketRegressionTests.gui;
  for(String n:new String[]{"pendingRemoteImageLabels","unavailableRemoteImageUrls"})set(n,new ConcurrentHashMap<>());
  for(String n:new String[]{"remoteImageLoads","remoteImageGameViewRequests"})set(n,ConcurrentHashMap.newKeySet());
  call("applyExternalSkinCatalog",new Class[]{String.class},Files.readString(Path.of("verification/current-skins.json")));
  Class<?> c=Class.forName("blahblah.ImageRepository");Constructor<?> ct=c.getDeclaredConstructor(hGui.class);ct.setAccessible(true);repo=ct.newInstance(gui);set("imageRepository",repo);
  Field dir=c.getDeclaredField("diskCacheDirectory");dir.setAccessible(true);dir.set(repo,cache);
  if(Files.exists(cache))try(var files=Files.walk(cache)){for(Path p:files.sorted(Comparator.reverseOrder()).collect(java.util.stream.Collectors.toList()))Files.delete(p);}
  executor=Executors.newFixedThreadPool(3,r->{Thread t=new Thread(r,"wear-test");t.setDaemon(true);return t;});set("remoteImageExecutor",executor);
  JPanel overlay=new JPanel();overlay.setVisible(true);set("startupLoadingOverlay",overlay);
  fn=ImageIO.read(new ByteArrayInputStream(bytes("fn")));bs=ImageIO.read(new ByteArrayInputStream(bytes("bs")));base=ImageIO.read(Path.of("verification/artwork-fixtures/AWP---Dragon-Lore.png").toFile());
  fnUrl=url(SKIN,FN);bsUrl=url(SKIN,BS);
  Object metadata=call("getArtworkMetadata",new Class[]{String.class},SKIN);Field im=metadata.getClass().getDeclaredField("imageUrl");im.setAccessible(true);standard=(String)im.get(metadata);
  responses.put(fnUrl,bytes("fn"));responses.put(bsUrl,bytes("bs"));responses.put(standard,Files.readAllBytes(Path.of("verification/artwork-fixtures/AWP---Dragon-Lore.png")));
 }
 static void mapping()throws Exception{
  check(fnUrl.endsWith("/awp/344/fn.png")&&bsUrl.endsWith("/awp/344/bs.png"),"Dragon Lore FN and BS route to different real online PNGs");
  String[] wear={FN,MW,"Field-Tested",WW,BS},abbr={"fn","mw","ft","ww","bs"};for(int i=0;i<wear.length;i++)check(url(SKIN,wear[i]).endsWith("/"+abbr[i]+".png"),"Online URL maps exterior "+wear[i]);
  check(key(SKIN,FN).equals(key("Souvenir ★ AWP | Dragon Lore",FN)),"Souvenir/star aliases share the same finish and wear cache key");
  check(key(SKIN,FN).equals(key("StatTrak™ AWP | Dragon Lore",FN)),"StatTrak aliases resolve genuine skin artwork rather than a local filename");
  check(url("Nova | Wurst Holle",FN)!=null,"Legacy ASCII names resolve accented catalog names without requiring their old local PNG");
  check(key("AK-47 | Redline",FN).equals(key("ak47 | redline",FN)),"Case and punctuation aliases canonicalize to the catalog name");
  check(!key(SKIN,FN).equals(key(SKIN,BS))&&!key(SKIN,FN).equals(key(SKIN,null)),"Standard, FN and BS images have separate memory-cache keys");
  check(url("Bayonet | Vanilla",FN)==null&&url(SKIN,"Normal")==null,"Vanilla/no-wear items never invent wear-specific render URLs");
  String p1=url("Bayonet | Doppler (Phase 1)",FN),p2=url("Bayonet | Doppler (Phase 2)",FN);
  check(p1.endsWith("bayonet/418/fn.png")&&p2.endsWith("bayonet/419/fn.png"),"Doppler phases retain their actual distinct paint indexes");
  check(url("Bayonet | Doppler",FN).equals(p1),"Unspecified Doppler consistently defaults to the catalog's Phase 1");
  check(url("Sport Gloves | Vice",BS).endsWith("sporty_gloves/10048/bs.png"),"Gloves resolve through their real glove weapon ID and paint index");
  check(!same(fn,bs),"Downloaded genuine Dragon Lore FN and BS fixtures are visually different pixel data");
 }
 static void downloading()throws Exception{
  long start=System.nanoTime();home(SKIN,FN);check((System.nanoTime()-start)<TimeUnit.MILLISECONDS.toNanos(250),"PNG decoding/downloading stays asynchronous instead of blocking the calling UI");await(key(SKIN,FN));
  check(same(image(key(SKIN,FN)),fn),"FN cache contains the genuine downloaded FN render unchanged");
  home(SKIN,BS);await(key(SKIN,BS));check(same(image(key(SKIN,BS)),bs),"BS cache contains its genuine BS render, not the FN image or a wear filter");
  check(count(fnUrl)==1&&count(bsUrl)==1,"Each exterior downloads once and repeated requests reuse its memory cache");home(SKIN,FN);home(SKIN,BS);check(count(fnUrl)==1&&count(bsUrl)==1,"Cached wear requests cause no additional HTTP requests");
  check(Files.exists(disk(fnUrl))&&Files.exists(disk(bsUrl))&&!disk(fnUrl).equals(disk(bsUrl)),"Wear URLs persist under distinct SHA-256 disk-cache filenames");
  remove(key(SKIN,FN));home(SKIN,FN);await(key(SKIN,FN));check(count(fnUrl)==1&&same(image(key(SKIN,FN)),fn),"A cold memory cache restores genuine PNGs from downloaded cache without network/local asset files");
  Files.writeString(disk(fnUrl),"corrupt cache");remove(key(SKIN,FN));home(SKIN,FN);await(key(SKIN,FN));check(count(fnUrl)==2&&same(image(key(SKIN,FN)),fn),"Corrupt downloaded caches self-repair from the online source");
  String missing=url(SKIN,MW);home(SKIN,MW);await(key(SKIN,MW));check(count(missing)==1&&same(image(key(SKIN,MW)),base),"A missing real wear render falls back to the actual standard online PNG");
  check(((Map)get("unavailableRemoteImageUrls")).containsKey(missing),"Missing render URLs are negatively cached for bounded retries");
  remove(key(SKIN,MW));home(SKIN,MW);await(key(SKIN,MW));check(count(missing)==1&&count(standard)==1&&same(image(key(SKIN,MW)),base),"Repeated unavailable wear requests suppress 404 retries and reuse the standard downloaded cache");
  ((Map)get("unavailableRemoteImageUrls")).put(missing,System.currentTimeMillis()-1);responses.put(missing,bytes("fn"));remove(key(SKIN,MW));home(SKIN,MW);await(key(SKIN,MW));check(count(missing)==2&&same(image(key(SKIN,MW)),fn),"Expired negative-cache entries retry the genuine wear source successfully");
  for(String[] v:new String[][]{{"Sport Gloves | Vice",FN,"vice-fn"},{"Sport Gloves | Vice",BS,"vice-bs"},{"Bayonet | Doppler (Phase 1)",FN,"doppler-p1-fn"},{"Bayonet | Doppler (Phase 2)",FN,"doppler-p2-fn"}}){String u=url(v[0],v[1]);responses.put(u,bytes(v[2]));home(v[0],v[1]);await(key(v[0],v[1]));check(same(image(key(v[0],v[1])),ImageIO.read(new ByteArrayInputStream(bytes(v[2])))),"Genuine PNG downloads work for "+v[0]+" / "+v[1]);}
 }
 static InventoryItem item(String wear,Image im){return new InventoryItem(new ImageIcon(im),SKIN,wear,"Covert",BigDecimal.TEN,wear.equals(FN)?.03:.65,false,42,null,10);}
 static void callbacks()throws Exception{
  InventoryItem f=item(FN,base),b=item(BS,base);List<InventoryItem> items=(List)get("inventoryList");items.clear();items.add(f);items.add(b);f.getThumb110();f.getThumb130();
  edt(()->call("showLoadedCaseResultImage",new Class[]{String.class,Image.class},key(SKIN,FN),image(key(SKIN,FN))));
  check(same(f.image.getImage(),fn)&&b.image.getImage()==base,"An FN completion updates FN items only, never other exteriors");
  check(f.thumb110x75==null&&f.thumb130x88==null,"Real-wear arrival invalidates both previously generated thumbnail sizes");
  edt(()->call("showLoadedCaseResultImage",new Class[]{String.class,Image.class},key(SKIN,BS),image(key(SKIN,BS))));
  check(same(b.image.getImage(),bs),"BS completion updates the matching inventory item");
  put(SKIN,base);edt(()->call("showLoadedCaseResultImage",new Class[]{String.class,Image.class},SKIN,base));check(same(f.image.getImage(),fn)&&same(b.image.getImage(),bs),"Late standard images cannot overwrite already-cached FN or BS artwork");
  check(same((Image)call("getInspectDisplayImage",new Class[]{InventoryItem.class},f),fn)&&same((Image)call("getInspectDisplayImage",new Class[]{InventoryItem.class},b),bs),"Inspect lookup selects each concrete item's exterior");
  JLabel label=new JLabel();edt(()->{bind(SKIN,FN,label);bind(SKIN,BS,label);});Icon wanted=label.getIcon();
  ((Map)get("pendingRemoteImageLabels")).put(key(SKIN,FN),new HashSet<>(List.of(label)));edt(()->call("updatePendingRemoteImageLabels",new Class[]{String.class,Image.class},key(SKIN,FN),fn));
  check(label.getIcon()==wanted,"A stale FN callback cannot overwrite a reused label now displaying BS");
  set("finalSkinName",SKIN);set("gunName",SKIN);set("finalCondition",FN);set("finalSkin",base);set("activeResultImageLabel",label);
  edt(()->call("showLoadedCaseResultImage",new Class[]{String.class,Image.class},key(SKIN,BS),bs));check(get("finalSkin")==base&&label.getIcon()==wanted,"A different exterior's completion cannot overwrite the current case reward");
  edt(()->call("showLoadedCaseResultImage",new Class[]{String.class,Image.class},key(SKIN,FN),fn));check(same((Image)get("finalSkin"),fn)&&label.getIcon()==wanted,"Case artwork updates without clobbering an unrelated globally active result label");
  JLabel waiting=new JLabel();set("remoteImageExecutor",null);remove(key(SKIN,FN));remove(key(SKIN,BS));
  edt(()->{bind(SKIN,FN,waiting);bind(SKIN,BS,waiting);});check(!((Map)get("pendingRemoteImageLabels")).containsKey(key(SKIN,FN))&&((Set)((Map)get("pendingRemoteImageLabels")).get(key(SKIN,BS))).contains(waiting),"Changing wear unregisters the old pending label instead of retaining stale listeners");
  put(key(SKIN,FN),fn);put(key(SKIN,BS),bs);set("remoteImageExecutor",executor);
 }
 static void isolationAndFailure()throws Exception{
  List<InventoryItem> items=(List)get("inventoryList");for(InventoryItem i:items)i.image=new ImageIcon(base);
  Map pool=(Map)get("armouryAnimationPoolCache");pool.put("sentinel",List.of());remove(key(SKIN,FN));home(SKIN,FN);await(key(SKIN,FN));
  check(items.stream().allMatch(i->i.image.getImage()==base)&&pool.containsKey("sentinel"),"Feed-only wear downloads do not scan/change inventory or invalidate unrelated animation pools");
  String n="Bayonet | Doppler (Phase 1)",k=key(n,FN);remove(k);Files.deleteIfExists(disk(url(n,FN)));blocked=url(n,FN);entered=new CountDownLatch(1);release=new CountDownLatch(1);home(n,FN);check(entered.await(5,TimeUnit.SECONDS),"Feed download can remain in flight while an ordinary UI asks for the same wear");
  JLabel promoted=new JLabel();edt(()->bind(n,FN,promoted));release.countDown();await(k);blocked=null;
  check(promoted.getIcon()!=null&&!pool.containsKey("sentinel"),"A regular UI request promotes an in-flight feed download and receives its artwork normally");
  JLabel failed=new JLabel();String ww=url(SKIN,WW);responses.remove(standard);Files.deleteIfExists(disk(standard));
  edt(()->bind(SKIN,WW,failed));await(key(SKIN,WW));check(image(key(SKIN,WW))==null&&count(ww)==1,"When both sources fail, no invented/simulated wear image is manufactured");
  check(failed.getToolTipText().contains("unavailable")&&!((Map)get("pendingRemoteImageLabels")).containsKey(key(SKIN,WW)),"Failed downloads report unavailable artwork and release pending label registrations");
 }
 static void sourceAudit()throws Exception{
  String s=Files.readString(Path.of("hGui.java"));String load=TradeUpProbabilityTests.segment(s,"public void loadSkinImages(","private void updateCrateImageDisplay(");
  check(!load.contains("new File(")&&!load.contains("ImageIO.read")&&!load.contains("new ImageIcon(\""),"Legacy skin initialization no longer opens bundled PNG files");
  String getter=TradeUpProbabilityTests.segment(s,"private Image getSkinImageFromName(String skinName)","private SkinMetadata findDopplerVariantMetadata(");check(getter.contains("getRemoteSkinArtwork")&&!getter.contains("SKIN_TO_FILE"),"Central image lookup is online-only, independent of legacy PNG filename mappings");
  String verifier=TradeUpProbabilityTests.segment(s,"private String buildSkinImageVerifierReport(","private void verifyTierOrder(");check(!verifier.contains(".exists()")&&verifier.contains("No bundled/local PNG files are required"),"Developer diagnostics no longer falsely require old local skin PNGs");
  check(s.contains("getSkinImageFromName(finalSkinName, finalCondition, activeResultImageLabel")&&s.contains("getSkinImageFromName(skinName, finalCondStr, activeResultImageLabel"),"Case and Armoury completion panels both bind asynchronously to their exact reward wear");
  check(s.contains("getSkinImageFromName(item.name, item.condition, inspectArtwork"),"Inspect windows always provide an asynchronous wear-aware image target");
  check(s.contains("getSkinImageFromName(equipped.name, equipped.condition, imgLbl"),"Equipped loadout cards request online images for their actual wear");
  check(!s.contains("RescaleOp")&&!s.contains("wearOverlay"),"No artificial wear overlay or pixel-darkening effect was introduced");
 }
 public static void main(String[] args)throws Exception{try{setup();mapping();downloading();callbacks();isolationAndFailure();sourceAudit();System.out.println("All "+checks+" real-wear remote image checks passed.");}finally{if(release!=null)release.countDown();if(executor!=null)executor.shutdownNow();if(gui!=null)((java.util.prefs.Preferences)get("marketPricePreferences")).removeNode();}System.exit(0);}
}
