package blahblah;
import java.lang.reflect.*;
import java.util.*;
import java.nio.file.*;
import java.math.BigDecimal;
import java.awt.*;
import java.awt.event.*;
import java.awt.image.BufferedImage;
import javax.swing.*;

@SuppressWarnings({"unchecked","rawtypes"})
public class GoldTradeUpTests {
 static hGui gui;
 static Object call(String n,Class<?>[] t,Object...a)throws Exception{return MarketRegressionTests.call(n,t,a);}
 static Object get(String n)throws Exception{Field f=MarketRegressionTests.field(n);return f.get(Modifier.isStatic(f.getModifiers())?null:gui);}
 static void set(String n,Object v)throws Exception{MarketRegressionTests.field(n).set(gui,v);}
 static void check(boolean b,String m){MarketRegressionTests.check(b,m);}
 static CaseType source(InventoryItem it)throws Exception{return (CaseType)call("getGoldTradeUpSource",new Class[]{InventoryItem.class},it);}
 static Map<String,Double> odds(java.util.List<InventoryItem> in)throws Exception{return (Map)call("getGoldTradeUpOdds",new Class[]{java.util.List.class},in);}
 static Map<String,Double> caseOdds(CaseType ct)throws Exception{return (Map)call("getCaseGoldOutcomeOdds",new Class[]{CaseType.class},ct);}
 static InventoryItem item(String name,String rarity,boolean st){return new InventoryItem(new ImageIcon(new BufferedImage(130,88,2)),name,"Field-Tested",st?"StatTrak "+rarity:rarity,BigDecimal.valueOf(20),.2,st,42,null,20);}
 static ArrayList<InventoryItem> batch(CaseType a,int n,CaseType b,int m,boolean st){ArrayList<InventoryItem> in=new ArrayList<>();for(int i=0;i<n+m;i++)in.add(item((i<n?a:b).regularDropNames.get("Covert").get(0),"Covert",st));return in;}
 static void seedPriceAndArt(String name)throws Exception{DevGeneratorTests.gui=gui;DevGeneratorTests.cached(name,1000);}
 static void validate(java.util.List<InventoryItem> in,boolean full)throws Exception{call("validateTradeUpInputs",new Class[]{java.util.List.class,boolean.class},in,full);}
 static boolean invalid(java.util.List<InventoryItem> in)throws Exception{try{validate(in,true);return false;}catch(Exception ex){return true;}}
 static Component find(Component c,String n){return DevGeneratorTests.find(c,n);}
 static void layout(Component c){DevGeneratorTests.layout(c);}
 static void run()throws Exception{
  call("registerBundledTerminals",new Class[0]);call("registerRequestedMarketCollections",new Class[0]);
  call("applyExternalSkinCatalog",new Class[]{String.class},Files.readString(Path.of("verification/current-skins.json")));
  call("applyExternalCrateCatalog",new Class[]{String.class},Files.readString(Path.of("crates.json")));
  CaseType chroma=CaseType.CHROMA,dead=null,gen=null;
  for(CaseType ct:CaseType.values()){if(ct.crateName.equals("Sealed Dead Hand Terminal"))dead=ct;if(ct.crateName.equals("Sealed Genesis Terminal"))gen=ct;}
  check(dead!=null&&gen!=null&&!chroma.rareDropNames.isEmpty(),"Chroma and both bundled terminal catalogs are available");
  System.out.println("POOLS: Chroma="+chroma.rareDropNames.size()+", Dead Hand="+dead.rareDropNames.size());
  ArrayList<InventoryItem> in=batch(chroma,3,dead,2,false);
  check(source(in.get(0))==chroma&&source(in.get(4))==dead,"Covert names resolve to the correct Chroma and Dead Hand source containers");
  check(source(item(gen.regularDropNames.get("Covert").get(0),"Covert",false))==null,"Genesis Coverts are excluded because that terminal has no gold pool");
  gen.rareDropNames.add(chroma.rareDropNames.get(0));gen.rareDropCategories.put(chroma.rareDropNames.get(0),"Knives");
  try{check(source(item(gen.regularDropNames.get("Covert").get(0),"Covert",false))==null,"Only Dead Hand is eligible among terminals, even if another terminal is accidentally assigned a rare pool");}
  finally{gen.rareDropNames.clear();gen.rareDropCategories.clear();}
  int eligibleCases=0;
  for(CaseType ct:CaseType.values())if(!ct.isSouvenir&&!ct.isTerminal&&!ct.rareDropNames.isEmpty()){
   for(String n:ct.regularDropNames.getOrDefault("Covert",java.util.Collections.emptyList()))if(source(item(n,"Covert",false))!=ct)throw new AssertionError("Wrong eligible case source: "+ct.name+" / "+n);
   eligibleCases++;
  }
  check(eligibleCases>30,"Verified Covert-to-source resolution works across all "+eligibleCases+" knife/glove cases, not just Chroma");
  check(source(item("AWP | Dragon Lore","Covert",false))==null&&source(item("AK-47 | B the Monster","Covert",false))==null,"Non-case collection and Armoury Coverts cannot enter gold contracts");
  check(source(item("Souvenir "+in.get(0).name,"Covert",false))==null&&source(item(in.get(0).name,"Classified",false))==null,"Souvenirs and non-Covert inputs are not gold eligible");
  Map<String,Double> o=odds(in);double knife=0,glove=0;
  for(Map.Entry<String,Double> e:o.entrySet())if(call("getGoldTradeUpOutputRarity",new Class[]{String.class},e.getKey()).equals("Gloves"))glove+=e.getValue();else knife+=e.getValue();
  check(Math.abs(knife-.6)<1e-12&&Math.abs(glove-.4)<1e-12,"Three Chroma plus two Dead Hand Coverts give EXACTLY 60% knives and 40% gloves despite different pool sizes");
  check(Math.abs(o.values().stream().mapToDouble(Double::doubleValue).sum()-1)<1e-12,"Combined exact outcome probabilities sum to 100%");
  String dop=chroma.rareDropNames.stream().filter(n->n.endsWith(" | Doppler")).findFirst().orElseThrow();
  double base=.6/5.0;
  check(Math.abs(o.get(dop+" (Phase 1)")-base*.095)<1e-14&&Math.abs(o.get(dop+" (Phase 4)")-base*.095)<1e-14,"Each individual Chroma Doppler phase uses the calculator weight, normalized within its source collection");
  check(Math.abs(o.get(dop+" (Sapphire)")-base*.01)<1e-14&&Math.abs(o.get(dop+" (Ruby)")-base*.01)<1e-14&&Math.abs(o.get(dop+" (Black Pearl)")-base*.0025)<1e-14,"Chroma Sapphire/Ruby/Black Pearl use source-normalized 0.01/0.01/0.0025 relative weights");
  check(!o.containsKey(dop),"The unexpanded Doppler base is not counted as an additional outcome");
  String normal=chroma.rareDropNames.stream().filter(n->!n.contains("Doppler")).findFirst().orElseThrow();
  check(Math.abs(o.get(normal)-base*.1195)<1e-14,"A non-Doppler Chroma knife receives its calculator 0.1195 relative weight");
  String gloveName=dead.rareDropNames.get(0);
  check(Math.abs(o.get(gloveName)-.4/dead.rareDropNames.size())<1e-14,"Every Dead Hand glove finish receives 40% divided by its verified glove pool size");
  Map<String,Double> gamma=(Map)call("getDopplerVariantOdds",new Class[]{String.class},"Bayonet | Gamma Doppler");
  check(gamma.size()==5&&Math.abs(gamma.get("Bayonet | Gamma Doppler (Emerald)")-.0135/.1675)<1e-12&&Math.abs(gamma.get("Bayonet | Gamma Doppler (Phase 2)")-.0385/.1675)<1e-12,"Gamma Doppler uses the calculator Emerald/phase weight ratio");
  Map<String,Double> same=odds(batch(chroma,3,chroma,2,false)),chromaOdds=caseOdds(chroma);
  check(same.keySet().equals(chromaOdds.keySet())&&same.entrySet().stream().allMatch(e->Math.abs(e.getValue()-chromaOdds.get(e.getKey()))<1e-14),"Repeated inputs from one case merge without duplicating or diluting individual odds");
  StringBuilder csv=new StringBuilder("Outcome,Probability,Percent\n");for(Map.Entry<String,Double> e:o.entrySet())csv.append('"').append(e.getKey()).append("\",").append(e.getValue()).append(',').append(e.getValue()*100).append('\n');Files.writeString(Path.of("verification/gold-example-odds.csv"),csv.toString());
  java.util.List<InventoryItem> inv=(java.util.List)get("inventoryList");inv.addAll(in);set("inventoryValue",100.0);
  validate(in,true);check(true,"Five eligible Covert inputs pass complete-contract validation");
  ArrayList<InventoryItem> bad=new ArrayList<>(in.subList(0,4));check(invalid(bad),"Four-Coverts contract cannot execute");
  bad=new ArrayList<>(in);bad.add(item(in.get(0).name,"Covert",false));inv.add(bad.get(5));check(invalid(bad),"Six-Coverts contract cannot execute");
  bad=new ArrayList<>(in);bad.set(4,in.get(0));check(invalid(bad),"Duplicate references cannot count as two consumed items");
  bad=new ArrayList<>(in);bad.set(4,item(in.get(0).name,"Covert",false));check(invalid(bad),"Items absent from inventory cannot be used in a contract");
  InventoryItem mixed=item(in.get(0).name,"Covert",true);inv.add(mixed);bad=new ArrayList<>(in);bad.set(4,mixed);check(invalid(bad),"StatTrak and normal inputs cannot be mixed");
  InventoryItem lower=item(in.get(0).name,"Classified",false);inv.add(lower);bad=new ArrayList<>(in);bad.set(4,lower);check(invalid(bad),"Mixed-rarity contracts are rejected");
  InventoryItem lore=item("AWP | Dragon Lore","Covert",false);inv.add(lore);bad=new ArrayList<>(in);bad.set(4,lore);check(invalid(bad),"An ineligible collection Covert invalidates the entire gold contract");
  check(inv.containsAll(in)&&(Double)get("inventoryValue")==100.0,"Rejected contracts do not consume items or change inventory value");
  Class<?> cls=Class.forName("blahblah.InventoryIdGenerator");Constructor<?> ctor=cls.getDeclaredConstructor();ctor.setAccessible(true);set("inventoryIdGenerator",ctor.newInstance());
  cls=Class.forName("blahblah.ImageRepository");ctor=cls.getDeclaredConstructor(hGui.class);ctor.setAccessible(true);set("imageRepository",ctor.newInstance(gui));
  for(String name:o.keySet())seedPriceAndArt(name);
  JPanel preview=(JPanel)call("buildTradeUpOutcomesPanel",new Class[]{ArrayList.class},in);
  String text=labels(preview);
  check(!text.contains("Chroma Case: 60.0%")&&!text.contains("Doppler:")&&!text.contains("Pattern premiums"),"The requested source-share and phase-explanation text block is removed from the outcomes preview");
  check(!text.contains("Chroma Collection")&&!text.contains("Chroma 2 Collection"),"Knife/glove outcome cards do not claim a collection; source weights stay internal");
  check(text.contains("0.120000% chance")&&text.contains("1.140000% chance")&&text.contains("1.818182% chance"),"The preview displays precise individual gem, Doppler phase and glove odds rather than rounding gems to 0.0%");
  preview.setSize(1000,760);layout(preview);BufferedImage outImage=new BufferedImage(1000,760,2);Graphics2D og=outImage.createGraphics();preview.printAll(og);og.dispose();javax.imageio.ImageIO.write(outImage,"png",Path.of("verification/gold-tradeup-outcomes-render.png").toFile());
  Set<String> rolled=new HashSet<>();int dopplerRolls=0,gemRolls=0;((Random)get("random")).setSeed(807123);
  for(int j=0;j<12000;j++){
   String r=(String)call("getRandomCaseGoldDrop",new Class[]{CaseType.class,String.class},chroma,"Knives");
   if(!chromaOdds.containsKey(r))throw new AssertionError("Unboxing/preview drift: "+r);
   rolled.add(r);if(r.contains("Doppler")){dopplerRolls++;if(!r.contains("Phase"))gemRolls++;}
  }
  check(gemRolls>0&&Math.abs(gemRolls/(double)dopplerRolls-.08)<.025,"Actual unboxing uses its separate 8% total gem split without changing gold contracts");
  check((Double)call("getGoldTradeUpOutputFloat",new Class[]{java.util.List.class,String.class},in,"Bayonet | Vanilla")==0.0,"Vanilla gold outcomes remain no-float Normal items");
  ArrayList<InventoryItem> standard=new ArrayList<>();String classified=chroma.regularDropNames.get("Classified").get(0);
  for(int j=0;j<10;j++)standard.add(item(classified,"Classified",false));inv.addAll(standard);
  for(String covert:chroma.regularDropNames.get("Covert"))seedPriceAndArt(covert);
  validate(standard,true);
  JPanel standardPreview=(JPanel)call("buildTradeUpOutcomesPanel",new Class[]{ArrayList.class},standard);
  check((Integer)call("getTradeUpRequiredCount",new Class[]{java.util.List.class},standard)==10&&!labels(standardPreview).contains("Doppler:"),"Standard ten-Classified contracts and their ordinary outcomes preview remain available");
  set("inventoryTabPanel",new JPanel());set("tradeUpTabPanel",new JPanel());set("lowestFloat",1.0);
  int gloves=0;Set<Integer> patterns=new HashSet<>();Set<String> ids=new HashSet<>();int trials=800;
  for(int i=0;i<trials;i++){
   inv.clear();ArrayList<InventoryItem> batch=batch(chroma,3,dead,2,false);inv.addAll(batch);set("inventoryValue",100.0);
   InventoryItem result=(InventoryItem)call("performGoldTradeUp",new Class[]{java.util.List.class},batch);
   if(inv.size()!=1||inv.get(0)!=result||inv.stream().anyMatch(batch::contains))throw new AssertionError("Atomic consume");
   String clean=result.name.replaceAll(" \\(Blue Gem [^)]+\\)$","");
   if(!o.containsKey(clean))throw new AssertionError("Foreign output: "+clean);
   double[] bounds=(double[])call("getMarketWearBounds",new Class[]{String.class},clean);
   if(!result.condition.equals(call("getConditionForFloat",new Class[]{String.class,double.class},clean,result.itemFloat))||result.itemFloat<bounds[0]||result.itemFloat>bounds[1])throw new AssertionError("Illegal output float");
   if(result.isStattrak||result.patternID<0||result.patternID>999||!"YOU".equals(result.currentOwner)||result.itemId==null||result.history.isEmpty()||result.collection!=null)throw new AssertionError("Reward metadata");
   if(Math.abs((Double)get("inventoryValue")-result.price.doubleValue())>.001)throw new AssertionError("Value update");
   if(result.rarity.equals("Gloves"))gloves++;
   patterns.add(result.patternID);ids.add(result.itemId);
  }
  check(Math.abs(gloves/(double)trials-.4)<.07,"Actual mixed-contract rolls follow the 60/40 source split (observed gloves: "+gloves+"/"+trials+")");
  check(true,"Every executed contract consumes exactly five items, adds exactly one legal gold, and updates inventory value once");
  check(patterns.size()>100&&ids.size()==trials,"Gold rewards have randomized legal patterns, unique tracking IDs, YOU ownership, no collection and gold-contract source history");
  check(true,"Gold reward floats and wear obey the output's actual skin bounds");
  check((Integer)get("totalCrates")==0,"Gold trade-ups do not increment case-opening counts");
  inv.clear();ArrayList<InventoryItem> st=batch(chroma,5,chroma,0,true);inv.addAll(st);set("inventoryValue",100.0);
  InventoryItem sr=(InventoryItem)call("performGoldTradeUp",new Class[]{java.util.List.class},st);
  check(sr.isStattrak&&sr.rarity.equals("StatTrak Knife"),"All-StatTrak Coverts produce a StatTrak knife");
  inv.clear();st=batch(dead,5,dead,0,true);inv.addAll(st);set("inventoryValue",100.0);
  sr=(InventoryItem)call("performGoldTradeUp",new Class[]{java.util.List.class},st);
  check(!sr.isStattrak&&sr.rarity.equals("Gloves"),"Gloves never acquire unsupported StatTrak status");
  inv.clear();in=batch(chroma,3,dead,2,false);inv.addAll(in);set("inventoryValue",100.0);set("goldTradeUpMode",true);
  JPanel panel=new JPanel(new BorderLayout());set("tradeUpTabPanel",panel);call("refreshTradeUpTab",new Class[0]);
  JComboBox mode=(JComboBox)find(panel,"tradeUpContractMode");check(mode==null,"Contract mode selector is removed; eligibility starts unrestricted");
  java.util.List<InventoryItem> selection=(java.util.List)get("tradeUpSelection");selection.addAll(in);
  javax.swing.Timer timer=(javax.swing.Timer)panel.getClientProperty("selTimer");for(ActionListener l:timer.getActionListeners())l.actionPerformed(new ActionEvent(timer,0,"tick"));
  JButton gold=findButton(panel,"GOLD TRADE UP (5)");check(gold!=null&&gold.isEnabled(),"Five gold selections enable the gold contract button");
  selection.clear();for(ActionListener l:timer.getActionListeners())l.actionPerformed(new ActionEvent(timer,0,"tick"));check(!gold.isEnabled()&&!(Boolean)get("goldTradeUpMode"),"Clearing the inferred gold contract disables stale execution");
  selection.addAll(in);for(ActionListener l:timer.getActionListeners())l.actionPerformed(new ActionEvent(timer,0,"tick"));
  JScrollPane sc=DevGeneratorTests.first(panel,JScrollPane.class);Object rebuild=((JPanel)sc.getViewport().getView()).getClientProperty("rebuildGrid");if(rebuild instanceof Runnable)((Runnable)rebuild).run();
  panel.setSize(1000,760);layout(panel);BufferedImage image=new BufferedImage(1000,760,2);Graphics2D g=image.createGraphics();panel.printAll(g);g.dispose();javax.imageio.ImageIO.write(image,"png",Path.of("verification/gold-tradeup-render.png").toFile());timer.stop();
 }
 static String labels(Component c){StringBuilder s=new StringBuilder();if(c instanceof JLabel)s.append(((JLabel)c).getText()).append('\n');if(c instanceof Container)for(Component ch:((Container)c).getComponents())s.append(labels(ch));return s.toString();}
 static JButton findButton(Component c,String text){if(c instanceof JButton&&((JButton)c).getText().equals(text))return (JButton)c;if(c instanceof Container)for(Component ch:((Container)c).getComponents()){JButton b=findButton(ch,text);if(b!=null)return b;}return null;}
 public static void main(String[] args)throws Exception{MarketRegressionTests.setup();gui=MarketRegressionTests.gui;SwingUtilities.invokeAndWait(()->{try{run();}catch(Exception ex){throw new RuntimeException(ex);}});((java.util.prefs.Preferences)get("marketPricePreferences")).removeNode();System.out.println("All gold trade-up tests passed.");}
}
