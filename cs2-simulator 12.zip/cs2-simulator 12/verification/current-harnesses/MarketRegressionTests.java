package blahblah;
import java.lang.reflect.*;
import java.util.*;
import java.util.prefs.Preferences;
import java.math.BigDecimal;
import java.awt.*;
import java.awt.image.BufferedImage;
import javax.swing.*;
import javax.imageio.ImageIO;
import java.io.File;
import sun.misc.Unsafe;

@SuppressWarnings({"unchecked","rawtypes"})
public class MarketRegressionTests {
    static hGui gui;
    static Field field(String n) throws Exception {Field f=SimulatorContext.class.getDeclaredField(n);f.setAccessible(true);return f;}
    static Object call(String name,Class<?>[] types,Object...args) throws Exception {
        Method m=ModularAccess.method(name,types);m.setAccessible(true);
        try{return m.invoke(ModularAccess.receiver(gui,m),args);}catch(InvocationTargetException e){throw new RuntimeException(name,e.getCause());}
    }
    static void check(boolean ok,String msg){if(!ok)throw new AssertionError(msg);System.out.println("PASS: "+msg);}
    static class HeadlessGui extends hGui {public void revalidate(){} public void repaint(){} }
    static void setup() throws Exception {
        Field uf=Unsafe.class.getDeclaredField("theUnsafe");uf.setAccessible(true);gui=(hGui)((Unsafe)uf.get(null)).allocateInstance(HeadlessGui.class); ModularAccess.initialize(gui);
        for(Field f:SimulatorContext.class.getDeclaredFields()) {
            if(Modifier.isStatic(f.getModifiers()))continue;f.setAccessible(true);
            if(Map.class.isAssignableFrom(f.getType()))f.set(gui,new HashMap<>());
            else if(Set.class.isAssignableFrom(f.getType()))f.set(gui,new HashSet<>());
            else if(Queue.class.isAssignableFrom(f.getType()) || f.getType()==LinkedList.class)f.set(gui,new LinkedList<>());
            else if(java.util.List.class.isAssignableFrom(f.getType()))f.set(gui,new ArrayList<>());
        }
        field("marketPricePreferences").set(gui,Preferences.userRoot().node("arena-market-regression-test"));
    }
    static void cap(String name,double min,double max) throws Exception {
        Class<?> c=Class.forName("blahblah.FloatRange");Constructor<?> ctor=c.getDeclaredConstructor(Double.class,Double.class);ctor.setAccessible(true);
        ((Map)field("FLOAT_LIMITS").get(null)).put(name,ctor.newInstance(min,max));
        ((Map)field("availableConditionsCache").get(gui)).remove(name);
        ((Map)field("rarityCache").get(gui)).put(name,"Milspec");
        ((Map)field("liveBasePrices").get(gui)).put(name,100.0);
    }
    static MarketListing listing(String name,String condition,boolean st,boolean player,double price,double fl) {
        InventoryItem it=new InventoryItem(null,name,condition,st?"StatTrak Milspec":"Milspec",BigDecimal.valueOf(price),fl,st,1,null,price);
        return new MarketListing(it,price,100,player);
    }
    static Map<String,Integer> counts(ArrayList<MarketListing> listings){Map<String,Integer> counts=new LinkedHashMap<>();for(MarketListing l:listings)if(!l.isPlayerListing)counts.merge(l.item.condition,1,Integer::sum);return counts;}
    static void supply() throws Exception {
        String name="AK-47 | Regression Full Range";cap(name,0,1);
        Map<String,ArrayList<MarketListing>> market=(Map)field("globalMarketListings").get(gui);
        ArrayList<MarketListing> regular=new ArrayList<>(),st=new ArrayList<>();
        for(int i=0;i<1000;i++)regular.add(listing(name,"Battle-Scarred",false,false,1,0.8));
        for(int i=0;i<800;i++)regular.add(listing(name,"Well-Worn",false,false,2,0.4));
        for(int i=0;i<600;i++)st.add(listing(name,"Battle-Scarred",true,false,1,0.8));
        for(String wear:new String[]{"Factory New","Minimal Wear","Field-Tested","Well-Worn"})st.add(listing(name,wear,true,false,5,0.8));
        MarketListing player=listing(name,"Factory New",false,true,987.65,0.03);regular.add(player);
        market.put(name,regular);market.put("StatTrak "+name,st);
        call("ensureMinimumListings",new Class<?>[0]);
        Map<String,Integer> normalCounts=counts(regular),statCounts=counts(st);
        System.out.println("Repaired normal: "+normalCounts+"; StatTrak: "+statCounts);
        check(normalCounts.size()==5 && statCounts.size()==5,"Repair restores all five conditions for normal and StatTrak despite high total stock");
        check(normalCounts.values().stream().allMatch(n->n>=8)&&statCounts.values().stream().allMatch(n->n>=2),"Every wear receives multiple listings, not one token listing");
        check(regular.contains(player)&&player.listPrice==987.65&&player.item.itemFloat==0.03,"Player listings, ask price and float are preserved");
        for(MarketListing l:regular)checkFloat(l,0,1);
        for(MarketListing l:st)checkFloat(l,0,1);
        check(true,"All repaired/generated floats agree with both the skin cap and listing condition");
        call("trimMarketListingsForResponsiveUi",new Class<?>[0]);
        check(counts(regular).size()==5&&counts(st).size()==5,"Trimming preserves every wear instead of keeping only cheapest Battle-Scarred");
        regular.removeIf(l->!l.isPlayerListing&&l.item.condition.equals("Factory New"));
        call("replenishThinMarketListings",new Class<?>[0]);
        check(counts(regular).getOrDefault("Factory New",0)>=8,"A depleted wear is replenished while other conditions still have deep stock");
        for(String key:new String[]{name,"StatTrak "+name})check(counts(market.get(key)).values().stream().mapToInt(i->i).sum()<=1440,"NPC stock remains bounded: "+key);
        String capped="AK-47 | Regression Capped";cap(capped,0.10,0.42);market.put(capped,new ArrayList<>());
        call("ensureMinimumListings",new Class<?>[0]);
        check(counts(market.get(capped)).keySet().equals(new LinkedHashSet<>(Arrays.asList("Minimal Wear","Field-Tested","Well-Worn"))),"Capped skin generates only the three possible wears");
        for(MarketListing l:market.get(capped))checkFloat(l,0.10,0.42);
        String emerald="SCAR-20 | Regression Emerald";cap(emerald,0,1);
        check(!(Boolean)call("isDopplerGemSkin",new Class<?>[]{String.class},emerald),"An Emerald-named gun is not misclassified as a two-wear Doppler gem");
        cap(emerald,0.1,0.5);
        call("applyExternalSkinCatalog",new Class<?>[]{String.class},"[{\"name\":\""+emerald+"\",\"min_float\":0,\"max_float\":1,\"category\":{\"name\":\"Rifles\"},\"rarity\":{\"name\":\"Mil-Spec Grade\"}}]");
        double[] bounds=(double[])call("getMarketWearBounds",new Class<?>[]{String.class},emerald);
        check(bounds[0]==0&&bounds[1]==1,"Catalog's authoritative 0–1 cap replaces an outdated gun cap");
    }
    static void checkFloat(MarketListing l,double min,double max) throws Exception {
        if(l.isPlayerListing)return;
        if(l.item.itemFloat<min||l.item.itemFloat>max||!l.item.condition.equals(call("getConditionForFloat",new Class<?>[]{String.class,double.class},l.item.name,l.item.itemFloat)))throw new AssertionError("Invalid float: "+l.item.condition+" "+l.item.itemFloat);
    }
    static void prices() throws Exception {
        String name="Karambit | Vanilla";
        check(call("getPublicFeedSkinName",new Class<?>[]{String.class,String.class},name,null).equals("Karambit"),"Vanilla knife uses canonical CSFloat name without '| Vanilla'");
        Map<String,String> snapshots=(Map)field("publicPriceSnapshots").get(gui);
        snapshots.put("csfloat","{\"★ Karambit\":{\"price\":1523.45},\"★ StatTrak™ Karambit\":{\"price\":1400.00}}");
        ((Map)field("publicPriceSnapshotTimes").get(gui)).put("csfloat",System.currentTimeMillis());
        ((Map)field("publicPriceSnapshotIndexes").get(gui)).clear();
        Object quote=call("fetchPublicFeedBasePrice",new Class<?>[]{String.class},name);
        Field base=quote.getClass().getDeclaredField("basePrice");base.setAccessible(true);
        Field cond=quote.getClass().getDeclaredField("conditionMultipliers");cond.setAccessible(true);
        check(Math.abs((double)base.get(quote)-1523.45)<0.0001,"CSFloat fixture resolves the correct vanilla price, without a wear suffix");
        check(((Map)cond.get(quote)).equals(Map.of("Normal",1.0)),"Normal vanilla quote is not divided by a wear multiplier");
        Field statPrice=quote.getClass().getDeclaredField("vanillaStatTrakPrice");statPrice.setAccessible(true);
        check((Double)statPrice.get(quote)==1400.0,"StatTrak vanilla resolves its own canonical CSFloat quote");
        Preferences prefs=(Preferences)field("marketPricePreferences").get(gui);prefs.putDouble("p."+name,5);
        check(call("loadCachedMarketBasePrice",new Class<?>[]{String.class},name)==null,"Old broken vanilla cache is ignored automatically");
        Map<String,ArrayList<MarketListing>> market=(Map)field("globalMarketListings").get(gui);market.clear();
        MarketListing old=listing(name,"Normal",false,false,5,0),player=listing(name,"Normal",false,true,2222,0);
        market.put(name,new ArrayList<>(Arrays.asList(old,player)));
        ((Map)field("basePriceCache").get(gui)).put(name,1600.0);
        call("updateBasePriceFromMarket",new Class<?>[]{String.class,quote.getClass()},name,quote);
        check(old.listPrice>1400&&old.listPrice<1700&&old.item.condition.equals("Normal")&&old.item.itemFloat==0,"Previously mispriced saved vanilla stock rebases directly to the feed quote");
        check(player.listPrice==2222,"Feed updates do not change a player's listed ask");
        double statBase=(Double)call("getVanillaVariantBasePrice",new Class<?>[]{String.class,boolean.class,double.class},name,true,1523.45);
        check(statBase==1400.0,"StatTrak vanilla valuation uses the actual quote rather than a generic multiplier");
        MarketListing statNew=(MarketListing)call("createNpcWearListing",new Class<?>[]{String.class,String.class,boolean.class,double.class,String.class},name,"Normal",true,1523.45,"Knife");
        check(statNew.listPrice>=1400*.90*.975&&statNew.listPrice<=1400*1.10*1.05&&statNew.item.itemFloat==0,"New StatTrak vanilla stock is priced around its dedicated quote, including existing marketplace premiums");
        call("ensureMinimumListings",new Class<?>[0]);
        check(counts(market.get(name)).keySet().equals(Set.of("Normal")),"Vanilla supply stays Normal-only with no artificial wear states");
        for(MarketListing l:market.get(name))if(l.item.itemFloat!=0)throw new AssertionError("Vanilla float");
        prefs.removeNode();
    }
    static void bars() throws Exception {
        String full="AK-47 | Regression Full Range",capped="AK-47 | Regression Capped";
        JPanel bar=(JPanel)call("createWearRangePanel",new Class<?>[]{String.class},full);
        double[] range=(double[])bar.getClientProperty("wearRangeBounds");
        check(range[0]==0&&range[1]==1,"Wear bar exposes the actual full 0–1 range");
        JPanel narrow=(JPanel)call("createWearRangePanel",new Class<?>[]{String.class},capped);
        double[] caps=(double[])narrow.getClientProperty("wearRangeBounds");check(caps[0]==.10&&caps[1]==.42,"Wear bar uses the skin's own caps, not its available listings");
        JPanel vanilla=(JPanel)call("createWearRangePanel",new Class<?>[]{String.class},"Karambit | Vanilla");check(vanilla.getClientProperty("wearRangeBounds")==null,"Vanilla has an explicit no-float state, not a fake 0–1 bar");
        BufferedImage image=new BufferedImage(400,480,BufferedImage.TYPE_INT_RGB);Graphics2D g=image.createGraphics();g.setColor(new Color(39,45,57));g.fillRect(0,0,400,480);
        int y=10;for(JPanel p:new JPanel[]{bar,narrow,vanilla}){p.setSize(366,p.getPreferredSize().height);Graphics2D sub=(Graphics2D)g.create(17,y,366,p.getHeight());p.paint(sub);sub.dispose();y+=p.getHeight()+14;}g.dispose();ImageIO.write(image,"png",new File("verification/wear-range-render.png"));
        check(true,"Full-range, capped and no-float components render headlessly");
    }
    static void fullCatalog() throws Exception {
        String json=java.nio.file.Files.readString(java.nio.file.Paths.get("skins.json"));
        call("applyExternalSkinCatalog",new Class<?>[]{String.class},json);
        Set<String> names=new HashSet<>(((Map<String,Object>)field("skinCatalog").get(gui)).keySet());
        int conditions=0;
        for(String name:names) {
            if((Boolean)call("hasNoFloatWear",new Class<?>[]{String.class},name))continue;
            double[] bounds=(double[])call("getMarketWearBounds",new Class<?>[]{String.class},name);
            Map<String,Integer> targets=(Map)call("getMarketSupplyTargets",new Class<?>[]{String.class,boolean.class},name,false);
            for(Map.Entry<String,Integer> target:targets.entrySet()) {
                if(target.getValue()<1)throw new AssertionError("Empty condition: "+name);
                for(int i=0;i<10;i++) {
                    double fl=(Double)call("generateFloatForCondition",new Class<?>[]{String.class,String.class},name,target.getKey());
                    if(fl<bounds[0]||fl>bounds[1]||!target.getKey().equals(call("getConditionForFloat",new Class<?>[]{String.class,double.class},name,fl)))throw new AssertionError("Bad catalog float: "+name+" "+target.getKey()+" "+fl+" caps="+Arrays.toString(bounds));
                }
                conditions++;
            }
        }
        check(names.size()>2000,"Supply policy and sampled floats validated across "+names.size()+" catalog variants / "+conditions+" valid wear conditions");
        java.nio.file.Path fixture=java.nio.file.Paths.get("verification/vanilla-live-feed-fixture.json");
        if(java.nio.file.Files.exists(fixture)) {
            ((Map)field("publicPriceSnapshots").get(gui)).put("csfloat",java.nio.file.Files.readString(fixture));
            ((Map)field("publicPriceSnapshotIndexes").get(gui)).clear();
            for(String name:new String[]{"Karambit | Vanilla","Bayonet | Vanilla","Butterfly Knife | Vanilla"}) {
                Object quote=call("fetchPublicFeedBasePrice",new Class<?>[]{String.class},name);
                check(quote!=null,"Canonical lookup also resolves the downloaded real feed entry: "+name);
            }
        }
    }
    public static void main(String[] args)throws Exception {setup();SwingUtilities.invokeAndWait(()->{try{supply();prices();bars();fullCatalog();}catch(Exception e){throw new RuntimeException(e);}});System.out.println("All market regression tests passed.");}
}
