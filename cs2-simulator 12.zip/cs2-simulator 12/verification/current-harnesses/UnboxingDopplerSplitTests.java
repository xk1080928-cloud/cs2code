package blahblah;
import java.util.*;
import java.nio.file.*;

@SuppressWarnings({"unchecked","rawtypes"})
public class UnboxingDopplerSplitTests {
 static Object call(String n,Class<?>[] t,Object...a)throws Exception{return MarketRegressionTests.call(n,t,a);}
 static void check(boolean b,String s){MarketRegressionTests.check(b,s);}
 static boolean near(double a,double b){return Math.abs(a-b)<1e-12;}
 static Map<String,Double> variants(String n)throws Exception{return (Map)call("getUnboxingDopplerVariantOdds",new Class[]{String.class},n);}
 static Map<String,Double> gold(CaseType c)throws Exception{return (Map)call("getCaseGoldOutcomeOdds",new Class[]{CaseType.class},c);}
 static Map<String,Double> unbox(CaseType c)throws Exception{return (Map)call("getCaseUnboxingGoldOutcomeOdds",new Class[]{CaseType.class,String.class},c,null);}
 static double share(Map<String,Double> m,String base){return m.entrySet().stream().filter(e->e.getKey().equals(base)||e.getKey().startsWith(base+" (")).mapToDouble(Map.Entry::getValue).sum();}
 public static void main(String[] args)throws Exception{
  MarketRegressionTests.setup();
  call("registerBundledTerminals",new Class[0]);call("registerRequestedMarketCollections",new Class[0]);
  call("applyExternalSkinCatalog",new Class[]{String.class},Files.readString(Path.of("verification/current-skins.json")));
  call("applyExternalCrateCatalog",new Class[]{String.class},Files.readString(Path.of("crates.json")));
  String d="Bayonet | Doppler",g="Butterfly Knife | Gamma Doppler";Map<String,Double> dv=variants(d),gv=variants(g);
  check(near(dv.get(d+" (Ruby)"),.035)&&near(dv.get(d+" (Sapphire)"),.035)&&near(dv.get(d+" (Black Pearl)"),.01),"Unboxing regular Doppler is exactly 3.5% Ruby, 3.5% Sapphire and 1% Black Pearl");
  check(java.util.stream.IntStream.rangeClosed(1,4).allMatch(i->near(dv.get(d+" (Phase "+i+")"),.23)),"Unboxing regular Doppler is exactly 23% per phase (92% combined)");
  check(near(gv.get(g+" (Emerald)"),.08)&&java.util.stream.IntStream.rangeClosed(1,4).allMatch(i->near(gv.get(g+" (Phase "+i+")"),.23)),"Unboxing Gamma Doppler is exactly 8% Emerald and 23% per phase");
  check(near(dv.values().stream().mapToDouble(Double::doubleValue).sum(),1)&&near(gv.values().stream().mapToDouble(Double::doubleValue).sum(),1),"Both unboxing-only conditional distributions sum to 100%");
  check(variants(d+" (Ruby)").size()==1&&variants("Bayonet | Fade").get("Bayonet | Fade")==1&&variants(null).isEmpty(),"Resolved phases/gems, ordinary finishes and null inputs are handled without rerolling");
  int cases=0;
  for(CaseType ct:CaseType.values())if(!ct.isSouvenir&&!ct.rareDropNames.isEmpty()){
   Map<String,Double> a=gold(ct),b=unbox(ct);
   if(!near(b.values().stream().mapToDouble(Double::doubleValue).sum(),1))throw new AssertionError("Normalization: "+ct.name);
   for(String base:ct.rareDropNames){
    double p=share(b,base);if(!near(p,share(a,base)))throw new AssertionError("Base finish changed: "+base);
    if(base.endsWith(" | Doppler")||base.endsWith(" | Gamma Doppler"))for(Map.Entry<String,Double> e:variants(base).entrySet())
     if(!near(b.get(e.getKey())/p,e.getValue()))throw new AssertionError("Conditional split: "+e.getKey());
   }
   cases++;
  }
  check(cases>30,"Every verified rare pool stays normalized and every base-finish probability is preserved across "+cases+" containers");
  check(true,"All Doppler generations and case families receive the same requested unboxing-only conditional splits");
  CaseType chroma=CalculatorMatchingTests.crate("Chroma 3 Case"),dreams=CalculatorMatchingTests.crate("Dreams & Nightmares Case");
  Map<String,Double> cg=gold(chroma),dg=gold(dreams);
  check(near(cg.get("Bayonet | Tiger Tooth"),.0239)&&near(cg.get(d+" (Phase 1)"),.019)&&near(cg.get(d+" (Ruby)"),.002)&&near(cg.get(d+" (Black Pearl)"),.0005),"Gold trade-ups still match Chroma calculator odds exactly: 2.39% / 1.90% / 0.20% / 0.05%");
  check(near(dg.get(g+" (Emerald)"),.0027)&&near(dg.get(g+" (Phase 1)"),.0077)&&near(dg.get("Butterfly Knife | Lore"),.0333),"Gold trade-ups still match Dreams calculator odds exactly: 0.27% / 0.77% / 3.33%");
  Map<String,Integer> counts=new HashMap<>();int total=0;Random r=(Random)MarketRegressionTests.field("random").get(null);r.setSeed(781923);
  for(int i=0;i<12000;i++){
   String skin=(String)call("getRandomCaseGoldDrop",new Class[]{CaseType.class,String.class},dreams,"Knives");
   if(skin.contains("Gamma Doppler")){total++;counts.merge(skin.contains("Emerald")?"Emerald":"Phases",1,Integer::sum);}
  }
  check(total>500&&Math.abs(counts.getOrDefault("Emerald",0)/(double)total-.08)<.025,"Actual Dreams unboxing rolls use 8% Emerald conditional on a Gamma Doppler");
  if(!Files.exists(Path.of("verification/before-unboxing-only-doppler-split.java.txt"))){System.out.println("SKIP: historical monolithic source-only comparison; current runtime math checked above");return;}
  String old=Files.readString(Path.of("verification/before-unboxing-only-doppler-split.java.txt")),now=Files.readString(Path.of("hGui.java"));
  check(TradeUpProbabilityTests.segment(old,"private Map<String, Double> getCaseGoldOutcomeOdds(","private boolean isTradeUpEligibleForMode").equals(TradeUpProbabilityTests.segment(now,"private Map<String, Double> getCaseGoldOutcomeOdds(","private boolean isTradeUpEligibleForMode")),"Gold case/contract probability resolvers are byte-for-byte unchanged");
  check(TradeUpProbabilityTests.segment(old,"private double getGoldTradeUpOutputFloat(","private String getGoldTradeUpOutputRarity").equals(TradeUpProbabilityTests.segment(now,"private double getGoldTradeUpOutputFloat(","private String getGoldTradeUpOutputRarity")),"Gold output-float formula is byte-for-byte unchanged");
  check(TradeUpProbabilityTests.segment(old,"private InventoryItem performGoldTradeUp(","private final ArrayList<InventoryItem> tradeUpSelection").strip().replace("result.collection = collection;", "result.collection = null;").replace("getSkinImageFromName(name)", "getSkinImageFromName(name, wear)").equals(TradeUpProbabilityTests.segment(now,"private InventoryItem performGoldTradeUp(","private static final int INVENTORY_PAGE_SIZE").strip()),"Gold reward generation and output-float logic are unchanged apart from removing collection metadata and selecting artwork by wear");
  ((java.util.prefs.Preferences)MarketRegressionTests.field("marketPricePreferences").get(MarketRegressionTests.gui)).removeNode();
  System.out.println("All unboxing-only Doppler split tests passed.");
 }
}
