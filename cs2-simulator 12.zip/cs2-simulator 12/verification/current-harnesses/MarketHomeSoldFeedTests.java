package blahblah;
import java.awt.*;
import java.awt.event.*;
import java.lang.reflect.*;
import java.nio.file.*;
import java.util.*;
import java.util.List;
import javax.swing.*;
@SuppressWarnings({"unchecked","rawtypes"})
public class MarketHomeSoldFeedTests {
 static hGui gui;static JPanel feed,root;static int checks;
 static List<String> keys;static Map<String,ArrayList<MarketListing>> market;
 static MarketListing awp,knife,glove;
 static Object call(String n,Class<?>[]t,Object...a)throws Exception{return MarketRegressionTests.call(n,t,a);}
 static Object field(String n)throws Exception{return MarketRegressionTests.field(n).get(gui);}
 static Object get(Object o,String n)throws Exception{return MarketHomeFeedTests.get(o,n);}
 static Object invoke(String n,Class<?>[] t,Object...a)throws Exception{return MarketHomeFeedTests.innerCall(feed,n,t,a);}
 static void set(Object o,String n,Object v)throws Exception{MarketHomeFeedTests.set(o,n,v);}
 static void edt(MarketHomeFeedTests.Throwing a)throws Exception{MarketHomeFeedTests.edt(a);}
 static void flush()throws Exception{MarketHomeFeedTests.flush();}
 static void check(boolean b,String m){MarketRegressionTests.check(b,m);checks++;}
 static List<Object> entries()throws Exception{return (List)get(feed,"entries");}
 static javax.swing.Timer timer()throws Exception{return (javax.swing.Timer)get(feed,"feedTimer");}
 static SaleRecord record(Object e)throws Exception{return (SaleRecord)get(e,"record");}
 static Object roll(List<String> pool,boolean art)throws Exception{return call("rollHomeMarketSale",new Class[]{List.class,boolean.class},pool,art);}
 static void ready()throws Exception{set(feed,"lastSoldInsertedAt",System.nanoTime()-300000000L);}
 static void setup()throws Exception{
  MarketHomeFeedTests.setup();gui=MarketHomeFeedTests.gui;
  market=(Map)field("globalMarketListings");market.clear();
  awp=MarketRegressionTests.listing("AWP | Dragon Lore","Battle-Scarred",false,false,200,.65);
  knife=MarketRegressionTests.listing("Bayonet | Doppler (Ruby)","Factory New",true,false,2000,.03);
  glove=MarketRegressionTests.listing("Sport Gloves | Vice","Field-Tested",false,false,900,.25);
  ArrayList<MarketListing> large=new ArrayList<>();for(int i=0;i<200;i++)large.add(awp);
  market.put(awp.item.name,large);market.put("StatTrak "+knife.item.name,new ArrayList<>(List.of(knife)));market.put(glove.item.name,new ArrayList<>(List.of(glove)));market.put("Empty bucket",new ArrayList<>());
  keys=(List)call("snapshotHomeMarketSkinKeys",new Class[0]);
  for(String[] p:new String[][]{{awp.item.name,awp.item.condition,"bs"},{"AWP | Dragon Lore","Factory New","fn"}}){String k=(String)call("getSkinArtworkKey",new Class[]{String.class,String.class},p[0],p[1]);TradeUpPresentationTests.putArt(k,javax.imageio.ImageIO.read(Path.of("verification/wear-source-fixtures/"+p[2]+".png").toFile()));}
  Class<?> c=Class.forName("blahblah.MarketHomeUnboxFeed");Constructor<?> ctor=c.getDeclaredConstructor(hGui.class,boolean.class);ctor.setAccessible(true);
  edt(()->{feed=(JPanel)ctor.newInstance(gui,true);root=new JPanel(new BorderLayout());root.add(feed);root.setSize(1000,504);DevGeneratorTests.layout(root);});
 }
 static void delaysAndSource()throws Exception{
  boolean bounded=true;Set<Integer> delays=new HashSet<>();long sum=0;
  for(int i=0;i<20000;i++){int d=(Integer)call("nextHomeSoldDelay",new Class[0]);bounded&=d>=30&&d<=150;delays.add(d);sum+=d;}
  check(bounded,"Twenty thousand sold-feed delays stay inside 0.03–0.15 seconds");
  check(delays.size()==121&&Math.abs(sum/20000.0-90)<3,"Sold timing genuinely varies over its full range, with an approximately 90 ms mean");
  check(keys.size()==3&&!keys.contains("Empty bucket"),"Sampling snapshots only current nonempty market skin buckets");
  edt(()->{
   Map<String,Integer> counts=new HashMap<>();boolean valid=true;
   for(int i=0;i<3000;i++){Object entry=roll(keys,false);SaleRecord r=record(entry);String name=r.skinName;counts.merge(name,1,Integer::sum);
    MarketListing match=name.contains("Bayonet")?knife:name.contains("Gloves")?glove:awp;
    valid&=r.price==match.getPrice()&&r.itemFloat==match.item.itemFloat&&r.condition.equals(match.item.condition)&&r.marketplaceName.equals(match.marketplaceName);
   }
   check(valid,"Simulated sold entries copy the selected listing's actual market price, float, condition and marketplace");
   check(counts.size()==3&&counts.values().stream().allMatch(n->n>0)&&counts.values().stream().mapToInt(Integer::intValue).sum()==3000,"Weighted sampling considers distinct skin buckets without multiplying a bucket by its backing-lot count");
   check(((List)field("recentSales")).isEmpty()&&((List)field("recentUnboxedSkins")).isEmpty()&&((List)field("inventoryList")).isEmpty(),"Random feed sampling does not record sales/unboxes or create inventory");
   check(market.get(awp.item.name).size()==200&&market.get(glove.item.name).get(0)==glove,"Simulated sold entries never remove or alter the market listings they sample");
   Object ruby=roll(List.of("StatTrak "+knife.item.name),false);SaleRecord r=record(ruby);
   check(r.skinName.equals("StatTrak "+knife.item.name)&&r.specialVariant.equals("Ruby")&&get(ruby,"imageKey").equals(call("getSkinArtworkKey",new Class[]{String.class,String.class},knife.item.name,knife.item.condition)),"StatTrak, Doppler variant and genuine-wear artwork keys survive market sampling");
   check(roll(List.of(),false)==null&&roll(List.of("removed bucket"),false)==null,"Empty and removed market buckets produce no invented item or exception");
  });
  String s=Files.readString(Path.of("hGui.java"));String home=TradeUpProbabilityTests.segment(s,"private void createMarketplaceHomeContent(","private JLabel createMarketplaceHomeSectionLabel");
  check(home.contains("createMarketplaceHomeSectionLabel(\"Recently Sold Skins\")")&&home.contains("createMarketplaceHomeSectionLabel(\"Recently Unboxed Skins\")")&&!home.contains("LIVE"),"Requested plain Home headings and sold-feed placement remain intact");
  check(!s.contains("publishHomeSale(")&&!s.contains("activeHomeSoldFeeds"),"The Home sold feed is completely disconnected from actual sale callbacks");
  check(feed.getToolTipText().contains("Simulated")&&feed.getToolTipText().contains("0.03"),"The feed describes its simulated source and minimum-delay behavior");
 }
 static void pacing()throws Exception{
  edt(()->{
   check(!timer().isRunning()&&entries().isEmpty(),"A hidden sold feed starts stopped and empty");root.addNotify();DevGeneratorTests.layout(root);
   check(timer().isRunning()&&!timer().isRepeats()&&timer().isCoalesce()&&get(feed,"worker")==null,"Visible sold activity uses one coalesced one-shot timer, not a queue of pending actual sales");
   invoke("requestNext",new Class[0]);timer().stop();check(entries().size()==1,"A tick samples exactly one random market item");
   long first=(Long)get(feed,"lastSoldInsertedAt");
   for(int i=0;i<100;i++)invoke("requestNext",new Class[0]);timer().stop();
   check(entries().size()==1&&(Long)get(feed,"lastSoldInsertedAt")==first,"Even 100 back-to-back tick callbacks cannot insert a burst of rows");
   Object incoming=roll(keys,false);for(int i=0;i<20;i++)invoke("acceptEntry",new Class[]{incoming.getClass()},incoming);
   check(entries().size()==1,"The insertion boundary itself enforces the minimum gap even if called directly");
   int count=entries().size();for(int i=0;i<200;i++)call("recordMarketListingSale",new Class[]{MarketListing.class,String.class,Image.class},awp,"Real Buyer",null);
   check(entries().size()==count,"A burst of 200 real sales cannot add or queue any Home sold-feed entries");
   check(!((List)field("recentSales")).isEmpty(),"Actual sales still record normally in their existing histories");
   ready();invoke("requestNext",new Class[0]);timer().stop();check(entries().size()==2,"Once the minimum gap has elapsed, the next tick adds exactly one row");
   root.setVisible(false);
  });
  int old=entries().size();Thread.sleep(800);flush();check(entries().size()==old,"Hidden time creates no simulated sales or pending catch-up events");
  List<Long> stamps=new ArrayList<>();edt(()->root.setVisible(true));
  long end=System.nanoTime()+4500000000L;while(stamps.size()<5&&System.nanoTime()<end){edt(()->{long at=(Long)get(feed,"lastSoldInsertedAt");if(stamps.isEmpty()||stamps.get(stamps.size()-1)!=at)stamps.add(at);});Thread.sleep(10);}
  edt(()->{root.setVisible(false);});
  boolean spaced=stamps.size()>=5;for(int i=1;i<stamps.size();i++)spaced&=stamps.get(i)-stamps.get(i-1)>=30000000L;
  check(spaced,"Live timer arrivals maintain at least a 30 ms gap between every observed pair");
  edt(()->{
   Object top=entries().get(0);root.setVisible(true);check(entries().get(0)==top&&timer().getInitialDelay()>=30,"Returning Home retains the chain and waits a fresh delay rather than replaying missed arrivals");
   timer().stop();
   int history=((List)field("recentSales")).size();Object e=roll(List.of(awp.item.name),true);
   for(int i=0;i<2200;i++){ready();invoke("acceptEntry",new Class[]{e.getClass()},e);}
   ((javax.swing.Timer)get(feed,"animationTimer")).stop();check(entries().size()==7&&feed.getComponentCount()==0,"Long-running simulated sales retain six visible rows plus one transition row, without Swing-card buildup");
   check(((List)field("recentSales")).size()==history&&((List)field("recentUnboxedSkins")).isEmpty(),"Long-running feed entries do not pollute real sales, unbox histories or market charts");
   set(feed,"insertedAt",System.nanoTime()-200000000L);TradeUpPresentationTests.render(feed,"market-home-paced-sold-feed-render.png",1000,504);
   root.removeNotify();check(!timer().isRunning()&&!((javax.swing.Timer)get(feed,"animationTimer")).isRunning(),"Disposing Home immediately stops both arrival and animation timers");
  });
 }
 static void navigationAndArtwork()throws Exception{
  final JPanel[] view=new JPanel[1];edt(()->{view[0]=(JPanel)call("createMarketplaceBrowserPanel",new Class[0]);root=new JPanel(new BorderLayout());root.add(view[0]);root.setSize(1100,1400);});flush();
  edt(()->{
   JPanel browser=view[0];root.addNotify();DevGeneratorTests.layout(root);feed=(JPanel)DevGeneratorTests.find(browser,"marketHomeSoldFeed");
   check(feed!=null&&feed.isShowing()&&timer().isRunning(),"The real marketplace Home starts the paced simulated sold feed");
   invoke("requestNext",new Class[0]);timer().stop();Object top=entries().get(0);JButton home=(JButton)DevGeneratorTests.find(browser,"marketplaceHomeButton");for(int i=0;i<100;i++)home.doClick(0);
   check(entries().size()==1&&entries().get(0)==top&&DevGeneratorTests.find(browser,"marketHomeSoldFeed")==feed,"Spamming Home neither rebuilds the chain nor adds simulated sales");
   JComboBox search=DevGeneratorTests.first(browser,JComboBox.class);JTextField editor=(JTextField)search.getEditor().getEditorComponent();editor.setText("zz_no_matching_skin_zz");editor.postActionEvent();
   check(!feed.isShowing()&&!timer().isRunning(),"Marketplace search pauses the sold clock even while the Market tab remains open");
   home.doClick(0);check(DevGeneratorTests.find(browser,"marketHomeSoldFeed")==feed&&entries().get(0)==top&&timer().isRunning(),"Returning from search resumes the same chain without immediate extra rows");timer().stop();
   javax.swing.Timer stats=(javax.swing.Timer)browser.getClientProperty("browserRefreshTimer");for(ActionListener a:stats.getActionListeners())a.actionPerformed(new ActionEvent(browser,0,"test"));
   check(DevGeneratorTests.find(browser,"marketHomeSoldFeed")==feed&&entries().size()==1,"Market-stat refreshes do not reset or inject the sold chain");
   ((javax.swing.Timer)get(feed,"animationTimer")).stop();RepaintManager previous=RepaintManager.currentManager(feed);
   class Tracker extends RepaintManager{int count;public void addDirtyRegion(JComponent c,int x,int y,int w,int h){if(c==feed)count++;}}
   Tracker tracker=new Tracker();RepaintManager.setCurrentManager(tracker);
   try{
    call("repaintHomeFeedsForArtwork",new Class[]{String.class},"unrelated-image");check(tracker.count==0,"Unrelated PNG completions do not repaint sold rows");
    call("repaintHomeFeedsForArtwork",new Class[]{String.class},get(top,"imageKey"));check(tracker.count==1,"A matching late PNG completion still updates its visible sold artwork");
    root.setVisible(false);tracker.count=0;call("repaintHomeFeedsForArtwork",new Class[]{String.class},get(top,"imageKey"));check(tracker.count==0&&((Set)field("activeHomeArtworkFeeds")).isEmpty(),"Hidden Home stops image-completion repaints as well as sale arrivals");
   }finally{RepaintManager.setCurrentManager(previous);stats.stop();root.removeNotify();}
  });
 }
 public static void main(String[]a)throws Exception{try{setup();delaysAndSource();pacing();navigationAndArtwork();System.out.println("All "+checks+" paced simulated-sold checks passed.");}finally{if(root!=null)edt(()->{root.setVisible(false);root.removeAll();});if(gui!=null)((java.util.prefs.Preferences)field("marketPricePreferences")).removeNode();}System.exit(0);}
}
