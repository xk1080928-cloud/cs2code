package blahblah;
import java.lang.reflect.*;
import java.util.*;
import java.nio.file.*;
import java.math.BigDecimal;
import javax.swing.*;
import sun.misc.Unsafe;

@SuppressWarnings({"unchecked", "rawtypes"})
public class RegressionTests {
    static hGui gui;
    static Field field(String n) throws Exception { Field f=SimulatorContext.class.getDeclaredField(n); f.setAccessible(true); return f; }
    static Object call(String name, Class<?>[] types, Object... args) throws Exception {
        Method m=ModularAccess.method(name,types);m.setAccessible(true);
        try{return m.invoke(ModularAccess.receiver(gui,m),args);}catch(InvocationTargetException e){throw new RuntimeException(name,e.getCause());}
    }
    static void check(boolean ok,String msg){ if(!ok)throw new AssertionError(msg);System.out.println("PASS: "+msg); }
    static InventoryItem item(String name,String wear,boolean st) {
        return new InventoryItem(null,name,wear,"Classified",BigDecimal.valueOf(100),0.04,st,1,null,100);
    }
    public static void main(String[] args) throws Exception {
        Field uf=Unsafe.class.getDeclaredField("theUnsafe");uf.setAccessible(true);
        gui=(hGui)((Unsafe)uf.get(null)).allocateInstance(hGui.class); ModularAccess.initialize(gui);
        for(Field f:SimulatorContext.class.getDeclaredFields()) {
            if(Modifier.isStatic(f.getModifiers()))continue;f.setAccessible(true);
            if(Map.class.isAssignableFrom(f.getType()))f.set(gui,new HashMap<>());
            else if(Set.class.isAssignableFrom(f.getType()))f.set(gui,new HashSet<>());
            else if(Queue.class.isAssignableFrom(f.getType()) || f.getType()==LinkedList.class)f.set(gui,new LinkedList<>());
            else if(List.class.isAssignableFrom(f.getType()))f.set(gui,new ArrayList<>());
        }
        call("registerBundledTerminals",new Class<?>[0]);
        Map<String,CaseType> cases=new HashMap<>();
        for(CaseType ct:CaseType.values())cases.put(ct.crateName,ct);
        CaseType genesis=cases.get("Sealed Genesis Terminal"),dead=cases.get("Sealed Dead Hand Terminal");
        check(genesis!=null && dead!=null,"Both terminals available without a live catalog");
        check(genesis.isTerminal && genesis.rareDropNames.isEmpty(),"Genesis has no invented rare drops");
        check(dead.isTerminal && dead.rareDropNames.size()==22 && dead.rareDropCategory.equals("Gloves"),"Dead Hand includes all 22 glove drops");
        for(CaseType ct:new CaseType[]{genesis,dead}) {
            check(ct.regularDropNames.values().stream().mapToInt(List::size).sum()==17,ct.name+" has all 17 weapon skins");
            check((Boolean)call("hasVerifiedCasePools",new Class<?>[]{CaseType.class},ct),ct.name+" is openable");
            TradeUpCollection col=(TradeUpCollection)call("buildCatalogCaseCollection",new Class<?>[]{CaseType.class},ct);
            check(col!=null && col.covertSkins.length==2,ct.name+" collection/trade-up registration");
        }
        for(int i=0;i<100000;i++) {
            Object roll=CaseRollService.crateItem(genesis);
            Field rarity=roll.getClass().getDeclaredField("rarityName");rarity.setAccessible(true);
            checkNoGold(String.valueOf(rarity.get(roll)));
        }
        System.out.println("PASS: 100,000 Genesis rolls never select gold");
        call("applyExternalCrateCatalog",new Class<?>[]{String.class},Files.readString(Paths.get("crates.json")));
        Comparator<CaseType> comparator=(Comparator<CaseType>)call("defaultContainerOrder",new Class<?>[0]);
        check(comparator.compare(CaseType.CHROMA,CaseType.CHROMA_2)<0 && comparator.compare(CaseType.CHROMA_2,CaseType.CHROMA_3)<0,"Chroma, Chroma 2, Chroma 3 chronological ordering");
        List<CaseType> souvenirs=new ArrayList<>();
        for(CaseType ct:CaseType.values())if(ct.isSouvenir)souvenirs.add(ct);
        souvenirs.sort(comparator);
        String previous="";int date=0;boolean mapOrder=true;
        for(CaseType ct:souvenirs) {
            if(previous.equals(ct.mapName)){if(date>ct.releaseOrder)mapOrder=false;}
            else if(previous.compareToIgnoreCase(ct.mapName)>0)mapOrder=false;
            previous=ct.mapName;date=ct.releaseOrder;
        }
        check(mapOrder && souvenirs.size()>100,"Souvenirs grouped by map, then oldest to newest");
        SwingUtilities.invokeAndWait(()-> {try {salesTests();viewTests();}catch(Exception e){throw new RuntimeException(e);}});
        System.out.println("All regression tests passed.");
    }
    static void checkNoGold(String rarity) {if(rarity.equals("Knife")||rarity.equals("Gloves"))throw new AssertionError("Genesis gold");}
    static void salesTests() throws Exception {
        Map<String,ArrayList<MarketListing>> market=(Map)field("globalMarketListings").get(gui);
        String[] names={"AK-47 | Wild Lotus","AK-47 | Hydroponic","AUG | Akihabara Accept","M249 | Bock Blocks"};
        for(String name:names) {
            ArrayList<MarketListing> listings=new ArrayList<>();
            for(String condition:new String[]{"Factory New","Minimal Wear"})for(int i=0;i<4;i++)
                listings.add(new MarketListing(item(name,condition,false),100+i,100,false));
            listings.add(new MarketListing(item(name,"Factory New",false),1,100,true));
            market.put(name,listings);
        }
        call("refillFairSalesQueue",new Class<?>[0]);
        call("generateFairCoverageSales",new Class<?>[]{int.class,boolean.class},100,true);
        Map<String,Map<String,ArrayList<SaleRecord>>> history=(Map)field("salesHistory").get(gui);
        for(String name:names) {
            check(history.containsKey(name) && history.get(name).size()==2,name+" gets sales in every available condition");
            check(market.get(name).size()==7 && market.get(name).stream().anyMatch(l->l.isPlayerListing),name+" sales remove real NPC listings, not player items");
        }
        call("generateFairCoverageSales",new Class<?>[]{int.class,boolean.class},100,false);
        for(String name:names)check(history.get(name).values().stream().mapToInt(List::size).sum()==3,name+" continues receiving sales on next sweep");
    }
    static void viewTests() throws Exception {
        ArrayList<InventoryItem> inventory=(ArrayList)field("inventoryList").get(gui);
        InventoryItem it=item("AK-47 | Cartel","Factory New",false);inventory.add(it);
        ArrayList<InventoryItem> selected=(ArrayList)field("tradeUpSelection").get(gui);selected.add(it);
        JPanel inv=new JPanel(),trade=new JPanel();field("inventoryTabPanel").set(gui,inv);field("tradeUpTabPanel").set(gui,trade);
        JLabel marker=new JLabel("active card");inv.add(marker);trade.add(new JLabel("selected card"));
        inv.putClientProperty("inventorySnapshot",new ArrayList<>(inventory));trade.putClientProperty("inventorySnapshot",new ArrayList<>(inventory));
        JLabel price=new JLabel();price.putClientProperty("inventoryPriceItem",it);inv.add(price);
        call("refreshInventoryTab",new Class<?>[0]);call("refreshTradeUpTab",new Class<?>[0]);
        check(inv.getComponent(0)==marker && trade.getComponentCount()==1,"Price/tab refresh leaves existing inventory and trade-up components intact");
        check(selected.size()==1 && selected.get(0)==it,"Trade-up selection survives refresh");
        check(price.getText().equals("$100"),"Visible price labels update in place");
        JComboBox<String> filter=new JComboBox<>(new String[]{"All","Covert"});filter.setSelectedIndex(1);inv.add(filter);
        JTextField text=new JTextField("Wild Lotus");inv.add(text);
        List<Object> saved=(List)call("captureViewControls",new Class<?>[]{JPanel.class},inv);
        filter.setSelectedIndex(0);text.setText("");call("restoreViewControls",new Class<?>[]{JPanel.class,List.class},inv,saved);
        check(filter.getSelectedItem().equals("Covert") && text.getText().equals("Wild Lotus"),"Filters and search survive structural rebuild state capture");
        Class<?> repoClass=Class.forName("blahblah.ImageRepository");
        Constructor<?> ctor=repoClass.getDeclaredConstructor(hGui.class);ctor.setAccessible(true);
        Object repo=ctor.newInstance(gui);field("imageRepository").set(gui,repo);
        Method put=repoClass.getDeclaredMethod("put",String.class,java.awt.Image.class);put.setAccessible(true);
        String longSkin="Souvenir M4A4 | 龍王 (Dragon King)",longKnife="Butterfly Knife | Gamma Doppler (Emerald)",longer="StatTrak M9 Bayonet | Doppler (Black Pearl)";
        for(String name:new String[]{longSkin.replace("Souvenir ",""),longKnife,longer})
            put.invoke(repo,name,new java.awt.image.BufferedImage(150,95,2));
        CaseType.registerCatalogCase("Layout Test",Map.of("Covert",List.of(longSkin)),List.of(longKnife,longer),Map.of(longKnife,"Knives",longer,"Knives"),null);
        CaseType test=null;for(CaseType ct:CaseType.values())if(ct.crateName.equals("Layout Test"))test=ct;
        // Suppress expansion into extra test-only Doppler phases.
        test.rareDropNames.clear();test.regularDropNames.put("Classified",List.of(longKnife,longer));
        JPanel preview=(JPanel)call("createContainerContentsPanel",new Class<?>[]{CaseType.class},test);
        preview.setSize(1140,720);
        for(java.awt.event.ComponentListener l:preview.getComponentListeners())l.componentResized(new java.awt.event.ComponentEvent(preview,java.awt.event.ComponentEvent.COMPONENT_RESIZED));
        JScrollPane scroll=(JScrollPane)preview.getComponent(0);
        JPanel grid=(JPanel)scroll.getViewport().getView();grid.setSize(1100,500);grid.doLayout();
        for(java.awt.Component c:grid.getComponents()) {
            JPanel card=(JPanel)c;card.doLayout();
            JLabel name=(JLabel)((java.awt.BorderLayout)card.getLayout()).getLayoutComponent(java.awt.BorderLayout.SOUTH);
            javax.swing.text.View html=(javax.swing.text.View)name.getClientProperty("html");
            java.awt.Insets padding=name.getInsets();
            System.out.println("Layout span="+html.getPreferredSpan(javax.swing.text.View.X_AXIS)+"x"+html.getPreferredSpan(javax.swing.text.View.Y_AXIS)+" label="+name.getSize()+" padding="+padding);
            check(html.getPreferredSpan(javax.swing.text.View.X_AXIS)<=name.getWidth()-padding.left-padding.right && html.getPreferredSpan(javax.swing.text.View.Y_AXIS)<=name.getHeight()-padding.top-padding.bottom,"Full long name fits its widened card: "+name.getToolTipText());
        }
    }
}
