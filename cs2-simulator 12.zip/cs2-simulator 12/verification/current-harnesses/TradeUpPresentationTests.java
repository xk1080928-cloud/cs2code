package blahblah;
import java.lang.reflect.*;
import java.util.*;
import java.nio.file.*;
import java.math.BigDecimal;
import java.awt.*;
import java.awt.event.*;
import java.awt.image.BufferedImage;
import java.util.concurrent.atomic.AtomicInteger;
import javax.swing.*;
import javax.imageio.ImageIO;
@SuppressWarnings({"unchecked","rawtypes"})
public class TradeUpPresentationTests {
 static hGui gui;
 static Object call(String n,Class<?>[] t,Object...a)throws Exception{return MarketRegressionTests.call(n,t,a);}
 static Object get(String n)throws Exception{Field f=MarketRegressionTests.field(n);return f.get(Modifier.isStatic(f.getModifiers())?null:gui);}
 static void set(String n,Object v)throws Exception{MarketRegressionTests.field(n).set(gui,v);}
 static void check(boolean b,String m){MarketRegressionTests.check(b,m);}
 static Component find(Component c,String n){return DevGeneratorTests.find(c,n);}
 static void render(JPanel p,String file,int w,int h)throws Exception{p.setSize(w,h);DevGeneratorTests.layout(p);BufferedImage image=new BufferedImage(w,h,2);Graphics2D g=image.createGraphics();p.printAll(g);g.dispose();ImageIO.write(image,"png",Path.of("verification/"+file).toFile());}
 static void putArt(String n,Image image)throws Exception{Object repo=get("imageRepository");Method m=repo.getClass().getDeclaredMethod("put",String.class,Image.class);m.setAccessible(true);m.invoke(repo,n,image);}
 static java.util.List<JLabel> art(Component c){java.util.List<JLabel> a=new ArrayList<>();if(c instanceof JLabel&&"tradeUpSkinArtwork".equals(c.getName()))a.add((JLabel)c);if(c instanceof Container)for(Component ch:((Container)c).getComponents())a.addAll(art(ch));return a;}
 static String actualPopupHtml(JComponent badge)throws Exception{for(MouseListener listener:badge.getMouseListeners())for(Field f:listener.getClass().getDeclaredFields())if(JPopupMenu.class.isAssignableFrom(f.getType())){f.setAccessible(true);return GoldTradeUpTests.labels((JPopupMenu)f.get(listener)).trim();}throw new AssertionError("No shared hover popup");}
 static JPanel reward(InventoryItem item,Runnable close)throws Exception{return (JPanel)call("buildTradeUpResultPanel",new Class[]{InventoryItem.class,Runnable.class},item,close);}
 static void run()throws Exception{
  call("registerBundledTerminals",new Class[0]);call("registerRequestedMarketCollections",new Class[0]);
  call("applyExternalSkinCatalog",new Class[]{String.class},Files.readString(Path.of("verification/current-skins.json")));
  call("applyExternalCrateCatalog",new Class[]{String.class},Files.readString(Path.of("crates.json")));
  Class<?> cls=Class.forName("blahblah.ImageRepository");Constructor<?> ctor=cls.getDeclaredConstructor(hGui.class);ctor.setAccessible(true);set("imageRepository",ctor.newInstance(gui));DevGeneratorTests.gui=gui;
  CaseType chroma=CaseType.CHROMA;Map<String,Double> odds=(Map)call("getCaseGoldOutcomeOdds",new Class[]{CaseType.class},chroma);
  for(String n:odds.keySet())DevGeneratorTests.cached(n,1000);
  for(String n:new String[]{"AWP | Dragon Lore","AK-47 | Head Shot","M4A4 | Temukau"})DevGeneratorTests.cached(n,1000);
  String index=Files.readString(Path.of("verification/artwork-fixtures/index.json"));java.util.regex.Matcher pairs=java.util.regex.Pattern.compile("\\\"([^\\\"]+)\\\": \\\"([^\\\"]+)\\\"").matcher(index);
  int loaded=0;while(pairs.find()){putArt(pairs.group(1),ImageIO.read(Path.of(pairs.group(2)).toFile()));loaded++;}
  check(loaded>=10,"Real skin PNG fixtures load for outcome and reward rendering");
  java.util.List<InventoryItem> inventory=(java.util.List)get("inventoryList");ArrayList<InventoryItem> inputs=GoldTradeUpTests.batch(chroma,5,chroma,0,false);inventory.addAll(inputs);
  JPanel panel=(JPanel)call("buildTradeUpOutcomesPanel",new Class[]{ArrayList.class},inputs);JPanel grid=(JPanel)find(panel,"tradeUpOutcomesGrid");
  check(grid!=null&&grid.getLayout() instanceof GridLayout&&((GridLayout)grid.getLayout()).getColumns()==5,"Trade-up outcome layout uses five columns instead of three");
  check(grid.getComponentCount()==60&&art(panel).size()==60,"All 60 Chroma outcomes have their own image label, including every Doppler phase and gem");
  check(art(panel).stream().allMatch(l->l.getIcon()!=null&&l.getIcon().getIconWidth()>0&&l.getIcon().getIconWidth()<=214&&l.getIcon().getIconHeight()<=140),"Every outcome has artwork or a placeholder scaled within its card without stretching");
  Set<Object> names=new HashSet<>();for(JLabel l:art(panel))names.add(l.getClientProperty("tradeUpSkinName"));
  check(names.contains("Bayonet | Doppler (Ruby)")&&names.contains("Bayonet | Doppler (Black Pearl)")&&names.size()==60,"Artwork lookup preserves exact Doppler phase/gem identities");
  String text=GoldTradeUpTests.labels(panel);check(text.contains("2.390000% chance")&&text.contains("1.900000% chance")&&text.contains("0.200000% chance")&&!text.contains("Pattern premiums"),"Outcome odds and the requested clean header remain unchanged while adding artwork");
  Dimension wide=(Dimension)call("getTradeUpOutcomesWindowSize",new Class[]{Rectangle.class},new Rectangle(0,0,1920,1080));
  check(wide.width==1420&&wide.height==860,"The outcome window opens substantially wider at 1420 × 860 on a large screen");
  Dimension small=(Dimension)call("getTradeUpOutcomesWindowSize",new Class[]{Rectangle.class},new Rectangle(0,0,1024,768));
  check(small.width<=1024&&small.height<=768,"Window size is clamped to usable screen dimensions on smaller displays");
  JScrollPane sc=DevGeneratorTests.first(panel,JScrollPane.class);check(sc.getHorizontalScrollBarPolicy()==ScrollPaneConstants.HORIZONTAL_SCROLLBAR_AS_NEEDED,"Narrow displays can scroll horizontally without discarding the five-column layout");
  render(panel,"tradeup-five-column-artwork-render.png",1420,860);
  inventory.clear();ArrayList<InventoryItem> standard=TradeUpProbabilityTests.batch(1,9);inventory.addAll(standard);
  JPanel standardPanel=(JPanel)call("buildTradeUpOutcomesPanel",new Class[]{ArrayList.class},standard);
  check(art(standardPanel).size()==3&&GoldTradeUpTests.labels(standardPanel).contains("10.0% chance")&&GoldTradeUpTests.labels(standardPanel).split("45.0% chance",-1).length==3,"Regular contracts also display skin PNGs and retain the correct 10%/45%/45% odds");
  render(standardPanel,"tradeup-standard-artwork-render.png",1420,740);
  InventoryItem skin=GoldTradeUpTests.item("AWP | Dragon Lore","Covert",false);skin.itemFloat=.012345;skin.patternID=661;skin.condition="Factory New";skin.price=BigDecimal.valueOf(12500);skin.collection="The Cobblestone Collection";
  JLabel originalCaseImage=new JLabel("Unchanged case image");set("activeResultImageLabel",originalCaseImage);set("finalSkinName","Unrelated previous case skin");set("gunName","");
  AtomicInteger closed=new AtomicInteger();JPanel result=reward(skin,closed::incrementAndGet);java.util.List<JLabel> rewardArt=art(result);
  check(rewardArt.size()==1&&rewardArt.get(0).getIcon()!=null&&rewardArt.get(0).getIcon().getIconWidth()<=540&&rewardArt.get(0).getIcon().getIconHeight()<=285,"Completion panel displays large correctly scaled skin artwork");
  check(GoldTradeUpTests.labels(result).contains("AWP | Dragon Lore")&&!GoldTradeUpTests.labels(result).contains("$12500.00")&&!GoldTradeUpTests.labels(result).contains("Factory New")&&!GoldTradeUpTests.labels(result).contains("Hover for skin details"),"Completion panel shows the awarded skin without redundant condition, price or hover instruction text (updated user requirement)");
  JComponent badge=(JComponent)find(result,"tradeUpResultInfo");String expected=(String)call("buildItemInfoHtml",new Class[]{String.class,String.class,double.class,int.class,String.class,boolean.class},skin.rarity,skin.condition,skin.itemFloat,skin.patternID,skin.collection,false);
  check(badge!=null&&actualPopupHtml(badge).equals(expected),"The info circle uses the identical hover-popup builder and exact stats as an unboxing result");
  check(expected.contains("Rarity:")&&expected.contains("Wear:")&&expected.contains("0.012345")&&expected.contains("661")&&expected.contains("Cobblestone"),"Hover details include rarity, wear, float, pattern ID and collection");
  check(badge.getPreferredSize().equals(new Dimension(28,28))&&badge instanceof JLabel&&((JLabel)badge).getText().equals("i"),"Completion panel reuses the same painted circular i badge as unboxing");
  int before=inventory.size();double beforeValue=(Double)get("inventoryValue");((JButton)find(result,"tradeUpResultClose")).doClick();
  check(closed.get()==1&&inventory.size()==before&&(Double)get("inventoryValue")==beforeValue,"Closing a reward panel only dismisses it; it cannot consume inputs or create another reward");
  check(get("activeResultImageLabel")==originalCaseImage,"Trade-up reward presentation does not replace the active unboxing image target");
  render(result,"tradeup-result-dragon-lore-render.png",680,560);
  InventoryItem knife=GoldTradeUpTests.item("Bayonet | Doppler (Ruby)","Knife",true);knife.condition="Factory New";knife.itemFloat=.018888;knife.patternID=999;knife.price=BigDecimal.valueOf(4300.25);knife.collection="Chroma Collection";
  JPanel gold=reward(knife,()->{});JComponent goldBadge=(JComponent)find(gold,"tradeUpResultInfo");String goldPopup=actualPopupHtml(goldBadge);
  check(GoldTradeUpTests.labels(gold).contains("NEW ITEM")&&GoldTradeUpTests.labels(gold).contains("StatTrak™ Bayonet | Doppler (Ruby)")&&goldPopup.contains("StatTrak Knife")&&goldPopup.contains("999"),"Gold rewards show the exact gem name and StatTrak status, including matching hover stats");
  render(gold,"tradeup-result-ruby-render.png",680,560);
  InventoryItem vanilla=GoldTradeUpTests.item("Bayonet | Vanilla","Knife",false);vanilla.condition="Normal";vanilla.itemFloat=0;vanilla.collection="Weapon Case One";DevGeneratorTests.cached(vanilla.name,500);
  JPanel plain=reward(vanilla,()->{});String plainInfo=actualPopupHtml((JComponent)find(plain,"tradeUpResultInfo"));
  check(plainInfo.contains("Normal")&&!plainInfo.contains("<b>Float:</b>")&&plainInfo.contains("Pattern ID:"),"Vanilla reward hover behaves just like unboxing: Normal wear, no artificial float field");
  String blue="Bayonet | Case Hardened (Blue Gem Tier 1)";DevGeneratorTests.cached("Bayonet | Case Hardened",2000);JLabel blueArt=(JLabel)call("createTradeUpSkinArtwork",new Class[]{String.class,Image.class,int.class,int.class},blue,null,480,285);
  check(blueArt.getClientProperty("tradeUpSkinName").equals("Bayonet | Case Hardened")&&blueArt.getIcon()!=null,"Blue Gem suffixes are stripped for PNG lookup without losing the awarded item's display name");
  String delayed="AWP | Tradeup Artwork Fixture";call("applyExternalSkinCatalog",new Class[]{String.class},"[{\"name\":\""+delayed+"\",\"image\":\"https://example.com/fixture.png\",\"min_float\":0,\"max_float\":1,\"category\":{\"name\":\"Sniper Rifles\"},\"rarity\":{\"name\":\"Covert\"}}]");
  ((Set)get("remoteImageLoads")).add(delayed);
  JLabel pending=(JLabel)call("createTradeUpSkinArtwork",new Class[]{String.class,Image.class,int.class,int.class},delayed,null,214,140);
  check(((Map)get("pendingRemoteImageLabels")).containsKey(delayed)&&pending.getIcon()!=null,"Uncached artwork registers for asynchronous delivery while retaining a visible placeholder");
  Icon oldIcon=pending.getIcon();Image downloaded=ImageIO.read(Path.of("verification/artwork-fixtures/AWP---Dragon-Lore.png").toFile());
  check((Boolean)call("updatePendingRemoteImageLabels",new Class[]{String.class,Image.class},delayed,downloaded)&&pending.getIcon()!=oldIcon&&pending.getText().isEmpty()&&pending.getIcon().getIconWidth()<=214,"Downloaded PNGs replace placeholders at the correct outcome-card size without reopening the view");
  String source=Files.readString(Path.of("hGui.java"));String execute=TradeUpProbabilityTests.segment(source,"private void executeTradeUp(","private void refreshMarketTab(");
  check(execute.split("showTradeUpResult\\(result\\)",-1).length==3&&!execute.contains("Trade-Up successful!")&&!execute.contains("JOptionPane.showMessageDialog(this, msg)"),"Both regular and gold execution paths use the illustrated reward panel instead of success-message dialogs");
  String show=TradeUpProbabilityTests.segment(source,"private void showTradeUpResult(","private Component findNamedComponent(");
  check(show.contains("JDialog.DISPOSE_ON_CLOSE")&&show.contains("ESCAPE")&&show.contains("setDefaultButton(close)"),"The result dialog supports its close button, Enter, Escape and normal window closing");
 }
 public static void main(String[] args)throws Exception{MarketRegressionTests.setup();gui=MarketRegressionTests.gui;SwingUtilities.invokeAndWait(()->{try{run();}catch(Exception ex){throw new RuntimeException(ex);}});((java.util.prefs.Preferences)get("marketPricePreferences")).removeNode();System.out.println("All trade-up artwork and reward presentation tests passed.");}
}
