package blahblah;
import java.awt.*;
import java.awt.image.BufferedImage;
import java.io.*;
import java.net.*;
import java.lang.reflect.*;
import java.nio.file.*;
import java.math.BigDecimal;
import java.util.*;
import java.util.List;
import java.util.concurrent.*;
import java.util.concurrent.atomic.*;
import java.util.zip.GZIPOutputStream;
import javax.swing.*;
@SuppressWarnings({"unchecked","rawtypes"})
public class DeepDiveTests {
 static hGui gui;static JPanel overlay;static ExecutorService tasks;static int checks;
 static AtomicInteger http=new AtomicInteger();static volatile int status=200;static volatile boolean blocked;
 static CountDownLatch entered,release;static byte[] body;
 static Object call(String n,Class<?>[]t,Object...a)throws Exception{return MarketRegressionTests.call(n,t,a);}
 static Object get(String n)throws Exception{return MarketRegressionTests.field(n).get(gui);}
 static void set(String n,Object v)throws Exception{MarketRegressionTests.field(n).set(gui,v);}
 static void check(boolean b,String m){MarketRegressionTests.check(b,m);checks++;}
 static void edt(MarketHomeFeedTests.Throwing a)throws Exception{MarketHomeFeedTests.edt(a);}
 static void flush()throws Exception{MarketHomeFeedTests.flush();}
 static void setup()throws Exception{
  URL.setURLStreamHandlerFactory(protocol->!protocol.equals("https")?null:new URLStreamHandler(){protected URLConnection openConnection(URL url){return new HttpURLConnection(url){
   public void connect(){}public void disconnect(){}public boolean usingProxy(){return false;}
   public int getResponseCode()throws IOException{http.incrementAndGet();if(blocked){entered.countDown();try{if(!release.await(8,TimeUnit.SECONDS))throw new IOException("gate timeout");}catch(InterruptedException e){throw new IOException(e);}}return status;}
   public long getContentLengthLong(){return body.length;}
   public InputStream getInputStream(){return new ByteArrayInputStream(body);}
   public String getContentEncoding(){return null;}
  };}});
  MarketRegressionTests.setup();gui=MarketRegressionTests.gui;TradeUpPresentationTests.gui=gui;
  Class<?> ids=Class.forName("blahblah.InventoryIdGenerator");Constructor<?> idctor=ids.getDeclaredConstructor();idctor.setAccessible(true);set("inventoryIdGenerator",idctor.newInstance());
  for(String n:new String[]{"publicPriceSnapshotLocks","publicPriceFeedRetryAfter","publicPriceIndexSources","publicPriceSnapshots","publicPriceSnapshotTimes","publicPriceSnapshotIndexes"})set(n,new ConcurrentHashMap<>());
  for(String n:new String[]{"startupPriceRequestedNames","pendingMarketPriceLookups","marketPriceLookups"})set(n,ConcurrentHashMap.newKeySet());
  call("applyExternalSkinCatalog",new Class[]{String.class},Files.readString(Path.of("verification/current-skins.json")));
  set("startupProgressPercent",0);set("startupProgressStatus","Preparing the interface...");set("startupStartedAt",System.currentTimeMillis());
  edt(()->{overlay=(JPanel)call("createStartupLoadingOverlay",new Class[0]);set("startupLoadingOverlay",overlay);overlay.setVisible(true);});
  set("startupWorkStarted",true);tasks=Executors.newCachedThreadPool();
  body="{\"AWP | Dragon Lore (Factory New)\":{\"price\":250}}".getBytes(java.nio.charset.StandardCharsets.UTF_8);
 }
 static byte[] gzip(String text)throws Exception{ByteArrayOutputStream bytes=new ByteArrayOutputStream();try(GZIPOutputStream zip=new GZIPOutputStream(bytes)){zip.write(text.getBytes(java.nio.charset.StandardCharsets.UTF_8));}return bytes.toByteArray();}
 static String snapshot()throws Exception{return (String)call("getPublicPriceSnapshot",new Class[]{String.class},"csfloat");}
 static void networkAndUi()throws Exception{
  call("prepareStartupPriceTracking",new Class[]{Set.class},Set.of("AWP | Dragon Lore","AK-47 | Redline","Sport Gloves | Vice"));
  blocked=true;entered=new CountDownLatch(1);release=new CountDownLatch(1);
  Future<String> network=tasks.submit(()->snapshot());check(entered.await(3,TimeUnit.SECONDS),"A real background CSFloat request can be held in flight for the loading-display test");
  Future<?> paint=tasks.submit(()->{try{edt(()->{call("setStartupProgress",new Class[]{int.class,String.class},12,"Downloading CSFloat skin prices...");call("refreshStartupLoadingDisplay",new Class[0]);});}catch(Exception e){throw new RuntimeException(e);}});
  boolean responsive;try{paint.get(700,TimeUnit.MILLISECONDS);responsive=true;}catch(TimeoutException e){responsive=false;}finally{blocked=false;release.countDown();}
  check(responsive,"The EDT and startup progress keep updating while CSFloat network I/O is blocked, with no JFrame monitor lockup");network.get(5,TimeUnit.SECONDS);flush();
  check(((JLabel)get("startupLoadingPriceDetailsLabel")).getText().contains("0 / 3"),"The loading UI shows skin prices loaded out of the full total while the feed is downloading");
  check((Long)get("startupPriceFeedBytes")==body.length&&(Long)get("startupPriceFeedTotal")==body.length,"CSFloat transfer byte counters track bytes received and known content length");
  int before=http.get();snapshot();check(http.get()==before,"Fresh price snapshots reuse the cached feed instead of issuing one HTTP request per skin");
  String json="{\"AK-47 | Redline (Field-Tested)\":{\"price\":42.75}}";
  String decoded=(String)call("readPublicPriceFeedBody",new Class[]{InputStream.class},new ByteArrayInputStream(gzip(json)));
  check(decoded.equals(json),"Gzip price responses decode correctly even when Content-Encoding is absent");
  check(call("readPublicPriceFeedBody",new Class[]{InputStream.class},new ByteArrayInputStream(json.getBytes(java.nio.charset.StandardCharsets.UTF_8))).equals(json),"Uncompressed feed responses still decode correctly");
  ((Map)get("publicPriceSnapshotTimes")).put("csfloat",0L);status=503;before=http.get();
  String stale=snapshot();snapshot();check(stale.contains("Dragon Lore")&&http.get()==before+1,"A transient feed outage reuses a valid older snapshot and prevents repeated HTTP failures");
  ((Map)get("publicPriceSnapshots")).clear();((Map)get("publicPriceSnapshotTimes")).clear();((Map)get("publicPriceFeedRetryAfter")).clear();before=http.get();int failures=0;
  for(int i=0;i<12;i++)try{snapshot();}catch(RuntimeException e){failures++;}
  check(failures==12&&http.get()==before+1,"Cold-start feed failure triggers one network request plus cooldown, not a retry storm for every skin");
  status=200;((Map)get("publicPriceFeedRetryAfter")).put("csfloat",System.currentTimeMillis()-1);check(snapshot().contains("Dragon Lore"),"Expired feed cooldown allows recovery without restarting the application");
 }
 static void countersAndWrapping()throws Exception{
  String a="AWP | Dragon Lore",b="AK-47 | Redline",c="Sport Gloves | Vice";Set names=Set.of(a,b,c);
  call("prepareStartupPriceTracking",new Class[]{Set.class},names);((Set)get("startupPriceRequestedNames")).addAll(names);Map live=(Map)get("liveBasePrices");live.put(a,100.0);live.put(b,50.0);((Set)get("pendingMarketPriceLookups")).add(c);
  edt(()->{call("reportStartupPriceProgress",new Class[0]);call("refreshStartupLoadingDisplay",new Class[0]);});
  check((Integer)get("startupPricesLoaded")==2&&(Integer)get("startupPriceFallbacks")==0,"Loaded-price counters do not count an in-flight unresolved skin as completed");
  check(((JLabel)get("startupLoadingPriceDetailsLabel")).getText().contains("2 / 3"),"Visible price counter advances incrementally rather than waiting for all prices");
  ((Set)get("pendingMarketPriceLookups")).remove(c);edt(()->call("reportStartupPriceProgress",new Class[0]));flush();
  check((Integer)get("startupPricesLoaded")==2&&(Integer)get("startupPriceFallbacks")==1,"Missing real/cached quotes are honestly separated as fallbacks instead of falsely loaded");
  live.put(c,300.0);edt(()->{call("reportStartupPriceProgress",new Class[0]);call("refreshStartupLoadingDisplay",new Class[0]);});
  check((Integer)get("startupPricesLoaded")==3&&((JProgressBar)get("startupLoadingProgressBar")).getValue()==40,"All resolved cached/real skin prices produce the completed price-stage counter and progress");
  String longText="Loading CSFloat skin prices for the complete weapons, knives, gloves, Doppler variants and agents catalog. "+"This deliberately long startup message must wrap onto multiple lines instead of disappearing beyond the edge of the loading card. ".repeat(3);
  edt(()->{set("startupProgressStatus",longText);call("refreshStartupLoadingDisplay",new Class[0]);TradeUpPresentationTests.render(overlay,"deep-dive-loading-wrap-render.png",810,860);});flush();
  JTextArea area=(JTextArea)get("startupLoadingStatusLabel");JTextArea time=(JTextArea)get("startupLoadingTimeLabel");
  check(area.getLineWrap()&&area.getWrapStyleWord()&&area.getText().equals(longText),"Long startup information uses real word wrapping and preserves the full text");
  check(area.getRows()>3&&area.getHeight()>=area.getRows()*area.getFontMetrics(area.getFont()).getHeight(),"The status area grows vertically to fit long progress information rather than clipping fixed-height rows");
  check(time.getLineWrap()&&area.getToolTipText().equals(longText),"Elapsed/remaining time also wraps, and the full status remains available as a tooltip");
  check(area.getX()>=0&&area.getX()+area.getWidth()<=area.getParent().getWidth(),"Wrapped status stays inside the loading card at the normal minimum window width");
  edt(()->TradeUpPresentationTests.render(overlay,"deep-dive-loading-wrap-wide-render.png",1000,700));
  edt(()->{set("startupProgressStatus","Skin prices loaded: 1,376 / 2,191 (fallback: 2)");call("refreshStartupLoadingDisplay",new Class[0]);TradeUpPresentationTests.render(overlay,"deep-dive-loading-price-render.png",810,600);});
 }
 static void coherentIndexAndParsing()throws Exception{
  String name="AWP | Example (Field-Tested)",one="{\""+name+"\":{\"price\":12}}",two="{\"Unrelated longer item\":{\"price\":999},\""+name+"\":{\"price\":34}}";
  Double x=(Double)call("findCsfloatSnapshotPrice",new Class[]{String.class,String.class,String.class},one,name,null),y=(Double)call("findCsfloatSnapshotPrice",new Class[]{String.class,String.class,String.class},two,name,null);
  check(x==12&&y==34,"A replacement feed body rebuilds its matching price index instead of applying stale offsets");
  check((Double)call("findCsfloatSnapshotPrice",new Class[]{String.class,String.class,String.class},one,name,null)==12,"Concurrent/older response lookups remain coherent with their own response content");
  String numeric="123.45"+" ".repeat(2000000);long start=System.nanoTime();for(int i=0;i<2000;i++)call("parseMarketPriceValue",new Class[]{String.class,int.class,String.class},numeric,0,null);double ms=(System.nanoTime()-start)/1e6;
  check((Double)call("parseMarketPriceValue",new Class[]{String.class,int.class,String.class},numeric,0,null)==123.45,"Numeric legacy prices parse from matcher regions without copying the remaining multi-megabyte feed");
  System.out.printf("TIMING: 2,000 numeric lookups against a 2 MB response: %.2f ms%n",ms);
 }
 static int oldBudget(String name,boolean st)throws Exception{
  String rarity=(String)call("getSkinRarity",new Class[]{String.class},name);int mean;
  switch(rarity){case "Consumer":mean=480;break;case "Industrial":mean=390;break;case "Milspec":case "Distinguished":mean=300;break;case "Restricted":case "Exceptional":mean=210;break;case "Classified":case "Superior":mean=140;break;case "Covert":case "Master":mean=90;break;case "Contraband":mean=65;break;case "Knife":case "Gloves":mean=60;break;default:mean=300;}
  double variance=(Double)call("getMarketSupplyVariance",new Class[]{String.class},rarity);if(name.contains("Doppler")&&(name.contains("Ruby")||name.contains("Sapphire")||name.contains("Emerald")||name.contains("Black Pearl"))){mean=32;variance=.04;}
  String key=(String)call("normalizeCatalogSkinName",new Class[]{String.class},name.replaceFirst("(?i)^StatTrak(?:™)?\\s+",""));long seed=((long)key.hashCode())^0x6A09E667F3BCC909L;seed=(seed^(seed>>>30))*0xBF58476D1CE4E5B9L;seed=(seed^(seed>>>27))*0x94D049BB133111EBL;seed^=seed>>>31;
  int budget=(int)Math.round(mean*(1+((seed>>>11)*0x1.0p-53*2-1)*variance));if(st)budget=(int)Math.floor(budget*.35);int floor=st?2:(rarity.equals("Knife")||rarity.equals("Gloves"))?6:8;
  return Math.max(((String[])call("getAvailableConditions",new Class[]{String.class},name)).length*floor,budget);
 }
 static void stockAndSafety()throws Exception{
  String[] names={"AWP | Dragon Lore","AK-47 | Redline","Sport Gloves | Vice","Bayonet | Doppler (Ruby)","Bayonet | Vanilla"};boolean twice=true,stable=true;
  for(String n:names)for(boolean st:new boolean[]{false,true}){int budget=(Integer)call("getMarketSupplyBudget",new Class[]{String.class,boolean.class},n,st);twice&=budget==2*oldBudget(n,st);Map<String,Integer> targets=(Map)call("getMarketSupplyTargets",new Class[]{String.class,boolean.class},n,st);stable&=targets.values().stream().mapToInt(Integer::intValue).sum()==budget&&targets.equals(call("getMarketSupplyTargets",new Class[]{String.class,boolean.class},n,st));}
  check(twice,"Market supply budgets are exactly twice the prior deterministic budgets for weapons, gloves, knives, gems and StatTrak");
  check(stable,"Doubled stock remains deterministic and conserves exact valid-wear totals without rerolling on refresh");
  MarketListing npc=(MarketListing)call("createNpcWearListing",new Class[]{String.class,String.class,boolean.class,double.class,String.class},"AK-47 | Redline","Field-Tested",false,100.0,"Classified");
  check(npc.item.history==null&&npc.item.itemId==null,"Bulk NPC stock avoids allocating unused ownership histories until an item is actually tracked");
  call("ensureInventoryItemTracking",new Class[]{InventoryItem.class},npc.item);check(npc.item.history!=null&&npc.item.itemId!=null,"Ownership tracking still initializes correctly on demand for a market item");
  BufferedImage tall=new BufferedImage(1,10000,BufferedImage.TYPE_INT_ARGB);InventoryItem item=new InventoryItem(new ImageIcon(tall),"AWP | Dragon Lore","Factory New","Covert",BigDecimal.TEN,.02,false,1,null,10);
  check(item.getThumb110().getIconWidth()>=1&&item.getThumb130().getIconWidth()>=1,"Extreme-aspect PNGs cannot crash inventory thumbnail scaling with a zero-width image");
  check(((List)call("getDisplayHistory",new Class[]{InventoryItem.class,String.class},null,"YOU")).isEmpty(),"A null inspect/history item returns an empty history rather than dereferencing null");
  MarketListing broken=MarketRegressionTests.listing("AWP | Dragon Lore","Factory New",false,false,10,.03);broken.item.name=null;
  check(call("createSaleRecordFromListing",new Class[]{MarketListing.class,String.class,Image.class},broken,null,null)==null,"Malformed nameless market items cannot crash sale recording");broken.item.name="AWP | Dragon Lore";broken.listPrice=Double.NaN;
  check(call("createSaleRecordFromListing",new Class[]{MarketListing.class,String.class,Image.class},broken,null,null)==null,"Non-finite asks are rejected instead of corrupting sale history");
 }
 static class CountingMap extends HashMap<String,ArrayList<MarketListing>>{int scans;public Set<Map.Entry<String,ArrayList<MarketListing>>> entrySet(){scans++;return super.entrySet();}}
 static void targetedPriceUpdates()throws Exception{
  CountingMap market=new CountingMap();for(int i=0;i<10000;i++)market.put("unrelated "+i,new ArrayList<>());
  String n="AK-47 | Redline";MarketListing npc=MarketRegressionTests.listing(n,"Field-Tested",false,false,100,.2),player=MarketRegressionTests.listing(n,"Field-Tested",false,true,987,.2);market.put(n,new ArrayList<>(List.of(npc,player)));set("globalMarketListings",market);
  ((Map)get("basePriceCache")).put(n,100.0);((Map)get("liveConditionPriceMultipliers")).put(n,Map.of("Field-Tested",1.0));double old=npc.listPrice;
  Class<?> quote=Class.forName("blahblah.MarketPriceData");Constructor<?> c=quote.getDeclaredConstructor(double.class,Map.class);c.setAccessible(true);Object q=c.newInstance(200.0,Map.of("Field-Tested",1.0));
  edt(()->call("updateBasePriceFromMarket",new Class[]{String.class,quote},n,q));
  check(market.scans==0,"Applying one price update uses direct normal/StatTrak bucket lookups instead of scanning 10,000 unrelated market buckets");
  check(Math.abs(npc.listPrice-old*2)<.001&&player.listPrice==987,"Targeted price updates preserve existing repricing formulas and never alter a player's ask");
 }
 public static void main(String[]a)throws Exception{try{setup();networkAndUi();countersAndWrapping();coherentIndexAndParsing();stockAndSafety();targetedPriceUpdates();System.out.println("All "+checks+" deep-dive bug/performance checks passed.");}finally{if(release!=null)release.countDown();if(tasks!=null)tasks.shutdownNow();if(gui!=null)((java.util.prefs.Preferences)get("marketPricePreferences")).removeNode();}System.exit(0);}
}
