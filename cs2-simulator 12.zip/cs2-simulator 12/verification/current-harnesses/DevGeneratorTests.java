package blahblah;
import java.util.*;
import java.lang.reflect.*;
import java.nio.file.*;
import java.awt.*;
import java.awt.image.BufferedImage;
import javax.swing.*;

@SuppressWarnings({"unchecked","rawtypes"})
public class DevGeneratorTests {
 static hGui gui;
 static Object call(String n,Class<?>[] ts,Object...a)throws Exception{return MarketRegressionTests.call(n,ts,a);}
 static Object get(String n)throws Exception{Field f=MarketRegressionTests.field(n);return f.get(Modifier.isStatic(f.getModifiers())?null:gui);}
 static void set(String n,Object v)throws Exception{MarketRegressionTests.field(n).set(gui,v);}
 static void check(boolean b,String m){MarketRegressionTests.check(b,m);}
 static Component find(Component c,String name){if(name.equals(c.getName()))return c;if(c instanceof Container)for(Component ch:((Container)c).getComponents()){Component found=find(ch,name);if(found!=null)return found;}return null;}
 static <T> T first(Component c,Class<T> type){if(type.isInstance(c))return type.cast(c);if(c instanceof Container)for(Component ch:((Container)c).getComponents()){T found=first(ch,type);if(found!=null)return found;}return null;}
 static void layout(Component c){if(c instanceof Container){((Container)c).doLayout();for(Component ch:((Container)c).getComponents())layout(ch);}}
 static java.util.List<InventoryItem> generate(String skin,int q,Double fl,Integer pat)throws Exception{return (java.util.List)call("generateDevSkins",new Class<?>[]{String.class,int.class,Double.class,Integer.class},skin,q,fl,pat);}
 static void cached(String skin,double price)throws Exception{
  ((Map)get("liveBasePrices")).put(skin,price);
  Object repo=get("imageRepository");Method put=repo.getClass().getDeclaredMethod("put",String.class,Image.class);put.setAccessible(true);put.invoke(repo,skin,new BufferedImage(150,95,2));
 }
 static void run()throws Exception{
  call("registerBundledTerminals",new Class<?>[0]);call("registerRequestedMarketCollections",new Class<?>[0]);
  call("applyExternalSkinCatalog",new Class<?>[]{String.class},Files.readString(Path.of("verification/current-skins.json")));
  call("applyExternalCrateCatalog",new Class<?>[]{String.class},Files.readString(Path.of("crates.json")));
  set("currentCase",CaseType.BRAVO);
  Class<?> cls=Class.forName("blahblah.InventoryIdGenerator");Constructor<?> ctor=cls.getDeclaredConstructor();ctor.setAccessible(true);set("inventoryIdGenerator",ctor.newInstance());
  cls=Class.forName("blahblah.ImageRepository");ctor=cls.getDeclaredConstructor(hGui.class);ctor.setAccessible(true);set("imageRepository",ctor.newInstance(gui));
  String lore="AWP | Dragon Lore";cached(lore,1000);
  JPanel inv=new JPanel(),trade=new JPanel();inv.putClientProperty("inventorySnapshot","old");trade.putClientProperty("inventorySnapshot","old");set("inventoryTabPanel",inv);set("tradeUpTabPanel",trade);
  java.util.List<InventoryItem> batch=generate(lore,10,null,null);
  double[] bounds=(double[])call("getMarketWearBounds",new Class<?>[]{String.class},lore);
  check(batch.size()==10&&bounds[0]==0&&bounds[1]==.7,"Ten Dragon Lores are generated using the authoritative 0–0.7 float range");
  Set<Double> floats=new HashSet<>();Set<Integer> patterns=new HashSet<>();Set<String> ids=new HashSet<>();double total=0;
  for(InventoryItem item:batch){
   if(item.itemFloat<0||item.itemFloat>.7||item.patternID<0||item.patternID>999)throw new AssertionError("Limits");
   if(!item.condition.equals(call("getConditionForFloat",new Class<?>[]{String.class,double.class},lore,item.itemFloat)))throw new AssertionError("Wear");
   if(!"YOU".equals(item.currentOwner)||item.itemId==null||item.history.isEmpty()||!item.history.get(item.history.size()-1).title.equals("Developer generated"))throw new AssertionError("Tracking");
   if(item.collection==null||item.price.doubleValue()<=0||item.isStattrak)throw new AssertionError("Metadata");
   floats.add(item.itemFloat);patterns.add(item.patternID);ids.add(item.itemId);total+=item.price.doubleValue();
  }
  check(floats.size()>1&&patterns.size()>1,"Blank float and pattern fields generate independent random values per item");
  check(ids.size()==10,"Each generated skin has a unique inventory ID, ownership and explicit developer-generation history");
  set("finalSkinName","Unrelated last opened skin");set("gunName","");
  Image downloaded=new BufferedImage(160,100,2);
  call("showLoadedCaseResultImage",new Class<?>[]{String.class,Image.class},lore,downloaded);
  check(batch.stream().allMatch(item->item.image.getImage()==downloaded&&item.thumb110x75==null&&item.thumb130x88==null),"Downloaded artwork updates all generated inventory items even when they were not the last case reward");
  check(((java.util.List)get("inventoryList")).size()==10&&Math.abs((Double)get("inventoryValue")-total)<.001,"Items are added to inventory and their value is included exactly once");
  check(inv.getClientProperty("inventorySnapshot")==null&&trade.getClientProperty("inventorySnapshot")==null&&(Integer)get("totalCrates")==0,"Inventory/trade-up views are invalidated without increasing case-opening statistics");
  batch=generate(lore,10,.012345678,661);for(InventoryItem item:batch)if(item.itemFloat!=.012345678||item.patternID!=661||!item.condition.equals("Factory New"))throw new AssertionError("Fixed settings");
  check(true,"Specified float precision and pattern are applied to every generated skin");
  batch=generate(lore,20,.2,null);patterns.clear();for(InventoryItem item:batch){patterns.add(item.patternID);if(item.itemFloat!=.2)throw new AssertionError("Fixed float");}
  check(patterns.size()>1,"A fixed float can be combined with random patterns");
  batch=generate(lore,20,null,42);floats.clear();for(InventoryItem item:batch){floats.add(item.itemFloat);if(item.patternID!=42)throw new AssertionError("Fixed pattern");}
  check(floats.size()>1,"A fixed pattern can be combined with random floats");
  int before=((java.util.List)get("inventoryList")).size();int rejected=0;
  Object[][] bad={{lore,0,null,null},{lore,1001,null,null},{lore,1,-.01,null},{lore,1,.71,null},{lore,1,Double.NaN,null},{lore,1,Double.POSITIVE_INFINITY,null},{lore,1,null,-1},{lore,1,null,1000},{"AWP | Invented",1,null,null}};
  for(Object[] args:bad)try{generate((String)args[0],(Integer)args[1],(Double)args[2],(Integer)args[3]);}catch(Exception ex){rejected++;}
  check(rejected==bad.length&&((java.util.List)get("inventoryList")).size()==before,"Invalid quantities, impossible floats, invalid patterns and unknown skins are rejected without partial generation");
  generate(lore,1,0.0,0);generate(lore,1,.7,999);check(true,"Valid minimum/maximum float and pattern values are accepted");
  String vanilla="Bayonet | Vanilla";cached(vanilla,300);batch=generate(vanilla,3,null,null);
  check(batch.stream().allMatch(it->it.itemFloat==0&&it.condition.equals("Normal")),"Vanilla knives remain Normal-only with zero float");
  JPanel panel=(JPanel)call("buildDevToolsPanel",new Class<?>[0]);panel.setSize(760,660);layout(panel);
  check(find(panel,"devContainer") instanceof JList&&find(panel,"devContainerSearch") instanceof JTextField,"Case dropdown is replaced with a genuine search bar and scrollable results list");
  JTextField search=(JTextField)find(panel,"devContainerSearch");JList<CaseType> list=(JList)find(panel,"devContainer");JComboBox<String> outcomes=(JComboBox)find(panel,"devOutcome");
  search.setText("sEaLeD dEaD hAnD");
  check(list.getModel().getSize()==1&&list.getSelectedValue().crateName.equals("Sealed Dead Hand Terminal"),"Case search supports multiple words and is case-insensitive");
  Set<String> offered=new HashSet<>();for(int i=0;i<outcomes.getItemCount();i++)offered.add(outcomes.getItemAt(i));
  check(offered.contains("Gloves")&&!offered.contains("Knife"),"Filtered case selection immediately updates overrides to that case's legal outcomes");
  search.setText("no case matches this string");check(list.getModel().getSize()==0&&outcomes.getItemCount()==0,"No-match case searches cannot expose stale outcomes from the previous case");
  search.setText("bravo");
  for(String name:new String[]{"devMode","devOutcome","devStatTrak"}){
   JComboBox box=(JComboBox)find(panel,name);
   if(!box.getUI().getClass().getName().contains("UiWidgets$"))throw new AssertionError("Native combo UI");
   JLabel renderer=(JLabel)box.getRenderer().getListCellRendererComponent(new JList<>(),"Normal odds",-1,false,false);
   if(!renderer.isOpaque()||renderer.getVerticalAlignment()!=SwingConstants.CENTER||renderer.getBackground().equals(renderer.getForeground()))throw new AssertionError("Renderer contrast/alignment "+name+" opaque="+renderer.isOpaque()+" vertical="+renderer.getVerticalAlignment()+" bg="+renderer.getBackground()+" fg="+renderer.getForeground());
   box.setSize(250,34);layout(box);BufferedImage img=new BufferedImage(250,34,2);Graphics2D g=img.createGraphics();box.printAll(g);g.dispose();
   int light=0;for(int y=0;y<34;y++)for(int x=0;x<250;x++){Color c=new Color(img.getRGB(x,y),true);if(c.getRed()>240&&c.getGreen()>240&&c.getBlue()>240)light++;}
   if(light>250*34/4)throw new AssertionError("White native bezel "+name);
  }
  check(true,"All Dev Tools dropdowns use explicit non-native dark UI, centered opaque renderers and no white bezel");
  JTabbedPane tabs=first(panel,JTabbedPane.class);check(tabs.getTabCount()==3,"Case overrides, generator and wallet are organized into separate readable sections");
  layout(panel);
  BufferedImage preview=new BufferedImage(760,660,2);Graphics2D pg=preview.createGraphics();panel.printAll(pg);pg.dispose();javax.imageio.ImageIO.write(preview,"png",Path.of("verification/dev-search-case-render.png").toFile());
  tabs.setSelectedIndex(1);layout(panel);
  JTextField skinSearch=(JTextField)find(panel,"devGeneratorSkinSearch");skinSearch.setText("dragon lore");
  JList skinList=(JList)find(panel,"devGeneratorSkin");check(skinList.getModel().getSize()==1&&skinList.getSelectedValue().equals(lore),"Skin generator search locates Dragon Lore without free-typing an unverified skin name: count="+skinList.getModel().getSize()+", selected="+skinList.getSelectedValue());
  JSpinner quantity=(JSpinner)find(panel,"devGeneratorQuantity");quantity.setValue(10);
  before=((java.util.List)get("inventoryList")).size();((JButton)find(panel,"devGenerateSkins")).doClick();
  check(((java.util.List)get("inventoryList")).size()==before+10&&((JLabel)find(panel,"devGeneratorStatus")).getText().contains("Added 10"),"Generator UI creates the requested quantity with blank random settings");
  ((JComboBox)find(panel,"devGeneratorFloatMode")).setSelectedItem("Specific float");
  ((JTextField)find(panel,"devGeneratorFloat")).setText(".99");((JButton)find(panel,"devGenerateSkins")).doClick();
  check(((java.util.List)get("inventoryList")).size()==before+10&&((JLabel)find(panel,"devGeneratorStatus")).getText().contains("Float must"),"Generator UI explains an out-of-range float without adding items");
  ((JTextField)find(panel,"devGeneratorFloat")).setText("");
  ((JComboBox)find(panel,"devGeneratorFloatMode")).setSelectedItem("Random float");
  ((JButton)find(panel,"devGenerateSkins")).doClick();
  preview=new BufferedImage(760,660,2);pg=preview.createGraphics();panel.printAll(pg);pg.dispose();javax.imageio.ImageIO.write(preview,"png",Path.of("verification/dev-generator-render.png").toFile());
  generatorModes(panel);
 }
 static void generatorModes(JPanel panel)throws Exception{
  JTextField skinSearch=(JTextField)find(panel,"devGeneratorSkinSearch");JList skins=(JList)find(panel,"devGeneratorSkin");
  JComboBox<String> fm=(JComboBox)find(panel,"devGeneratorFloatMode"),wear=(JComboBox)find(panel,"devGeneratorWearRange"),pm=(JComboBox)find(panel,"devGeneratorPatternMode");
  JTextField fl=(JTextField)find(panel,"devGeneratorFloat"),pat=(JTextField)find(panel,"devGeneratorPattern");
  JSpinner qty=(JSpinner)find(panel,"devGeneratorQuantity");JButton button=(JButton)find(panel,"devGenerateSkins");
  java.util.List<InventoryItem> inventory=(java.util.List)get("inventoryList");
  check(fm.getItemCount()==3&&pm.getItemCount()==2&&fm.getItemAt(0).equals("Random float")&&fm.getItemAt(1).equals("Specific float")&&fm.getItemAt(2).equals("Float within range"),"Float offers exactly three explicit modes and pattern offers exactly two");
  skinSearch.setText("dragon lore");fm.setSelectedItem("Float within range");wear.setSelectedItem("Minimal Wear");pm.setSelectedItem("Random pattern");qty.setValue(100);
  int before=inventory.size();button.doClick();Set<Double> fs=new HashSet<>();Set<Integer> ps=new HashSet<>();
  for(InventoryItem it:inventory.subList(before,inventory.size())){if(it.itemFloat<.07||it.itemFloat>=.15||!it.condition.equals("Minimal Wear"))throw new AssertionError("MW boundary "+it.itemFloat);fs.add(it.itemFloat);ps.add(it.patternID);}
  check(inventory.size()==before+100&&fs.size()>1&&ps.size()>1,"Dragon Lore Minimal Wear produces independent random floats in [0.07, 0.15), with independent random patterns");
  check(((JLabel)find(panel,"devGeneratorFloatInfo")).getText().contains("0.07")&&((JLabel)find(panel,"devGeneratorFloatInfo")).getText().contains("0.15"),"Selected wear interval is displayed numerically");
  fm.setSelectedItem("Specific float");fl.setText(".091234567");pm.setSelectedItem("Specific pattern");pat.setText("661");qty.setValue(10);before=inventory.size();button.doClick();
  for(InventoryItem it:inventory.subList(before,inventory.size()))if(it.itemFloat!=.091234567||it.patternID!=661)throw new AssertionError("Specific mode");
  check(inventory.size()==before+10&&fl.isVisible()&&pat.isVisible()&&!wear.isVisible(),"Specific float and specific pattern apply exact values and show only relevant inputs");
  fm.setSelectedItem("Random float");pm.setSelectedItem("Random pattern");fl.setText("not a float");pat.setText("not a pattern");before=inventory.size();button.doClick();
  check(inventory.size()==before+10&&!fl.isVisible()&&!pat.isVisible(),"Random modes ignore stale hidden specific values and hide unused fields");
  fm.setSelectedItem("Specific float");fl.setText("");before=inventory.size();button.doClick();
  check(inventory.size()==before&&((JLabel)find(panel,"devGeneratorStatus")).getText().contains("Enter a float"),"Specific float requires an entered value rather than silently randomizing");
  fm.setSelectedItem("Random float");pm.setSelectedItem("Specific pattern");pat.setText("");before=inventory.size();button.doClick();
  check(inventory.size()==before&&((JLabel)find(panel,"devGeneratorStatus")).getText().contains("Enter a pattern"),"Specific pattern requires an entered value rather than silently randomizing");
  pat.setText("123.4");button.doClick();check(inventory.size()==before&&((JLabel)find(panel,"devGeneratorStatus")).getText().contains("whole number"),"Specific patterns reject decimal IDs without generating any items");
  String chatter="Galil AR | Chatterbox";cached(chatter,100);skinSearch.setText("chatterbox");fm.setSelectedItem("Float within range");pm.setSelectedItem("Random pattern");
  Set<String> available=new HashSet<>();for(int i=0;i<wear.getItemCount();i++)available.add(wear.getItemAt(i));
  check(available.equals(Set.of("Field-Tested","Well-Worn","Battle-Scarred")),"Wear picker excludes Factory New and Minimal Wear for Chatterbox, which starts at 0.35");
  wear.setSelectedItem("Field-Tested");qty.setValue(100);before=inventory.size();button.doClick();
  for(InventoryItem it:inventory.subList(before,inventory.size()))if(it.itemFloat<.35||it.itemFloat>=.38||!it.condition.equals("Field-Tested"))throw new AssertionError("Clipped FT");
  check(inventory.size()==before+100,"Wear-range generation clips the requested interval to the skin's own minimum float");
  boolean rejected=false;before=inventory.size();try{call("generateDevSkins",new Class<?>[]{String.class,int.class,Double.class,Integer.class,String.class},chatter,10,null,null,"Minimal Wear");}catch(Exception ex){rejected=true;}
  check(rejected&&inventory.size()==before,"Unavailable wear ranges are rejected by generation logic as well as excluded from the UI");
  String hot="M4A1-S | Hot Rod";cached(hot,100);skinSearch.setText("hot rod");skins.setSelectedValue(hot,true);wear.setSelectedItem("Minimal Wear");qty.setValue(50);before=inventory.size();button.doClick();
  for(InventoryItem it:inventory.subList(before,inventory.size()))if(it.itemFloat<.07||it.itemFloat>=.08||!it.condition.equals("Minimal Wear"))throw new AssertionError("Clipped MW maximum");
  check(inventory.size()==before+50&&wear.getItemCount()==2,"Hot Rod offers only FN/MW, and MW floats are clipped to [0.07, 0.08)");
  skinSearch.setText("bayonet vanilla");skins.setSelectedValue("Bayonet | Vanilla",true);qty.setValue(10);before=inventory.size();button.doClick();
  for(InventoryItem it:inventory.subList(before,inventory.size()))if(it.itemFloat!=0||!it.condition.equals("Normal"))throw new AssertionError("Vanilla");
  check(inventory.size()==before+10&&!fm.isEnabled()&&wear.getItemCount()==0,"No-float vanilla items disable wear selection and remain Normal with zero float");
  skinSearch.setText("dragon lore");fm.setSelectedItem("Float within range");wear.setSelectedItem("Minimal Wear");qty.setValue(10);button.doClick();layout(panel);
  BufferedImage image=new BufferedImage(760,660,2);Graphics2D g=image.createGraphics();panel.printAll(g);g.dispose();javax.imageio.ImageIO.write(image,"png",Path.of("verification/dev-generator-modes-render.png").toFile());
 }

 public static void main(String[] args)throws Exception{
  MarketRegressionTests.setup();gui=MarketRegressionTests.gui;
  SwingUtilities.invokeAndWait(()->{try{run();}catch(Exception e){throw new RuntimeException(e);}});
  ((java.util.prefs.Preferences)get("marketPricePreferences")).removeNode();System.out.println("All Dev Tools search, styling and skin-generator tests passed.");
 }
}
