package blahblah;
import java.util.*;
import java.lang.reflect.*;
import java.nio.file.*;
import java.awt.*;
import java.awt.event.*;
import java.awt.image.BufferedImage;
import javax.swing.*;
@SuppressWarnings({"unchecked","rawtypes"})
public class CalculatorMatchingTests {
 static hGui gui;
 static Object call(String n,Class<?>[] t,Object...a)throws Exception{return MarketRegressionTests.call(n,t,a);}
 static Object get(String n)throws Exception{Field f=MarketRegressionTests.field(n);return f.get(Modifier.isStatic(f.getModifiers())?null:gui);}
 static void check(boolean b,String m){MarketRegressionTests.check(b,m);}
 static Map<String,Double> odds(CaseType c)throws Exception{return (Map)call("getCaseGoldOutcomeOdds",new Class[]{CaseType.class},c);}
 static boolean near(double x,double y){return Math.abs(x-y)<1e-12;}
 static boolean sameOdds(Map<String,Double> a,Map<String,Double> b){return a.keySet().equals(b.keySet())&&a.entrySet().stream().allMatch(e->near(e.getValue(),b.get(e.getKey())));}
 static CaseType crate(String name){for(CaseType ct:CaseType.values())if(ct.crateName.equals(name))return ct;throw new AssertionError(name);}
 static Map<String,Double> contract(CaseType ct)throws Exception{return (Map)call("getGoldTradeUpOdds",new Class[]{java.util.List.class},GoldTradeUpTests.batch(ct,5,ct,0,false));}
 static void render(JPanel panel,String filename)throws Exception{panel.setSize(1000,760);DevGeneratorTests.layout(panel);BufferedImage img=new BufferedImage(1000,760,2);Graphics2D g=img.createGraphics();panel.printAll(g);g.dispose();javax.imageio.ImageIO.write(img,"png",Path.of("verification/"+filename).toFile());}
 static void run()throws Exception{
  call("registerBundledTerminals",new Class[0]);call("registerRequestedMarketCollections",new Class[0]);
  call("applyExternalSkinCatalog",new Class[]{String.class},Files.readString(Path.of("verification/current-skins.json")));
  call("applyExternalCrateCatalog",new Class[]{String.class},Files.readString(Path.of("crates.json")));
  CaseType chroma=crate("Chroma 3 Case"),dreams=crate("Dreams & Nightmares Case");
  Map<String,Double> c=contract(chroma),d=contract(dreams);
  String dop="Bayonet | Doppler",gam="Butterfly Knife | Gamma Doppler";
  check(near(c.get("Bayonet | Tiger Tooth"),.0239),"Chroma calculator match: each ordinary knife finish is EXACTLY 2.39%");
  check(java.util.stream.IntStream.rangeClosed(1,4).allMatch(i->near(c.get(dop+" (Phase "+i+")"),.019)),"Chroma calculator match: each individual Doppler phase is EXACTLY 1.90%");
  check(near(c.get(dop+" (Sapphire)"),.002)&&near(c.get(dop+" (Ruby)"),.002),"Chroma calculator match: Sapphire and Ruby are EXACTLY 0.20% each per knife");
  check(near(c.get(dop+" (Black Pearl)"),.0005),"Chroma calculator match: Black Pearl is EXACTLY 0.05% per knife");
  check(c.size()==60&&near(c.values().stream().mapToDouble(Double::doubleValue).sum(),1),"All 60 phase-resolved Chroma outcomes sum to 100% without rounding or a duplicate base Doppler");
  double totalDoppler=c.entrySet().stream().filter(e->e.getKey().contains("Doppler")).mapToDouble(Map.Entry::getValue).sum();
  check(near(totalDoppler,.4025),"Chroma's combined Doppler share is 40.25%, matching the calculator rather than incorrectly assuming equal base finishes");
  check(near(d.get(gam+" (Emerald)"),.0027),"Dreams calculator match: Butterfly Emerald is EXACTLY 0.27%");
  check(java.util.stream.IntStream.rangeClosed(1,4).allMatch(i->near(d.get(gam+" (Phase "+i+")"),.0077)),"Dreams calculator match: each Butterfly Gamma phase is EXACTLY 0.77%");
  check(near(d.get("Butterfly Knife | Lore"),.0333)&&near(d.get("Butterfly Knife | Autotronic"),.0333),"Dreams calculator match: each ordinary finish is EXACTLY 3.33%");
  check(d.size()==50&&near(d.values().stream().mapToDouble(Double::doubleValue).sum(),1),"All 50 phase-resolved Dreams & Nightmares outcomes sum to 100%");
  check(near(d.entrySet().stream().filter(e->e.getKey().contains("Gamma Doppler")).mapToDouble(Map.Entry::getValue).sum(),.1675),"Dreams Gamma Dopplers have a combined 16.75% share, including 1.35% total Emeralds across all five knives");
  for(String name:new String[]{"Chroma Case","Chroma 2 Case"})check(sameOdds(odds(crate(name)),c),name+" shares the verified Chroma 3 rare-item weighting");
  for(String name:new String[]{"Gamma Case","Gamma 2 Case","Operation Riptide Case"}){
   Map<String,Double> m=odds(crate(name));String base=crate(name).rareDropNames.stream().filter(n->n.endsWith("Gamma Doppler")).findFirst().orElseThrow();
   check(near(m.get(base+" (Emerald)"),.0027)&&near(m.get(base+" (Phase 1)"),.0077),name+" uses the calculator's Gamma profile, not a universal Emerald percentage");
  }
  for(String name:new String[]{"Spectrum Case","Spectrum 2 Case","Prisma Case","Prisma 2 Case","Fever Case"}){
   CaseType ct=crate(name);Map<String,Double> m=odds(ct);String base=ct.rareDropNames.stream().filter(n->n.endsWith(" | Doppler")).findFirst().orElseThrow();
   double total=m.get(base+" (Phase 1)")/m.get(base+" (Ruby)");double expected=name.startsWith("Spectrum")?.0335/.015:.033/.015;
   check(near(total,expected)&&near(m.values().stream().mapToDouble(Double::doubleValue).sum(),1),name+" uses its own calculator profile and remains normalized");
  }
  Map<String,Double> unbox=(Map)call("getCaseUnboxingGoldOutcomeOdds",new Class[]{CaseType.class,String.class},chroma,"Knives");
  check(near(unbox.get(dop+" (Ruby)"),.0805*.035)&&near(c.get(dop+" (Ruby)"),.002),"Unboxing uses its own gem split while gold contracts retain the calculator distribution");
  Map<String,Integer> counts=new HashMap<>();((Random)get("random")).setSeed(432175);int n=15000;
  for(int i=0;i<n;i++)counts.merge((String)call("getRandomCaseGoldDrop",new Class[]{CaseType.class,String.class},chroma,"Knives"),1,Integer::sum);
  check(unbox.entrySet().stream().allMatch(e->Math.abs(counts.getOrDefault(e.getKey(),0)/(double)n-e.getValue())<.006),"15000 actual unboxing special-item rolls follow the separate unboxing weights");
  java.util.List<InventoryItem> inputs=GoldTradeUpTests.batch(chroma,3,crate("Sealed Dead Hand Terminal"),2,false);
  Map<String,Double> mix=(Map)call("getGoldTradeUpOdds",new Class[]{java.util.List.class},inputs);
  check(near(mix.get(dop+" (Phase 1)"),.6*.019)&&near(mix.get(dop+" (Ruby)"),.6*.002),"Mixed-source contracts retain collection shares before applying the new phase weights");
  Class<?> cls=Class.forName("blahblah.ImageRepository");Constructor<?> ctor=cls.getDeclaredConstructor(hGui.class);ctor.setAccessible(true);MarketRegressionTests.field("imageRepository").set(gui,ctor.newInstance(gui));DevGeneratorTests.gui=gui;
  java.util.List<InventoryItem> inv=(java.util.List)get("inventoryList");ArrayList<InventoryItem> five=GoldTradeUpTests.batch(chroma,5,chroma,0,false);inv.addAll(five);
  for(String name:c.keySet())DevGeneratorTests.cached(name,1000);
  JPanel outcomes=(JPanel)call("buildTradeUpOutcomesPanel",new Class[]{ArrayList.class},five);String labels=GoldTradeUpTests.labels(outcomes);
  check(!labels.contains("Chroma 3 Case: 100")&&!labels.contains("Doppler:")&&!labels.contains("Pattern premiums"),"The complete screenshot text block is removed from the gold outcome header");
  check(labels.contains("2.390000% chance")&&labels.contains("1.900000% chance")&&labels.contains("0.200000% chance")&&labels.contains("0.050000% chance"),"The actual gold outcomes UI displays every calculator-matched Chroma percentage");
  render(outcomes,"calculator-chroma-outcomes-render.png");
  inv.clear();five=GoldTradeUpTests.batch(dreams,5,dreams,0,false);inv.addAll(five);for(String name:d.keySet())DevGeneratorTests.cached(name,1000);
  outcomes=(JPanel)call("buildTradeUpOutcomesPanel",new Class[]{ArrayList.class},five);labels=GoldTradeUpTests.labels(outcomes);
  check(labels.contains("0.270000% chance")&&labels.contains("0.770000% chance")&&labels.contains("3.330000% chance"),"The actual Dreams outcomes UI displays the calculator's Emerald, phase and ordinary-finish percentages");
  render(outcomes,"calculator-dreams-outcomes-render.png");
  JPanel generator=(JPanel)call("buildDevSkinGeneratorPanel",new Class[0]);
  JTextField search=(JTextField)DevGeneratorTests.find(generator,"devGeneratorSkinSearch");JList list=(JList)DevGeneratorTests.find(generator,"devGeneratorSkin");JScrollPane results=(JScrollPane)DevGeneratorTests.find(generator,"devGeneratorSkinResults");
  check(!results.isVisible(),"The generator starts with its skin results list collapsed");
  search.setText("dragon lore");check(results.isVisible()&&list.getModel().getSize()==1,"Typing a new query opens the filtered skin list");
  search.postActionEvent();check(!results.isVisible()&&list.getSelectedValue().equals("AWP | Dragon Lore")&&search.getText().equals("AWP | Dragon Lore"),"Enter commits a skin, fills the search bar and closes its results without losing the selection");
  for(MouseListener l:search.getMouseListeners())l.mousePressed(new MouseEvent(search,MouseEvent.MOUSE_PRESSED,System.currentTimeMillis(),0,5,5,1,false,MouseEvent.BUTTON1));
  check(results.isVisible(),"Clicking the search bar reopens results so another skin can be chosen");
  search.setText("hot rod");list.setSelectedValue("M4A1-S | Hot Rod",true);list.setSize(600,200);Rectangle r=list.getCellBounds(list.getSelectedIndex(),list.getSelectedIndex());
  MouseEvent click=new MouseEvent(list,MouseEvent.MOUSE_RELEASED,System.currentTimeMillis(),0,r.x+5,r.y+5,1,false,MouseEvent.BUTTON1);
  for(MouseListener l:list.getMouseListeners())l.mouseReleased(click);
  check(!results.isVisible()&&list.getSelectedValue().equals("M4A1-S | Hot Rod"),"Mouse selection closes the results list, including a result already highlighted by filtering");
  search.setText("dragon lore");search.getActionMap().get("browseResults").actionPerformed(new ActionEvent(search,0,"down"));
  check(results.isVisible(),"Keyboard Down opens results for browsing instead of prematurely closing the list");
  list.getActionMap().get("commitSkinSelection").actionPerformed(new ActionEvent(list,0,"enter"));check(!results.isVisible(),"Enter while browsing the list also commits and closes it");
  search.setText("hot rod");search.getActionMap().get("closeSkinResults").actionPerformed(new ActionEvent(search,0,"escape"));check(!results.isVisible()&&list.getSelectedValue()!=null,"Escape dismisses the list without clearing the selected skin");
  search.setText("no such skin fixture 1729");check(!results.isVisible()&&list.getSelectedValue()==null,"A no-match search clears stale selection and does not leave an empty list open");
  search.setText("dragon lore");search.postActionEvent();call("styleDeveloperPanel",new Class[]{Component.class},generator);render(generator,"generator-collapsed-results-render.png");
  JPanel dev=(JPanel)call("buildDevToolsPanel",new Class[0]);JScrollPane cases=(JScrollPane)DevGeneratorTests.find(dev,"devContainerResults");check(cases!=null&&cases.isVisible(),"The case selector remains a permanent search/list, unaffected by generator-only collapse behavior");
  if(!Files.exists(Path.of("verification/before-calculator-weights.java.txt"))){System.out.println("SKIP: historical monolithic source-only comparison; current runtime math checked above");return;}
  String old=Files.readString(Path.of("verification/before-calculator-weights.java.txt")),now=Files.readString(Path.of("hGui.java"));
  check(TradeUpProbabilityTests.segment(old,"private double getGoldTradeUpOutputFloat(","private String getGoldTradeUpOutputRarity").equals(TradeUpProbabilityTests.segment(now,"private double getGoldTradeUpOutputFloat(","private String getGoldTradeUpOutputRarity")),"Gold output-float formula remains byte-for-byte unchanged");
 }
 public static void main(String[] args)throws Exception{MarketRegressionTests.setup();gui=MarketRegressionTests.gui;SwingUtilities.invokeAndWait(()->{try{run();}catch(Exception ex){throw new RuntimeException(ex);}});((java.util.prefs.Preferences)get("marketPricePreferences")).removeNode();System.out.println("All calculator-match and generator-collapse tests passed.");}
}
