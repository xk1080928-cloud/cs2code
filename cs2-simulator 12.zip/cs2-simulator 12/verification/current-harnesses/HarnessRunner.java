package blahblah;
public class HarnessRunner { public static void main(String[]args) {Thread.setDefaultUncaughtExceptionHandler((t,e)->{e.printStackTrace();System.exit(1);});try{Class.forName("blahblah."+args[0]).getMethod("main",String[].class).invoke(null,(Object)new String[0]);System.exit(0);}catch(Throwable e){e.printStackTrace();System.exit(1);}} }
