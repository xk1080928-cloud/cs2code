package blahblah;

import java.awt.*;
import java.awt.event.*;
import java.awt.image.BufferedImage;
import java.math.BigDecimal;
import java.nio.file.*;
import java.util.*;
import java.util.List;
import javax.imageio.ImageIO;
import javax.swing.*;

/** Native checks for the follow-up requirements; uses the real extracted feature objects. */
public class RetainedUiChecks {
  static hGui app; static int checks;
  static void check(boolean ok,String text) { if(!ok)throw new AssertionError(text);checks++;System.out.println("PASS: "+text); }
  static void edt(MarketHomeFeedTests.Throwing action)throws Exception {Cs2RedesignTests.edt(action);}
  static InventoryItem item(String name,double f) {return new InventoryItem(null,name,"Factory New","Covert",BigDecimal.valueOf(100),f,false,42,null,100);}
  static MarketListing lot(InventoryItem i,String site,double price,int qty) {MarketListing l=new MarketListing(i,price,120,false);l.marketplaceName=site;l.setPrice(price);l.quantity=qty;return l;}
  static <T>T find(Component c,Class<T> type,String name){return Cs2RedesignTests.find(c,type,name);}
  static void click(Component c) {for(MouseListener l:c.getMouseListeners())l.mouseClicked(new MouseEvent(c,MouseEvent.MOUSE_CLICKED,System.currentTimeMillis(),0,12,12,1,false,MouseEvent.BUTTON1));}
  static String tree(Component c) {
    String s=c.getClass().getSimpleName();
    if(c instanceof JSplitPane)s+="/"+((JSplitPane)c).getOrientation()+"/"+((JSplitPane)c).getResizeWeight();
    if(c instanceof Container){LayoutManager l=((Container)c).getLayout();s+="["+(l==null?"null":l.getClass().getSimpleName());
      if(l instanceof GridLayout)s+="/"+((GridLayout)l).getRows()+"/"+((GridLayout)l).getColumns();
      for(Component child:((Container)c).getComponents()){
        if(l instanceof BorderLayout)s+="@"+((BorderLayout)l).getConstraints(child);
        s+=tree(child);
      }s+="]";
    }return s;
  }
  static void render(JPanel panel,String file)throws Exception {Cs2RedesignTests.render(panel,file,1440,960);}
  static void defaults()throws Exception {
    check(app.cs2EquipmentScreens.collectibleInventory().isEmpty(),"Fresh default equipment contributes zero collectible skins");
    for(String gun:new String[]{"CT Knife","T Knife","CT Gloves","T Gloves"}) {
      InventoryItem i=app.inventoryList.stream().filter(x->x.name.equals(gun+" | Default")).findFirst().get();
      Image image=app.cs2EquipmentScreens.defaultWeaponImage(i.name);
      check(image!=null&&image.getWidth(null)>100&&i.price.signum()==0,"Genuine stock artwork and zero value: "+gun);
      check(app.loadoutScreen.isUsableOnSide(i,gun.startsWith("T "))&&!app.loadoutScreen.isUsableOnSide(i,!gun.startsWith("T ")),"Stock equipment respects T/CT side: "+gun);
    }
    Mission m=new Mission("followup","Collect 10","test","INVENTORY",10,1);app.activeMissions.clear();app.activeMissions.add(m);
    edt(()->app.missionService.checkMissionProgress());check(m.current==0&&!m.completed,"Stock guns, knives and gloves do not advance skin-count missions");
    edt(()->app.missionService.checkInventoryCollectionAchievements());
    check(app.achievements.get("low_float_5").progress==0&&app.achievements.get("knife_3types").progress==0,"Defaults do not award low-float or knife-collection achievements");
    InventoryItem real=item("AK-47 | Slate",.025);app.inventoryList.add(real);edt(()->app.missionService.checkMissionProgress());
    check(m.current==1,"An actual owned skin advances inventory missions exactly once");
    app.inventoryList.remove(real);app.activeMissions.clear();
    JLabel late=new JLabel("Loading image…");
    edt(()->{app.artworkService.registerPendingRemoteImageLabel("cs2-stock-async-test",late,100,60);app.imageRepository.put("cs2-stock-async-test",new BufferedImage(120,80,BufferedImage.TYPE_INT_ARGB));});
    edt(()->{});check(late.getIcon()!=null&&late.getText().isEmpty(),"A late stock PNG updates its existing label on the EDT without tab navigation");
    Path src=Path.of("/home/user/cs2-simulator/src/blahblah");
    for(String removed:new String[]{"MarketEvents","ActiveMarketEvent","MarketEventDefinition","MarketEventMarker"})check(!Files.exists(src.resolve(removed+".java")),"Removed event engine type: "+removed);
    check(Arrays.stream(SimulatorContext.class.getDeclaredFields()).noneMatch(f->f.getName().toLowerCase().contains("marketevent")),"No random-event state, event factor or event timer remains");
    for(InventoryItem i:app.inventoryList)if(app.cs2EquipmentScreens.isDefaultWeaponItem(i))check(i.price.signum()==0,"Default retains zero price: "+i.name);
  }
  static void pricingAndGrouping()throws Exception {
    InventoryItem a=item("AWP | Gungnir",.012),b=item("AWP | Gungnir",.059);a.condition="Factory New";b.condition="Factory New";b.patternID=982;
    MarketplaceProfile auto=MarketplaceProfile.byName("CS.MONEY"),custom=MarketplaceProfile.byName("Skinport");
    MarketListing x=lot(a,auto.name,120,15),y=lot(b,auto.name,180,4);app.exchangeSiteStock.put(auto.name,new ArrayList<>(List.of(x,y)));
    check(x.getPrice()!=y.getPrice(),"Individual automatic-site backing offers preserve their different simulated asks");
    check(app.marketplacePricing.quickSellQuote(auto,a)>app.marketplacePricing.quickSellQuote(auto,b),"Automatic quick-sell quotes now value the better float above the ordinary float");
    MarketListing cx=lot(a,custom.name,120,15),cy=lot(b,custom.name,180,4);
    check(cx.getPrice()==120&&cy.getPrice()==180,"Custom-ask sites preserve different prices for the same variant");
    List<MarketplaceGroups.Group> grouped=app.marketplaceGroups.group(List.of(cx,cy));
    check(grouped.size()==1&&grouped.get(0).units()==19&&grouped.get(0).lots.size()==2,"19 independent units collapse into two compact backing lots");
    check(cx.quantity==15&&cy.quantity==4&&cx.item==a&&cy.item==b,"Collapsing groups leaves backing stock and its seed records unchanged");
    app.exchangeSiteStock.put(auto.name,new ArrayList<>(List.of(x,y)));app.exchangeSiteStock.put(custom.name,new ArrayList<>(List.of(cx,cy)));
    check(app.marketplacePricing.suggested(custom,a)==Math.round((Math.min(app.marketplaceUnitStock.floorAsk(cx),app.marketplaceUnitStock.floorAsk(cy))-.01)*100)/100.0,"Custom undercut shortcut computes lowest comparable ask minus one cent");
    app.inventoryList.add(a);app.inventoryList.add(b);
    try{app.exchangeTransactionService.commitExchangeListing(auto,a,x.getPrice()+1);throw new AssertionError("Automatic ask override succeeded");}catch(IllegalArgumentException expected){check(app.inventoryList.contains(a),"Automatic price enforcement rejects edited asks atomically");}
    JPanel[] buy={null},sell={null};edt(()->{buy[0]=app.exchangeCatalogScreens.createExchangeBuy(custom,"Gungnir");sell[0]=app.exchangeCatalogScreens.createExchangeSell(custom,a);});
    JPanel grid=find(buy[0],JPanel.class,"exchangeBuyGrid");check(grid.getComponentCount()==1,"Buy catalog renders one grouped stack, not duplicate same-variant cards");
    edt(()->click(grid.getComponent(0)));JPanel offers=find(app.exchangeHostSections.getSelectedComponent(),JPanel.class,"exchangeStackIndividuals");
    check(offers!=null&&offers.getComponentCount()==15,"Expanding a stack pages independently selectable stock units in a new tab");
    JPanel offer=find(offers,JPanel.class,"exchangeListingCard");Rectangle[] before={null};Insets[] padding={null};
    edt(()->{buy[0].setSize(1440,960);DevGeneratorTests.layout(buy[0]);before[0]=offer.getComponent(0).getBounds();padding[0]=offer.getInsets();click(offer);});
    JPanel again=find(buy[0],JPanel.class,"exchangeListingCard");
    JPanel newOffers=find(app.exchangeHostSections.getSelectedComponent(),JPanel.class,"exchangeStackIndividuals");JPanel selected=find(newOffers,JPanel.class,"exchangeListingCard");
    edt(()->DevGeneratorTests.layout(buy[0]));
    check(Boolean.TRUE.equals(selected.getClientProperty("marketSelected"))&&padding[0].equals(selected.getInsets())&&before[0].equals(selected.getComponent(0).getBounds()),"Selecting an individual offer retains artwork/text bounds and border insets");
    check(find(newOffers,JButton.class,"exchangeOfferBuy").isEnabled(),"The selected offer exposes its enabled Buy button without moving card contents");
    check(find(sell[0],JPanel.class,"exchangeSellGrid").getComponentCount()==1,"Sell inventory also groups variants while retaining real owned identities");
    render(buy[0],"followup-grouped-offers.png");
    // Equal-price container lots are one aggregate card, not repeated copies.
    CaseType ct=Cs2RedesignTests.source("Revolution Case");InventoryItem box=item(ct.catalogCrateName(),0);box.condition="Normal";
    MarketListing c1=lot(box,custom.name,1.23,11),c2=lot(box,custom.name,1.23,7);app.exchangeSiteStock.put(custom.name,new ArrayList<>(List.of(c1,c2)));
    edt(()->buy[0]=app.exchangeCatalogScreens.createExchangeBuy(custom,"Revolution"));
    check(find(buy[0],JPanel.class,"exchangeBuyGrid").getComponentCount()==1&&GoldTradeUpTests.labels(buy[0]).contains("18 available"),"Identical-price container lots show once with summed stock");
    app.inventoryList.remove(a);app.inventoryList.remove(b);
  }
  static void layoutsAndChooser()throws Exception {
    InventoryItem sale=item("AK-47 | Slate",.025);app.inventoryList.add(sale);
    Set<String> buyTrees=new HashSet<>(),sellTrees=new HashSet<>(),swapTrees=new HashSet<>();int automatic=0;
    for(MarketplaceProfile site:MarketplaceProfile.CATALOG) {
      if(MarketplacePricing.automatic(site.name))automatic++;
      JPanel[] buy={null},sell={null};edt(()->{buy[0]=app.exchangeCatalogScreens.createExchangeBuy(site,"");sell[0]=app.exchangeCatalogScreens.createExchangeSell(site,sale);});
      System.out.println("STRUCTURE "+site.name+" BUY="+tree(buy[0]).hashCode()+" SELL="+tree(sell[0]).hashCode());buyTrees.add(tree(buy[0]));sellTrees.add(tree(sell[0]));
      JTextField ask=find(sell[0],JTextField.class,"exchangeSellAsk");check(ask.isEditable()!=MarketplacePricing.automatic(site.name),site.name+" uses its declared automatic/custom Sell price policy");
      check(!GoldTradeUpTests.labels(buy[0]).contains("Wallet"),site.name+" has no duplicate site-wallet label");
      if(ExchangeStockService.supportsExchangeSwap(site.name)){JPanel[] swap={null};edt(()->swap[0]=app.exchangeCatalogScreens.createExchangeSwap(site));swapTrees.add(tree(swap[0]));}
      if(Arrays.asList("CS.MONEY","DMarket","SkinSwap","MirageX","VaultDrop").contains(site.name)){render(buy[0],"followup-"+site.name.replace('.','-')+"-buy.png");render(sell[0],"followup-"+site.name.replace('.','-')+"-sell.png");}
    }
    check(buyTrees.size()==18&&sellTrees.size()==18,"All 18 Buy and all 18 Sell layouts have distinct component hierarchies, not recolors");
    check(swapTrees.size()==5,"The five supported Swap sites have distinct workspace hierarchies");
    check(automatic==8,"Eight sites use automatic float-aware valuations; ten let the seller set an ask");
    edt(()->app.exchangeScreens.navigateExchangeDirectory(sale));
    JPanel directory=find(app.marketTabPanel,JPanel.class,"marketplaceDirectory");
    check(directory!=null&&app.exchangeHostSections.getSelectedIndex()==1&&app.exchangePendingSale==sale,"Inventory Sell on Market opens the dedicated chooser and retains the exact sale item");
    check(find(directory,JPanel.class,"marketplaceDirectoryGrid").getComponentCount()==18,"The chooser lists all 18 marketplaces");
    edt(()->find(directory,JButton.class,"marketplaceDirectoryOpen-Skinport").doClick());
    JTabbedPane tabs=find(app.exchangeHostSections.getSelectedComponent(),JTabbedPane.class,"marketplaceSiteTabs");
    check(tabs.getSelectedIndex()==2&&find(tabs,JTextField.class,"exchangeSellAsk").isEditable(),"Choosing a site opens its Sell desk for the retained item");
    app.inventoryList.remove(sale);
  }
  static void swapGrouping()throws Exception {
    MarketplaceProfile site=MarketplaceProfile.byName("SkinSwap");
    InventoryItem first=item("AWP | Gungnir",.013),second=item("AWP | Gungnir",.054);
    app.inventoryList.add(first);app.inventoryList.add(second);
    MarketListing one=lot(item("AWP | Gungnir",.02),site.name,110,3),two=lot(item("AWP | Gungnir",.05),site.name,120,4);
    app.exchangeSiteStock.put(site.name,new ArrayList<>(List.of(one,two)));
    app.globalMarketListings.put(one.item.name,new ArrayList<>(List.of(one,two)));
    JPanel[] swap={null};edt(()->swap[0]=app.exchangeCatalogScreens.createExchangeSwap(site));
    JPanel user=find(swap[0],JPanel.class,"exchangeSwapUserGrid"),stock=find(swap[0],JPanel.class,"exchangeSwapSiteGrid");
    check(user.getComponentCount()==1&&stock.getComponentCount()==1,"Swap halves group identical owned variants and actual site offers");
    SwingUtilities.invokeLater(()->click(((Container)user.getComponent(0)).getComponent(0)));
    Cs2RedesignTests.flush();JPanel dialog=(JPanel)app.exchangeHostSections.getSelectedComponent();JPanel individuals=find(dialog,JPanel.class,"exchangeStackIndividuals");
    check(individuals.getComponentCount()==2,"Expanding an owned Swap stack displays exactly its two real inventory identities");
    edt(()->click(individuals.getComponent(0)));
    edt(()->click(individuals.getComponent(1)));
    check(GoldTradeUpTests.labels(swap[0]).contains("$210.00  (2)"),"Choosing two individual owned skins credits each exact identity once");
    edt(()->MarketplaceOpeningChecks.button(dialog,"Close tab").doClick());
    SwingUtilities.invokeLater(()->click(stock.getComponent(0)));
    Cs2RedesignTests.flush();JPanel choices=(JPanel)app.exchangeHostSections.getSelectedComponent();JPanel rows=find(choices,JPanel.class,"exchangeStackIndividuals");
    check(rows.getComponentCount()==7,"Expanding site stock exposes all seven independently selectable float-bearing units");
    MarketListing selectedUnit=(MarketListing)((JComponent)rows.getComponent(0)).getClientProperty("marketListing");
    edt(()->click(rows.getComponent(0)));
    check(GoldTradeUpTests.labels(swap[0]).contains(String.format("$%,.2f  (1)",app.exchangeTransactionService.swapSiteValue(selectedUnit))),"Site selection uses the displayed real lot and the disclosed 10–15 percent Swap markup");
    edt(()->MarketplaceOpeningChecks.button(choices,"Close tab").doClick());
    check(one.quantity==3&&two.quantity==4&&app.inventoryList.contains(first)&&app.inventoryList.contains(second),"Previewing and selecting Swap stacks does not consume inventory or stock");
    app.inventoryList.remove(first);app.inventoryList.remove(second);
  }
  static void containerContents()throws Exception {
    CaseType source=null;for(CaseType ct:CaseType.values())if(ct.isSouvenir
        &&!ct.regularDropNames.getOrDefault("Consumer",Collections.emptyList()).isEmpty()
        &&!ct.regularDropNames.getOrDefault("Industrial",Collections.emptyList()).isEmpty()){source=ct;break;}
    check(source!=null,"A genuine souvenir fixture includes Consumer and Industrial outcomes");
    final CaseType ct=source;final JDialog[] owner={null};final JPanel[] content={null};int owned=app.inventoryList.size();
    edt(()->{owner[0]=new JDialog(app,"Container contents test",false);app.cs2ContainerDialog=owner[0];
      content[0]=app.cs2Screens.createCs2ContainerPanel(ct,owner[0]);owner[0].setContentPane(content[0]);owner[0].setSize(1440,960);owner[0].setVisible(true);});
    JPanel grid=find(content[0],JPanel.class,"cs2ContainerContents");
    int expected=ct.regularDropNames.values().stream().mapToInt(List::size).sum()+(ct.rareDropNames.isEmpty()?0:1);
    check(grid.getComponentCount()==expected,"Container contents include every rarity, including outcomes below Milspec");
    check(!GoldTradeUpTests.labels(content[0]).contains("Inspect Items"),"The redundant right-side Inspect Items button is gone");
    edt(()->click(grid.getComponent(0)));JMenuItem inspect=null;
    for(MenuElement element:MenuSelectionManager.defaultManager().getSelectedPath())if(element instanceof JPopupMenu)
      for(Component c:((JPopupMenu)element).getComponents())if(c instanceof JMenuItem&&((JMenuItem)c).getText().equals("Inspect"))inspect=(JMenuItem)c;
    check(inspect!=null,"Clicking an unowned container outcome opens an Inspect action");
    final JMenuItem command=inspect;SwingUtilities.invokeLater(command::doClick);
    MarketplaceOpeningChecks.waitFor(()->MarketplaceOpeningChecks.dialog("Inspect")!=null,4000);
    JDialog view=MarketplaceOpeningChecks.dialog("Inspect");
    check(view.getOwner()==owner[0]&&owner[0].isShowing(),"Outcome inspection is correctly owned by the still-open container GUI");
    edt(()->{view.dispose();owner[0].dispose();app.cs2ContainerDialog=null;});
    check(app.inventoryList.size()==owned,"Inspecting an unowned outcome does not grant or alter inventory");
  }
  public static void main(String[] args)throws Exception {
    Thread.setDefaultUncaughtExceptionHandler((t,e)->{e.printStackTrace();System.exit(1);});
    Cs2RedesignTests.setup();app=Cs2RedesignTests.gui;
    defaults();pricingAndGrouping();layoutsAndChooser();swapGrouping();containerContents();
    edt(()->{for(Window w:Window.getWindows())w.dispose();});
    System.out.println("All "+checks+" follow-up checks passed.");System.exit(0);
  }
}
