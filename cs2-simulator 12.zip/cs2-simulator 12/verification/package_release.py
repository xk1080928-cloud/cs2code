"""Verify and package the complete current project; no external artwork/catalog fixtures required.
Run: python verification/package_release.py [output.zip]
The optional lab/native tests require their documented external fixtures and are not rerun here.
"""
from pathlib import Path
import hashlib,json,os,shutil,subprocess,sys,zipfile,base64,re

P=Path(__file__).resolve().parents[1]
R=P.parent
C=R/'.cache'/'card-packaging'
C.mkdir(parents=True,exist_ok=True)
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def run(args,cwd=None,timeout=90):
    result=subprocess.run(list(map(str,args)),cwd=cwd,text=True,stdout=subprocess.PIPE,stderr=subprocess.STDOUT,timeout=timeout)
    if result.returncode:raise RuntimeError(result.stdout)
    return result.stdout

sources=sorted((P/'src').rglob('*.java'))
assert len(sources)==187
assert not any(p.stem in {'PriceChartScreen','MarketCapChartPanel','MarketCapSample'} for p in sources)
assert (P/'src/blahblah/MarketHistoryScreen.java').is_file() and (P/'src/blahblah/SalesHistoryScreen.java').is_file()
source_manifest=''.join(f'{sha(p)}  {p.relative_to(P).as_posix()}\n' for p in sources)
assert (P/'SOURCE_SHA256SUMS.txt').read_text()==source_manifest
proof=json.loads((P/'verification/card-release-proof.json').read_text())
assert proof['source_manifest_sha256']==hashlib.sha256(source_manifest.encode()).hexdigest()
assert proof['native_assertions']==971 and proof['native_suites']==20 and proof['headless']['passed_suites']==19
assert proof['headless']['passing_checks']==578

assert sha(P/'verification/previous-buffer-extension.dat')==proof['old_buffer_fixture_sha256']
agent_rows=json.loads((P/'verification/agent-preview-sources.json').read_text())
encoded={}
for statement in re.findall(r'DATA\.put\((.*?)\);',(P/'src/blahblah/BundledAgentPreviews.java').read_text(),re.S):
    literals=re.findall(r'"(?:[^"\\]|\\.)*"',statement)
    values=[json.loads(x) for x in literals]
    encoded[values[0]]=base64.b64decode(''.join(values[1:]))
assert len(encoded)==len(agent_rows)==63
for agent in agent_rows:
    image=encoded[agent['name']]
    assert image.startswith(b'\x89PNG\r\n\x1a\n')
    assert hashlib.sha256(image).hexdigest()==agent['preview_sha256'],agent['name']

# Embedded collection previews use genuine URLs; decode every image and match its audit hash.
collection_rows=json.loads((P/'verification/collection-emblem-sources.json').read_text())
collection_pngs={}
for statement in re.findall(r'ICONS\.put\((.*?)\);',(P/'src/blahblah/CollectionEmblems.java').read_text(),re.S):
    values=[json.loads(v) for v in re.findall(r'"(?:[^"\\]|\\.)*"',statement)]
    collection_pngs[values[0]]=base64.b64decode(''.join(values[1:]))
assert len(collection_pngs)==len(collection_rows)==110
for row in collection_rows:
    image=collection_pngs[row['name']]
    assert image.startswith(b'\x89PNG\r\n\x1a\n')
    assert hashlib.sha256(image).hexdigest()==row['preview_sha256'],row['name']
for row in json.loads((P/'verification/card-preserved-models.json').read_text()):
    assert sha(P/'src/blahblah'/row['file'])==row['sha256']
audit=json.loads((P/'verification/stattrak-artwork-audit.json').read_text())
assert audit['stattrak_entries']==audit['same_png_as_normal_matching_finish_and_wear']==5280
assert audit['distinct_png_entries']==0

excluded={'build','target','.cache','__pycache__','node_modules','.git'}
files=sorted(p for p in P.rglob('*') if p.is_file() and not (set(p.relative_to(P).parts)&excluded) and p.name!='SHA256SUMS.txt')
(P/'SHA256SUMS.txt').write_text(''.join(f'{sha(p)}  {p.relative_to(P).as_posix()}\n' for p in files))
files.append(P/'SHA256SUMS.txt')
archive=C/'complete-project-verified.zip'
with zipfile.ZipFile(archive,'w',zipfile.ZIP_DEFLATED,compresslevel=9) as z:
    for p in files:z.write(p,'cs2-simulator/'+p.relative_to(P).as_posix())
extracted=C/'extracted'
if extracted.exists():shutil.rmtree(extracted)
extracted.mkdir()
with zipfile.ZipFile(archive) as z:
    assert z.testzip() is None
    assert len(z.namelist())==len(files)
    for p in files:assert hashlib.sha256(z.read('cs2-simulator/'+p.relative_to(P).as_posix())).hexdigest()==sha(p),str(p)
    z.extractall(extracted)
root=extracted/'cs2-simulator'
for manifest in ['SOURCE_SHA256SUMS.txt','SHA256SUMS.txt']:
    for line in (root/manifest).read_text().splitlines():
        expected,path=line.split('  ',1)
        assert sha(root/path)==expected,path
build=run(['sh','build.sh'],cwd=root)
(R/'verification').mkdir(exist_ok=True)
(R/'verification/card-extracted-build.txt').write_text(build)
schema_classes=C/'schema-classes';schema_classes.mkdir(exist_ok=True)
run(['javac','-encoding','UTF-8','--release','11','-d',schema_classes,root/'verification/SaveSchemaDump.java'])
schema=run(['java','-cp',str(root/'build/classes')+os.pathsep+str(schema_classes),'SaveSchemaDump'])
assert schema==(P/'verification/liquidity-save-schema.txt').read_text()
result=dict(java_files=len(sources),archived_files=len(files),archive_bytes=archive.stat().st_size,archive_sha256=sha(archive),crc='passed',all_archived_checksums='passed',extracted_JDK11_build='passed',five_original_save_descriptors='unchanged',native_suites=20,native_assertions=971,headless_suites=19,headless_assertions=578)
destination=Path(sys.argv[1]).resolve() if len(sys.argv)>1 else R/'cs2-simulator-source.zip'
# Never replace the delivered ZIP until build, descriptors, CRCs and all hashes have passed.
os.replace(archive,destination)
(R/'verification/card-package-verification.json').write_text(json.dumps(result,indent=2)+'\n')
destination.with_suffix(destination.suffix+'.verification.json').write_text(json.dumps(result,indent=2)+'\n')
destination.with_suffix(destination.suffix+'.sha256').write_text(result['archive_sha256']+'  '+destination.name+'\n')
print(json.dumps(result,indent=2))
