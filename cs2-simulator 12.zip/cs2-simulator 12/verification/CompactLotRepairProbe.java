package blahblah;

import java.awt.Window;
import java.math.BigDecimal;
import java.util.ArrayList;

/** Same ten-million-unit probe against the previous release and the current release. */
public class CompactLotRepairProbe {
  public static void main(String[] args) throws Exception {
    Thread.setDefaultUncaughtExceptionHandler((t,e)->{e.printStackTrace();System.exit(1);});
    String mode=args.length==0?"fixed":args[0];
    Cs2RedesignTests.setup();
    hGui app=Cs2RedesignTests.gui;
    Cs2RedesignTests.edt(()->{
      app.backgroundUnboxing.stop();if(app.marketTimer!=null)app.marketTimer.stop();
      app.globalMarketListings.clear();app.inventoryList.clear();app.ownedSupplies.clear();app.activeListings.clear();
      app.inventoryToolsService.state=new InventoryToolsState();
    });
    String name="AK-47 | Slate";
    int target=app.marketStockService.getMarketSupplyTargets(name,false).get("Field-Tested");
    int parents=target*20,quantity=10_000_000/parents,remainder=10_000_000%parents;
    ArrayList<MarketListing> lots=new ArrayList<>();
    for(int n=0;n<parents;n++){
      InventoryItem i=new InventoryItem(null,name,"Field-Tested","Restricted",BigDecimal.valueOf(10+n*.01),.2,false,0,null,10,true);
      MarketListing l=new MarketListing(i,10+n*.01,120,true);l.isPlayerListing=false;
      l.quantity=quantity+(n==parents-1?remainder:0);lots.add(l);
    }
    app.globalMarketListings.put(name,lots);app.globalSupply.initialize();
    long before=app.marketStockService.getTotalMarketListingCount(),world=app.globalSupply.total();
    Cs2RedesignTests.edt(()->app.marketStockService.trimMarketListingsForResponsiveUi());
    long after=app.marketStockService.getTotalMarketListingCount();
    System.out.println("COMPACT REPAIR PROBE: mode="+mode+", before="+before+", after="+after+", worldBefore="+world+", worldAfter="+app.globalSupply.total()+", initialParents="+parents+", survivingParents="+lots.size()+", legacyWearTarget="+target);
    if(before!=10_000_000||world!=10_000_000||app.globalSupply.total()!=world)throw new AssertionError("Invalid probe/conservation");
    if(mode.equals("old")){if(after<400_000||after>600_000)throw new AssertionError("Expected legacy collapse");}
    else if(after!=before||lots.size()!=parents)throw new AssertionError("Live compact parents were truncated");
    System.out.println("PASS: "+(mode.equals("old")?"Previous-release compact-lot repair reproduces a ten-million to roughly-five-hundred-thousand listing collapse; surviving world stock is unchanged.":"Current live repair preserves all ten million listed units and every compact parent."));
    Cs2RedesignTests.edt(()->{for(Window w:Window.getWindows())w.dispose();});System.exit(0);
  }
}
